<!-- pop up image -->

<!-- get current date and expiry date -->
<?php

// time_zone
date_default_timezone_set('Asia/Kolkata');

$currentDateTime =date('Y-m-d');
$ExpiryDateTime=date('2021-09-16');

?>

<?php 
     if ($currentDateTime < $ExpiryDateTime)
     {
?>
<style>
body {
    overflow: hidden;
}
</style>
<section class="imagepopup-section" style="display:block;">
    <div class="container-fluid">
        <div class="row">
            <div class="col p-0">
                <a href="<?php echo base_url(); ?>promotions">
                    <img class=" img-fluid RdayPost_img"
                        src="<?php echo base_url();?>dist/img/iDayWebPopup_Extended.svg"
                        alt="iDayWebPopup_Extended.png">
                </a>
                <i class="fa fa-3x fa-times-circle close_img" aria-hidden="true" style="position:fixed;"></i>
            </div>

        </div>
    </div>
</section>
<?php
     }

?>




<div class="hero-wrap js-fullheight hero-section">

    <div class="container-fluid px-0">

        <div class="row d-md-flex no-gutters slider-text align-items-center js-fullheight justify-content-end">

            <div class="one-forth d-flex align-self-end ftco-animate js-fullheight mt-5">
                <div class="text mt-5">
                    <h1><span>Complex Analytics, Simplified!</span></h1>
                    <h1 class="mb-3 subheading">C5 CDR ANALYZER</h1>
                    <p class="h6">Your search for a robust, high performing, affordable, CDR analysis software
                        ends here.</p>
                    <p><a href="<?php echo base_url(); ?>products/cdr-analysis-software"
                            class="btn px-4 py-3 text-light button-color btn-primary">Know More</a></p>
                </div>
            </div>
            <!-- <img  class="one-third js-fullheight align-self-end order-md-last img-fluid"
                src="<?php echo base_url(); ?>dist/img/newbundleoffer.svg" alt="Home-svg"> -->


            <img class="one-third js-fullheight align-self-end order-md-last img-fluid Hero_img"
                src="<?php echo base_url() ;?>dist/img/homeHero.svg">

        </div>
    </div>
</div>

<!-- <div class="hero-wrap js-fullheight hero-section">

    <div class="container-fluid px-0">

        <div class="row d-md-flex no-gutters slider-text align-items-center js-fullheight justify-content-end">

            <div class="one-forth d-flex align-self-end ftco-animate js-fullheight mt-5">
                <div class="text mt-5">
                    <h1><span>Complex Analytics, Simplified!</span></h1>
                    <h1 class="mb-3 subheading">C5 CDR ANALYZER</h1>
                    <p class="h6">Your search for a robust, high performing, affordable, CDR data analysis solution
                        ends here.</p>
                    <p><a href="<?php echo base_url(); ?>Product/c5cdr"
                            class="btn px-4 py-3 text-light button-color btn-primary">Know More</a></p>
                </div>
            </div


            <img  class="one-third js-fullheight align-self-end order-md-last img-fluid Hero_img"
            style="display:none;">

        </div>
    </div>
</div> -->

<!-- video section -->
<section class=" bg-lightgrey mt-5 d-flex justify-content-center">
    <iframe width="560" height="315" src="https://www.youtube.com/embed/KS_j4ZGzn0Y?enablejsapi=1&rel=0" frameborder="0"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
        allowfullscreen></iframe>
</section>

<section class=" bg-light mt-5">
    <div class="container">
        <div class="row justify-content-center mb-5 pb-3">
            <div class="col-md-7 text-center heading-section ftco-animate">
                <h2 class="mb-0">Our Clientele </h2>
                <p class="h5 mb-0">Providing you with powerful analytical tools, is what we do best.</p>
            </div>
        </div>
        <div class="row justify-content-center mb-10 pb-3">
            <div class="col-md-12 d-flex align-self-stretch ftco-animate">
                <div id="clients" class="owl-carousel clients owl-theme">
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-karnataka_state_police.jpg"
                                class="img-fluid" alt="Prosoft-karnataka state police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img src="<?php echo base_url(); ?>dist/img/clients/prosoft-CBI.jpg"
                                class="img-fluid" alt="Prosoft-CBI"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-income_tax.png" class="img-fluid"
                                alt="Prosoft-income_tax"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img src="<?php echo base_url(); ?>dist/img/clients/prosoft-NIA.jpg"
                                class="img-fluid" alt="Prosoft-NIA"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img src="<?php echo base_url(); ?>dist/img/clients/prosoft-ED.jpg"
                                class="img-fluid" alt="Prosoft-ED"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img src="<?php echo base_url(); ?>dist/img/clients/prosoft-RPF.jpg"
                                class="img-fluid" alt="Prosoft-RPF"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-karnataka_forest_department.jpg"
                                class="img-fluid" alt="Prosoft-karnataka_forest_department"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-NASSCOM.jpg" class="img-fluid"
                                alt="Prosoft-NASSCOM"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-C-DAC.jpg" class="img-fluid"
                                alt="Prosoft-C-DAC"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-telangana_police.jpg"
                                class="img-fluid" alt="Prosoft-telangana_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-cyberabad_police.jpg"
                                class="img-fluid" alt="Prosoft-cyberabad_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-odisha_police.jpg"
                                class="img-fluid" alt="Prosoft-odisha_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-bangalore_city_police.jpg"
                                class="img-fluid" alt="Prosoft-bangalore_city_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-tamilnadu_police.jpg"
                                class="img-fluid" alt="Prosoft-tamilnadu_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-bihar_police.jpg"
                                class="img-fluid" alt="Prosoft-bihar_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-punjab_police.jpg"
                                class="img-fluid" alt="Prosoft-punjab_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-kerala_police.jpg"
                                class="img-fluid" alt="Prosoft-kerala_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-maharashtra_police.jpg"
                                class="img-fluid" alt="Prosoft-maharashtra_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-gujrat_police.jpg"
                                class="img-fluid" alt="Prosoft-gujrat_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-kolkata_police.jpg"
                                class="img-fluid" alt="Prosoft-kolkata_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-rajasthan_police.jpg"
                                class="img-fluid" alt="Prosoft-rajasthan_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-chhattisgarh_police.jpg"
                                class="img-fluid" alt="Prosoft-chhattisgarh_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-mumbai_police.jpg"
                                class="img-fluid" alt="Prosoft-mumbai_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-andhra_pradesh_police.jpg"
                                class="img-fluid" alt="Prosoft-andhra_pradesh_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-west_bengal_police.jpg"
                                class="img-fluid" alt="Prosoft-west_bengal_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-bangladesh_police.jpg"
                                class="img-fluid" alt="Prosoft-bangladesh_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-algeria_police.jpg"
                                class="img-fluid" alt="Prosoft-algeria_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-nigeria_police.jpg"
                                class="img-fluid" alt="Prosoft-nigeria_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-lokayukta.png" class="img-fluid"
                                alt="Prosoft-lokayukta"></a>
                    </div>
                </div>

                <script>
                $(document).ready(function() {
                    var owlClients = $('.clients');
                    owlClients.owlCarousel({
                        items: 6,
                        loop: true,
                        margin: 10,
                        autoplay: true,
                        autoplayTimeout: 1000,
                        autoplayHoverPause: true
                    });
                    /*$('.play').on('click', function() {
			owl.trigger('play.owl.autoplay', [1000])
		  })
		  $('.stop').on('click', function() {
			owl.trigger('stop.owl.autoplay')
		  })*/

                    var owlMobileImages = $('.mobile_images');
                    owlMobileImages.owlCarousel({
                        items: 4,
                        loop: true,
                        margin: 10,
                        autoplay: true,
                        autoplayTimeout: 1000,
                        autoplayHoverPause: true
                    });

                    var owlCustomers = $('.customers');
                    owlCustomers.owlCarousel({
                        items: 2,
                        loop: true,
                        margin: 50,
                        autoplay: true,
                        autoplayTimeout: 3000,
                        autoplayHoverPause: true
                    });

                })
                </script>
            </div>
        </div>
    </div>
</section>

<section class="plan-section ftco-section bg-light">
    <div class="container">
        <div class="row justify-content-center mb-2 pb-2">
            <div class="col-xs-7 col-sm-7 col-md-7 col-lg-7 text-center heading-section ftco-animate ">
                <h2 class="mb-0">Choose a Plan</h2>
                <p class="h5">We offer pricing plans that fit all investigation types and team sizes. Compare and find
                    the best plan for you.</p>
            </div>
        </div>
    </div>
    <div class="container plan-container">
        <div class="row">
            <div class="ftco-animate">
                <div class="card Ccard First-card">
                    <div class="card-body">
                        <h2 class="card-title font-weight-bold"><span class="card-heading">Free
                                Trial</span><span>
                                <!-- <img class="float-right card-svg" src="<?php echo base_url(); ?>dist/img/edition/001-trial.svg" alt="Home-png"> -->
                                <img class="float-right card-svg"
                                    src="<?php echo base_url(); ?>dist/img/ficons/trial.svg" alt="Home-png">
                            </span>
                        </h2>
                        <p class="card-text text-left h5 mt-5">The perfect way to test out your analytical needs and
                            later upgrade to what suites you best.</p>
                        <hr class="hr bg-dark">
                        <ul class="list-unstyled">
                            <li class="h6">
                                <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg" alt="rightmark svg">
                                <strong>30 days </strong> Licence
                            </li>

                            <li class="h6">
                                <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg" alt="rightmark svg">
                                <strong>All Features </strong> Unlocked
                            </li>

                            <li class="h6">
                                <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg" alt="rightmark svg">
                                <strong>No Payments </strong> Required
                            </li>

                            <li class="h6">
                                <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg" alt="rightmark svg">
                                Quick Installation
                            </li>

                            <li class="h6">
                                <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg" alt="rightmark svg">
                                Easy to Upgrade
                                <!-- to Premium -->
                            </li>

                            <li class="h6">
                                <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg" alt="rightmark svg">
                                Mobile App
                            </li>

                        </ul>
                        <a href="<?php echo base_url(); ?>UserInfo?edition=TRIAL"
                            class="btn btn-primary d-block px-3 py-3 mt-4"> Start Free Trial</a>
                    </div>
                </div>
            </div>

            <!-- <div class="ftco-animate">
                <div class="card Ccard second-card">
                    <div class="card-body">
                        <h2 class="card-title font-weight-bold text-light"><span class="card-heading">Lite
                                Edition</span>
                            <span>
                                <img class="float-right card-svg text-light" style="background-color:white;" src="<?php echo base_url(); ?>dist/img/edition/002-lite.svg" alt="Home-png">
                                <img class="float-right card-svg text-light" style="background-color:white;"
                                    src="<?php echo base_url(); ?>dist/img/ficons/lite.svg" alt="Home-png">
                            </span>
                        </h2>
                        <p class="card-text h5 text-light text-left  mt-5">A great plan for Investigation officers
                            looking to take their data analytics skills to the next level.</p>
                        <hr class="bg-light hr">
                        <ul class="list-unstyled text-light">
                            <li class="h6">
                                <img src="<?php echo base_url();?>dist/img/edition/whiterightmark.svg"
                                    alt="rightmark svg" class="text-light">
                                Prepetual Licence
                            </li>

                            <li class="h6">
                                <img src="<?php echo base_url();?>dist/img/edition/whiterightmark.svg"
                                    alt="rightmark svg">
                                Quick Analysis
                            </li>

                            <li class="h6">
                                <img src="<?php echo base_url();?>dist/img/edition/whiterightmark.svg"
                                    alt="rightmark svg">
                                Geo Analysis
                            </li>

                            <li class="h6">
                                <img src="<?php echo base_url();?>dist/img/edition/whiterightmark.svg"
                                    alt="rightmark svg">
                                Frequencies
                            </li>

                            <li class="h6">
                                <img src="<?php echo base_url();?>dist/img/edition/whiterightmark.svg"
                                    alt="rightmark svg">
                                Common Numbers
                            </li>

                            <li class="h6">
                                <img src="<?php echo base_url();?>dist/img/edition/whiterightmark.svg"
                                    alt="rightmark svg">
                                Print Ready Reports
                            </li>

                        </ul>
                        <a href="<?php echo base_url(); ?>UserInfo?edition=LITE"
                            class="btn btn-light d-block px-3 py-3 mt-4">Buy Now</a>
                    </div>
                </div>
            </div> -->

            <div class="ftco-animate">

                <?php

                if ($currentDateTime < $ExpiryDateTime)
                {
                ?>

                <div class="card Ccard iDay_card">
                    <?php
                }
                else
                {
                ?>


                    <div class="card Ccard offer-card-reg">

                        <?php
                }
                ?>

                        <div class="card-body">
                            <h2 class="card-title font-weight-bold text-dark"><span class="card-heading">Lite
                                    Edition</span>
                                <span>


                                    <!--change offer_svg based on date-->
                                    <?php

                                    if ($currentDateTime < $ExpiryDateTime)
                                    {
                                ?>

                                    <img class="float-right card-svg " style="background-color:white;"
                                        src="<?php echo base_url(); ?>dist/img/ficons/lite_republic.svg"
                                        alt="Home_republic-png">
                                    <?php
                                    }
                                    else
                                    {
                                ?>


                                    <img class="float-right card-svg offer_svg" style="background-color:white;"
                                        src="<?php echo base_url(); ?>dist/img/ficons/lite.svg" alt="Home-png">

                                    <?php
                                    }
                                ?>
                                    <!-- <img class="float-right card-svg text-light" style="background-color:white;" src="<?php echo base_url(); ?>dist/img/edition/002-lite.svg" alt="Home-png"> -->


                                    <!-- for republic day -->
                                    <!-- <img class="float-right card-svg " style="background-color:white;"
                                    src="<?php echo base_url(); ?>dist/img/ficons/lite_republic.svg" alt="Home_republic-png"> -->
                                </span>
                            </h2>
                            <p class="card-text h5 text-light text-left  mt-5">A great plan for Investigation officers
                                looking to take their data analytics skills to the next level.</p>
                            <?php

                            if ($currentDateTime < $ExpiryDateTime)
                            {
                            ?>
                            <hr class="hr" style="background-color:#000080">
                            <?php
                            }
                            else
                            {
                            ?>
                            <hr class="hr" style="background-color:#ffffff">
                            <?php
                            }
                            ?>




                            <ul class="list-unstyled text-light">
                                <li class="h6">

                                    <?php

                                if ($currentDateTime < $ExpiryDateTime)
                                {
                            ?>
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark_republic.svg"
                                        alt="rightmark svg" class="text-light rightmark">
                                    <?php
                            }
                            else
                            {
                            ?>
                                    <img src="<?php echo base_url();?>dist/img/edition/whiterightmark.svg"
                                        alt="rightmark svg" class="rightmark">
                                    <?php
                            }
                            ?>


                                    <!-- for republic day -->
                                    <!-- <img src="<?php echo base_url();?>dist/img/edition/rightmark_republic.svg"
                                    alt="rightmark svg" class="text-light rightmark"> -->
                                    Prepetual Licence
                                </li>

                                <li class="h6">
                                    <?php

                                    if ($currentDateTime < $ExpiryDateTime)
                                    {
                                    ?>
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark_republic.svg"
                                        alt="rightmark svg" class="text-light rightmark">
                                    <?php
                                    }
                                    else
                                    {
                                    ?>
                                    <img src="<?php echo base_url();?>dist/img/edition/whiterightmark.svg"
                                        alt="rightmark svg" class="rightmark">
                                    <?php
                                    }
                                    ?>


                                    <!-- for republic day -->
                                    <!-- <img src="<?php echo base_url();?>dist/img/edition/rightmark_republic.svg"
                                    alt="rightmark svg" class="text-dark rightmark"> -->
                                    Quick Analysis
                                </li>

                                <li class="h6">
                                    <?php

                                if ($currentDateTime < $ExpiryDateTime)
                                {
                                ?>
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark_republic.svg"
                                        alt="rightmark svg" class="text-light rightmark">
                                    <?php
                                }
                                else
                                {
                                ?>
                                    <img src="<?php echo base_url();?>dist/img/edition/whiterightmark.svg"
                                        alt="rightmark svg" class="rightmark">
                                    <?php
                                }
                            ?>

                                    <!-- for republic day -->
                                    <!-- <img src="<?php echo base_url();?>dist/img/edition/rightmark_republic.svg"
                                    alt="rightmark svg" class="text-dark rightmark"> -->
                                    Geo Analysis
                                </li>

                                <li class="h6">
                                    <?php

                                if ($currentDateTime < $ExpiryDateTime)
                                {
                                ?>
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark_republic.svg"
                                        alt="rightmark svg" class="text-light rightmark">
                                    <?php
                                }
                                else
                                {
                                ?>
                                    <img src="<?php echo base_url();?>dist/img/edition/whiterightmark.svg"
                                        alt="rightmark svg" class="rightmark">
                                    <?php
                                }
                                ?>

                                    <!-- for republic day -->
                                    <!-- <img src="<?php echo base_url();?>dist/img/edition/rightmark_republic.svg"
                                    alt="rightmark svg" class="text-dark rightmark"> -->
                                    Frequencies
                                </li>

                                <li class="h6">
                                    <?php

                                if ($currentDateTime < $ExpiryDateTime)
                                {
                                ?>
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark_republic.svg"
                                        alt="rightmark svg" class="text-light rightmark">
                                    <?php
                                }
                                else
                                {
                                ?>
                                    <img src="<?php echo base_url();?>dist/img/edition/whiterightmark.svg"
                                        alt="rightmark svg" class="rightmark">
                                    <?php
                                }
                                ?>

                                    <!-- for republic day -->
                                    <!-- <img src="<?php echo base_url();?>dist/img/edition/rightmark_republic.svg"
                                    alt="rightmark svg" class="text-dark rightmark"> -->
                                    Common Numbers
                                </li>

                                <li class="h6">
                                    <?php

                                if ($currentDateTime < $ExpiryDateTime)
                                {
                                ?>
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark_republic.svg"
                                        alt="rightmark svg" class="text-light rightmark">
                                    <?php
                                }
                                else
                                {
                                ?>
                                    <img src="<?php echo base_url();?>dist/img/edition/whiterightmark.svg"
                                        alt="rightmark svg" class="rightmark">
                                    <?php
                                }
                                ?>

                                    <!-- for republic day -->
                                    <!-- <img src="<?php echo base_url();?>dist/img/edition/rightmark_republic.svg"
                                    alt="rightmark svg" class="text-dark rightmark"> -->
                                    Print Ready Reports
                                </li>

                            </ul>

                            <?php
                                if ($currentDateTime < $ExpiryDateTime)
                                {
                                
                                ?>
                            <a href="<?php echo base_url(); ?>promotions"
                                class="btn btn-outline-warning d-block px-3 py-3 mt-4">View
                                Offers</a>
                            <?php
                                }
                                else
                                {
                            ?>
                            <a href="<?php echo base_url(); ?>promotions"
                                class="btn btn-outline-info d-block px-3 py-3 mt-4">View
                                Offers</a>
                            <?php
                                }
                               ?>



                            <!-- <a href="<?php echo base_url(); ?>UserInfo?edition=LITE"
                            class="btn btn-light d-block px-3 py-3 mt-4">Buy Now</a> -->
                            <!-- <a href="<?php echo base_url(); ?>UserInfoc/lite_user_info" class="btn btn-light d-block px-3 py-3 ">Buy Now</a> -->
                        </div>
                    </div>
                </div>

                <div class="ftco-animate">
                    <div class="card Ccard third-card">
                        <div class="card-body">
                            <h2 class="card-title font-weight-bold"><span class="card-heading">Professional
                                    Edition</span><span>
                                    <img class=" float-right card-svg"
                                        src="<?php echo base_url(); ?>dist/img/ficons/professional.svg" alt="Home-png">
                                </span>
                            </h2>
                            <p class=" card-text h5 mt-5 text-left">The optimum choice of IOS to let Application work as
                                a client-server in local network or stand-alone as well. </p>
                            <hr class="hr bg-dark">
                            <ul class="list-unstyled">
                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Data Accessibility
                                </li>

                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Server Configuration
                                </li>

                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Multiple Analysis
                                </li>

                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    ODBC Option
                                </li>

                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Data Repository
                                </li>

                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Features of Lite Edition
                                </li>

                            </ul>
                            <a href="<?php echo base_url(); ?>ContactUs"
                                class="btn btn-primary d-block px-3 py-3 mt-4">Contact Us</a>
                        </div>
                    </div>
                </div>

                <div class="ftco-animate">
                    <div class="card Ccard fourth-card">
                        <div class="card-body">
                            <h2 class="card-title font-weight-bold"><span class="card-heading">Enterprise
                                    Edition</span><span>
                                    <img class="float-right card-svg"
                                        src="<?php echo base_url(); ?>dist/img/ficons/enterprise.svg" alt="Home-png">
                                </span>
                            </h2>
                            <p class="card-text  h5 mt-5 text-left">The most powerful option for mid and big-size
                                organizations looking to get as much data as possible.</p>
                            <hr class="hr bg-dark">
                            <ul class="list-unstyled">
                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    <strong>Centralized </strong> Solution
                                </li>

                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    <strong>Big Data </strong> Handling
                                </li>

                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Case & Management
                                </li>

                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    User Management
                                </li>

                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Data Repository
                                </li>

                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Features of Professional
                                </li>

                            </ul>
                            <a href="<?php echo base_url(); ?>ContactUs"
                                class="btn btn-primary d-block px-3 py-3 mt-4">Contact Us</a>
                        </div>
                    </div>
                </div>

                <div class="ftco-animate">
                    <div class="card Ccard fifth-card">
                        <div class="card-body">
                            <h2 class="card-title font-weight-bold"><span class="card-heading">Enterprise
                                    PLUS</span><span>
                                    <img class="float-right card-svg"
                                        src="<?php echo base_url(); ?>dist/img/ficons/enterpriseplus.svg"
                                        alt="Home-png">
                                </span>
                            </h2>

                            <p class="card-text h5 mt-5 text-left">
                                This edition is a bespoke data analytical solution. Designed, developed and tailored to
                                fit
                                your organizations specific needs
                            </p>
                            <br>
                            <hr class="bg-dark hr">
                            <ul class="list-unstyled">

                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Redesigned back-end structure
                                </li>

                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    On-site deployment
                                </li>

                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Configured data handler
                                </li>
                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Features of Enterprise
                                </li>

                            </ul>
                            <a href="<?php echo base_url(); ?>ContactUs"
                                class="btn btn-primary d-block px-3 py-3 mt-4">Contact Us</a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
</section>

<section class="ftco-section ftco-counter img" id="section-counter" style="background-color:#0A3FFF;">
    <div class="container">
        <div class="row justify-content-center mb-2 pb-2">
            <div class="col-xs-7 col-sm-7 col-md-7 col-lg-7 text-center heading-section ftco-animate ">
                <h4 class="text-white">C5 CDR Analyzer</h4>
                <h2 class="text-white">Android Application</h2>
            </div>
        </div>

        <div class="row align-items-center">
            <div class="col-md-3">
                <div class="row justify-content-center">
                    <div class="text-center heading-section ftco-animate ">

                        <h4 class="text-white">To continue CDR Analysis on the move, download the App now</h4>
                        <!-- <h4 class="text-white">For the officers on the move</h4> -->
                        <a href="https://play.google.com/store/apps/details?id=com.prosoft.CDR_Analyzer"
                            target="_blank"><img style="width: 80%" class="hov"
                                src="<?php echo base_url(); ?>dist/img/google-play-badge.svg">
                        </a>

                        <a><img class="one-third js-fullscreen align-item-center order-md-last img-fluid"
                                style="width: 30%" src="<?php echo base_url(); ?>dist/img/qr.png" alt="QRCode"></a>

                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="owl-carousel mobile_images" data-nav-arrow="true" data-items="3" data-md-items="3"
                    data-sm-items="2" data-xs-items="2">
                    <div class="item">
                        <img class="img-fluid full-width"
                            src="<?php echo base_url(); ?>dist/img/analyzer/screenshots/IMEI_Dashboard.png"
                            alt="IMEI_Dashboard">
                    </div>
                    <div class="item">
                        <img class="img-fluid full-width"
                            src="<?php echo base_url(); ?>dist/img/analyzer/screenshots/DV.png" alt="DV">
                    </div>
                    <div class="item">
                        <img class="img-fluid full-width"
                            src="<?php echo base_url(); ?>dist/img/analyzer/screenshots/NewHomeScreen.png"
                            alt="NewHomeScreen">
                    </div>
                    <div class="item">
                        <img class="img-fluid full-width"
                            src="<?php echo base_url(); ?>dist/img/analyzer/screenshots/Sync_screenshot.png"
                            alt="Sync_screenshot">
                    </div>
                    <div class="item">
                        <img class="img-fluid full-width"
                            src="<?php echo base_url(); ?>dist/img/analyzer/screenshots/GeoAnalysis_screenshot.png"
                            alt="GeoAnalysis">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="ftco-section testimony-section flaticon-section">
    <div class="container Con">

        <div class="row justify-content-center mb-5 pb-3">
            <div class="col-md-7 text-center heading-section ftco-animate">
                <h2 class="mb-0">Why Choose Us</h2>
                <p class="h5">Providing you with powerful analytical tools, is what we do best.</p>
            </div>
        </div>

        <div class="row flaticon-row">
            <div class="col-md-6 d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services d-flex align-items-center">
                    <div class="icon d-flex align-items-center justify-content-center order-md-last">
                        <span class="flaticon-cpu"></span>
                    </div>
                    <div class="media-body pl-4 pl-md-0 pr-md-4 text-md-right">
                        <h3 class="heading">Big Data</h3>
                        <p>
                            We all live in BIG DATA age where the capability of organization to handle big data plays a
                            key role in determining the success and growth of the organizations. Our expertise in
                            handling
                            big data will give your organization a distinct advantage in making smarter decisions.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services d-flex align-items-center">
                    <div class="icon d-flex align-items-center justify-content-center">
                        <span class="flaticon-star-1"></span>
                    </div>
                    <div class="media-body pl-4">
                        <h3 class="heading">Delivering High Class Innovative Solutions</h3>
                        <p class="mb-0">With our relentless efforts we are committed to add that extra value so as to
                            exceed our client’s expectation.</p>
                    </div>
                </div>
            </div>


            <div class="col-md-6 d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services d-flex align-items-center">
                    <div class="icon d-flex align-items-center justify-content-center order-md-last">
                        <span class="flaticon-insurance"></span>
                    </div>
                    <div class="media-body pl-4 pl-md-0 pr-md-4 text-md-right">
                        <h3 class="heading">Baked-in Security</h3>
                        <p>
                            Our all-inclusive approach to application security provides the foundation of our
                            development model. Bearing in mind different possible threat to your information and data,
                            we employ security in our products and solutions to ensure that your business is covered
                            from all angles.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services d-flex align-items-center">
                    <div class="icon d-flex align-items-center justify-content-center">
                        <span class="flaticon-speedometer"></span>
                    </div>
                    <div class="media-body pl-4">
                        <h3 class="heading">Performance, Reliability and Scalability</h3>
                        <p>
                            Once it is deployed to production any application needs to fulfill the expected level of
                            performance. It needs to be reliable, and scale if needed. We make sure all these quality
                            attributes are carefully designed and implemented in order to make any application
                            delightful to use.
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-md-6 d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services d-flex align-items-center">
                    <div class="icon d-flex align-items-center justify-content-center order-md-last">
                        <span class="flaticon-loyalty"></span>
                    </div>
                    <div class="media-body pl-4 pl-md-0 pr-md-4 text-md-right">
                        <h3 class="heading">Values</h3>
                        <p>In pursuit of our purpose of delivering high class innovative products, we create an
                            environment of innovation and learning while continuously reaching for the highest level of
                            excellence.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services d-flex align-items-center">
                    <div class="icon d-flex align-items-center justify-content-center">
                        <span class="flaticon-headphones"></span>
                    </div>
                    <div class="media-body pl-4">
                        <h3 class="heading">Hands-on Support</h3>
                        <p>
                            Not only do we provide assistance with the product but also assist with the analytical
                            knowledge.
                            We provide the best in class customer support throughout the product life cycle.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="ftco-section ftco-counter img" id="section-counter" style="background-color:#0A3FFF;">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-7 text-center heading-section heading-section-white ftco-animate">
                <h2 class="mb-0">Headline Figures</h2>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="row">
                    <div class="col-md-3 d-flex justify-content-center counter-wrap ftco-animate">
                        <div class="block-18 text-center">
                            <div class="text">
                                <strong class="number" data-number="1000">0</strong><strong class="number"> +</strong>
                                <span>Installations</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 d-flex justify-content-center counter-wrap ftco-animate">
                        <div class="block-18 text-center">
                            <div class="text">
                                <strong class="number" data-number="12">0</strong><strong class="number"> +</strong>
                                <span>Years of Experience</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 d-flex justify-content-center counter-wrap ftco-animate">
                        <div class="block-18 text-center">
                            <div class="text">
                                <strong class="number" data-number="500">0</strong><strong class="number"> +</strong>
                                <span>Locations</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 d-flex justify-content-center counter-wrap ftco-animate">
                        <div class="block-18 text-center">
                            <div class="text">
                                <strong class="number" data-number="30">0</strong><strong class="number"> +</strong>
                                <span>Law Enforcement Agencies</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="customer-section ftco-section testimony-section">

    <div class="container">
        <div class="row justify-content-center mb-0">
            <div class="col-md-9 text-center heading-section ftco-animate">
                <h2 class="mb-1">Our satisfied customer says</h2>
            </div>
        </div>
    </div>

    <div class="container">
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
            </ol>

            <div class="container ">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <div class="carouselcard">
                            <div class="testimony-wrap p-4 text-center">
                                <div class="user-img mb-4 img-fluid"
                                    style="background-image: url(<?php echo base_url(); ?>dist/img/avatar5.png) ">
                                    <span class="quote d-flex align-items-center justify-content-center">
                                        <i class="icon-quote-left"></i>
                                    </span>
                                </div>

                                <div class="text text-justify h6">
                                    <p class="name text-center">B.Dayananda IPS</p>
                                    <p class="text-center">Deputy Inspector General of Police State
                                        Intelligence, Bangalore</p>
                                </div>

                                <div class="text text-justify h6">
                                    <p>The C5 – CDR Analyzer has been implemented as a statewide project in
                                        Karnataka wherein all the District Police units and Commissionerates
                                        have been given a copy of the software to do CDR analysis of their
                                        cases pertaining to crime, investigation, surveillance, enquiry… Etc.
                                        The software has been quite successful in solving several
                                        important/complicated cases. The field officers are finding it quite
                                        easy to use and get different types of analysis reports pertaining to
                                        their cases.
                                    <p>Based on the feed back of the officers, software is being further
                                        modified by the developers to fine-tune it to our present requirements.
                                    </p>
                                    <p>This continuous support being given by the company is the main key to
                                        their ‘SUCCESS’ and commitment.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="carouselcard  ">
                            <div class="testimony-wrap p-4 text-center">
                                <div class="user-img mb-4 img-fluid"
                                    style="background-image: url(<?php echo base_url(); ?>dist/img/avatar5.png) ">
                                    <span class="quote d-flex align-items-center justify-content-center">
                                        <i class="icon-quote-left"></i>
                                    </span>
                                </div>

                                <div class="text text-justify h6">
                                    <p class="name text-center">H.S. Revanna IPS</p>
                                    <p class="text-center">Deputy Commissioner of Police North Division,
                                        Bangalore City</p>
                                </div>

                                <div class="text text-justify h6">
                                    <p>With the help of C5 – CDR application it has become easy to generate
                                        various types of report depending on the requirement of investigation
                                        officer irrespective of intensity of cases. With the help application
                                        analysis may be done with no time, which saves lot of time for the IOs.
                                        Especially, the application places very vital role while analyzing
                                        tower data, finding common between many numbers of CDRs, provision of
                                        watch dog facility to monitor the IMEI numbers are really one of the
                                        best options provided. The newly introduced option provided to obtain
                                        SDR is very useful one. However, while analysis the tower data, some
                                        OBDC error appears and the entire application shutdowns.</p>
                                    <p>At present the CDRs obtain from service provider do not contain tower
                                        data;the same inturn is being changed with Vlookup option in MS-Excel.
                                        By incorporating the tower dis of all service providers in your
                                        application, if automated updation to chabge the cell id to name of the
                                        tower is provided, it would be another golden feather to C5 – CDR
                                        application.</p>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="carouselcard  ">
                            <div class="testimony-wrap p-4 text-center">
                                <div class="user-img mb-4 img-fluid"
                                    style="background-image: url(<?php echo base_url(); ?>dist/img/avatar5.png) ">
                                    <span class="quote d-flex align-items-center justify-content-center">
                                        <i class="icon-quote-left"></i>
                                    </span>
                                </div>

                                <div class="text text-justify h6">
                                    <p class="name text-center">Sharath.M.D</p>
                                    <p class="text-center">Cybercrime Police Station Bangalore</p>
                                </div>

                                <div class="text text-justify h6">
                                    <p>
                                        CDR analysis software provided by prosoft IT is really good and it is really
                                        evolving, there are really good features like geo analysis, common numbers,
                                        peacock chart, and playing with peacock chart according to our needs is the
                                        greatest advantage.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="carouselcard  ">
                            <div class="testimony-wrap p-4 text-center">
                                <div class="user-img mb-4 img-fluid"
                                    style="background-image: url(<?php echo base_url(); ?>dist/img/avatar5.png) ">
                                    <span class="quote d-flex align-items-center justify-content-center">
                                        <i class="icon-quote-left"></i>
                                    </span>
                                </div>

                                <div class="text text-justify h6">
                                    <p class="name text-center">Nilesh Kumar,Senior DySP</p>
                                    <p class="text-center">Cyber Crime Unit, Bihar</p>
                                </div>

                                <div class="text text-justify h6">
                                    <p>C5 – CDR application provided by Prosoft is fantastic. There are various
                                        good features like GEO Analysis, Common Numbers, Link analysis,
                                        Conference calls, Cluster analysis in different mode. I have solved
                                        many complicated crime incident with this software. In my view LEA can
                                        improve their efficiency by using this software. Huge tower dump data
                                        can be analysed with this tool easily. I personally using this software
                                        for last six months only and solved many blind cases with dump data
                                        with great ease.</p>
                                    <p>What I like most is the response of technical team. They are always
                                        ready to solve any type of problem promptly, whenever I made contact
                                        with them, the technical team provided me customized solutions in
                                        various occasion. The Prosoft team will certainly go far ahead to
                                        achieve their goal.</p>
                                    <p>I wish Prosoft team for successful feature and hoping for continuance of
                                        their zeal and enthusiasm with they are working in this field.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon m-0" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next " href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
</section>

<section class="ftco-section bg-lightgrey">
    <div class="container">
        <div class="row  align-items-center d-flex ">
            <div class="col-md-6 ml-5">
                <div class="heading-section heading-section-white ftco-animate">
                    <span class="h1 text-dark font-weight-bold">Ready to get started?</span>
                    <h3 class="text-dark">With C5 CDR Analyzer get more insightful reports</h3>
                    <a href="<?php echo base_url(); ?>UserInfo?edition=TRIAL"
                        class="btn btn-primary px-3 py-3 mt-5 button">Start Free Trial</a>
                </div>
            </div>

            <div class="col-md-4">
                <div class="section-title">
                    <a><img class="one-third js-fullscreen align-item-center order-md-last img-fluid"
                            src="<?php echo base_url(); ?>dist/img/trialUserInfo.svg" alt="Home-svg"></a>
                </div>
            </div>
        </div>
    </div>
</section>


<script>
$(document).ready(function() {


    // console.log(moment(new Date("08/31/2021")).isAfter(new Date("08/31/2021")));

    // //  for offer only [pop up image ]
    // if (moment(new Date()).isAfter(new Date("08/31/2021")) == false) {

    //     // add mega offer image
    //     $('.imagepopup-section').css('display', 'block');
    //     $('body').css('overflow', 'hidden');


    // } else {
    //     $('body').css('overflow', 'auto');

    // }


    // close pop-up
    $('.close_img').on('click', function() {
        $('.imagepopup-section').css('display', 'none');
        $('body').css('overflow', 'auto');
        console.log("popup image closed");
    });

});
</script>