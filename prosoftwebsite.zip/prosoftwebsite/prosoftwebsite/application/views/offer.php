
    <section class="ftco-section bg-light">
        <div class="container">
            <div class="row">
				<div class="col-md-12">

                        <a href="<?php echo base_url(); ?>UserInfo?edition=LITE">
                            <img style="cursor: pointer;" class="float-right card-svg" src="<?php echo base_url(); ?>dist/img/offer/offer2.svg" alt="Home-png">
                        </a>

                </div>    
            </div>
        </div>
    </section>