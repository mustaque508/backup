<!DOCTYPE html>
<html lang="en">




<head>
    <!-- GTM -->
    <script>
    (function(w, d, s, l, i) {
        w[l] = w[l] || [];
        w[l].push({
            'gtm.start': new Date().getTime(),
            event: 'gtm.js'
        });
        var f = d.getElementsByTagName(s)[0],
            j = d.createElement(s),
            dl = l != 'dataLayer' ? '&l=' + l : '';
        j.async = true;
        j.src =
            'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
        f.parentNode.insertBefore(j, f);
    })(window, document, 'script', 'dataLayer', 'GTM-NG6GMFK');
    </script>
    <!-- End GTM -->

    <title>Prosoft e-Solutions India Pvt Ltd</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords"
        content="CDR analysis software, CDR analysis, Tower dump analysis software, IPDR analysis software, CDR analysis software free download, CDR and IPDR, CDR and TDR, CDR and SDR, CDR full form, CDR bsnl, CDR airtel, CDR Vodaphone, CDR jio, CDR cyber security, CDR data analysis, CDR data, Tower data, Tower dump analysis, Tower dump software" />
    <meta name="keywords"
        content="Cell tower dump analysis software, Cell tower dump data, Phone tower dump, IPDR analysis, IPDR full form, IPDR CDR, IPDR CDR analysis, IPDR data, Police software, Police software download, Police analytics software " />
    <meta name="keywords"
        content="Police software case management, Police cdr software, Police evidence software, Police forensic software, Next gen police software, Investigation of criminal cases, Investigation software , Investigation officer, CDR investigation, Investigation reports, IMEI , IMEI CDR" />
    <meta name="keywords"
        content="IMEI analysis, C5 CDR Analyzer, C5CDR, C5 software, C5 CDR App, C5 report, C5 TDR, C5 SDR, C5 IPDR, Data Repository, Open database connectivity, Data Visualization, Data Visualizer, Peacock Chart, Multilingual interface, Powerful smart search engine, Suspect List" />
    <meta name="keywords"
        content="Strong security features, User friendly, Designed for big data, Call Details Records, Internet Protocol Details Records, ILD , International Long Distance, Advance Analytics, Crime Mapping, Dashboard, Quick Reports , Quick Analysis, Location, Common Numbers" />
    <meta name="keywords"
        content="Call Frequency, Recee , Group Formation, Suspicious Behavior, Burner mobiles, Roamer calls, Target number, International Cartel, Suspected Individuals , Hidden Network, CDR Analysis Mobile App, CDR Android App, CDR Mobile App, CDR iOS App, C5 CDR Android App" />
    <meta name="keywords"
        content="C5 CDR Mobile App, CDR Mobile Tracker, Enterprise Edition, Professional edition, LITE Edition, Free Trial, COVID-19 Edition , Financial Analysis, Predictive insight , Financial officers, Detect fraud , Banking Fraud , Banking Security, Fraud Cell, Tax evasion" />
    <meta name="keywords"
        content="Illegal activity , Public corruption, Financial fraud, Dashboard , Flow of Funds, Money Trail, Money Rotation, Foreign inward outward report, Breakup report, Financial report, C5 Financial Analytics, Financial Data Analytics, Financial Data Analyzer" />
    <meta name="keywords"
        content="Banking data analytics, Cell ID Data Analyzer, BTS Data Analyzer, Geospacial Analysis, Geo Fencing, SDR Data Analysis, Subscriber Detail Record, Data Mining Tools, LEA Tools, Police Intelligence Software, State Intelligence Software, CID Software" />
    <meta name="keywords"
        content="Popular CDR Software, Popular CDR Analysis Application, Crime Database, CDR Tracking, Crime Mapping, Movement Analysis, Suspect Movement Analysis, Number Tracing, IMSI Data,  Crime Data Analysis, Suspect CDR, Day Call Analysis, Night Call Analysis" />
    <meta name="keywords"
        content="Frequent Locations, Match Numbers, ODBC, Suspect Database Search,  Android Phone Location Analysis, Link Analysis" />
    <meta name="description"
        content="Prosoft e-Solutions India Pvt. Ltd. is a research-based software development company committed to delivering world class software and enterprise solutions." />
    <meta name="author" content="" />

    <link href="https://fonts.googleapis.com/css?family=Assistant" rel="stylesheet">


    <link rel="stylesheet" href="<?php echo base_url(); ?>dist/css/normalize.css">

    <link rel="shortcut icon" href="<?php echo base_url(); ?>dist/img/favicon-black.png">

    <link rel="stylesheet" href="<?php echo base_url(); ?>dist/css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>dist/css/animate.css">



    <link rel="stylesheet" href="<?php echo base_url(); ?>dist/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>dist/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>dist/css/magnific-popup.css">

    <link rel="stylesheet" href="<?php echo base_url(); ?>dist/css/aos.css">

    <link rel="stylesheet" href="<?php echo base_url(); ?>dist/css/ionicons.min.css">

    <link rel="stylesheet" href="<?php echo base_url(); ?>dist/css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>dist/css/jquery.timepicker.css">

    <link rel="stylesheet" href="<?php echo base_url(); ?>dist/css/flaticons/flaticon.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>dist/css/Flaticon.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>dist/css/icomoon.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>dist/css/style.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>dist/css/productsc5cdr.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>dist/css/main_plancard.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>dist/css/comp_logo.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>dist/css/main_customer_cards.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>dist/css/head_resnavbarbutton.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>dist/css/main_freetrialbanner.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>dist/css/footer.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>dist/css/c5cdrkeyfeature.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>dist/css/Cards_ProductHistory.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>dist/css/FAQInfo.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>dist/css/companyleaders.css">

    <link rel="stylesheet" href="<?php echo base_url(); ?>dist/css/thank_you.css">

    <link rel="stylesheet" href="<?php echo base_url(); ?>dist/css/subscriptionplan.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>dist/css/order_review.css">

    <link rel="stylesheet" href="<?php echo base_url(); ?>dist/css/hero_img.css">

    <!-- font-awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">



    <script src="<?php echo base_url(); ?>dist/js/jquery.min.js"></script>
    <script src="<?php echo base_url(); ?>dist/js/owl.carousel.js"></script>
    <!--<script src="<?php echo base_url(); ?>dist/js/timeline.min.js"></script>-->
    <script src="<?php echo base_url(); ?>dist/js/Card_ProductHistory.js"></script>

    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
</head>

<script type="text/javascript">
var Tawk_API = Tawk_API || {},
    Tawk_LoadStart = new Date();
(function() {
    var s1 = document.createElement("script"),
        s0 = document.getElementsByTagName("script")[0];
    s1.async = true;
    s1.src = 'https://embed.tawk.to/5cfdfd15267b2e57853197fc/default';
    s1.charset = 'UTF-8';
    s1.setAttribute('crossorigin', '*');
    s0.parentNode.insertBefore(s1, s0);
})();
</script>

<script>
new WOW().init();
</script>


<body>

    <!-- get current date and expiry date -->
    <?php
        // time_zone
        date_default_timezone_set('Asia/Kolkata');

        $currentDateTime =date('Y-m-d');
        $ExpiryDateTime=date('2021-09-16');
    ?>


    <!-- GTM (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NG6GMFK" height="0" width="0"
            style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End GTM (noscript) -->

    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
        <div class="container">
            <a class="navbar-brand" href="<?php echo base_url(); ?>Home"><img
                    src="<?php echo base_url(); ?>dist/img/Prosoft_Logo.png" alt="Prosoft e-Solutions"
                    class="img-fluid img"></a>
            <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#ftco-nav"
                aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="icon-bar top-bar"></span>
                <span class="icon-bar middle-bar"></span>
                <span class="icon-bar bottom-bar"></span>
            </button>

            <div class="collapse navbar-collapse" id="ftco-nav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active"><a href="<?php echo base_url(); ?>Home" class="nav-link">Home</a></li>
                    <li class="nav-item"><a href="<?php echo base_url(); ?>AboutUs" class="nav-link">Company</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="navbarDropdown" role="button" data-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">
                            Products
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo base_url(); ?>products/cdr-analysis-software">C5
                                CDR Analyzer</a>
                            <a class="dropdown-item" href="<?php echo base_url(); ?>products/financial-analytics">C5
                                Financial Analytics</a>
                            <a class="dropdown-item" href="<?php echo base_url(); ?>products/health-soft">HealthSoft</a>
                            <a class="dropdown-item"
                                href="<?php echo base_url(); ?>products/enterprise-resource-planning">Enterprise
                                Resource Planning</a>
                            <a class="dropdown-item"
                                href="<?php echo base_url(); ?>products/fleet-management-system">Fleet Management</a>
                        </div>
                    </li>
                    <li class="nav-item"><a href="<?php echo base_url(); ?>ContactUs" class="nav-link">Contact Us</a>
                    </li>
                    <li class="nav-item"><a href="<?php echo base_url(); ?>PartnerRegistration" class="nav-link">Become
                            a Partner</a></li>
                    <li class="nav-item cta"><a href="<?php echo base_url(); ?>UserInfo?edition=TRIAL"
                            class="nav-link"><span>Start Free Trial</span></a></li>

                    <?php

                        if ($currentDateTime < $ExpiryDateTime)
                        {
                        ?>

                    <!-- on offer day -->
                    <li class="nav-item offer_color ml-2"><a href="<?php echo base_url(); ?>promotions"
                            class="nav-link"><span>Buy C5 Lite</span></a></li>
                    <?php
                        }
                        else
                        {
                        ?>
                    <li class="nav-item basic_color ml-2"><a href="<?php echo base_url(); ?>promotions"
                            class="nav-link"><span>Buy C5 Lite</span></a></li>
                    <?php
                        }
                        ?>


                </ul>
            </div>
        </div>
    </nav>