	<!-- <div class="hero-wrap js-fullheight">
		<div class="container-fluid px-0">
			<div class="row d-md-flex no-gutters slider-text align-items-center js-fullheight justify-content-end">
				<div class="one-forth d-flex align-self-end ftco-animate js-fullheight mt-5">
					<div class="text mt-5">
						<p class="breadcrumbs mb-0"><span><a href="<?php echo base_url();?>index.php/Home">Home<i
										class="ion-ios-arrow-forward"></i></a></span>Become a Partner</p>
						<h1 class="mb-3">Become a Partner</span></h1>
						<p class="h4">It would be great to hear from you! If you got anything related to our Company /
							Product / Services.</p>
					</div>
				</div>
				<img class="one-third js-fullheight align-self-end order-md-last img-fluid"
					src="<?php echo base_url(); ?>dist/img/contactUs.svg" alt="contactUs-svg">

			</div>
		</div>
	</div> -->

	<section class="ftco-section contact-section ftco-degree-bg">
		<div class="container">
			<div class="row">

				<div class="col-md-6 align-self-stretch">
					<div class="heading-section heading-section-black ftco-animate">
						<h1 class="text-dark font-weight-bold">
							<h2 class='text-dark' style='font-size: 30px;'>Become a Partner</h2>
						</h1>
					</div>

					<div class="heading-section heading-section-black ftco-animate">
						<!-- <h3 class='text-dark'>Light on the pocket, Lite years ahead in analytics.</h3> -->
						<h4>Turn an opportunity into a fresh revenue stream. </h4>
							<h5>We believe that our partnership is about creating a valuable relationship, 
							fill up the form and find out what differentiates us from the rest.
						</h5>
					</div>

					<div class="heading-section heading-section-black ftco-animate">
						<a><img class="one-third js-fullscreen align-item-center order-md-last img-fluid"
								src="<?php echo base_url(); ?>dist/img/partnerHero.svg" alt="Partner-svg"></a>
					</div>
				</div>

				<div class="col-md-6 pr-md-5">
                
					<form action="<?php echo base_url(); ?>PartnerRegistration/save" method="post">
						<h2 style="font-size: 30px; color: red;"><?php echo $error;?></h2>
						<div class="form-group">
							<input type="text" class="form-control" placeholder="Your Name*" name="p_name" id="p_name"
								value="<?php echo $this->session->userdata('p_name');?>" required>
							<span style="color: red; font-size:small;"><?php echo $p_name_error;?></span>
						</div>
						<div class="form-group">
							<input type="text" class="form-control" placeholder="Your Contact No.*" name="p_contact_no"
								id="contact_no" value="<?php echo $this->session->userdata('p_contact_no');?>" required>
							<span style="color: red; font-size:small;"><?php echo $p_contact_error;?></span>
						</div>
						<div class="form-group">
							<input type="text" class="form-control" placeholder="Your Email*" name="p_email" id="p_email"
								value="<?php echo $this->session->userdata('p_email');?>" required>
							<span style="color: red; font-size:small;"><?php echo $p_email_error;?></span>
						</div>
						<div class="form-group">
							<input type="text" class="form-control" placeholder="Company*" name="company" id="company"
								value="<?php echo $this->session->userdata('company');?>" required>
							<span style="color: red; font-size:small;"><?php echo $p_company_error;?></span>
						</div>
						<div class="form-group">
							<input type="text" class="form-control" placeholder="Address" name="address" id="address" 
								value="<?php echo $this->session->userdata('address');?>">
						</div>
						<div class="form-group">
							<input type="text" class="form-control" placeholder="Country" name="country" id="country" 
								value="<?php echo $this->session->userdata('country');?>">
						</div>
						<div class="form-group">
							<input type="text" class="form-control" placeholder="Company Website" name="website"
								value="<?php echo $this->session->userdata('website');?>" id="website" >
						</div>
						<div class="form-group">
							<textarea name="message" id="message" cols="30" rows="7" class="form-control"
								placeholder="Message*" required><?php echo $this->session->userdata('message');?></textarea>
							<span style="color: red; font-size:small;"><?php echo $p_message_error;?></span>
						</div>

						<div class="form-group">
							<div class="g-recaptcha" data-sitekey="6Ldtzb4UAAAAAGnBmlLGQjPansZXAGZu4Bd1j8-I"></div>
						</div>

						<div class="form-group">
							<input type="submit" value="Send Message" class="btn btn-primary py-3 px-5">
						</div>
					</form>
				</div>
			</div>
		</div>
	</section>
	<script>
		//var mEmail = "<?php echo $this->session->userdata('message'); ?>";
		//alert(mEmail);
	</script>