<div class="hero-wrap js-fullheight">
    <div class="container-fluid px-0">
        <div class="row d-md-flex no-gutters slider-text align-items-center js-fullheight justify-content-end">

            <div class="one-forth d-flex align-self-end ftco-animate js-fullheight mt-5">
                <div class="text mt-5">
                        <p class="breadcrumbs mb-0"><span><a href="<?php echo base_url();?>index.php/Home"> Home <i
                                        class="ion-ios-arrow-forward"></i></a></span> Products <i
                                class="ion-ios-arrow-forward"></i></a></span> FMS </p>
                        <h1 class="mb-3">Fleet Management System</span></h1>
                        <p class="h3">Control the chaos</p>
                </div>
            </div>
            <img class="one-third js-fullheight align-self-end order-md-last img-fluid"
                src="<?php echo base_url(); ?>dist/img/products/fleetHeroBanner.svg" alt="fleetHeroBanner-svg">

        </div>
    </div>
</div>

<!-- <div class="hero-wrap js-fullheight">
    <div class="overlay"></div>
    <div class="container-fluid px-0">
        <div class="row d-md-flex no-gutters slider-text align-items-center js-fullheight justify-content-end">
            <img class="one-third js-fullheight align-self-end order-md-last img-fluid"
                src="<?php echo base_url(); ?>dist/img/products/fleetHeroBanner.svg" alt="fleetHeroBanner-png" />
            <div class="one-forth d-flex align-items-center ftco-animate js-fullheight">
                <div class="text mt-5">
                    <p class="breadcrumbs mb-0"><span><a href="<?php echo base_url();?>index.php/Home">Home<i
                                    class="ion-ios-arrow-forward"></i></a></span>Products<i
                            class="ion-ios-arrow-forward"></i></a></span>FMS</p>
                    <h1 class="mb-3">Fleet Management System</span></h1>
                    <p class="h3">Control the chaos</p>
                </div>
            </div>
        </div>
    </div>
</div> -->


<section class="ftco-section ftco-no-pt ftc-no-pb flaticon-section">
    <div class="container">
        <div class="row justify-content-center mb-2 pb-3">
            <div class="col-md-7 text-center heading-section ftco-animate">
                <h2 class="mb-4">Fleet Management System</h2>
                <!-- <p class="h5">Information Superhighway For Healthcare</p> -->
            </div>
        </div>

        <div class="row">
            <div class="col-md-4 text-center ftco-animate">
                <img class="img-fluid" style="width:180px;height:180px;"
                    src="<?php echo base_url(); ?>dist/img/products/fleetHeroBanner.svg" alt="Big Data.svg" />
            </div>
            <div class="col-md-8 text-justify ftco-animate">
                <p class="h5">
                    The detachment between different stakeholders such as fleet managers, owners, drivers, admins and
                    other operations personnel can mean unexpected downtime and profit loss. e-MTS gives you the tools
                    and data you need to manage vehicles and equipment from acquisition to disposal.
                </p>

            </div>
        </div>
    </div>
</section>

<section class="ftco-section testimony-section flaticon-section bg-lighter">
    <div class="container Con">

        <!-- <div class="row justify-content-center mb-5 pb-3">
	            <div class="col-md-7 text-center heading-section ftco-animate">
	                <h2 class="mb-0">title</h2>
	                <p class="h5">desc</p>
	            </div>
	        </div> -->

        <div class="row flaticon-row">
            <div class="col-md-6 d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services d-flex align-items-center">
                    <div class="icon d-flex align-items-center justify-content-center order-md-last">
                        <span class="flaticon-test"></span>
                    </div>
                    <div class="media-body pl-4 pl-md-0 pr-md-4 text-md-right">
                        <p class="mb-0">
                            e-MTS stands ahead in data security and reliability. It is designed and programmed to adopt
                            with
                            changing times in working environment and ensure smooth and efficient operation. e-MTS is
                            user friendly,
                            expandable and practical.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services d-flex align-items-center">
                    <div class="icon d-flex align-items-center justify-content-center">
                        <span class="flaticon-support"></span>
                    </div>
                    <div class="media-body pl-4">
                        <p class="mb-0">
                            e-MTS ensures Lean time is maintained in operations while also providing a vigilant platform
                            to track
                            any unpleasant activities. It also will be beneficial to record, analyse & put to use the
                            best practices
                            of a standardised process of performing activities. This will lead to cost savings, in turn
                            increase
                            profitability for your organization.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="bg-lightgrey">
    <div class="container">
        <div class="row  d-flex align-items-center justify-content-center ">
            <div class="col-md-6 mb-4 mt-4  ftco-animate ">
                <h4 >We would love to demonstrate our product</h4>
			</div>
            <div class="col-md-3 mb-4 mt-4 ftco-animate">
            
                <a href="<?php echo base_url(); ?>ContactUs" class="btn px-4 py-3 text-light button-color btn-primary ">Contact Us</a>


            </div>

        </div>
    </div>
</section>

<section class=" bg-light mt-5">
    <div class="container">
        <div class="row justify-content-center mb-5 pb-3">
            <div class="col-md-7 text-center heading-section ftco-animate">
                <h2 class="mb-0">Our Clientele </h2>
                <p class="h5 mb-0"></p>
            </div>
        </div>
        <div class="row justify-content-center mb-10 pb-3">
            <div class="col-md-6 d-flex align-self-stretch ftco-animate">
                <div id="clients" class="owl-carousel clients owl-theme">
                    <div class="item" style="width:180px;height:180px;">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/SI_bangalore.png"
                                class="img-fluid" alt="SI_bangalore.png"></a>
                    </div>
                    <div class="item" style="width:180px;height:180px;">
                        <a href="#" class="partner"><img src="<?php echo base_url(); ?>dist/img/clients/SP_belgaum.png"
                                class="img-fluid" alt="SP_belgaum"></a>
                    </div>
                    <div class="item" style="width:180px;height:180px;">
                        <a href="#" class="partner"><img src="<?php echo base_url(); ?>dist/img/clients/SP_dharwad.png"
                                class="img-fluid" alt="SP_dharwad"></a>
                    </div>
                    <div class="item" style="width:180px;height:180px;">
                        <a href="#" class="partner"><img src="<?php echo base_url(); ?>dist/img/clients/SP_mangalore.png"
                                class="img-fluid" alt="SP_mangalore"></a>
                    </div>
                </div>

			  
                <script>
				$(document).ready(function() {
				  var owlClients = $('.clients');				  
				  owlClients.owlCarousel({
					items: 2,
					loop: true,
					margin: 10,
					autoplay: true,
					autoplayTimeout: 1000,
					autoplayHoverPause: true
				  });
				  /*$('.play').on('click', function() {
					owl.trigger('play.owl.autoplay', [1000])
				  })
				  $('.stop').on('click', function() {
					owl.trigger('stop.owl.autoplay')
				  })*/
				  
				  var owlMobileImages = $('.mobile_images');				  
				  owlMobileImages.owlCarousel({
					items: 2,
					loop: true,
					margin: 10,
					autoplay: true,
					autoplayTimeout: 1000,
					autoplayHoverPause: true
				  });
				  
				  var owlCustomers = $('.customers');				  
				  owlCustomers.owlCarousel({
					items: 2,
					loop: true,
					margin: 50,
					autoplay: true,
					autoplayTimeout: 3000,
					autoplayHoverPause: true
				  });
				  
				})
			  </script>		  

            </div>
        </div>
    </div>
</section>

