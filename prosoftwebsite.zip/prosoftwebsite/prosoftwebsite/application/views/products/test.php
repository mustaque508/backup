<div class="hero-wrap js-fullheight">

  <div class="container-fluid px-0">

      <div class="row d-md-flex no-gutters slider-text align-items-center js-fullheight justify-content-end">

          <div class="one-forth d-flex align-self-end ftco-animate js-fullheight mt-5">
              <div class="text mt-5">
                  <h1><span>Complex Analytics, Simplified!</span></h1>
                  <h1 class="mb-3 subheading">C5 CDR ANALYZER</h1>
                  <p class="h6">Your search for a robust, high performing, affordable, CDR data analysis solution
                      ends here.</p>
                  <p><a href="<?php echo base_url();?>products/c5cdr"
                          class="btn px-4 py-3 text-light button-color btn-primary">Know More</a></p>
              </div>
          </div>
          <img class="one-third js-fullheight align-self-end order-md-last img-fluid"
              src="<?php echo base_url(); ?>dist/img/homeHero.svg" alt="Home-svg">

      </div>
  </div>
</div>

<section class="bg-dark">
  <div class="container">
    <h2>Carousel Example</h2>  
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
      <!-- Indicators -->
      <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
      </ol>

      <!-- Wrapper for slides -->
      <div class="carousel-inner">
        <div class="item active">
            <div class="user-img mb-4 img-fluid"
              style="background-image: url(<?php echo base_url(); ?>dist/img/avatar5.png) ">

              <span class="quote d-flex align-items-center justify-content-center">
                  <i class="icon-quote-left"></i>
              </span>
            </div>

            <div class="text text-justify h6">
                <p class="name text-center">B.Dayananda IPS</p>
                <p class="text-center">Deputy Inspector General of Police State
                    Intelligence, Bangalore</p>
            </div>

            <div class="text text-justify h6">
                <p>The C5 – CDR Analyzer has been implemented as a statewide project in
                    Karnataka wherein all the District Police units and Commissionerates
                    have been given a copy of the software to do CDR analysis of their
                    cases pertaining to crime, investigation, surveillance, enquiry… Etc.
                    The software has been quite successful in solving several
                    important/complicated cases. The field officers are finding it quite
                    easy to use and get different types of analysis reports pertaining to
                    their cases.
                <p>Based on the feed back of the officers, software is being further
                    modified by the developers to fine-tune it to our present requirements.
                </p>
                <p>This continuous support being given by the company is the main key to
                    their ‘SUCCESS’ and commitment.</p>
            </div>
        </div>

        <div class="item">
              <div class="user-img mb-4 img-fluid"
                style="background-image: url(<?php echo base_url(); ?>dist/img/avatar5.png) ">

                <span class="quote d-flex align-items-center justify-content-center">
                    <i class="icon-quote-left"></i>
                </span>
              </div>

              <div class="text text-justify h6">
                  <p class="name text-center">Some one</p>
                  <p class="text-center">cxvbcxv vbcvbcvb</p>
              </div>

              <div class="text text-justify h6">
                  <p>Based on the feed back of the officers, software is being further
                      modified by the developers to fine-tune it to our present requirements.
                  </p>
                  <p>This continuous support being given by the company is the main key to
                      their ‘SUCCESS’ and commitment.</p>
              </div>
        </div>
      
        <div class="item">

        <div class="user-img mb-4 img-fluid"
                style="background-image: url(<?php echo base_url(); ?>dist/img/avatar5.png) ">

                <span class="quote d-flex align-items-center justify-content-center">
                    <i class="icon-quote-left"></i>
                </span>
              </div>

              <div class="text text-justify h6">
                  <p class="name text-center">tyjh ghkhjkhj </p>
                  <p class="text-center">fgj jfghkiyui ,nm,nm</p>
              </div>

              <div class="text text-justify h6">
                  <p>This continuous support being given by the company is the main key to
                      their ‘SUCCESS’ and commitment.</p>
              </div>
        
        </div>
      </div>

      <!-- Left and right controls -->
      <a class="left carousel-control" href="#myCarousel" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="right carousel-control" href="#myCarousel" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>
  </div>
</section>