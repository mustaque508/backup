<div class="hero-wrap js-fullheight">
    <div class="container-fluid px-0">
        <div class="row d-md-flex no-gutters slider-text align-items-center js-fullheight justify-content-end">

            <div class="one-forth d-flex align-self-end ftco-animate js-fullheight mt-5">
                <div class="text mt-5">
                    <p class="breadcrumbs mb-0"><span><a href="<?php echo base_url();?>index.php/Home"> Home <i
                                    class="ion-ios-arrow-forward"></i></a></span> Products <i
                            class="ion-ios-arrow-forward"></i></a></span> ERP </p>
                    <h1 class="mb-3">Prosoft Business Software</span></h1>
                    <p class="h3">Growth made simple</p>
                </div>
            </div>
            <img class="one-third js-fullheight align-self-end order-md-last img-fluid"
                src="<?php echo base_url(); ?>dist/img/products/erpHeroBanner.svg" alt="erpHeroBanner-svg">

        </div>
    </div>
</div>


<!-- <div class="hero-wrap js-fullheight">
    <div class="overlay"></div>
    <div class="container-fluid px-0">
        <div class="row d-md-flex no-gutters slider-text align-items-center js-fullheight justify-content-end">
            <img class="one-third js-fullheight align-self-end order-md-last img-fluid"
                src="<?php echo base_url(); ?>dist/img/products/erpHeroBanner.svg" alt="erpHeroBanner.svg" />
            <div class="one-forth d-flex align-items-center ftco-animate js-fullheight">
                <div class="text mt-5">
                    <p class="breadcrumbs mb-0"><span><a href="<?php echo base_url();?>index.php/Home">Home<i
                                    class="ion-ios-arrow-forward"></i></a></span>Products<i
                            class="ion-ios-arrow-forward"></i></a></span>ERP</p>
                    <h1 class="mb-3">Prosoft Business Software</span></h1>
                    <p class="h3">Growth made simple</p>
                </div>
            </div>
        </div>
    </div>
</div> -->

<section class="ftco-section ftco-no-pt ftc-no-pb">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-7 text-center heading-section ftco-animate">
                <h2>Enterprise Resource Planning</h2>
                <!-- <p class="h5">
                    Support Your Company's Business Goals
                </p> -->
            </div>
        </div>

        <div class="row">
            <div class="col-md-8 justify-content-center">
                <div class="row mt-3">
                    <div class="ftco-animate">

                        <div class="block-erp text-justify h5 ">
                            <ul class="list-unstyled">
                                <li><span class="icon"><img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                            alt="rightmark svg"></span>
                                    <span class="text text-dark">
                                        <p>
                                            Solutions that support your company’s business goals and practices are not
                                            out of your reach! We at Prosoft have the solutions and support offerings
                                            that open up possibilities you previously thought would be impossible with
                                            your company’s budget or timeframe.
                                        </p>
                                    </span>
                                </li>
                                <ul class="list-unstyled">
                                    <li><span class="icon"><img
                                                src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                                alt="rightmark svg"></span>
                                        <span class="text text-dark">
                                            <p>
                                                The Prosoft Business Software provides a widely diversified range for
                                                manufacturing companies, commerce industry and the service industry.
                                            </P>
                                        </span>
                                    </li>
                                    <ul class="list-unstyled">
                                        <li><span class="icon"><img
                                                    src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                                    alt="rightmark svg"></span>
                                            <span class="text text-dark">
                                                <p>
                                                    As one of the leading providers of software solutions in system and
                                                    application software. We continue to set new standards for quality,
                                                    performance and reliability. Prosoft provides solutions for a work
                                                    group to be more productive. Our custom-tailored products are
                                                    flexible in every way to fit in your budget and your environment.
                                                </p>
                                            </span>
                                        </li>
                                        <!-- <ul class="list-unstyled">
                                            <li><span class="icon"><img
                                                        src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                                        alt="rightmark svg"></span>
                                                <span class="text text-dark">
                                                    <p>
                                                        As one of the leading provider of software solutions in system
                                                        and Application software. Prosoft
                                                        continues to set new standards for quality, performance and
                                                        reliability. Prosoft provides solutions
                                                        for a work group to be more productive. Our custom tailored
                                                        products are flexible in every way to fit
                                                        in your budget and your environment.
                                                    </P>

                                                </span>
                                            </li>

                                        </ul> -->
                        </div>


                    </div>
                </div>
            </div>


            <div class="col-md-4 text-center ftco-animate">
                <img class="img-fluid" style="width:180px;height:180px;"
                    src="<?php echo base_url(); ?>dist/img/products/erpHeroBanner.svg" alt="erpHeroBanner.svg" />
            </div>

        </div>

    </div>
</section>

<section class="bg-lightgrey">
    <div class="container">
        <div class="row  d-flex align-items-center justify-content-center ">
            <div class="col-md-6 mb-4 mt-4   ftco-animate">
                <h4 >We would love to demonstrate our product</h4>
			</div>
            <div class="col-md-3 mb-4 mt-4 ftco-animate">
            
                <a href="<?php echo base_url(); ?>ContactUs" class="btn px-4 py-3 text-light button-color btn-primary ">Contact Us</a>


            </div>

        </div>
    </div>
</section>

<section class=" bg-light mt-5">
    <div class="container">
        <div class="row justify-content-center mb-5 pb-3">
            <div class="col-md-7 text-center heading-section ftco-animate">
                <h2 class="mb-0">Our Clientele </h2>
                <p class="h5 mb-0"></p>
            </div>
        </div>
        <div class="row justify-content-center mb-10 pb-3">
            <div class="col-md-6 d-flex align-self-stretch ftco-animate">
                <div id="clients" class="owl-carousel clients owl-theme">
                    <div class="item" style="width:180px;height:180px;">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/netalkar1.png"
                                class="img-fluid" alt="netalkar"></a>
                    </div>
                    <div class="item" style="width:180px;height:180px;">
                        <a href="#" class="partner"><img src="<?php echo base_url(); ?>dist/img/clients/netalkar2.png"
                                class="img-fluid" alt="netalkar2"></a>
                    </div>
                </div>

                <script>
                $(document).ready(function() {
                    var owlClients = $('.clients');
                    owlClients.owlCarousel({
                        items: 2,
                        loop: false,
                        margin: 10,
                        autoplay: true,
                        autoplayTimeout: 1000,
                        autoplayHoverPause: true
                    });


                })
                </script>
            </div>
        </div>
    </div>
</section>

