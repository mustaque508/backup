<div class="hero-wrap js-fullheight">
    <div class="container-fluid px-0">
        <div class="row d-md-flex no-gutters slider-text align-items-center js-fullheight justify-content-end">

            <div class="one-forth d-flex align-self-end ftco-animate js-fullheight mt-5">
                <div class="text mt-5">
                    <p class="breadcrumbs mb-0"><span><a href="<?php echo base_url();?>index.php/Home"> Home 
                                <i class="ion-ios-arrow-forward"></i></a></span> Products 
                                <i class="ion-ios-arrow-forward"></i></a></span> C5FA 
                    </p>
                    <h1><span>C5 Financial Data Analytics</span></h1>
                    <p class="h6">The Future of Financial Analytics</p>
                    <p><a href="<?php echo base_url();?>dist/profile/C5_Financial_Analytics_Brochure.pdf"
                            target="_blank" class="btn px-4 py-3 text-light button-color btn-primary">Download
                            Brochure</a></p>
                </div>
            </div>
            <img class="one-third js-fullheight align-self-end order-md-last img-fluid"
                src="<?php echo base_url(); ?>dist/img/products/faHeroBanner.svg" alt="faHeroBanner-svg">

        </div>
    </div>
</div>

<section class="ftco-section ftco-no-pt ftc-no-pb">
    <div class="container">
        <div class="row justify-content-center mb-2 pb-3">
            <div class="col-md-7 text-center heading-section ftco-animate">
                <h2 class="mb-4">Financial Data Analysis</h2>
            </div>
        </div>

        <div class="row">
            <!-- <div class="col-md-4 text-center ftco-animate">
                <img class="img-fluid" style="width:180px;height:180px;"
                    src="<?php echo base_url(); ?>dist/img/products/Big Data.svg" alt="Big Data.svg" />
            </div> -->
            <div class="col-md-12 text-justify ftco-animate">
                <p class="h5">
                    Financial analysis is the process of evaluating businesses, projects, budgets and
                    individuals to determine their performance and suitability. Typically, financial
                    analysis is used to analyze whether an entity is stable, solvent, liquid or profitable
                    enough to warrant a monetary investment. When looking at a specific company or a Person
                    of Interest, a financial officer conducts analysis by focusing on the income statement,
                    balance sheet, and cash flow statement.
                </p>
                <!-- </div>
        </div> -->

                <!-- <div class="row">
            <div class="col-md-12 text-justify heading-section ftco-animate"> -->
                <p class="h5">
                    In today’s highly competitive business environment, financial officers need more from Finance
                    than accurate financial statements and reports. They need forward-looking, predictive insights
                    that can help detect fraudulent activity and improve decision-making in real time.
                </p>
            </div>
        </div>
        <div class="row ftco-animate justify-content-end">
            <div class="col-md-3">
                <a href="<?php echo base_url(); ?>ContactUs"
                    class="btn px-4 py-3 text-light button-color btn-primary">Contact us to know more</a>
            </div>
        </div>
    </div>
</section>

<section class="ftco-section bg-lighter">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-7 text-center heading-section ftco-animate">
                <h2>Necessity of Financial Analysis</h2>
                <p class="h5">
                    A financial investigation is analysis of where money comes from, how it moves and how it is used.
                </p>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-8 py-5">
                <div class="heading-section ftco-animate">
                    <div class="block-fa bg-accent text-justify  pl-2 pr-2 pt-2 pb-2">
                        <div class="media-bodyfa bg-accent">
                            <p class="h6 text-light">
                                In most cases, financial analysis revolves around collection and analysis
                                of financial data. The collection aspect involves searching through a variety of
                                financial documents.
                            </p>
                            <!-- </div>
                    </div>

                    <div class="block-fa border text-left" style="background-color:white;">
                        <div class="media-bodyfa"> -->

                            <p class="h6 text-light mt-3">
                                Bank fraud is the use of potentially illegal means to obtain capital, assets, or other
                                property owned or held by a financial institution, or to obtain money from depositors by
                                fraudulently posing as a bank. In many cases, bank fraud is a criminal offence. RBI has
                                elaborate set of early warning signals (EWS) for banks to curtail frauds. However, there
                                are inadequate tools and technology in place to detect such EWS pertaining to different
                                frauds.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 py-5 justify-content-center">
                <div class="row ">
                    <p class="h6">
                        Financial Investigations or Financial Analytics can reveal:
                    </p>
                </div>

                <div class="row">
                    <div class="ftco-animate">
                        <div class="mt-3 ml-3">
                            <ul class="list-unstyled">
                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Financial fraud
                                </li>
                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Banking fraud
                                </li>
                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Tax evasion
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="ftco-animate">
                        <div class="mt-3 ml-3">
                            <ul class="list-unstyled">
                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Public corruption
                                </li>

                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Terrorist financing
                                </li>

                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Illegal activity
                                </li>
                            </ul>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </div>
</section>

<section class="ftco-section flaticon-section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-7 text-center heading-section ftco-animate">
                <h2 class="mb-0">Purpose of Financial Statements</h2>
                <p class="h5">
                    Financial statements are formal records of the financial activities and positions of a business,
                    person, or other entity.
                    Relevant financial information is presented in a structured manner and in a form, which is easy to
                    understand.
                </p>
                <!-- <br> -->
                <p class="h6">
                    They typically include these basic financial statements :
                </p>
            </div>
        </div>

        <div class="row flaticon-row">
            <div class="col-md-4 text-center ftco-animate">
                <div class="steps">
                    <div class="icon mb-4 d-flex justify-content-center align-items-center">
                        <h1 style="color:white;">1</h1>
                        <!-- <span class="flaticon-qr-code"></span> -->
                    </div>
                    <!-- <h3>Choose Your Plan</h3> -->
                    <p>
                        A Balance Sheet or a statement of financial position, reports on an individual’s assets,
                        liabilities and owner’s equity at a given point in time.
                    </p>
                </div>
            </div>
            <div class="col-md-4 text-center ftco-animate">
                <div class="steps">
                    <div class="icon mb-4 d-flex justify-content-center align-items-center">
                        <!-- <span class="flaticon-qr-code"></span> -->
                        <h1 style="color:white;">2</h1>
                    </div>
                    <!-- <h3>Create Your Account</h3> -->
                    <p>
                        An Income Statement reports on an individual’s income, expenses and profits over a stated
                        period of time. This provides information on the operation of an enterprise.
                    </p>
                </div>
            </div>
            <div class="col-md-4 text-center ftco-animate">
                <div class="steps">
                    <div class="icon mb-4 d-flex justify-content-center align-items-center">
                        <h1 style="color:white;">3</h1>
                        <!-- <span class="flaticon-qr-code"></span> -->
                    </div>
                    <!-- <h3>Launch</h3> -->
                    <p>
                        A Cash Flow Statement reports on a company’s or individual’s cash flow activated. Particularly
                        its operating, investing and financing activities over a stated period of time.
                    </p>
                </div>
            </div>
        </div>

        <div class="row justify-content-center mb-2 pb-3">
            <div class="col-md-12 text-justify heading-section ftco-animate">
                <!-- <h2 class="mb-0">Purpose of Financial Statements</h2> -->
                <!-- <br/> -->
                <p class="h5">
                    Financial statements are intended to be understandable by readers who have a reasonable knowledge of
                    business, economics activities, accounting and who are willing to study the information diligently.
                </p>
            </div>
        </div>

    </div>
</section>

<section class="ftco-section bg-lightgrey">
    <div class="container">
        <div class="row justify-content-center mb-2 pb-3">
            <div class="col-md-7 text-center heading-section ftco-animate">
                <h2 class="mb-4">Introduction to C5 Financial Analytics</h2>
            </div>
        </div>

        <div class="row">
            <div class="col-md-8 text-justify ftco-animate">
                <p class="h5">
                    C5 Financial Analytics is a customized tool to gather actionable intelligence from a variety
                    of financial data, collected from various banks. The application helps financial
                    Investigating Officers identify suspicious transactions based on user defined criteria.
                </p>
            </div>
            <div class="col-md-4 text-center ftco-animate">
                <img class="img-fluid" style="width:180px;height:180px;"
                    src="<?php echo base_url(); ?>dist/img/products/faIntro.svg" alt="Big Data.svg" />
            </div>
        </div>

        <div class="row justify-content-center ftco-animate bg-accent">
            <div class="block-fa bg-accent text-left">
                <div class="col-md-12 text-justify heading-section ftco-animate bg-accent text-light">
                    <h5 class="mb-4 text-light">How does C5 FA work?</h5>
                    <p class="h6">
                        It begins with data acquisition in the form of financial statements, bank statements in all the
                        accepted file formats. The application then creates an analysis report based on the imported
                        data.
                        From the analysis dashboard, the financial Investigating Officer is presented with visually
                        sound
                        data that is helpful in quickly determining the gravity of the case. The analysis can also
                        display
                        variety of analysis patterns and commands, categorizing, filtering and summarizing the data.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="ftco-section ">
    <div class="container">
        <div class="row justify-content-center mb-5 pb-3 ">
            <div class="col-md-7 text-center ftco-animate">
                <h2 class="mb-4  heading-section">Key Features</h2>
            </div>
        </div>

        <div class="row mb-5 justify-content-center">
            <div class="col-md-4 text-center ftco-animate mb-4">
                <div class="steps-kf">
                    <div class="icon-kf mb-4 d-flex justify-content-center align-items-center">
                        <span>
                            <img class="icon-kf-extended js-fullheight align-self-end img-fluid"
                                src="<?php echo base_url(); ?>dist/img/products/fof.svg" alt="fof">
                        </span>
                    </div>

                    <h3 class="heading">Flow of Fund</h3>
                    <p class="mb-0 text-justify">
                        Leave it to this tool to provide you with a comprehensive picture of all the funds in
                        any given case. C5 Financial Analytics intelligently tracks and tags the flow of funds
                        from and to a number of accounts that are involved in money rotations or it can connect
                        the dots with money trails to show where and how the funds end up. The flow is tracked
                        and intelligently plotted in a visual representation, making sense of vast and composite
                        fund routes a breeze for the Investigating Officer.
                    </p>

                </div>
            </div>
            <div class="col-md-4 text-center ftco-animate mb-4">
                <div class="steps-kf">
                    <div class="icon-kf mb-4 d-flex justify-content-center align-items-center"> 
                        <span>
                            <img class="icon-kf-extended js-fullheight align-self-end img-fluid"
                                src="<?php echo base_url(); ?>dist/img/products/foreignInOut.svg"
                                alt="foreignInOut">
                        </span>
                    </div>
                    
                    <h3 class="heading">Foreign Inward/Outward Report</h3>
                    <p class="mb-0 text-justify">
                        Following the funds internationally has never been easier, with this feature can trace
                        the forex transactions.
                    </p>
                </div>
            </div>
            <div class="col-md-4 text-center ftco-animate mb-4">
                <div class="steps-kf">
                    <div class="icon-kf mb-4 d-flex justify-content-center align-items-center">
                        <span>
                            <img class="icon-kf-extended js-fullheight align-self-end img-fluid"
                                src="<?php echo base_url(); ?>dist/img/products/moneyTrail.svg"
                                alt="moneyTrail">
                        </span>
                    </div>
                    
                        <h3 class="heading">Money Trail and Money Rotation</h3>
                        <p class="mb-0">
                            Get a better understanding of where and how the same money is being circulated among
                            different individuals involved.
                        </p>
                </div>
            </div>
            <div class="col-md-4 text-center ftco-animate mb-4">
                <div class="steps-kf">
                    <div class="icon-kf mb-4 d-flex justify-content-center align-items-center">
                        <span>
                            <img class="icon-kf-extended js-fullheight align-self-end img-fluid"
                            src="<?php echo base_url(); ?>dist/img/products/narration.svg"
                                alt="narration">
                        </span>
                    </div>
                        <h3 class="heading">Narration/Description</h3>
                        <p class="mb-0 text-justify">
                            Let the application do the heavy lifting for you, with this unique feature the
                            application intelligently
                            extracts information from the narration/description to identify various parameters like
                            mode, beneficiary,
                            reference number of the transaction etc., Identifies the transaction whether it falls
                            under FEMA/PMLA
                        </p>
                </div>
            </div>
            <div class="col-md-4 text-center ftco-animate mb-4">
                <div class="steps-kf">
                    <div class="icon-kf mb-4 d-flex justify-content-center align-items-center">
                        <span>
                            <img class="icon-kf-extended js-fullheight align-self-end img-fluid"
                            src="<?php echo base_url(); ?>dist/img/products/dashboard.svg" alt="dashboard">
                        </span>
                    </div>
                        <h3 class="heading">Dashboard</h3>
                        <p class="mb-0 text-justify">
                            C5 Financial Analytics makes it easy for the Investigating Officer to view all the
                            complex data in a simple and
                            intuitive manner, with vibrant data charts and relevant parameters being highlighted.
                        </p>
                </div>
            </div>
            <div class="col-md-4 text-center ftco-animate mb-4">
                <div class="steps-kf">
                    <div class="icon-kf mb-4 d-flex justify-content-center align-items-center">
                        <span>
                            <img class="icon-kf-extended js-fullheight align-self-end img-fluid"
                                    src="<?php echo base_url(); ?>dist/img/products/breakupReports.svg" alt="breakupReports">
                            </span>
                        </div>

                        <h3 class="heading">Breakup Report</h3>
                        <p class="mb-0 text-justify">
                            Easy to use Pivot report, summarizes data by dragging the columns to different sections
                            of the table.
                        </p>
                </div>
            </div>
            <div class="col-md-4 text-center ftco-animate mb-4">
                <div class="steps-kf">
                    <div class="icon-kf mb-4 d-flex justify-content-center align-items-center">
                        <span>
                            <img class="icon-kf-extended js-fullheight align-self-end img-fluid"
                                src="<?php echo base_url(); ?>dist/img/products/dv.svg" alt="dv">
                        </span>
                    </div>

                        <h3 class="heading">Data Visualization</h3>
                        <p class="mb-0 text-justify">
                            Enables user to visually inspect the data using various types of graphics
                            such as Forced Chart, Circular char, Timeline, Hierarchical chart etc.
                        </p>
                </div>
            </div>
            <div class="col-md-4 text-center ftco-animate mb-4">
                <div class="steps-kf">
                    <div class="icon-kf mb-4 d-flex justify-content-center align-items-center">
                        <span>
                            <img class="icon-kf-extended js-fullheight align-self-end img-fluid"
                                src="<?php echo base_url(); ?>dist/img/products/reports.svg"
                                alt="">
                        </span>
                    </div>
                    
                    <h3 class="heading">Reports</h3>
                    <p class="mb-0 text-justify">
                        Generates various reports with the parameters that matter most to you, giving you the
                        flexibility
                        and ease to ready the most relevant data and investigate the relations.
                    </p>
                </div>
            </div>


        </div>
    </div>
</section>