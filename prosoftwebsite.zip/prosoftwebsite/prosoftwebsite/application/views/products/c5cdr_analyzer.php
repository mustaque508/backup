<!-- get current date and expiry date -->
<?php
        // time_zone
        date_default_timezone_set('Asia/Kolkata');

        $currentDateTime =date('Y-m-d');
        $ExpiryDateTime=date('2021-09-16');
    ?>


<div class="hero-wrap js-fullheight">
    <div class="container-fluid px-0">
        <div class="row d-md-flex no-gutters slider-text align-items-center js-fullheight justify-content-end">

            <div class="one-forth d-flex align-self-end ftco-animate js-fullheight mt-5">
                <div class="text mt-5">
                    <p class="breadcrumbs mb-0"><span><a href="<?php echo base_url();?>index.php/Home"> Home <i
                                    class="ion-ios-arrow-forward"></i></a></span> Products <i
                            class="ion-ios-arrow-forward"></i></a></span> C5 CDR Analyzer </p>
                    <h1 class="mb-3">C5 CDR ANALYZER</span></h1>
                    <p class="h3">Provides integrated results with advanced visual analytical interface.</p>
                    <p><a href="<?php echo base_url();?>dist/profile/C5_CDR_Analyzer_Brochure.pdf" target="_blank"
                            class="btn px-4 py-3 text-light button-color btn-primary">Download Brochure</a></p>
                </div>
            </div>
            <img class="one-third js-fullheight align-self-end order-md-last img-fluid"
                src="<?php echo base_url(); ?>dist/img/ProductsC5CDR.svg" alt="faHeroBanner-svg">

        </div>
    </div>
</div>

<section class="ftco-section ">
    <div class="container">
        <div class="row justify-content-center mb-5 pb-3 ">
            <div class="col-md-7 text-center ftco-animate">
                <h2 class="mb-4  heading-section">Key Features</h2>
            </div>
        </div>

        <div class="row mb-5 justify-content-center">
            <div class="col-md-4 text-center ftco-animate mb-4">
                <div class="steps-kf">
                    <div class="icon-kf mb-4 d-flex justify-content-center align-items-center">
                        <span>
                            <img class="icon-kf-extended js-fullheight align-self-end img-fluid"
                                src="<?php echo base_url(); ?>dist/img/products/Big Data.svg" alt="">
                        </span>
                    </div>

                    <h3 class="heading"> Designed for Big Data</h3>
                    <p class="mb-0 text-justify">
                        We know about the volumes of data that needs to be analysed to get actionable intelligence.
                        We’ve made quick processing of millions of records a reality. Along with the intuitive
                        Dashboard,
                        mining of valuable information and generating Intel reports is a breeze.
                    </p>
                </div>
            </div>
            <div class="col-md-4 text-center ftco-animate mb-4">
                <div class="steps-kf">
                    <div class="icon-kf mb-4 d-flex justify-content-center align-items-center">
                        <span>
                            <img class="icon-kf-extended js-fullheight align-self-end img-fluid"
                                src="<?php echo base_url(); ?>dist/img/products/dv.svg" alt="">
                        </span>
                    </div>

                    <h3 class="heading">CDR (Call Details Records) / Tower Dump Data</h3>
                    <p class="mb-0 text-justify">
                        The key data, which once processed through our application shells out valuable information like
                        locations,
                        associates, common numbers, recee, pursuit of victim, group formations, suspicious behaviour,
                        use of burner mobiles,
                        roamer calls and much more intelligence.
                    </p>
                </div>
            </div>
            <div class="col-md-4 text-center ftco-animate mb-4">
                <div class="steps-kf">
                    <div class="icon-kf mb-4 d-flex justify-content-center align-items-center">
                        <span>
                            <img class="icon-kf-extended js-fullheight align-self-end img-fluid"
                                src="<?php echo base_url(); ?>dist/img/products/IPDR-ILD.svg" alt="">
                        </span>
                    </div>

                    <h3 class="heading">IPDR (Internet Protocol Details Record)</h3>
                    <p class="mb-0 text-justify">
                        With VOIP and VOLTE becoming the norm, you can ascertain the internet connectivity and draw
                        inferences to assist
                        in the investigation. The application’s IPDR analysis also provides information such as which
                        websites and social
                        media is used by the person of interest.
                    </p>
                </div>
            </div>
            <div class="col-md-4 text-center ftco-animate mb-4">
                <div class="steps-kf">
                    <div class="icon-kf mb-4 d-flex justify-content-center align-items-center">
                        <span>
                            <img class="icon-kf-extended js-fullheight align-self-end img-fluid"
                                src="<?php echo base_url(); ?>dist/img/products/ILD.svg" alt="">
                        </span>
                    </div>
                    <h3 class="heading">ILD (International Long Distance)</h3>
                    <p class="mb-0 text-justify">
                        Going International with your investigation, we’ve got you covered. The ILD analysis yields
                        result where international cartel
                        is suspected during the investigation. Trace internationally connected individuals and their
                        hidden network groups.
                    </p>
                </div>
            </div>
            <div class="col-md-4 text-center ftco-animate mb-4">
                <div class="steps-kf">
                    <div class="icon-kf mb-4 d-flex justify-content-center align-items-center">
                        <span>
                            <img class="icon-kf-extended js-fullheight align-self-end img-fluid"
                                src="<?php echo base_url(); ?>dist/img/products/Sync.svg" alt="">
                        </span>
                    </div>
                    <h3 class="heading">Data Synchronize</h3>
                    <p class="mb-0 text-justify">
                        Welcome to the future of connected mobility and data synchronization. Managing intelligence
                        reports or case
                        data on different devices can be tasking. With this feature you can securely transfer data
                        between the C5 CDR Analyzer
                        desktop application and the Android app or vice-versa.
                    </p>
                </div>
            </div>
            <div class="col-md-4 text-center ftco-animate mb-4">
                <div class="steps-kf">
                    <div class="icon-kf mb-4 d-flex justify-content-center align-items-center">
                        <span>
                            <img class="icon-kf-extended js-fullheight align-self-end img-fluid"
                                src="<?php echo base_url(); ?>dist/img/products/dv.svg" alt="dv">
                        </span>
                    </div>

                    <h3 class="heading">Data Visualization</h3>
                    <p class="mb-0 text-justify">
                        Enables user to visually inspect the data using various types of graphics
                        such as Forced Chart, Circular char, Timeline, Hierarchical chart etc.
                    </p>
                </div>
            </div>
            <div class="col-md-4 text-center ftco-animate mb-4">
                <div class="steps-kf">
                    <div class="icon-kf mb-4 d-flex justify-content-center align-items-center">
                        <span>
                            <img class="icon-kf-extended js-fullheight align-self-end img-fluid"
                                src="<?php echo base_url(); ?>dist/img/products/Cloud Data.svg" alt="Cloud Data">
                        </span>
                    </div>

                    <h3 class="heading">Cloud Data</h3>
                    <p class="mb-0 text-justify">
                        Always have updated data wherever you are, irrespective of your devices too. We’ve got Cell Ids
                        and other data up
                        in the clouds so you can seamlessly continue your investigation without worrying about data
                        availability.
                    </p>
                </div>
            </div>
            <div class="col-md-4 text-center ftco-animate mb-4">
                <div class="steps-kf">
                    <div class="icon-kf mb-4 d-flex justify-content-center align-items-center">
                        <span>
                            <img class="icon-kf-extended js-fullheight align-self-end img-fluid"
                                src="<?php echo base_url(); ?>dist/img/products/Data Repository.svg" alt="">
                        </span>
                    </div>

                    <h3 class="heading"> Data Repository</h3>
                    <p class="mb-0 text-justify">
                        Everything case related in one place. This feature enables you to store all the information of a
                        different cases and individuals
                        in once place, which will give you a greater insight during the investigation.
                    </p>
                </div>
            </div>
            <div class="col-md-4 text-center ftco-animate mb-4">
                <div class="steps-kf">
                    <div class="icon-kf mb-4 d-flex justify-content-center align-items-center">
                        <span>
                            <img class="icon-kf-extended js-fullheight align-self-end img-fluid"
                                src="<?php echo base_url(); ?>dist/img/products/ODBC.svg" alt="">
                        </span>
                    </div>

                    <h3 class="heading"> Open Database Connectivity</h3>
                    <p class="mb-0 text-justify">
                        Need more information about the case? You can now search multiple connected databases allowing
                        you to match or cross manipulate
                        data to different databases and files, enabling you to see an integrated view of the case.
                    </p>
                </div>
            </div>

        </div>
    </div>
</section>

<section class="plan-section ftco-section bg-light">
    <div class="container">
        <div class="row justify-content-center mb-2 pb-2">
            <div class="col-xs-7 col-sm-7 col-md-7 col-lg-7 text-center heading-section ftco-animate ">
                <h2 class="mb-0">Choose a Plan</h2>
                <p class="h5">We offer pricing plans that fit all investigation types and team sizes. Compare and find
                    the best plan for you.</p>
            </div>
        </div>
    </div>
    <div class="container plan-container">
        <div class="row">
            <div class="ftco-animate">
                <div class="card Ccard First-card">
                    <div class="card-body">
                        <h2 class="card-title font-weight-bold"><span class="card-heading">Free
                                Trial</span><span>
                                <!-- <img class="float-right card-svg" src="<?php echo base_url(); ?>dist/img/edition/001-trial.svg" alt="Home-png"> -->
                                <img class="float-right card-svg"
                                    src="<?php echo base_url(); ?>dist/img/ficons/trial.svg" alt="Home-png">
                            </span>
                        </h2>
                        <p class="card-text text-left h5 mt-5">The perfect way to test out your analytical needs and
                            later upgrade to what suites you best.</p>
                        <hr class="hr bg-dark">
                        <ul class="list-unstyled">
                            <li class="h6">
                                <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg" alt="rightmark svg">
                                <strong>30 days </strong> Licence
                            </li>

                            <li class="h6">
                                <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg" alt="rightmark svg">
                                <strong>All Features </strong> Unlocked
                            </li>

                            <li class="h6">
                                <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg" alt="rightmark svg">
                                <strong>No Payments </strong> Required
                            </li>

                            <li class="h6">
                                <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg" alt="rightmark svg">
                                Quick Installation
                            </li>

                            <li class="h6">
                                <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg" alt="rightmark svg">
                                Easy to Upgrade
                                <!-- to Premium -->
                            </li>

                            <li class="h6">
                                <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg" alt="rightmark svg">
                                Mobile App
                            </li>

                        </ul>
                        <a href="<?php echo base_url(); ?>UserInfo?edition=TRIAL"
                            class="btn btn-primary d-block px-3 py-3 mt-4"> Start Free Trial</a>
                    </div>
                </div>
            </div>

            <!-- <div class="ftco-animate">
                <div class="card Ccard second-card">
                    <div class="card-body">
                        <h2 class="card-title font-weight-bold text-light"><span class="card-heading">Lite
                                Edition</span>
                            <span>
                                <img class="float-right card-svg text-light" style="background-color:white;" src="<?php echo base_url(); ?>dist/img/edition/002-lite.svg" alt="Home-png">
                                <img class="float-right card-svg text-light" style="background-color:white;"
                                    src="<?php echo base_url(); ?>dist/img/ficons/lite.svg" alt="Home-png">
                            </span>
                        </h2>
                        <p class="card-text h5 text-light text-left  mt-5">A great plan for Investigation officers
                            looking to take their data analytics skills to the next level.</p>
                        <hr class="bg-light hr">
                        <ul class="list-unstyled text-light">
                            <li class="h6">
                                <img src="<?php echo base_url();?>dist/img/edition/whiterightmark.svg"
                                    alt="rightmark svg" class="text-light">
                                Prepetual Licence
                            </li>

                            <li class="h6">
                                <img src="<?php echo base_url();?>dist/img/edition/whiterightmark.svg"
                                    alt="rightmark svg">
                                Quick Analysis
                            </li>

                            <li class="h6">
                                <img src="<?php echo base_url();?>dist/img/edition/whiterightmark.svg"
                                    alt="rightmark svg">
                                Geo Analysis
                            </li>

                            <li class="h6">
                                <img src="<?php echo base_url();?>dist/img/edition/whiterightmark.svg"
                                    alt="rightmark svg">
                                Frequencies
                            </li>

                            <li class="h6">
                                <img src="<?php echo base_url();?>dist/img/edition/whiterightmark.svg"
                                    alt="rightmark svg">
                                Common Numbers
                            </li>

                            <li class="h6">
                                <img src="<?php echo base_url();?>dist/img/edition/whiterightmark.svg"
                                    alt="rightmark svg">
                                Print Ready Reports
                            </li>

                        </ul>
                        <a href="<?php echo base_url(); ?>UserInfo?edition=LITE"
                            class="btn btn-light d-block px-3 py-3 mt-4">Buy Now</a>
                    </div>
                </div>
            </div> -->

            <div class="ftco-animate">

                <?php

                if ($currentDateTime < $ExpiryDateTime)
                {
                ?>

                <div class="card Ccard iDay_card">
                    <?php
                }
                else
                {
                ?>


                    <div class="card Ccard offer-card-reg">

                        <?php
                }
                ?>

                        <div class="card-body">
                            <h2 class="card-title font-weight-bold text-dark"><span class="card-heading">Lite
                                    Edition</span>
                                <span>


                                    <!--change offer_svg based on date-->
                                    <?php

                    if ($currentDateTime < $ExpiryDateTime)
                    {
                ?>

                                    <img class="float-right card-svg " style="background-color:white;"
                                        src="<?php echo base_url(); ?>dist/img/ficons/lite_republic.svg"
                                        alt="Home_republic-png">
                                    <?php
                    }
                    else
                    {
                ?>


                                    <img class="float-right card-svg offer_svg" style="background-color:white;"
                                        src="<?php echo base_url(); ?>dist/img/ficons/lite.svg" alt="Home-png">

                                    <?php
                    }
                ?>
                                    <!-- <img class="float-right card-svg text-light" style="background-color:white;" src="<?php echo base_url(); ?>dist/img/edition/002-lite.svg" alt="Home-png"> -->


                                    <!-- for republic day -->
                                    <!-- <img class="float-right card-svg " style="background-color:white;"
                    src="<?php echo base_url(); ?>dist/img/ficons/lite_republic.svg" alt="Home_republic-png"> -->
                                </span>
                            </h2>
                            <p class="card-text h5 text-light text-left  mt-5">A great plan for Investigation officers
                                looking to take their data analytics skills to the next level.</p>
                            <?php

            if ($currentDateTime < $ExpiryDateTime)
            {
            ?>
                            <hr class="hr" style="background-color:#000080">
                            <?php
            }
            else
            {
            ?>
                            <hr class="hr" style="background-color:#ffffff">
                            <?php
            }
            ?>




                            <ul class="list-unstyled text-light">
                                <li class="h6">

                                    <?php

                if ($currentDateTime < $ExpiryDateTime)
                {
            ?>
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark_republic.svg"
                                        alt="rightmark svg" class="text-light rightmark">
                                    <?php
            }
            else
            {
            ?>
                                    <img src="<?php echo base_url();?>dist/img/edition/whiterightmark.svg"
                                        alt="rightmark svg" class="rightmark">
                                    <?php
            }
            ?>


                                    <!-- for republic day -->
                                    <!-- <img src="<?php echo base_url();?>dist/img/edition/rightmark_republic.svg"
                    alt="rightmark svg" class="text-light rightmark"> -->
                                    Prepetual Licence
                                </li>

                                <li class="h6">
                                    <?php

                    if ($currentDateTime < $ExpiryDateTime)
                    {
                    ?>
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark_republic.svg"
                                        alt="rightmark svg" class="text-light rightmark">
                                    <?php
                    }
                    else
                    {
                    ?>
                                    <img src="<?php echo base_url();?>dist/img/edition/whiterightmark.svg"
                                        alt="rightmark svg" class="rightmark">
                                    <?php
                    }
                    ?>


                                    <!-- for republic day -->
                                    <!-- <img src="<?php echo base_url();?>dist/img/edition/rightmark_republic.svg"
                    alt="rightmark svg" class="text-dark rightmark"> -->
                                    Quick Analysis
                                </li>

                                <li class="h6">
                                    <?php

                if ($currentDateTime < $ExpiryDateTime)
                {
                ?>
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark_republic.svg"
                                        alt="rightmark svg" class="text-light rightmark">
                                    <?php
                }
                else
                {
                ?>
                                    <img src="<?php echo base_url();?>dist/img/edition/whiterightmark.svg"
                                        alt="rightmark svg" class="rightmark">
                                    <?php
                }
            ?>

                                    <!-- for republic day -->
                                    <!-- <img src="<?php echo base_url();?>dist/img/edition/rightmark_republic.svg"
                    alt="rightmark svg" class="text-dark rightmark"> -->
                                    Geo Analysis
                                </li>

                                <li class="h6">
                                    <?php

                if ($currentDateTime < $ExpiryDateTime)
                {
                ?>
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark_republic.svg"
                                        alt="rightmark svg" class="text-light rightmark">
                                    <?php
                }
                else
                {
                ?>
                                    <img src="<?php echo base_url();?>dist/img/edition/whiterightmark.svg"
                                        alt="rightmark svg" class="rightmark">
                                    <?php
                }
                ?>

                                    <!-- for republic day -->
                                    <!-- <img src="<?php echo base_url();?>dist/img/edition/rightmark_republic.svg"
                    alt="rightmark svg" class="text-dark rightmark"> -->
                                    Frequencies
                                </li>

                                <li class="h6">
                                    <?php

                if ($currentDateTime < $ExpiryDateTime)
                {
                ?>
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark_republic.svg"
                                        alt="rightmark svg" class="text-light rightmark">
                                    <?php
                }
                else
                {
                ?>
                                    <img src="<?php echo base_url();?>dist/img/edition/whiterightmark.svg"
                                        alt="rightmark svg" class="rightmark">
                                    <?php
                }
                ?>

                                    <!-- for republic day -->
                                    <!-- <img src="<?php echo base_url();?>dist/img/edition/rightmark_republic.svg"
                    alt="rightmark svg" class="text-dark rightmark"> -->
                                    Common Numbers
                                </li>

                                <li class="h6">
                                    <?php

                if ($currentDateTime < $ExpiryDateTime)
                {
                ?>
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark_republic.svg"
                                        alt="rightmark svg" class="text-light rightmark">
                                    <?php
                }
                else
                {
                ?>
                                    <img src="<?php echo base_url();?>dist/img/edition/whiterightmark.svg"
                                        alt="rightmark svg" class="rightmark">
                                    <?php
                }
                ?>

                                    <!-- for republic day -->
                                    <!-- <img src="<?php echo base_url();?>dist/img/edition/rightmark_republic.svg"
                    alt="rightmark svg" class="text-dark rightmark"> -->
                                    Print Ready Reports
                                </li>

                            </ul>

                            <?php
                if ($currentDateTime < $ExpiryDateTime)
                {
                
                ?>
                            <a href="<?php echo base_url(); ?>promotions"
                                class="btn btn-outline-warning d-block px-3 py-3 mt-4">View
                                Offers</a>
                            <?php
                }
                else
                {
            ?>
                            <a href="<?php echo base_url(); ?>promotions"
                                class="btn btn-outline-info d-block px-3 py-3 mt-4">View
                                Offers</a>
                            <?php
                }
               ?>



                            <!-- <a href="<?php echo base_url(); ?>UserInfo?edition=LITE"
            class="btn btn-light d-block px-3 py-3 mt-4">Buy Now</a> -->
                            <!-- <a href="<?php echo base_url(); ?>UserInfoc/lite_user_info" class="btn btn-light d-block px-3 py-3 ">Buy Now</a> -->
                        </div>
                    </div>
                </div>
                <div class="ftco-animate">
                    <div class="card Ccard third-card">
                        <div class="card-body">
                            <h2 class="card-title font-weight-bold"><span class="card-heading">Professional
                                    Edition</span><span>
                                    <img class=" float-right card-svg"
                                        src="<?php echo base_url(); ?>dist/img/ficons/professional.svg" alt="Home-png">
                                </span>
                            </h2>
                            <p class=" card-text h5 mt-5 text-left">The optimum choice of IOS to let Application work as
                                a client-server in local network or stand-alone as well. </p>
                            <hr class="hr bg-dark">
                            <ul class="list-unstyled">
                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Data Accessibility
                                </li>

                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Server Configuration
                                </li>

                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Multiple Analysis
                                </li>

                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    ODBC Option
                                </li>

                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Data Repository
                                </li>

                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Features of Lite Edition
                                </li>

                            </ul>
                            <a href="<?php echo base_url(); ?>ContactUs"
                                class="btn btn-primary d-block px-3 py-3 mt-4">Contact Us</a>
                        </div>
                    </div>
                </div>

                <div class="ftco-animate">
                    <div class="card Ccard fourth-card">
                        <div class="card-body">
                            <h2 class="card-title font-weight-bold"><span class="card-heading">Enterprise
                                    Edition</span><span>
                                    <img class="float-right card-svg"
                                        src="<?php echo base_url(); ?>dist/img/ficons/enterprise.svg" alt="Home-png">
                                </span>
                            </h2>
                            <p class="card-text  h5 mt-5 text-left">The most powerful option for mid and big-size
                                organizations looking to get as much data as possible.</p>
                            <hr class="hr bg-dark">
                            <ul class="list-unstyled">
                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    <strong>Centralized </strong> Solution
                                </li>

                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    <strong>Big Data </strong> Handling
                                </li>

                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Case & Management
                                </li>

                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    User Management
                                </li>

                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Data Repository
                                </li>

                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Features of Professional
                                </li>

                            </ul>
                            <a href="<?php echo base_url(); ?>ContactUs"
                                class="btn btn-primary d-block px-3 py-3 mt-4">Contact Us</a>
                        </div>
                    </div>
                </div>

                <div class="ftco-animate">
                    <div class="card Ccard fifth-card">
                        <div class="card-body">
                            <h2 class="card-title font-weight-bold"><span class="card-heading">Enterprise
                                    PLUS</span><span>
                                    <img class="float-right card-svg"
                                        src="<?php echo base_url(); ?>dist/img/ficons/enterpriseplus.svg"
                                        alt="Home-png">
                                </span>
                            </h2>

                            <p class="card-text h5 mt-5 text-left">
                                This edition is a bespoke data analytical solution. Designed, developed and tailored to
                                fit
                                your organizations specific needs
                            </p>
                            <br>
                            <hr class="bg-dark hr">
                            <ul class="list-unstyled">

                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Redesigned back-end structure
                                </li>

                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    On-site deployment
                                </li>

                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Configured data handler
                                </li>
                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Features of Enterprise
                                </li>

                            </ul>
                            <a href="<?php echo base_url(); ?>ContactUs"
                                class="btn btn-primary d-block px-3 py-3 mt-4">Contact Us</a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <div class="container ftco-animate">
            <a class="h6" href="<?php echo base_url();?>dist/profile/c5cdrhwspec.pdf" target="_blank"">Click here to know system specifications</a><br/>
    </div>
</section>

<section class=" ftco-section testimony-section flaticon-section ">
    <div class=" container Con">

                <div class="row justify-content-center mb-5 pb-3">
                    <div class="col-md-7 text-center heading-section ftco-animate">
                        <h2 class="mb-0">Editions That Fulfil Your CDR Analysis Requirements</h2>
                    </div>
                </div>

                <div class="row flaticon-row">
                    <div class="col-md-6 d-flex align-self-stretch ftco-animate">
                        <div class="media block-6 services d-flex align-items-center">
                            <div class="icon d-flex align-items-center justify-content-center order-md-last">
                                <span class="flaticon-rocket-3"></span>
                            </div>
                            <div class="media-body pl-4 pl-md-0 pr-md-4 text-md-right">
                                <h3 class="heading"> Enterprise Edition - Plus</h3>
                                <p class="h5">Unlimited Big Data, Ultimate Solution</p>
                                <p class="mb-0">Data with no limits for Big data analysis with state of art data
                                    security
                                    measures.Enterprise edition of the C5 CDR analyzer consist of a server license and a
                                    complimentary copy of the client License. Server License would be installed on the
                                    server
                                    thereafter client license would be installed on a computer connected to the server
                                    through
                                    LAN network. This implementation would enable C5 client to connect to the server and
                                    access
                                    the data on the basis of assigned privileges. Thus maintaining data security would
                                    be
                                    easy
                                    and data is located centrally.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 d-flex align-self-stretch ftco-animate">
                        <div class="media block-6 services d-flex align-items-center">
                            <div class="icon d-flex align-items-center justify-content-center">
                                <span class="flaticon-rocket-3"></span>
                            </div>
                            <div class="media-body pl-4">
                                <h3 class="heading">Enterprise Edition</h3>
                                <p class="h5">Ultimate solution for Big Data Analysis</p>
                                <p class="mb-0">Ultimate solution for Big data analysis with state of art data security
                                    measures.Enterprise edition of the C5 CDR analyzer consist of a server license and a
                                    complimentary copy of the client License. Server License would be installed on the
                                    server
                                    thereafter client license would be installed on a computer connected to the server
                                    through
                                    LAN network. .This implementation would enable C5 client to connect to the server
                                    and
                                    access the data on the basis of assigned privileges. Thus maintaining data security
                                    would
                                    be easy and data is located centrally.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 d-flex align-self-stretch ftco-animate">
                        <div class="media block-6 services d-flex align-items-center">
                            <div class="icon d-flex align-items-center justify-content-center order-md-last">
                                <span class="flaticon-rocket-11"></span>
                            </div>
                            <div class="media-body pl-4 pl-md-0 pr-md-4 text-md-right">
                                <h3 class="heading">Professional Edition</h3>
                                <p>The C5 CDR Analyzer's Professional Edition is capable of working as a client to the
                                    server
                                    in local network as well as this edition also can be used as stand-alone; required
                                    data
                                    from the server can be transferred into this and can be carried anywhere needed for
                                    analysis.</p>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 d-flex align-self-stretch ftco-animate">
                        <div class="media block-6 services d-flex align-items-center">
                            <div class="icon d-flex align-items-center justify-content-center">
                                <span class="flaticon-rocket-launch-1"></span>
                            </div>
                            <div class="media-body pl-4">
                                <h3 class="heading">Lite Edition</h3>
                                <p>A Lite version of the acclaimed C5 CDR ANALYZER made by Prosoft e-Solutions India
                                    Pvt.
                                    Ltd.
                                    The desktop application that is convenient and simple to use, helps you find crucial
                                    information expeditiously. Ideal for day to day CDR analysis, it’s designed from the
                                    ground
                                    up with performance and accuracy being the focus of development. With an intuitive
                                    UI
                                    and
                                    user-friendly operations this application makes it a must have, for anyone with the
                                    need
                                    and know-how of CDR analytics.</p>

                            </div>
                        </div>
                    </div>
                </div>

        </div>
</section>

<section class="ftco-section ftco-counter img" id="section-counter" style="background-color:#0A3FFF;">
    <div class="container">
        <div class="row justify-content-center mb-2 pb-2">
            <div class="col-xs-7 col-sm-7 col-md-7 col-lg-7 text-center heading-section ftco-animate ">
                <h4 class="text-white">C5 CDR Analyzer</h4>
                <h2 class="text-white">Android Application</h2>
            </div>
        </div>

        <div class="row align-items-center">
            <div class="col-md-3">
                <div class="row justify-content-center">
                    <div class="text-center heading-section ftco-animate ">
                        <h4 class="text-white">For the officers on the move</h4>
                        <a href="https://play.google.com/store/apps/details?id=com.prosoft.CDR_Analyzer"
                            target="_blank"><img style="width: 80%" class="hov"
                                src="<?php echo base_url(); ?>dist/img/google-play-badge.svg">
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="owl-carousel mobile_images" data-nav-arrow="true" data-items="3" data-md-items="3"
                    data-sm-items="2" data-xs-items="2">
                    <div class="item">
                        <img class="img-fluid full-width"
                            src="<?php echo base_url(); ?>dist/img/analyzer/screenshots/IMEI_Dashboard.png"
                            alt="IMEI_Dashboard">
                    </div>
                    <div class="item">
                        <img class="img-fluid full-width"
                            src="<?php echo base_url(); ?>dist/img/analyzer/screenshots/DV.png" alt="DV">
                    </div>
                    <div class="item">
                        <img class="img-fluid full-width"
                            src="<?php echo base_url(); ?>dist/img/analyzer/screenshots/NewHomeScreen.png"
                            alt="NewHomeScreen">
                    </div>
                    <div class="item">
                        <img class="img-fluid full-width"
                            src="<?php echo base_url(); ?>dist/img/analyzer/screenshots/Sync_screenshot.png"
                            alt="Sync_screenshot">
                    </div>
                    <div class="item">
                        <img class="img-fluid full-width"
                            src="<?php echo base_url(); ?>dist/img/analyzer/screenshots/GeoAnalysis_screenshot.png"
                            alt="GeoAnalysis">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<script>
var owlMobileImages = $('.mobile_images');
owlMobileImages.owlCarousel({
    items: 4,
    loop: true,
    margin: 10,
    autoplay: true,
    autoplayTimeout: 1000,
    autoplayHoverPause: true
});
</script>

<section class="bg-lightgrey">
    <div class="container">
        <div class="row justify-content-center mb-5 pb-3">
            <div class="col-md-7 text-center heading-section ftco-animate">
                <h2 class="mb-0 mt-5">Our Clientele </h2>
                <p class="h5 mb-0">Providing you with powerful analytical tools, is what we do best.</p>
            </div>
        </div>
        <div class="row justify-content-center mb-10 pb-3">
            <div class="col-md-12 d-flex align-self-stretch ftco-animate">
                <div id="clients" class="owl-carousel clients owl-theme">
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-karnataka_state_police.jpg"
                                class="img-fluid" alt="Prosoft-karnataka state police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img src="<?php echo base_url(); ?>dist/img/clients/prosoft-CBI.jpg"
                                class="img-fluid" alt="Prosoft-CBI"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-income_tax.png" class="img-fluid"
                                alt="Prosoft-income_tax"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img src="<?php echo base_url(); ?>dist/img/clients/prosoft-NIA.jpg"
                                class="img-fluid" alt="Prosoft-NIA"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img src="<?php echo base_url(); ?>dist/img/clients/prosoft-ED.jpg"
                                class="img-fluid" alt="Prosoft-ED"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img src="<?php echo base_url(); ?>dist/img/clients/prosoft-RPF.jpg"
                                class="img-fluid" alt="Prosoft-RPF"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-karnataka_forest_department.jpg"
                                class="img-fluid" alt="Prosoft-karnataka_forest_department"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-NASSCOM.jpg" class="img-fluid"
                                alt="Prosoft-NASSCOM"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-C-DAC.jpg" class="img-fluid"
                                alt="Prosoft-C-DAC"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-telangana_police.jpg"
                                class="img-fluid" alt="Prosoft-telangana_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-cyberabad_police.jpg"
                                class="img-fluid" alt="Prosoft-cyberabad_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-odisha_police.jpg"
                                class="img-fluid" alt="Prosoft-odisha_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-bangalore_city_police.jpg"
                                class="img-fluid" alt="Prosoft-bangalore_city_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-tamilnadu_police.jpg"
                                class="img-fluid" alt="Prosoft-tamilnadu_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-bihar_police.jpg"
                                class="img-fluid" alt="Prosoft-bihar_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-punjab_police.jpg"
                                class="img-fluid" alt="Prosoft-punjab_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-kerala_police.jpg"
                                class="img-fluid" alt="Prosoft-kerala_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-maharashtra_police.jpg"
                                class="img-fluid" alt="Prosoft-maharashtra_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-gujrat_police.jpg"
                                class="img-fluid" alt="Prosoft-gujrat_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-kolkata_police.jpg"
                                class="img-fluid" alt="Prosoft-kolkata_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-rajasthan_police.jpg"
                                class="img-fluid" alt="Prosoft-rajasthan_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-chhattisgarh_police.jpg"
                                class="img-fluid" alt="Prosoft-chhattisgarh_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-mumbai_police.jpg"
                                class="img-fluid" alt="Prosoft-mumbai_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-andhra_pradesh_police.jpg"
                                class="img-fluid" alt="Prosoft-andhra_pradesh_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-west_bengal_police.jpg"
                                class="img-fluid" alt="Prosoft-west_bengal_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-bangladesh_police.jpg"
                                class="img-fluid" alt="Prosoft-bangladesh_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-algeria_police.jpg"
                                class="img-fluid" alt="Prosoft-algeria_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-nigeria_police.jpg"
                                class="img-fluid" alt="Prosoft-nigeria_police"></a>
                    </div>
                    <div class="item">
                        <a href="#" class="partner"><img
                                src="<?php echo base_url(); ?>dist/img/clients/prosoft-lokayukta.png" class="img-fluid"
                                alt="Prosoft-lokayukta"></a>
                    </div>
                </div>

                <script>
                $(document).ready(function() {
                    var owlClients = $('.clients');
                    owlClients.owlCarousel({
                        items: 6,
                        loop: true,
                        margin: 10,
                        autoplay: true,
                        autoplayTimeout: 1000,
                        autoplayHoverPause: true
                    });


                    var owlMobileImages = $('.mobile_images');
                    owlMobileImages.owlCarousel({
                        items: 4,
                        loop: true,
                        margin: 10,
                        autoplay: true,
                        autoplayTimeout: 1000,
                        autoplayHoverPause: true
                    });

                    var owlCustomers = $('.customers');
                    owlCustomers.owlCarousel({
                        items: 2,
                        loop: true,
                        margin: 50,
                        autoplay: true,
                        autoplayTimeout: 3000,
                        autoplayHoverPause: true
                    });

                })
                </script>
            </div>
        </div>
    </div>
</section>

<section class="our-history white-bg p-5 mt-3">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="section-title text-center">
                    <h2 class="title-effect font-weight-bold">Product Timeline</h2>
                    <p>Version Timeline of C5 CDR Analyzer</p>
                </div>
            </div>
        </div>
    </div>

    <div class="container" id="cd-timeline">

        <!-- new added -->

        <div class="cd-timeline-block">
            <div class="cd-timeline-img-app"></div>
            <div class="cd-timeline-content">
                <div class="cardapp wow fadeInLeft">
                    <h3 class="card-header">C5 CDR Analyzer Android App 2.1</h3>
                    <div class="card-body text-justify">
                        <p>Performance Enhancement and Optimization</p>
                    </div>
                </div>
                <span class="cd-date date-left wow fadeInRight"> Released Updates<br>Aug 2021
                </span>
            </div>
        </div>

        <div class="cd-timeline-block">
            <div class="cd-timeline-img-release"></div>
            <div class="cd-timeline-content">
                <div class="cardreleaseright wow fadeInRight">
                    <h3 class="card-header">C5 CDR Analyzer-Version 5.6 </h3>
                    <div class="card-body text-justify">
                        <ul>
                            <li>SMS Details for company SMS in SDR Columns</li>
                            <li>IPDR Common Numbers (MSDN + IP Details)</li>
                            <li>Multiple Card Selection in Dashboard, Analysis and Quick Analysis</li>
                            <li>Displaying and comparing 14 Digit IMEI in all common number commands</li>
                        </ul>
                    </div>
                </div>
                <span class="cd-date date-right wow fadeInLeft">
                    Released

                    <br>August 2021 </span>
            </div>
        </div>



        <div class="cd-timeline-block">
            <div class="cd-timeline-img-app"></div>
            <div class="cd-timeline-content">
                <div class="cardapp wow fadeInLeft">
                    <h3 class="card-header">C5 CDR Analyzer Android App 2.0</h3>
                    <div class="card-body text-justify">
                        <p>Major tweaks, analytical upgrades and a redesigned UI.</p>
                    </div>
                </div>
                <span class="cd-date date-left wow fadeInRight"> Launched <br>Feb 2021</span>

            </div>
        </div>


        <div class="cd-timeline-block">
            <div class="cd-timeline-img-launch"></div>
            <div class="cd-timeline-content">
                <div class="cardlaunchright wow fadeInRight">
                    <h3 class="card-header">C5 CDR Analyzer - Version 5.5</h3>
                    <div class="card-body text-justify">
                        <ul>
                            <li>Option for analysis of calls made while traveling</li>
                            <li>Export individual for Geo Analysis Movements</li>
                            <li>Hexadecimal convert in analysis</li>
                            <li>New IPDR dashboard</li>
                            <li>New Search option – ‘Match Cases’</li>
                            <li>SDR column display options</li>
                            <li>Find nearest Tower from Cloud</li>
                        </ul>
                    </div>
                </div>
                <span class="cd-date date-right wow fadeInLeft">Launched <br>Jan 2021</span>
            </div>
        </div>

        <div class="cd-timeline-block">
            <div class="cd-timeline-img-eol"></div>
            <div class="cd-timeline-content">
                <div class="cardeol wow fadeInLeft">
                    <h3 class="card-header"> Version 4.x – E.O.L </h3>
                    <div class="card-body text-justify">
                        <p> C5 CDR Analyzer version 4.x reached its End of Life, as much as we loved developing for
                            version 4.x, we always kept looking forward and with the widely popular and more advanced
                            version 5.x, it was only natural to phase out this version.
                        </p>


                    </div>
                </div>
                <span class="cd-date  date-left wow fadeInRight"> End of Support <br> Aug 2020
                </span>
            </div>
        </div>



        <!------>

        <div class="cd-timeline-block">
            <div class="cd-timeline-img-launch"></div>
            <div class="cd-timeline-content">
                <div class="cardlaunchright wow fadeInRight">
                    <h3 class="card-header">Trial Edition - C5 CDR Analyzer</h3>
                    <div class="card-body text-justify">
                        <p> Don’t take our word for it. Try the application yourself, with all the features unlocked
                            for 30 days, absolutely free!</p>
                    </div>
                </div>
                <span class="cd-date date-right wow fadeInLeft"> Launched Free Edition <br> August 2020</span>
            </div>
        </div>

        <div class="cd-timeline-block">
            <div class="cd-timeline-img-release"></div>
            <div class="cd-timeline-content">
                <div class="cardrelease wow fadeInLeft">
                    <h3 class="card-header"> C5 CDR Analyzer 5.1.8.3</h3>
                    <div class="card-body text-justify">
                        <ul>
                            <li>Option to create SDR connection file added</li>
                            <li>Night Calls now available in Quick Analysis</li>
                            <li>Geo-Fencing enhanced</li>
                            <li>Easy navigation between different Analysis</li>
                        </ul>
                    </div>
                </div>
                <span class="cd-date date-left wow fadeInRight">Released<br>August 2020</span>
            </div>
        </div>

        <div class="cd-timeline-block">
            <div class="cd-timeline-img-app"></div>
            <div class="cd-timeline-content">
                <div class="cardappright wow fadeInRight">
                    <h3 class="card-header">C5 CDR Analyzer Android App</h3>
                    <div class="card-body text-justify">
                        <p>We’ve made the already influential C5 CDR Analyzer app even better. Major tweaks, analytical
                            upgrades and an even more convenient synchronization module has made this our most
                            wide-ranging and feature rich update to the app yet.</p>
                    </div>
                </div>
                <span class="cd-date date-right wow fadeInLeft"> Released Updates<br>August 2020 </span>
            </div>
        </div>

        <div class="cd-timeline-block">
            <div class="cd-timeline-img-release"></div>
            <div class="cd-timeline-content">
                <div class="cardrelease wow fadeInLeft">
                    <h3 class="card-header"> C5 CDR Analyzer 5.1.7.3</h3>
                    <div class="card-body text-justify">
                        <ul>
                            <li>Option to “Match Movements” with select CDR added</li>
                            <li>Users can match numbers between one or more analysis</li>
                            <li>Option to merge CDR into IPDR Analysis</li>
                            <li>”Clean Data” feature in Database Management</li>
                            <li>Detailed view of “Behavior Analysis”</li>
                            <li>Improved Cell Site update settings</li>
                        </ul>
                    </div>
                </div>
                <span class="cd-date date-left wow fadeInRight">Released<br>May 2020</span>
            </div>
        </div>

        <div class="cd-timeline-block">
            <div class="cd-timeline-img-launch"></div>
            <div class="cd-timeline-content">
                <div class="cardlaunchright wow fadeInRight">
                    <h3 class="card-header">C5 CDR Analyzer – Covid-19 Edition</h3>
                    <div class="card-body text-justify">
                        <p>To tackle such an unparalleled situation to contain the virus and those infected,
                            authorities were facing a mammoth task. We sought out to ease this by launching an
                            exclusive COVID19 Edition. All the familiar features but with more focus on</p>
                        <ul>
                            <li>Containment</li>
                            <li>Ascertaining risk zones</li>
                            <li>Identifying vulnerable individuals, and more</li>
                        </ul>

                    </div>
                </div>
                <span class="cd-date date-right wow fadeInLeft"> Launched Covid-19 Edition<br>May 2020 </span>
            </div>
        </div>

        <div class="cd-timeline-block">
            <div class="cd-timeline-img-release"></div>
            <div class="cd-timeline-content">
                <div class="cardrelease wow fadeInLeft">
                    <h3 class="card-header">C5 CDR Analyzer 5.1.5.0</h3>
                    <div class="card-body text-justify">
                        <ul>
                            <li>Cloud search for Cell IDs added</li>
                            <li>Access to Cell ID data from server machine</li>
                            <li>Option to update Cell Sites from local, server or cloud while importing files added
                            </li>

                        </ul>
                    </div>
                </div>
                <span class="cd-date date-left wow fadeInRight"> Released <br> November 2019</span>
            </div>
        </div>

        <div class="cd-timeline-block">
            <div class="cd-timeline-img-release"></div>
            <div class="cd-timeline-content">
                <div class="cardreleaseright wow fadeInRight">
                    <h3 class="card-header"> C5 CDR Analyzer 5.1.4.1 </h3>
                    <div class="card-body text-justify">
                        <ul>
                            <li>Feature Enhancements</li>
                            <li>New Quick Analysis design with fast data import</li>
                            <li>Data synchronization between C5 Desktop and Android application</li>
                            <li>Improved Combined number Analysis</li>
                            <li>Easy “Export to Excel” and .zip, .rar file import support added</li>
                            <li>Option to analyse individual CDR from Combined Analysis added</li>
                            <li>Intuitive Notifications added for user ease</li>
                        </ul>
                    </div>
                </div>
                <span class="cd-date date-right wow fadeInLeft">Released <br>August 2019 </span>
            </div>
        </div>

        <div class="cd-timeline-block">
            <div class="cd-timeline-img-app"></div>
            <div class="cd-timeline-content">
                <div class="cardapp wow fadeInLeft">
                    <h3 class="card-header"> C5 CDR Analyzer Android App</h3>
                    <div class="card-body text-justify">
                        <p> We envisioned to bring the powerful and robust data analytics of the desktop C5 CDR
                            Analyzer to the convenience of the mobile platform. Our Android app offers some of the
                            popular features that I.Os find resourceful. With easy import, analysis and share modules
                            the app is an upgrade in everyday investigative scenarios.
                        </p>
                    </div>
                </div>
                <span class="cd-date date-left wow fadeInRight">Launched Mobile App<br> August 2019 </span>
            </div>
        </div>

        <div class="cd-timeline-block">
            <div class="cd-timeline-img-release"></div>
            <div class="cd-timeline-content">
                <div class="cardreleaseright wow fadeInRight">
                    <h3 class="card-header"> C5 CDR Analyzer 5.1.2.0 </h3>
                    <div class="card-body text-justify">

                        <ul>
                            <li> Large Data Performance Optimization in a low-end server</li>
                            <li>Dashboard performance enhancement</li>
                            <li>Cell ID data standardization</li>
                        </ul>

                    </div>
                </div>
                <span class="cd-date date-right wow fadeInLeft">Released<br>April 2019 </span>
            </div>
        </div>



        <div class="cd-timeline-block">
            <div class="cd-timeline-img-launch"></div>
            <div class="cd-timeline-content">
                <div class="cardlaunch wow fadeInLeft">
                    <h3 class="card-header"> C5 CDR Analyzer 5.1 </h3>
                    <div class="card-body text-justify">
                        <ul>
                            <li> Enterprise Plus Edition</li>
                            <li> SDR data management</li>

                        </ul>
                    </div>
                </div>
                <span class="cd-date date-left wow fadeInRight"> Launched Enterprise Plus Edition
                    <br>August 2018 </span>
            </div>
        </div>

        <div class="cd-timeline-block">
            <div class="cd-timeline-img-certified"></div>
            <div class="cd-timeline-content">
                <div class="cardcertifiedright wow fadeInRight">
                    <h3 class="card-header"> C5 CDR Analyzer 5.0.5 </h3>
                    <div class="card-body text-justify">

                        <ul>
                            <li> Standardisation Testing and Quality Certification (STQC), also performed the Security
                                Testing on the application and certified it</li>
                            <li>Security Testing of the application is done by a CERT-IN empaneled vendor</li>
                        </ul>

                    </div>
                </div>
                <span class="cd-date date-right wow fadeInLeft"> Certified <br> June 2018 </span>
            </div>
        </div>

        <div class="cd-timeline-block">
            <div class="cd-timeline-img-certified"></div>
            <div class="cd-timeline-content">
                <div class="cardcertified wow fadeInLeft">
                    <h3 class="card-header"> C5 CDR Analyzer 5.0.3</h3>
                    <div class="card-body text-justify">
                        <p> Standardisation Testing and Quality Certification (STQC) Directorate is an attached office
                            of the Ministry of Electronics and Information Technology, Government of India.
                            Functionality Testing was completed and achieved on this version of the C5 CDR Analyzer
                            during e-Governance project for CBI (Central Bureau of Investigation)</p>
                    </div>
                </div>
                <span class="cd-date date-left wow fadeInRight"> Certified <br> January 2018</span>
            </div>
        </div>

        <div class="cd-timeline-block">
            <div class="cd-timeline-img-eol"></div>
            <div class="cd-timeline-content">
                <div class="cardeolright wow fadeInRight">
                    <h3 class="card-header"> Version 3.x – E.O.L </h3>
                    <div class="card-body text-justify">
                        <p> The version 3.x reached its End of Life As much as we loved developing for version 3.x, we
                            always kept looking forward and with the widely popular version 4.x, it was only natural to
                            phase out this version.
                        </p>


                    </div>
                </div>
                <span class="cd-date  date-right wow fadeInLeft"> End of Support <br> Dec 2017
                </span>
            </div>
        </div>

        <div class="cd-timeline-block">
            <div class="cd-timeline-img-release"></div>
            <div class="cd-timeline-content">
                <div class="cardrelease wow fadeInLeft">
                    <h3 class="card-header"> C5 CDR Analyzer 4.5.200</h3>
                    <div class="card-body text-justify">
                        <ul>
                            <li>User preferred Print Ready option added</li>
                            <li>User convenience buttons added</li>
                            <li>Tower name and Azimuth gets added while updating Cell Site in CDR</li>
                            <li> “Foot Print Report” now added to reports</li>
                            <li>Pivot view option now available in Common Numbers</li>
                            <li>Easy “Day wise” option added in Timeline Analysis</li>
                            <li>IPDR Frequency Analysis now gets graphical representation</li>
                            <li>Option to update IPDR case wises added </li>
                            <li>Patterns Analysis now available in IPDR Analysis</li>
                            <li>Option added to backup cases to Server added</li>
                        </ul>
                    </div>
                </div>
                <span class="cd-date  date-left wow fadeInRight"> Released<br>June 2017 </span>
            </div>
        </div>


        <div class="cd-timeline-block">
            <div class="cd-timeline-img-release"></div>
            <div class="cd-timeline-content">
                <div class="cardreleaseright wow fadeInRight">
                    <h3 class="card-header"> C5 CDR Analyzer 5.0.0.10</h3>
                    <div class="card-body text-justify">
                        <p> The most feature rich release of the version 5 so far. We fine-tuned all of the features
                            for maximum performance and efficiency. This version had the highest adoptability rate,
                            with positive industry experiences across the board.</p>

                    </div>
                </div>
                <span class="cd-date date-right wow fadeInLeft">Release <br>June 2017 </span>
            </div>
        </div>


        <div class="cd-timeline-block">
            <div class="cd-timeline-img-release"></div>
            <div class="cd-timeline-content">
                <div class="cardrelease wow fadeInLeft">
                    <h3 class="card-header"> C5 CDR Analyzer 4.5.151</h3>
                    <div class="card-body text-justify">
                        <ul>
                            <li>In Roamer option added in ILD Analysis </li>
                            <li>Sort and delete duplicate options added in IPDR Analysis</li>
                            <li>Frequency Analysis for IPDR added</li>
                            <li>IP details search improved along with arrange column option in IPDR Analysis</li>
                            <li>IMEI CDR gets “Roamer” update</li>
                            <li>ILD Analysis now comes with Suspect List option</li>
                            <li>Option to match IPDR data with Tower or CDR data</li>
                            <li>Enhanced “Matched Data” visualization</li>
                        </ul>
                    </div>
                </div>
                <span class="cd-date  date-left wow fadeInRight"> Release<br>January 2017 </span>
            </div>
        </div>


        <div class="cd-timeline-block">
            <div class="cd-timeline-img-release"></div>
            <div class="cd-timeline-content">
                <div class="cardreleaseright wow fadeInRight">
                    <h3 class="card-header"> C5 CDR Analyzer 4.5.128</h3>
                    <div class="card-body text-justify">

                        <ul>
                            <li> “Movements” added to Location Analysis in CDR and Quick analysis reports</li>
                            <li>New data regarding IP details is updated</li>
                            <li>S.O.P reports now available in Quick Analysis</li>
                            <li>Option to update cell site in IPDR Analysis added</li>
                            <li>Added Cell IDs Import Log Report in Reports with Delete option</li>
                        </ul>

                    </div>
                </div>
                <span class="cd-date date-right wow fadeInLeft">Released <br>September 2016</span>
            </div>
        </div>


        <div class="cd-timeline-block">
            <div class="cd-timeline-img-launch"></div>
            <div class="cd-timeline-content">
                <div class="cardlaunch wow fadeInLeft">
                    <h3 class="card-header"> C5 CDR Analyzer 4.5 – Educational Edition
                    </h3>
                    <div class="card-body text-justify">
                        <ul>
                            <li>Ideal for LEA academies to teach future I.Os </li>
                            <li>Easy for hands on training. </li>
                            <li>All features unlocked for maximum exposure. </li>


                        </ul>
                    </div>
                </div>
                <span class="cd-date date-left wow fadeInRight"> Launched New Edition <br>June 2016</span>
            </div>
        </div>


        <div class="cd-timeline-block">
            <div class="cd-timeline-img-release"></div>
            <div class="cd-timeline-content">
                <div class="cardreleaseright wow fadeInRight">
                    <h3 class="card-header"> C5 CDR Analyzer 4.5.105 </h3>
                    <div class="card-body text-justify">
                        <ul>
                            <li>Print Duplex option added</li>
                            <li>IPDR Analysis in Dashboard added</li>
                            <li>Ability to search for same numbers in CDR and TDR Analysis</li>
                            <li>Get IPDR Analysis on main screen</li>
                            <li>Update SDR of select cases and filters in Database Management</li>
                            <li>Option to import crime cases from excel in Case Master added</li>
                        </ul>
                    </div>
                </div>
                <span class="cd-date  date-right wow fadeInLeft">Released <br>May 2016 </span>
            </div>
        </div>


        <div class="cd-timeline-block">
            <div class="cd-timeline-img-launch"></div>
            <div class="cd-timeline-content">
                <div class="cardlaunch wow fadeInLeft">
                    <h3 class="card-header">Version 5.0 - C5 CDR Analyzer</h3>
                    <div class="card-body text-justify">
                        <p> After two years of constantly developing and performing tweaks after the beta release, we
                            were proud to launch our most comprehensive solution, yet. New ways to help you analyse CDR
                            data, and improvements across the entire application to make it faster and delightful to
                            use.</p>
                    </div>
                </div>
                <span class="cd-date date-left wow fadeInRight"> Launch New Version 5
                    <br>April 2016 </span>
            </div>
        </div>




        <div class="cd-timeline-block">
            <div class="cd-timeline-img-eol"></div>
            <div class="cd-timeline-content">
                <div class="cardeolright wow fadeInRight">
                    <h3 class="card-header">Version 2.x – E.O.L </h3>
                    <div class="card-body text-justify">
                        <p> The version 2.x reached its end of life, we had come a long way in terms of technological
                            development that it served no benefit to keep the support operational for this version. We
                            had a better version to offer. </p>
                    </div>
                </div>
                <span class="cd-date date-right wow fadeInLeft"> End of Support<br>December 2015 </span>
            </div>
        </div>


        <div class="cd-timeline-block">
            <div class="cd-timeline-img-release"></div>
            <div class="cd-timeline-content">
                <div class="cardrelease wow fadeInLeft">
                    <h3 class="card-header"> C5 CDR Analyzer 4.5.50</h3>
                    <div class="card-body text-justify">
                        <ul>
                            <li>Copy as RTF option added</li>
                            <li>Assign bulk numbers for Group name in Number Tracking</li>
                            <li>Enhanced ‘Found Numbers’ search throughout the application</li>
                            <li> “Out of Box” searching option added</li>
                            <li>New ILD importing module added</li>
                            <li>Option to interchange columns in ILD Analysis added</li>
                            <li>Improved ILD Analysis management</li>
                        </ul>
                    </div>
                </div>
                <span class="cd-date date-left wow fadeInRight">Released<br>November 2015 </span>
            </div>
        </div>





        <div class="cd-timeline-block">
            <div class="cd-timeline-img-release"></div>
            <div class="cd-timeline-content">
                <div class="cardreleaseright wow fadeInRight">
                    <h3 class="card-header"> C5 CDR Analyzer 4.5.40</h3>
                    <div class="card-body text-justify">
                        <ul>
                            <li>Compatible with Windows 10</li>
                            <li>Option to update Roaming Details in CDR Analysis</li>
                            <li>Quick Analysis gets improved “First and Last” calls in location analysis</li>
                            <li>Option to update SDR with service provider and circle name in CDR and TDR analysis</li>
                            <li>Improved Common Number name display</li>
                            <li>Option to match CDR filters with telephone book added</li>
                            <li>Option to arrange columns position in Tower Analysis for base number and other details
                            </li>
                            <li>Advance Search can now search service provider by LRN</li>
                            <li>Option to hide or display number of IMSI used in CDR Analysis</li>
                        </ul>

                    </div>
                </div>
                <span class="cd-date date-right wow fadeInLeft">Released<br>August 2015 </span>
            </div>
        </div>


        <div class="cd-timeline-block">
            <div class="cd-timeline-img-release"></div>
            <div class="cd-timeline-content">
                <div class="cardrelease wow fadeInLeft">
                    <h3 class="card-header">C5 CDR Analyzer 5.0</h3>
                    <div class="card-body text-justify">
                        <ul>
                            <li>Beta version released, while the development work continued.</li>
                        </ul>
                    </div>
                </div>
                <span class="cd-date date-left wow fadeInRight"> Beta Version Released<br>March 2015</span>
            </div>
        </div>




        <div class="cd-timeline-block">
            <div class="cd-timeline-img-release"></div>
            <div class="cd-timeline-content">
                <div class="cardreleaseright wow fadeInRight">
                    <h3 class="card-header"> C5 CDR Analyzer 4.5.30 </h3>
                    <div class="card-body text-justify">
                        <ul>
                            <li>Option to create more detailed Clusters added</li>
                            <li>Users can now add notes to IMEI and Cell sites</li>
                            <li>Pattern Analysis in tower details gets option for “Time Between” </li>
                            <li>Option to Keep Case Details while deleting imported data added</li>
                            <li>Option to remove LRN in Tower Analysis added</li>
                            <li>Now Find and Replace cell sites in CDR Analysis</li>
                            <li>Open Tower Analysis added</li>
                        </ul>
                    </div>
                </div>
                <span class="cd-date date-right wow fadeInLeft">Released<br>August 2014 </span>
            </div>
        </div>

        <div class="cd-timeline-block">
            <div class="cd-timeline-img-release"></div>
            <div class="cd-timeline-content">
                <div class="cardrelease wow fadeInLeft">
                    <h3 class="card-header"> C5 CDR Analyzer 4.5.0</h3>
                    <div class="card-body text-justify">
                        <ul>
                            <li>Users can now transfer unwanted cases to a reference database</li>
                            <li>New delete options introduced for database maintenance</li>
                            <li>Improved Filter management </li>
                            <li>Main search now includes results from reference database</li>
                            <li>Now match CDR in reference database</li>
                            <li>Support for Bulk SDR import added </li>
                            <li>Option to add or remove, Cell IDs import log in Reports </li>
                            <li>Searching IMEI and CDR made easy</li>
                            <li>New utility options to Backup or Restore cases</li>
                        </ul>
                    </div>
                </div>
                <span class="cd-date date-left wow fadeInRight">Released<br>February 2014</span>
            </div>
        </div>

        <div class="cd-timeline-block">
            <div class="cd-timeline-img-rnd"></div>
            <div class="cd-timeline-content">
                <div class="cardrndright wow fadeInRight">
                    <h3 class="card-header">New Version</h3>
                    <div class="card-body text-justify">
                        <p> Research and development work commenced on the next big iteration to the C5 CDR Analyzer
                            application</p>
                    </div>
                </div>
                <span class="cd-date date-right wow fadeInLeft"> R & D commenced<br>January 2014 </span>
            </div>
        </div>

        <!-- 
	        <div class="cd-timeline-block">
	            <div class="cd-timeline-img"></div>
	            <div class="cd-timeline-content">
	                <div class="cardcertified wow fadeInRight">
	                    <h3 class="card-header"> </h3>
	                    <div class="card-body text-justify">
	                        <ul>
	                            <li></li>
	                            <li></li>
	                            <li></li>
	                            <li></li>
	                        </ul>
	                    </div>
	                </div>
	                <span class="cd-date wow fadeInLeft"> <br> </span>
	            </div>
	        </div> -->



        <div class="cd-timeline-block">
            <div class="cd-timeline-img-release"></div>
            <div class="cd-timeline-content">
                <div class="cardrelease wow fadeInLeft">
                    <h3 class="card-header">C5-CDR Analyzer 4.0</h3>
                    <div class="card-body text-justify">
                        <ul>
                            <li>Compatible with Windows 8</li>
                            <li>Designed for Big Data - handles tens of terabytes of data & quickly processes</li>
                            <li>Powerful and interactive visual analytics.</li>
                            <li>Case Visualizer.</li>
                            <li>Geo-Spatial Analysis: Gen-Fencing, Animation of movements on google map sequentially to
                                give a fair idea of target numbers’ movement patterns.</li>
                        </ul>
                    </div>
                </div>
                <span class="cd-date date-left wow fadeInRight">Released<br> June 2013</span>
            </div>
        </div>



        <div class="cd-timeline-block">
            <div class="cd-timeline-img-release"></div>
            <div class="cd-timeline-content">
                <div class="cardlaunchright wow fadeInRight">
                    <h3 class="card-header">C5-CDR Analyzer 3.5</h3>
                    <div class="card-body text-justify">
                        <p>Release Service Pack 1</p>
                        <ul>
                            <li>During login process the user name will be retain the name of the previously logged
                                user.</li>
                            <li>Ability of Bulk Importing of CDR’s, where numerous CDR’s can be imported at a single
                                go.</li>
                        </ul>
                    </div>
                </div>
                <span class="cd-date date-right wow fadeInLeft">Released<br>May 2012</span>
            </div>
        </div>




        <div class="cd-timeline-block">
            <div class="cd-timeline-img-launch"></div>
            <div class="cd-timeline-content">
                <div class="cardlaunch wow fadeInLeft">
                    <h3 class="card-header">C5-CDR Analyzer 3.0</h3>
                    <div class="card-body text-justify">
                        <ul>
                            <li>Compatibility with Windows XP, Vista and Windows 7 <br>(Ultimate Edition).</li>
                            <li>Supports Client Server Architecture. With option to connect to the database located on
                                various locations, viz. Local, Server, Group, Global. It also supports integration with
                                DDA (Dump Data Analysis) as prior versions supported SDR database integration.</li>
                            <li>Quick Search option has been provided to search required series, STD, ISD Codes, Tower
                                Details, mobile numbers and names on a <br>single click.</li>
                        </ul>
                    </div>
                </div>
                <span class="cd-date date-left wow fadeInRight">Launched<br>May 2011</span>
            </div>
        </div>


        <div class="cd-timeline-block">
            <div class="cd-timeline-img-release"></div>
            <div class="cd-timeline-content">
                <div class="cardreleaseright wow fadeInRight">
                    <h3 class="card-header">C5-CDR Analyzer 2.0</h3>
                    <div class="card-body text-justify">
                        <p>Service Pack 2
                        <p>
                        <ul>
                            <li>Provision to update Series, STD, ISD Codes and Cellsites (TowerID’s).</li>
                            <li>Provision to add Tower Details with all possible Cell ID’s combinations.</li>
                            <li>Generation of Hash value to ensure consistency of required file.</li>
                        </ul>

                    </div>
                </div>
                <span class="cd-date date-right wow fadeInLeft"> Released<br>March 2010</span>
            </div>
        </div>

        <div class="cd-timeline-block">
            <div class="cd-timeline-img-release"></div>
            <div class="cd-timeline-content">
                <div class="cardrelease wow fadeInLeft">
                    <h3 class="card-header">C5-CDR Analyzer 2.0</h3>
                    <div class="card-body text-justify">
                        <p>Service Pack 1</p>
                        <ul>
                            <li>Updated Service provider series, STD and ISD codes and Updated Tower details of all
                                Service providers of Karnataka State.</li>
                            <li>Provision to import CDR's of HTML and PDF format files.</li>
                            <li>Performance of CDR Analysis has been increased pertaining to speed and accuracy.</li>
                            <li>Enabling fast access to Geo Analysis (i.e., Displays tower locations, CDR movements and
                                mapping nearest towers).</li>
                        </ul>
                    </div>
                </div>
                <span class="cd-date date-left wow fadeInRight">Released<br>October 2009</span>
            </div>
        </div>

        <div class="cd-timeline-block">
            <div class="cd-timeline-img-launch"></div>
            <div class="cd-timeline-content">
                <div class="cardlaunchright wow fadeInRight">
                    <h3 class="card-header">C5-CDR Analyzer 1.0</h3>
                    <div class="card-body text-justify">
                        <p>This was first version of the software, was developed to import multi-formatted CDR files
                            and to perform CDR analysis by generating various patterns needed and to generate
                            intelligent reports.</p>
                    </div>
                </div>
                <span class="cd-date  date-right wow fadeInLeft">Launched<br>June 2008</span>
            </div>
        </div>
    </div>
</section>