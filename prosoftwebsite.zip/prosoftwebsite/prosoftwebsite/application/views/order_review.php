
	<?php
		require_once(APPPATH . 'third_party/razorpay-php/config.php');
		require_once(APPPATH . 'third_party/razorpay-php/Razorpay.php');
	?>

	<style>
	.razorpay-payment-button {
		color: #ffffff !important;
		background-color: #0071bc;
		border-color: #7266ba;
		font-size: 16px;
		padding: 5px;
		display: block;
		max-width: 300px;
		margin: auto;
	}

	.razorpay-payment-button:hover {
		color: #ffffff !important;
		background-color: #0071bcc4;
		border-color: #7266ba;
		font-size: 16px;
		padding: 5px;
		display: block;
		max-width: 300px;
		margin: auto;
		margin-top: -2px;
	}
	</style>

	<!-- session varaible for PR coupon -->
	<?php
		//if($this->input->get("id")==md5("PR"))
		//{
	?>
		<script>
			$(document).ready(function(){
				$('.Actual-price').html('<?php echo $base_price;?>');
				$('.Offer-price').html('<?php echo $OfferPrice;?>');
				$('.Product-name').html('<?php echo $Product_Name;?>');
				$('.Subscriptionplan-name').html('<?php echo $SubscriptionPlan_Name;?>');
				$('.Coupon-Code').html('<?php echo $CouponCode;?>');
				$('.f_name').html('<?php echo $f_name?>');
				$('.f_contact').html('<?php echo $f_contact?>');
				$('.f_email').html('<?php echo $f_email?>');
				$('.f_department').html('<?php echo $f_department?>');
				$('.f_designation').html('<?php echo $f_designation?>');
				$('.f_address').html('<?php echo $f_address?>');
				$('.total_amount').html('<?php echo $total_amount;?>');
				$('.total_amount').css('font-size','1.5rem');
				$('.total_amount').addClass("h1");
				$('.Before_GST').html('<?php echo $amount_before_GST;?>');
				$('.GST_18').html('<?php echo $GST_18;?>');                   
			});
		</script>
	<?php
		//}
	?>

	<!-- session varaible for S1 coupon -->
	<?php
		/*
		if($this->input->get("id")==md5("S1"))
		{
	?>
		<script>
			$(document).ready(function(){
				$('.Actual-price').html('<?php echo $base_price;?>');
				$('.Offer-price').html('<?php echo $OfferPrice;?>');
				$('.Product-name').html('<?php echo $Product_Name;?>');
				$('.Subscriptionplan-name').html('<?php echo $SubscriptionPlan_Name;?>');
				$('.Coupon-Code').html('<?php echo $CouponCode;?>');
				$('.f_name').html('<?php echo $f_name?>');
				$('.f_contact').html('<?php echo $f_contact?>');
				$('.f_email').html('<?php echo $f_email?>');
				$('.f_department').html('<?php echo $f_department?>');
				$('.f_designation').html('<?php echo $f_designation?>');
				$('.f_address').html('<?php echo $f_address?>');
				$('.total_amount').html('<?php echo $total_amount;?>');
				$('.total_amount').css('font-size','1.5rem');
				$('.Before_GST').html('<?php echo $amount_before_GST;?>');
				$('.GST_18').html('<?php echo $GST_18;?>');
			});
		</script>
	<?php
		}
	?>

	<!-- session varaible for PR  base  -->
	<?php
		if($this->input->get("id")==md5("basePR"))
		{
	?>
		<script>
            $(document).ready(function(){
                $('.Actual-price').html('<?php echo $base_price;?>');
                $('.Offer-price').html('<?php echo $OfferPrice;?>');
                $('.Product-name').html('<?php echo $Product_Name;?>');
                $('.Subscriptionplan-name').html('<?php echo $SubscriptionPlan_Name;?>');
                $('.Coupon-Code').html('<?php echo $CouponCode;?>');
                $('.f_name').html('<?php echo $f_name?>');
                $('.f_contact').html('<?php echo $f_contact?>');
                $('.f_email').html('<?php echo $f_email?>');
                $('.f_department').html('<?php echo $f_department?>');
                $('.f_designation').html('<?php echo $f_designation?>');
                $('.f_address').html('<?php echo $f_address?>');
                $('.total_amount').html('<?php echo $total_amount;?>');
                $('.total_amount').css('font-size','1.5rem');
                $('.Before_GST').html('<?php echo $amount_before_GST;?>');
                $('.GST_18').html('<?php echo $GST_18;?>');
            });
		</script>
	<?php
		}
	?>

	<!-- session varaible for S1 base -->
	<?php
		if($this->input->get("id")==md5("baseS1"))
		{
	?>
		<script>
			$(document).ready(function(){
				$('.Actual-price').html('<?php echo $base_price;?>');
				$('.Offer-price').html('<?php echo $OfferPrice;?>');
				$('.Product-name').html('<?php echo $Product_Name;?>');
				$('.Subscriptionplan-name').html('<?php echo $SubscriptionPlan_Name;?>');
				$('.Coupon-Code').html('<?php echo $CouponCode;?>');
				$('.f_name').html('<?php echo $f_name?>');
				$('.f_contact').html('<?php echo $f_contact?>');
				$('.f_email').html('<?php echo $f_email?>');
				$('.f_department').html('<?php echo $f_department?>');
				$('.f_designation').html('<?php echo $f_designation?>');
				$('.f_address').html('<?php echo $f_address?>');

				$('.total_amount').html('<?php echo $total_amount;?>');
				$('.Before_GST').html('<?php echo $amount_before_GST;?>');
				$('.GST_18').html('<?php echo $GST_18;?>');
			});
		</script>
	<?php
		}
		*/
	?>

	<section class=" ftco-section bg-light oder_review-section">
		<div class="container">
			<div class="row justify-content-center pb-3 mt-4">
				<div class="col-md-7 text-center heading-section ftco-animate">
						<h2 class="mb-4">Review Your Order</h2>
						<h3>C5 CDR Analyzer - <span class="text-danger">Lite Edition</span></h3>
				</div>
			</div>
		</div>

		<div class="container">
			<div class="row">
				<div class="col-sm-6 product_info ">
					<!-- product information -->
					<div class="row">
						<div class="col-12">
							<h4 class="text-center mt-4 mb-4 font-weight-bold">Product Information</h4>
						</div>
					</div>

					<div class="row price_info">
						<div class="col-12">
							<!-- actual price -->
							<div class="row">
								<div class="col-5 ">
										<span>Actual Price</span>
								</div>
								<div class="col-1 text-center">
										<span> : </span>
								</div>
								<div class="col-5">
										<span class="Actual-price"></span>
								</div>
							</div>

							<!-- offer price -->
							<div class="row">
								<div class="col-5 " >
										<span>Offer Price</span>
								</div>
								<div class="col-1  text-center">
										<span> : </span>
								</div>
								<div class="col-5 ">
										<span class="Offer-price"></span>
								</div>
							</div>

							<!-- Product-name -->
							<div class="row">
								<div class="col-5 ">
										<span>Product Name</span>
								</div>
								<div class="col-1 text-center ">
										<span> : </span>
								</div>
								<div class="col-5  ">
										<span class="Product-name"></span>
								</div>
							</div>

							<!-- Subscriptionplan-name -->
							<div class="row">
								<div class="col-5  " >
										<span>Subscription Plan </span>
								</div>
								<div class="col-1 text-center ">
										<span> : </span>
								</div>
								<div class="col-5 ">
										<span class="Subscriptionplan-name"></span>
								</div>
							</div>

							<!-- Coupon-Code -->
							<div class="row">
								<div class="col-5 ">
										<span>Coupon Code</span>
								</div>
								<div class="col-1 text-center ">
										<span> : </span>
								</div>
								<div class="col-5  ">
										<span class="Coupon-Code"></span>
								</div>
							</div>
						</div>
					</div>
					<!-- --------------- -->

					<!-- user information -->
					<div class="row ">
						<div class="col-12">
							<h4 class=" text-center mt-4 mb-4 font-weight-bold">User Information</h4>
						</div>
					</div>

					<div class="row user_info mb-4">
						<div class="col-12">
            

							<!-- Full Name -->
							<div class="row">
								<div class="col-5 ">
										<span>Full Name</span>
								</div>
								<div class="col-1 text-center">
										<span> : </span>
								</div>
								<div class="col-5 ">
										<span class="f_name"></span>
								</div>
							</div>

							<!-- Contact No -->
							<div class="row">
								<div class="col-5 " >
										<span>Contact No</span>
								</div>
								<div class="col-1  text-center">
										<span> : </span>
								</div>
								<div class="col-5 ">
										<span class="f_contact"></span>
								</div>
							</div>

							<!-- Department Email-ID -->
							<div class="row">
								<div class="col-5 " >
										<span>Department Email-ID</span>
								</div>
								<div class="col-1 text-center ">
										<span> : </span>
								</div>
								<div class="col-5 ">
										<span class="f_email"></span>
								</div>
							</div>

							<!-- Department -->
							<div class="row">
								<div class="col-5  " >
										<span>Department</span>
								</div>
								<div class="col-1 text-center ">
										<span> : </span>
								</div>
								<div class="col-5 ">
										<span class="f_department"></span>
								</div>
							</div>

							<!-- Designation -->
							<div class="row">
								<div class="col-5 " >
										<span>Designation</span>
								</div>
								<div class="col-1 text-center ">
										<span> : </span>
								</div>
								<div class="col-5 ">
										<span class="f_designation"></span>
								</div>
							</div>

								<!-- Address -->
								<div class="row">
								<div class="col-5 " >
										<span>Address</span>
								</div>
								<div class="col-1 text-center">
										<span> : </span>
								</div>
								<div class="col-5 ">
										<span class="f_address"></span>
								</div>
							</div>

						</div>
					</div>
				</div>

				<div class="col-sm-6 bg-white">
					<div class="row">
						<div class="col-12">
							<h4 class="text-center mt-4 mb-4 font-weight-bold">Payment Information</h4>
						</div>
					</div>

					<!-- payment  information -->
					<div class="row payment_info">
						<div class="col-12">
							<!-- amount before GST -->
							<div class="row d-flex justify-content-center">
								<div class="col-5">
									<span>Amount Before GST</span>
								</div>
								<div class="col-1">
									<span> :</span>
								</div>
								<div class="col-5">
									<span class="Before_GST d-flex justify-content-end"> </span>
								</div>
							</div>

							<!-- Apply GST -->
							<div class="row d-flex justify-content-center">
								<div class="col-5">
									<span>GST (18%)</span>
								</div>
								<div class="col-1">
									<span> :</span>
								</div>
								<div class="col-5">
									<span class="GST_18 d-flex justify-content-end"> </span>
								</div>
							</div>

								<!-- Total  Amount -->
							<div class="row d-flex justify-content-center">
								<div class="col-5">
									<span>Net Total Amount</span>
								</div>
								<div class="col-1">
									<span> :</span>
								</div>
								<div class="col-5">
									<span class="total_amount d-flex justify-content-end"> </span>
								</div>
							</div>

							<div class="row mt-4">
								<div class="col-12 d-flex justify-content-center">
									<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
									<form role="form" name='razorpayform' id="razorpayform" class="float-right" 
										action="<?php echo base_url(); ?>index.php/UserInfo/payment_response" method="POST">

										<input type="hidden" name="razorpay_payment_id" id="razorpay_payment_id">
										<input type="hidden" name="razorpay_signature" id="razorpay_signature">

										<button type="button" class="btn btn-success px-5" id="rzp-button1">Pay Now</button>

										<!-- <script
											src="https://checkout.razorpay.com/v1/checkout.js"
											data-key="<?php echo $keyId; ?>"
											data-amount="<?php echo ($this->session->userdata('amount') * 100); ?>"
											data-buttontext="Proceed to Pay"
											data-name="Prosoft e-Solutions"
											data-description="Transaction with Razorpay"
											data-image="img/logo/favicon-black.png"
                      
											data-prefill.name="<?php echo $this->session->userdata('f_name') ?>"
											data-prefill.email="<?php echo $this->session->userdata('f_email') ?>"
											data-prefill.contact="<?php echo $this->session->userdata('f_contact') ?>"
      
											data-notes.soolegal_order_id="<?php echo $this->session->userdata('unique_id') ?>"      
											data-theme.color="#0071bc"/>
										</script>   -->
									</form>
									<!--<button type="button" class="btn btn-success">Pay Now</button>-->
								</div>
							</div>                        
						</div>                    
					</div>
				</div>
			</div>
		</div>
	</section>


	<!-- disable input fields -->
	<script>
		/*
		$(document).ready(function(){
			$('input').attr('disabled',true);
			$('input').css("cursor","not-allowed");
		});
		*/

		// Checkout details as a json
		var options = <?php echo $json; ?>;

		/**
		 * The entire list of Checkout fields is available at
		 * https://docs.razorpay.com/docs/checkout-form#checkout-fields
		 */
		options.handler = function(response) {
		  document.getElementById('razorpay_payment_id').value = response.razorpay_payment_id;
		  document.getElementById('razorpay_signature').value = response.razorpay_signature;
		  document.razorpayform.submit();
		};

		// Boolean whether to show image inside a white frame. (default: true)
		options.theme.image_padding = false;

		options.modal = {
		  ondismiss: function() {
			console.log("This code runs when the popup is closed");
		  },
		  // Boolean indicating whether pressing escape key 
		  // should close the checkout form. (default: true)
		  escape: true,
		  // Boolean indicating whether clicking translucent blank
		  // space outside checkout form should close the form. (default: false)
		  backdropclose: false
		};

		var rzp = new Razorpay(options);

		document.getElementById('rzp-button1').onclick = function(e) {
		  rzp.open();
		  e.preventDefault();
		}
	</script>