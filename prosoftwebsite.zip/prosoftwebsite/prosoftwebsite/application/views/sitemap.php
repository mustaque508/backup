<Style>

.col-md-12 {
    position: relative;
    min-height: 1px;
    float: left;
    padding-right: 10px;
    padding-left: 10px
}

.product-main{
    margin-top: 130px;
    margin-bottom: 20px;
}

.pricing-table.active .pricing-top a.button { padding: 12px 30px; }

.pricing-content .pricing-table-list ul li { font-size: 14px; }
.pricing-content { width: 90%; }
.pricing-content .pricing-table-list ul li i { width: 18px; }


.pricing-table.boxed {  box-shadow: 0 0 40px rgba(0, 0, 0, 0.05); padding: 30px; margin-bottom:20px; border-top: 8px solid #0A3FFF; border-radius: 6px;  }
.pricing-table.boxed .pricing-top { box-shadow: none; border: 0; padding: inherit; border-radius: inherit; padding: 0; }
.pricing-table.boxed .pricing-content { width: inherit; margin:0 ; margin-top: 20px; }
.pricing-table.active.boxed { border-top: 16px solid #0071bc; box-shadow: 0 0 50px rgba(0, 0, 0, 0.05); }

</Style>
<!-- <section class=" white-bg">
  <div class="container">
    <div class="row padd-40">
      <div class="col-md-12">
        <div class="section-title text-center product-main">
          <h2 class="title-effect">SITEMAP</h2>
        </div>
      </div>
    </div>


     
                  <ul class="list list-arrow">

                  <li><a class="sitemap-list" href="<?php echo base_url(); ?>Home">Home</a>
                  <UL>
                  <li><a class="sitemap-list" href="#">Know More</a></li>
                  <li><a class="sitemap-list" href="<?php echo base_url(); ?>ContactUs">Contact Us</a></li>
                  <li><a class="sitemap-list" href="<?php echo base_url(); ?>UserInfo?edition=TRIAL">Start Free Trial</a></li>
                    <li><a class="sitemap-list" href="<?php echo base_url(); ?>UserInfo?edition=LITE">Buy Now</a></li>
                  </UL>

                  </li>
                    <li><a class="sitemap-list" href="<?php echo base_url(); ?>AboutUs">Company</a>
                    <ul> <li><a class="sitemap-list" href="<?php echo base_url(); ?>dist/profile/Prosoft_Corporate_Profile.pdf">Download Corporate Profile </a></li></ul>
                    </li>

                    <li><a class="sitemap-list" href="<?php echo base_url(); ?>Productc/c5cdr">Products</a>
                    <ul>
                    <li><a class="sitemap-list" href="<?php echo base_url(); ?>Productc/c5cdr">C5 CDR Analyzer</a>
                    <ul><li><a class="sitemap-list" href="<?php echo base_url(); ?>dist/profile/C5_CDR_Analyzer_Brochure.pdf">Download Brochure</a></li>
                    <li><a class="sitemap-list" href="<?php echo base_url(); ?>ContactUs">Contact Us</a></li>
                    <li><a class="sitemap-list" href="<?php echo base_url(); ?>UserInfo?edition=TRIAL">Start Free Trial</a></li>
                    <li><a class="sitemap-list" href="<?php echo base_url(); ?>UserInfo?edition=LITE">Buy Now</a></li>
                    </ul>
                    </ul>
                    </li>
                    </li>
                    <li><a class="sitemap-list" href="<?php echo base_url(); ?>ContactUs">Contact Us</a></li>
                    <li><a class="sitemap-list" href="<?php echo base_url(); ?>UserInfo?edition=TRIAL">Start Free Trial</a></li>
                  </ul>
              </div>
     

   
</section> -->



<section class=" white-bg">
  <div class="container">
    <div class="row padd-40">
      <div class="col-md-12">
        <div class="section-title text-center product-main">
          <h2 class="title-effect">SITEMAP</h2>
        </div>
      </div>
    </div>
    
    <div class="row">
      <div class="col-lg-6 col-md-6 mb-60">
        <div class="pricing-table boxed">
           <div class="pricing-top">
             <div class="pricing-title">
            
               <h3 href="index.php">Home</h3>
               <div class="pricing-table-list">
                  <ul class="list list-arrow"> 
                      <li>
                        <a class="sitemap-list" href="<?php echo base_url(); ?>Home">Home</a> 
                      </li>
                    <!-- <li><a class="sitemap-list" href="#">Know More</a></li>
                  <li><a class="sitemap-list" href="<?php echo base_url(); ?>ContactUs">Contact Us</a></li>
                  <li><a class="sitemap-list" href="<?php echo base_url(); ?>UserInfo?edition=TRIAL">Start Free Trial</a></li>
                    <li><a class="sitemap-list" href="<?php echo base_url(); ?>UserInfo?edition=LITE">Buy Now</a></li> -->
                  </ul>
              </div>
             </div>
           </div>
        </div>
      </div>

      <div class="col-lg-6 col-md-6 mb-60">
        <div class="pricing-table boxed">
           <div class="pricing-top">
             <div class="pricing-title">
               <h3 >Company</h3>
               <div class="pricing-table-list">
                  <ul class="list list-arrow">
                  <li><a class="sitemap-list" href="<?php echo base_url(); ?>AboutUs">Company</a> </li>
                     <!-- <li><a class="sitemap-list" href="<?php echo base_url(); ?>dist/profile/Prosoft_Corporate_Profile.pdf">Download Corporate Profile </a></li> -->
                  </ul>
              </div>
             </div>
           </div>
        </div>
      </div>
    <!-- </div>

    <div class="row"> -->
      <div class="col-lg-6 col-md-6 mb-60">
        <div class="pricing-table boxed">
          <div class="pricing-top">
            <div class="pricing-title">
              <h3 >Products</h3>
              <div class="pricing-table-list">
                <ul class="list list-arrow">
                <!-- <li><a class="sitemap-list" href="<?php echo base_url(); ?>Product/c5cdr">Products</a></li> -->
                <li><a class="sitemap-list" href="<?php echo base_url(); ?>Product/c5cdr">C5 CDR Analyzer</a></li>
                <li><a class="sitemap-list" href="<?php echo base_url(); ?>Product/c5fa">C5 Financial Analytics</a></li>
                <li><a class="sitemap-list" href="<?php echo base_url(); ?>Product/healthsoft">HealthSoft</a></li>
                <li><a class="sitemap-list" href="<?php echo base_url(); ?>Product/erp">Enterprise Resource Planning</a></li>
                <li><a class="sitemap-list" href="<?php echo base_url(); ?>Product/fms">Fleet Management</a></li>
                
                <!-- <ul><li><a class="sitemap-list" href="<?php echo base_url(); ?>dist/profile/C5_CDR_Analyzer_Brochure.pdf">Download Brochure</a></li>
                    <li><a class="sitemap-list" href="<?php echo base_url(); ?>ContactUs">Contact Us</a></li>
                    <li><a class="sitemap-list" href="<?php echo base_url(); ?>UserInfo?edition=TRIAL">Start Free Trial</a></li>
                    <li><a class="sitemap-list" href="<?php echo base_url(); ?>UserInfo?edition=LITE">Buy Now</a></li>
                    </ul> -->
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-lg-6 col-md-6 mb-60">
        <div class="pricing-table boxed">
          <div class="pricing-top">
            <div class="pricing-title">
              <h3>Contact Us</h3>
              <div class="pricing-table-list">
                <ul class="list list-arrow">
                <li><a class="sitemap-list" href="<?php echo base_url(); ?>ContactUs">Contact Us</a></li>
                </ul>
              </div>
              <br>
              <br>
              <br>
              <br>
              <!-- <h3>Start Free Trial</h3>
              <div class="pricing-table-list">
                <ul class="list list-arrow">
                <li><a class="sitemap-list" href="<?php echo base_url(); ?>UserInfo?edition=TRIAL">Start Free Trial</a></li>
                </ul>
              </div> -->
            </div>
          </div>
        </div>
      </div>

      <div class="col-lg-6 col-md-6 mb-60">
        <div class="pricing-table boxed">
           <div class="pricing-top">
             <div class="pricing-title">
            
               <h3 href="index.php">Miscellaneous</h3>
               <div class="pricing-table-list">
                  <ul class="list list-arrow"> 
                      <li>
                        <a class="sitemap-list" href="<?php echo base_url(); ?>FAQ">FAQs</a> 
                      </li>
                  </ul>
                  <ul class="list list-arrow"> 
                      <li>
                        <a class="sitemap-list" href="<?php echo base_url(); ?>Policy/privacy_policy">Privacy Policy</a> 
                      </li>
                  </ul>
                  <ul class="list list-arrow"> 
                      <li>
                        <a class="sitemap-list" href="<?php echo base_url(); ?>Policy/cookie_policy">Cookie Policy</a> 
                      </li>
                  </ul>
              </div>
             </div>
           </div>
        </div>
      </div>


    </div>
  </div>
</section>

<!-- <section class=" white-bg">
  <div class="container">
    <div class="row padd-40">
      <div class="col-md-12">
        <div class="section-title text-center product-main">
          <h2 class="title-effect">SITEMAP</h2>
        </div>
      </div>
    </div>
    
    <div class="row">
      <div class="col-lg-6 col-md-6 mb-60">
        <div class="pricing-table boxed">
           <div class="pricing-top">
             <div class="pricing-title">
               <h3 class="mb-15">Links</h3>
               <div class="pricing-table-list">
                  <ul class="list list-arrow">
                    <li><a class="sitemap-list" href="index.php">Home</a></li>
                    <li><a class="sitemap-list" href="about.php">Company</a></li>
                    <li><a class="sitemap-list" href="career.php">Products</a></li>
                    <li><a class="sitemap-list" href="contact.php">Contact Us</a></li>
                  </ul>
              </div>
             </div>
           </div>
        </div>
      </div>

      <div class="col-lg-6 col-md-6 mb-60">
        <div class="pricing-table boxed">
           <div class="pricing-top">
             <div class="pricing-title">
               <h3 class="mb-15">Products & Services</h3>
               <div class="pricing-table-list">
                  <ul class="list list-arrow">
                    <li><a class="sitemap-list" href="C5-CDR-Analyzer.php">C5 CDR Analyzer</a></li>
                    <li><a class="sitemap-list" href="C5-CDR-Analyzer-Lite.php">C5 CDR Analyzer Lite</a></li>
                    <li><a class="sitemap-list" href="Financial-Analytics.php">Financial Analytics</a></li>
                    <li><a class="sitemap-list" href="HealthSoft.php">HealthSoft</a></li>
                    <li><a class="sitemap-list" href="ERP.php">Enterprise Resource Planning</a></li>
                    <li><a class="sitemap-list" href="FleetInfo.php">Fleet Management</a></li>
                    <li><a class="sitemap-list" href="payroll.php">Payroll</a></li>
                  </ul>
              </div>
             </div>
           </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-6 col-md-6 mb-60">
        <div class="pricing-table boxed">
          <div class="pricing-top">
            <div class="pricing-title">
              <h3 class="mb-15">Products</h3>
              <div class="pricing-table-list">
                <ul class="list list-arrow">
                  <li><a class="sitemap-list" href="support/admin/index.php">Login</a></li>
                  <li><a class="sitemap-list" href="free-trial.php">Start Free Trial</a></li>
                  <li><a class="sitemap-list" href="enterprise-plus.php">Buy C5 CDR Analyzer - Enterprise Edition Plus</a></li>
                  <li><a class="sitemap-list" href="enterprise_form.php">Buy C5 CDR Analyzer - Enterprise Edition</a></li>
                  <li><a class="sitemap-list" href="cdr_lite_form.php">Buy C5 CDR Analyzer - Lite</a></li>
                  <li><a class="sitemap-list" href="professional_cdr.php">Buy C5 CDR Analyzer - Professional Edition</a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-lg-6 col-md-6 mb-60">
        <div class="pricing-table boxed">
          <div class="pricing-top">
            <div class="pricing-title">
              <h3 class="mb-15">Profile / Brochure</h3>
              <div class="pricing-table-list">
                <ul class="list list-arrow">
                  <li><a class="sitemap-list" href="profile/Prosoft_Profile.pdf" target="_blank">Download Our Profile</a></li>
                  <li><a class="sitemap-list" href="profile/C5_CDR_Analyzer_Brochure.pdf" target="_blank">Download C5 CDR Analyzer Brochure</a></li>
                </ul>
              </div>
              <br>
              <h3 class="mb-15">C5 CDR Analyzer - Terms and Conditions</h3>
              <div class="pricing-table-list">
                <ul class="list list-arrow">
                  <li><a class="sitemap-list" href="profile/C5_CDR_Analyzer_(Desktop)_Terms&Conditions.pdf" target="_blank">Desktop Application</a></li>
                  <li><a class="sitemap-list" href="profile/C5_CDR_Analyzer_(Android)_Terms&Conditions.pdf" target="_blank">Android Application</a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section> -->