
    <section class="ftco-section bg-light">
    	<div class="container">
    		
    		<div class="row">				
				<div class="col-md-12 align-items-center ftco-animate">            
					<div class="tab-content ftco-animate" id="v-pills-tabContent">
						<div class="tab-pane fade show active" id="v-pills-nextgen" role="tabpanel" aria-labelledby="v-pills-nextgen-tab">
              				<div class="d-md-flex">	              				
	              				<div class="one-half ml-md-5 align-self-center">
									<h1 class="mb-4" style="color:Tomato; border:2px solid green;">This page is under construction.</h1>
		              				<!--<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.</p>
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt voluptate, quibusdam sunt iste dolores consequatur</p>
									<p><a href="#" class="btn btn-primary py-3">Get in touch</a></p>-->
								</div>
								<div class="one-forth align-self-center">
	              					<img src="<?php echo base_url(); ?>dist/img/undraw_laravel_and_vue_59tp.svg" class="img-fluid" alt="">
	              				</div>
							</div>
						</div>	
					</div>
				</div>
			</div>
        </div>
    </section>