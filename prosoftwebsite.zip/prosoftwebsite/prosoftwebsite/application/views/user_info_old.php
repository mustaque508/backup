  
	<section class="ftco-section contact-section ftco-degree-bg">
    <div class="container">
      <div class="row mb-12 pb-5 align-items-center d-flex">    
			  <div class="col-md-6">
          <div class="heading-section heading-section-black ftco-animate">
            <!--<span id="spanID" class="subheading">Get an easy quote</span>-->
            <h2 style="font-size: 30px;"><?php echo $this->session->userdata('edition')?> Edition</h2>
          </div>
        </div>
      </div>
      <div class="row mb-12 pb-5 d-flex">    
			  <div class="col-md-6">
          <div class="heading-section heading-section-black ftco-animate">
            <?php if ($this->session->userdata('edition') == "TRIAL"){ echo "<br><br><h2 style='font-size: 30px;'>Try C5 CDR Analyzer, FREE for 30 Days.</h2><br><br><h4 style='font-size: 30px;'>Join thousands of investigating officers  using C5 CDR Analyzer to unleash to power of data analytics.</h4>"; } else { echo "<h4 style='font-size: 30px;'>A great edition for Investigation officers looking to take their data analytics skills to the next level.</h4>"; } ?>            
          </div>
        </div>
    
        <div class="col-md-6">          
          <form role="form" id="checkout-selection" action="<?php echo base_url();?>index.php/UserInfo/submit" method="post">
            <div class="form-group">
              <p style="color: red;"><?php echo $error;?></p>
            </div>            
            <div class="form-group">
              <input type="text" class="form-control" placeholder="Full Name*" name="f_name" id="f_name" value="<?php echo $this->session->userdata('f_name');?>" required>
              <span style="color: red; font-size:small;"><?php echo $f_name_error;?></span>
            </div>
            <div class="form-group">
              <input type="text" class="form-control" placeholder="Contact No*" name="f_contact" id="f_contact" value="<?php echo $this->session->userdata('f_contact');?>" required>
              <span style="color: red; font-size:small;"><?php echo $f_contact_error;?></span>
            </div>
            <div class="form-group">
              <input type="text" class="form-control" placeholder="Department Email-ID*" name="f_email" id="f_email" value="<?php echo $this->session->userdata('f_email');?>" required>
              <span style="color: red; font-size:small;"><?php echo $f_email_error;?></span>
            </div>
    
            <div class="row md-6">
              <div class="col-md-6">
                <div class="form-group">
                <input type="text" class="form-control" placeholder="Department*" name="f_department" id="f_department" value="<?php echo $this->session->userdata('f_department');?>" required>
                <span style="color: red; font-size:small;"><?php echo $f_department_error;?></span>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                <input type="text" class="form-control" placeholder="Designation" name="f_designation" id="f_designation" value="<?php echo $this->session->userdata('f_designation');?>">
                </div>
              </div>
            </div>
    
            <div class="form-group">
              <textarea cols="30" rows="7" class="form-control" placeholder="Address" name="f_address" id="f_address" value="<?php echo $this->session->userdata('f_address');?>"></textarea>
            </div>
            
            <input type="checkbox" name="terms" id="terms" required>
            <label>
              I agree with the <a href="#" onclick="return false;">terms and conditions</a>.
            </label>

            <div class="form-group">
              <div class="g-recaptcha" data-sitekey="6Ldtzb4UAAAAAGnBmlLGQjPansZXAGZu4Bd1j8-I"></div>
            </div>
            
            <div class="form-group">
              <?php /* if ($edition == "LITE") {
                require_once(APPPATH . 'third_party/razorpay-php/config.php');
                require_once(APPPATH . 'third_party/razorpay-php/Razorpay.php');
              ?>
                <style>
                  .razorpay-payment-button {
                    color: #ffffff !important;
                    background-color: #0071bc;
                    border-color: #7266ba;
                    font-size: 16px;
                    padding: 20px;
                    display: block;
                    max-width: 300px;
                    margin: auto;
                    }
                    .razorpay-payment-button:hover {
                    color: #ffffff !important;
                    background-color: #0071bcc4;
                    border-color: #7266ba;
                    font-size: 16px;
                    padding: 20px;
                    display: block;
                    max-width: 300px;
                    margin: auto;
                    margin-top: -2px;
                    }
                </style>
                
                <script
                    src="https://checkout.razorpay.com/v1/checkout.js"
                    data-key="<?php echo $keyId; ?>"
                    data-amount="<?php echo 100000; ?>"
                    data-buttontext="Pay with Razorpay"
                    data-name="Prosoft e-Solutions"
                    data-description="Transaction with Razorpay"
                    data-image="img/logo/favicon-black.png"
                    data-prefill.name="Full Name"
                    data-prefill.email="info@prosoftesolutions.com"
                    data-theme.color="#0071bc">
                    <input type="hidden" value="Hidden Element" name="hidden">
                </script>                  
              <?php } else { */ ?>
                <button name="submit" type="submit" value="Send" class="btn btn-primary py-3 px-5"> Submit </button>                  
              <?php //} ?>
              <!--onclick="onSubmitFormClick();"-->
            </div>
          </form>        
        </div>
      </div>		
    </div>
  </section>
	
