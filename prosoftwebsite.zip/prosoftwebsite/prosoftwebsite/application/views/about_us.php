<div class="hero-wrap js-fullheight">
    <div class="container-fluid px-0">
        <div class="row d-md-flex no-gutters slider-text align-items-center js-fullheight justify-content-end">
            <div class="one-forth d-flex align-self-end ftco-animate js-fullheight mt-5">
                <div class="text mt-5">
                    <p class="breadcrumbs mb-0"><span><a href="<?php echo base_url();?>index.php/Home"> Home <i
                                        class="ion-ios-arrow-forward"></i></a></span> Company </p>
                    <h1 class="mb-3">Prosoft<span>e-Solutions</span></h1>
                    <p>Is a research based software development company committed to delivering world class software and
                        enterprise solutions.</p>
                    <p><a href="<?php echo base_url(); ?>dist/profile/Prosoft_Corporate_Profile.pdf" target="_blank"
                        class="btn px-4 py-3 text-light button-color btn-primary">Download Corporate Profile</a></p>
                </div>
            </div>
            <img class="one-third js-fullheight align-self-end order-md-last img-fluid"
                src="<?php echo base_url(); ?>dist/img/Company.svg" alt="Company-svg">
        </div>
    </div>
</div>

<section class="ftco-section ftco-no-pt ftc-no-pb flaticon-section mt-5">
    <div class="container">
        <div class="row justify-content-center mb-2 pb-3">
            <div class="col-md-7 text-center heading-section ftco-animate">
                <h2 class="mb-4 mt-4">Our Story</h2>
            </div>
        </div>

        <div class="row ftco-animate">
            <div class="col-md-4 text-center ">
                <img class="img-fluid" style="width:220px;height:220px;"
                    src="<?php echo base_url(); ?>dist/img/products/ourStory.svg" alt="Big Data.svg" />
            </div>
            <div class="col-md-8 text-justify ftco-animate">
                <p class="h5">
                    Founded by 3 technology and business entrepreneurs in 2000, backed by amazing teams of talented
                    individuals, our journey is that of growth and tremendous technological integrations.
                </p>
                <p class="h5 mt-3">
                    We at Prosoft, an ISO 9001:2015 certified company, develop and build telecommunication data
                    analytics solutions for Law Enforcement Agencies in India and around the world, among other
                    organizational software. We have been at the developmental forefront of CDR data analytics for over
                    a decade.
                </p>


            </div>
            <div class="container ">
                <div class="md-7 text-justify">
                    <p class="h5 mt-3">
                        With 1000+ clients, including some of the elite Indian Law Enforcement Agencies such as NIA, CID,
                        ED, ACB, Income Tax and all of the CBI branches throughout India utilize our applications to carry
                        out their respective investigative analysis.
                    </p>
                    <p class="h5 mt-3">
                        Prosoft offers IT services comprising of application development, application maintenance, data
                        maintenance and much more. Experience high performing, intuitive and quality software experience
                        with us.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="ftco-section ftco-no-pt ftc-no-pb flaticon-section">
    <div class="container">
        <div class="row justify-content-center mb-2 pb-3">
            <div class="col-md-7 text-center heading-section ftco-animate">
                <h2 class="mb-4">Milestone</h2>
                <!-- <p class="h5">Information Superhighway For Healthcare</p> -->
            </div>
        </div>

        <div class="row flaticon-row">
            <!-- ISO -->
            <div class="col-md-6 d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services d-flex align-items-center">
                    <div class="icon d-flex align-items-center justify-content-center order-md-last">
                        <span class="flaticon-achievement"></span>
                    </div>
                    <div class="media-body pl-4 pl-md-0 pr-md-4 text-md-right">
                        <h3 class="heading">International Organization for Standardization</h3>
                        <p>
                            Prosoft is an ISO 9001:2015 certified company
                        </p>
                    </div>
                </div>
            </div>

            <!-- DSCI -->
            <div class="col-md-6 d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services d-flex align-items-center">
                    <div class="icon d-flex align-items-center justify-content-center">
                        <span class="flaticon-diploma"></span>
                    </div>
                    <div class="media-body pl-4">
                        <h3 class="heading">DSCI - NASSCOM</h3>
                        <p class="mb-0">
                            We are associated with DSCI and regularly participate in Cybercrime Awareness Workshops held
                            all across India to educate Law Enforcement personnel to deal with modern day crime
                            scenarios.
                        </p>
                    </div>
                </div>
            </div>

            <!-- WORKSHOP -->
            <div class="col-md-6 d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services d-flex align-items-center">
                    <div class="icon d-flex align-items-center justify-content-center order-md-last">
                        <span class="flaticon-family"></span>
                    </div>
                    <div class="media-body pl-4 pl-md-0 pr-md-4 text-md-right">
                        <h3 class="heading">Workshops</h3>
                        <p>
                        We’ve had the honour to exchange ideas and train I.Os with various Law Enforcement Agencies across the county such as NEPA, SVP, CID and many more. These workshops are and excellent opportunity to carry out Capacity Building Excercise. It also helps us understand what investigators essentially need from their application.
                        </p>
                    </div>
                </div>
            </div>

            <!-- NEWS -->
            <div class="col-md-6 d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services d-flex align-items-center">
                    <div class="icon d-flex align-items-center justify-content-center">
                        <span class="flaticon-news"></span>
                    </div>
                    <div class="media-body pl-4">
                        <h3 class="heading">In the News</h3>
                            <p class="mb-0">
                                •	The Times of India - 2009
                                <br>
                                •	The Indian Express - 2013
                                <br>
                                •	Dainik Bhaskar - 2015
                            </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="ftco-section testimony-section flaticon-section">
    <div class="container Con">
        <div class="row justify-content-center mb-5 pb-3">
            <div class="col-md-7 text-center heading-section ftco-animate">
                <h2 class="mb-0">Who we are</h2>
                <!-- <p class="h5">We add value to your organization by our domain expertise and capability to handle big
                    data.</p> -->
            </div>
        </div>

        <div class="row flaticon-row">



            <!-- OUR MISSION -->
            <div class="col-md-6 d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services d-flex align-items-center">
                    <div class="icon d-flex align-items-center justify-content-center order-md-last">
                        <span class="flaticon-goals"></span>
                    </div>
                    <div class="media-body pl-4 pl-md-0 pr-md-4 text-md-right">
                        <h3 class="heading">Our Mission</h3>
                        <p>Our mission is to empower Law Enforcement Agencies take swift and insightful decisions by
                            unleashing the power of data analytics.</p>
                    </div>
                </div>
            </div>

            <!-- OUR VISION -->
            <div class="col-md-6 d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services d-flex align-items-center">
                    <div class="icon d-flex align-items-center justify-content-center">
                        <span class="flaticon-visionary"></span>
                    </div>
                    <div class="media-body pl-4">
                        <h3 class="heading">Our Vision</h3>
                        <p class="mb-0">Our Vision is to provide excellent software solutions at affordable prices to
                            all forms of businesses, to help grip the operations with ease and expand their business by
                            using the latest software technology.</p>
                    </div>
                </div>
            </div>

            <!-- VALUES -->
            <div class="col-md-6 d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services d-flex align-items-center">
                    <div class="icon d-flex align-items-center justify-content-center order-md-last">
                        <span class="flaticon-loyalty"></span>
                    </div>
                    <div class="media-body pl-4 pl-md-0 pr-md-4 text-md-right">
                        <h3 class="heading">Our Values</h3>
                        <p>In pursuit of our purpose of delivering high class innovative products, we create an
                            environment of innovation and learning while continuously reaching for the highest level of
                            excellence.</p>
                    </div>
                </div>
            </div>

            <!-- CUSTOMER CENTRIC APPROACH -->
            <div class="col-md-6 d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services d-flex align-items-center">
                    <div class="icon d-flex align-items-center justify-content-center">
                        <span class="flaticon-group"></span>
                    </div>
                    <div class="media-body pl-4">
                        <h3 class="heading">Customer Centric Approach</h3>
                        <h5>
                            <p>We engage with our customers at every level of product development so our customers are
                                not only involved in product development but actually shape how a specific feature
                                works.</p>
                        </h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="ftco-section bg-lighter">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-7 text-center heading-section ftco-animate">
                <h2>What we do</h2>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-8 py-5">
                <div class="heading-section ftco-animate">
                    <div class="block-fa bg-accent text-justify">
                        <div class="media-bodyfa bg-accent pl-5 pr-5 pt-5 pb-5">
                            <p class="h5 text-light">
                                At Prosoft we service a wide range of Industry verticals and technology platforms. 
                                We offer a full spectrum of technology services and help our clients harness emerging 
                                potential of newer technologies, and at the same time making the most out of legacy IT.
                                We transform client’s insight into actual products and services with the most 
                                suited technologies.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 py-5 mt-2 justify-content-center">
                <div class="row">
                    <div class="ftco-animate">
                        <div class="ml-3">
                            <ul class="list-unstyled">

                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Web application & RIAs
                                </li>
                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Android / iOS Apps 
                                </li>    
                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                    Desktop application development
                                </li>
                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                        UI interfaces, databases 
                                </li>
                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                        Server website integration 
                                </li>
                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                        Cross-platform development 
                                </li>                                
                                <li class="h6">
                                    <img src="<?php echo base_url();?>dist/img/edition/rightmark.svg"
                                        alt="rightmark svg">
                                        Mobile Web Apps
                                </li>     
 
                              </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
          <div class="col-lg-12">
              <p class="h5">
                Based on Agile development methodology, continuous integrations each having its own Design, Development and 
                Testing cycle. Our Agile process enables to deliver you solutions faster, with less need for detailed 
                documentation, i.e. for less investment costs and with shorter time-to-market. 
              </p>
          </div>
        </div>

    </div>
</section>

<!-- <section class="leader-section ftco-section flaticon-section">
    <div class="row justify-content-center mb-2 pb-3">
        <div class="col-md-7 text-center heading-section ftco-animate">
            <h2 class="mb-4">Meet Our Team</h2>
        </div>
    </div>
    <div class="container leader-container">
        <div class="row flaticon-row">
            <div class="ftco-animate">
                <div class="card lcard leader-card">
                    <div class="card-body">
                        <div class="steps text-center justify-content-center align-items-center">
                            <div class="icon mb-4 mt-4 d-flex justify-content-center align-items-center bg-lighter">

                                <span>
                                <img class="one-third js-fullheight align-self-end order-md-last img-fluid" style="width:56px;height:56px;"
                                    src="<?php echo base_url(); ?>dist/img/team/md.svg" alt="">
                                    </span>
                            </div>
                            <h5>Mr. Saleem Landur</h5>
                            <h6>Director</h6>
                            <p class="text-justify" style="font-size:13px;">
                                Has always been fascinated with entrepreneurship and he sets strategic direction for the
                                company while nurturing a strong leadership team to drive its execution.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="ftco-animate">
                <div class="card lcard leader-card">
                    <div class="card-body">
                        <div class="steps text-center justify-content-center align-items-center">
                            <div class="icon mb-4 mt-4 d-flex justify-content-center align-items-center bg-lighter">

                                <span>
                                <img class="one-third js-fullheight align-self-end order-md-last img-fluid" style="width:56px;height:56px;"
                                    src="<?php echo base_url(); ?>dist/img/team/ceo.svg" alt="">
                                    </span>
                            </div>
                            <h5>Mr. Mohsin Dhalayat</h5>
                            <h6>Director</h6>
                            <p class="text-justify" style="font-size:13px;">
                                Discovers and implements new technologies that yield competitive advantage. He also
                                develops
                                technical aspects of the company’s strategy to ensure alignment with its business goals.
                                In this
                                role he supervises system infrastructure to ensure functionality and efficiency. He
                                leads
                                Prosoft in being a global organization, across all industry segments, in emerging
                                technology
                                solutions and business intelligence.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="ftco-animate">
                <div class="card lcard leader-card">
                    <div class="card-body">
                        <div class="steps text-center justify-content-center align-items-center">
                            <div class="icon mb-4 mt-4 d-flex justify-content-center align-items-center bg-lighter">

                                <span>
                                <img class="one-third js-fullheight align-self-end order-md-last img-fluid" style="width:56px;height:56px;"
                                    src="<?php echo base_url(); ?>dist/img/team/cfo.svg" alt="">
                                    </span>
                            </div>
                            <h5>Mr. Rafiq Ahmed Betgeri</h5>
                            <h6>Director</h6>
                            <p class="text-justify" style="font-size:13px;">
                                Drives the financial planning of the company by analysing its performance and risks. He
                                oversees
                                key function across the company including corporate taxation, risk management and
                                investors
                                relation. He is also responsible for implementing operational priorities in line with
                                overall
                                business objectives and oversee all audit and internal control operations.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container leader-container mt-3">
        <div class="row flaticon-row">
            <div class="ftco-animate">
                <div class="card lcard-team leader-card-team">
                    <div class="card-body">
                        <div class="steps text-center justify-content-center align-items-center">
                            <div class="icon mb-4  d-flex justify-content-center align-items-center bg-lighter">

                                <span>
                                <img class="one-third js-fullheight align-self-end order-md-last img-fluid" style="width:56px;height:56px;"
                                    src="<?php echo base_url(); ?>dist/img/team/sales.svg" alt="">
                                    </span>
                            </div>
                            <h5>Mr. Kapil Nagaich</h5>
                            <h6>Country Sales Manager</h6>
                            <p class="text-justify" style="font-size:13px;">
                                Has over eight year of experience in business development and marketing. He is excited by the transformative power of new technologies playing a vital role in crime investigation and prevention.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="ftco-animate">
                <div class="card lcard-team leader-card-team">
                    <div class="card-body">
                        <div class="steps text-center justify-content-center align-items-center">
                            <div class="icon mb-4  d-flex justify-content-center align-items-center bg-lighter">

                                <span>
                                <img class="one-third js-fullheight align-self-end order-md-last img-fluid" style="width:56px;height:56px;"
                                    src="<?php echo base_url(); ?>dist/img/team/devLead.svg" alt="">
                                    </span>
                            </div>
                            <h5>Mr. Irshad Mujawar</h5>
                            <h6>Lead - Software Development</h6>
                            <p class="text-justify" style="font-size:13px;">
                                Oversees operational feasibility by evaluating analysis, problem definition requirement solution development and proposed solution. He also improves operation by conducting system analysis, recording changes in policies and procedures.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="ftco-animate">
                <div class="card lcard-team leader-card-team">
                    <div class="card-body">
                        <div class="steps text-center justify-content-center align-items-center">
                            <div class="icon mb-4 d-flex justify-content-center align-items-center bg-lighter">

                                <span>
                                <img class="one-third js-fullheight align-self-end order-md-last img-fluid" style="width:56px;height:56px;"
                                    src="<?php echo base_url(); ?>dist/img/team/supportLead.svg" alt="">
                                    </span>
                            </div>
                            <h5>Mr. Amit Kadkol </h5>
                            <h6>Lead - Technical Support Engineer</h6>
                            <p class="text-justify" style="font-size:13px;">
                                Diagnoses and troubleshoots technical issues, including account setup and network configuration. He talks clients through a series of actions, either via phone, email or chat, until they’ve solved a technical issue.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="ftco-animate">
                <div class="card lcard-team leader-card-team">
                    <div class="card-body">
                        <div class="steps text-center justify-content-center align-items-center">
                            <div class="icon mb-4  d-flex justify-content-center align-items-center bg-lighter">

                                <span>
                                <img class="one-third js-fullheight align-self-end order-md-last img-fluid" style="width:56px;height:56px;"
                                    src="<?php echo base_url(); ?>dist/img/team/content.svg" alt="">
                                    </span>
                            </div>
                            <h5>Mr. Zubair Khan </h5>
                            <h6>Lead - Content Strategist</h6>
                            <p class="text-justify" style="font-size:13px;">
                                Uses data, research and his understanding of psychology to shape the Prosoft narrative and create content experiences tailored to the company’s audience. He oversees content requirements and creates content strategy deliverables across a project life cycle.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</section> -->