<div class="hero-wrap js-fullheight">
    <div class="overlay"></div>
    <div class="container-fluid px-0">
      <div class="row d-md-flex no-gutters slider-text align-items-center js-fullheight justify-content-end">
        <img class="one-third js-fullheight align-self-end order-md-last img-fluid mt-5" src="<?php echo base_url(); ?>dist/img/faqs.svg" alt="faqs.svg">
        <div class="one-forth d-flex align-items-center ftco-animate js-fullheight">
          <div class="text mt-5">
            <!-- <p class="breadcrumbs mb-0"><span><a href="<?php echo base_url();?>index.php/Home">FAQ<i class="ion-ios-arrow-forward"></i></a></span>Company</p> -->
            <h1 class="mb-3">Frequently Asked Questions</h1>
            <!-- <p>Add some text here....</p> -->
          </div>
        </div>
      </div>
    </div>
</div>

<section class="ftco-section bg-light">
    <div class="container">
        <div class="row justify-content-center mb-5">
            <div class="col-md-7 text-center heading-section ftco-animate">
                <h2 class="mb-4">FAQs</h2>
                <!-- <p class="h5">add some text here........</p> -->
            </div>
        </div>
        <!-- GENEREAL -->
        <div class="row">
                    <div class="col-md-12  faq-heading ftco-animate">
                        <h2 class="mb-4">General</h2>
                    </div>
                

            <div class="col-md-12 ftco-animate">
                <div id="accordion">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <a class="card-link" data-toggle="collapse" href="#menuone" aria-expanded="true"
                                        aria-controls="menuone">Is C5 CDR Analyzer for anyone? <span class="collapsed"><i
                                                class="ion-ios-arrow-up"></i></span><span class="expanded"><i
                                                class="ion-ios-arrow-down"></i></span></a>
                                </div>
                                <div id="menuone" class="collapse show">
                                    <div class="card-body text-justify">
                                        <p>
                                            A: No, the application is not intended for general public use. It’s
                                            specifically designed for Law Enforcement Agencies (LEA) who have clearance 
                                            to carry out CDR Analysis.
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <div class="card">
                                <div class="card-header">
                                    <a class="card-link" data-toggle="collapse" href="#menutwo" aria-expanded="false"
                                        aria-controls="menutwo">Is it available worldwide?<span
                                            class="collapsed"><i class="ion-ios-arrow-up"></i></span><span
                                            class="expanded"><i class="ion-ios-arrow-down"></i></span></a>
                                </div>
                                <div id="menutwo" class="collapse">
                                    <div class="card-body text-justify">
                                        <p>
                                            A: Currently the application is optimized to work in India, Nepal, Bangladesh,
                                            Togo and Malaysia. We’ll be adding support for more countries in the future.
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <div class="card">
                                <div class="card-header">
                                    <a class="card-link" data-toggle="collapse" href="#menuthree" aria-expanded="false"
                                        aria-controls="menuthree">Does Prosoft provide the Call Detail records or SDR data? <span class="collapsed"><i
                                                class="ion-ios-arrow-up"></i></span><span class="expanded"><i
                                                class="ion-ios-arrow-down"></i></span></a>
                                </div>
                                <div id="menuthree" class="collapse">
                                    <div class="card-body text-justify">
                                        <p>
                                            A: No, only Law Enforcement Agencies can request for the required CDR,
                                            TDR and SDR data to the telecom service providers through pre-approved channels.
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <div class="card">
                                <div class="card-header">
                                    <a class="card-link" data-toggle="collapse" href="#menufour" aria-expanded="false"
                                        aria-controls="menufour">What are your Cookie and Privacy policies?<span
                                            class="collapsed"><i class="ion-ios-arrow-up"></i></span><span
                                            class="expanded"><i class="ion-ios-arrow-down"></i></span></a>
                                </div>
                                <div id="menufour" class="collapse">
                                    <div class="card-body text-justify">
                                        <p>
                                            A:Here are our <a href="<?php echo base_url(); ?>Policy/privacy_policy" target="_blank">Privacy Policy</a> & 
                                            <a href="<?php echo base_url(); ?>Policy/cookie_policy" target="_blank">Cookie Policy</a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <!-- PAYMENTS -->
        <div class="row mt-5">
            <div class="col-md-7 faq-heading  ftco-animate">
                <h2 class="mb-4">Payment</h2>
            </div>

            <div class="col-md-12 ftco-animate">
                <div id="accordion">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                   
                                <a class="card-link" data-toggle="collapse" href="#menufive" aria-expanded="false"
                                        aria-controls="menufive">How do I check the status of my payment? <span
                                            class="collapsed"><i class="ion-ios-arrow-up"></i></span><span
                                            class="expanded"><i class="ion-ios-arrow-down"></i></span></a>
                                </div>
                                <div id="menufive" class="collapse">
                                    <div class="card-body text-justify">
                                        <p>
                                            A: Upon a successful transaction, you will receive a confirmation email 
                                            from Razorpay. We only have a payment gateway and only facilitate you with
                                            online payments for our products on our website.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="card">
                                <div class="card-header">
                                    <a class="card-link" data-toggle="collapse" href="#menusix" aria-expanded="false"
                                        aria-controls="menusix">I made a payment and it failed, but the money got debited. <span
                                            class="collapsed"><i class="ion-ios-arrow-up"></i></span><span
                                            class="expanded"><i class="ion-ios-arrow-down"></i></span></a>
                                </div>
                                <div id="menusix" class="collapse">
                                    <div class="card-body text-justify">
                                        <p>
                                            A: If you have not received a mail confirmation and the payment has failed, 
                                            the amount will be auto-refunded to you within 7 days (from the transaction date).
                                            If you don't receive the refund credit in 7 days, raise a request here and we will get 
                                            back to you at the earliest.
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <div class="card">
                                <div class="card-header">
                                    <a class="card-link" data-toggle="collapse" href="#menuseven" aria-expanded="false"
                                        aria-controls="menuseven">My card details are saved on Razorpay. How do I remove it? <span class="collapsed"><i
                                                class="ion-ios-arrow-up"></i></span><span class="expanded"><i
                                                class="ion-ios-arrow-down"></i></span></a>
                                </div>
                                <div id="menuseven" class="collapse">
                                    <div class="card-body text-justify">
                                        <p>
                                            A: Saving card details on Razorpay is at the discretion of the customer attempting the
                                            transaction and is optional. Razorpay is a PCI DSS complaint, rest assured your details
                                            are safe.That said, if you wish to remove your card details, you can click on the link 
                                            "MANAGE YOUR CARDS" received in the Email "Card successfully saved with Razorpay".
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <div class="card">
                                <div class="card-header">
                                    <a class="card-link" data-toggle="collapse" href="#menueight" aria-expanded="false"
                                        aria-controls="menueight">Best Practices for hassle-free transactions.<span class="collapsed"><i
                                                class="ion-ios-arrow-up"></i></span><span class="expanded"><i
                                                class="ion-ios-arrow-down"></i></span></a>
                                </div>
                                <div id="menueight" class="collapse">
                                    <div class="card-body text-justify">
                                        <p>
                                            A: Communication with us is the best recourse to a hassle-free transaction. You can also follow these tips:
                                            <ul>
                                                <li>Clearly understand the product before making a purchase.</li>
                                                <li>Make sure to review the T&C, on our website before making a payment.</li>
                                                <li>Wait one business day for the - delivery of digital items (from the date of transaction) before filing a complaint.</li>
                                                <li>Only enter details on secure sites. Look for an https connection and valid security certificates.</li>
                                                <li>Don't enter credit card details on suspicious websites as it may be a phishing attempt.</li>
                                                <li>Keep your antivirus software and browsers up to date</li>
                                                <li>If the application does not download or install properly, you must contact the customer care department via email or call.</li>
                                                <li>In case of issues related to bank processing, you should wait for 5-7 business days & check for refund status in your bank statement.</li>
                                            </ul>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <!-- Technical -->
        <div class="row mt-5">
                <div class="col-md-6  faq-heading  ftco-animate">
                    <h2 class="mb-4">Technical</h2>
                </div>
            <div class="col-md-12 ftco-animate">
                <div id="accordion">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                <a class="card-link" data-toggle="collapse" href="#menunine" aria-expanded="false"
                                        aria-controls="menunine">While installing the application, I’ve encountered an error.<span
                                            class="collapsed"><i class="ion-ios-arrow-up"></i></span><span
                                            class="expanded"><i class="ion-ios-arrow-down"></i></span></a>
                                </div>
                                <div id="menunine" class="collapse">
                                    <div class="card-body text-justify">
                                        <p>
                                            A: Send us an email to <a href="mailto:care@prosoftesolutions.com">care@prosoftesolutions.com</a> with a screen shot of the error,
                                            an explanation of the error you’ve encountered and we’ll be happy to help you.
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <div class="card">
                                <div class="card-header">
                                    <a class="card-link" data-toggle="collapse" href="#menuten" aria-expanded="false"
                                        aria-controls="menuten">What is the recommended system specification?<span
                                            class="collapsed"><i class="ion-ios-arrow-up"></i></span><span
                                            class="expanded"><i class="ion-ios-arrow-down"></i></span></a>
                                </div>
                                <div id="menuten" class="collapse">
                                    <div class="card-body text-justify">
                                        <p>
                                            A:Click  on below desired edition to view the complete system specifications for the C5 CDR Analyzer application.
                                            <br/>
                                            <a class="ml-5"  href="<?php echo base_url();?>dist/profile/C5 CDR Analyzer V5 Prerequisites - Lite  Client  Educational  Community Editions .pdf" target="_blank"">•	Lite/Client/Community/Educational/Trial Edition</a><br/>
                                            <a class="ml-5"  href="<?php echo base_url();?>dist/profile/C5 CDR Analyzer V5 Prerequisites - Professional Edition.pdf" target="_blank"">•	Professional Edition</a></br>
                                            <a class="ml-5"  href="<?php echo base_url();?>dist/profile/C5 CDR Analyzer V5 Prerequisites - Enterprise Edition.pdf" target="_blank"">•	Enterprise Edition</a><br/>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>