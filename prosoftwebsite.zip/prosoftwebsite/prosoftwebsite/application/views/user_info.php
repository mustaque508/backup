<section class="ftco-section bg-light">
    <div class="container">
        <div class="row">
            
            <!-- banner -->
            <div class="col-md-6 align-self-stretch">
            <!-- <div class="col-6   align-self-stretch ftco-animate  ml-3 mr-3"> -->
                <div class="heading-section heading-section-black ftco-animate">
                    <h1 class="text-dark font-weight-bold">
                        <!-- <?php echo $this->session->userdata('edition')?> Edition -->

                        <?php if ($this->session->userdata('edition') == "TRIAL")
                            { echo "<h2 class='text-dark style='font-size: 30px;'>Trial Edition</h2>";
                            }
                            else
                            { echo "<h2 class='text-dark style='font-size: 30px;'>Lite Edition</h2>";
                            }
                        ?>

                    </h1>
                </div>

                <div class="heading-section heading-section-black ftco-animate">
                    <?php if ($this->session->userdata('edition') == "TRIAL")
                      { echo "<h3 class='text-dark'>Try C5 CDR Analyzer, FREE for 30 Days.</h3>
                              <h4>Join thousands of investigating officers  using C5 CDR Analyzer to unleash the power of data analytics.</h4>";
                      }
                      else
                      { echo "<h3 class='text-dark'>Light on the pocket, Lite years ahead in analytics.</h3>
                        <h4>Get the best of both worlds in the Lite Edition of C5 CDR Analyzer. A great opportunity for I.Os to take their investigative skills to the next level.</h4>";
                      }
                    ?>
                </div>

                <div class="heading-section heading-section-black ftco-animate">
                  <a><img class="one-third js-fullscreen align-item-center order-md-last img-fluid"
                          src="<?php echo base_url(); ?>dist/img/C5Lite_TrialFormPage.svg" alt="Home-svg"></a>
                </div>
            </div>


            <!-- FORM -->
            <div class="col-md-6 align-self-stretch">
            <!-- <div class="col-5   align-self-stretch ftco-animate  ml-3 mr-3"> -->
                <form role="form" id="checkout-selection" action="<?php echo base_url();?>index.php/UserInfo/submit"
                    method="post">
                    <div class="form-group">
                        <p style="color: red;"><?php echo $error;?></p>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Full Name*" name="f_name" id="f_name"
                            value="<?php echo $this->session->userdata('f_name');?>" required>
                        <span style="color: red; font-size:small;"><?php echo $f_name_error;?></span>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Contact No*" name="f_contact"
                            id="f_contact" value="<?php echo $this->session->userdata('f_contact');?>" required>
                        <span style="color: red; font-size:small;"><?php echo $f_contact_error;?></span>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Department Email-ID*" name="f_email"
                            id="f_email" value="<?php echo $this->session->userdata('f_email');?>" required>
                        <span style="color: red; font-size:small;"><?php echo $f_email_error;?></span>
                    </div>

                    <div class="row md-6">
                        <div class="col-md-6">
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Department*" name="f_department"
                                    id="f_department" value="<?php echo $this->session->userdata('f_department');?>"
                                    required>
                                <span style="color: red; font-size:small;"><?php echo $f_department_error;?></span>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Designation" name="f_designation"
                                    id="f_designation" value="<?php echo $this->session->userdata('f_designation');?>">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <textarea cols="30" rows="7" class="form-control" placeholder="Address" name="f_address"
                            id="f_address" value="<?php echo $this->session->userdata('f_address');?>"></textarea>
                    </div>

                    <!-- <input type="checkbox" name="terms" id="terms" required> -->

                    <label>
                        By clicking submit you confirm that you have read and agree to <a href="<?php echo base_url(); ?>dist/profile/C5_CDR_Analyzer_(Desktop)_Terms&Conditions.pdf" target="_blank">terms and conditions</a>.
                    </label>

                    <!-- <label>
                        I agree with the <a href="<?php echo base_url(); ?>dist/profile/C5_CDR_Analyzer_(Desktop)_Terms&Conditions.pdf" target="_blank">terms and conditions</a>.
                    </label> -->

                    <div class="form-group">
                        <div class="g-recaptcha" data-sitekey="6Ldtzb4UAAAAAGnBmlLGQjPansZXAGZu4Bd1j8-I"></div>
                    </div>

                    <div class="form-group">
                        <?php /* if ($edition == "LITE") {
                                require_once(APPPATH . 'third_party/razorpay-php/config.php');
                                require_once(APPPATH . 'third_party/razorpay-php/Razorpay.php');
                              ?>
                        <style>
                        .razorpay-payment-button {
                            color: #ffffff !important;
                            background-color: #0071bc;
                            border-color: #7266ba;
                            font-size: 16px;
                            padding: 20px;
                            display: block;
                            max-width: 300px;
                            margin: auto;
                        }

                        .razorpay-payment-button:hover {
                            color: #ffffff !important;
                            background-color: #0071bcc4;
                            border-color: #7266ba;
                            font-size: 16px;
                            padding: 20px;
                            display: block;
                            max-width: 300px;
                            margin: auto;
                            margin-top: -2px;
                        }
                        </style>

                        <script src="https://checkout.razorpay.com/v1/checkout.js" data-key="<?php echo $keyId; ?>"
                            data-amount="<?php echo 100000; ?>" data-buttontext="Pay with Razorpay"
                            data-name="Prosoft e-Solutions" data-description="Transaction with Razorpay"
                            data-image="img/logo/favicon-black.png" data-prefill.name="Full Name"
                            data-prefill.email="info@prosoftesolutions.com" data-theme.color="#0071bc">
                        < input type = "hidden"
                        value = "Hidden Element"
                        name = "hidden" >
                        </script>
                        <?php } else { */ ?>
                        <button name="submit" type="submit" value="Send" class="btn btn-primary py-3 px-5"> Submit
                        </button>
                        <h5 class="text-dark mt-2" style="font-size: 14px;">Submit your information. We’ll send you
                            an email with the download link.</h5>
                        <h5 class="text-secondary mt-2" style="font-size: 14px;">Disclaimer: This software and all its services are only intended for Law Enforcement Agencies.
                                                We do not provide details such as CDR, SDR, Tower ID etc.</h5>

                        <?php //} ?>

                    </div>
                </form>
            </div>
        </div>
    </div>

</section>