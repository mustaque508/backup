 <div class="hero-wrap js-fullheight">
     <div class="container-fluid px-0">
         <div class="row d-md-flex no-gutters slider-text align-items-center js-fullheight justify-content-end">
             <div class="one-forth d-flex align-self-end ftco-animate js-fullheight mt-5">
                <div class="text mt-5">
                        <p class="breadcrumbs mb-0"><span><a href="<?php echo base_url();?>index.php/Home">Home<i
                                        class="ion-ios-arrow-forward"></i></a></span>Contact Us</p>
                        <!-- <span class="subheading">Isometric Hosting</span> -->
                        <h1 class="mb-3">Get in touch with us</span></h1>
                        <p class="h4">It would be great to hear from you! If you got anything related to our Company /
                            Product / Services.</p>
                        <!-- <p><a href="<?php echo base_url(); ?>dist/profile/Prosoft_Corporate_Profile.pdf" class="btn px-4 py-3 text-light button-color">Download Corporate Profile</a></p> -->
                 </div>
             </div>
             <img class="one-third js-fullheight align-self-end order-md-last img-fluid"
                 src="<?php echo base_url(); ?>dist/img/contactUs.svg" alt="contactUs-svg">

         </div>
     </div>
 </div>

<!-- 
 <div class="hero-wrap js-fullheight">
     <div class="overlay"></div>
     <div class="container-fluid px-0">
         <div class="row d-md-flex no-gutters slider-text align-items-center js-fullheight justify-content-end">
             <img class="one-third js-fullheight align-self-end order-md-last img-fluid"
                 src="<?php echo base_url(); ?>dist/img/contactUs.svg" alt="contactus-png">
             <div class="one-forth d-flex align-items-center ftco-animate js-fullheight">
                 <div class="text mt-5">
                     <p class="breadcrumbs mb-0"><span><a href="<?php echo base_url();?>index.php/Home">Home<i
                                     class="ion-ios-arrow-forward"></i></a></span>Contact Us</p>
                     <span class="subheading">Isometric Hosting</span>
                     <h1 class="mb-3">Get in touch with us</span></h1>
                     <p class="h4">It would be great to hear from you! If you got anything related to our Company /
                         Product / Services.</p>
                     <p><a href="<?php echo base_url(); ?>dist/profile/Prosoft_Corporate_Profile.pdf" class="btn px-4 py-3 text-light button-color">Download Corporate Profile</a></p>
                 </div>
             </div>
         </div>
     </div>
 </div> -->

 <section class="ftco-section contact-section ftco-degree-bg">
     <div class="container">


         <div class="row block-9">
             <div class="col-md-6 pr-md-5">
                 <form action="<?php echo base_url(); ?>ContactUs/save" method="post">
                     <h2 style="font-size: 30px; color: red;"><?php echo $response;?></h2>
                     <div class="form-group">
                         <input type="text" class="form-control" placeholder="Your Name*" name="f_name" id="f_name"
                             value="<?php echo $this->session->userdata('cont_name');?>" required>
						 <span style="color: red; font-size:small;"><?php echo $f_name_error;?></span>
                     </div>
                     <div class="form-group">
                        <input type="text" class="form-control" placeholder="Your Contact No.*" name="contact_no"
                            id="contact_no" value="<?php echo $this->session->userdata('cont_contact');?>" required>
						<span style="color: red; font-size:small;"><?php echo $f_contact_error;?></span>
                    </div>
                    <div class="form-group">
                         <input type="text" class="form-control" placeholder="Your Email*" name="f_email" id="f_email"
                             value="<?php echo $this->session->userdata('cont_email');?>" required>
						 <span style="color: red; font-size:small;"><?php echo $f_email_error;?></span>
                     </div>
                     <div class="form-group">
                         <input type="text" class="form-control" placeholder="Subject*" name="subject" id="subject"
                             value="<?php echo $this->session->userdata('cont_subject');?>" required>
						 <span style="color: red; font-size:small;"><?php echo $f_subject_error;?></span>
                     </div>
                     <div class="form-group">
                         <textarea name="message" id="message" cols="30" rows="7" class="form-control"
                             placeholder="Message*" value="<?php echo $this->session->userdata('cont_message');?>" required></textarea>
						 <span style="color: red; font-size:small;"><?php echo $f_message_error;?></span>
                     </div>

                     <div class="form-group">
                        <div class="g-recaptcha" data-sitekey="6Ldtzb4UAAAAAGnBmlLGQjPansZXAGZu4Bd1j8-I"></div>
                    </div>
                   
                     <div class="form-group">
                         <input type="submit" value="Send Message" class="btn btn-primary py-3 px-5">
                     </div>
                 </form>
             </div>

             <div class="col-md-6">
                 <iframe
                     src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3837.4000676380097!2d74.51192031461528!3d15.888098188993078!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bbf669f5095362f%3A0x689f3bcb2dda30f4!2sProsoft+e-Solutions+India+Pvt.+Ltd!5e0!3m2!1sen!2sin!4v1557570245932!5m2!1sen!2sin"
                     height="100%" Width="100%" style="border:1px solid lightgray;"></iframe>
             </div>
         </div>
     </div>
     </div>

 </section>

 <script>
// $.post("<?php echo base_url(); ?>ContactUsc/save_contact_us", { 
// 		'f_name': document.getElementById("f_name").value,
// 		'f_email': document.getElementById("f_email").value,
//     'subject': document.getElementById("subject").value,
//     'message': document.getElementById("message").value
// 	},
// 	function(data){			

//     if (data != "-1"){					

//     } else {

//     }

// }, "json");	
 </script>