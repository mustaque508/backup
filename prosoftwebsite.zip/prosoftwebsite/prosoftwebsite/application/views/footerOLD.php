
<footer>    

<section class="bg-lighter">
    <div class="container">
        <div class="row justify-content-center ftco-animate">
            <div class="col-md-4 text-left mt-3 sales-div">
                <div class="row align-items-center">
                    <h5 class="sales-heading">Sales :</h5>
                    <div class="col-md-6 ml-3 ftco-animate">
                        <div class="row">
                            <div class="media block-4 d-flex align-items-center">
                                <div class="icon d-flex align-items-center justify-content-center order-md-first mr-3">
                                    <!-- <span class="flaticon-headset d-flex"></span> -->
                                    <img
                                        src="<?php echo base_url(); ?>dist/img/ficons/064-headset.svg"
                                        alt="Big Data.svg" class="sales-img ">

                                </div>
                                <div class="media-body pl-4 pl-md-0 text-md-right">
                                    <h5>+91 9743577121</h5>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="media block-4 d-flex align-items-center">
                                <div class="d-flex align-items-center justify-content-center order-md-first mr-3">
                                    <!-- <span class="flaticon-headset d-flex"></span> -->
                                    <img style="width:24px;height:24px;"
                                        src="<?php echo base_url(); ?>dist/img/ficons/email.svg" alt="Big Data.svg" class="sales-img ">

                                </div>
                                <div class="media-body pl-4 pl-md-0 pr-md-4 text-md-left">
                                    <h5>sales@prosoftesolutions.com</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-1 mt-3">
                <h1>|</h1>
            </div>

            <div class="col-md-7 text-left mt-3 customer-div">
                <div class="row align-items-center">
                    <h5 class="custom-heading">Customer Care :</h5>
                    <div class="col-md-5 d-flex align-self-stretch ftco-animate">
                        <div class="media block-4 d-flex align-items-center">
                            <div class="icon d-flex align-items-center justify-content-center order-md-first mr-3">
                                <!-- <span class="flaticon-headset"></span> -->
                                <img
                                    src="<?php echo base_url(); ?>dist/img/ficons/064-headset.svg" alt="Big Data.svg"  class="custom-img ">
                            </div>
                            <div class="media-body pl-4 pl-md-0 text-md-right">
                                <h5>+91 7090773360</h5>
                                <h5>+91 7090773306</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 d-flex align-self-stretch ftco-animate">
                        <div class="media block-4 d-flex align-items-center">
                            <div class="d-flex align-items-center justify-content-center order-md-first mr-3">
                                <!-- <span class="flaticon-support" ></span> -->
                                <img
                                    src="<?php echo base_url(); ?>dist/img/ficons/email.svg" alt="Big Data.svg" class="img">
                            </div>
                            <div class="media-body pl-4 pl-md-0 pr-md-4 text-md-left">
                                <h5>care@prosoftesolutions.com</h5>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- <h5>Customer Support</h5>  -->
            </div>
        </div>
    </div>
</section>

    <!-- <section class="bg-lightgrey" style="border:2px solid green;">
    <div class="container">
          <div class="row">

              <div class="col-md-3 border">

                <div class="sales-div" style="border:2px solid yellow;">
                      <div class="sales-icon">
                          <span class="flaticon-goals"></span>
                      </div>
                      <div class="sales-content">
                        <h3>Sales</h3>
                        <p>some text here....</p>
                      </div>
                </div>

              </div>
              <div class="col-md-9 border">

              </div>
              

        </div>
      </div>
</section> -->

</footer>

<footer class="ftco-footer ftco-section footer">

    <div class="container">
        <div class="row mb-5 d-flex">

            <div class="ftco-footer-widget mb-4 bg-primary  p-3 col-md-3 footer-responsive">
                <img src="<?php echo base_url(); ?>dist/img/ProsoftDFE1EB.png" width="100" height="100"
                    alt="Prosoft e-Solutions" class="img-fluid "></a>
                <h2 class="ftco-heading-2">Prosoft e-Solution India Pvt. Ltd.</h2>
                <p class="text-justify">Committed to delivering world class software and enterprise solutions.</p>
                <ul class="ftco-footer-social list-unstyled mb-0">
                    <li class="ftco-animate"><a href="https://twitter.com/prosoftesoln" target="_blank"><span
                                class="icon-twitter"></span></a></li>
                    <li class="ftco-animate"><a href="https://www.facebook.com/ProsofteSolutions" target="_blank"><span
                                class="icon-facebook"></span></a></li>
                    <li class="ftco-animate"><a href="https://www.youtube.com/channel/UCmwlP6X1M-86sM3M1vvgWJw"
                            target="_blank"><span class="icon-youtube"></span></a></li>
                    <li class="ftco-animate"><a href="https://www.linkedin.com/company/prosoftesolutions"
                            target="_blank"><span class="icon-linkedin"></span></a></li>
                </ul>
            </div>

            <div class="col-md-2 footer-responsive ">
                <h5 class=" text-light font-weight-bolder mb-4">Navigational</h5>
                <ul class="list-unstyled ">
                    <li><a href="<?php echo base_url(); ?>Home" class="py-2 d-block text-light">Home</a></li>
                    <li><a href="<?php echo base_url(); ?>AboutUs" class="py-2 d-block text-light">Company</a></li>
                    <li><a href="<?php echo base_url(); ?>ContactUs" class="py-2 d-block text-light">Contact</a></li>
                    <li><a href="<?php echo base_url(); ?>FAQ" class="py-2 d-block text-light">FAQs</a></li>
                    <li><a href="<?php echo base_url(); ?>SiteMap" class="py-2 d-block text-light">Sitemap</a></li>
                </ul>
            </div>

            <div class="col-md-3 footer-responsive ">
                <h5 class=" text-light font-weight-bolder ml-3 mb-4 ">Products</h5>
                <ul class="list-unstyled ml-3">
                    <li><a href="<?php echo base_url(); ?>products/c5cdr" class="py-2 d-block text-light">C5
                            CDR Analyzer</a></li>
                    <li><a href="<?php echo base_url(); ?>products/c5fa"
                            class="py-2 d-block text-light">Financial Analytics</a></li>
                    <li><a href="<?php echo base_url(); ?>products/healthsoft"
                            class="py-2 d-block text-light">HealthSoft</a></li>
                    <li><a href="<?php echo base_url(); ?>products/erp"
                            class="py-2 d-block text-light">Enterprise Resource Planning</a></li>
                    <li><a href="<?php echo base_url(); ?>products/fms" class="py-2 d-block text-light">Fleet
                            Management</a></li>

                </ul>
            </div>

            <div class="col-md-3 footer-responsive ">
                <h5 class=" text-light font-weight-bolder ml-3 mb-4 ">Office</h5>
                    <div class="block-23 mb-0 ml-0">
                        <ul class="list-unstyled ml-0">
                            <li><span class="icon icon-map-marker text-light "></span>
                                    <span class="text text-light">
                                    <p class="h6 text-light">Prosoft House, 303, 3rd Floor, 
                                    Bel-Heights, Annapurnawadi, 
                                    Belgaum - 590010 Karnataka, India.
                                    </p>
                                    </span></li>
                              <li><a href="#"><span class="icon icon-phone text-light"></span>
                                    <span class="text text-light">
                                        <p class="h6 text-light">
                                            Info : +91 9019858560
                                        </p>
                                    </span></a></li>

                            <li><a href="#"><span class="icon icon-envelope text-light"></span>
                                    <span class="text text-light">
                                        <p class="h6 text-light">
                                            Email : info@prosoftesolutions.com
                                        </p>
                                    </span></a></li>
                        </ul>
                    </div>
            </div>

            <!-- <div class="col-md-3 footer-responsive ">
                <div class="ftco-footer-widget mb-4">
                    <h2 class="ftco-heading-2 text-light ml-0 font-weight-bolder  footer-office ">Office</h2>
                    <div class="block-23 mb-0 ml-0">
                        <ul class="list-unstyled ml-0">
                            <li><span class="icon icon-map-marker text-light "></span><span
                                    class="text text-light">Prosoft House 303, Bel Heights, 3rd Floor, Azam Nagar,
                                    Belgaum - 590010 Karnataka, India.</span></li>
                              <li><a href="#"><span class="icon icon-phone text-light"></span><span
                                        class="text text-light ">Info : +91 9019858560</span></a></li>

                            <li><a href="#"><span class="icon icon-envelope text-light"></span><span
                                        class="text text-light pl-2">info@prosoftesolutions.com</span></a></li>
                        </ul>
                    </div>
                </div>
            </div> -->
        </div>


        <!--<div class="col-md">
              <div class="ftco-footer-widget mb-4 ml-md-5">
                <h2 class="ftco-heading-2">Unseful Links</h2>
                <ul class="list-unstyled">
                  <li><a href="#" class="py-2 d-block">Servers</a></li>
                  <li><a href="#" class="py-2 d-block">Windos Hosting</a></li>
                  <li><a href="#" class="py-2 d-block">Cloud Hosting</a></li>
                  <li><a href="#" class="py-2 d-block">OS Servers</a></li>
                  <li><a href="#" class="py-2 d-block">Linux Servers</a></li>
                  <li><a href="#" class="py-2 d-block">Policy</a></li>
                </ul>
              </div>
            </div> -->

        <div class="row">
            <div class="col-md-12">
                <div class="footer-widget mt-20 footer-space">
                    <div class="row">
                        <!-- <div class="col-lg-6 col-md-6 mt-20">
                  <p><a href="#" class="link-foot" data-toggle="modal" data-target="#cookie_model">Privacy Policy</a></p>
                </div> -->
                        <!-- <p><a href="#" class="link-foot">Terms & Conditions</a> | <a href="#" class="link-foot">Privacy Policy</a></p> -->

                        <div class="col-lg-6 col-md-6 mt-20 ml-2">
                            <p>&copy;<span id="copyright">
                                    <script>
                                    document.getElementById('copyright').appendChild(document.createTextNode(new Date()
                                        .getFullYear()))
                                    </script>
                                </span> <a href="<?php echo base_url(); ?>Home" class="link-foot"> Prosoft
                                    e-solutions India Pvt. Ltd. </a> All Rights Reserved </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

<div id="cookieConsent">
    <!-- <div id="closeCookieConsent">x</div> -->
    <p>We use cookies to offer you a better experience, analyse site traffic and serve targeted ads.
        By continuing to use this website, you consent to the use of cookies in accordance with our Cookie Policy.
        Please read our
        <a href="<?php echo base_url(); ?>Policy/privacy_policy" target="_blank">Privacy Policy</a> &
        <a href="<?php echo base_url(); ?>Policy/cookie_policy" target="_blank">Cookie Policy</a>
        <a class="cookieConsentOK" onClick="onClickConsentOK()">That's Fine</a>
    </p>
</div>

<style type="text/css">
/*Cookie Consent Begin*/
#cookieConsent {
    background-color: rgba(20, 20, 20, 0.8);
    min-height: 26px;
    font-size: 14px;
    color: #ccc;
    line-height: 26px;
    padding: 8px 0 8px 30px;
    font-family: "Trebuchet MS", Helvetica, sans-serif;
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    display: none;
    z-index: 9999;
}

#cookieConsent a {
    color: #4B8EE7;
    text-decoration: none;
}

#cookieConsent p {
    margin: 0 5% 0 5%;
    text-decoration: none;
}

#closeCookieConsent {
    float: right;
    display: inline-block;
    cursor: pointer;
    height: 20px;
    width: 20px;
    margin: -15px 0 0 0;
    font-weight: bold;
}

#closeCookieConsent:hover {
    color: #FFF;
}

#cookieConsent a.cookieConsentOK {
    background-color: #F1D600;
    color: #000;
    display: inline-block;
    border-radius: 5px;
    padding: 0 20px;
    cursor: pointer;
    float: right;
    margin: 0 60px 0 10px;
}

#cookieConsent a.cookieConsentOK:hover {
    background-color: #E0C91F;
}

/*Cookie Consent End*/
</style>

<script>
$(document).ready(function() {
    if (localStorage.getItem('cookies_enabled') === null) {
        setTimeout(function() {
            $("#cookieConsent").fadeIn(200);
        }, 100);
        $("#closeCookieConsent, .cookieConsentOK").click(function() {
            $("#cookieConsent").fadeOut(200);
        });
    } else {
        //localStorage.removeItem("cookies_enabled");
        //alert("cookies already enabled");
    }
});



// // Add active class to the current button (highlight it)
// var header = document.getElementById("ftco-nav");
// var btns = header.getElementsByClassName("nav-item");
// for (var i = 0; i < btns.length; i++) {
// 	btns[i].addEventListener("click", function() {
// 		var current = document.getElementsByClassName("active");
// 		current[0].className = current[0].className.replace(" active", "");
// 		this.className += " active";
// 	});
// }

$(function() {
    var current_page_URL = location.href;
    $("a").each(function() {

        if ($(this).attr("href") !== "#") {

            var target_URL = $(this).prop("href");

            if (target_URL == current_page_URL) {
                $('nav a').parents('li, ul').removeClass('active');
                $(this).parent('li').addClass('active');

                return false;
            }
        }
    });
});

function onClickConsentOK() {
    localStorage.setItem('cookies_enabled', '1'); // Use cookies
}
</script>

<!-- loader -->
<div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px">
        <circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" />
        <circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10"
            stroke="#0A3FFF" />
    </svg></div>

<script src="<?php echo base_url(); ?>dist/js/jquery-migrate-3.0.1.min.js"></script>
<script src="<?php echo base_url(); ?>dist/js/popper.min.js"></script>
<script src="<?php echo base_url(); ?>dist/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>dist/js/jquery.easing.1.3.js"></script>
<script src="<?php echo base_url(); ?>dist/js/jquery.waypoints.min.js"></script>
<script src="<?php echo base_url(); ?>dist/js/jquery.stellar.min.js"></script>

<script src="<?php echo base_url(); ?>dist/js/owl.carousel.min.js"></script>
<script src="<?php echo base_url(); ?>dist/js/jquery.magnific-popup.min.js"></script>
<script src="<?php echo base_url(); ?>dist/js/aos.js"></script>
<script src="<?php echo base_url(); ?>dist/js/jquery.animateNumber.min.js"></script>
<script src="<?php echo base_url(); ?>dist/js/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url(); ?>dist/js/jquery.timepicker.min.js"></script>
<script src="<?php echo base_url(); ?>dist/js/scrollax.min.js"></script>
<script src="<?php echo base_url(); ?>dist/js/google-map.js"></script>
<script src="<?php echo base_url(); ?>dist/js/main.js"></script>

</body>

</html>