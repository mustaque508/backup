<div class="hero-wrap js-fullheight">
    <div class="container-fluid px-0">
        <div class="row d-md-flex no-gutters slider-text align-items-center js-fullheight justify-content-end">

            <div class="one-forth d-flex align-self-end ftco-animate js-fullheight mt-5">
                <div class="text mt-5">
                    
                    <h1 class="mb-3" style="color:red">We’ll be back soon!</span></h1>
                    <p>Sorry for the inconvenience but we are performing some maintenance at the moment.
									If you need to you can always contact us at care@prosoftesolutions.com, otherwise we’ll be back online shortly.</p>
					<p>-         Prosoft Web Team.</p>
                </div>
            </div>
            <img class="one-third js-fullheight align-self-end order-md-last img-fluid"
                src="<?php echo base_url(); ?>dist/img/Maintenance.svg" alt="faHeroBanner-svg">

        </div>
    </div>
</div>
