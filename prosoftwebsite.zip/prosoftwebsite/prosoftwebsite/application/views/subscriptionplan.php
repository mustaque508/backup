<!-- <section class="ftco-section bg-light">
    <div class="container">
        <div class="row">
  
            <div class="col-md-6 align-self-stretch">
         
                <div class="heading-section heading-section-black ftco-animate">
                    <h1>Subscription Plans</h1>
                    <h3>C5 CDR Analyzer - <span class="text-danger">Lite Edition</span></h3>
                </div>
            </div>
        </div>
    </div>
</section> -->


<?php
    $getData=json_decode($data,true);
?>

<section class="ftco-section bg-gray mt-5">
    <div class="container">
        <div class="row justify-content-center mb-5 pb-3">
            <div class="col-md-7 text-center heading-section ftco-animate">
                <h2 class="mb-4">Subscription Plans</h2>
                <h3>C5 CDR Analyzer - <span class="text-danger">Lite Edition</span></h3>
                <h6><span class="text-danger"><?php echo $error; ?></span></h6>
            </div>
        </div>
        <div class="row d-flex justify-content-center">
            <div class="col-lg-4 col-md-6 ftco-animate">
                <div class="block-7">
                    <div class="text-center">

                        <h3><?php echo $getData[0]["SubscriptionName"]; ?></h3>
                        <span class="price "><span class="number base_price">-</span>
                            <!-- <span class="price "><sup class="base_color">INR</sup> <span
                                    class="number base_strikethrough base_price "><?php echo $getData[0]["Amount_After_GST"];?><small
                                        class="per"></small></span></span>
                            <span class="price" id="PR_base_price"><span class=" PR_span baseprice_span">Offer
                                    price</span><sup class=" PR_sup PR_INR">INR</sup> <span
                                    class="number PR_baseprice"><?php echo $getData[0]["OfferPrice"];?><small
                                        class="per"></small></span></span> -->


                            <span class="price" id="PR_base_price"><sup class=" PR_sup PR_INR">INR</sup> <span
                                    class="number PR_baseprice"><?php echo $getData[0]["OfferPrice"];?><small
                                        class="per"></small></span></span>

                            <!-- offer price for PR coupon -->
                            <!-- <h3 class="PR_offertitle"></h3> -->
                            <span class="price PR_offerprice" style="display:none;"><span class="text-danger">final
                                    price</span><sup class="text-danger final_INR">INR</sup> <span
                                    class="number PRoffer_price"></span><small>&nbsp;</small><small
                                    class="per PR_cc"></small></span>

                            <!-- coupon form  for PR -->
                            <form autocomplete="off" method="post" id="PR_form" class="PR_form mb-3">
                                <label for="PR_coupon">Coupon code : </label>
                                <input type="text" name="PR_coupon" id="PR_coupon" class="text-uppercase ml-1" required>
                                <button type="submit" class="btn  ml-2" id="PR_apply">Apply</button>
                                <p class="PR_invalid"></p>
                            </form>


                            <div class="PR_Example">
                                <!-- <small class="per">Use Coupon 'PRPRO' for discount</small> -->
                                <a href="<?php echo base_url(); ?>UserInfo/user_info_lite?id=<?php echo md5('basePR');?>"
                                    class="btn btn-primary d-block px-3 py-3 mb-4 PR_BuyNow" id="PR_baseprice">Buy
                                    Now</a>
                            </div>


                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 ftco-animate">
                <div class="block-7">
                    <div class="text-center">
                        <h3><?php echo $getData[1]["SubscriptionName"]; ?></h3>
                        <span class="price "><span class="number base_price">-</span>
                            <span class="price" id="S1_base_price"><sup class="S1_sup S1_INR">INR </sup><span
                                    class="number S1_baseprice"><?php echo $getData[1]["OfferPrice"];?><small
                                        class="per">/year</small></span></span>

                            <!-- offer price for coupon S1 -->
                            <span class="price S1_offerprice" style="display:none;"><span class="text-danger">final
                                    price</span><sup class="text-danger final_INR">INR</sup> <span
                                    class="number S1offer_price"></span><small class="per text-danger">/year
                                    &nbsp;</small><small class="per S1_cc"></small></span>

                            <!-- coupon form  for S1 -->
                            <form autocomplete="off" method="post" id="S1_form" class="S1_form mb-3">
                                <label for="S1_coupon">Coupon code : </label>
                                <input type="text" name="S1_coupon" id="S1_coupon" class="text-uppercase ml-1" required>
                                <button type="submit" class="btn ml-2" id="S1_apply">Apply</button>
                                <p class="S1_invalid"></p>
                            </form>
                            <div class="S1_Example">
                                <!-- <small class="per">Use Coupon 'S1PRO' for discount</small> -->
                                <a href="<?php echo base_url(); ?>UserInfo/user_info_lite?id=<?php echo md5('baseS1');?>"
                                    class="btn btn-primary d-block px-3 py-3 mb-4 S1_BuyNow" id="S1_baseprice">Buy
                                    Now</a>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
$(document).ready(function() {



    // PR coupon code form
    $('#PR_form').on('submit', function(event) {
        console.log("PR_Apply button clicked.");
        $('#PR_apply').attr('disabled', true);
        $('#PR_apply').addClass('disable');
        $('.disable').css("cursor", "not-allowed");
        event.preventDefault();

        $.ajax({
            url: '<?php echo base_url();?>SubscriptionPlan/getPROffer_details',
            type: 'post',
            dataType: 'json',
            data: $('#PR_form').serialize(),
            success: function(response) {
                if (response == "110") {
                    // card style if coupon code is invalid
                    console.log("invalid coupon code");
                    $(".PR_invalid").html("Invalid coupon code");
                    $(".PR_invalid").css("display", "block");
                    $(".PR_invalid").css("margin-top", "-0.2rem");
                    $('.PR_Example').css("margin-top", "-0.95rem");
                    $('.PR_form').css('margin-top', '-0.6rem');
                    // $('.PR_Example').css('border','1px solid black');
                    // $('.PR_Example').css('margin-top','-1.7rem');
                    // $('.PR_Exmaple').css('padding','0px');
                    $('.PR_offerprice').css("display", "none");
                    $('.PR_baseprice').removeClass("PRbase_price");
                    $('.PR_strikethrough').removeClass("PR_strikethrough");
                    $('.PR_span').addClass('baseprice_span');
                    $('.PR_INR').css('font-size', '20px');
                    // $('.base_strikethrough').addClass("text-muted");
                    $('.offer_color').removeClass("offer_color");
                    $('#PR_apply').attr('disabled', false);
                    $('.disable').css("cursor", "auto");
                    $('.PR_BuyNow').attr('href',
                        '<?php echo base_url(); ?>UserInfo/user_info_lite?id=<?php echo md5('basePR') ?>'
                    );
                } else {
                    if (response.length > 0) {
                        // check PR coupon code already used
                        if (response[0].IsUsed == 1) {
                            $(".PR_invalid").html("Already used");
                            $(".PR_invalid").css("display", "block");
                            $('.PR_form').css('margin-top', '-0.6rem');
                            $('.PR_Example').css("margin-top", "-0.95rem");
                            $(".PR_invalid").css("margin-top", "-0.2rem");
                            $('.disable').css("cursor", "auto");
                            $('.PR_span').addClass('baseprice_span');
                            $('#PR_apply').attr('disabled', false);

                            $('.PR_offerprice').css("display", "none");
                            $('.PR_baseprice').removeClass("PRbase_price");
                            $('.PR_strikethrough').removeClass("PR_strikethrough");
                            $('.PR_span').addClass('baseprice_span');
                            $('.PR_INR').css('font-size', '20px');
                            // $('.base_strikethrough').addClass("text-muted");
                            $('.offer_color').removeClass("offer_color");

                            console.log(response[0].IsUsed);
                        } else if (response[0].IsUsed == 0) {
                            PR_base_price = '<?php echo $getData[0]["Amount_After_GST"];?>';
                            PR_OfferPrice = response[0].OfferPrice;

                            PR_ProductID = response[0].Product_ID;
                            PR_Product_Name = response[0].Product_Name;
                            PR_SubscriptionPlan_No = response[0].SubscriptionPlan_No;
                            PR_CouponCode = response[0].CouponCode;
                            PR_SubscriptionPlan_Name =
                                '<?php echo $getData[0]["SubscriptionName"];?>'
                            console.log(response);

                            // card style if coupon code is valid
                            $('.PR_offerprice').css("display", "block");
                            $('.PRoffer_price').addClass("text-danger");
                            $('.PRoffer_price').html(PR_OfferPrice);
                            $('.PR_cc').html("cc=" + PR_CouponCode);
                            $('.PR_cc').addClass("text-danger");
                            $('.PR_baseprice').addClass("PRbase_price");
                            $('.PRbase_price').addClass("PR_strikethrough");
                            $('.PRbase_price').addClass("offer_color");
                            $('.PR_INR').css('font-size', '15px');
                            $('.PR_INR').addClass("offer_color");
                            $('#PR_form').css('margin-top', '-0.5rem');
                            $('#PR_base_price').css('margin-top', '-0.2rem');
                            $('.PR_Example').css("margin-top", "0");
                            $('.disable').css("cursor", "auto");
                            $('.baseprice_span').removeClass("baseprice_span");




                            $.ajax({
                                url: '<?php echo base_url();?>SubscriptionPlan/set_general_session',
                                type: 'post',
                                dataType: 'json',
                                data: {
                                    'OfferType': "PR",
                                    'ProductID': PR_ProductID,
                                    'OfferPrice': PR_OfferPrice,
                                    'Product_Name': PR_Product_Name,
                                    'SubscriptionPlan_No': PR_SubscriptionPlan_No,
                                    'CouponCode': PR_CouponCode,
                                    'base_price': PR_base_price,
                                    'SubscriptionPlan_Name': PR_SubscriptionPlan_Name
                                },

                                success: function(response) {
                                    console.log(response);
                                    console.log(
                                        "successfully sent for session");
                                    $('.PR_BuyNow').attr('href',
                                        '<?php echo base_url(); ?>UserInfo/user_info_lite?id=<?php echo md5('PR') ?>'
                                    );
                                    console.log($('.PR_BuyNow').attr('href'));

                                },

                                error: function(error) {
                                    console.log("session not set");
                                }
                            });

                            $(".PR_invalid").css("display", "none");
                            $('#PR_apply').attr('disabled', false);
                            $('#PR_form')['0'].reset();
                        }
                    }
                }
            },
            error: function(error) {
                console.log("something went wrong");
            }
        });
    });

    // S1 coupon code form
    $('#S1_form').on('submit', function(event) {
        console.log("S1_Apply button clicked.");
        $('#S1_apply').attr('disabled', true);
        $('#S1_apply').addClass('disable');
        $('.disable').css("cursor", "not-allowed");
        event.preventDefault();

        $.ajax({
            url: '<?php echo base_url();?>SubscriptionPlan/getS1Offer_details',
            type: 'post',
            dataType: 'json',
            data: $('#S1_form').serialize(),
            success: function(response) {
                if (response == "110") {
                    // card style if coupon code is invalid
                    console.log("invalid coupon code");
                    $(".S1_invalid").html("Invalid coupon code");
                    $(".S1_invalid").css("display", "block");
                    // $(".S1_invalid").css("margin-top","-0.2rem");
                    // $('.S1_Example').css("margin-top","-1.5rem");
                    // $('.S1_form').css('margin-top','-1rem');
                    $('.S1_form').css('margin-top', '-0.6rem');
                    $('.S1_Example').css("margin-top", "-0.95rem");
                    $(".S1_invalid").css("margin-top", "-0.2rem");
                    $('.S1_offerprice').css("display", "none");

                    $('.S1_span').addClass('S1baseprice_span');
                    $('.S1_INR').css('font-size', '20px');
                    $('.S1_baseprice').removeClass("S1base_price");
                    $('.S1_strikethrough').removeClass("S1_strikethrough");
                    $('.text-muted').removeClass("text-muted");
                    $('#S1_apply').attr('disabled', false);
                    $('.disable').css("cursor", "auto");
                    $('.S1_BuyNow').attr('href',
                        '<?php echo base_url(); ?>UserInfo/user_info_lite?id=<?php echo md5('baseS1') ?>'
                    );
                } else {
                    if (response.length > 0) {
                        // check PR coupon code already used
                        if (response[0].IsUsed == 1) {
                            $(".S1_invalid").html("Already used");
                            $(".S1_invalid").css("display", "block");
                            $('.S1_form').css('margin-top', '-0.6rem');
                            $('.S1_Example').css("margin-top", "-0.95rem");
                            $(".S1_invalid").css("margin-top", "-0.2rem");
                            $('.disable').css("cursor", "auto");
                            $('.S1_span').addClass('baseprice_span');
                            $('#S1_apply').attr('disabled', false);


                            $('.S1_offerprice').css("display", "none");
                            $('.S1_baseprice').removeClass("S1base_price");
                            $('.S1_strikethrough').removeClass("S1_strikethrough");
                            $('.S1_span').addClass('S1baseprice_span');
                            $('.text-muted').removeClass("text-muted");

                            $('.S1_INR').css('font-size', '20px');
                            console.log(response[0].IsUsed);
                        } else if (response[0].IsUsed == 0) {
                            S1_base_price = '<?php echo $getData[1]["Amount_After_GST"];?>';
                            S1_OfferPrice = response[0].OfferPrice;

                            S1_Product_ID = response[0].Product_ID;
                            S1_Product_Name = response[0].Product_Name;
                            S1_SubscriptionPlan_No = response[0].SubscriptionPlan_No;
                            S1_CouponCode = response[0].CouponCode;

                            S1_SubscriptionPlan_Name =
                                '<?php echo $getData[1]["SubscriptionName"];?>'
                            console.log(response);

                            // card style if coupon code is valid
                            $('.S1_offerprice').css("display", "block");
                            $('.S1offer_price').addClass("text-danger");
                            $('.S1offer_price').html(S1_OfferPrice);
                            $('.S1_cc').html("cc=" + S1_CouponCode);
                            $('.S1_cc').addClass("text-danger");
                            $('.S1_baseprice').addClass("S1base_price");
                            $('.S1base_price').addClass("S1_strikethrough");
                            $('.S1base_price').addClass("text-muted");
                            $('.S1_INR').css('font-size', '15px');
                            $('.S1_INR').addClass("text-muted");
                            $('#S1_form').css('margin-top', '-0.5rem');
                            $('#S1_base_price').css('margin-top', '-0.2rem');
                            $('.S1_Example').css("margin-top", "0");
                            $('.disable').css("cursor", "auto");
                            $('.S1baseprice_span').removeClass("S1baseprice_span");

                            $.ajax({
                                url: '<?php echo base_url();?>SubscriptionPlan/set_general_session',
                                type: 'post',
                                dataType: 'json',
                                data: {
                                    'OfferType': "S1",
                                    'ProductID': S1_Product_ID,
                                    'OfferPrice': S1_OfferPrice,
                                    'Product_Name': S1_Product_Name,
                                    'SubscriptionPlan_No': S1_SubscriptionPlan_No,
                                    'CouponCode': S1_CouponCode,
                                    'base_price': S1_base_price,
                                    'SubscriptionPlan_Name': S1_SubscriptionPlan_Name
                                },
                                success: function(response) {
                                    console.log(response);
                                    console.log(
                                        "successfully variable sent for session"
                                    );
                                    console.log(response);
                                    $('.S1_BuyNow').attr('href',
                                        '<?php echo base_url(); ?>UserInfo/user_info_lite?id=<?php echo md5('S1') ?>'
                                    );
                                    console.log($('.S1_BuyNow').attr('href'));

                                }
                            });

                            $(".S1_invalid").css("display", "none");
                            $('#S1_apply').attr('disabled', false);
                            $('#S1_form')['0'].reset();
                        }
                    }
                }
            },
            error: function(error) {
                console.log("something went wrong");
            }
        });
    });

    //PR coupon base price
    $('#PR_baseprice').on('click', function(event) {

        if ($('#PR_baseprice').attr('href') ==
            '<?php echo base_url();?>UserInfo/user_info_lite?id=<?php echo md5('basePR') ?>') {
            event.preventDefault();
            $.ajax({
                url: '<?php echo base_url();?>SubscriptionPlan/getPRBase_details',
                type: 'post',
                dataType: 'json',
                success: function(response) {
                    if (response.length > 0) {
                        console.log(response);
                        var PR_base_price = response[0].Amount_After_GST;
                        var pr_offer_price = response[0].OfferPrice;

                        var PR_ProductID = response[0].Product_ID;
                        var PR_base_Product_Name = response[0].Product_Name;
                        var PR_base_SubscriptionPlan_Name = response[0].SubscriptionName;
                        var PR_subscriptionPlan_No = response[0].SubscriptionPlan_No;

                        $.ajax({
                            url: '<?php echo base_url();?>SubscriptionPlan/set_general_session',
                            type: 'post',
                            dataType: 'json',
                            data: {
                                'OfferType': "PR_BASE",
                                'ProductID': PR_ProductID,
                                'OfferPrice': pr_offer_price,
                                'Product_Name': PR_base_Product_Name,
                                'SubscriptionPlan_No': PR_subscriptionPlan_No,
                                'CouponCode': "-----",
                                'base_price': PR_base_price,
                                'SubscriptionPlan_Name': PR_base_SubscriptionPlan_Name
                            },
                            success: function(response) {
                                console.log("successfully sent for session");
                                window.location.href =
                                    '<?php echo base_url();?>UserInfo/user_info_lite?id=<?php echo md5('basePR') ?>';
                            },
                            error: function(error) {
                                console.log("session not set");
                            }
                        });
                    }
                },
                error: function(error) {
                    console.log("something went wrong....");
                }
            });
        }
    });

    //S1 coupon base price
    $('#S1_baseprice').on('click', function(event) {

        if ($('#S1_baseprice').attr('href') ==
            '<?php echo base_url();?>UserInfo/user_info_lite?id=<?php echo md5('baseS1') ?>') {
            event.preventDefault();
            $.ajax({
                url: '<?php echo base_url();?>SubscriptionPlan/getPRBase_details',
                type: 'post',
                dataType: 'json',
                success: function(response) {
                    if (response.length > 0) {
                        console.log(response);
                        var S1_base_price = response[1].Amount_After_GST;
                        var s1_offer_price = response[1].OfferPrice;

                        var PR_ProductID = response[1].Product_ID;

                        var S1_base_Product_Name = response[1].Product_Name;
                        var S1_base_SubscriptionPlan_Name = response[1].SubscriptionName;
                        var S1_subscriptionPlan_No = response[1].SubscriptionPlan_No;

                        $.ajax({
                            url: '<?php echo base_url();?>SubscriptionPlan/set_general_session',
                            type: 'post',
                            dataType: 'json',
                            data: {
                                'OfferType': "S1_BASE",
                                'ProductID': PR_ProductID,
                                'OfferPrice': s1_offer_price,
                                'Product_Name': S1_base_Product_Name,
                                'SubscriptionPlan_No': S1_subscriptionPlan_No,
                                'CouponCode': "-----",
                                'base_price': S1_base_price,
                                'SubscriptionPlan_Name': S1_base_SubscriptionPlan_Name
                            },
                            success: function(response) {
                                console.log("successfully sent for session");
                                window.location.href =
                                    '<?php echo base_url();?>UserInfo/user_info_lite?id=<?php echo md5('baseS1')?>';
                            },
                            error: function(error) {
                                console.log("session not set");
                            }
                        });
                    }
                },
                error: function(error) {
                    console.log("something went wrong....");
                }
            });
        }
    });
});
</script>