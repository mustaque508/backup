
	<section class="ftco-section contact-section ftco-degree-bg">
      <div class="container">
	  	<div class="row justify-content-center mb-10 pb-3">    
			<div class="col-md-4">
				<div class="py-4">
					<img class="img-fluid"  src="<?php echo base_url(); ?>dist/img/thankYouEmail.svg" alt="">
				</div>
			</div>
			<div class="col-md-8">
				<div class="row justify-content-center mb-2">
					<br>
					<br>
					<br>
					<br>
				</div>
				<div class="container justify-content-center mb-2">
					<div class="heading-section heading-section-black ftco-animate">					
						<h2 style="font-size: 30px;">THANK YOU!</h2>
						<span id="spanID" class="subheading">We appreciate your interest in our Partner Program. We’ll get back to you soon.</span>
				  	</div>
				</div>  
      		</div>			  
		</div>
      </div>
    </section>