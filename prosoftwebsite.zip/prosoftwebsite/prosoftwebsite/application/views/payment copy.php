  <?php
    require_once(APPPATH . 'third_party/razorpay-php/config.php');
    require_once(APPPATH . 'third_party/razorpay-php/Razorpay.php');
  ?>

  <style>
    .razorpay-payment-button {
      color: #ffffff !important;
      background-color: #0071bc;
      border-color: #7266ba;
      font-size: 16px;
      padding: 5px;
      display: block;
      max-width: 300px;
      margin: auto;
      }
      .razorpay-payment-button:hover {
      color: #ffffff !important;
      background-color: #0071bcc4;
      border-color: #7266ba;
      font-size: 16px;
      padding: 5px;
      display: block;
      max-width: 300px;
      margin: auto;
      margin-top: -2px;
      }
  </style>

  <section class="ftco-section bg-light">    
    <div class="container">
	    <div class="row justify-content-center mb-2 pb-3">
        <!-- <div class="col-md-7 text-center heading-section ftco-animate">          
          <p class="h5">Providing you with powerful analytical tools, is what we do best.</p>
        </div> -->
      </div>

		  <div class="row">
        <div class="row">
          <div class="col-md-8">
            <h6 style="color: red;"><?php echo $error; ?></h6>
          </div>
        </div>
        <div class="row">
          <div class="col-md-8">
            <div class="card">
              <div class="card-header">
                Selected Product
              </div>
              <div class="card-body">
              <div class="row">
                <div class="col-4 mt-3 ml-3 mb-5 mr-3"><img src="<?php echo base_url(); ?>dist/img/C5-lite-logo-with-Title.png" alt="Prosoft e-Solutions" class="img-fluid img"></div>
                  <div class="row">
                    <h3 class="ml-5" >C5 CDR Analyzer - Lite Edition</h3>
                  </div>
                <!-- <div class="col-8">
                  <div class="row">
                    <h3>Edition : <?php echo $this->session->userdata('edition')?></h3> 
                  </div>

                  <div class="row">
                    <h3>Quantity : 1</h3>
                  </div>
                  <div class="row">
                    <h3>Amount : <?php echo $this->session->userdata('amount') . " INR"?></h3>
                  </div>
                </div> -->
              </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card">
              <div class="card-header">
                Payment Description
              </div>
              <div class="card-body">
                  <style>
                  table {
                    border-collapse: collapse;
                    width: 100%;
                  }

                  th, td {
                    padding: 8px;
                    text-align: left;
                    border-bottom: 1px solid #ddd;
                  }

                  tr:hover {background-color:#f5f5f5;}
                  </style>
              <table class="h5">
                <tr>
                  <td>Amount</td>
                  <td>: </td>
                  <td>25000.00 INR</td>
                </tr>
                <tr>
                  <td>GST 18%</td>
                  <td>:</td>
                  <td>4500.00 INR</td>
                </tr>

                <tfoot class="h3">
                  <tr >
                    <td>Net Total</td>
                    <td>:</td>
                    <td>29500.00 INR</td>
                  </tr>
                </tfoot>
              </table>

                <!-- <div class="row">
                    <p class="card-text">Amount : 6396.00 </p>
                </div>
                <div class="row">
                    <p class="card-text">GST (18%)  : 1404.00</p>
                </div>
                <div class="row">
                    <h5 class="card-title">Amount Payable : <?php echo $this->session->userdata('amount') . " INR"?></h5>
                </div> -->
                <!-- <?php echo $this->session->userdata('amount') ?></p> -->
                <!-- <p class="card-text">GST (18%)  : 1404.00</p> -->
                <!-- <h5 class="card-title">Amount Payable : <?php echo $this->session->userdata('amount') . " INR"?></h5> -->
              </div>
              <div class="card-footer">
                <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
                <form role="form" name='razorpayform' id="razorpayform" class="float-right" action="<?php echo base_url();?>index.php/UserInfo/payment_response" method="post">                        
                  <input type="hidden" name="razorpay_payment_id" id="razorpay_payment_id">
                  <input type="hidden" name="razorpay_signature"  id="razorpay_signature" >

                  <button type="button" class="btn btn-primary px-5" id="rzp-button1">Pay Now</button>

                  <!-- <script
                      src="https://checkout.razorpay.com/v1/checkout.js"
                      data-key="<?php echo $keyId; ?>"
                      data-amount="<?php echo ($this->session->userdata('amount') * 100); ?>"
                      data-buttontext="Proceed to Pay"
                      data-name="Prosoft e-Solutions"
                      data-description="Transaction with Razorpay"
                      data-image="img/logo/favicon-black.png"
                      
                      data-prefill.name="<?php echo $this->session->userdata('f_name')?>"
                      data-prefill.email="<?php echo $this->session->userdata('f_email')?>"
                      data-prefill.contact="<?php echo $this->session->userdata('f_contact')?>"
      
                      data-notes.soolegal_order_id="<?php echo $this->session->userdata('unique_id')?>"      
                      data-theme.color="#0071bc"/>
                  </script>   -->
                </form>
              </div>
            </div>                                                
          </div>        
        </div>
      </div>
    </div>
  </section>

<script>
  // Checkout details as a json
  var options = <?php echo $json; ?>;

  /**
   * The entire list of Checkout fields is available at
   * https://docs.razorpay.com/docs/checkout-form#checkout-fields
   */
  options.handler = function (response){
      document.getElementById('razorpay_payment_id').value = response.razorpay_payment_id;
      document.getElementById('razorpay_signature').value = response.razorpay_signature;
      document.razorpayform.submit();
  };

  // Boolean whether to show image inside a white frame. (default: true)
  options.theme.image_padding = false;

  options.modal = {
      ondismiss: function() {
          console.log("This code runs when the popup is closed");
      },
      // Boolean indicating whether pressing escape key 
      // should close the checkout form. (default: true)
      escape: true,
      // Boolean indicating whether clicking translucent blank
      // space outside checkout form should close the form. (default: false)
      backdropclose: false
  };

  var rzp = new Razorpay(options);

  document.getElementById('rzp-button1').onclick = function(e){
      rzp.open();
      e.preventDefault();
  }
</script>
		
