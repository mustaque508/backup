	<div class="hero-wrap hero-wrap-2" style="background-image: url('<?php echo base_url(); ?>dist/img/partner-banner.png');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-end justify-content-start">
          <div class="col-md-8 ftco-animate text-center text-md-left mb-5">
          	<p class="breadcrumbs mb-0"><span class="mr-3"><a href="<?php echo base_url(); ?>Indexc">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Become A Partner</span></p>
            <h1 class="mb-3 bread">Become A Partner</h1>
          </div>
        </div>
      </div>
    </div>

	<section class="ftco-section ftco-no-pt ftc-no-pb">
    	<div class="container">
    		<div class="row">
    			<div class="col-lg-12 py-5">    				
    				<div class="heading-section ftco-animate mt-5">
						<h2 class="mb-4">Why Partner with Us</h2>
						<p>At Prosoft, we believe that our partnership is about creating valuable relationship, and together we can add that extra value to our product and services that would differentiate us from rest of the market. It is also being part of the family.</p>
					</div>
    			</div>
			</div>
			<div class="row">
    			<div class="col-lg-12 py-5">
    				<div class="row">
    					<div class="col-md-4 ftco-animate">
    						<div class="media block-6 services border text-center">
								<div class="icon d-flex align-items-center justify-content-center">
									<span class="flaticon-cloud-computing"></span>
								</div>
								<div class="mt-3 media-body media-body-2">
									<h3 class="heading">Valuable Relationship</h3>
									<p>We have a business partner model on the principle that innovating and deepening relationship would be at the heart of our partnership philosophy.</p>
								</div>
							</div>
    					</div>
    					<div class="col-md-4 ftco-animate">
    						<div class="media block-6 services border text-center">
								<div class="icon d-flex align-items-center justify-content-center">
									<span class="flaticon-cloud"></span>
								</div>
							  <div class="mt-3 media-body media-body-2">
								<h3 class="heading">Proven track record and research</h3>
								<p>We are pioneers of CDR analysis software in India and have experience and expertise to deliver world class software and enterprise solutions. Our clientele includes top most government and private organizations.</p>
							  </div>
							</div>
    					</div>
    					<div class="col-md-4 ftco-animate">
    						<div class="media block-6 services border text-center">
								<div class="icon d-flex align-items-center justify-content-center">
									<span class="flaticon-server"></span>
								</div>
							  <div class="mt-3 media-body media-body-2">
								<h3 class="heading">Flexible and agile</h3>
								<p>We understand that market is a dynamic place and thus are flexible and agile to constantly deliver world class products and services.</p>
							  </div>
							</div>
    					</div>    					
    				</div>
				</div>
				<!--<div class="col-lg-6 py-5">
    				<div class="row">
						<div class="col-md-5 business-date-box sm-mt-40" style="background: url(<?php echo base_url(); ?>dist/img/24.jpg);">
							<div class="business-date-box-text h-100">
							  <div class="text-right position-relative">
								<h2 class="text-right theme-color">20</h2>
								<span class="text-right">Years</span>
							  </div>
							  <br>

							  <div class="position-relative">
								<h4 style="margin-top: -15px;" class="theme-color">"Empowering Law Enforcement Agencies with the power of Data Analytics."</h4>
							  </div>

							  <div class="pos-bot mb-30 mr-20">
								<h4>Partnership Is About Creating Valuable Relationship</h4>
								<a class="button button-gradient" href="contact.php">Contact Us</a>
							  </div>
							</div>
						</div>
					</div>
				</div>-->
    		</div>
    	</div>
    </section>
	
	<section class="ftco-section ftco-no-pt ftc-no-pb">
    	<div class="container">
    		<div class="row">
    			<div class="col-lg-12 py-5">    				
    				<div class="heading-section ftco-animate mt-5">
						<h2 class="mb-4">Partner Benefits</h2>						
					</div>
    			</div>
			</div>
			<div class="row">
    			<div class="col-lg-12 py-5">
    				<div class="row">
    					<div class="col-md-3 ftco-animate">
    						<div class="media block-6 services border text-center">
								<div class="icon d-flex align-items-center justify-content-center">
									<span class="flaticon-cloud-computing"></span>
								</div>
								<div class="mt-3 media-body media-body-2">
									<h3 class="heading">In-depth market knowledge</h3>
									<p>Right from the start we would assist you in identifying prospects clients by our in depth market understanding.</p>
								</div>
							</div>
    					</div>
						<div class="col-md-3 ftco-animate">
    						<div class="media block-6 services border text-center">
								<div class="icon d-flex align-items-center justify-content-center">
									<span class="flaticon-cloud-computing"></span>
								</div>
								<div class="mt-3 media-body media-body-2">
									<h3 class="heading">Training</h3>
									<p>We constantly invest in training to help you establish your business and get a jump start from solid knowledge support.</p>
								</div>
							</div>
    					</div>
						<div class="col-md-3 ftco-animate">
    						<div class="media block-6 services border text-center">
								<div class="icon d-flex align-items-center justify-content-center">
									<span class="flaticon-cloud-computing"></span>
								</div>
								<div class="mt-3 media-body media-body-2">
									<h3 class="heading">Sales support</h3>
									<p>We would provide you comprehensive sales support by client visits, online demos, marketing brochures and other activities.</p>
								</div>
							</div>
    					</div>
						<div class="col-md-3 ftco-animate">
    						<div class="media block-6 services border text-center">
								<div class="icon d-flex align-items-center justify-content-center">
									<span class="flaticon-cloud-computing"></span>
								</div>
								<div class="mt-3 media-body media-body-2">
									<h3 class="heading">Customer support</h3>
									<p>We shall provide dedicated uninterrupted customer support.</p>
								</div>
							</div>
    					</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="ftco-section bg-light">
    	<div class="container">
    		<div class="row">
    			<div class="col-lg-12 py-5">    				
    				<div class="heading-section ftco-animate mt-5">
						<h2 class="mb-4">Interested In Our Partner Program?</h2>						
					</div>
    			</div>
			</div>
			<div class="row">
    			<div class="col-lg-12 py-5">
    				<div class="row">
    					<div class="col-md-8 ftco-animate">
    						<div class="media block-6 services border text-center">
								<form action="" method="POST">
									<div class="row">
									  <div class="section-field col-md-6">
									   <label>Full Name</label>
										<div class="field-widget">
										  <input type="text" class="form-control" name="fullname" required>
										</div>  
									  </div> 
									  <div class="section-field col-md-6">
									   <label>Designation</label>
									   <div class="field-widget">
										<input type="text" class="form-control" name="designation" required>
										</div>
									  </div>
									</div>

									<div class="row">
									  <div class="section-field col-md-6">
									   <label>Email Id</label>
										<div class="field-widget">
										 <input  class="email form-control" type="text" name="email" required>
										</div> 
									  </div>
									  <div class="section-field col-md-6">
									   <label>Company Address </label>
										<div class="field-widget">
										 <input class="web form-control" type="text" name="address" required>
										</div> 
									  </div>
									</div>

									<div class="row">
									  <div class="section-field col-md-6">
									   <label>Mobile No</label>
										<div class="field-widget">
										 <input id="phone" class="phone form-control" type="text" name="phone" required>
										</div> 
									  </div>
									  <div class="section-field col-md-6">
									   <label>Pincode</label>
										<div class="field-widget">
										 <input id="phone" class="phone form-control" type="text" name="pincode" required>
										</div> 
									  </div>
									</div>

									<div class="row">
									  <div class="section-field col-md-6">
									   <label>Company Name</label>
										<div class="field-widget">
										 <input id="text" class="phone form-control" type="text" name="companyname" required>
										</div> 
									  </div>
									  <div class="section-field col-md-6">
									   <label>Website</label>
										<div class="field-widget">
										 <input id="text" class="phone form-control" type="text" name="website" required>
										</div> 
									  </div>
									</div>

									<div class="section-field">
									  <label>What type of company do you work for?</label>
									  <select name="companytype" class="phone form-control" required style="height: calc(3rem + 2px);">
										<option value="">-- Select --</option>
										<option value="Independent Software Vendor">Independent Software Vendor</option>
										<option value="Corporation or Government Entity">Corporation or Government Entity</option>
										<option value="Technology System Integrator or Consultancy">Technology System Integrator or Consultancy</option>
										<option value="Progress Partner">Progress Partner</option>
										<option value="Software Reseller">Software Reseller</option>
										<option value="Technology Service Provider">Technology Service Provider</option>
									  </select>
									</div>

									<div class="section-field">
									  <label>Industry?</label>
									  <select name="industry" class="phone form-control" required style="height: calc(3rem + 2px);">
										<option value="">-- Select --</option>
										<option value="Aerospace & Defence">Aerospace & Defence</option> 
										<option value="Agriculture, Forestry, Fishing & Hunting">Agriculture, Forestry, Fishing & Hunting </option>
										<option value="Business Services">Business Services </option>
										<option value="Chemicals ">Chemicals </option>
										<option value="Communications & Media">Communications & Media </option>
										<option value="Construction">Construction </option>
										<option value="Consumer Packaged Goods">Consumer Packaged Goods </option>
										<option value="Consumer Services">Consumer Services </option>
										<option value="Education ">Education </option>
										<option value="Energy">Energy </option>
										<option value="Financial Services - Banking">Financial Services - Banking </option>
										<option value="Financial Services - Capital Markets">Financial Services - Capital Markets </option>
										<option value="Financial Services - Insurance">Financial Services - Insurance </option>
										<option value="Government - Federal">Government - Federal </option>
										<option value="Government - State & Local">Government - State & Local </option>
										<option value="Healthcare">Healthcare </option>
										<option value="Horizontal">Horizontal </option>
										<option value="Life Sciences">Life Sciences </option>
										<option value="Manufacturing">Manufacturing</option>
										<option value="Mining & Querying ">Mining & Querying </option>
										<option value="Non-Profit">Non-Profit </option>
										<option value="Real Estate, Rental & Leasing">Real Estate, Rental & Leasing </option>
										<option value="Retail ">Retail </option>
										<option value="Technology - Hardware">Technology - Hardware </option>
										<option value="Technology - Software">Technology - Software </option>
										<option value="Transport & Logistics">Transport & Logistics </option>
										<option value="Travel & Leisure">Travel & Leisure </option>
										<option value="Utilities">Utilities </option>
									  </select>
									</div>

									<div class="section-field">
									  <label>Annual Company Revenue?</label>
									  <select name="revenue" class="phone form-control" required style="height: calc(3rem + 2px);">
									  <option value="">-- Select --</option>
									  <option value="Less than 2M">Less than 2M</option>
									  <option value="2-10M">2-10M</option>
									  <option value="10-50M">10-50M</option>
									  <option value="50-100M">50-100M</option>
									  <option value="100-500M">100-500M</option>
									  <option value="500-1B">500-1B</option>
									  <option value="1B+">1B+</option>
									  </select>
									</div>

									<label>Message</label>
									<textarea name="message" cols="30" rows="3" class="phone form-control" id="text"></textarea>
									<br>

									<div class="section-field">
									  <div class="g-recaptcha" data-sitekey="6Ldtzb4UAAAAAGnBmlLGQjPansZXAGZu4Bd1j8-I"></div>
									</div>

									<div class="section-field submit-button" style="padding-top: 15px;">
									  <input type="hidden" name="action" value="sendEmail"/>
									  <button id="submit" name="submit" type="submit" value="Send" class="button"> Submit </button>
									</div>
								</form>
							</div>
    					</div>
						
					</div>
				</div>
			</div>
		</div>
	</section>
