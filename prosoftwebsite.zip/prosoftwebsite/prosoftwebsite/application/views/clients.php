<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta name="author" content="" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<title>Prosoft e-Solutions | Clients</title>


<?php include 'header.php' ?>

<section class="page-title center light-overlay parallax" data-jarallax='{"speed": 0.6}' style="background-image: url(img/clients/client-banner.jpg);">
  <div class="container">
    <div class="row"> 
      <div class="col-lg-12"> 
      <div class="page-title-name">
          <h1 class="text-black">Clients</h1>
          <!-- <p class="text-black">We know the secret of your success</p> -->
        </div>
        <ul class="page-breadcrumb">
          <li><a href="index.php"><i class="fa fa-home"></i> Home</a> <i class="fa fa-angle-double-right"></i></li>
          <li><span>Clients</span> </li>
       </ul>
     </div>
     </div>
  </div>
</section>


<!-- Title -->
<section class="contact white-bg ">
  	<div class="container">
   		<div class="row justify-content-center">
       		<div class="col-lg-8">
          		<div class="section-title text-center">
            		<p>We are delighted to have them with us</p>
          		</div>
      		</div>
      	</div>
  	</div>
</section>


<section class="white-bg ">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 text-center">
          <div class="isotope-filters">
            <button data-filter="" class="active">All</button>
            <button data-filter=".analyzer">C5 CDR Analyzer</button>
            <button data-filter=".healthsoft">Healthsoft</button>
            <button data-filter=".erp">Enterprise Resource Planning</button>
            <button data-filter=".fleet">Fleet Management</button>
            <button data-filter=".payroll">Payroll</button>
          </div>
            
          <div class="isotope columns-5 popup-gallery ">

              <div class="grid-item analyzer">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-karnataka_state_police.jpg" alt="Prosoft-karnataka_state_police">
                  </div>
              </div>

              <div class="grid-item analyzer">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-CBI.jpg" alt="Prosoft-CBI">
                  </div>
              </div>

              <div class="grid-item healthsoft">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-zilla_panchayat.jpg" alt="Prosoft-zilla_panchayat">
                  </div>
              </div>

              <div class="grid-item analyzer">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-income_tax.png" alt="Prosoft-income_tax">
                  </div>
              </div>

              <div class="grid-item analyzer">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-NIA.jpg" alt="Prosoft-NIA">
                  </div>
              </div>

              <div class="grid-item analyzer">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-ED.jpg" alt="Prosoft-ED">
                  </div>
              </div>

              <div class="grid-item healthsoft">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-District_Health_F.W.Office.jpg" alt="Prosoft-District_Health_F.W.Office">
                  </div>
              </div>

              <div class="grid-item analyzer">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-RPF.jpg" alt="Prosoft-RPF">
                  </div>
              </div>

              <div class="grid-item healthsoft">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-malaria_office.jpg" alt="Prosoft-malaria_office">
                  </div>
              </div>

              <div class="grid-item analyzer">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-karnataka_forest_department.jpg" alt="Prosoft-karnataka_forest_department">
                  </div>
              </div>

              <div class="grid-item healthsoft">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-RNTCP_Office.jpg" alt="Prosoft-RNTCP Office">
                  </div>
              </div>

              <div class="grid-item analyzer">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-NASSCOM.jpg" alt="Prosoft-NASSCOM">
                  </div>
              </div>

              
              <div class="grid-item analyzer">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-C-DAC.jpg" alt="Prosoft-C-DAC">
                  </div>
              </div>

              
              <div class="grid-item analyzer">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-telangana_police.jpg" alt="Prosoft-telangana_police">
                  </div>
              </div>

              
              <div class="grid-item analyzer">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-cyberabad_police.jpg" alt="Prosoft-cyberabad_police">
                  </div>
              </div>

              <div class="grid-item analyzer">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-odisha_police.jpg" alt="Prosoft-odisha_police">
                  </div>
              </div>

              <div class="grid-item analyzer">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-bangalore_city_police.jpg" alt="Prosoft-bangalore_city_police">
                  </div>
              </div>

              <div class="grid-item analyzer">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-tamilnadu_police.jpg" alt="Prosoft-tamilnadu_police">
                  </div>
              </div>

              <div class="grid-item analyzer">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-bihar_police.jpg" alt="Prosoft-bihar_police">
                  </div>
              </div>

              <div class="grid-item analyzer">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-punjab_police.jpg" alt="Prosoft-punjab_police">
                  </div>
              </div>

              <div class="grid-item analyzer">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-kerala_police.jpg" alt="Prosoft-kerala_police">
                  </div>
              </div>

              <div class="grid-item analyzer">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-maharashtra_police.jpg" alt="Prosoft-maharashtra_police">
                  </div>
              </div>

              <div class="grid-item analyzer">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-gujrat_police.jpg" alt="Prosoft-gujrat_police">
                  </div>
              </div>

              <div class="grid-item analyzer">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-kolkata_police.jpg" alt="Prosoft-kolkata_police">
                  </div>
              </div>

              <div class="grid-item analyzer">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-rajasthan_police.jpg" alt="Prosoft-rajasthan_police">
                  </div>
              </div>

              <div class="grid-item analyzer">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-chhattisgarh_police.jpg" alt="Prosoft-chhattisgarh_police">
                  </div>
              </div>

              <div class="grid-item analyzer">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-mumbai_police.jpg" alt="Prosoft-mumbai_police">
                  </div>
              </div>

              <div class="grid-item analyzer">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-andhra_pradesh_police.jpg" alt="Prosoft-andhra_pradesh_police">
                  </div>
              </div>

              <div class="grid-item analyzer">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-west_bengal_police.jpg" alt="Prosoft-west_bengal_police">
                  </div>
              </div>

              <div class="grid-item analyzer">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-bangladesh_police.jpg" alt="Prosoft-bangladesh_police">
                  </div>
              </div>

              <div class="grid-item erp">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/netalkar1.png" alt="Prosoft-netalkar">
                  </div>
              </div>
              
              <div class="grid-item erp">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/netalkar2.png" alt="Prosoft-netalkar">
                  </div>
              </div>
              
              <div class="grid-item payroll">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/niyaaz.png" alt="Prosoft-niyaaz">
                  </div>
              </div>

              <div class="grid-item analyzer">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-algeria_police.jpg" alt="Prosoft-algeria_police">
                  </div>
              </div>

              <div class="grid-item analyzer">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-nigeria_police.jpg" alt="Prosoft-nigeria_police">
                  </div>
              </div>

              <div class="grid-item analyzer">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/prosoft-lokayukta.png" alt="Prosoft-lokayukta">
                  </div>
              </div>      

              <div class="grid-item fleet">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/SP_belgaum.png" alt="Prosoft-SP_belgaum">
                  </div>
              </div>

              <div class="grid-item fleet">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/SP_dharwad.png" alt="Prosoft-SP_dharwad">
                  </div>
              </div>

              <div class="grid-item fleet">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/SP_mangalore.png" alt="Prosoft-SP_mangalore">
                  </div>
              </div>

              <div class="grid-item fleet">
                  <div class="portfolio-item hover-item">
                    <img class="img-cl" src="img/clients/SI_bangalore.png" alt="Prosoft-SI_bangalore">
                  </div>
              </div>

          </div>
      </div>
    </div>
  </div> 
</section>


<?php include 'footer.php' ?>