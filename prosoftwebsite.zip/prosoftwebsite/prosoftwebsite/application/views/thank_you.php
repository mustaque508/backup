
<section class="ftco-section contact-section ftco-degree-bg mt-5">
   <div class="container">
      <div class="row justify-content-center mb-10 pb-3">
         <div class="col-md-4">
            <div class="py-4">
               <img class="img-fluid"  src="<?php echo base_url(); ?>dist/img/thankYouEmail.svg" alt="thankYouEmail.svg">
            </div>
         </div>
         <div class="col-md-8 mt-3">
            <div class="container">
               <div class="heading-section heading-section-black ftco-animate">
                  <h2 style="font-size: 30px;">THANK YOU!</h2>
                  <span id="spanID" class="subheading">Please check your email for  further details and the link to download the application.</span>
               </div>
               <div class="download-div ">
                  <div class="card shadow p-3 mb-5 bg-white   ftco-animate">
                     <div class="card-body">
                        <div class="qr_code">
                           <img src="<?php echo base_url();?>dist/img/c5appQR.png" alt="c5appQR.png" class="img-fluid qr_code_img  ">
                          
                        </div>
                        <div class="qr_code-content text-justify ">
                           <h5 class="text-dark">To continue CDR Analysis on the move, download the app now.</h5>
                            <a href="https://play.google.com/store/apps/details?id=com.prosoft.CDR_Analyzer" target="_blank"><img class="playstore-badge img-fluid"
                              src="<?php echo base_url(); ?>dist/img/google-play-badge.svg">
                           </a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>

