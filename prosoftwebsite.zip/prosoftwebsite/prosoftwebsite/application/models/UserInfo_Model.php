<?php
class UserInfo_Model extends CI_Model {
	
    function __construct()
    {
        //parent::__construct();
    }
	
	function save($full_name, $contact_no, $dept_email_id, $department, $designation, $address, 
						$serial_key, $razorpay_order_id, $razorpay_payment_id, $razorpay_signature, $status, $product_id)
	{
		try {
			$this->full_name = $full_name;
			$this->contact_no = $contact_no;
			$this->dept_email_id = $dept_email_id;
			$this->department = $department;
			$this->designation = $designation;
			$this->address = $address;

			$date = date('Y-m-d H:i:s');
			$this->created_dt = $date;
			$this->serial_key = $serial_key;

			$this->razorpay_order_id = $razorpay_order_id;
			$this->razorpay_payment_id = $razorpay_payment_id;
			$this->razorpay_signature = $razorpay_signature;
			$this->status = $status;
			$this->Product_ID = $product_id;			

			$this->installed_dt = $date;
		
			$this->db->insert('tbl_user_info', $this);
			$record_id =  $this->db->insert_id();			
				
			return $record_id;
		} catch(Exception $e) {	
			log_message('error', $e->getMessage());
			return -1;
		}
	}

	function update($user_id, $serial_key, $razorpay_order_id, $razorpay_payment_id, $razorpay_signature, $status){
		try {
			$this->db->where('id', $user_id);
			$this->db->update('tbl_user_info', array('serial_key' => $serial_key, 'razorpay_order_id' => $razorpay_order_id, 
											'razorpay_payment_id' => $razorpay_payment_id, 'razorpay_signature' => $razorpay_signature, 'status' => $status));

			return true;			
		} catch(Exception $e) {		
			log_message('error', $e->getMessage());
			return false;
		}
	}
}	
?>