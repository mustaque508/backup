<?php
class PartnerRegistration_Model extends CI_Model {
	
    function __construct()
    {
        //parent::__construct();
    }

	function save($p_name, $p_contact_no, $p_email, $company, $address, $country, $website, $message)
	{
		try 
		{
			$this->f_name = $p_name;
			$this->contact_no = $p_contact_no;
			$this->f_email = $p_email;
			$this->company = $company;
			$this->address = $address;
			$this->country = $country;
			$this->website = $website;
			$this->message = $message;

			$date = date('Y-m-d H:i:s');
			$this->registeredon = $date;
					
			$this->db->insert('PartnerRegistration', $this);
			$record_id =  $this->db->insert_id();		
					
			return $record_id;
		} catch(Exception $e) 
		{			
			return -1;
		}
	}
}	
?>