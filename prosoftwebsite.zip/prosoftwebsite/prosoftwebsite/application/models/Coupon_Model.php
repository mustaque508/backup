<?php
class Coupon_Model extends CI_Model {
	
    function __construct()
    {
        //parent::__construct();
    }

	//function save($coupon_code, $coupon_value, $coupon_percentage, $subscription_plan_no, $created_date, $expiry_date, 
	//					$issued_to, $issued_date, $issued_by, $is_used, $vendorID_customerID)	
	function save($coupon_code, $coupon_value, $coupon_percentage, $subscription_plan_no, 
						$issued_to, $vendorID_customerID)
	{
		try {
			$this->CouponCode = $coupon_code;
			$this->CouponValue = $coupon_value;
			$this->CouponPercentage = $coupon_percentage;
			$this->SubscriptionPlan_No = $subscription_plan_no;

			$date = date('Y-m-d H:i:s');

			$this->CreatedDate = $date; // $created_date
			$this->ExpiryDate = "2021-01-31 11:59:00";

			
			$this->IssuedTo = $issued_to;
			$this->IssuedDate = $date; // $issued_date

			$this->IssuedBy = "System";
			$this->IsUsed = 0; // $is_used
			$this->VendorID_CustomerID = $vendorID_customerID;
			
			$this->db->insert('Coupon', $this);
			$record_id =  $this->db->insert_id();		
				
			return $record_id;
		} catch(Exception $e) {			
			return -1;
		}
	}

	function update($coupon_code){
		try {
			$this->db->where('CouponCode', $coupon_code);
			$this->db->update('Coupon', array('IsUsed' => 1));

			return true;			
		} catch(Exception $e) {			
			return false;
		}
	}
}	
?>