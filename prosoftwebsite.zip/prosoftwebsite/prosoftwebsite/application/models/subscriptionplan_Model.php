<?php
class subscriptionplan_Model extends CI_Model {
	
    function __construct()
    {
        //parent::__construct();
    }

	function get_subscriptions()
	{
		$sql = "SELECT SubscriptionPlan_No, Product_ID, Product_Name, [Edition],
                        SubscriptionName
                        ,Amount_Before_GST
                        ,GST
                        ,Amount_After_GST
						,OfferPrice
						
                    FROM [SubscriptionPlan]"			
                    ;
		
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0) 
		{
			return $query->result();
		}
		else
		{
			return 0;
		}
	}	

	function get_selected_subscriptions($subscriptionname)
	{
		$sql = "SELECT SubscriptionPlan_No, Product_ID, Product_Name, [Edition],
                    SubscriptionName
                    ,Amount_Before_GST
                    ,GST
                    ,Amount_After_GST
					,OfferPrice
                    FROM [SubscriptionPlan]
                        WHERE SubscriptionName = '". $subscriptionname ."'";
			
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0) 
		{
			return $query;
		}
		else
		{
			return 0;
		}
	}


	// get offer for PR_coupon
	public function getPR_offer($PR_coupon)
	{

		// fetch data from database
			$sql="SELECT 
					cc.[ID]
		   			,[CouponCode]
		   			,OfferPrice = ([OfferPrice]-[CouponValue])
		   			,sp.Product_ID
		   			,cc.SubscriptionPlan_No
		   			,cc.ExpiryDate
					,sp.Product_Name
					,cc.IsUsed
   					FROM  [Coupon] cc
		   			INNER JOIN [SubscriptionPlan] sp ON sp.[SubscriptionPlan_No] = cc.[SubscriptionPlan_No]
					INNER JOIN [Product] mr ON mr.[Product_ID] = sp.[Product_ID]
   					WHERE CouponCode = '".$PR_coupon."' and CouponCode Like 'P%' and ExpiryDate >= getdate()";

		$query=$this->db->query($sql);

		if($query->num_rows()>0)
		{
			return $query->result();
		}
		else{
			return "";
		}

		
					
	}


		// get offer for S1_coupon
		public function getS1_offer($S1_coupon)
		{
	
			// fetch data from database
				$sql="SELECT 
						cc.[ID]
						   ,[CouponCode]
						   ,OfferPrice = ([OfferPrice]-[CouponValue])
						   ,sp.Product_ID
						   ,cc.SubscriptionPlan_No
						   ,cc.ExpiryDate
						   ,sp.Product_Name
						   ,cc.IsUsed
						   FROM  [Coupon] cc
						   INNER JOIN [SubscriptionPlan] sp ON sp.[SubscriptionPlan_No] = cc.[SubscriptionPlan_No]
						   INNER JOIN [Product] mr ON mr.[Product_ID] = sp.[Product_ID]
						   WHERE CouponCode = '".$S1_coupon."' and CouponCode Like 'S%' and ExpiryDate >= getdate()";
	
			$query=$this->db->query($sql);
	
			if($query->num_rows()>0)
			{
				return $query->result();
			}
			else{
				return "";
			}
	
			
						
		}
	
	
	//get PR base price
	// public function getPRBase()
	// {
	// 	// $result=array(
	// 	// 	'PR-base-price':'29500',
	// 	// 	'PR-Product_Name':'C5 CDR ANALYZER v5.0',
	// 	// 	'PR-SubscriptionPlan_No':'1',
	// 	// 	'PR-CouponCode':'none'
	// 	// );

	// 	// return $result;

	// }
    
}	
?>