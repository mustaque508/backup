<?php
class ContactUs_Model extends CI_Model {
	
    function __construct()
    {
        //parent::__construct();
    }
	
	function save($f_name, $contact_no, $f_email, $subject, $message)
	{
		$this->f_name = $f_name;
		$this->contact_no = $contact_no;
		$this->f_email = $f_email;
		$this->subject = $subject;
		$this->message = $message;

		$date = date('Y-m-d H:i:s');
		$this->contacted_on = $date;
				
		$this->db->insert('tbl_contact_us', $this);
		$record_id =  $this->db->insert_id();		
				
		return $record_id;
	}
}	
?>