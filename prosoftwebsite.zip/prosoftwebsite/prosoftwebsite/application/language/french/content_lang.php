<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$lang['welcome'] = 'Bienvenue sur notre site';
$lang['message'] = 'Notre mission est de fournir des services de conception Web professionnels et très créatifs, ainsi que d’autres services connexes, à un large éventail de clients potentiels dans le monde entier.';
