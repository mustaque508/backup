<?php

$keyId = "rzp_test_QFP1hE86BMyeon";
$keySecret = "aN6dD5jKwU5h37eaHUsn6j67";
$displayCurrency = 'INR';

//These should be commented out in production
// This is for error reporting
// Add it to config.php to report any errors
// error_reporting(E_ALL);
// ini_set('display_errors', 1);

?>