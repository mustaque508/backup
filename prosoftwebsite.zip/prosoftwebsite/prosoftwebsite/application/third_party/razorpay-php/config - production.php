<?php
$keyId = "rzp_live_khui6DI1WoAHE4";
$keySecret = "JaiV3h5MjrL4s7savO0waMN6";

$displayCurrency = 'INR';

//These should be commented out in production
// This is for error reporting
// Add it to config.php to report any errors
// error_reporting(E_ALL);
// ini_set('display_errors', 1);

?>