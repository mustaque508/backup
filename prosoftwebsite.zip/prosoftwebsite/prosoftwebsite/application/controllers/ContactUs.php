<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ContactUs extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	
	public function index($array_error_data = array())
	{
		if (empty($array_error_data)) {
			// set default array of errors
			$array_error_data = array(
				'response'  => "",
				'f_name_error'     => "",
				'f_contact_error' => "",
				'f_email_error' => "",
				'f_subject_error' => "",
				'f_message_error' => ""
			);
		}

		$this->load->view('header');								
		$this->load->view('contact_us', $array_error_data);
		$this->load->view('footer');
	}

	public function save(){
		try {
			$f_name = $_POST['f_name'];
			$contact_no = $_POST['contact_no'];
			$f_email = $_POST['f_email'];
			$subject = $_POST['subject'];
			$message = $_POST['message'];

			$f_name = strip_tags($f_name);
			$f_name = addslashes($f_name);
			$f_name = filter_var($f_name, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);

			$f_email = strip_tags($f_email);
			//$f_email = filter_var($f_email, FILTER_SANITIZE_EMAIL);
			//$f_email = filter_var($f_email, FILTER_VALIDATE_EMAIL);
			$f_email = addslashes($f_email);
			$f_email = filter_var($f_email, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);

			$subject = strip_tags($subject);
			$subject = addslashes($subject);
			$subject = filter_var($subject, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);

			$message = strip_tags($message);
			$message = addslashes($message);
			$message = filter_var($message, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);

			$this->clear_session();

			// set array of user info in session
			$arraydata = array(				
                'cont_name'     => $f_name,
				'cont_contact' => $contact_no,
                'cont_email' => $f_email,				
				'cont_subject' => $subject,
				'cont_message' => $message
			);
			$this->session->set_userdata($arraydata);

			
			$captcha;
			if(isset($_POST['g-recaptcha-response'])){
				$captcha=$_POST['g-recaptcha-response'];
			}

			if(!$captcha){
				$this->index("Please validate the recaptcha.");
			 	return;
			}

			$secretKey = "6Ldtzb4UAAAAAAa5r47B3tweq9YZwvK0U5L9W8si";
			$ip = $_SERVER['REMOTE_ADDR'];
			// post request to server
			$url =  'https://www.google.com/recaptcha/api/siteverify?secret=' . urlencode($secretKey) .  '&response=' . urlencode($captcha);
			$response = file_get_contents($url);
			$responseKeys = json_decode($response,true);
			
			//$responseKeys["success"] = true;

			if($responseKeys["success"] == false) 
			{
				//$this->on_error_redirect("Please validate the recaptcha.");
				$this->index("Please validate the recaptcha.");
				return;
			}

			$val_result = $this->validate($f_name, $contact_no, $f_email, $subject, $message);

			if ($val_result) {
				$this->load->model('ContactUs_Model');
				$response = $this->ContactUs_Model->save($f_name, $contact_no, $f_email, $subject, $message);

				if ($response > 0){					
					$this->send_mail($f_name, $f_email, $subject, $message);
					redirect('index.php/Greeting/contact');
				} else {
					$this->index("Failed to save contact us information.");
				}
			}
		}catch(Exception $e) {			
			$this->Index("Error while submitting the user information. Error : " . $e->getMessage());
		}
	}

	public function validate($f_name, $contact_no, $f_email, $subject, $message) {		
		$f_name_error = "";
		$f_contact_error = "";
		$f_email_error = "";
		$f_subject_error = "";
		$f_message_error = "";

		$f_name = $this->test_input($f_name);
		// check if name only contains letters and whitespace
		if (!preg_match("/^[a-zA-Z ]*$/",$f_name)) {
			$f_name_error = "Only letters and white space allowed";
		}	
		
		$contact_no = $this->test_input($contact_no);
		// check if contact number is correct
		if(preg_match('/^\d{10}$/',$contact_no) == false){
			$f_contact_error = "Only numeric value and with 10 digit is allowed.";		
		}

		$f_email = $this->test_input($f_email);
		// check if e-mail address is well-formed
		//if (!filter_var($f_email, FILTER_VALIDATE_EMAIL)) {
		if ($this->valid_email($f_email) === false) {
			$f_email_error = "Invalid email format.";
		}

		$subject = $this->test_input($subject);		
		if ($subject === "") {
			$f_subject_error = "Subject cannot be empty.";
		}

		$message = $this->test_input($message);		
		if ($message === "") {
			$f_message_error = "Message cannot be empty.";
		}

		$array_error_data = array();

		if ($f_name_error != "" || $f_contact_error != "" || $f_email_error != "" || $f_subject_error != "" || $f_message_error != ""){
			$this->on_error_redirect("Invalid input.", $f_name_error, $f_contact_error, 
				$f_email_error, $f_subject_error, $f_message_error);
			
			return false;
		} else {
			return true;
		}		
	}

	////Check user input characters
	function test_input($data) {
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}

	////Check if valid email id
	function valid_email($str) {
		return (!preg_match("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$^", $str)) ? false : true;
	}

	private function on_error_redirect($error = "", $f_name_error = "", $f_contact_error = "", 
		$f_email_error = "", $f_subject_error = "", $f_message_error = "")
	{
		$error = ($error !== "") ? "ERROR : " . $error : "";
		$f_name_error = ($f_name_error !== "") ? "*" . $f_name_error : "";
		$f_contact_error = ($f_contact_error !== "") ? "*" . $f_contact_error : "";
		$f_email_error = ($f_email_error !== "") ? "*" . $f_email_error : "";
		$f_subject_error = ($f_subject_error !== "") ? "*" . $f_subject_error : "";
		$f_message_error = ($f_message_error !== "") ? "*" . $f_message_error : "";

		// set array of errors
		$array_error_data = array(
			'response'  => $error,
			'f_name_error'     => $f_name_error,
			'f_contact_error' => $f_contact_error,
			'f_email_error' => $f_email_error,
			'f_subject_error' => $f_subject_error,
			'f_message_error' => $f_message_error
		);
		
		$this->index($array_error_data);		
	}

	// Clear previous session
	public function clear_session(){		
		$array_items = array('cont_name', 'cont_contact', 'cont_email', 'cont_subject', 'cont_message');
		$this->session->unset_userdata($array_items);
	}

	//// Send email
	public function send_mail($f_name, $f_email, $subject, $message) {
		try{
			$from_email = "noreply@prosoftesolutions.com";
			$to_email = "prosoft.esolution@gmail.com"; // "prosoft.esolution@gmail.com";

			$body = "<b>Customer Name : </b>" . $f_name . "<br><b>Email : </b>" . $f_email . "<br><b>Subject : </b>" . $subject . "<br><b>message : </b>" . $message . "";

			//Load email library
			$this->load->library('email');
			$config = array();
			$config['protocol'] = 'smtp';
			$config['smtp_host'] = 'smtp.mailhostbox.com';
			$config['smtp_user'] = $from_email;
			$config['smtp_pass'] = 'ProUser@123';
			$config['smtp_port'] = 587;
			$this->email->initialize($config);
			$this->email->set_newline("\r\n");

			$this->email->from($from_email, 'Prosoft e-Solutions Ind Pvt Ltd');
			$this->email->to($to_email);
			$this->email->subject('Customer Query/Complaint/Feedback');
			$this->email->message($body);
			$this->email->set_mailtype("html");

			//Send mail
			if($this->email->send())
				return true;
			else
				return false;
		} catch(Exception $e) {
			return false;
		}
    }
} ?>
