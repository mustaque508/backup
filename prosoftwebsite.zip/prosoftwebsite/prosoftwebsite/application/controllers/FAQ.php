<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class FAQ extends CI_Controller 
{

	public function index()
	{
	    $this->load->view('header');								
		$this->load->view('FAQInfo');
		$this->load->view('footer');
	}	
} ?>

