<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class SubscriptionPlan extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	
	public function index()
	{
		$error = "";
		if(isset($_GET['error'])) {
		 	$error = $_GET['error'];
		}

		// $data['new_subscriptionname'] = $subscriptionname;

		$this->load->model('subscriptionplan_Model');
		$data = $this->subscriptionplan_Model->get_subscriptions();
		$getdata['data']=json_encode($data);
		$getdata['error']=$error;

		$this->load->view('header');
		$this->load->view('subscriptionplan', $getdata);
		$this->load->view('footer');
	}	

    public function get_subscriptions_details()
	{
		$subscriptionname = $_GET['subscriptionname'];
		// $subscriptionname = $this->filter_field($subscriptionname);
		
		$this->load->model('subscriptionplan_Model');
		$data = $this->subscriptionplan_Model->get_selected_subscriptions($subscriptionname);
		
		if (!is_int($data))
		{
			if ($data->num_rows() > 0){
				echo json_encode($data->result());
			} else {
				echo json_encode(110);
			}
		}
		else
		{
			echo json_encode(110);
		}		
    }
    
	public function get_subscriptions()
	{
		$this->load->model('subscriptionplan_Model');
		$data = $this->subscriptionplan_Model->get_subscriptions();
		
		if (!is_int($data))
		{
			if ($data->num_rows() > 0){
				echo json_encode($data->result());
			} else {
				echo json_encode(110);
			}
		}
		else
		{
			echo json_encode(110);
		}
	}


	// get  PR coupon offer
	public function getPROffer_details()
	{
		sleep(1);
		$PR_coupon=$this->input->post('PR_coupon');

		$result=$this->subscriptionplan_Model->getPR_offer($PR_coupon);

		if(!empty($result)){
			echo json_encode($result);
		}
		else{
			echo json_encode(110);
		}
	}

	// get  S1 coupon offer
	public function getS1Offer_details()
	{
		sleep(1);
		$S1_coupon=$this->input->post('S1_coupon');

		$result=$this->subscriptionplan_Model->getS1_offer($S1_coupon);

		if(!empty($result)){
			echo json_encode($result);
		}
		else{
			echo json_encode(110);
		}
	}

	public function set_general_session(){
		$this->session->set_userdata("OfferType",$this->input->post("OfferType"));
		$this->session->set_userdata("ProductID",$this->input->post("ProductID"));
		$this->session->set_userdata("OfferPrice",$this->input->post("OfferPrice"));
		$this->session->set_userdata("Product_Name",$this->input->post("Product_Name"));
		$this->session->set_userdata("SubscriptionPlan_No",$this->input->post("SubscriptionPlan_No"));
		$this->session->set_userdata("CouponCode",$this->input->post("CouponCode"));
		$this->session->set_userdata("base_price",$this->input->post("base_price"));
		$this->session->set_userdata("SubscriptionPlan_Name",$this->input->post("SubscriptionPlan_Name"));

		echo json_encode(121);
	}

	// PR coupon base price
	public function getPRBase_details()
	{
		// echo json_encode(121);
		$result=$this->subscriptionplan_Model->get_subscriptions();

		if(!empty($result))
		{
			echo json_encode($result);
		}
		else
		{
			echo json_encode(110);
		}
	}
}
?>
