<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	
	public function index()
	{		
		if(!isset($_SESSION["site_lang"])){ 
			$this->session->set_userdata('site_lang',  "english");
		} 
		
		$this->load->view('header');								
		$this->load->view('main');
		$this->load->view('footer');
	}
	
	public function switchLang($language = "") 
	{
		$this->session->set_userdata('site_lang', $language);
		header('Location: https://prosoftesolutions.com/');
	}
   
	/* public function signout()
	{
		$s_lang = $this->session->userdata('site_lang');
		$this->session->sess_destroy(); 		
		$this->switchLang($s_lang);
	} */
} ?>
