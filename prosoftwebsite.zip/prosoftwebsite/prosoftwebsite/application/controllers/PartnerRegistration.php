<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class PartnerRegistration extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */

	public function index($array_error_data = array())
	{		

		//$this->session->sess_destroy();
		//$this->session->set_userdata('edition', $edition);
				
		if (empty($array_error_data)) {
			// set default array of errors
			$array_error_data = array(
				'error'  => "",
				'p_name_error'     => "",				
				'p_contact_error' => "",				
				'p_email_error' => "",
				'p_company_error' => "",
				'p_message_error' => ""
			);
		}

		$this->load->view('header');								
		$this->load->view('partner_registration', $array_error_data);
		$this->load->view('footer');
	}	
		
	public function save(){
		try {

			$p_name = $_POST['p_name'];
			$p_contact_no = $_POST['p_contact_no'];
			$p_email = $_POST['p_email'];
			$company = $_POST['company'];
			$address = $_POST['address'];
			$country = $_POST['country'];
			$website = $_POST['website'];
			$message = $_POST['message'];

			$p_name = htmlspecialchars($p_name);
			$p_contact_no = htmlspecialchars($p_contact_no);
			$p_email = htmlspecialchars($p_email);
			$company = htmlspecialchars($company);
			$address = htmlspecialchars($address);
			$country = htmlspecialchars($country);
			$website = htmlspecialchars($website);
			$message = htmlspecialchars($message);

			$p_name = strip_tags($p_name);
			$p_name = addslashes($p_name);
			$p_name = filter_var($p_name, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);

			$p_contact_no = strip_tags($p_contact_no);
			$p_contact_no = filter_var($p_contact_no, FILTER_VALIDATE_INT);

			$p_email = strip_tags($p_email);
			//$p_email = filter_var($p_email, FILTER_SANITIZE_EMAIL);
			//$p_email = filter_var($p_email, FILTER_VALIDATE_EMAIL);
			$p_email = addslashes($p_email);
			$p_email = filter_var($p_email, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);

			$company = strip_tags($company);
			$company = addslashes($company);
			$company = filter_var($company, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);

			$address = strip_tags($address);
			$address = addslashes($address);
			$address = filter_var($address, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);

			$country = strip_tags($country);
			$country = addslashes($country);
			$country = filter_var($country, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);

			$website = strip_tags($website);
			$website = addslashes($website);
			$website = filter_var($website, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);

			$message = strip_tags($message);
			$message = addslashes($message);
			$message = filter_var($message, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);

			$this->clear_session();

			// set array of user info in session
			$arraydata = array(
				'p_name'     => $p_name,
				'p_contact_no' => $p_contact_no,
                'p_email' => $p_email,
				'company' => $company,
				'address' => $address,
				'country' => $country,
				'website' => $website,
				'message' => $message
			);

			$this->session->set_userdata($arraydata);				

			$captcha;
			if(isset($_POST['g-recaptcha-response'])){
				$captcha=$_POST['g-recaptcha-response'];
			}

			if(!$captcha){
				//$this->Index("Please Validate the Captcha.");
				$this->on_error_redirect("Please Validate the Captcha.");
			 	return;
			}

			$secretKey = "6Ldtzb4UAAAAAAa5r47B3tweq9YZwvK0U5L9W8si";
			$ip = $_SERVER['REMOTE_ADDR'];
			// post request to server
			$url =  'https://www.google.com/recaptcha/api/siteverify?secret=' . urlencode($secretKey) .  '&response=' . urlencode($captcha);
			$response = file_get_contents($url);
			$responseKeys = json_decode($response,true);
			
			//$responseKeys["success"] = true;

			if($responseKeys["success"] == false) 
			{
				// 	//$this->Index("Please Validate the Captcha.");
				$this->on_error_redirect("Please validate the recaptcha.");
				return;
			}

			$val_result = $this->validate($p_name, $p_contact_no, $p_email, $company, $message);

			if ($val_result) {
				$this->load->model('PartnerRegistration_Model');
				$response = $this->PartnerRegistration_Model->save($p_name, $p_contact_no, $p_email, $company, $address, $country, $website, $message);

				if ($response > 0){
					$this->send_mail($p_name, $p_contact_no, $p_email, $company, $address, $country, $website, $message);
					$this->clear_session();
					redirect('index.php/Greeting/PartnerRegistration');
				} else {
					$this->on_error_redirect("Failed to save partner's information.");
					// $this->index("Failed to save partner's information.");
				}
			}
		}catch(Exception $e) {			
			//$this->Index("Error while submitting the user information. Error : " . $e->getMessage());
			$this->on_error_redirect("Error while submitting the partner registration information. Error : " . $e->getMessage());
		}
	}

	// Clear previous session
	public function clear_session(){		
		$array_items = array('p_name', 'p_email', 'p_contact_no', 'company', 'address', 
							'country', 'website', 'message');
		$this->session->unset_userdata($array_items);
	}


	public function validate($p_name, $p_contact_no, $p_email, $company, $message) {		
		$p_name_error = "";
		$p_contact_error = "";
		$p_email_error = "";
		$p_company_error = "";		
		$p_message_error = "";

		$p_name = $this->test_input($p_name);
		// check if name only contains letters and whitespace
		if (!preg_match("/^[a-zA-Z ]*$/",$p_name)) {
			$p_name_error = "Only letters and white space allowed";
		}	
		
		$p_contact_no = $this->test_input($p_contact_no);
		// check if contact number is correct
		if(preg_match('/^\d{10}$/',$p_contact_no) == false){
			$p_contact_error = "Only numeric value and with 10 digit is allowed.";		
		}

		$p_email = $this->test_input($p_email);
		// check if e-mail address is well-formed
		//if (!filter_var($p_email, FILTER_VALIDATE_EMAIL)) {
		if ($this->valid_email($p_email) === false) {
			$p_email_error = "Invalid email format.";
		}

		if ($p_name_error != "" || $p_contact_error != "" || $p_email_error != "" || $p_company_error != "" || $p_message_error != ""){
			$this->on_error_redirect("Invalid input.", $p_name_error, $p_contact_error, 
				$p_email_error, $p_company_error, $p_message_error);
			return false;
		} else {
			return true;
		}
	}

	////Check user input characters
	function test_input($data) {
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}

	////Check if valid email id
	function valid_email($str) {
		return (!preg_match("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$^", $str)) ? false : true;
	}

	private function on_error_redirect($error = "", $p_name_error = "", $p_contact_error = "", $p_email_error = "", $p_company_error = "", $p_message_error = "")
	{
		//$edition = $this->session->userdata('edition');

		$error = ($error !== "") ? "ERROR : " . $error : "";
		$p_name_error = ($p_name_error !== "") ? "*" . $p_name_error : "";
		$p_contact_error = ($p_contact_error !== "") ? "*" . $p_contact_error : "";		
		$p_email_error = ($p_email_error !== "") ? "*" . $p_email_error : "";
		$p_company_error = ($p_company_error !== "") ? "*" . $p_company_error : "";
		$p_message_error = ($p_message_error !== "") ? "*" . $p_message_error : "";

		// set array of errors
		$array_error_data = array(
			'error'  => $error,
			'p_name_error' => $p_name_error,
			'p_contact_error' => $p_contact_error,			
			'p_email_error' => $p_email_error,
			'p_company_error' => $p_company_error,
			'p_message_error' => $p_message_error			
		);
		
		$this->index($array_error_data);		
	}

	public function send_mail($p_name, $p_contact_no, $p_email, $company, $address, $country, $website, $message) {
		try{
			$from_email = "noreply@prosoftesolutions.com";
			$to_email = "prosoft.esolution@gmail.com";
			$cc_email = "sales@prosoftesolutions.com"; //, info@prosoftesolutions.com"; // "prosoft.esolution@gmail.com";
			$subject = "Partner Request from : " . $p_name . " | " . $company . " | " . $country;

			$body = 
			"<b>Contact Name : </b>" . $p_name . 
			"<br><b>Email : </b>" . $p_email . 
			"<br><b>Contact : </b>" . $p_contact_no . 
			"<br><b>Company : </b>" . $company . 
			"<br><b>Address : </b>" . $address . 
			"<br><b>Country : </b>" . $country . 
			"<br><b>Website : </b>" . $website . 
			"<br><b>Message : </b>" . $message . "";

			//Load email library
			$this->load->library('email');
			$config = array();
			$config['protocol'] = 'smtp';
			$config['smtp_host'] = 'smtp.mailhostbox.com';
			$config['smtp_user'] = $from_email;
			$config['smtp_pass'] = 'ProUser@123';
			$config['smtp_port'] = 587;
			$this->email->initialize($config);
			$this->email->set_newline("\r\n");

			$this->email->from($from_email, 'Prosoft e-Solutions India Pvt Ltd');
			$this->email->to($to_email);
			$this->email->cc($cc_email);
			 

			$this->email->subject($subject);
			$this->email->message($body);
			$this->email->set_mailtype("html");

			//Send mail
			if($this->email->send())
				return true;
			else
				return false;
		} catch(Exception $e) {
			return false;
		}
    }
} 
?>
