<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;

class UserInfo extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */	
	
	 /*
	function __construct() {
		parent :: __construct();

		include APPPATH . 'third_party/razorpay-php/config.php';
		include APPPATH . 'third_party/razorpay-php/Razorpay.php';
	}
	*/

	public function index($array_error_data = array(), $m_edition = "")
	{		
		$edition = "TRIAL";

		if (isset($_GET['edition'])){
			$edition = $_GET['edition'];
		} else if ($m_edition !== "") {
			$edition = $m_edition;
		}

		//$this->session->sess_destroy();
		$this->session->set_userdata('edition', $edition);
				
		if (empty($array_error_data)) {
			// set default array of errors
			$array_error_data = array(
				'error'  => "",
				'f_name_error'     => "",
				'f_contact_error' => "",
				'f_department_error' => "",
				'f_email_error' => ""
			);
		}

		$this->load->view('header');								
		$this->load->view('user_info', $array_error_data);
		$this->load->view('footer');
	}
	
	public function submit()
	{
		try {
		
			$edition = $this->session->userdata('edition');
			
			// This should be reciept number
			$unique_id = $this->getGUID();

			$f_name = $_POST['f_name'];
			$f_email =$_POST['f_email'];
			$f_contact = $_POST['f_contact'];
			$f_department = $_POST['f_department'];
			$f_designation = $_POST['f_designation'];
			$f_address = $_POST['f_address'];

			$f_name = htmlspecialchars($f_name);
			$f_email = htmlspecialchars($f_email);
			$f_contact = htmlspecialchars($f_contact);
			$f_department = htmlspecialchars($f_department);
			$f_designation = htmlspecialchars($f_designation);
			$f_address = htmlspecialchars($f_address);

			$f_name = strip_tags($f_name);
			$f_name = addslashes($f_name);
			$f_name = filter_var($f_name, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);

			$f_email = strip_tags($f_email);
			//$f_email = filter_var($f_email, FILTER_SANITIZE_EMAIL);
			//$f_email = filter_var($f_email, FILTER_VALIDATE_EMAIL);
			$f_email = addslashes($f_email);
			$f_email = filter_var($f_email, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);

			//$f_contact = strip_tags($f_contact);
			//$f_contact = filter_var($f_contact, FILTER_VALIDATE_INT);

			$f_department = strip_tags($f_department);
			$f_department = addslashes($f_department);
			$f_department = filter_var($f_department, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);

			$f_designation = strip_tags($f_designation);
			$f_designation = addslashes($f_designation);
			$f_designation = filter_var($f_designation, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);

			$f_address = strip_tags($f_address);
			$f_address = addslashes($f_address);
			$f_address = filter_var($f_address, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);

			$this->clear_session();

			// set array of user info in session
			$arraydata = array(
				'unique_id' => $unique_id,
                'edition'  => $edition,
                'f_name'     => $f_name,
                'f_email' => $f_email,
				'f_contact' => $f_contact,
				'f_department' => $f_department,
				'f_designation' => $f_designation,
				'f_address' => $f_address
			);
			$this->session->set_userdata($arraydata);			
		
			/*
			$captcha;
			if(isset($_POST['g-recaptcha-response'])){
			 	$captcha=$_POST['g-recaptcha-response'];
			}

			if(!$captcha){
			 	$this->on_error_redirect("Please Validate the Captcha.");
			  	return;
			}

			$secretKey = "6Ldtzb4UAAAAAAa5r47B3tweq9YZwvK0U5L9W8si";
			$ip = $_SERVER['REMOTE_ADDR'];
			// // post request to server
			$url =  'https://www.google.com/recaptcha/api/siteverify?secret=' . urlencode($secretKey) .  '&response=' . urlencode($captcha);
			$response = file_get_contents($url);
			$responseKeys = json_decode($response,true);
			*/
			$responseKeys["success"] = true;

			if($responseKeys["success"] == false) 
			{
				$this->on_error_redirect("Please validate the recaptcha.");
				return;
			}									

			$val_result = $this->validate($f_name, $f_email, $f_contact, $f_department, 
						$f_designation, $f_address);
				
			if ($val_result) {
				//Save user information into our database (MySql)
				$this->load->model('UserInfo_Model');
					$user_id = $this->UserInfo_Model->save($f_name, $f_contact, $f_email, 
										$f_department, $f_designation, $f_address, "", "", "", "", "", "");
				if ($user_id > 0){
					//Store saved record id into session
					$this->session->set_userdata('user_id', $user_id);

					if ($edition == "TRIAL") {					
						$this->on_order_placed("", "", "", "TRIAL");
					
					} else {					
						$this->goto_payment();		
					}
				} else {
					$this->on_error_redirect("Failed to save user information.");
				}
			}
		}
		catch(Exception $e) {			
			$this->on_error_redirect("Error while submitting the user information. Error : " . $e->getMessage());
			return;
		}
	}

	public function submitLite()
	{
		try {
			// This should be reciept number
			$unique_id = $this->getGUID();

			$edition = "LITE";

			$f_name = $_POST['f_name'];
			$f_email =$_POST['f_email'];
			$f_contact = $_POST['f_contact'];
			$f_department = $_POST['f_department'];
			$f_designation = $_POST['f_designation'];
			$f_address = $_POST['f_address'];

			$f_name = htmlspecialchars($f_name);
			$f_email = htmlspecialchars($f_email);
			$f_contact = htmlspecialchars($f_contact);
			$f_department = htmlspecialchars($f_department);
			$f_designation = htmlspecialchars($f_designation);
			$f_address = htmlspecialchars($f_address);

			$f_name = strip_tags($f_name);
			$f_name = addslashes($f_name);
			$f_name = filter_var($f_name, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);

			$f_email = strip_tags($f_email);
			//$f_email = filter_var($f_email, FILTER_SANITIZE_EMAIL);
			//$f_email = filter_var($f_email, FILTER_VALIDATE_EMAIL);
			$f_email = addslashes($f_email);
			$f_email = filter_var($f_email, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);

			//$f_contact = strip_tags($f_contact);
			//$f_contact = filter_var($f_contact, FILTER_VALIDATE_INT);

			$f_department = strip_tags($f_department);
			$f_department = addslashes($f_department);
			$f_department = filter_var($f_department, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);

			$f_designation = strip_tags($f_designation);
			$f_designation = addslashes($f_designation);
			$f_designation = filter_var($f_designation, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);

			$f_address = strip_tags($f_address);
			$f_address = addslashes($f_address);
			$f_address = filter_var($f_address, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);

			$this->clear_session();

			// set array of user info in session
			$arraydata = array(
				'unique_id' => $unique_id,
                'edition'  => $edition,
                'f_name'     => $f_name,
                'f_email' => $f_email,
				'f_contact' => $f_contact,
				'f_department' => $f_department,
				'f_designation' => $f_designation,
				'f_address' => $f_address
			);
			$this->session->set_userdata($arraydata);

			/*
			$this->session->set_userdata("f_name",$this->input->post("f_name"));
			$this->session->set_userdata("f_contact",$this->input->post("f_contact"));
			$this->session->set_userdata("f_email",$this->input->post("f_email"));
			$this->session->set_userdata("f_department",$this->input->post("f_department"));
			$this->session->set_userdata("f_designation",$this->input->post("f_designation"));
			$this->session->set_userdata("f_address",$this->input->post("f_address"));
			*/
			
			$captcha;
			if(isset($_POST['g-recaptcha-response'])){
			 	$captcha=$_POST['g-recaptcha-response'];
			}

			if(!$captcha){
			$this->on_error_redirect("Please Validate the Captcha.");
			 	return;
			}

			$secretKey = "6Ldtzb4UAAAAAAa5r47B3tweq9YZwvK0U5L9W8si";
			$ip = $_SERVER['REMOTE_ADDR'];
			// // post request to server
			$url =  'https://www.google.com/recaptcha/api/siteverify?secret=' . urlencode($secretKey) .  '&response=' . urlencode($captcha);
			$response = file_get_contents($url);
			$responseKeys = json_decode($response,true);
			
			//$responseKeys["success"] = true;

			if($responseKeys["success"] == false) 
			{
				$this->on_error_redirect("Please validate the recaptcha.");
				return;
			}

			$val_result = $this->validate($f_name, $f_email, $f_contact, $f_department, 
						$f_designation, $f_address);
				
			if ($val_result) {
				//Save user information into our database (MySql)
				$this->load->model('UserInfo_Model');
					$product_id = $this->session->userdata("PR_ProductID");
					$user_id = $this->UserInfo_Model->save($f_name, $f_contact, $f_email, 
										$f_department, $f_designation, $f_address, "", "", "", "", "PENDING", $product_id);
				if ($user_id > 0){
					//Store saved record id into session
					$this->session->set_userdata('user_id', $user_id);
				} else {
					$this->on_error_redirect("Failed to save user information.");
					return;
				}
			}
		}
		catch(Exception $e) {			
			$this->on_error_redirect("Error while submitting the Lite user information. Error : " . $e->getMessage());
			return;
		}

		/*
		//submit page for  PR coupon code
		if($this->input->get("id")==md5("PR"))
		{
			if($this->session->userdata("PR_OfferPrice"))
			{
				$PR_data=array(
					'PR_OfferPrice'=>$this->session->userdata("PR_OfferPrice"),
					'PR_Product_Name'=>$this->session->userdata("PR_Product_Name"),
					'PR_SubscriptionPlan_No'=>$this->session->userdata("PR_SubscriptionPlan_No"),
					'PR_CouponCode'=>$this->session->userdata("PR_CouponCode"),
					'PR_base_price'=>$this->session->userdata("PR_base_price"),
					'PR_SubscriptionPlan_Name'=>$this->session->userdata("PR_SubscriptionPlan_Name"),
					'f_name'=>$this->session->userdata("f_name"),
					'f_contact'=>$this->session->userdata("f_contact"),
					'f_email'=>$this->session->userdata("f_email"),
					'f_department'=>$this->session->userdata("f_department"),
					'f_designation'=>$this->session->userdata("f_designation"),
					'f_address'=>$this->session->userdata("f_address")
				);

				$this->load->view('header');
				$this->load->view('order_review',$PR_data);
				$this->load->view('footer'); 
			}				
		}
	
		// submit page for S1 coupon code
		else if($this->input->get("id")==md5("S1"))
		{
			if($this->session->userdata("S1_OfferPrice"))
			{
				$S1_data=array(
					'S1_OfferPrice'=>$this->session->userdata("S1_OfferPrice"),
					'S1_Product_Name'=>$this->session->userdata("S1_Product_Name"),
					'S1_SubscriptionPlan_No'=>$this->session->userdata("S1_SubscriptionPlan_No"),
					'S1_CouponCode'=>$this->session->userdata("S1_CouponCode"),
					'S1_base_price'=>$this->session->userdata("S1_base_price"),
					'S1_SubscriptionPlan_Name'=>$this->session->userdata("S1_SubscriptionPlan_Name"),
					'f_name'=>$this->session->userdata("f_name"),
					'f_contact'=>$this->session->userdata("f_contact"),
					'f_email'=>$this->session->userdata("f_email"),
					'f_department'=>$this->session->userdata("f_department"),
					'f_designation'=>$this->session->userdata("f_designation"),
					'f_address'=>$this->session->userdata("f_address")
				);

				$this->load->view('header');
				$this->load->view('order_review',$S1_data);
				$this->load->view('footer');
			}
		}		
		
		//submit page for PR base_price
		else if($this->input->get("id")==md5("basePR"))
		{
			if($this->session->userdata("PR_base_price"))
			{
				$PRbase_data=array(
					'PR_base_price'=>$this->session->userdata("PR_base_price"),
					'PR_base_Product_Name'=>$this->session->userdata("PR_base_Product_Name"),
					'PR_base_SubscriptionPlan_Name'=>$this->session->userdata("PR_base_SubscriptionPlan_Name"),
					'PR_base_CouponCode'=>$this->session->userdata("PR_base_CouponCode"),
					'f_name'=>$this->session->userdata("f_name"),
					'f_contact'=>$this->session->userdata("f_contact"),
					'f_email'=>$this->session->userdata("f_email"),
					'f_department'=>$this->session->userdata("f_department"),
					'f_designation'=>$this->session->userdata("f_designation"),
					'f_address'=>$this->session->userdata("f_address")
				);	
	
				$this->load->view('header');
				$this->load->view('order_review',$PRbase_data);
				$this->load->view('footer');	
			}				
		}
	
		//submit page for S1 base_price
		else if($this->input->get("id")==md5("baseS1"))
		{
			if($this->session->userdata("S1_base_price"))
			{
				$S1base_data=array(
					'S1_base_price'=>$this->session->userdata("S1_base_price"),
					'S1_base_Product_Name'=>$this->session->userdata("S1_base_Product_Name"),
					'S1_base_SubscriptionPlan_Name'=>$this->session->userdata("S1_base_SubscriptionPlan_Name"),
					'S1_base_CouponCode'=>$this->session->userdata("S1_base_CouponCode"),
					'f_name'=>$this->session->userdata("f_name"),
					'f_contact'=>$this->session->userdata("f_contact"),
					'f_email'=>$this->session->userdata("f_email"),
					'f_department'=>$this->session->userdata("f_department"),
					'f_designation'=>$this->session->userdata("f_designation"),
					'f_address'=>$this->session->userdata("f_address")
				);	
	
				$this->load->view('header');
				$this->load->view('order_review',$S1base_data);
				$this->load->view('footer');	
			}			
		}
		*/

		require_once(APPPATH . 'third_party/razorpay-php/config.php');
		require_once(APPPATH . 'third_party/razorpay-php/Razorpay.php');

		$displayCurrency = "INR";
		
		//$edition = $this->session->userdata('edition');
		//$unique_id = $this->session->userdata('unique_id');	

		$OfferPrice =$this->session->userdata("OfferPrice");
		$total_amount=0;
		$GST_18=0;
		$amount_before_GST=0;

		
		if (is_numeric($OfferPrice)){
			$total_amount=number_format((float)$OfferPrice, 2, '.', '');
			$GST_18=number_format((float)(($total_amount*18)/100),2,'.','');
			$amount_before_GST=number_format((float)($total_amount-$GST_18),2,'.','');
		}else{
			$base_price=$this->session->userdata("base_price");
			$total_amount=number_format((float)$base_price, 2, '.', '');
			$GST_18=number_format((float)(($total_amount*18)/100),2,'.','');
			$amount_before_GST=number_format((float)($total_amount-$GST_18),2,'.','');
		}
		
		
		// Create the Razorpay Order
		//
		// We create an razorpay order using orders api
		// Docs: https://docs.razorpay.com/docs/orders

		$orderData = [
			'receipt'         => $unique_id, // 3456,
			'amount'          => $total_amount * 100, // amount in paise
			'currency'        => $displayCurrency,
			'payment_capture' => 1 // auto capture
		];

		$api = new Api($keyId, $keySecret);
		$razorpayOrder = $api->order->create($orderData);

		$razorpayOrderId = $razorpayOrder['id'];
		$this->session->set_userdata('razorpay_order_id', $razorpayOrderId);

		$displayAmount = $total_amount;

		if ($displayCurrency !== 'INR')	{
			$url = "https://api.fixer.io/latest?symbols=$displayCurrency&base=INR";
			$exchange = json_decode(file_get_contents($url), true);

			$displayAmount = $exchange['rates'][$displayCurrency] * $total_amount / 100;
		} else {
			$displayAmount = $total_amount / 100;
		}

		$this->session->unset_userdata('amount');
		$this->session->set_userdata('amount', $displayAmount);

		//$checkout = 'manual';
		// if (isset($_GET['checkout']) and in_array($_GET['checkout'], ['automatic', 'manual'], true))
		// {
		// 	$checkout = $_GET['checkout'];
		// }

		$data = [
			"key"               => $keyId,
			"amount"            => $total_amount,
			"name"              => "Prosoft e-Solutions Ind. Pvt. Ltd",
			"description"       => "Transaction with Razorpay",
			"image"             => base_url() . "dist/img/Prosoft_Logo.png",
			"prefill"           => [
				"name"              => $f_name,
				"email"             => $f_email,
				"contact"           => $f_contact,
			],
			"notes"             => [
				"address"           => $f_address,
				"merchant_order_id" => "12312321",
			],
			"theme"             => [
				"color"             => "#0071bc"
			],
			"order_id"          => $razorpayOrderId,
		];

		if ($displayCurrency !== 'INR')
		{
			$data['display_currency']  = $displayCurrency;
			$data['display_amount']    = $displayAmount;
		}

		$ui_data=array(
			'OfferType'=>$this->session->userdata("OfferType"),
			'ProductID'=>$this->session->userdata("ProductID"),
			'OfferPrice'=>$this->session->userdata("OfferPrice"),			
			'Product_Name'=>$this->session->userdata("Product_Name"),
			'SubscriptionPlan_No'=>$this->session->userdata("SubscriptionPlan_No"),
			'CouponCode'=>$this->session->userdata("CouponCode"),
			'base_price'=>$this->session->userdata("base_price"),
			'SubscriptionPlan_Name'=>$this->session->userdata("SubscriptionPlan_Name"),

			'f_name'=>$f_name,
			'f_contact'=>$f_contact,
			'f_email'=>$f_email,
			'f_department'=>$f_department,
			'f_designation'=>$f_designation,
			'f_address'=>$f_address,

			'total_amount'=>$total_amount,
			'GST_18'=>$GST_18,
			'amount_before_GST'=>$amount_before_GST,

			'error'=>"",
			'json'=>json_encode($data)
		);
		
		/*
		$m_data['ui_json'] = json_encode($ui_data);
		$m_data['json'] = json_encode($data);
		$m_data['error'] = $error;
		*/

		$this->load->view('header');
		$this->load->view('order_review',$ui_data);
		$this->load->view('footer');

		// $this->load->view('header');
		// $this->load->view('order_review');
		// $this->load->view('footer');
	}

	public function goto_payment($error = ""){
		require_once(APPPATH . 'third_party/razorpay-php/config.php');
		require_once(APPPATH . 'third_party/razorpay-php/Razorpay.php');

		$displayCurrency = "INR";
		$amount = 0;

		$edition = $this->session->userdata('edition');
		$unique_id = $this->session->userdata('unique_id');

		if ($edition == "LITE"){
			$amount = 29500 * 100; // Convert amount into paise			
		} else {
			$amount = 29500 * 100; // Convert amount into paise
		}		
		
		// Create the Razorpay Order
		//
		// We create an razorpay order using orders api
		// Docs: https://docs.razorpay.com/docs/orders

		$orderData = [
			'receipt'         => $unique_id, // 3456,
			'amount'          => $amount, // amount in paise
			'currency'        => $displayCurrency,
			'payment_capture' => 1 // auto capture
		];

		$api = new Api($keyId, $keySecret);
		$razorpayOrder = $api->order->create($orderData);

		$razorpayOrderId = $razorpayOrder['id'];
		$this->session->set_userdata('razorpay_order_id', $razorpayOrderId);

		$displayAmount = $amount;

		if ($displayCurrency !== 'INR')	{
			$url = "https://api.fixer.io/latest?symbols=$displayCurrency&base=INR";
			$exchange = json_decode(file_get_contents($url), true);

			$displayAmount = $exchange['rates'][$displayCurrency] * $amount / 100;
		} else {
			$displayAmount = $amount / 100;
		}

		$this->session->unset_userdata('amount');
		$this->session->set_userdata('amount', $displayAmount);

		//$checkout = 'manual';
		// if (isset($_GET['checkout']) and in_array($_GET['checkout'], ['automatic', 'manual'], true))
		// {
		// 	$checkout = $_GET['checkout'];
		// }

		$data = [
			"key"               => $keyId,
			"amount"            => $amount,
			"name"              => "Prosoft e-Solutions",
			"description"       => "Transaction with Razorpay",
			"image"             => base_url() . "dist/img/Prosoft_Logo.png",
			"prefill"           => [
				"name"              => $this->session->userdata('f_name'),
				"email"             => $this->session->userdata('f_email'),
				"contact"           => $this->session->userdata('f_contact'),
			],
			"notes"             => [
				"address"           => $this->session->userdata('f_address'),
				"merchant_order_id" => "12312321",
			],
			"theme"             => [
				"color"             => "#0071bc"
			],
			"order_id"          => $razorpayOrderId,
		];

		if ($displayCurrency !== 'INR')
		{
			$data['display_currency']  = $displayCurrency;
			$data['display_amount']    = $displayAmount;
		}
		
		$m_data['json'] = json_encode($data);
		$m_data['error'] = $error;

		$this->load->model('subscriptionplan_Model');
		$m_data['subscriptions'] = $this->subscriptionplan_Model->get_subscriptions();

		$this->load->view('header');								
		$this->load->view('payment', $m_data);
		$this->load->view('footer');
	}

	
	public function payment_response(){
		require_once(APPPATH . 'third_party/razorpay-php/config.php');
		require_once(APPPATH . 'third_party/razorpay-php/Razorpay.php');		

		$success = true;
		$error = "Payment Failed";

		$razorpay_order_id = "";
		$razorpay_payment_id = "";
		$razorpay_signature = "";

		if (empty($_POST['razorpay_payment_id']) === false)
		{
			$api = new Api($keyId, $keySecret);

			try
			{
				// Please note that the razorpay order ID must
				// come from a trusted source (session here, but
				// could be database or something else)
				$razorpay_order_id = $this->session->userdata('razorpay_order_id');
				$razorpay_payment_id = $_POST['razorpay_payment_id'];
				$razorpay_signature = $_POST['razorpay_signature'];

				$attributes = array(
					'razorpay_order_id' => $razorpay_order_id,
					'razorpay_payment_id' => $razorpay_payment_id,
					'razorpay_signature' => $razorpay_signature
				);

				$api->utility->verifyPaymentSignature($attributes);
			}
			catch(SignatureVerificationError $e)
			{
				$success = false;
				$error = 'Razorpay Error : ' . $e->getMessage();
			}
		}
		else
		{
			$razorpay_payment_id = "EMPTY";
		}

		if ($success === true)
		{
			// $html = "<p>Your payment was successful</p>
			// 		<p>Payment ID: {$_POST['razorpay_payment_id']}</p>";
			$this->on_order_placed($razorpay_order_id, $razorpay_payment_id, $razorpay_signature, "SUCCESS");
		}
		else
		{
			// $html = "<p>Your payment failed</p>
			// 		<p>{$error}</p>";
			$this->goto_payment($error);			
		}		
	}

	public function validate($f_name, $f_email, $f_contact, $f_department, 
								$f_designation, $f_address) 
	{		
		$f_name_error = "";
		$f_contact_error = "";
		$f_department_error = "";
		$f_email_error = "";

		$f_name = $this->test_input($f_name);
		// check if name only contains letters and whitespace
		if (!preg_match("/^[a-zA-Z ]*$/",$f_name)) {
			$f_name_error = "Only letters and white space allowed";
		}

		$f_contact = $this->test_input($f_contact);
		// check if contact number is correct
		if(preg_match('/^\d{10}$/',$f_contact) == false){
			$f_contact_error = "Only numeric value and with 10 digit is allowed.";		
		}

		$f_email = $this->test_input($f_email);
		// check if e-mail address is well-formed
		//if (!filter_var($f_email, FILTER_VALIDATE_EMAIL)) {
		if ($this->valid_email($f_email) === false) {
			$f_email_error = "Invalid email format.";
		}

		$f_department = $this->test_input($f_department);
		// check if name only contains letters and whitespace
		if (!preg_match("/^[a-zA-Z ]*$/",$f_department)) {
			$f_department_error = "Only letters and white space allowed.";
		}

		if ($f_name_error != "" || $f_contact_error != "" || $f_department_error != "" || $f_email_error != ""){			
			$this->on_error_redirect("Invalid input.", $f_name_error, $f_contact_error, 
				$f_department_error, $f_email_error);
			return false;
		} else {
			return true;
		}
	}	
	
	public function on_order_placed($razorpay_order_id = "", $razorpay_payment_id = "", $razorpay_signature = "", $status = "")
	{
		try {			
			$new_coupon_code_P = "";
			$new_coupon_code_S = "";

			$user_id = $this->session->userdata('user_id');
			$subscription_no = $this->session->userdata("SubscriptionPlan_No");
			$subscription_type = 1;

			//log_message('error', "SUBSCRIPTION_NO=".$subscription_no);

			if ($subscription_no != null && $subscription_no != ""){
				if ($subscription_no === "1"){
					$subscription_type = "PERPETUAL";
				}else if ($subscription_no === "2"){
					$subscription_type = "SAAS";
				}
			}else{
				$subscription_type = "OTHER";
			}

			$this->load->model('Coupon_Model');
			$OfferPrice =$this->session->userdata("OfferPrice");
			$coupon_code = $this->session->userdata("CouponCode");

			//if (is_numeric($OfferPrice)){			
				if ($coupon_code != null && $coupon_code != "" && $coupon_code != "-----"){					
					$has_updated = $this->Coupon_Model->update($coupon_code);
				}				
			//}

			$new_coupon_code_P = "P" . $this->random_strings(5);
			$has_inserted = $this->Coupon_Model->save($new_coupon_code_P, 1000, 75, 1, $user_id, $user_id);

			$new_coupon_code_S = "S" . $this->random_strings(5);
			$has_inserted = $this->Coupon_Model->save($new_coupon_code_S, 400, 75, 2, $user_id, $user_id);

			$edition = $this->session->userdata('edition');
			$f_name = $this->session->userdata('f_name');
			$f_email = $this->session->userdata('f_email');
			$f_contact = $this->session->userdata('f_contact');
			$f_department = $this->session->userdata('f_department');
			$f_designation = $this->session->userdata('f_designation');
			$f_address = $this->session->userdata('f_address');									
			
			//The URL we want to send a HTTP request to.
			$url = "https://prosoftesolutions.com/C5CDRAnalyzerV5_Web/SendEmailProsoftSite.aspx";

			//Initiate cURL
			$ch = curl_init($url);

			//Tell cURL that it should only spend 10 seconds
			//trying to connect to the URL in question.
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);

			//A given cURL operation should only take
			//30 seconds max.
			curl_setopt($ch, CURLOPT_TIMEOUT, 30);

			//Tell cURL to return the response output as a string.
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

			log_message('info', "SUBSCRIPTION_TYPE=".$subscription_type);

			$post = [
				'edition' => $edition,
				'subscription_type' => $subscription_type,
				'f_name' => $f_name,
				'f_contact'   => $f_contact,
				'f_department'   => $f_department,
				'f_email'   => $f_email,
				'f_designation'   => $f_designation,
				'f_address'   => $f_address,
				'coupon_code_p'   => $new_coupon_code_P,
				'coupon_code_s'   => $new_coupon_code_S
			];
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);

			//Execute the request.
			$response = curl_exec($ch);

			//$this->on_error_redirect("Server Response : " . $response);
			//return;

			//Did an error occur? If so, dump it out.
			if(curl_errno($ch)){
				$this->on_error_redirect(curl_error($ch));
				//return array("FAILED", curl_error($ch));
			} else {
				// close the connection, release resources used
				curl_close ($ch);

				$obj = json_decode($response);
				if ($obj->{'STATUS'} == "SUCCESS"){
					
					//Update serial key for Lite users for particular user 
					//using user_id session value
					$this->load->model('UserInfo_Model');
					$has_updated = $this->UserInfo_Model->update($user_id, $obj->{'SERIAL_KEY'}, $razorpay_order_id, $razorpay_payment_id, $razorpay_signature, $status);
					
					//Clear the session
					$this->clear_session();

					//redirect user to greetings page
					redirect('index.php/Greeting');					
				} else {
					//$this->on_error_redirect($obj->{'ERROR'});
					redirect('index.php/SubscriptionPlan?error='.$obj->{'ERROR'});
				}				
			}	
		}
		catch(Exception $e) {
			//$this->on_error_redirect($e->getMessage());
			redirect('index.php/SubscriptionPlan?error='.$e->getMessage());
		}
	}

	// Outdated
	public function send_email($mail_to, $subject, $body)
	{
		try{
			/*
			if (mail($f_email, $subject, $message_to_client, $headers)){
				echo "SENT";
				
				return;
			} else {
				//echo  "<script> alert('Failed to send email to client email address.')</script>";
				$this->on_error_redirect("Failed to send email to client email address.");
				return;
			}*/

			$m_subject = $subject;
			//$m_subject = str_replace(" ","%20", $m_subject);

			$m_body = $body;
			//$m_body = str_replace(" ","%20", $m_body);
			$m_body = str_replace("'","%27", $m_body);
			$m_body = str_replace("<","c5lt;", $m_body);
			$m_body = str_replace(">","c5gt;", $m_body);

			//The URL we want to send a HTTP request to.
			$url = "https://prosoftesolutions.com/C5CDRAnalyzerV5_Web/SendEmail.aspx";

			//Initiate cURL
			$ch = curl_init($url);

			//Tell cURL that it should only spend 10 seconds
			//trying to connect to the URL in question.
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);

			//A given cURL operation should only take
			//30 seconds max.
			curl_setopt($ch, CURLOPT_TIMEOUT, 30);

			//Tell cURL to return the response output as a string.
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

			$post = [
				'serial_key' => '11111-11111-11111',
				'emailTo' => $mail_to,
				'subject'   => $m_subject,
				'body'   => $m_body
			];
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);

			//Execute the request.
			$response = curl_exec($ch);

			//Did an error occur? If so, dump it out.
			if(curl_errno($ch)){
				//throw new Exception(curl_error($ch));
				return curl_error($ch);
			} else {
				// close the connection, release resources used
				curl_close ($ch);
				return $response;
			}	
		}
		catch(Exception $e) {
			//$this->on_error_redirect("Error while saving the user information. Error : " . $e->getMessage());
			return $e->getMessage();
		}
	}

	public function test_email()
	{
		$f_email = "inamullah.mulla@gmail.com";
		if(isset($_GET['email'])){
			$f_email = $_GET['email'];
		}
		
		$edition = "LITE";
		$f_name = "IGNORE"; 
		//$f_email = "inamullah.mulla@gmail.com"; 
		$f_contact = "11111";
		$f_department = "TEST DEPT 1"; 
		$f_designation = "TEST DESIGNATION 1"; 
		$f_address = "TEST ADDR 1";

		// $erms = "Thank you for contacting us ! We will get back to you soon.";

		// To send HTML mail, the Content-type header must be set
		$headers = "MIME-Version: 1.0\r\n";
		$headers .= "Content-type: text/html\r\n";
		$headers .= "From: noreply@prosoftesolutions.com\r\n";

		$message_to_prosoft = "message to prosoft message";
		
		$subject = "test subject.";
		$message_to_client = "test message";

		try{
				/*
				if (mail($f_email, $subject, $message_to_client, $headers)){
					echo "SENT";
					
					return;
				} else {
					//echo  "<script> alert('Failed to send email to client email address.')</script>";
					$this->on_error_redirect("Failed to send email to client email address.");
					return;
				}*/

				//The URL we want to send a HTTP request to.
				//In this case, it is a script on my local machine.
				$url = "https://prosoftesolutions.com/C5CDRAnalyzerV5_Web/SendEmail.aspx";

				//Initiate cURL
				$ch = curl_init($url);

				//Tell cURL that it should only spend 10 seconds
				//trying to connect to the URL in question.
				curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);

				//A given cURL operation should only take
				//30 seconds max.
				curl_setopt($ch, CURLOPT_TIMEOUT, 30);

				//Tell cURL to return the response output as a string.
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

				$post = [
					'serial_key' => '11111-11111-11111',
					'emailTo' => $f_email,
					'subject'   => "subject%20goes%20here",
					'body'   => "body%20goes%20here"
				];
				curl_setopt($ch, CURLOPT_POSTFIELDS, $post);

				//Execute the request.
				$response = curl_exec($ch);

				//Did an error occur? If so, dump it out.
				if(curl_errno($ch)){
					throw new Exception(curl_error($ch));
				}

				// close the connection, release resources used
				curl_close ($ch);
			
				echo "EMAIL TO " . $f_email . " RESPONSE : " . $response;
				return;
		}
		catch(Exception $e) {
			$this->on_error_redirect("Error while saving the user information. Error : " . $e->getMessage());
			return;
		}
	}	
	
	////-------------
	////Util methods

	////Redirect to specific page with error
	private function on_error_redirect($error = "", $f_name_error = "", $f_contact_error = "", 
		$f_department_error = "", $f_email_error = "")
	{
		$edition = $this->session->userdata('edition');

		$error = ($error !== "") ? "ERROR : " . $error : "";
		$f_name_error = ($f_name_error !== "") ? "*" . $f_name_error : "";
		$f_contact_error = ($f_contact_error !== "") ? "*" . $f_contact_error : "";
		$f_department_error = ($f_department_error !== "") ? "*" . $f_department_error : "";
		$f_email_error = ($f_email_error !== "") ? "*" . $f_email_error : "";

		// set array of errors
		$array_error_data = array(
			'error'  => $error,
			'f_name_error'     => $f_name_error,
			'f_contact_error' => $f_contact_error,
			'f_department_error' => $f_department_error,
			'f_email_error' => $f_email_error
		);
		
		if ($edition === "LITE")
		{
			$this->user_info_lite($array_error_data, $edition);
		}
		else
		{
			$this->index($array_error_data, $edition);
		}
		
	}

	// Clear previous session
	public function clear_session(){		
		$array_items = array('unique_id', 'edition', 'f_name', 'f_email', 'f_contact', 'f_department', 'f_designation', 
							'f_address', 'amount', 'razorpay_order_id', 'user_id');
		$this->session->unset_userdata($array_items);
	}

	////Create a unique_id
	private function getGUID(){
		if (function_exists('com_create_guid')){
			return com_create_guid();
		}else{
			mt_srand((double)microtime()*10000);//optional for php 4.2.0 and up.
			$charid = strtoupper(md5(uniqid(rand(), true)));
			$hyphen = chr(45);// "-"
			$uuid = chr(123)// "{"
				.substr($charid, 0, 8).$hyphen
				.substr($charid, 8, 4).$hyphen
				.substr($charid,12, 4).$hyphen
				.substr($charid,16, 4).$hyphen
				.substr($charid,20,12)
				.chr(125);// "}"
			return $uuid;
		}
	}

	// This function will return a random 
	// string of specified length 
	function random_strings($length_of_string) 
	{ 
  
		// String of all alphanumeric character 
		//$str_result = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'; 
		$str_result = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'; 
  
		// Shufle the $str_result and returns substring 
		// of specified length 
		return substr(str_shuffle($str_result),  
						   0, $length_of_string); 
	} 

	////Check user input characters
	function test_input($data) {
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}

	////Check if valid email id
	function valid_email($str) {
		return (!preg_match("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$^", $str)) ? false : true;
	}

    public function get_subscriptions_details()
	{
		$subscriptionname = $_GET['subscriptionname'];
		// $subscriptionname = $this->filter_field($subscriptionname);
		
		$this->load->model('subscriptionplan_Model');
		$data = $this->subscriptionplan_Model->get_selected_subscriptions($subscriptionname);
		
		if (!is_int($data))
		{



			if ($data->num_rows() > 0){
				echo json_encode($data->result());
			} else {
				echo json_encode(110);
			}
		}
		else
		{
			echo json_encode(110);
		}		
	}

	// user_info_lite page
	public function user_info_lite($array_error_data = array(), $m_edition = "")
	{
		// $_SERVER['HTTP_REFERER'] avoid direct access...
        if(!isset($_SERVER['HTTP_REFERER']))
            return redirect('Home/index');

		/*
		//user_info_lite page for  PR coupon code
		if($this->input->get("id")==md5("PR"))
		{
			if($this->session->userdata("PR_OfferPrice"))
			{
				$PR_data=array(
					'PR_OfferPrice'=>$this->session->userdata("PR_OfferPrice"),
					'PR_Product_Name'=>$this->session->userdata("PR_Product_Name"),
					'PR_SubscriptionPlan_No'=>$this->session->userdata("PR_SubscriptionPlan_No"),
					'PR_CouponCode'=>$this->session->userdata("PR_CouponCode"),
				);
				$this->load->view('header');
				$this->load->view('user_info_lite',$PR_data);
				$this->load->view('footer');
			}			
		}

		// user_info_lite page for S1 coupon code
		else if($this->input->get("id")==md5("S1"))
		{
			if($this->session->userdata("S1_OfferPrice"))
			{
				$S1_data=array(
					'S1_OfferPrice'=>$this->session->userdata("S1_OfferPrice"),
					'S1_Product_Name'=>$this->session->userdata("S1_Product_Name"),
					'S1_SubscriptionPlan_No'=>$this->session->userdata("S1_SubscriptionPlan_No"),
					'S1_CouponCode'=>$this->session->userdata("S1_CouponCode"),
				);
				$this->load->view('header');
				$this->load->view('user_info_lite',$S1_data);
				$this->load->view('footer');
			}
		}	
	
		//user_info_lite page for PR base_price
		else if($this->input->get("id")==md5("basePR"))
		{
			if($this->session->userdata("PR_base_price"))
			{
				$PRbase_data=array(
					'PR_base_price'=>$this->session->userdata("PR_base_price"),
					'PR_base_Product_Name'=>$this->session->userdata("PR_base_Product_Name"),
					'PR_base_SubscriptionPlan_Name'=>$this->session->userdata("PR_base_SubscriptionPlan_Name"),
					'PR_base_CouponCode'=>$this->session->userdata("PR_base_CouponCode"),
				);

				$this->load->view('header');
				$this->load->view('user_info_lite',$PRbase_data);
				$this->load->view('footer');
			}			
		}

		//user_info_lite page for S1 base_price
		else if($this->input->get("id")==md5("baseS1"))
		{
			if($this->session->userdata("S1_base_price"))
			{
				$S1base_data=array(
					'S1_base_price'=>$this->session->userdata("S1_base_price"),
					'S1_base_Product_Name'=>$this->session->userdata("S1_base_Product_Name"),
					'S1_base_SubscriptionPlan_Name'=>$this->session->userdata("S1_base_SubscriptionPlan_Name"),
					'S1_base_CouponCode'=>$this->session->userdata("S1_base_CouponCode"),
				);

				$this->load->view('header');
				$this->load->view('user_info_lite',$S1base_data);
				$this->load->view('footer');
			}			
		}
		*/

		$edition = "LITE";
		
		//$this->session->sess_destroy();
		$this->session->set_userdata('edition', $edition);

		$error= "";
		$f_name_error= "";
		$f_contact_error= "";
		$f_department_error= "";
		$f_email_error= "";
				
		if (empty($array_error_data) === false) {
			$error= $array_error_data['error'];
			$f_name_error= $array_error_data['f_name_error'];
			$f_contact_error= $array_error_data['f_contact_error'];
			$f_department_error= $array_error_data['f_department_error'];
			$f_email_error= $array_error_data['f_email_error'];
		}
		
		// Not sure whether below code is required
		// Because we can directly access session values in user_info_lite page without passing them in an array
		$data=array(
			'error'  => $error,
			'f_name_error'     => $f_name_error,
			'f_contact_error' => $f_contact_error,
			'f_department_error' => $f_department_error,
			'f_email_error' => $f_email_error,

			'OfferType'=>$this->session->userdata("OfferType"),
			'ProductID'=>$this->session->userdata("ProductID"),
			'OfferPrice'=>$this->session->userdata("OfferPrice"),
			'Product_Name'=>$this->session->userdata("Product_Name"),
			'SubscriptionPlan_No'=>$this->session->userdata("SubscriptionPlan_No"),
			'CouponCode'=>$this->session->userdata("CouponCode"),
			'base_price'=>$this->session->userdata("base_price"),
			'SubscriptionPlan_Name'=>$this->session->userdata("SubscriptionPlan_Name")
		);

		$this->load->view('header');
		$this->load->view('user_info_lite',$data);
		$this->load->view('footer');
	}
} ?>


