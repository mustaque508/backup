<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-31 05:37:12 --> Unable to connect to the database
ERROR - 2021-08-31 05:40:30 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 05:40:30 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 05:40:30 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 05:40:30 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 05:40:30 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 05:41:26 --> Unable to connect to the database
ERROR - 2021-08-31 05:41:28 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 05:41:28 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 05:41:28 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 05:41:28 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 05:41:29 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 05:42:53 --> Unable to connect to the database
ERROR - 2021-08-31 05:42:54 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 05:42:55 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 05:42:55 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 05:42:55 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 05:42:55 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 05:50:28 --> Unable to connect to the database
ERROR - 2021-08-31 05:50:29 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 05:50:29 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 05:50:29 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 05:50:29 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 05:50:30 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 05:53:09 --> Unable to connect to the database
ERROR - 2021-08-31 05:53:09 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 05:53:09 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 05:53:10 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 05:53:10 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 05:53:10 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 05:54:50 --> Unable to connect to the database
ERROR - 2021-08-31 05:54:51 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 05:54:51 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 05:54:51 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 05:54:51 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 05:54:51 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 05:58:42 --> Unable to connect to the database
ERROR - 2021-08-31 05:58:45 --> Unable to connect to the database
ERROR - 2021-08-31 05:58:49 --> Unable to connect to the database
ERROR - 2021-08-31 05:58:49 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 05:58:49 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 05:58:50 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 05:58:50 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 05:58:50 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:00:46 --> Unable to connect to the database
ERROR - 2021-08-31 06:00:46 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:00:46 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:00:47 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:00:47 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:00:47 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:05:03 --> Unable to connect to the database
ERROR - 2021-08-31 06:05:03 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:05:04 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:05:04 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:05:04 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:05:04 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:07:02 --> Unable to connect to the database
ERROR - 2021-08-31 06:07:02 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:07:03 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:07:03 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:07:03 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:07:03 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:09:47 --> Unable to connect to the database
ERROR - 2021-08-31 06:09:47 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:09:47 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:09:48 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:09:48 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:09:48 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:11:09 --> Unable to connect to the database
ERROR - 2021-08-31 06:11:09 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:11:09 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:11:09 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:11:09 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:11:09 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:13:53 --> Unable to connect to the database
ERROR - 2021-08-31 06:13:54 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:13:54 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:13:54 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:13:54 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:13:55 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:15:14 --> Unable to connect to the database
ERROR - 2021-08-31 06:15:14 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:15:15 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:15:15 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:15:15 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:15:15 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:17:54 --> Unable to connect to the database
ERROR - 2021-08-31 06:17:55 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:17:55 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:17:55 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:17:55 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:17:56 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:20:08 --> Unable to connect to the database
ERROR - 2021-08-31 06:20:08 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:20:09 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:20:09 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:20:09 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:20:09 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:21:19 --> Unable to connect to the database
ERROR - 2021-08-31 06:21:19 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:21:19 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:21:20 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:21:20 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:21:20 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:22:19 --> Unable to connect to the database
ERROR - 2021-08-31 09:52:19 --> Severity: error --> Exception: DateTime::__construct(): Failed to parse time string (Y-m-d h:i:sa) at position 1 (-): Unexpected character D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 10
ERROR - 2021-08-31 06:23:29 --> Unable to connect to the database
ERROR - 2021-08-31 06:23:29 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:23:30 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:23:30 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:23:30 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:23:30 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:24:48 --> Unable to connect to the database
ERROR - 2021-08-31 06:24:48 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:24:49 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:24:49 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:24:49 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:24:49 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:26:27 --> Unable to connect to the database
ERROR - 2021-08-31 06:26:27 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:26:28 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:26:28 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:26:28 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:26:28 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:27:56 --> Unable to connect to the database
ERROR - 2021-08-31 06:27:56 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:27:57 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:27:57 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:27:57 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:27:57 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:28:58 --> Unable to connect to the database
ERROR - 2021-08-31 06:28:59 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:29:00 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:29:00 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:29:00 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:29:00 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:30:41 --> Unable to connect to the database
ERROR - 2021-08-31 06:30:42 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:30:42 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:30:42 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:30:42 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:30:42 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:31:43 --> Unable to connect to the database
ERROR - 2021-08-31 06:32:01 --> Unable to connect to the database
ERROR - 2021-08-31 06:32:02 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:32:02 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:32:02 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:32:02 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:32:02 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:36:25 --> Unable to connect to the database
ERROR - 2021-08-31 06:36:25 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:36:25 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:36:26 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:36:26 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:36:26 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:37:49 --> Unable to connect to the database
ERROR - 2021-08-31 06:37:49 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:37:50 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:37:50 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:37:50 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:37:50 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:39:45 --> Unable to connect to the database
ERROR - 2021-08-31 06:39:46 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:39:46 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:39:46 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:39:46 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:39:46 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:41:47 --> Unable to connect to the database
ERROR - 2021-08-31 06:41:47 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:41:48 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:41:48 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:41:48 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:41:48 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:43:29 --> Unable to connect to the database
ERROR - 2021-08-31 06:43:31 --> Unable to connect to the database
ERROR - 2021-08-31 06:43:31 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:43:32 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:43:32 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:43:32 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:43:32 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:44:53 --> Unable to connect to the database
ERROR - 2021-08-31 06:44:54 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:44:54 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:44:54 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:44:54 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:44:54 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:47:00 --> Unable to connect to the database
ERROR - 2021-08-31 06:47:00 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:47:01 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:47:01 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:47:01 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:47:01 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:48:38 --> Unable to connect to the database
ERROR - 2021-08-31 06:48:39 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:48:39 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:48:39 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:48:39 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:48:40 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:50:01 --> Unable to connect to the database
ERROR - 2021-08-31 06:50:02 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:50:02 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:50:02 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:50:03 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:50:03 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:51:31 --> Unable to connect to the database
ERROR - 2021-08-31 06:51:31 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:51:31 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:51:31 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:51:31 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:51:32 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:52:53 --> Unable to connect to the database
ERROR - 2021-08-31 06:52:54 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:52:54 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:52:54 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:52:54 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:52:54 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:54:18 --> Unable to connect to the database
ERROR - 2021-08-31 06:54:18 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:54:19 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:54:19 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:54:19 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:54:19 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:55:55 --> Unable to connect to the database
ERROR - 2021-08-31 06:55:55 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 06:55:56 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:55:56 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:55:56 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 06:55:56 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 07:01:15 --> Unable to connect to the database
ERROR - 2021-08-31 10:31:15 --> Severity: error --> Exception: syntax error, unexpected 'strtotime' (T_STRING), expecting ')' D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 9
ERROR - 2021-08-31 07:02:16 --> Unable to connect to the database
ERROR - 2021-08-31 07:02:17 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 07:02:17 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 07:02:17 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 07:02:17 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 07:02:18 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 07:03:39 --> Unable to connect to the database
ERROR - 2021-08-31 07:03:40 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 07:03:40 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 07:03:40 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 07:03:40 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 07:03:40 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 07:05:35 --> Unable to connect to the database
ERROR - 2021-08-31 07:05:36 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-31 07:05:36 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 07:05:36 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 07:05:36 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 07:05:36 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-31 07:06:50 --> Unable to connect to the database
ERROR - 2021-08-31 07:07:54 --> Unable to connect to the database
ERROR - 2021-08-31 07:14:33 --> Unable to connect to the database
ERROR - 2021-08-31 07:48:39 --> Unable to connect to the database
ERROR - 2021-08-31 07:49:50 --> Unable to connect to the database
ERROR - 2021-08-31 07:51:19 --> Unable to connect to the database
ERROR - 2021-08-31 07:51:48 --> Unable to connect to the database
ERROR - 2021-08-31 07:52:57 --> Unable to connect to the database
ERROR - 2021-08-31 07:57:51 --> Unable to connect to the database
ERROR - 2021-08-31 07:58:53 --> Unable to connect to the database
ERROR - 2021-08-31 07:59:19 --> Unable to connect to the database
ERROR - 2021-08-31 11:26:16 --> Unable to connect to the database
