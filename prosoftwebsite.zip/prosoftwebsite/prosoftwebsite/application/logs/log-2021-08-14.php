<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-14 01:29:40 --> Unable to connect to the database
ERROR - 2021-08-14 01:32:40 --> Unable to connect to the database
ERROR - 2021-08-14 01:34:20 --> Unable to connect to the database
ERROR - 2021-08-14 01:35:41 --> Unable to connect to the database
ERROR - 2021-08-14 01:37:07 --> Unable to connect to the database
ERROR - 2021-08-14 01:38:42 --> Unable to connect to the database
ERROR - 2021-08-14 01:40:03 --> Unable to connect to the database
ERROR - 2021-08-14 01:41:14 --> Unable to connect to the database
ERROR - 2021-08-14 01:42:46 --> Unable to connect to the database
ERROR - 2021-08-14 01:46:16 --> Unable to connect to the database
ERROR - 2021-08-14 01:47:30 --> Unable to connect to the database
ERROR - 2021-08-14 01:48:44 --> Unable to connect to the database
ERROR - 2021-08-14 01:49:51 --> Unable to connect to the database
ERROR - 2021-08-14 01:50:17 --> Unable to connect to the database
ERROR - 2021-08-14 01:51:00 --> Unable to connect to the database
ERROR - 2021-08-14 01:52:14 --> Unable to connect to the database
ERROR - 2021-08-14 01:53:50 --> Unable to connect to the database
ERROR - 2021-08-14 01:55:06 --> Unable to connect to the database
ERROR - 2021-08-14 01:56:37 --> Unable to connect to the database
ERROR - 2021-08-14 01:56:37 --> Unable to connect to the database
ERROR - 2021-08-14 01:56:37 --> Unable to connect to the database
ERROR - 2021-08-14 01:56:37 --> Unable to connect to the database
ERROR - 2021-08-14 01:56:37 --> Unable to connect to the database
ERROR - 2021-08-14 01:56:37 --> Unable to connect to the database
ERROR - 2021-08-14 02:01:18 --> Unable to connect to the database
ERROR - 2021-08-14 02:02:22 --> Unable to connect to the database
ERROR - 2021-08-14 02:03:31 --> Unable to connect to the database
ERROR - 2021-08-14 02:05:12 --> Unable to connect to the database
ERROR - 2021-08-14 02:06:29 --> Unable to connect to the database
ERROR - 2021-08-14 04:02:07 --> Unable to connect to the database
ERROR - 2021-08-14 04:02:07 --> Unable to connect to the database
ERROR - 2021-08-14 04:04:02 --> Unable to connect to the database
ERROR - 2021-08-14 04:36:36 --> Unable to connect to the database
ERROR - 2021-08-14 04:36:36 --> Unable to connect to the database
ERROR - 2021-08-14 04:37:36 --> Unable to connect to the database
ERROR - 2021-08-14 04:37:57 --> Unable to connect to the database
ERROR - 2021-08-14 04:37:57 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server]Named Pipes Provider: Could not open a connection to SQL Server [53].  - Invalid query: SELECT SubscriptionPlan_No, Product_ID, Product_Name, [Edition],
                        SubscriptionName
                        ,Amount_Before_GST
                        ,GST
                        ,Amount_After_GST
						,OfferPrice
						
                    FROM [SubscriptionPlan]
ERROR - 2021-08-14 04:37:57 --> Severity: error --> Exception: Call to a member function num_rows() on bool D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\models\subscriptionplan_Model.php 22
ERROR - 2021-08-14 07:59:19 --> Unable to connect to the database
ERROR - 2021-08-14 07:59:40 --> Unable to connect to the database
ERROR - 2021-08-14 07:59:40 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server]Named Pipes Provider: Could not open a connection to SQL Server [53].  - Invalid query: SELECT SubscriptionPlan_No, Product_ID, Product_Name, [Edition],
                        SubscriptionName
                        ,Amount_Before_GST
                        ,GST
                        ,Amount_After_GST
						,OfferPrice
						
                    FROM [SubscriptionPlan]
ERROR - 2021-08-14 07:59:40 --> Severity: error --> Exception: Call to a member function num_rows() on bool D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\models\subscriptionplan_Model.php 22
ERROR - 2021-08-14 08:00:28 --> Unable to connect to the database
ERROR - 2021-08-14 08:04:12 --> Unable to connect to the database
ERROR - 2021-08-14 08:04:33 --> Unable to connect to the database
ERROR - 2021-08-14 08:04:33 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server]Named Pipes Provider: Could not open a connection to SQL Server [53].  - Invalid query: SELECT SubscriptionPlan_No, Product_ID, Product_Name, [Edition],
                        SubscriptionName
                        ,Amount_Before_GST
                        ,GST
                        ,Amount_After_GST
						,OfferPrice
						
                    FROM [SubscriptionPlan]
ERROR - 2021-08-14 08:04:33 --> Severity: error --> Exception: Call to a member function num_rows() on bool D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\models\subscriptionplan_Model.php 22
ERROR - 2021-08-14 08:06:05 --> Unable to connect to the database
ERROR - 2021-08-14 08:06:27 --> Unable to connect to the database
ERROR - 2021-08-14 08:06:27 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server]Named Pipes Provider: Could not open a connection to SQL Server [53].  - Invalid query: SELECT SubscriptionPlan_No, Product_ID, Product_Name, [Edition],
                        SubscriptionName
                        ,Amount_Before_GST
                        ,GST
                        ,Amount_After_GST
						,OfferPrice
						
                    FROM [SubscriptionPlan]
ERROR - 2021-08-14 08:06:27 --> Severity: error --> Exception: Call to a member function num_rows() on bool D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\models\subscriptionplan_Model.php 22
ERROR - 2021-08-14 08:06:29 --> Unable to connect to the database
ERROR - 2021-08-14 08:06:33 --> Unable to connect to the database
ERROR - 2021-08-14 08:07:29 --> Unable to connect to the database
ERROR - 2021-08-14 08:07:51 --> Unable to connect to the database
ERROR - 2021-08-14 08:07:51 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server]Named Pipes Provider: Could not open a connection to SQL Server [53].  - Invalid query: SELECT SubscriptionPlan_No, Product_ID, Product_Name, [Edition],
                        SubscriptionName
                        ,Amount_Before_GST
                        ,GST
                        ,Amount_After_GST
						,OfferPrice
						
                    FROM [SubscriptionPlan]
ERROR - 2021-08-14 08:07:51 --> Severity: error --> Exception: Call to a member function num_rows() on bool D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\models\subscriptionplan_Model.php 22
ERROR - 2021-08-14 08:09:14 --> Unable to connect to the database
ERROR - 2021-08-14 08:11:55 --> Unable to connect to the database
ERROR - 2021-08-14 08:20:46 --> Unable to connect to the database
ERROR - 2021-08-14 08:20:50 --> Unable to connect to the database
ERROR - 2021-08-14 08:21:03 --> Unable to connect to the database
ERROR - 2021-08-14 08:21:07 --> Unable to connect to the database
ERROR - 2021-08-14 08:21:07 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server]Named Pipes Provider: Could not open a connection to SQL Server [53].  - Invalid query: SELECT SubscriptionPlan_No, Product_ID, Product_Name, [Edition],
                        SubscriptionName
                        ,Amount_Before_GST
                        ,GST
                        ,Amount_After_GST
						,OfferPrice
						
                    FROM [SubscriptionPlan]
ERROR - 2021-08-14 08:21:07 --> Severity: error --> Exception: Call to a member function num_rows() on bool D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\models\subscriptionplan_Model.php 22
ERROR - 2021-08-14 08:21:12 --> Unable to connect to the database
ERROR - 2021-08-14 08:21:12 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server]Named Pipes Provider: Could not open a connection to SQL Server [53].  - Invalid query: SELECT SubscriptionPlan_No, Product_ID, Product_Name, [Edition],
                        SubscriptionName
                        ,Amount_Before_GST
                        ,GST
                        ,Amount_After_GST
						,OfferPrice
						
                    FROM [SubscriptionPlan]
ERROR - 2021-08-14 08:21:12 --> Severity: error --> Exception: Call to a member function num_rows() on bool D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\models\subscriptionplan_Model.php 22
ERROR - 2021-08-14 08:21:59 --> Unable to connect to the database
ERROR - 2021-08-14 08:21:59 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server]Named Pipes Provider: Could not open a connection to SQL Server [53].  - Invalid query: SELECT SubscriptionPlan_No, Product_ID, Product_Name, [Edition],
                        SubscriptionName
                        ,Amount_Before_GST
                        ,GST
                        ,Amount_After_GST
						,OfferPrice
						
                    FROM [SubscriptionPlan]
ERROR - 2021-08-14 08:21:59 --> Severity: error --> Exception: Call to a member function num_rows() on bool D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\models\subscriptionplan_Model.php 22
ERROR - 2021-08-14 08:22:05 --> Unable to connect to the database
ERROR - 2021-08-14 08:25:10 --> Unable to connect to the database
ERROR - 2021-08-14 08:25:11 --> Unable to connect to the database
ERROR - 2021-08-14 08:25:18 --> Unable to connect to the database
ERROR - 2021-08-14 08:25:31 --> Unable to connect to the database
ERROR - 2021-08-14 08:25:31 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server]Named Pipes Provider: Could not open a connection to SQL Server [53].  - Invalid query: SELECT SubscriptionPlan_No, Product_ID, Product_Name, [Edition],
                        SubscriptionName
                        ,Amount_Before_GST
                        ,GST
                        ,Amount_After_GST
						,OfferPrice
						
                    FROM [SubscriptionPlan]
ERROR - 2021-08-14 08:25:31 --> Severity: error --> Exception: Call to a member function num_rows() on bool D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\models\subscriptionplan_Model.php 22
ERROR - 2021-08-14 08:26:19 --> Unable to connect to the database
ERROR - 2021-08-14 08:26:19 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server]Named Pipes Provider: Could not open a connection to SQL Server [53].  - Invalid query: SELECT SubscriptionPlan_No, Product_ID, Product_Name, [Edition],
                        SubscriptionName
                        ,Amount_Before_GST
                        ,GST
                        ,Amount_After_GST
						,OfferPrice
						
                    FROM [SubscriptionPlan]
ERROR - 2021-08-14 08:26:19 --> Severity: error --> Exception: Call to a member function num_rows() on bool D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\models\subscriptionplan_Model.php 22
ERROR - 2021-08-14 08:26:46 --> Unable to connect to the database
ERROR - 2021-08-14 08:27:34 --> Unable to connect to the database
ERROR - 2021-08-14 08:27:34 --> Unable to connect to the database
ERROR - 2021-08-14 08:27:34 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server]Named Pipes Provider: Could not open a connection to SQL Server [53].  - Invalid query: SELECT SubscriptionPlan_No, Product_ID, Product_Name, [Edition],
                        SubscriptionName
                        ,Amount_Before_GST
                        ,GST
                        ,Amount_After_GST
						,OfferPrice
						
                    FROM [SubscriptionPlan]
ERROR - 2021-08-14 08:27:34 --> Severity: error --> Exception: Call to a member function num_rows() on bool D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\models\subscriptionplan_Model.php 22
ERROR - 2021-08-14 08:27:41 --> Unable to connect to the database
ERROR - 2021-08-14 08:27:55 --> Unable to connect to the database
ERROR - 2021-08-14 08:27:55 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server]Named Pipes Provider: Could not open a connection to SQL Server [53].  - Invalid query: SELECT SubscriptionPlan_No, Product_ID, Product_Name, [Edition],
                        SubscriptionName
                        ,Amount_Before_GST
                        ,GST
                        ,Amount_After_GST
						,OfferPrice
						
                    FROM [SubscriptionPlan]
ERROR - 2021-08-14 08:27:55 --> Severity: error --> Exception: Call to a member function num_rows() on bool D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\models\subscriptionplan_Model.php 22
ERROR - 2021-08-14 08:28:43 --> Unable to connect to the database
ERROR - 2021-08-14 08:28:43 --> Unable to connect to the database
ERROR - 2021-08-14 08:28:43 --> Unable to connect to the database
ERROR - 2021-08-14 08:28:43 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server]Named Pipes Provider: Could not open a connection to SQL Server [53].  - Invalid query: SELECT SubscriptionPlan_No, Product_ID, Product_Name, [Edition],
                        SubscriptionName
                        ,Amount_Before_GST
                        ,GST
                        ,Amount_After_GST
						,OfferPrice
						
                    FROM [SubscriptionPlan]
ERROR - 2021-08-14 08:28:43 --> Severity: error --> Exception: Call to a member function num_rows() on bool D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\models\subscriptionplan_Model.php 22
ERROR - 2021-08-14 08:29:04 --> Unable to connect to the database
ERROR - 2021-08-14 08:29:04 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server]Named Pipes Provider: Could not open a connection to SQL Server [53].  - Invalid query: SELECT SubscriptionPlan_No, Product_ID, Product_Name, [Edition],
                        SubscriptionName
                        ,Amount_Before_GST
                        ,GST
                        ,Amount_After_GST
						,OfferPrice
						
                    FROM [SubscriptionPlan]
ERROR - 2021-08-14 08:29:04 --> Severity: error --> Exception: Call to a member function num_rows() on bool D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\models\subscriptionplan_Model.php 22
ERROR - 2021-08-14 08:29:52 --> Unable to connect to the database
ERROR - 2021-08-14 08:29:52 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server]Named Pipes Provider: Could not open a connection to SQL Server [53].  - Invalid query: SELECT SubscriptionPlan_No, Product_ID, Product_Name, [Edition],
                        SubscriptionName
                        ,Amount_Before_GST
                        ,GST
                        ,Amount_After_GST
						,OfferPrice
						
                    FROM [SubscriptionPlan]
ERROR - 2021-08-14 08:29:52 --> Severity: error --> Exception: Call to a member function num_rows() on bool D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\models\subscriptionplan_Model.php 22
ERROR - 2021-08-14 09:44:54 --> Unable to connect to the database
ERROR - 2021-08-14 09:47:23 --> Unable to connect to the database
ERROR - 2021-08-14 09:47:23 --> Unable to connect to the database
ERROR - 2021-08-14 09:47:23 --> Unable to connect to the database
ERROR - 2021-08-14 09:47:44 --> Unable to connect to the database
ERROR - 2021-08-14 09:47:44 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server]Named Pipes Provider: Could not open a connection to SQL Server [53].  - Invalid query: SELECT SubscriptionPlan_No, Product_ID, Product_Name, [Edition],
                        SubscriptionName
                        ,Amount_Before_GST
                        ,GST
                        ,Amount_After_GST
						,OfferPrice
						
                    FROM [SubscriptionPlan]
ERROR - 2021-08-14 09:47:44 --> Severity: error --> Exception: Call to a member function num_rows() on bool D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\models\subscriptionplan_Model.php 22
ERROR - 2021-08-14 10:10:33 --> Unable to connect to the database
