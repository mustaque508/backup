<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-01 06:49:28 --> Unable to connect to the database
ERROR - 2021-09-01 06:55:18 --> Unable to connect to the database
ERROR - 2021-09-01 06:57:34 --> Unable to connect to the database
ERROR - 2021-09-01 06:58:48 --> Unable to connect to the database
ERROR - 2021-09-01 06:58:48 --> Unable to connect to the database
ERROR - 2021-09-01 06:59:47 --> Unable to connect to the database
ERROR - 2021-09-01 06:59:47 --> Unable to connect to the database
ERROR - 2021-09-01 07:00:09 --> Unable to connect to the database
ERROR - 2021-09-01 07:00:09 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server]Named Pipes Provider: Could not open a connection to SQL Server [53].  - Invalid query: SELECT SubscriptionPlan_No, Product_ID, Product_Name, [Edition],
                        SubscriptionName
                        ,Amount_Before_GST
                        ,GST
                        ,Amount_After_GST
						,OfferPrice
						
                    FROM [SubscriptionPlan]
ERROR - 2021-09-01 07:00:09 --> Severity: error --> Exception: Call to a member function num_rows() on bool D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\models\subscriptionplan_Model.php 22
ERROR - 2021-09-01 07:00:12 --> Unable to connect to the database
