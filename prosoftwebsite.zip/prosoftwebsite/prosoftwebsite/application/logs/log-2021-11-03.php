<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-03 08:17:28 --> 404 Page Not Found: Dist/js
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-03 08:17:28 --> 404 Page Not Found: Dist/css
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-03 08:17:28 --> 404 Page Not Found: Dist/js
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-03 08:17:28 --> 404 Page Not Found: Dist/js
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-03 08:17:28 --> 404 Page Not Found: Dist/js
