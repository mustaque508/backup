<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-24 06:51:15 --> Unable to connect to the database
