<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-27 08:24:18 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-27 08:24:18 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-27 08:24:18 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-27 08:24:18 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-27 08:24:18 --> 404 Page Not Found: Dist/css
ERROR - 2021-10-27 12:06:10 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-27 12:06:10 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-27 12:06:10 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-27 12:06:10 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-27 12:06:10 --> 404 Page Not Found: Dist/css
