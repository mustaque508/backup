<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-20 08:37:32 --> 404 Page Not Found: Dist/js
ERROR - 2021-09-20 08:37:32 --> 404 Page Not Found: Dist/js
ERROR - 2021-09-20 08:37:32 --> 404 Page Not Found: Dist/js
ERROR - 2021-09-20 08:37:32 --> 404 Page Not Found: Dist/js
ERROR - 2021-09-20 08:37:33 --> 404 Page Not Found: Dist/css
