<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-21 07:26:14 --> 404 Page Not Found: Dist/css
ERROR - 2021-10-21 07:26:14 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-21 07:26:14 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-21 07:26:14 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-21 07:26:14 --> 404 Page Not Found: Dist/js
