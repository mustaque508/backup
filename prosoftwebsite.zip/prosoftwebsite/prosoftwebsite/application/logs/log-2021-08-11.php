<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-11 11:24:17 --> Unable to connect to the database
ERROR - 2021-08-11 11:27:16 --> Unable to connect to the database
ERROR - 2021-08-11 11:27:37 --> Unable to connect to the database
ERROR - 2021-08-11 11:27:37 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server]Named Pipes Provider: Could not open a connection to SQL Server [53].  - Invalid query: SELECT SubscriptionPlan_No, Product_ID, Product_Name, [Edition],
                        SubscriptionName
                        ,Amount_Before_GST
                        ,GST
                        ,Amount_After_GST
						,OfferPrice
						
                    FROM [SubscriptionPlan]
ERROR - 2021-08-11 11:27:37 --> Severity: error --> Exception: Call to a member function num_rows() on bool D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\models\subscriptionplan_Model.php 22
ERROR - 2021-08-11 11:28:30 --> Unable to connect to the database
ERROR - 2021-08-11 11:29:32 --> Unable to connect to the database
ERROR - 2021-08-11 11:29:53 --> Unable to connect to the database
ERROR - 2021-08-11 11:29:53 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server]Named Pipes Provider: Could not open a connection to SQL Server [53].  - Invalid query: SELECT SubscriptionPlan_No, Product_ID, Product_Name, [Edition],
                        SubscriptionName
                        ,Amount_Before_GST
                        ,GST
                        ,Amount_After_GST
						,OfferPrice
						
                    FROM [SubscriptionPlan]
ERROR - 2021-08-11 11:29:53 --> Severity: error --> Exception: Call to a member function num_rows() on bool D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\models\subscriptionplan_Model.php 22
ERROR - 2021-08-11 11:30:48 --> Unable to connect to the database
ERROR - 2021-08-11 11:33:20 --> Unable to connect to the database
ERROR - 2021-08-11 11:35:14 --> Unable to connect to the database
ERROR - 2021-08-11 11:37:28 --> Unable to connect to the database
ERROR - 2021-08-11 11:39:51 --> Unable to connect to the database
ERROR - 2021-08-11 11:40:49 --> Unable to connect to the database
ERROR - 2021-08-11 11:41:11 --> Unable to connect to the database
ERROR - 2021-08-11 11:41:11 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server]Named Pipes Provider: Could not open a connection to SQL Server [53].  - Invalid query: SELECT SubscriptionPlan_No, Product_ID, Product_Name, [Edition],
                        SubscriptionName
                        ,Amount_Before_GST
                        ,GST
                        ,Amount_After_GST
						,OfferPrice
						
                    FROM [SubscriptionPlan]
ERROR - 2021-08-11 11:41:11 --> Severity: error --> Exception: Call to a member function num_rows() on bool D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\models\subscriptionplan_Model.php 22
ERROR - 2021-08-11 11:49:39 --> Unable to connect to the database
ERROR - 2021-08-11 11:49:39 --> Unable to connect to the database
ERROR - 2021-08-11 11:54:50 --> Unable to connect to the database
ERROR - 2021-08-11 11:57:38 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 11:57:38 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 11:57:38 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 11:57:38 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 11:57:38 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 11:59:37 --> Unable to connect to the database
ERROR - 2021-08-11 12:00:40 --> Unable to connect to the database
ERROR - 2021-08-11 12:01:53 --> Unable to connect to the database
ERROR - 2021-08-11 12:02:00 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 12:02:00 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 12:02:00 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 12:02:00 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 12:02:00 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 12:04:02 --> Unable to connect to the database
ERROR - 2021-08-11 12:05:14 --> Unable to connect to the database
ERROR - 2021-08-11 12:08:00 --> Unable to connect to the database
ERROR - 2021-08-11 12:16:46 --> Unable to connect to the database
ERROR - 2021-08-11 12:18:00 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 12:18:00 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 12:18:00 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 12:18:00 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 12:18:00 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 12:19:52 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 12:19:52 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 12:19:52 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 12:19:52 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 12:19:52 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 12:24:46 --> Unable to connect to the database
ERROR - 2021-08-11 12:27:13 --> Unable to connect to the database
ERROR - 2021-08-11 12:27:13 --> Unable to connect to the database
ERROR - 2021-08-11 12:27:14 --> Unable to connect to the database
ERROR - 2021-08-11 12:27:17 --> Unable to connect to the database
ERROR - 2021-08-11 12:27:34 --> Unable to connect to the database
ERROR - 2021-08-11 12:27:34 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server]Named Pipes Provider: Could not open a connection to SQL Server [53].  - Invalid query: SELECT SubscriptionPlan_No, Product_ID, Product_Name, [Edition],
                        SubscriptionName
                        ,Amount_Before_GST
                        ,GST
                        ,Amount_After_GST
						,OfferPrice
						
                    FROM [SubscriptionPlan]
ERROR - 2021-08-11 12:27:34 --> Severity: error --> Exception: Call to a member function num_rows() on bool D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\models\subscriptionplan_Model.php 22
ERROR - 2021-08-11 12:28:22 --> Unable to connect to the database
ERROR - 2021-08-11 12:28:22 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server]Named Pipes Provider: Could not open a connection to SQL Server [53].  - Invalid query: SELECT SubscriptionPlan_No, Product_ID, Product_Name, [Edition],
                        SubscriptionName
                        ,Amount_Before_GST
                        ,GST
                        ,Amount_After_GST
						,OfferPrice
						
                    FROM [SubscriptionPlan]
ERROR - 2021-08-11 12:28:22 --> Severity: error --> Exception: Call to a member function num_rows() on bool D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\models\subscriptionplan_Model.php 22
ERROR - 2021-08-11 12:29:52 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 12:29:52 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 12:29:52 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 12:29:52 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 12:30:12 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 12:30:33 --> Unable to connect to the database
ERROR - 2021-08-11 12:31:39 --> Unable to connect to the database
ERROR - 2021-08-11 12:31:39 --> Unable to connect to the database
ERROR - 2021-08-11 12:31:46 --> Unable to connect to the database
ERROR - 2021-08-11 12:32:00 --> Unable to connect to the database
ERROR - 2021-08-11 12:32:00 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server]Named Pipes Provider: Could not open a connection to SQL Server [53].  - Invalid query: SELECT SubscriptionPlan_No, Product_ID, Product_Name, [Edition],
                        SubscriptionName
                        ,Amount_Before_GST
                        ,GST
                        ,Amount_After_GST
						,OfferPrice
						
                    FROM [SubscriptionPlan]
ERROR - 2021-08-11 12:32:00 --> Severity: error --> Exception: Call to a member function num_rows() on bool D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\models\subscriptionplan_Model.php 22
ERROR - 2021-08-11 12:32:48 --> Unable to connect to the database
ERROR - 2021-08-11 12:32:48 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server]Named Pipes Provider: Could not open a connection to SQL Server [53].  - Invalid query: SELECT SubscriptionPlan_No, Product_ID, Product_Name, [Edition],
                        SubscriptionName
                        ,Amount_Before_GST
                        ,GST
                        ,Amount_After_GST
						,OfferPrice
						
                    FROM [SubscriptionPlan]
ERROR - 2021-08-11 12:32:48 --> Severity: error --> Exception: Call to a member function num_rows() on bool D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\models\subscriptionplan_Model.php 22
ERROR - 2021-08-11 12:32:54 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 12:32:54 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 12:32:54 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 12:32:54 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 12:32:54 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 12:34:30 --> Unable to connect to the database
ERROR - 2021-08-11 12:36:13 --> Unable to connect to the database
ERROR - 2021-08-11 12:37:55 --> Unable to connect to the database
ERROR - 2021-08-11 12:39:09 --> Unable to connect to the database
ERROR - 2021-08-11 12:41:19 --> Unable to connect to the database
ERROR - 2021-08-11 12:41:25 --> Unable to connect to the database
ERROR - 2021-08-11 12:42:58 --> Unable to connect to the database
ERROR - 2021-08-11 12:44:16 --> Unable to connect to the database
ERROR - 2021-08-11 12:45:51 --> Unable to connect to the database
ERROR - 2021-08-11 12:45:51 --> Unable to connect to the database
ERROR - 2021-08-11 12:47:15 --> Unable to connect to the database
ERROR - 2021-08-11 12:49:31 --> Unable to connect to the database
ERROR - 2021-08-11 12:50:38 --> Unable to connect to the database
ERROR - 2021-08-11 12:52:14 --> Unable to connect to the database
ERROR - 2021-08-11 12:53:29 --> Unable to connect to the database
ERROR - 2021-08-11 12:55:31 --> Unable to connect to the database
ERROR - 2021-08-11 12:55:44 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 12:55:44 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 12:55:44 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 12:55:44 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 12:55:44 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 12:57:31 --> Unable to connect to the database
ERROR - 2021-08-11 12:58:50 --> Unable to connect to the database
ERROR - 2021-08-11 13:00:10 --> Unable to connect to the database
ERROR - 2021-08-11 13:05:57 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:05:57 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:05:57 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:05:57 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:05:58 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 13:06:59 --> Unable to connect to the database
ERROR - 2021-08-11 13:07:00 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 13:07:02 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:07:02 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:07:02 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:07:02 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:10:35 --> Unable to connect to the database
ERROR - 2021-08-11 13:10:37 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 13:10:37 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:10:37 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:10:37 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:10:38 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:12:12 --> Unable to connect to the database
ERROR - 2021-08-11 13:12:13 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 13:12:14 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:12:14 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:12:14 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:12:15 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:14:26 --> Unable to connect to the database
ERROR - 2021-08-11 13:14:28 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 13:14:28 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:14:28 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:14:29 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:14:29 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:22:35 --> Unable to connect to the database
ERROR - 2021-08-11 13:22:36 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 13:22:36 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:22:36 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:22:37 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:22:37 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:23:55 --> Unable to connect to the database
ERROR - 2021-08-11 13:23:57 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 13:23:57 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:23:57 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:23:57 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:23:58 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:26:14 --> Unable to connect to the database
ERROR - 2021-08-11 13:26:16 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 13:26:16 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:26:17 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:26:17 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:26:17 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:27:34 --> Unable to connect to the database
ERROR - 2021-08-11 13:27:36 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 13:27:36 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:27:36 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:27:36 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:27:37 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:29:12 --> Unable to connect to the database
ERROR - 2021-08-11 13:29:14 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 13:29:15 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:29:16 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:29:16 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:29:16 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:33:03 --> Unable to connect to the database
ERROR - 2021-08-11 13:33:04 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 13:33:05 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:33:05 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:33:06 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:33:06 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:35:04 --> Unable to connect to the database
ERROR - 2021-08-11 13:35:05 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 13:35:06 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:35:06 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:35:06 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:35:06 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:38:00 --> Unable to connect to the database
ERROR - 2021-08-11 13:38:01 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:38:01 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:38:02 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 13:38:02 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:38:03 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:40:03 --> Unable to connect to the database
ERROR - 2021-08-11 13:40:03 --> Unable to connect to the database
ERROR - 2021-08-11 13:40:11 --> Unable to connect to the database
ERROR - 2021-08-11 13:40:15 --> Unable to connect to the database
ERROR - 2021-08-11 13:40:16 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 13:40:17 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:40:17 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:40:18 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:40:18 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:43:14 --> Unable to connect to the database
ERROR - 2021-08-11 13:43:15 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 13:43:16 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:43:16 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:43:16 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:43:17 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:44:29 --> Unable to connect to the database
ERROR - 2021-08-11 13:44:30 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 13:44:30 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:44:31 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:44:31 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:44:31 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:46:24 --> Unable to connect to the database
ERROR - 2021-08-11 13:46:25 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 13:46:27 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:46:27 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:46:27 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:46:28 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:48:33 --> Unable to connect to the database
ERROR - 2021-08-11 13:48:35 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 13:48:35 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:48:35 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:48:35 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:48:36 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:50:49 --> Unable to connect to the database
ERROR - 2021-08-11 13:50:51 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 13:50:51 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:50:51 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:50:51 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:50:52 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:53:29 --> Unable to connect to the database
ERROR - 2021-08-11 13:53:30 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 13:53:30 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:53:30 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:53:31 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:53:31 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:56:09 --> Unable to connect to the database
ERROR - 2021-08-11 13:57:31 --> Unable to connect to the database
ERROR - 2021-08-11 13:58:41 --> Unable to connect to the database
ERROR - 2021-08-11 13:59:32 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:59:32 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:59:32 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:59:32 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 13:59:33 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 14:00:16 --> Unable to connect to the database
ERROR - 2021-08-11 14:00:16 --> Unable to connect to the database
ERROR - 2021-08-11 14:00:19 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 14:00:19 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:00:19 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:00:19 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:00:20 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:00:37 --> Unable to connect to the database
ERROR - 2021-08-11 14:00:37 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server]Named Pipes Provider: Could not open a connection to SQL Server [53].  - Invalid query: SELECT SubscriptionPlan_No, Product_ID, Product_Name, [Edition],
                        SubscriptionName
                        ,Amount_Before_GST
                        ,GST
                        ,Amount_After_GST
						,OfferPrice
						
                    FROM [SubscriptionPlan]
ERROR - 2021-08-11 14:00:37 --> Severity: error --> Exception: Call to a member function num_rows() on bool D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\models\subscriptionplan_Model.php 22
ERROR - 2021-08-11 14:02:02 --> Unable to connect to the database
ERROR - 2021-08-11 14:02:04 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:02:04 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 14:02:04 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:02:05 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:02:06 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:02:29 --> Unable to connect to the database
ERROR - 2021-08-11 14:02:34 --> Unable to connect to the database
ERROR - 2021-08-11 14:02:36 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 14:02:36 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:02:36 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:02:36 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:02:37 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:03:46 --> Unable to connect to the database
ERROR - 2021-08-11 14:03:48 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 14:03:48 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:03:48 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:03:49 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:03:49 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:05:18 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:05:18 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:05:18 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:05:18 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:05:38 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 14:05:39 --> Unable to connect to the database
ERROR - 2021-08-11 14:05:41 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 14:05:41 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:05:41 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:05:41 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:05:42 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:06:55 --> Unable to connect to the database
ERROR - 2021-08-11 14:06:56 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:06:56 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:06:56 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 14:06:56 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:06:57 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:08:23 --> Unable to connect to the database
ERROR - 2021-08-11 14:08:23 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-11 14:08:25 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:08:25 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:08:25 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:08:26 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-11 14:09:44 --> Unable to connect to the database
ERROR - 2021-08-11 14:10:59 --> Unable to connect to the database
ERROR - 2021-08-11 14:12:06 --> Unable to connect to the database
ERROR - 2021-08-11 14:13:29 --> Unable to connect to the database
ERROR - 2021-08-11 14:16:33 --> Unable to connect to the database
ERROR - 2021-08-11 14:31:11 --> Unable to connect to the database
ERROR - 2021-08-11 14:35:27 --> Unable to connect to the database
