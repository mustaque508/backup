<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-13 09:24:40 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1231
ERROR - 2021-08-13 09:32:56 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 09:32:56 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 09:32:56 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 09:32:56 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 09:32:57 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 09:33:11 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 09:33:13 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 09:33:13 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 09:33:13 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 09:33:13 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 09:34:31 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 09:34:32 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 09:34:32 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 09:34:32 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 09:34:33 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 09:35:49 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 09:35:49 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 09:35:50 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 09:35:50 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 09:35:50 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:22:15 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:22:15 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:22:15 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:22:15 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:22:16 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 11:22:28 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 11:22:29 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:22:29 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:22:29 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:22:30 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:24:59 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:24:59 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:24:59 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:24:59 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:24:59 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 11:26:34 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:26:34 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:26:34 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:26:34 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:26:34 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 11:26:45 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:26:45 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:26:45 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:26:45 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:26:45 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 11:29:44 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 11:29:45 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:29:45 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:29:45 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:29:46 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:29:58 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 11:29:58 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:29:58 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:29:58 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:29:58 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:30:08 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 11:30:08 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:30:08 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:30:09 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:30:09 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:30:44 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 11:30:44 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:30:44 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:30:45 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:30:45 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:37:05 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 11:37:06 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:37:06 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:37:06 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:37:06 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:39:35 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 11:39:37 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:39:37 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:39:37 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:39:37 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:40:00 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 11:40:01 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:40:01 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:40:02 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:40:02 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:40:18 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 11:40:18 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:40:18 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:40:18 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:40:19 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:40:49 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 11:40:49 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:40:49 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:40:49 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:40:50 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:42:12 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 11:42:13 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:42:13 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:42:13 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:42:14 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:42:24 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 11:42:24 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:42:24 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:42:24 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:42:25 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:42:46 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 11:42:46 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:42:46 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:42:46 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:42:47 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:43:49 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 11:43:50 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:43:50 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:43:50 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:43:50 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:45:32 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 11:45:32 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:45:32 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:45:32 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:45:33 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:46:03 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 11:46:05 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:46:05 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:46:05 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:46:06 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:47:40 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 11:47:40 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:47:40 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:47:40 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:47:40 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:53:23 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:53:23 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:53:23 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:53:23 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:53:23 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 11:53:24 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 11:53:26 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:53:26 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:53:26 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:53:27 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:55:04 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:55:04 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:55:05 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:55:05 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:55:05 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 11:56:09 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:56:09 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 11:56:09 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:56:09 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:56:10 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:56:36 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 11:56:38 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:56:38 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:56:38 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 11:56:39 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 12:01:34 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 12:01:34 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 12:01:34 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 12:01:34 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 12:01:34 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 12:02:29 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 12:02:29 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 12:02:29 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 12:02:29 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 12:02:31 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 13:50:29 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1308
ERROR - 2021-08-13 13:50:39 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1308
ERROR - 2021-08-13 13:50:40 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1308
ERROR - 2021-08-13 13:50:43 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1308
ERROR - 2021-08-13 13:50:50 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1308
ERROR - 2021-08-13 13:51:23 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1280
ERROR - 2021-08-13 13:51:27 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1280
ERROR - 2021-08-13 13:51:28 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1280
ERROR - 2021-08-13 13:51:30 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1280
ERROR - 2021-08-13 13:52:24 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1308
ERROR - 2021-08-13 13:53:48 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1308
ERROR - 2021-08-13 13:53:50 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1308
ERROR - 2021-08-13 13:53:50 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1308
ERROR - 2021-08-13 13:53:51 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1308
ERROR - 2021-08-13 13:53:52 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1308
ERROR - 2021-08-13 13:53:53 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1308
ERROR - 2021-08-13 13:53:54 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1308
ERROR - 2021-08-13 13:53:54 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1308
ERROR - 2021-08-13 13:53:55 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1308
ERROR - 2021-08-13 13:53:55 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1308
ERROR - 2021-08-13 13:53:56 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1308
ERROR - 2021-08-13 13:53:56 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1308
ERROR - 2021-08-13 13:53:56 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1308
ERROR - 2021-08-13 13:53:56 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1308
ERROR - 2021-08-13 13:53:56 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1308
ERROR - 2021-08-13 13:53:57 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1308
ERROR - 2021-08-13 13:53:57 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1308
ERROR - 2021-08-13 13:55:07 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 13:55:07 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 13:55:07 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 13:55:07 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 13:55:07 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 13:55:09 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 13:55:11 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 13:55:11 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 13:55:11 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 13:55:12 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 13:55:27 --> 404 Page Not Found: Dist/css
ERROR - 2021-08-13 13:55:29 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 13:55:29 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 13:55:29 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 13:55:30 --> 404 Page Not Found: Dist/js
ERROR - 2021-08-13 14:01:46 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 663
ERROR - 2021-08-13 14:02:53 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1309
ERROR - 2021-08-13 14:05:40 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1312
ERROR - 2021-08-13 14:05:58 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1312
ERROR - 2021-08-13 14:05:59 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1312
ERROR - 2021-08-13 14:05:59 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1312
ERROR - 2021-08-13 14:06:00 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1312
ERROR - 2021-08-13 14:06:00 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1312
ERROR - 2021-08-13 14:06:24 --> Severity: error --> Exception: syntax error, unexpected end of file D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\main.php 1310
ERROR - 2021-08-13 15:59:57 --> Unable to connect to the database
ERROR - 2021-08-13 15:59:57 --> Unable to connect to the database
ERROR - 2021-08-13 16:00:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-08-13 16:00:57 --> Unable to connect to the database
ERROR - 2021-08-13 16:01:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-08-13 16:01:05 --> Unable to connect to the database
ERROR - 2021-08-13 16:01:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-08-13 16:01:13 --> Unable to connect to the database
ERROR - 2021-08-13 16:01:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-08-13 16:01:13 --> Unable to connect to the database
ERROR - 2021-08-13 16:01:13 --> Query error: Access denied for user ''@'localhost' (using password: NO) - Invalid query: SELECT SubscriptionPlan_No, Product_ID, Product_Name, [Edition],
                        SubscriptionName
                        ,Amount_Before_GST
                        ,GST
                        ,Amount_After_GST
						,OfferPrice
						
                    FROM [SubscriptionPlan]
ERROR - 2021-08-13 16:01:13 --> Severity: error --> Exception: Call to a member function num_rows() on bool D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\models\subscriptionplan_Model.php 22
ERROR - 2021-08-13 16:01:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-08-13 16:01:16 --> Unable to connect to the database
ERROR - 2021-08-13 16:02:42 --> Unable to connect to the database
ERROR - 2021-08-13 16:03:05 --> Unable to connect to the database
ERROR - 2021-08-13 16:04:03 --> Unable to connect to the database
ERROR - 2021-08-13 16:05:36 --> Unable to connect to the database
ERROR - 2021-08-13 16:07:51 --> Unable to connect to the database
ERROR - 2021-08-13 16:12:55 --> Unable to connect to the database
ERROR - 2021-08-13 16:13:07 --> Unable to connect to the database
ERROR - 2021-08-13 16:18:05 --> Unable to connect to the database
ERROR - 2021-08-13 16:20:02 --> Unable to connect to the database
ERROR - 2021-08-13 16:29:30 --> Unable to connect to the database
ERROR - 2021-08-13 16:34:12 --> Unable to connect to the database
ERROR - 2021-08-13 16:38:11 --> Unable to connect to the database
ERROR - 2021-08-13 16:41:41 --> Unable to connect to the database
ERROR - 2021-08-13 16:47:45 --> Unable to connect to the database
ERROR - 2021-08-13 16:51:10 --> Unable to connect to the database
ERROR - 2021-08-13 16:51:11 --> Unable to connect to the database
ERROR - 2021-08-13 16:55:35 --> Unable to connect to the database
ERROR - 2021-08-13 16:59:14 --> Unable to connect to the database
ERROR - 2021-08-13 17:05:05 --> Unable to connect to the database
ERROR - 2021-08-13 17:08:49 --> Unable to connect to the database
ERROR - 2021-08-13 17:15:32 --> Unable to connect to the database
ERROR - 2021-08-13 17:15:32 --> Unable to connect to the database
ERROR - 2021-08-13 17:18:52 --> Unable to connect to the database
ERROR - 2021-08-13 17:22:00 --> Unable to connect to the database
ERROR - 2021-08-13 17:31:41 --> Unable to connect to the database
ERROR - 2021-08-13 17:35:58 --> Unable to connect to the database
ERROR - 2021-08-13 17:37:50 --> Unable to connect to the database
ERROR - 2021-08-13 17:39:29 --> Unable to connect to the database
ERROR - 2021-08-13 17:45:47 --> Unable to connect to the database
ERROR - 2021-08-13 17:47:36 --> Unable to connect to the database
ERROR - 2021-08-13 17:53:48 --> Unable to connect to the database
ERROR - 2021-08-13 17:57:26 --> Unable to connect to the database
ERROR - 2021-08-13 17:57:26 --> Unable to connect to the database
