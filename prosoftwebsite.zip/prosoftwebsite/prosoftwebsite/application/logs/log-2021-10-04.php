<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-04 12:45:04 --> Severity: error --> Exception: Call to a member function result_array() on array D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\payment.php 69
ERROR - 2021-10-04 09:15:40 --> 404 Page Not Found: Dist/css
ERROR - 2021-10-04 09:15:40 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-04 09:15:40 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-04 09:15:40 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-04 09:15:40 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-04 09:17:45 --> 404 Page Not Found: Dist/css
ERROR - 2021-10-04 09:17:45 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-04 09:17:45 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-04 09:17:45 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-04 09:17:45 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-04 15:21:06 --> Severity: error --> Exception: Call to a member function result_array() on array D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\views\payment.php 69
