<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-11 08:59:44 --> 404 Page Not Found: Dist/js
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-11 08:59:44 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 08:59:44 --> 404 Page Not Found: Dist/js
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-11 08:59:44 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 08:59:44 --> 404 Page Not Found: Dist/css
ERROR - 2021-10-11 08:59:50 --> 404 Page Not Found: Dist/css
ERROR - 2021-10-11 08:59:50 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 08:59:50 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 08:59:50 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 08:59:50 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 09:00:03 --> 404 Page Not Found: Dist/css
ERROR - 2021-10-11 09:00:03 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 09:00:03 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 09:00:03 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 09:00:03 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:21:50 --> Severity: error --> Exception: syntax error, unexpected '$user_id' (T_VARIABLE) D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\controllers\UserInfo.php 285
ERROR - 2021-10-11 13:24:16 --> 404 Page Not Found: Dist/css
ERROR - 2021-10-11 13:24:16 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:24:16 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:24:16 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:24:16 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:24:34 --> 404 Page Not Found: Dist/css
ERROR - 2021-10-11 13:24:34 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:24:34 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:24:34 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:24:34 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:38:42 --> 404 Page Not Found: Dist/css
ERROR - 2021-10-11 13:38:43 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:38:43 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:38:43 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:38:43 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:38:48 --> Severity: error --> Exception: syntax error, unexpected '}' D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\models\UserInfo_Model.php 42
ERROR - 2021-10-11 13:40:17 --> 404 Page Not Found: Dist/css
ERROR - 2021-10-11 13:40:17 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:40:17 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:40:17 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:40:17 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:40:42 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ';' or ',' D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\models\UserInfo_Model.php 42
ERROR - 2021-10-11 13:45:00 --> 404 Page Not Found: Dist/css
ERROR - 2021-10-11 13:45:00 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:45:00 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:45:00 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:45:00 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:45:51 --> 404 Page Not Found: Dist/css
ERROR - 2021-10-11 13:45:51 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:45:51 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:45:51 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:45:51 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:46:32 --> 404 Page Not Found: Dist/css
ERROR - 2021-10-11 13:46:32 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:46:32 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:46:32 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:46:32 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:47:15 --> 404 Page Not Found: Dist/css
ERROR - 2021-10-11 13:47:15 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:47:15 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:47:15 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-11 13:47:16 --> 404 Page Not Found: Dist/js
