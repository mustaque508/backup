<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-01 07:26:42 --> 404 Page Not Found: Dist/css
ERROR - 2021-10-01 07:26:42 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-01 07:26:42 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-01 07:26:42 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-01 07:26:43 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-01 08:55:14 --> 404 Page Not Found: Dist/css
ERROR - 2021-10-01 08:55:14 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-01 08:55:14 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-01 08:55:14 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-01 08:55:14 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-01 09:04:28 --> Severity: error --> Exception: syntax error, unexpected '{' D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\controllers\UserInfo.php 773
ERROR - 2021-10-01 09:04:35 --> Severity: error --> Exception: syntax error, unexpected '{' D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\controllers\UserInfo.php 773
ERROR - 2021-10-01 09:04:37 --> Severity: error --> Exception: syntax error, unexpected '{' D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\controllers\UserInfo.php 773
ERROR - 2021-10-01 09:04:38 --> Severity: error --> Exception: syntax error, unexpected '{' D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\controllers\UserInfo.php 773
ERROR - 2021-10-01 09:04:38 --> Severity: error --> Exception: syntax error, unexpected '{' D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\controllers\UserInfo.php 773
ERROR - 2021-10-01 09:04:39 --> Severity: error --> Exception: syntax error, unexpected '{' D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\controllers\UserInfo.php 773
ERROR - 2021-10-01 09:05:14 --> Severity: error --> Exception: syntax error, unexpected '{' D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\controllers\UserInfo.php 773
ERROR - 2021-10-01 09:05:16 --> Severity: error --> Exception: syntax error, unexpected '{' D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\controllers\UserInfo.php 773
ERROR - 2021-10-01 09:05:22 --> Severity: error --> Exception: syntax error, unexpected '{' D:\development\web\xampp\htdocs\prosoftwebsite\prosoftwebsite\application\controllers\UserInfo.php 773
ERROR - 2021-10-01 09:06:05 --> 404 Page Not Found: Dist/css
ERROR - 2021-10-01 09:06:05 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-01 09:06:05 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-01 09:06:05 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-01 09:06:06 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-01 09:06:49 --> 404 Page Not Found: Dist/css
ERROR - 2021-10-01 09:06:49 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-01 09:06:49 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-01 09:06:49 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-01 09:06:49 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-01 09:07:06 --> 404 Page Not Found: Dist/css
ERROR - 2021-10-01 09:07:06 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-01 09:07:06 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-01 09:07:06 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-01 09:07:06 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-01 09:07:19 --> 404 Page Not Found: Dist/css
ERROR - 2021-10-01 09:07:19 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-01 09:07:19 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-01 09:07:19 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-01 09:07:19 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-01 09:09:10 --> 404 Page Not Found: Dist/css
ERROR - 2021-10-01 09:09:10 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-01 09:09:10 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-01 09:09:10 --> 404 Page Not Found: Dist/js
ERROR - 2021-10-01 09:09:10 --> 404 Page Not Found: Dist/js
