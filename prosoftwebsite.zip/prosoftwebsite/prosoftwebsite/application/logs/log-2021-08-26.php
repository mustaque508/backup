<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-26 15:48:42 --> Unable to connect to the database
ERROR - 2021-08-26 15:49:53 --> Unable to connect to the database
ERROR - 2021-08-26 15:52:22 --> Unable to connect to the database
ERROR - 2021-08-26 15:57:13 --> Unable to connect to the database
