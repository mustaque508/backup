 <!-- email configure -->
<?php

$config['protocol']='smtp';
// $config['smtp_host']='ssl://smtp.gmail.com';
// $config['smtp_port']='465';

$config['smtp_host']='prosoftesolutions.com';
$config['smtp_port']='587';
$config['smtp_timeout']='60';
// $config['smtp_crypto']='ssl';

// $config['smtp_user']='mustaquemj1111@gmail.com'; //for testing purpose
// $config['smtp_pass']='Mustaqmj@1';                 //for testing purpose

$config['smtp_user']='noreply@prosoftesolutions.com'; 
$config['smtp_pass']='ProUser@123';


$config['charset']='utf-8';
$config['newline']="\r\n";
$config['mailtype']='html';
$config['validation']=TRUE;
// $config['smtp_timeout']=2;
?>