
<!-- this view will be displayed when the forgotpassword link has been sent the user's email id -->

<section clas="msg-section">
 <div class="msg-div">

<!-- <?php

// $Name=$this->input->post('Name');
$Email=$this->input->post('Email');

?> -->

<h5>
    for change password.........
</h5>
<p>
    we have sent a mail to <?php echo $Email ?> go and check it....
</p>


</section>