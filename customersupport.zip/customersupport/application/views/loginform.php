
<!-- login form -->
  <section class="login-section">
        <div class="container">
            <div class="row">
                <div class="login-image">
                    <img src="<?php echo base_url();?>dist/img/Login.svg" alt="Login.svg" width="500" height="500" class="img-fluid">
                </div>
                <div class="card">
                    <div class="card-body ">

                        <?php echo form_open('user_login/login','class="form-group"')?>

                            <h2 class="text-center">Sign in</h2>

                            <?php if($error=$this->session->flashdata('error')):?>

                                <div class="alert alert-danger">
                                
                                    <?php echo $error; ?>
                                
                                </div>

                            <?php endif; ?>


                            <?php if($success=$this->session->flashdata('success')):?>

                                <div class="alert alert-success">

                                    <?php echo $success; ?>

                                </div>

                            <?php endif; ?>


                          

                            <?php echo form_label('Email Address','email')?>
                            <?php echo form_input(['class'=>'form-control','name'=>'Email','type'=>'email', 'id'=>'Email','value'=>''.($this->input->cookie('emailcookie')? $this->input->cookie('emailcookie') : set_value('Email')).''])?>
                                <?php echo form_error('Email',"<p class='text-danger'>","</p>")?>

                            <?php echo form_label('Password','pass')?>
                            <?php echo form_input(['class'=>'form-control','name'=>'Password','type'=>'password','value'=>''.($this->input->cookie('passwordcookie')? $this->input->cookie('passwordcookie') : set_value('Password')).''])?>

                            <?php echo form_error('Password',"<p class='text-danger'>","</p>")?>

                            <?php echo form_checkbox('rememberme','',''.($this->input->cookie('rememberme')? $this->input->cookie('rememberme'):'').'')?>
                            <?php echo form_label('Remember Me','')?>
                           

                            <?php echo anchor('forgot/index','Forgot Password ?','class="float-right"')?>


                            <?php echo form_button(['class'=>'btn btn-primary mr-5','type'=>'submit'],'login')?>

                           

                         
                            
                                <p>
                                        Don't have an account ? 
                                    <?php echo anchor('user_reg/reg','Register')?>
                                </p>
                                

                            <?php echo form_close();?>
                    </div>
                </div>
            </div>
        </div>
  </section>


