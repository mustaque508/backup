<!-- Activationerror view

    this view display the Activationerrors
    
 -->


<?php if($error=$this->session->flashdata('error')): ?>

<div class="alert alert-danger">
    <?php echo $error; ?>
</div>


<?php endif;?>