
<!-- this view will be displayed when user successfully logged in -->

    

<section class="sidebar-section">
    <div class="container-fluid" >
        <div class="row">

            <div class=" col-xl-2 col-md-3 col-sm-12 ">
                <div class="side-bar shadow p-3 mb-5 ">
                            <div class="user-p">
                                <img src="<?php echo base_url();?>dist/img/avatar.png" alt="avtar.png">
                            </div>
                            <ul class="list-unstyled">
                                <a href="<?php echo base_url();?>index.php/user_login/complaint_form">
                                    <li>
                                        <i class="fa fa-comments">
                                        <span class="ml-1">Complaints</span>
                                        </i>  
                                    </li>
                                </a>

                                <a href="<?php echo base_url();?>index.php/user_login/show_youtube">
                                    <li>
                                        <i class="fa fa-video-camera">
                                        <span class="ml-1">Videos</span>
                                        </i>  
                                    </li>
                                </a>

                                <a href="<?php echo base_url();?>index.php/user_login/logout">
                                    <li>
                                        <i class="fa fa-power-off">
                                        <span class="ml-1">Logout</span>
                                        </i>  
                                    </li>
                                </a>

                                
                            </ul>
                    </div>
            
            </div>
            
            <div class="col-sm">
                    <nav class="nav-bar sticky-top shadow-sm p-2 mb-5">
                        <input type="checkbox" id="checkbox">
                            <label for="checkbox">
                                    <i id="navbtn" class="fa fa-bars" aria-hidden="true" title="menu"></i>
                            </label>

                            <span class="u-name">WELCOME BACK,  <b><?php echo $this->session->userdata("Name");?></span>
                    </nav>
                      
            </div>
           
    </div>
   
  </div>
</section>

<!-- responsive code -->
<script>
    
    $(document).ready(function(){

        // sidebar animation
        $('input[type="checkbox"]').click(function(){
            if($(this).prop("checked") == true){
                $('.side-bar').removeClass("animate__animated animate__slideOutLeft");
                $('.side-bar').addClass("animate__animated animate__slideInLeft");
                $('.side-bar').css("z-index","100");
                $('.side-bar').css('width','100%');
                $('.side-bar').css('display','inline');
                console.log("checked");
            }
            else if($(this).prop("checked") == false){
                $('.side-bar').removeClass("animate__animated animate__slideInLeft");
                $('.side-bar').addClass("animate__animated animate__slideOutLeft");
                // $('.side-bar').css('display','none');
                console.log("unchecked");
            }
        });
    })
</script>

















                    