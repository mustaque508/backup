
<!-- this view will be displayed when the user want to activate his/her account from different system -->

<section class="Register-section">
    <div class="container">

        <div class="row">
            <div class="card">
                <div class="card-body">

                <?php echo form_open('devicechanger/getData','class="form-group"')?>

                    <h5 class="text-center">Something went wrong .</h5>

                     <?php if($error=$this->session->flashdata('error')): ?>

                        <div class="alert alert-danger">
                            <?php echo $error ?>
                        </div>

                    <?php endif;?> 

                  
                   <?php echo form_label('Enter your register password','pass')?>
                   <?php echo form_input(['class'=>'form-control password','name'=>'Password','type'=>'password','id'=>'pass'],set_value('Password'))?>
                   <?php echo form_error('Password',"<p class='text-danger'>","</p>")?>

                 
                 


                   <?php echo form_button(['class'=>'btn btn-primary','type'=>'submit'],'submit')?>
                   
                <?php echo form_close();?>
                </div>
            </div>
           
           
        </div>
    </div>
</section>




 
