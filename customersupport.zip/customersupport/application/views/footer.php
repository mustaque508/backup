
<!-- footer part  -->
 

<!-- to display country code -->
    <script src="<?php echo base_url();?>dist/js/intlTelInput.js"></script>

    <script src="<?php echo base_url();?>dist/js/utils.js"></script> 
    <script src="<?php echo base_url();?>dist/js/popper.js"></script>

<!-- bootstrap.js -->
    <script src="<?php echo base_url();?>dist/js/bootstrap.js"></script>

<!-- toaster.js -->
    <script src="<?php echo base_url();?>dist/js/toasty.js"></script>

<!-- calling country code method -->
    <script src="<?php echo base_url();?>dist/js/countrycode.js"></script>

<!-- youtube API -->
    <script src="<?php echo base_url();?>dist/js/youtube.js"></script>

  <!-- font-awesome -->
    <script src='https://kit.fontawesome.com/a076d05399.js'></script>


</body>
</html>

<!-- right click disable -->
<!-- <script>
  $(document).bind("contextmenu",function(e) {
 e.preventDefault();
}); -->
</script>