
<!-- this view will be displayed when the user forgot his/her password -->

<section>
        <div class="container">
                <div class="row">
                    <div class="forgot_div">

                            <?php echo form_open('forgot/forgotpassword','class="form-group"')?>

                                <h2 class="text-center">Forgot password</h2>

                                <?php if($error=$this->session->flashdata('error')):?>

                                <div class="alert alert-danger">

                                    <?php echo $error; ?>

                                </div>

                                <?php endif; ?>


                                <?php if($success=$this->session->flashdata('success')):?>


                                <div class="alert alert-success">

                                    <?php echo $success; ?>

                                </div>

                                <?php endif; ?>


                                <?php echo form_label('Email Address','email')?>
                                <?php echo form_input(['class'=>'form-control','name'=>'Email','type'=>'email'], set_value('Email'))?>
                                <?php echo form_error('Email',"<p class='text-danger'>","</p>")?>

                                <?php echo form_button(['class'=>'btn btn-primary','type'=>'submit'],'submit')?>
                    </div>


                </div>
        </div>

</section>