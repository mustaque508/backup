
<!-- header  part -->
<!doctype html>
<html lang="en">
  <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

      <!-- font-family -->
      <link href="https://fonts.googleapis.com/css?family=Assistant" rel="stylesheet">

      <!-- Bootstrap CSS -->
      
      <link rel="stylesheet" href="<?php echo base_url();?>dist/css/bootstrap.css">


      <!-- toast.css -->
      <link href="<?php echo base_url();?>dist/css/toasty.css" rel="stylesheet" />
      

      <!-- country code styling file -->
      <link rel="stylesheet" href="<?php echo base_url();?>dist/css/intlTelInput.css">

      <!-- font-awesome -->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

      


      <!-- custom css -->
      <link rel="stylesheet" href="<?php echo base_url();?>dist/css/loginform.css">
      <link rel="stylesheet" href="<?php echo base_url();?>dist/css/regform.css">
      <link rel="stylesheet" href="<?php echo base_url();?>dist/css/change_password.css">
      <link rel="stylesheet" href="<?php echo base_url();?>dist/css/sidebar.css">
      <link rel="stylesheet" href="<?php echo base_url();?>dist/css/complaintform.css">
      <link rel="stylesheet" href="<?php echo base_url();?>dist/css/complaint_view.css">
      <link rel="stylesheet" href="<?php echo base_url();?>dist/css/youtube.css">
      

      <!-- testing purpose -->
      <!-- <link rel="stylesheet" href="<?php echo base_url();?>dist/css/demo.css"> -->
      

      <!-- jquery -->
        <script src="<?php echo base_url();?>dist/js/jquery-3.2.1.js"></script>


        

      <title>User Form</title>
  </head>
  
  <body>
   

