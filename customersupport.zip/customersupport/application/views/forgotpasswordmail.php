
<!-- this file will be sent to the user's email-id for change password -->

<?php

include_once('header.php');

?>
<section>

  <div class="container">
      <div class="row">
          <div class="emailmes-div">
               
                <p>
                    <a href="<?php echo base_url();?>index.php/forgot/confirm">click here </a> to change your password of prosoftesolutions.
                </p>
          </div>
      </div>
  </div>
</section>

<?php

include_once('footer.php');

?>

































