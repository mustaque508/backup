
<!-- register form -->
<section class="Register-section">
        <div class="container">

            <div class="row">
                <div class="Register-image">
                    <img src="<?php echo base_url();?>dist/img/Login.svg" alt="Login.svg" width="500" height="500" class="img-fluid">
                </div>


                <div class="card">
                    <div class="card-body">

                    <?php echo form_open('user_reg/getData','class="form-group"')?>

                        <h2 class="text-center">Register Form</h2>

                        <?php if($error=$this->session->flashdata('error')): ?>

                            <div class="alert alert-danger">
                                <?php echo $error ?>
                            </div>

                        <?php endif;?>

                        <?php if($success=$this->session->flashdata('success')): ?>

                            <div class="alert alert-success">
                            
                            <?php echo $success ?>
                            
                            </div>


                        <?php endif; ?>


                    <?php echo form_label('Enter your name','Name')?>
                    <?php echo form_input(['class'=>'form-control','name'=>'Name','type'=>'text','id'=>'Name'], set_value('Name'))?>
                        <?php echo form_error('Name',"<p class='text-danger'>","</p>")?>

                        

                        <?php echo form_label('Contact Number','Contact')?>
                    <?php echo form_input(['class'=>'form-control','name'=>'Contact','type'=>'tel','id'=>'phone'],set_value('Contact'))?>
                    <?php echo form_error('Contact',"<p class='text-danger contact'>","</p>")?>

                        
                        <!-- <p id="hide"></p> -->
                    
                        <?php echo form_label('Email Address','email')?>
                    <?php echo form_input(['class'=>'form-control','name'=>'Email','type'=>'email'],set_value('Email'))?>
                        <?php echo form_error('Email',"<p class='text-danger'>","</p>")?>


                        <?php echo form_label('Serial_key','Serial_key')?>
                    <?php echo form_input(['class'=>'form-control','name'=>'Serial_key','type'=>'text'],set_value('Serial_key'))?>
                        <?php echo form_error('Serial_key',"<p class='text-danger'>","</p>")?>



                        <!-- <?php echo form_label('Maintenance Code','maintain_code')?>
                    <?php echo form_input(['class'=>'form-control','name'=>'maintain_code','type'=>'text'],set_value('maintain_code'))?>
                        <?php echo form_error('maintain_code',"<p class='text-danger'>","</p>")?> -->



                    

                    <?php echo form_label('Enter password','pass')?>
                    <div class="input-group">
                        <?php echo form_input(['class'=>'form-control password','name'=>'Password','type'=>'password','id'=>'pass'],set_value('Password'))?>
                        <?php echo form_error('Password',"<p class='text-danger'>","</p>")?>
                        
                        <div class="input-group-prepend d-flex align-items-center">
                            <span class="input-group-text form-control">
                                <!-- <i class="fa fa-info-circle" aria-hidden="true" style="color:#0A3FFF; cursor:pointer" id="pass_rules" data-toggle="tooltip" data-placement="right"></i> -->
                                <i class="fa fa-info-circle" aria-hidden="true" style="color:#0A3FFF; cursor:pointer" id="pass_rules" data-toggle="popover" title=" The password must include" data-content></i>
                                
                            </span>
                        </div>
                    </div>


                    <!-- password rules -->
                    <div class="hide">
                        <ul class="list-unstyled">
                            <li>length should be minimum 8 characters.</li>
                            <li>atleast one numeric character.</li>
                            <li>atleast one Alphabetic letter.</li>
                            <li>atleast one capital letter.</li>
                            <li>one special character.</li>
                            <li>should not contain white space.</li>
                        </ul>
                      
                    </div>
                


                    <?php echo form_label('Confirm password','cpass')?>
                    <?php echo form_input(['class'=>'form-control','name'=>'Cpassword','type'=>'password'],set_value('Cpassword'))?>
                    <?php echo form_error('Cpassword',"<p class='text-danger'>","</p>")?>


                    <?php echo form_button(['class'=>'btn btn-primary','type'=>'submit'],'submit')?>
                    
                    <?php echo form_close();?>
                    </div>
                </div>
            
            
            </div>
        </div>
</section>


<script>

// popover for password rules
$(document).ready(function(){

    $('#pass_rules').mouseover(function(){

        $('#pass_rules').attr('data-content',$('.hide').html());
        // $('[data-toggle="popover"]').css('border','1px solid black');
        $('#pass_rules').popover({
            html:true,
            placement: 'right'
        });
        $('#pass_rules').popover('show');
    });

    $('#pass_rules').mouseout(function(){
        $('#pass_rules').popover('hide'); 
    });

});

</script>


 
