
<!-- this  file will be sent to the user's email id when user has successfully registered. -->

<?php

include_once('header.php');

?>
<section>

  <div class="container">
      <div class="row">
          <div class="emailmess-div">
              <?php

              $Activationcode=md5($this->input->post('Email'));
              $ses_id=$this->session->userdata('Password');

              ?>
              <p>
              Thanks for registering on prosoftesolutions please <a style="margin-left:5px; margin-right:5px;" href="<?php echo base_url();?>index.php/user_reg/confirm?id=<?php echo $Activationcode?>&ses_id=<?php echo $ses_id?>">click here</a> to activate your account. you will be able to log into prosoftesolutions and start doing business.
              </p>
            
          
          </div>
          
      </div>
  </div>
</section>

<?php

include_once('footer.php');

?>