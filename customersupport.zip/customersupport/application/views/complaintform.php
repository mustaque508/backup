
<!-- complaint - form -->
<section class="complaint-section">
        <div class="container-fluid">
            <div class="row">

                <!-- complaint-form -->
                <div class=" col-md-5 mt-2">
                    <div class="card shadow p-3 mb-5 bg-white rounded">
                        <div class="card-body">
                            <h3 class="text-left font-weight-bold card-title">Add New Complaint</h3>
                                
                            <?php echo form_open('user_login/storecomplaint','class="form-group"')?>


                            <?php
                            if($this->session->flashdata('error'))
                            {
                                echo '<script>
                                
                                $(document).ready(function(){
                                    var options = {
                                                autoClose: true,
                                                progressBar: true,
                                                enableSounds: true

                                                }
    
                                                 var toast = new Toasty(options);
                                                    toast.configure(options);
    
                                                    toast.error("Sorry !!!! your complaint is not recorded please contact admin..");
                                                    console.log("success");
    
                                });
                                </script>';
                            }

                            ?>
                            
                            <?php
                            if($this->session->flashdata('success'))
                            {
                                echo '<script>
                                
                                $(document).ready(function(){
                                    var options = {
                                                autoClose: true,
                                                progressBar: true,
                                                enableSounds: true
                                                }
    
                                                 var toast = new Toasty(options);
                                                    toast.configure(options);
    
                                                    toast.success("Your complaint is recorded, we will solve your issue very soon");
                                                    console.log("success");
    
                                });
                                </script>';
                            }



                            ?>

                            <?php echo form_label('Serial Key','serial_key')?>
                            <?php echo form_input(['class'=>'form-control','name'=>'Serial_key','type'=>'text','readonly'=>'true','value'=>$this->session->userdata('serialkey')])?>

                            <?php echo form_label('Complaint','complaint',['class'=>'mt-3']) ?>
                            <?php echo form_textarea(['class'=>'form-control','name'=>'Complaint','value'=>set_value('Complaint')]) ?>
                            <?php echo form_error('Complaint',"<p class='text-danger'>","</p>")?>

                            <?php echo form_button([ 'id'=>'successtoast','class'=>'btn btn-primary mt-3 ','type'=>'submit'],'submit')?>
                            
                        </div>
                    </div>
                </div>

                <!-- complaint-list -->
                <div class="col-md-7 mt-2" >
                    <div class="card shadow p-3 mb-5 bg-white rounded">
                        <div class="card-body">

                           
                            <!-- <div class="row">
                                <div class="col">
                                        <h3 class="text-left font-weight-bold card-title">My Complaints</h3>
                                </div>
                            </div> -->

                             <!-- search box -->
                            <div class="row">
                              <div class="col d-flex align-items-center">
                                 <h3 class="text-left font-weight-bold card-title ">My Complaints</h3>
                              </div>
                                    
                                    <div class="col mb-2 ">
                                        <div class="input-group">
                                            <input class="form-control py-2 rounded-pill mr-1 pr-5 " type="search" placeholder="search" id="myInput">
                                                <span class="input-group-append">
                                                        <button class="btn rounded-pill border-0 ml-n5" type="button">
                                                            <i class="fa fa-search"></i>
                                                        </button>
                                                </span>
                                        </div>
                                    </div>
                            </div>
                            
                          
                                <!-- <table class="table complaint-list table-bordered">
                                    <thead>
                                        <tr class="table-info">
                                            <th scope="col"> S.No</th>
                                            <th scope="col">Complaint</th>
                                            <th scope="col">Complate date&time</th>
                                            <th scope="col">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                            if(empty($userdata))
                                            {
                                            ?>
                                        <tr>
                                            <td class="text-danger"><?php echo "No records found";?></td>
                                        </tr>
                                        <?php
                                            }
                                            else
                                            {
                                                $count=0;
                                            foreach ($userdata as $row) 
                                            {
                                                $count++;
                                            ?>
                                        <tr>
                                            <th scope="row"><?php echo $count; ?></th>
                                            <td><?php echo $row->Complaint; ?></td>
                                            <td><?php echo date_format(new DateTime($row->Comp_date_time),'d-m-Y h:i:sa') ?></td>
                                            <td>
                                                <?php
                                                    if($row->Status=="0"){
                                                        echo "<p style='color:red' class='font-weight-bold'>open</p>";
                                                    }
                                                    
                                                    if($row->Status=="1"){
                                                    echo "<p style='color:green' class='font-weight-bold'>closed</p>";
                                                    
                                                    }
                                                    
                                                    
                                                    
                                                    
                                                    ?>
                                            </td>
                                        </tr>
                                        <?php
                                            }
                                            }
                                            ?>
                                    </tbody>
                                </table> -->

                                <table class="table complaint-list table-bordered " id="myTable">
                                    
                                    <thead>
                                        <tr class="table-info ">
                                            <th scope="col">S.No</th>
                                            <th scope="col">Complaint No.</th>
                                            <th scope="col">Serial-key</th>
                                            <th scope="col">Complaint</th>
                                            <th scope="col">Complate Date</th>
                                            <th scope="col">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody >
                                        <?php 
                                            if(empty($userdata))
                                            {
                                            ?>
                                        <tr>
                                            <td class="text-danger text-center" colspan="6" ><?php echo "No records found";?></td>
                                        </tr>
                                        <?php
                                            }
                                            else
                                            {
                                                $count=0;
                                            foreach ($userdata as $row) 
                                            {
                                                $count++;
                                            ?>
                                        <tr class="tr">
                                            <th scope="row"><?php echo $count; ?></th>
                                            <td><?php echo $row->ComplaintNo; ?></td>
                                            <td><?php echo $row->Serial_key; ?></td>
                                            <td><?php echo $row->Complaint; ?></td>
                                            <td><?php echo date_format(new DateTime($row->Comp_date_time),'d-m-Y h:i:sa') ?></td>
                                            <td>
                                                <?php
                                                    if($row->Status=="0"){
                                                        echo "<p style='color:red' class='font-weight-bold'>open</p>";
                                                    }
                                                    
                                                    if($row->Status=="1"){
                                                    echo "<p style='color:green' class='font-weight-bold'>closed</p>";
                                                    
                                                    }
                                                    
                                                    
                                                    
                                                    
                                                    ?>
                                            </td>
                                        </tr>
                                        <?php
                                            }
                                            }
                                            ?>
                                    </tbody>
                                </table>                            
                        </div>

                        <!-- refresh button -->
                            <div class="row" style="margin-top:-1.5rem;">
                                    <div class="col-12">
                                        <!-- <button id="refresh-btn" class="icon-btn"> -->
                                            <i class="fa fa-refresh font-weight-bolder " aria-hidden="true" id="refresh-btn" style="cursor:pointer;">
                                            <span>Refresh</span> 
                                            </i>
                                           
                                           
                                        <!-- </button> -->
                                    </div>
                                    
                            </div>
                    </div>
                </div>

            </div>

            <!-- <div class="row" >

                <div class="col-sm-12">
                    <div class="card  shadow p-3 mb-5 bg-white rounded">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h3 class=" font-weight-bold card-title">Detail information of complaints</h3>
                                </div>

                                <div class="col">
                                    <div class="input-group mb-4 border rounded-pill p-1 mt-1">
                                        <input type="search" id="myInput" placeholder="What're you searching for?" aria-describedby="button-addon3" class="form-control bg-none border-0">
                                            <div class="input-group-append border-0">
                                                <button id="button-addon3" type="button" class="btn btn-link text-success"><i class="fa fa-search"></i></button>
                                            </div>
                                    </div>
                                </div>
                           
                          
                            <table class="table table-bordered " id="myTable">
                                
                                <thead >
                                    <tr class="table-info ">
                                        <th scope="col">S.No</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Serial-key</th>
                                        <th scope="col">Complaint</th>
                                        <th scope="col">Complate date&time</th>
                                        <th scope="col">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                        if(empty($userdata))
                                        {
                                        ?>
                                    <tr>
                                        <td class="text-danger"><?php echo "No records found";?></td>
                                    </tr>
                                    <?php
                                        }
                                        else
                                        {
                                            $count=0;
                                        foreach ($userdata as $row) 
                                        {
                                            $count++;
                                        ?>
                                    <tr>
                                        <th scope="row"><?php echo $count; ?></th>
                                        <td><?php echo $row->Name; ?></td>
                                        <td><?php echo $row->Serial_key; ?></td>
                                        <td><?php echo $row->Complaint; ?></td>
                                        <td><?php echo date_format(new DateTime($row->Comp_date_time),'d-m-Y h:i:sa') ?></td>
                                        <td>
                                            <?php
                                                if($row->Status=="0"){
                                                    echo "<p style='color:red' class='font-weight-bold'>pending</p>";
                                                }
                                                
                                                if($row->Status=="1"){
                                                echo "<p style='color:green' class='font-weight-bold'>solved</p>";
                                                
                                                }
                                                
                                                
                                                
                                                
                                                ?>
                                        </td>
                                    </tr>
                                    <?php
                                        }
                                        }
                                        ?>
                                </tbody>
                            </table>
                        </div>  
                    </div>
                </div>

            </div> -->
        </div>
</section>



<!-- search and refresh function -->
<script>
    $(document).ready(function()
    {

        // search function
        $("#myInput").on("keyup", function()
        {
            var value = $(this).val().toLowerCase();
            $("#myTable .tr").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });


        //refresh function
        $('#refresh-btn').on('click',function()
        {
            setTimeout(() => {
                $('#myTable').fadeOut('fast').load('<?php echo base_url();?>index.php/user_login/getcomplaints').fadeIn('fast');
                console.log("refresh button clicked..");
            },0);
        
        });


    });
</script>