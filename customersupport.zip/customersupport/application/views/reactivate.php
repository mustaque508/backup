
<!-- this view will be displayec to the user if the user want to reactivate account -->

<section>

    <div class="container">

        <div class="row">

            <div class="reactivate-div">
                <p>Your account is already activated... no need to reactivate....</p>
            </div>

        </div>

    </div>

</section>