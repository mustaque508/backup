<!-- youtube video -->

<section class="youtube-section">

    <div class="container-fluid">

        <!-- video player -->
        <div class="row">
            <div class="col-sm-12">
                    <div class="card video-card shadow p-3 mb-5 bg-white ">
                        <h3 class="card-title  font-weight-bolder">Video player</h3>
                            <div class="card-body">
                                    <!-- video screen -->
                                    <!-- <div class="col-sm-12"> -->
                                        <i class="fa fa-play-circle fa-5x iframe-button" aria-hidden="true" id="play" title="play"></i>
                                        <button type="button" title="backword 10sec"  id="backword-button"><img src="<?php echo base_url();?>dist/img/backward10sec.png"/></button>
                                        <button type="button" title="forward 10sec"  id="forward-button"><img src="<?php echo base_url();?>dist/img/forward10sec.png"/></button>
                                        <iframe  class="youtube-video " id="ytplayer"  src="https://www.youtube-nocookie.com/embed/Yhs_3eoIHjk?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN" modestbranding="0"  controls="0" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allownetworking="internal"></iframe>
                                   
                                    
                        
                        </div>
                       
                    </div>
            </div>
        </div>


        <!-- video controls -->
            <div class="row ">
                <div class="col-sm-12">
                    <div id="controls">
                            <div id="progressBar">
                                <div></div>
                            
                            </div>
                            <div class="youtube-buttons mt-1">
                                <button type="button" title="previous-video" class="btn  mr-2" id="prev-button"><i class="fa fa-step-backward"></i></button>
                                <button type="button" title="play" class="btn  mr-2" id="play-button"><i class="fa fa-play"></i></button>
                                <button type="button" title="next-video" class="btn mr-2" id="next-button"><i class="fa fa-step-forward"></i></button>
                                <button type="button" title="mute" class="btn  mr-2 " id="mute-button"><i class="fas fa-volume-down"></i></button>
                                <span class="current ml-2"></span>
                                <span>/</span>
                                <span class="duration"></span>
                            </div>

                    </div>
                </div>
            </div>


        <!-- playlist -->
        <div class="row video-playlist">

                <!-- Enterprise Edition playlist -->
                <div class="col-sm-12">
                    <div id="carouselControls" class="carousel slide shadow p-3 mb-5 bg-white rounded" data-interval="false">
                            <div class="carousel-inner">
                                <!-- <h1 class="text-center">playlist</h1> -->


                                <div class="carousel-item active ">
                                    <div class="row">

                                    <!-- video [TDR Import Process Single Area]  -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/Yhs_3eoIHjk/1.jpg" alt="video1.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/Yhs_3eoIHjk?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">TDR Import Process Single Area</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    <!-- video [TDR Import of Multiple Areas at One Time] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/hlAMpHUV4lU/1.jpg" alt="video2.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/hlAMpHUV4lU?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">TDR Import of Multiple Areas at One Time</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>


                                    <!-- video [Skipped rows Re-import] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/djQYqytjrPI/1.jpg" alt="video3.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/djQYqytjrPI?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Skipped rows Re-import</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    <!-- video [Show previous and next call of Target Number] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/T891DixRwJQ/1.jpg" alt="video4.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/T891DixRwJQ?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Show previous and next call of Target Number</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>




                                    </div>
                                </div>

                                <div class="carousel-item ">
                                    <div class="row">

                                        <!-- video [Sheet Formatting]  -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/fJWZ5sIl3T0/1.jpg" alt="video5.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/fJWZ5sIl3T0?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Sheet Formatting</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    <!-- video [SDR Manual Import] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/p-BIBeWWPaA/1.jpg" alt="video6.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/p-BIBeWWPaA?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">SDR Manual Import</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>


                                    <!-- video [SDR Import Log Report] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/zqC8OfBtgck/1.jpg" alt="video7.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/zqC8OfBtgck?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">SDR Import Log Report</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    <!-- video [SDR Import] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/dbNG8x1DZPI/1.jpg" alt="video8.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/dbNG8x1DZPI?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">SDR Import</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="carousel-item ">
                                    <div class="row">

                                        <!-- video [Quick Analysis Single CDR]  -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/HeURBiODsZ0/1.jpg" alt="video9.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/HeURBiODsZ0?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Quick Analysis Single CDR</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    <!-- video [Quick Analysis Multiple CDRs] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/-KUVytycqeU/2.jpg" alt="video10.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/-KUVytycqeU?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Quick Analysis Multiple CDRs</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>


                                    <!-- video [Pattern Analysis] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/eAxfQSAgmRE/1.jpg" alt="video11.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/eAxfQSAgmRE?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Pattern Analysis</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    <!-- video [Number Tracking] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/fr-SV6WmFRU/1.jpg" alt="video12.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/fr-SV6WmFRU?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Number Tracking</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="carousel-item ">
                                    <div class="row">

                                        <!-- video [Night Calls]  -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/eZqh-T4NltA/1.jpg" alt="video13.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/eZqh-T4NltA?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Night Calls</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    <!-- video [Multiple Place TDR Importing process] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/SwjhMocXmLM/1.jpg" alt="video14.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/SwjhMocXmLM?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Multiple Place TDR Importing process</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>


                                    <!-- video [Multiple CDR Import] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/UAaUXPHUewU/1.jpg" alt="video15.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/UAaUXPHUewU?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Multiple CDR Import</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    <!-- video [More Option - Service Number Suspect List] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/UcbpMJCdyOA/1.jpg" alt="video16.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/UcbpMJCdyOA?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">More Option - Service Number Suspect List</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="carousel-item ">
                                    <div class="row">

                                        <!-- video [More Option - New Number Note]  -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/L3k-uqtRS2A/1.jpg" alt="video17.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/L3k-uqtRS2A?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">More Option - New Number Note</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    <!-- video [More Option Insert Photo Audio Video] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/PPmDM-bXBsk/1.jpg" alt="video18.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/PPmDM-bXBsk?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">More Option Insert Photo Audio Video</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>


                                    <!-- video [More Options - Copy Scramble Highlight] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/ve2jwjDVVEU/1.jpg" alt="video19.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/ve2jwjDVVEU?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">More Options - Copy Scramble Highlight</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    <!-- video [Match With Other DB] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/ulHbfluHAXA/1.jpg" alt="video20.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/ulHbfluHAXA?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Match With Other DB</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="carousel-item ">
                                    <div class="row">

                                        <!-- video [Match With GeoFence]  -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/3THYYwfwSFw/1.jpg" alt="video21.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/3THYYwfwSFw?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Match With GeoFence</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    <!-- video [Match with External Files] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/zOWD-gpYzs8/1.jpg" alt="video22.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/zOWD-gpYzs8?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Match with External Files</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>


                                    <!-- video [Match Unmatch Number] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/pQTub5Gnn3g/1.jpg" alt="video23.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/pQTub5Gnn3g?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Match Unmatch Number</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    <!-- video [IPDR Manual Importing] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/FB1DklFWNpM/1.jpg" alt="video24.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/FB1DklFWNpM?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">IPDR Manual Importing</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="carousel-item ">
                                    <div class="row">

                                        <!-- video [In Roamers]  -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/6yyfZEhwxZI/1.jpg" alt="video25.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/6yyfZEhwxZI?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">In Roamers</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    <!-- video [IMEI Import] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/kUqDbVAPG2w/1.jpg" alt="video26.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/kUqDbVAPG2w?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">IMEI Import</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>


                                    <!-- video [Geo Movements] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/Wgh53IcO2ok/1.jpg" alt="video27.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/Wgh53IcO2ok?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Geo Movements</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    <!-- video [Geo Fence] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/mVw1D2eeWgM/1.jpg" alt="video28.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/mVw1D2eeWgM?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Geo Fence</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="carousel-item ">
                                    <div class="row">

                                        <!-- video [Geo Crime Mapping]  -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/CfTkAm1pVRg/1.jpg" alt="video29.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/CfTkAm1pVRg?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Geo Crime Mapping</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    <!-- video [Geo Analysis] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/XOoCdDpQhhM/1.jpg" alt="video30.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/XOoCdDpQhhM?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Geo Analysis</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>


                                    <!-- video [Fixed Calls and Conference calls] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/aFh4Hn63TsY/1.jpg" alt="video31.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/aFh4Hn63TsY?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Fixed Calls and Conference calls</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    <!-- video [Filter within Analysis] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/vadZsH8zowM/1.jpg" alt="video32.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/vadZsH8zowM?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Filter within Analysis</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="carousel-item ">
                                    <div class="row">

                                        <!-- video [Details and Both Party Present]  -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/FJydrHLynE0/1.jpg" alt="video33.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/FJydrHLynE0?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Details and Both Party Present</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    <!-- video [Delete SDR Data] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/qJGXVKuTEp8/1.jpg" alt="video34.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/qJGXVKuTEp8?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Delete SDR Data</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>


                                    <!-- video [Delete IPDR Data Analysis] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/Kv3wH8EKjM4/1.jpg" alt="video35.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/Kv3wH8EKjM4?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Delete IPDR Data Analysis</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    <!-- video [Delete Cell ID Data] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/pSiNbQfD1uY/1.jpg" alt="video36.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/pSiNbQfD1uY?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Delete Cell ID Data</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="carousel-item ">
                                    <div class="row">

                                        <!-- video [Delete CDR Data and Analysis]  -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/xmBukM_KJsw/1.jpg" alt="video37.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/xmBukM_KJsw?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Delete CDR Data and Analysis</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    <!-- video [Days Present] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/C6xzOemOFqU/1.jpg" alt="video38.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/C6xzOemOFqU?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Days Present</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>


                                    <!-- video [Dates when no calls made] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/VP-8B5iXILk/1.jpg" alt="video39.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/VP-8B5iXILk?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Dates when no calls made</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    <!-- video [Dashboard of Combined analysis] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/9JNBdhVdYGw/1.jpg" alt="video40.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/9JNBdhVdYGw?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Dashboard of Combined analysis</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="carousel-item ">
                                    <div class="row">

                                        <!-- video [Dashboard Location]  -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/rbyzuS2uZwg/1.jpg" alt="video41.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/rbyzuS2uZwg?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Dashboard Location</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    <!-- video [Dashboard Frequency] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/rkxNC4PNPU8/1.jpg" alt="video42.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/rkxNC4PNPU8?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Dashboard Frequency</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>


                                    <!-- video [Dashboard Analysis] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/GeyfSNW2z0c/1.jpg" alt="video43.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/GeyfSNW2z0c?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Dashboard Analysis</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    <!-- video [Create Sub Analysis] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/cVmya9p-_68/1.jpg" alt="video44.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/cVmya9p-_68?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Create Sub Analysis</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="carousel-item ">
                                    <div class="row">

                                        <!-- video [Contacts Primary and Secondary]  -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/CrMBj4chzsk/1.jpg" alt="video45.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/CrMBj4chzsk?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Contacts Primary and Secondary</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    <!-- video [Cell ID Import Log Report] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/mILhBLg4dJY/1.jpg" alt="video46.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/mILhBLg4dJY?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Cell ID Import Log Report</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>


                                    <!-- video [Cell ID Import] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/05rw5k7G9tI/1.jpg" alt="video47.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/05rw5k7G9tI?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Cell ID Import</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    <!-- video [CDR Import Manually] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/IktlVFdOJu8/1.jpg" alt="video48.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/IktlVFdOJu8?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">CDR Import Manually</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="carousel-item ">
                                    <div class="row">

                                        <!-- video [CDR Import Log Report]  -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/ia_Owdghuo0/1.jpg" alt="video49.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/ia_Owdghuo0?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">CDR Import Log Report</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    <!-- video [CDR Import Avoid Duplicates in CDR] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/76uJlB-DgTs/1.jpg" alt="video50.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/76uJlB-DgTs?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">CDR Import Avoid Duplicates in CDR</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>


                                    <!-- video [CDR Import Avoid Blank Call Types] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/0Ui9tf2Ld0c/1.jpg" alt="video51.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/0Ui9tf2Ld0c?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">CDR Import Avoid Blank Call Types</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    <!-- video [CDR Import] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/IHjPIrYqqMA/1.jpg" alt="video52.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/IHjPIrYqqMA?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">CDR Import</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="carousel-item ">
                                    <div class="row">

                                        <!-- video [Analysis Update data]  -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/XbjSMc0s1P8/1.jpg" alt="video53.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/XbjSMc0s1P8?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Analysis Update data</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    <!-- video [Add New CDR In Existing Analysis] -->
                                        <div class="card shadow-sm p-3 mb-5  rounded  ">
                                                <img  title="play video" id="next-play" class="img-thumbnail" src="http://img.youtube.com/vi/GTY_tXdbUBo/1.jpg" alt="video54.jpg" onClick="document.getElementById('ytplayer').src='https://www.youtube-nocookie.com/embed/GTY_tXdbUBo?enablejsapi=1&vq=hd1080&modestbranding=1&fs=0&rel=0&controls=0&listType=playlist&list=PL7Zm4iklj7qw18z6h8VRtVSuFZ1QtwLcN'">
                                                <div class="card-body">
                                                    <h6 class="card-title font-weight-bold text-dark">Add New CDR In Existing Analysis</h6>
                                                    <!-- <span>Description :</span>
                                                    <p class="card-text  text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, veritatis?</p> -->
                                                </div>
                                        </div>

                                    </div>
                                </div>

                            </div>

                            <a class="carousel-control-prev " href="#carouselControls" role="button" data-slide="prev">
                            <i class="fas fa-chevron-left carousel"></i>
                                        <span class="sr-only">Previous</span>
                            </a>

                            <a class="carousel-control-next" href="#carouselControls" role="button" data-slide="next">
                                <i class="fas fa-chevron-right"></i>
                                <span class="sr-only">Next</span>
                            </a>
                    </div>

                </div>
        </div>

    </div>
    
</section>


<script>
    $(document).ready(function(){
        if ($(window).width() < 480) {
            console.log("success");
            $(".carousel-item").removeClass("carousel-item");
            $(".fa-chevron-left").removeClass("fa-chevron-left");
            $(".fa-chevron-right").removeClass("fa-chevron-right");

        }
    });
</script>





