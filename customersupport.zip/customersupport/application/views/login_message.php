
<!-- this view will be displayed when user's password is successfully updated. -->

<section>
<div class="container">
    <div class="row">
        <div class="login-div">
            <h5>
                your password is successfully updated..
            </h5>
            <p>
                please <a href="<?php echo base_url();?>index.php/user_login/index">click here </a> to login...
            </p>
        </div>
    </div>
</div>
</section>