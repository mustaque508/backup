
<!-- this view display the change password form  -->

<section class="change_password-section">

            <div class="container">
                    <div class="row">
                            <div class="card">
                                    <div class="card-body">

                                        <?php echo form_open('forgot/getData','class="form-group"')?>

                                        <h2 class="text-center">change password form</h2>

                                    

                                                <?php echo form_label('Enter password','pass')?>
                                                <div class="input-group">
                                                    <?php echo form_input(['class'=>'form-control password','name'=>'Password','type'=>'password','id'=>'pass'],set_value('Password'))?>
                                                    <?php echo form_error('Password',"<p class='text-danger'>","</p>")?>

                                                    <div class="input-group-prepend d-flex align-items-center">
                                                        <span class="input-group-text form-control">
                                                            <!-- <i class="fa fa-info-circle" aria-hidden="true" style="color:#0A3FFF; cursor:pointer" id="pass_rules" data-toggle="tooltip" data-placement="right"></i> -->
                                                            <i class="fa fa-info-circle" aria-hidden="true" style="color:#0A3FFF; cursor:pointer" id="pass_rules" data-toggle="popover" title=" The password must include" data-content></i> 
                                                        </span>
                                                    </div>
                                                </div>

                                                 <!-- password rules -->
                                                    <div class="hide">
                                                            <ul class="list-unstyled">
                                                                <li>length should be minimum 8 characters.</li>
                                                                <li>atleast one numeric character.</li>
                                                                <li>atleast one Alphabetic letter.</li>
                                                                <li>atleast one capital letter.</li>
                                                                <li>one special character.</li>
                                                                <li>should not contain white space.</li>
                                                            </ul>
                                                    </div>
                                                


                                                <?php echo form_label('Confirm password','cpass')?>
                                                <?php echo form_input(['class'=>'form-control','name'=>'Cpassword','type'=>'password'],set_value('Cpassword'))?>
                                                <?php echo form_error('Cpassword',"<p class='text-danger'>","</p>")?>


                                                <?php echo form_button(['class'=>'btn btn-primary','type'=>'submit'],'submit')?>
                                        
                                                <?php echo form_close();?>
                                    </div>
                            </div>  
                    </div>
            </div>
</section>

<script>

// popover for password rules
$(document).ready(function(){

    $('#pass_rules').mouseover(function(){

        $('#pass_rules').attr('data-content',$('.hide').html());
        // $('[data-toggle="popover"]').css('border','1px solid black');
        $('#pass_rules').popover({
            html:true,
            placement: 'right'
        });
        $('#pass_rules').popover('show');
    });

    $('#pass_rules').mouseout(function(){
        $('#pass_rules').popover('hide'); 
    });

});

</script>
 
