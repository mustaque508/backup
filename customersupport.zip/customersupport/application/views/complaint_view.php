<!-- complaint view -->
<!-- <?php
    // time_zone
    date_default_timezone_set('Asia/Kolkata');
    
    ?> -->
<section class="complaintview-section">
    <table class="table table-bordered " id="myTable">
        <thead>
            <tr class="table-info ">
                <th scope="col">S.No</th>
                <th scope="col">Complaint No.</th>
                <th scope="col">Serial-key</th>
                <th scope="col">Complaint</th>
                <th scope="col">Complate Date</th>
                <th scope="col">Status</th>
            </tr>
        </thead>
        <tbody >
            <?php 
                if(empty($userdata))
                {
                ?>
            <tr>
                <td class="text-danger text-center" colspan="6" ><?php echo "No records found";?></td>
            </tr>
            <?php
                }
                else
                {
                    $count=0;
                foreach ($userdata as $row) 
                {
                    $count++;
                ?>
            <tr class="tr">
                <th scope="row"><?php echo $count; ?></th>
                <td><?php echo $row->ComplaintNo; ?></td>
                <td><?php echo $row->Serial_key; ?></td>
                <td><?php echo $row->Complaint; ?></td>
                <td><?php echo date_format(new DateTime($row->Comp_date_time),'d-m-Y h:i:sa') ?></td>
                <td>
                    <?php
                        if($row->Status=="0"){
                            echo "<p style='color:red' class='font-weight-bold'>open</p>";
                        }
                        
                        if($row->Status=="1"){
                        echo "<p style='color:green' class='font-weight-bold'>closed</p>";
                        
                        }
                        
                        
                        
                        
                        ?>
                </td>
            </tr>
            <?php
                }
                }
                ?>
        </tbody>
    </table>
</section>