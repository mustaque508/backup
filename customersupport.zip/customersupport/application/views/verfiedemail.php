<!-- display this view after Account is activated -->

<section>

    <div class="container ">
        <div class="row">
                <div class="activate-div">
                    <p>Your Account is activated....</p>
                    <p>please <strong><a href="<?php echo base_url();?>index.php/user_login/index">click here</a></strong> to login</p>
                    
                </div>
        

        </div>
    </div>

</section>