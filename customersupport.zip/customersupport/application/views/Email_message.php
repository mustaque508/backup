
<!-- this view will be displayed to the user after the successfully message sent -->

<section clas="msg-section">
    <div class="msg-div">

            <?php

            $Name=$this->input->post('Name');
            $Email=$this->input->post('Email');

            ?>

            <h5>
            Thanks for registering, <?php echo $Name ?> !
            </h5>

            <p>
                we have sent a mail to <?php echo $Email ?> go and check it....
            </p>
    </div>
</section>