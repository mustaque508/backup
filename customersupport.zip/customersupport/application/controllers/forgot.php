<!-- forgot password controller

    control all forgot password operations.

 -->

<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// time_zone
date_default_timezone_set('Asia/Kolkata');

class forgot extends MY_Controller
{

    // render view to user
        public function index()
        {
            if(!(isset($_SERVER['HTTP_REFERER'])))
                    return redirect('user_login/index');

            // $this->session->userdata('demo','demo')
            $this->load->view('header');
            $this->load->view('forgot_password');
            $this->load->view('footer');
        }

    // verfiy Email-Id
        public function confirm()
        {
            
             // check session
                if(!$this->session->userdata('Email'))
                return redirect('user_login/index');

            // email sent date&time
            $sentdate_time=new DateTime($this->session->userdata('sent_time'));

            // current date&time
            $currentdate_time=new DateTime(date('Y-m-d h:i:sa'));
           
            
         
            // difference between current datetime and email sent datetime
            $diff_time=$currentdate_time->diff($sentdate_time);
          
            // echo $diff_time->format('%h hours %i minutes %S seconds'); 

            // echo $diff_time->days.' days total<br>';
            // echo $diff_time->y.' years<br>';
            // echo $diff_time->m.' months<br>';
            // echo $diff_time->d.' days<br>';
            // echo $diff_time->h.' hours<br>';
            // echo $diff_time->i.' minutes<br>';
            // echo $diff_time->s.' seconds<br>';

            // echo "<br/>";

            // codition for expiration date &time
            if(!($diff_time->h>0 || $diff_time->d>0 ||$diff_time->m>0||$diff_time->y>0))
            {
                $this->load->view('header');
                $this->load->view('change_password');
                $this->load->view('footer');
            }
            else
            {
                $this->session->set_flashdata('error','forgot password link was expired');
                return redirect('user_login/index');
            }
        }


    // useremail validation
    public function forgotpassword()
    {
        if(!(isset($_SERVER['HTTP_REFERER'])))
                return redirect('user_login/index');

        // validation for userdata
            $this->form_validation->set_rules('Email','Email Address','callback_email_check');

        // check validation is correct
            if($this->form_validation->run()==TRUE)
            {

                $Email=$this->input->post('Email');

                    // main session
                    $this->session->set_userdata('Email',$Email);

                    // sending email to $Email

                    $to=$Email;
                    $subject="forgotpassword";
                    $from="noreply@prosoftesolutions.com";

                    $this->email->set_mailtype("html");
                    $this->email->from($from);
                    $this->email->to($to);
                    $this->email->subject($subject);
                    $this->email->message($this->load->view('forgotpasswordmail','',TRUE));
                    $result=$this->email->send();

                        if($result)
                        {
                            // change $Email's status to 0
                            $result=$this->forgot_model->changestatus($Email);
                            
                            
                            if($result)
                            {
                               $sentdate_time=date('Y-m-d h:i:sa');
                               
                               // store email sent time in session variable
                               $this->session->set_userdata('sent_time',$sentdate_time);

                              // store Activationcode in session variable
                               $this->session->set_userdata('Activationcode',md5($Email));


                                // display success message
                               $this->session->set_flashdata('success','A link to reset your password has been sent to '.$Email.'  click that link within 1 hour');
                               return redirect('forgot/index');

                            }
                            else
                            {
                                // display error message
                                $this->session->set_flashdata('error','!sorry unable to load your request');
                                return redirect('forgot/index');
                            }
                        }
                        else
                        {
                            // display error message
                            $this->session->set_flashdata('error','Email is not sent please contact admin');
                            return redirect('forgot/index');
                        }


            }
            else
            {
                // display error message
                    $this->load->view('header');
                    $this->load->view('forgot_password');
                    $this->load->view('footer');
            }

    }


   


     // Custom email validation
     public function email_check($str)
     {
       
        // remove space in user[email] and check the validation
        if(trim($str)=="")
        {
            //  display error message
                 $this->form_validation->set_message('email_check','Email Address is required');
                return FALSE;
        }
        else
        {
            // fetch data from databse which is stored in log_model
               $fetch=$this->forgot_model->fetch_data($this->input->post('Email'));
               if(!empty($fetch))
               {
                   return TRUE;
               }
               else
               {
                   //  display error message
                   $this->session->set_flashdata('error','Email address is not registered..');
                   return redirect('forgot/index');
               }

        }
              
     }



    // get userdata['Password' and 'Confirm password'] to change password
     public function getData()
     {
          // check session
          if(!$this->session->userdata('Email'))
          return redirect('user_login/index');

          
        // validation for userdata
        $this->form_validation->set_rules('Password', 'Password', 'min_length[8]|callback_password_check');
        $this->form_validation->set_rules('Cpassword', 'Confirm Password', 'required|matches[Password]',array('matches'=>'mismatch password'));


        // check validation is correct
        if($this->form_validation->run())
        {

            // get activationcode
            $id = $this->session->userdata('Activationcode');

            // store user['Password'] into an array
            $user_data=array(
                'Password'=>md5($this->input->post('Password')),
                'Status'=>1
            );


            // check Activationcode is empty?
            if(!empty($id) && isset($id))
            {
                    // update user['Password','Status'] into database
                    $result=$this->forgot_model->storeData($user_data,$id);
                    if($result)
                    {
                        // return to the login page
                        $this->load->view('header');
                        $this->load->view('login_message');
                        $this->load->view('footer');
                    }
                    else
                    {
                        // display error message
                        $this->session->set_flashdata('error','sorry!! unable to laod your request');
                        return redirect('user_login/index');
                    }
                
            }
            else
            {
                    // display error message
                   $this->session->set_flashdata('error','Sorry!! unable to load your request due to wrong activationcode.');
                   return redirect('user_login/index');
            }

       }
       else
       {
            // display error message
            $this->load->view('header');
            $this->load->view('change_password');
            $this->load->view('footer');
       }
     }



      // password validation
      public function password_check($str)
      {
        
 
          //  check password empty?
              if(trim($str)=="")
              {
                  $this->form_validation->set_message('password_check','The Password field is required ');
                  return FALSE;
              }
          

          // check password contain atleast one numeric character    
              else if(!preg_match("/[0-9]+/",$str))
              {
                  $this->form_validation->set_message('password_check','The Password must include atleast one numeric character');
                  return FALSE;
              }

          // check password contain atleast one alphabetic letter
              else if(!preg_match("/[a-z]+/",$str))
              {
                  $this->form_validation->set_message('password_check','The Password must include atleast one Alphabetic letter');
                  return FALSE;
              }

          // check password contain atleast one capital letter
              else if(!preg_match("/[A-Z]+/",$str))
              {
                  $this->form_validation->set_message('password_check','The Password must include atleast one capital letter');
                  return FALSE;
              }

          // check password contain atleast one special character
              else if(!preg_match('/[\W]+/',$str))
              {
                  $this->form_validation->set_message('password_check','The Password atleast  contain one specail character');
                  return FALSE;
              }

          // check password should not contain any white space
          else if(preg_match('/[\s]/',$str))
          {
              $this->form_validation->set_message('password_check','The Password should not contain white space');
              return FALSE;
          }

          //  if success
          else
          {
              return TRUE;
          }
      }

    }


?>