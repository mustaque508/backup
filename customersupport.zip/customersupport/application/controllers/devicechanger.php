
<!-- this controller is activated when user wants to activate his/her account from different system -->

<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class devicechanger extends MY_Controller
{
    // render view page
    public function index()
    {
        $this->load->view('header');
        $this->load->view('devicechange');
        $this->load->view('footer');
    }

    // validation
        public function getData()
        {
            // validation for userdata
            $this->form_validation->set_rules('Password', 'Password', 'required');
        
            // check validation is correct
            if($this->form_validation->run())
            {
                $Password=md5($this->input->post('Password'));
                $Activationcode=$this->session->userdata('Activationcode');
                $result=$this->devicechange_model->checkActivationcode($Activationcode);

                if(!empty($result))
                {
                    foreach ($result as $data) {
                        if($data['Password']==$Password)
                        {
                            $status=0;

                            // check whether account is already activated ?
                                $result=$this->reg_model->updatestatus($status,$Activationcode);

                                // check whether updatestatus successfully executed or not 
                                    if($result)
                                    {
                                        // load success view
                                            $this->load->view('header');
                                            $this->load->view('verfiedemail');
                                            $this->load->view('footer');
                                    }

                                    // if account is already activated
                                    else
                                    {
                                        // load reactivate view
                                            $this->load->view('header');
                                            $this->load->view('reactivate');
                                            $this->load->view('footer');
                                        
                                    }
                        }
                        else
                        {
                            // display error message
                                $this->session->set_flashdata('error','mismatch password');
                                return redirect('devicechanger/index');
                        }
                    }
                }
                else
                {
                    // display error message
                        $this->session->set_flashdata('error','database is empty');
                        return redirect('devicechanger/index');
                }
           
            }

            else
            {
                // display error message
                    $this->load->view('header');
                    $this->load->view('devicechange');
                    $this->load->view('footer');
            }
        }
}
?>