 <!-- custom user_reg controller 
 
        control user-register operations.

 -->

<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class user_reg extends MY_Controller
{
    
    /* render register_form */
    public function reg()
    {
        if(!isset($_SERVER['HTTP_REFERER']))
                return redirect('user_login/index');

        $this->load->view('header');
        $this->load->view('regform');
        $this->load->view('footer');  
    }

    // render activation errors
    public function view()
    {
        // // check session
        // if(!$this->session->userdata('status'))
        //         return redirect('user_login/index');

        $this->load->view('header');
        $this->load->view('activationerror');
        $this->load->view('footer');
    }

 
    // verfiy Email-Id
        public function confirm()
        {
            /* this code work only when user use different browser or machine. this code avoid direct activation*/
           
                $Activationcode=$this->input->get('id');
                $ses_id=$this->input->get('ses_id');

                // check Activationcode is empty?
                if(!empty($Activationcode))
                {
                    log_message('error',$Activationcode);

                    // check session ( comparing url's[ses_id] with system session['password']  )
                        if($ses_id != $this->session->userdata('Password'))
                        {
                            log_message('error',$ses_id);
                            // check user[Activationcode] and database[Activationcode] same or not
                                $getresult=$this->reg_model->checkActivationcode($this->input->get('id'));

                                // check database return value or not
                                if(!empty($getresult))
                                {
                                    // success
                                    // check account is already activated
                                        foreach ($getresult as $data)
                                        {
                                            if($data['Status']==0)
                                            {
                                                // success
                                                    $Activationcode=$this->input->get('id');
                                                    // echo "we look like you have changed your machine";
                                                    // exit;
                                                    $this->session->set_userdata('Activationcode',$Activationcode);
                                                    return redirect('devicechanger/index');
                                            }
                                        
                                        }
                                
                                
                                
                                }

                                else
                                {
                                    // fail
                                    // display error to user
                                        $this->session->set_flashdata('error','Sorry!!!! unable to load your request..... please contact admin');
                                        return redirect('user_reg/view');
                                }
                        }
                
                }
            /*********************************************************************************************************/

            // get activationcode
                $id = $this->input->get('id');

                // check whether activationcode is empty?
                    if(!empty($id) && isset($id))
                    {
                        // pass Activationcode to database and check both activation code same or not
                            $getresult=$this->reg_model->checkActivationcode($id);

                        // check whether checkActivationcode method returned value or not 
                            if(!empty($getresult))
                            {
                                $status=0;

                                // check whether account is already activated ?
                                    $result=$this->reg_model->updatestatus($status,$id);

                                    // check whether updatestatus successfully executed or not 
                                        if($result)
                                        {
                                            $this->load->view('header');
                                            $this->load->view('verfiedemail');
                                            $this->load->view('footer');
                                        }

                                        // if account is already activated
                                        else
                                        {
                                            // set session
                                            $this->session->set_userdata('status',$status);
                                            
                                            $this->load->view('header');
                                            $this->load->view('reactivate');
                                            $this->load->view('footer');
                                          
                                        }

                        
                            }

                            // display message to user
                                else
                                {
                                    $this->session->set_flashdata('error','Sorry!!!! unable to load your request..... please contact admin');
                                    return redirect('user_reg/view');
                                }
                    }
                    
                // if activation code is empty display message to user
                    else
                    {
                       $this->session->set_flashdata('error','Sorry!!!! unable to load your request.....');
                      return redirect('user_reg/view');
                    }
        
        }
   

    // get data from user
        public function getData()
        {
            // // check session
            // if($this->session->userdata('current_url'))
            // {
            //     echo "hello";
            // }

            if(!isset($_SERVER['HTTP_REFERER']))
            return redirect('user_login/index');

            // validation for userdata
                $this->form_validation->set_rules('Name', 'Name', 'trim|required|alpha_numeric_spaces|min_length[3]|max_length[50]|callback_name_check');
                $this->form_validation->set_rules('Contact', 'Contact number', 'callback_contact_check|is_unique[user_register_form.Contact]',array('is_unique'=>'The %s already exist'));
                $this->form_validation->set_rules('Email', 'Email address', 'required|valid_email|is_unique[user_register_form.Email]',array('is_unique'=>'The %s already exist'));
                $this->form_validation->set_rules('Password', 'Password', 'min_length[8]|callback_password_check');
                $this->form_validation->set_rules('Cpassword', 'Confirm Password', 'required|matches[Password]',array('matches'=>'mismatch password'));
                $this->form_validation->set_rules('Serial_key','Serial_key','required|callback_Serial_key_check');
                // $this->form_validation->set_rules('maintain_code','Maintenance Code','required');
        
            // check validation is correct?
                if($this->form_validation->run())
                {

                    // start session
                        $Password=md5($this->input->post('Password'));
                        $this->session->set_userdata('Password',$Password);

                    // store userdata into database
                        $user_data=array(
                            'Name'=>$this->input->post('Name',FILTER_SANITIZE_STRING),
                            'Contact'=>$this->input->post('Contact',FILTER_SANITIZE_STRING),
                            'Email'=>$this->input->post('Email',FILTER_SANITIZE_STRING),
                            'Password'=>md5($this->input->post('Password')),
                            // 'Cpassword'=>md5($this->input->post('Cpassword')),
                            'Activationcode'=>md5($this->input->post('Email')),
                            'SerialKey'=>$this->input->post('Serial_key')
                        
                        );

                        $result=$this->reg_model->storeData($user_data);
                

                        // check userdata is stored in database or not
                        if($result)
                        {
                                // code to send email to ther user
                                    $to=$this->input->post('Email');
                                    $subject="Please activate your account at prosoftesolutions.";
                                    // $from="noreply@prosoftesolutions.com";
                                    $from="noreply@prosoftesolutions.com";

                                

                                // // email configure

                                //     $config['protocol']='smtp';
                                //     $config['smtp_host']='ssl://smtp.gmail.com';
                                //     $config['smtp_port']='465';
                                //     $config['smtp_timeout']='60';
                    
                                //     $config['smtp_user']='mustaquemj1111@gmail.com'; //for testing purpose
                                //     $config['smtp_pass']='mustaqmj';                 //for testing purpose
                    
                                //     $config['charset']='utf-8';
                                //     $config['newline']="\r\n";
                                //     $config['mailtype']='html';
                                //     $config['validation']=TRUE;



                                    // $this->email->initialize($config);

                                    // sending mail
                                    $this->email->set_mailtype("html");
                                    $this->email->from($from);
                                    $this->email->to($to);
                                    $this->email->subject($subject);
                                    $this->email->message($this->load->view('verifyemail','',TRUE));
                                    $result=$this->email->send();

                                    // check email is successfully sent or not
                                        if($result)
                                        {
                                            // $this->load->view('header');
                                            // $this->load->view('Email_message');
                                            // $this->load->view('footer');

                                            // display success message.
                                            $this->session->set_flashdata('success','Account Created successfully please visit your email to activate your account.... ');
                                            return redirect('user_reg/reg');
                                        }
                                        else
                                        {
                                            // display error message
                                            $this->session->set_flashdata('error','Account Created successfully... Sorry!! unable to send activation link please contact admin');
                                            return redirect('user_reg/reg');
                                        }
                    
                
                        }
                        else
                        {
                            // display error message
                            $this->session->set_flashdata('error','Sorry Unable to create an account try again !!!!!!');
                            return redirect('user_reg/reg');
                        }


                    
                }
                else
                {
                     // display validationerror message within same page
                        $this->load->view('header');
                        $this->load->view('regform');
                        $this->load->view('footer');
                }
            
        }

    // password validation
        public function password_check($str)
        {
            //  check password empty?
                if(trim($str)=="")
                {
                    $this->form_validation->set_message('password_check','The Password field is required ');
                    return FALSE;
                }
            

            // check password contain atleast one numeric character    
                 else if(!preg_match("/[0-9]+/",$str))
                {
                    $this->form_validation->set_message('password_check','The Password must include atleast one numeric character');
                    return FALSE;
                }

            // check password contain atleast one alphabetic letter
                else if(!preg_match("/[a-z]+/",$str))
                {
                    $this->form_validation->set_message('password_check','The Password must include atleast one Alphabetic letter');
                    return FALSE;
                }

            // check password contain atleast one capital letter
                else if(!preg_match("/[A-Z]+/",$str))
                {
                    $this->form_validation->set_message('password_check','The Password must include atleast one capital letter');
                    return FALSE;
                }

            // check password contain atleast one special character
                else if(!preg_match('/[\W]+/',$str))
                {
                    $this->form_validation->set_message('password_check','The Password atleast  contain one special character');
                    return FALSE;
                }

            // check password should not contain any white space
            else if(preg_match('/[\s]/',$str))
            {
                $this->form_validation->set_message('password_check','The Password should not contain white space');
                return FALSE;
            }

            //  if success
            else
            {
                return TRUE;
            }
        }


    // contact number validation 
        public function contact_check($str)
        {
            if(strlen($str)<5)
            {
                
                $this->form_validation->set_message('contact_check',' The conact field is required');
                return FALSE;
            }
            // else if(preg_match('/([\s]{1})?/',$str))
            // {
            //     $this->form_validation->set_message('contact_check','The contact number should not contain more than one  white space');
            //     return FALSE;
            // }

            else
            {
                return TRUE;
            }
        }
      

    // name validation
        public function name_check($str)
        {
            

            // check name should not contain more than one white space consecutively
                if(preg_match('/([\s]{2})/',$str))
                {
                    $this->form_validation->set_message('name_check','The Name field should not contain more than one white space consecutively');
                    return FALSE;
                }

            // check name only contain alphabetic letters
                else if(preg_match('/([0-9])/',$str))
                {
                    $this->form_validation->set_message('name_check','The Name field only contain alphabetic letters');
                    return FALSE;
                }

            // check name should not contain more than two letters consecutively
                else if(preg_match('/([a-zA-Z])\1{2,}/',str_replace(' ','',$str)))
                {
                    $this->form_validation->set_message('name_check','The Name field should not contain more than two repeated letters consecutively ');
                    return FALSE;
                }
            
            // if success
                else
                {
                    return TRUE;
                }
        }

    //validate Serial key 
    public function Serial_key_check($str)
    {
        // check serial_key already used ?
            $result=$this->reg_model->isserialkeyalreadyused($str);
            if(!empty($result))
            {
                $this->form_validation->set_message('Serial_key_check','Already used');
                return FALSE;
            }
            else
            {
                $result=$this->reg_model->validate_Serial_key($str);
                if($result!="INVALID_SERIAL_KEY")
                {
                    return TRUE;
                }
                else
                {
                    $this->form_validation->set_message('Serial_key_check','Invalid serial key');
                    return FALSE;
                }

                        
            }


    }
 }

?>