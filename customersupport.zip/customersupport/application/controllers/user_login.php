<!-- Custom user_login Controller 

    control user-login operations..

-->


<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// cookie expiration time for 1day
define("REMEMBERME_COOKIE_EXPIRY",time()+24*60*60);
define("REMEMBERME_COOKIE_DELETE",time()-24*60*60);

// time_zone
date_default_timezone_set('Asia/Kolkata');

 class user_login extends MY_Controller
{
    
    /* render loginform */
        public function index()
        {  
           return redirect('user_login/login');
        }

        /* render after logout*/
        public function view()
        {
            $this->load->view('header');
            $this->load->view('loginform');
            $this->load->view('footer');
        }
    

    // logout section
    public function logout()
    {
      
        // $_SERVER['HTTP_REFERER'] avoid direct access...
        if(!isset($_SERVER['HTTP_REFERER']))
            return redirect('user_login/index');
        
        // delete cookie
        setcookie('emailcookie','',REMEMBERME_COOKIE_DELETE);
        setcookie('passwordcookie','',REMEMBERME_COOKIE_DELETE);
        setcookie('rememberme','',REMEMBERME_COOKIE_DELETE);
        // // $this->session->unset_userdata('demo');

        $this->session->set_flashdata('success','you logged out successfully');
        return redirect('user_login/view');
    }
   
    /*perform login operations */
        public function login()
        {

            // $call_complaint=new user_login(); 
           
            // validation for userdata
                $this->form_validation->set_rules('Email','Email Address','required');
                $this->form_validation->set_rules('Password','Password','required|callback_password_check');

            // check validation is correct
                if($this->form_validation->run()==TRUE)
                {
                    // fetch user input data
                    $Email=$this->input->post('Email');
                    $Password=md5($this->input->post('Password'));
                    $paswordcookie=$this->input->post('Password');

                    // check whether user['Email','Password'] are same as database['Email','Password']
                    $Activationcode=md5($this->input->post('Email'));
                    $fetch=$this->log_model->fetch_data($Activationcode);
                    if(!empty($fetch))
                    {
                        foreach ($fetch as $data) 
                        {
                            if($data['Email']==$Email && $data['Password']==$Password)
                            {
                                 // check whether user[email] status is activated or not
                                $result=$this->log_model->verifyemail($Email);

                                // $data['email']=md5($Email);


                                if($result)
                                {
                            
                                    $this->session->set_userdata('Name',$data['Name']);
                                    $this->session->set_userdata('user_id',$data['Id']);
                                    $this->session->set_userdata('serialkey',$data['SerialKey']);

                                    if(isset($_POST['rememberme']))
                                    {
                                        
                                        // set cookies
                                        setcookie('emailcookie',$Email,REMEMBERME_COOKIE_EXPIRY);
                                        setcookie('passwordcookie',$paswordcookie,REMEMBERME_COOKIE_EXPIRY);
                                        setcookie('rememberme',TRUE,REMEMBERME_COOKIE_EXPIRY);

                                        // $this->load->view('header');
                                        // $this->load->view('sidebar');
                                        // $this->load->view('footer');

                                        $this->complaint_form();

                                        // $call_complaint->complaint_form();
                                      
                                    }
                                    else
                                    {
                                        // // set session
                                        // $this->session->set_userdata('demo','demo');
                                       
                                        
                                        // delete cookie
                                        setcookie('emailcookie','',REMEMBERME_COOKIE_DELETE);
                                        setcookie('passwordcookie','',REMEMBERME_COOKIE_DELETE);
                                        setcookie('rememberme','',REMEMBERME_COOKIE_DELETE);

                                        // $this->load->view('header');
                                        // $this->load->view('sidebar');
                                        // $this->load->view('footer');

                                        $this->complaint_form();
                                    }
                               
                                }
                               
                                else
                                {
                                     // if fail
                                    $this->session->set_flashdata('error','please activate your account');
                                        return redirect('user_login/view');
                                }
                            }
                            else
                            {
                                $this->session->set_flashdata('error','Email address is not registered..');
                                return redirect('user_login/view');
                                // print_r($fetch);
                            }
                        }
                       

                        

                    }
                    else
                    {
                        $this->session->set_flashdata('error','Email address is not registered..');
                        return redirect('user_login/index');
                    }
                    // $Email=$this->input->post('Email');
                    
                    // // check whether user[email] status is activated or not
                    // $result=$this->log_model->verifyemail($Email);
                   
                    // // if success 
                    // if($result)
                    // {
                    //     echo "welcome";
                    // }
                    // // if fail
                    // else
                    // {
                    //     $this->session->set_flashdata('error','please activate your account');
                    //         return redirect('user_login/index');
                    // }

                   

                }
                // if fail
                else
                {
                  
                    $this->load->view('header');
                    $this->load->view('loginform');
                    $this->load->view('footer');

                    // $this->load->view('header');
                    // $this->load->view('sidebar');
                    // $this->load->view('footer');
                    
                }
        
    
        }

    // // Custom email validation
    //     public function email_check($str)
    //     {
    //         if(!(trim($str)==""))
    //         {
           
    //         // fetch data from databse which is stored in log_model
    //             $Activationcode=md5($this->input->post('Email'));
    //             $fetch=$this->log_model->fetch_data($Activationcode);
               
    //             if(!empty($fetch))
    //             {
    //                 foreach ($fetch as $data) 
    //                 {
    //                     // check user input[email] is similar to database[email]
    //                         if($str==$data['Email'])
    //                         {
    //                             return TRUE;
    //                         }
    //                         else
    //                         {
    //                             // remove space in user[email] and check the validation
    //                                 if(trim($str)=="")
    //                                 {
    //                                     $this->form_validation->set_message('email_check','Email Address is required');
    //                                     return FALSE;
    //                                 }
    //                                 else
    //                                 {
    //                                     $this->session->set_flashdata('error','Email address is not registered..');
    //                                     return redirect('user_login/index');
    //                                 }
    //                         }

                    
    //                 }
    //              }
    //              else
    //              {
    //                 //  display error message
    //                 $this->session->set_flashdata('error','Email address is not registered..');
    //                 return redirect('user_login/index');
    //              }
    //         }

    //     }

    // custom password validation
        public function password_check($str)
        {
            //    // $_SERVER['HTTP_REFERER'] avoid direct access...
            //     if(!isset($_SERVER['HTTP_REFERER']))
            //         return redirect('user_login/index');


           if(!(trim($str)==""))
           {
            // fetch data from databse which is stored in log_model
                $Activationcode=md5($this->input->post('Email'));
                $fetch=$this->log_model->fetch_data($Activationcode);
                if(!empty($fetch))
                {
                    foreach ($fetch as $data) 
                    {
                        // check user input[Pasword] is similar to database[Password]
                            if(md5($str)==$data['Password'])
                            {
                                return TRUE;
                            }
                            else
                            {
                                // // remove space in user[Password] and check the validation
                                // if(trim($str)=="")
                                // {
                                //     $this->form_validation->set_message('password_check','Password is required');
                                //     return FALSE;
                                // }
                                // else
                                // {
                                    $this->form_validation->set_message('password_check','Incorrect password');
                                    return FALSE;
                                // }
                            
                            }
                        
                    }
                } 
                else
                {
                    //  display error message
                        $this->session->set_flashdata('error','Email address is not registered..');
                        return redirect('user_login/view');
                }
           }
               
        }

   
    //complaintform
    public function complaint_form()
    {
        // $_SERVER['HTTP_REFERER'] avoid direct access...
        if(!isset($_SERVER['HTTP_REFERER']))
        return redirect('user_login/index');

        // show complaints
        if($this->session->userdata('Name'))
        {
            // fetch userdata based on user name
               $result['userdata']=$this->complaint_model->fetch_complaints($this->session->userdata('user_id'));
            //    $result['Id']=$this->session->userdata('user_id');
               
               if($result['userdata']==TRUE)
               {
                    $this->load->view('header');
                    $this->load->view('sidebar');
                    $this->load->view('complaintform',$result);
                    $this->load->view('footer');
               }
               else
               {
                    
                    $this->load->view('header');
                    $this->load->view('sidebar');
                    $this->load->view('complaintform');
                    $this->load->view('footer');
                
               }
               
            
        }
        // else
        // {
        //     $this->load->view('header');
        //     $this->load->view('sidebar');
        //     $this->load->view('complaintform');
        //     $this->load->view('footer');
        // }

       
       
       
    }

    // store complaint
    public function storecomplaint()
    {

      
             // validation for userdata
            //  $this->form_validation->set_rules('Serial_key','Serial_key','required');
             $this->form_validation->set_rules('Complaint','Complaint','required');

             if($this->form_validation->run()==TRUE)
             {
                //echo $this->session->userdata('user_id');
                 if($this->session->userdata('Name'))
                 {
                    // current date&time
                    $date_time=new DateTime(date('Y-m-d H:i:s'));
                    $complaintdate_time=$date_time->format('Y-m-d H:i:s');
                    
                    //generate a UNIQUE reference number as ComplaintNo
                    $auto_complaintno =mt_rand(100000, 999999);; //909123  (6 digit only)

                    //  get userdata
                    $userdata=array(
                        'Name'=>$this->session->userdata('Name'),
                        'userid'=>$this->session->userdata('user_id'),
                        'ComplaintNo'=>$auto_complaintno,
                        'Serial_key'=>$this->input->post('Serial_key'),
                        'Complaint'=>$this->input->post('Complaint'),
                        'Comp_date_time'=>$complaintdate_time 
                    );

                // display userdata for developer understanding
                //    foreach ($userdata as $value) {
                //        echo $value;
                //    }

                // store userdata in database
                    $result=$this->complaint_model->store_data($userdata);

                    if($result==TRUE)
                    {
                        $this->session->set_flashdata('success','Your complaint is recorded, we will solve your issue very soon..');
                        return redirect('user_login/complaint_form');
                    }
                    else
                    {
                        $this->session->set_flashdata('error','Sorry !!!! your complaint is not recorded please contact admin..');
                        return redirect('user_login/complaint_form');
                    }

                   

           

                    
                   
                 }
                 else
                 {
                     $this->session->set_flashdata('error','Unknown customer');
                     return redirect('user_login/complaint_form');

                   
                 }
                    
             }
             else
             {
                if($this->session->userdata('Name'))
                {
                     // fetch userdata based on user name
                        $result['userdata']=$this->complaint_model->fetch_complaints($this->session->userdata('user_id'));
               
                        if($result['userdata']==TRUE)
                        {
                                $this->load->view('header');
                                $this->load->view('sidebar');
                                $this->load->view('complaintform',$result);
                                $this->load->view('footer');
                        }
                        else
                        {
                            //   $this->session->set_flashdata('error','Sorry!!!! data not found please contact admin.');
                            //   return redirect('user_login/complaintview');
                            
                        }
                }
             }
            
    }


    // complaint_view
    // public function complaintview()
    // {
    //       // $_SERVER['HTTP_REFERER'] avoid direct access...
    //       if(!isset($_SERVER['HTTP_REFERER']))
    //       return redirect('user_login/index');

    //     $this->load->view('header');
    //     $this->load->view('sidebar');
    //     $this->load->view('complaintform');
    //     $this->load->view('footer');
    // }

    // get complaints only for refresh button
    public function getcomplaints()
    {
          // $_SERVER['HTTP_REFERER'] avoid direct access...
          if(!isset($_SERVER['HTTP_REFERER']))
          return redirect('user_login/index');

        if($this->session->userdata('Name'))
        {
            // fetch userdata based on user name
               $result['userdata']=$this->complaint_model->fetch_complaints($this->session->userdata('user_id'));
               
               if($result['userdata']==TRUE)
               {
                    $this->load->view('header');
                    // $this->load->view('sidebar');
                    $this->load->view('complaint_view',$result);
                    $this->load->view('footer');
               }
               else
               {
                  $this->session->set_flashdata('error','Sorry!!!! data not found please contact admin.');
                  return redirect('user_login/complaint_form');
                
               }
               
            
        }

    }

    // youtube channel
    public function show_youtube()
    {
        //   $_SERVER['HTTP_REFERER'] avoid direct access...
          if(!isset($_SERVER['HTTP_REFERER']))
          return redirect('user_login/index');
          
        $this->load->view('header');
        $this->load->view('sidebar');
        $this->load->view('youtube');
        $this->load->view('footer');
    }

}



?>