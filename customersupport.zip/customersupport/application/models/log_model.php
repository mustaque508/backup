
<!-- log model

        control login database operations..

 -->


<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class log_model extends CI_Model
{
    
    // check user[Activationcode] and database[Activationcode] same or not
        public function fetch_data($Activationcode)
        {
            //fetch data from database 
                $this->db->select(['Email','Password','Name','Id','SerialKey']);
                $get=$this->db->get_where('user_register_form',array('Activationcode'=>$Activationcode));

            //check database contain data or not ?
                if($get->num_rows()>0)
                {
                    return $get->result_array();
                }
                else
                {
                    return "";
                }
            
        }

    // verifyemail
    public function verifyemail($Email)
    {
        $this->db->select();
        $get=$this->db->get_where('user_register_form',array('Email'=>$Email));
        foreach ($get->result_array() as $data) 
        {
            
            if($data['Status']==1)
            {
                // success
                return TRUE;
            }
            else
            {
                // fail
                return FALSE;
            }
            
        }

    }
}
?>
  