
<!-- this model is called when user wants to activate his/her acoount from different system -->

<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class devicechange_model extends CI_Model
{
    // check user[Activationcode] and database[Activationdcode] same or not
        public function checkActivationcode($id)
        {
            $this->db->select(['Password']);
            $get=$this->db->get_where('user_register_form',array('Activationcode'=>$id));

            if($get->num_rows()>0)
            {
                // success
                return $get->result_array();
            }
            else
            {
                // fail
                return FALSE;
            }
        }

  
}

?>