<!-- forgot password model 

    control forgot password database operations..

-->

<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class forgot_model extends CI_Model
{

    // fetch user[*] from database for validation
    public function fetch_data($Email)
    {
        //fetch data from database 
        $this->db->select('*');
        $get=$this->db->get_where('user_register_form',array('Email'=>$Email));

        //check database contain data or not ?
            if($get->num_rows()>0)
            {
                // success
                return $get->result_array();
            }
            else
            {
                // fail
                return "";
            }
        
    }


    // change Email status to 0
    public function  changestatus($Email)
    {
       if(!empty($Email) && isset($Email))
       {
           $status=0;
           $this->db->where('Email',$Email);
           $result=$this->db->update('user_register_form',array('Status'=>$status));

           if($result)
           {
                // success
                return TRUE;
           }
           else
           {
                // fail
               return FALSE;
           }
       }

       else
       {
           // fail
           return FALSE;
       }
    }


    // store new user['Password','Status'] into database
    public function storeData($user_data,$id)
    {
     
        $status=1;
        $this->db->where('Activationcode',$id);
        $result=$this->db->update('user_register_form',$user_data);

        if($result)
        {
            // success
            return TRUE;
        }
        else
        {
            // fail
            return FALSE;
        }
    }

}


?>