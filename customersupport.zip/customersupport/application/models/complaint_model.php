
<!-- log model

        control complaint database operations..

 -->

<?php  

defined('BASEPATH') OR exit('No direct script access allowed');

class complaint_model extends CI_Model
{
    public function store_data($userdata)
    {
        //also insert userid
           $result=$this->db->insert('complaint_details',$userdata);
           if($result==1)
           {
              return TRUE;
           }
           else
           {
               return FALSE;
           }
            

          
    }

    public function fetch_complaints($userid)
    {
        $this->db->select('*');
        $this->db->order_by("Comp_date_time", "desc");
        $get=$this->db->get_where('complaint_details',array('userid'=>$userid));

         return $get->result();
        
    }
}



?>