
<!-- registeration model 

    control register database operations

-->

<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class reg_model extends CI_Model
{

  // store userdata into database
      public function storeData($getData)
      {
        $data=$this->db->insert('user_register_form',$getData);

        if($data==1)
        {
          // success
          return TRUE;
        }
        else
        {
          // fail
          return FALSE;
        }
      }

  // fetch activation code from database and check both user[activationcode] and database[activationcode] same or not
      public function checkActivationcode($id)
      {
        //fetch data from database
          $this->db->select();
          $get=$this->db->get_where('user_register_form',array('Activationcode'=>$id));

        //check database contain data or not ?
          if($get->num_rows()>0)
          {
              return $get->result_array();
          }
        // if database is empty
          else
          {
              return "";
          }

      }


    // account activtion
      public function updatestatus($status,$id)
      {
        // check status field contain data or not ?
          if(isset($status))
          { 
            // check whether passed activation code and status are same or not comapre to database[Activationcode,status]
                $this->db->select();
                $get=$this->db->get_where('user_register_form',array('Activationcode'=>$id,'Status'=>$status));
              
            // check whether database contain data or not
              if($get->num_rows()>0)
              {
                // if success upadate database[Status] 
                  $status=1;
                    $this->db->where('Activationcode',$id);
                    $result=$this->db->update('user_register_form',array('Status'=>$status));

                // check whether update query successfully executed or not
                    if($result)
                    {
                      return TRUE;
                    }

                // return null value
                    else
                    {
                      return FALSE;
                    }
              }
              else
              {
                  return "";
              }
          }
        
          
          
      }

      public function checkcontact($str)
      {
           //fetch data from database 
           $this->db->select();
           $get=$this->db->get_where('user_register_form',array('Contact'=>$str));

       //check database contain data or not ?
           if($get->num_rows()>0)
           {
               return $get->result_array();
           }
           else
           {
               return "";
           }
       
      }

      // Validate Serial key 
      public function validate_Serial_key($str)
      {

        //https://prosoftesolutions.com/C5CDRAnalyzerV5_Web/UserValidationsNew.aspx
        //serial_key = $str['Serialkey']
        //hdd_address = ""
        //product_id = C5CDRAnalyzer_V5
        
        ////Response != INVALID_SERIAL_KEY

          // /****************curl library *****************/
          
          $data_array=array(
            'serial_key'=>$str,
            'hdd_address'=>'',
            'product_id'=>'C5CDRAnalyzer_V5'
          );

          //API key
            $url="https://prosoftesolutions.com/C5CDRAnalyzerV5_Web/UserValidationsNew.aspx";

          //connection
            $curl=curl_init();

          //set cURL options
            curl_setopt($curl,CURLOPT_URL,$url);//set url
            curl_setopt($curl,CURLOPT_POST,TRUE);//when you use post request with parameters
            curl_setopt($curl,CURLOPT_POSTFIELDS,http_build_query($data_array));//when you use post request with parameters
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);//avoid curl success message
          
          // execute cURL
            $response=curl_exec($curl);
            

            if(curl_error($curl))
            {
              echo "request-error :".curl_error($curl);
            }
            else
            {
              
                return $response;
            }
      
            // close cURL
            curl_close($curl);

      }

      // Validate Serial key already used
      public function isserialkeyalreadyused($str)
      {
             //fetch data from database 
             $this->db->select();
             $get=$this->db->get_where('user_register_form',array('Serialkey'=>$str));
  
         //check database contain data or not ?
             if($get->num_rows()>0)
             {
                 return $get->result_array();
             }
             else
             {
                 return "";
             }
      }
    
}


?>