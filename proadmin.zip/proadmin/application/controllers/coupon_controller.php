<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class coupon_controller extends CI_Controller 
{
    public function index()
    {

        $this->load->model('vendor_model');
        $data['vendors'] = $this->vendor_model->get_vendors();

		// get_offer_details
		$data['offers']=$this->coupon_model->get_offer_details();
        

        $this->load->view('header');
        $this->load->view('sidebar');
        $this->load->view('coupon_report',$data);    
        $this->load->view('footer');

      
    }

    public function get_data()
	{
		$get_details=array(
			'couponcode'=>$_GET['couponcode'],
			'vendor_id'=>$_GET['vendor_id'],
			'isused'=>$_GET['isused'],
			'fromDateTime'=>$_GET['fromDateTime'],
			'toDateTime'=>$_GET['toDateTime'],
			'offername'=>$_GET['offername']
		);
		
		// $this->load->model('coupon_model');
		$data = $this->coupon_model->get_data($get_details);
		
		// echo json_encode($data);
		if (!is_int($data))
		{
			if ($data->num_rows() > 0){
				echo json_encode($data->result());
			} else {
				echo json_encode(110);
			}
		}
		else
		{
			echo json_encode(110);
		}
	}

}


?>