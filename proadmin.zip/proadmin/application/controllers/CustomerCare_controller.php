<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class CustomerCare_controller extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	
	public function index()
	{
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('customer_care');    
		$this->load->view('footer');			
	}
	
	public function get_data()
	{
		$maintenance_code = $_GET['maintenance_code'];
		$serial_key = $_GET['serial_key'];
		$mobile_no = $_GET['mobile_no'];
		$email_id = $_GET['email_id'];
		
		$this->load->model('Customer_care_model');
		$data = $this->Customer_care_model->get_data($maintenance_code, $serial_key, $mobile_no, $email_id);
		
		if (!is_int($data))
		{
			if ($data->num_rows() > 0){
				echo json_encode($data->result());
			} else {
				echo json_encode(110);
			}
		}
		else
		{
			echo json_encode(110);
		}
	}

	// getdata through api
	public function getdata_api()
	{
		$mobile=$_GET['mobile'];
		$email=$_GET['email'];
		$this->load->model('Customer_care_model');
		$data = $this->Customer_care_model->get_data_api($mobile, $email);
		if(!empty($data)){
			// echo json_encode($data);
			echo $data;
		}
		else{
			echo json_encode(110);
		}
	}
}
?>
