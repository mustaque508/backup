<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Download_controller extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	
	public function index()
	{
		$this->load->model('Product_model');
		$data['products'] = $this->Product_model->get_distinct_product_names();

		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('download', $data);    
		$this->load->view('footer');			
	}
	
	public function get_all_downloads()
	{
		//$product_name = $_GET['product_name'];
		//$edition = $_GET['edition'];
		$from_timestamp = $_GET['from_timestamp'];
		$to_timestamp = $_GET['to_timestamp'];
		
		// $this->load->model('Product_model');
		// $product_id = $this->Product_model->get_product_id($product_name, $edition);
		
		// if ($product_id == ""){
		// 	echo json_encode(110);
		// 	return;
		// }

		$this->load->model('Download_model');
		$data = $this->Download_model->get_all_downloads($from_timestamp, $to_timestamp);

		//echo json_encode($data);
		//return;
		
		if (!is_int($data))
		{
			if ($data->num_rows() > 0){
				echo json_encode($data->result());
			} else {
				echo json_encode(110);
			}
		}
		else
		{
			echo json_encode(110);
		}		
	}

	public function get_downloads_by_status()
	{

		$from_timestamp = $_GET['from_timestamp'];
		$to_timestamp = $_GET['to_timestamp'];
		$onlytrial = $_GET['onlytrial'];
		$onlypurchased = $_GET['onlypurchased'];
		

		$this->load->model('Download_model');
		$data = $this->Download_model->get_downloads_by_status($from_timestamp, $to_timestamp, $onlytrial, $onlypurchased);
		
		if (!is_int($data))
		{
			if ($data->num_rows() > 0){
				echo json_encode($data->result());
			} else {
				echo json_encode(110);
			}
		}
		else
		{
			echo json_encode(110);
		}		
	}
	public function get_downloads_by_cust_info()
	{
		$mobile_no = $_GET['mobile_no'];
		$email_id = $_GET['email_id'];

		$from_timestamp = $_GET['from_timestamp'];
		$to_timestamp = $_GET['to_timestamp'];

		$order_id = $_GET['order_id'];
						
		$this->load->model('Download_model');
		$data = $this->Download_model->get_downloads_by_cust_info($mobile_no, $email_id, $from_timestamp, $to_timestamp, $order_id);

		//echo json_encode($data);
		//return;
		
		if (!is_int($data))
		{
			if ($data->num_rows() > 0){
				echo json_encode($data->result());
			} else {
				echo json_encode(110);
			}
		}
		else
		{
			echo json_encode(110);
		}		
	}
}
?>
