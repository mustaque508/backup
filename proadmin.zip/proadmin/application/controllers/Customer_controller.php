<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Customer_controller extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	
	public function index()
	{
					
	}
	
	public function get_customers()
	{		
		$this->load->model('Customer_model');
		$data = $this->Customer_model->get_customers();
		
		if ($data->num_rows() > 0){
			echo json_encode($data->result());
		} else {
			echo json_encode(110);
		}	
	}

	public function get_customer_details()
	{		
		$customer_id = $_GET['customer_id'];

		$this->load->model('Customer_model');
		$data = $this->Customer_model->get_customer_details($customer_id);

		//echo json_encode($data);
		//return;
		
		if (!is_int($data))
		{
			if ($data->num_rows() > 0){
				echo json_encode($data->result());
			} else {
				echo json_encode(110);
			}
		}
		else
		{
			echo json_encode(110);
		}
		return;
	}

	public function save_customer(){


		$customer_id = $_POST['customer_id'];
		$customer_name = $_POST['customer_name'];
		$address = $_POST['address'];
		$city = $_POST['city'];
		$state = $_POST['state'];
		$country = $_POST['country'];
		$gstin = $_POST['gstin'];
		$pan = $_POST['pan'];
		$tan = $_POST['tan'];

		//// Apply Filter
		// $customer_id = $this->filter_field($customer_id);
		// $customer_name = $this->filter_field($customer_name);
		// $address = $this->filter_field($address);
		// $city = $this->filter_field($city);
		// $state = $this->filter_field($state);
		// $country = $this->filter_field($country);
		// $gstin = $this->filter_field($gstin);
		// $pan = $this->filter_field($pan);
		// $tan = $this->filter_field($tan);


		//store data
		$store_data=array(
			'Customer_ID'=>$this->filter_field($customer_id),
			'Customer_Name'=>$this->filter_field($customer_name),
			'Customer_Address'=>$this->filter_field($address),
			'Customer_City'=>$this->filter_field($city),
			'Customer_State'=>$this->filter_field($state),
			'Customer_Country'=>$this->filter_field($country),
			'GSTIN_No'=>$this->filter_field($gstin),
			'PAN_No'=>$this->filter_field($pan),
			'TAN_No'=>$this->filter_field($tan)
		);

				
		// Load Customer model
		// $this->load->model('Customer_model');
		// $data = $this->Customer_model->save_customer($customer_id, $customer_name, $address, $city, $state, $country, $gstin, $pan, $tan);
		// $data=$this->Customer_model->save_customer($store_data);
		
		// echo json_encode($store_data);	
		
		$this->load->model('Customer_model');
		$response=$this->Customer_model->save_customer($store_data);

		if($response==TRUE)
		{
			//submitted successfully
			$result=array(
				'success'=>true,
				'response'=>201
			);
		}
		else
		{
			//failed to submit form
			$result=array(
				'success'=>true,
				'response'=>110
			);
		}
		echo json_encode($result);
	}

	// Filter a field
	function filter_field($field){
		$field = htmlspecialchars($field);
		$field = strip_tags($field);
		$field = addslashes($field);
		$field = filter_var($field, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);
			
		return $field;
	}
}
?>
