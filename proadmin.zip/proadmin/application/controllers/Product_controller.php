<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Product_controller extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	
	public function index()
	{
					
	}
	
	public function get_products()
	{		
		$this->load->model('Product_model');
		$data = $this->Product_model->get_products();
		
		if (!is_int($data))
		{
			if ($data->num_rows() > 0){
				echo json_encode($data->result());
			} else {
				echo json_encode(110);
			}
		}
		else
		{
			echo json_encode(110);
		}
	}

	public function get_distinct_product_names() 
	{		
		$this->load->model('Product_model');
		$data = $this->Product_model->get_distinct_product_names();
		
		if (!is_int($data))
		{
			if ($data->num_rows() > 0){
				echo json_encode($data->result());
			} else {
				echo json_encode(110);
			}
		}
		else
		{
			echo json_encode(110);
		}
	}

	public function get_product_editions()
	{		
		$product_name = $_GET['product_name'];

		$this->load->model('Product_model');
		$data = $this->Product_model->get_product_editions($product_name);
		
		if ($data->num_rows() > 0){
			echo json_encode($data->result());
		} else {
			echo json_encode(110);
		}
	}

	public function get_product_details()
	{		
		$product_id = $_GET['product_id'];

		$this->load->model('Product_model');
		$data = $this->Product_model->get_product_details($product_id);

		//echo json_encode($data);
		//return;
		
		if (!is_int($data))
		{
			if ($data->num_rows() > 0){
				echo json_encode($data->result());
			} else {
				echo json_encode(110);
			}
		}
		else
		{
			echo json_encode(110);
		}
		return;
	}

	public function save_product(){

		
		$product_id = $_POST['product_id'];
		$product_name = $_POST['product_name'];
		$product_version = "";//$_GET['product_version'];
		$product_desc = $_POST['product_desc'];
		$rate = $_POST['rate'];
		$edition = $_POST['edition'];


		$storedata=array(
			'Product_ID'=>$this->filter_field($product_id),
			'Product_Name'=>$this->filter_field($product_name),
			'Product_Version'=>$this->filter_field($product_version),
			'Product_Desc'=>$this->filter_field($product_desc),
			'Rate'=> $this->filter_field($rate),
			'Edition'=> $this->filter_field($edition)
		);

		// //// Apply Filter
		// $product_id = $this->filter_field($product_id);
		// $product_name = $this->filter_field($product_name);
		// $product_version = $this->filter_field($product_version);
		// $product_desc = $this->filter_field($product_desc);
		// $rate = $this->filter_field($rate);
		// $edition = $this->filter_field($edition);
						
		//// Load product model
		$this->load->model('Product_model');
		$response = $this->Product_model->save_product($storedata);

		if($response==TRUE)
		{
			//submitted successfully
			$result=array(
				'success'=>true,
				'response'=>201
			);
		}
		else
		{
			//failed to submit form
			$result=array(
				'success'=>true,
				'response'=>110
			);
		}
		echo json_encode($result);
		
		// echo json_encode($data);		
	}

	// Filter a field
	function filter_field($field){
		$field = htmlspecialchars($field);
		$field = strip_tags($field);
		$field = addslashes($field);
		$field = filter_var($field, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);
			
		return $field;
	}
}
?>
