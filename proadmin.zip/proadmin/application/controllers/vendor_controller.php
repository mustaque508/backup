<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class vendor_controller extends CI_Controller 
{
    public function index()
    {
        $this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('vendor');    
		$this->load->view('footer');
    }

    public function get_vendors()
    {
        $result=$this->vendor_model->get_vendors();

        return $result;
    }

}


?>