<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Quotation_controller extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	
	public function index()
	{
		$quotation_no = "";
		if(isset($_GET['quotation_no'])) {
			$quotation_no = $_GET['quotation_no'];
			$quotation_no = $this->filter_field($quotation_no);
		}

		$data['new_quotation_no'] = $quotation_no;

		$this->load->model('Quotation_model');
		$data['quotations'] = $this->Quotation_model->get_quotations();

		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('Quotations/view_quotation', $data);    
		$this->load->view('footer');
	}	

	public function create_quotation()
	{
		$this->load->model('Customer_model');
		$data['customers'] = $this->Customer_model->get_customers();

		$this->load->model('Product_model');
		$data['products'] = $this->Product_model->get_products();

		$this->load->model('StateGSTCode_modal');
		$data['statesgstcode'] = $this->StateGSTCode_modal->get_stategstcode();

		$data['quotation_type'] = "NEW";

		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('Quotations/create_quotation', $data);    
		$this->load->view('footer');	

	}

	public function revise_quotation()
	{
		$this->load->model('Quotation_model');
		$data['quotations'] = $this->Quotation_model->get_quotations();

		$this->load->model('Customer_model');
		$data['customers'] = $this->Customer_model->get_customers();

		$this->load->model('Product_model');
		$data['products'] = $this->Product_model->get_products();

		$this->load->model('StateGSTCode_modal');
		$data['statesgstcode'] = $this->StateGSTCode_modal->get_stategstcode();

		$data['quotation_type'] = "REVISE";

		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('Quotations/create_quotation', $data);    
		$this->load->view('footer');	

	}

	public function edit_quotation_view()
	{
		$this->load->model('Quotation_model');
		$data['quotations'] = $this->Quotation_model->get_quotations();

		$this->load->model('Customer_model');
		$data['customers'] = $this->Customer_model->get_customers();

		$this->load->model('Product_model');
		$data['products'] = $this->Product_model->get_products();

		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('Quotations/edit_quotation', $data);    
		$this->load->view('footer');			
	}

	public function view_quotation()
	{
		$quotation_no = "";
		if(isset($_GET['quotation_no'])) {
			$quotation_no = $_GET['quotation_no'];
			$quotation_no = $this->filter_field($quotation_no);
		}

		$data['new_quotation_no'] = $quotation_no;

		$this->load->model('Quotation_model');
		$data['quotations'] = $this->Quotation_model->get_quotations();

		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('Quotations/view_quotation_new', $data);    
		$this->load->view('footer');
	}	
	
	public function get_quotation_details()
	{
		$quotation_no = $_GET['quotation_no'];
		$quotation_no = $this->filter_field($quotation_no);
		
		$this->load->model('Quotation_model');
		$data = $this->Quotation_model->get_selected_quotations($quotation_no);
		
		

		if ($data){
			echo json_encode($data->result());
		}
		else 
		{
			echo json_encode(110);
		}


	// 	if (!is_int($data))
	// 	{
	// 		if ($data->num_rows() > 0){
	// 			echo json_encode($data->result());
	// 		} else {
	// 			echo json_encode(110);
	// 		}
	// 	}
	// 	else
	// 	{
	// 		echo json_encode(110);
	// 	}		
	 }

	public function get_quotation_item_details()
	{
		$quotation_no = $_GET['quotation_no'];
		$quotation_no = $this->filter_field($quotation_no);
		
		$this->load->model('Quotation_model');
		$data = $this->Quotation_model->get_quotation_item_details($quotation_no);

		//echo json_encode($data);
		//return;
				
		if (!is_int($data))
		{
			if ($data->num_rows() > 0){
				echo json_encode($data->result());
			} else {
				echo json_encode(111);
			}
		}
		else
		{
			echo json_encode(110);
		}		
	}

	public function get_quotations()
	{
		$this->load->model('Quotation_model');
		$data = $this->Quotation_model->get_quotations();
		
		if (!is_int($data))
		{
			if ($data->num_rows() > 0){
				echo json_encode($data->result());
			} else {
				echo json_encode(110);
			}
		}
		else
		{
			echo json_encode(110);
		}
	}

	public function save_quotation()
	{
		$revised_on_quot=$_POST['revised_on_quot'];
		
		// $revised_on_quot = $_GET['revised_on_quot'];

		//// Customer Info
		$state = $_POST['state'];
		$code = $_POST['code'];
		$cust_gstin = $_POST['cust_gstin'];
		$currency = $_POST['currency'];
		$customer_id = $_POST['customer_id'];

		//// Quotation Details
		$quotation_no = $_POST['quotation_no'];
		$quotation_date = $_POST['quotation_date']; // $('#collected_datetime').data('datetimepicker');
		$reference_no = $_POST['reference_no'];
        $reference_date = $_POST['reference_date'];
		$preparedby = $_POST['preparedby'];
        
		$project_job = $_POST['project_job'];
		$hsnsac_code = $_POST['hsnsac_code'];

		//// Purchased Details

		//// Amount Details
		$total_beforegst = $_POST['total_beforegst'];
		//$igst_percentage = $_GET['txt_igst_percentage'];
		$igst = $_POST['igst'];
		//$sgst_percentage = $_GET['txt_sgst_percentage'];
		$sgst = $_POST['sgst'];
		//$cgst_percentage = $_GET['txt_cgst_percentage'];
		$cgst = $_POST['cgst'];
		//$r_add = $_GET['txt_add'];
		//$r_less = $_GET['txt_less'];
		$round_off = $_POST['round_off'];
		$total_aftergst = $_POST['total_aftergst'];

		$note = $_POST['note'];

		// Apply Filter
		$state = $this->filter_field($state);
		$code = $this->filter_field($code);
		$cust_gstin = $this->filter_field($cust_gstin);
		$currency = $this->filter_field($currency);
		$customer_id = $this->filter_field($customer_id);

		//// Quotation Details
		$quotation_no = $this->filter_field($quotation_no);
		$quotation_date = $this->filter_field($quotation_date); // $('#collected_datetime').data('datetimepicker');
		$reference_no = $this->filter_field($reference_no);
        $reference_date = $this->filter_field($reference_date);
        $preparedby = $this->filter_field($preparedby);
        
		$project_job = $this->filter_field($project_job);
		$hsnsac_code = $this->filter_field($hsnsac_code);

		//// Purchased Details

		//// Amount Details
		$total_beforegst = $this->filter_field($total_beforegst);
		//$igst_percentage = $this->filter_field($txt_igst_percentage);
		$igst = $this->filter_field($igst);
		//$sgst_percentage = $this->filter_field($txt_sgst_percentage);
		$sgst = $this->filter_field($sgst);
		//$cgst_percentage = $this->filter_field($txt_cgst_percentage);
		$cgst = $this->filter_field($cgst);
		//$r_add = $this->filter_field($txt_add);
		//$r_less = $this->filter_field($txt_less);
		$round_off = $this->filter_field($round_off);
		$total_aftergst = $this->filter_field($total_aftergst);

		$note = $this->filter_field($note);

		//// Check if quotation number already exists
		$this->load->model('Quotation_model');
		$is_exists = $this->Quotation_model->is_quotation_number_exists($quotation_no);

		if($is_exists)
		{
			echo json_encode(2);
		}
		else
		{

			// Load quotation model
			$response = $this->Quotation_model->save_quotation($state, $code, $cust_gstin, $currency, $customer_id, 
			$quotation_no, $quotation_date, $reference_no, $reference_date, $preparedby, $project_job, $hsnsac_code, 
			$total_beforegst, $igst, $sgst, $cgst, $round_off, $total_aftergst, $note, $revised_on_quot);

			if($response==TRUE)
			{
				//submitted successfully
				$result=array(
					'success'=>true,
					'response'=>201
				);
			}
			else
			{
				//failed to submit form
				$result=array(
					'success'=>true,
					'response'=>110
				);
			}

			echo json_encode($result);

		}
		
		// if ($is_exists){
		// 	echo json_encode(2);
		// // }else{
		// 	//// Load quotation model		
		// 	$data = $this->Quotation_model->save_quotation($state, $code, $cust_gstin, $currency, $customer_id, 
		// 										$quotation_no, $quotation_date, $reference_no, $reference_date, $preparedby, $project_job, $hsnsac_code, 
		// 										$total_beforegst, $igst, $sgst, $cgst, $round_off, $total_aftergst, $note, $revised_on_quot);
		// 	echo json_encode($data);
		// }		
	}

	public function edit_quotation()
	{
		//// Customer Info
		$state = $_GET['state'];
		$code = $_GET['code'];
		$cust_gstin = $_GET['cust_gstin'];
		$currency = $_GET['currency'];
		$customer_id = $_GET['customer_id'];

		//// Quotation Details
		$quotation_no = $_GET['quotation_no'];
		$quotation_date = $_GET['quotation_date']; // $('#collected_datetime').data('datetimepicker');
		$reference_no = $_GET['reference_no'];
        $reference_date = $_GET['reference_date'];
        $preparedby = $_GET['preparedby'];
		$project_job = $_GET['project_job'];
		$hsnsac_code = $_GET['hsnsac_code'];

		//// Purchased Details

		//// Amount Details
		$total_beforegst = $_GET['total_beforegst'];
		//$igst_percentage = $_GET['txt_igst_percentage'];
		$igst = $_GET['igst'];
		//$sgst_percentage = $_GET['txt_sgst_percentage'];
		$sgst = $_GET['sgst'];
		//$cgst_percentage = $_GET['txt_cgst_percentage'];
		$cgst = $_GET['cgst'];
		//$r_add = $_GET['txt_add'];
		//$r_less = $_GET['txt_less'];
		$round_off = $_GET['round_off'];
		$total_aftergst = $_GET['total_aftergst'];

		// Apply Filter
		$state = $this->filter_field($state);
		$code = $this->filter_field($code);
		$cust_gstin = $this->filter_field($cust_gstin);
		$customer_id = $this->filter_field($customer_id);

		//// Quotation Details
		$quotation_no = $this->filter_field($quotation_no);
		$quotation_date = $this->filter_field($quotation_date); // $('#collected_datetime').data('datetimepicker');
		$reference_no = $this->filter_field($reference_no);
        $reference_date = $this->filter_field($reference_date);
        $preparedby = $this->filter_field($preparedby);
		$project_job = $this->filter_field($project_job);
		$hsnsac_code = $this->filter_field($hsnsac_code);

		//// Purchased Details

		//// Amount Details
		$total_beforegst = $this->filter_field($total_beforegst);
		//$igst_percentage = $this->filter_field($txt_igst_percentage);
		$igst = $this->filter_field($igst);
		//$sgst_percentage = $this->filter_field($txt_sgst_percentage);
		$sgst = $this->filter_field($sgst);
		//$cgst_percentage = $this->filter_field($txt_cgst_percentage);
		$cgst = $this->filter_field($cgst);
		//$r_add = $this->filter_field($txt_add);
		//$r_less = $this->filter_field($txt_less);
		$round_off = $this->filter_field($round_off);
		$total_aftergst = $this->filter_field($total_aftergst);

		//// Check if quotation number already exists
		//$this->load->model('Quotation_model');
		//$is_exists = $this->Quotation_model->is_quotation_number_exists($quotation_no);
		
		//if ($is_exists){
		//	echo json_encode(2);
		//}else{
			//// Load quotation model	
			$this->load->model('Quotation_model');
			$data = $this->Quotation_model->edit_quotation($state, $code, $cust_gstin, $currency, $customer_id, 
												$quotation_no, $quotation_date, $reference_no, $reference_date, $preparedby, $project_job, $hsnsac_code, 
												$total_beforegst, $igst, $sgst, $cgst, $round_off, $total_aftergst);
			echo json_encode($data);
		//}		
	}

	public function save_quotation_items()
	{
		$quotation_no = $_GET['quotation_no'];
		$product_id = $_GET['product_id'];
		$description = $_GET['description'];
		$rate = $_GET['rate'];

		$warranty = $_GET['warranty'];
		$amc_percentage = $_GET['amc_percentage'];

		$quantity = $_GET['quantity'];

		// Apply Filter
		$quotation_no = $this->filter_field($quotation_no);
		$product_id = $this->filter_field($product_id);
		$description = $this->filter_field($description);
		$rate = $this->filter_field($rate);
		$warranty = $this->filter_field($warranty);
		$amc_percentage = $this->filter_field($amc_percentage);
		$quantity = $this->filter_field($quantity);
				
		//// Load quotation model
		$this->load->model('Quotation_model');
		$data = $this->Quotation_model->save_quotation_items($quotation_no, $product_id, $description, $rate, $warranty, $amc_percentage,  $quantity);
		
		echo json_encode($data);		
	}

	public function delete_quotation_items($quotation_no)
	{
		if($quotation_no != "")
		{
			// Apply Filter
			$quotation_no = $this->filter_field($quotation_no);

			$this->load->model('Quotation_model');
			$data = $this->Quotation_model->delete_quotation_items($quotation_no);

			return $data;
		}
		// else
		// {
		// 	echo json_encode("testing");
		// }
		// $quotation_no = $_GET['quotation_no'];
		
		// // Apply Filter
		// $quotation_no = $this->filter_field($quotation_no);
		
		// //// Load quotation model
		// $this->load->model('Quotation_model');
		// $data = $this->Quotation_model->delete_quotation_items($quotation_no);
		
		// echo json_encode($data);		
	}

	// Filter a field
	function filter_field($field){
		$field = htmlspecialchars($field);
		$field = strip_tags($field);
		$field = addslashes($field);
		$field = filter_var($field, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);
			
		return $field;
	}

	//get state and satecode
	public function get_state_code ()
	{
		$this->load->model('StateGSTCode_modal');
		$data=$this->StateGSTCode_modal->get_stategstcode();

			
		if ($data){
			echo json_encode($data->result());
		} else {
			echo json_encode(110);
		}	
	}


	//delete quotation based on Quotation No
	public function delete_quotation()
	{
		$quotation_no = $_POST['quotation_no'];

		// Apply Filter
		$quotation_no = $this->filter_field($quotation_no);


		/*
		 * step 1: delete quotation details from table[Quotation]
		 * step2: if Quotation details is successfully deleted from table[Quotation]
		 * then delte items details from table[Quotation_items]
		*/

		$this->load->model('Quotation_model');
		$data=$this->Quotation_model->delete_quotation($quotation_no);

		if($data)
		{
			$result=$this->delete_quotation_items($quotation_no);
			if($result){
				echo json_encode(201);//succcessfully deleted
			}else{
				 echo json_encode(110);//failed to delete record
			}
		}
		else
		{
			echo json_encode(110);
		}
	}


}
?>
