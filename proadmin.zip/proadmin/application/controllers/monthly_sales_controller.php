<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class monthly_sales_controller extends CI_Controller 
{
    public function index()
    {
        $this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('monthly_sales');    
		$this->load->view('footer');
    }

}


?>