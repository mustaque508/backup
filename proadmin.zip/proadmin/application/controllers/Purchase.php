<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Purchase extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	
	public function index()
	{
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('purchase');    
		$this->load->view('footer');			
	}
	
	public function get_all_purchases()
	{
		$from_timestamp = $_GET['from_timestamp'];
		$to_timestamp = $_GET['to_timestamp'];
		$top_records = $_GET['top_records'];
		
		$this->load->model('Purchase_Model');
		$data['mData'] = $this->Purchase_Model->get_all_purchases($from_timestamp, $to_timestamp, $top_records);
		
		if (!is_int($data['mData']))
		{
			if ($data['mData']->num_rows() > 0){
				echo json_encode($data['mData']->result());
			} else {
				echo json_encode(110);
			}
		}
		else
		{
			echo json_encode(110);
		}
		return;
		
		/*
		if (!is_int($data['mData']))
		{
			$jqxData = array();
			
			// output data of each row
			foreach ($data['mData']->result() as $row1)
			{
				$jqxData[] = array('id' => $row1["id"], 'full_name' => $row1["full_name"], 'contact_no' => $row1["contact_no"], 
									'dept_email_id' => $row1["dept_email_id"], 'department' => $row1["department"], 'designation' => $row1["designation"], 
									'address' => $row1["address"], 'created_dt' => $row1["created_dt"], 'serial_key' => $row1["serial_key"], 'installed_dt' => $row1["installed_dt"]);
			}
			
			echo json_encode($jqxData);
		} else {
			echo json_encode(110);
		}
		*/
	}
}
?>
