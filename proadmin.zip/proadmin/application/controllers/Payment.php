<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

use Razorpay\Api\Api;

class Payment extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	
	public function index()
	{
		$data['razorpay_order_id'] = $_GET['razorpay_order_id'];
		
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('payment', $data);    
		$this->load->view('footer');			
	}
	
	public function custom_reports()
	{
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('payment_custom');    
		$this->load->view('footer');
	}


	// get order_id based on payment_id
	public function get_order_id()
	{
		require_once(APPPATH . 'third_party/razorpay-php/config.php');
		require_once(APPPATH . 'third_party/razorpay-php/Razorpay.php');

		$api = new Api($keyId, $keySecret);

		if(isset($_GET['payment_id']))
		{
			// fetch payment_details based on payment_id
			$payment_details = $api->payment->fetch($_GET['payment_id']);
			if(isset($payment_details))
			{
				foreach (array($payment_details) as $value) {
					echo json_encode($value->order_id);
				}
			}
			else
			{
				echo json_encode(110);//not found order_id
			}
			
		}


	}
	
	public function get_order_with_id()
	{
		$order_id = $_GET['order_id'];
		if ($order_id === "") {
			echo json_encode(110);
			return;
		}
		
		//$from_timestamp = $_GET['from_timestamp'];
		//$to_timestamp = $_GET['to_timestamp'];
		//$top_records = $_GET['top_records'];
		
		//require_once("razorpay-php/config.php");
		//require_once("razorpay-php/Razorpay.php");	

		require_once(APPPATH . 'third_party/razorpay-php/config.php');
		require_once(APPPATH . 'third_party/razorpay-php/Razorpay.php');

		$api = new Api($keyId, $keySecret);
		
		//if($from_timestamp == 0)
		//	$from_timestamp = strtotime("2020-01-01 00:00:01");
		
		//if ($to_timestamp == 0){
		//	$curr_datetime = date('Y-m-d H:i:s');
		//	$to_timestamp = strtotime($curr_datetime);
		//}

		/*
		$params = array(
			'count' => $top_records,
			'skip'  => 0,
			'from'  => $from_timestamp,
			'to'  => $to_timestamp
		);
		*/
		
		//echo json_encode($params);
		//return;

		try{
			$order = $api->Order->fetch($order_id);
			//$order = $api->Order->fetch($order_id);
			//echo json_encode($order);
			
			$m_array = array();					
			$m_array[] = array(
				'id' => $order['id'],
				'entity' => $order['entity'],
				'amount' => $order['amount'],
				'amount_paid' => $order['amount_paid'],
				'amount_due' => $order['amount_due'],
				'currency' =>$order['currency'],
				'receipt' => $order['receipt'],
				'status' => $order['status'],
				'attempts' => $order['attempts'],
				'created_at' => $order['created_at']
			);
			
			echo json_encode($m_array);
		} catch(Exception $e) {
			echo json_encode(110);
		}		
	}
	
	public function get_orders()
	{
		$from_timestamp = $_GET['from_timestamp'];
		$to_timestamp = $_GET['to_timestamp'];
		$top_records = 100;
		$order_id = $_GET['order_id'];

		$payment_id=$_GET['payment_id'];
		
		//require_once("razorpay-php/config.php");
		//require_once("razorpay-php/Razorpay.php");	

		require_once(APPPATH . 'third_party/razorpay-php/config.php');
		require_once(APPPATH . 'third_party/razorpay-php/Razorpay.php');

		$api = new Api($keyId, $keySecret);

		try{
			$m_array = array();
			
			if ($order_id !== "") {
				$order = $api->Order->fetch($order_id);
				$m_array[] = array(
					'id' => $order['id'],
					'entity' => $order['entity'],
					'amount' => $order['amount'],
					'amount_paid' => $order['amount_paid'],
					'amount_due' => $order['amount_due'],
					'currency' =>$order['currency'],
					'receipt' => $order['receipt'],
					'status' => $order['status'],
					'attempts' => $order['attempts'],
					'created_at' => $order['created_at']
				);

				

			} 
			
			else if($payment_id != "")
				{
					// fetch payment_details based on payment_id
					 $payments = $api->payment->fetch($payment_id);
					 foreach (array($payments) as $value)
					 {
						//  pass order_id based on payment_id
						$order = $api->Order->fetch($value->order_id);
						$m_array[] = array(
							'id' => $order['id'],
							'entity' => $order['entity'],
							'amount' => $order['amount'],
							'amount_paid' => $order['amount_paid'],
							'amount_due' => $order['amount_due'],
							'currency' =>$order['currency'],
							'receipt' => $order['receipt'],
							'status' => $order['status'],
							'attempts' => $order['attempts'],
							'created_at' => $order['created_at']
						); 
					 }
				}
			
			else {
				if($from_timestamp == 0)
					$from_timestamp = strtotime("2020-01-01 00:00:01");
				
				if ($to_timestamp == 0){
					$curr_datetime = date('Y-m-d H:i:s');
					$to_timestamp = strtotime($curr_datetime);
				}

				$params = array(
					'count' => $top_records,
					'skip'  => 0,
					'from'  => $from_timestamp,
					'to'  => $to_timestamp
				);
				$orders = $api->Order->all($params);
				
				$t_count = $orders->count;				
				for ($x = 0; $x < $t_count; $x++) {
					$m_array[] = array(
						'id' => $orders->items[$x]['id'],
						'entity' => $orders->items[$x]['entity'],
						'amount' => $orders->items[$x]['amount'],
						'amount_paid' => $orders->items[$x]['amount_paid'],
						'amount_due' => $orders->items[$x]['amount_due'],
						'currency' =>$orders->items[$x]['currency'],
						'receipt' => $orders->items[$x]['receipt'],
						'status' => $orders->items[$x]['status'],
						'attempts' => $orders->items[$x]['attempts'],
						'created_at' => $orders->items[$x]['created_at']
					);
				}
			}
			
			echo json_encode($m_array);
		} catch(Exception $e) {
			echo json_encode(110);
		}		
	}
	
	public function get_payments()
	{
		$from_timestamp = $_GET['from_timestamp'];
		$to_timestamp = $_GET['to_timestamp'];
		$top_records = 100;
		$selected_order_id = $_GET['selected_order_id'];

		$payment_id=$_GET['payment_id'];
		
		//require_once("razorpay-php/config.php");
		//require_once("razorpay-php/Razorpay.php");	

		require_once(APPPATH . 'third_party/razorpay-php/config.php');
		require_once(APPPATH . 'third_party/razorpay-php/Razorpay.php');

		$api = new Api($keyId, $keySecret);
			
		try{

			$m_array = array();

			if ($selected_order_id != "") {
				$payments = $api->order->fetch($selected_order_id)->payments();
			}
			
			else if($payment_id != "")
			{
				// fetch payment_details based on payment_id
				$payment_details = $api->payment->fetch($payment_id);
				foreach (array($payment_details) as $value) 
				{
					$m_array[]=array(
						'id' => $value->id,
						'entity' => $value->entity,
						'amount' => $value->amount,
						'currency' =>  $value->currency,
						'status' => $value->status,
						'order_id' => $value->order_id,
						'invoice_id' => $value->invoice_id,
						'international' =>  $value->international,
						'method' =>  $value->method,
						'amount_refunded' =>  $value->amount_refunded,
						'refund_status' => $value->refund_status,
						'captured' =>  $value->captured,
						'description' =>  $value->description,
						'card_id' => $value->card_id,
						'bank' =>  $value->bank,
						'wallet' =>  $value->wallet,
						'vpa' => $value->vpa,
						'email' =>  $value->email,
						'contact' =>  $value->contact,
						'notes' => $value->notes,
						'fee' =>  $value->fee,
						'tax' => $value->tax,
						'error_code' =>  $value->error_code,
						'error_description' => $value->error_description,
						'created_at' => $value->created_at
					);
				}
			}


			else
			{
				if($from_timestamp == 0)
					$from_timestamp = strtotime("2020-01-01 00:00:01");
				
				if ($to_timestamp == 0){
					$curr_datetime = date('Y-m-d H:i:s');
					$to_timestamp = strtotime($curr_datetime);
				}
				
				$params = array(
					'count' => $top_records,
					'skip'  => 0,
					'from'  => $from_timestamp,
					'to'  => $to_timestamp
				);
				$payments = $api->payment->all($params);
			}
			
		
			if(isset($payments))
			{
				$t_count = $payments->count;
				//echo "<br><br>" . $payments->items[0]["id"];
				//echo $t_count;
			
				for ($x = 0; $x < $t_count; $x++) {
					$m_array[] = array(
						'id' => $payments->items[$x]['id'],
						'entity' => $payments->items[$x]['entity'],
						'amount' => $payments->items[$x]['amount'],
						'currency' => $payments->items[$x]['currency'],
						'status' => $payments->items[$x]['status'],
						'order_id' =>$payments->items[$x]['order_id'],
						'invoice_id' => $payments->items[$x]['invoice_id'],
						'international' => $payments->items[$x]['international'],
						'method' => $payments->items[$x]['method'],
						'amount_refunded' => $payments->items[$x]['amount_refunded'],
						'refund_status' => $payments->items[$x]['refund_status'],
						'captured' => $payments->items[$x]['captured'],
						'description' => $payments->items[$x]['description'],
						'card_id' => $payments->items[$x]['card_id'],
						'bank' => $payments->items[$x]['bank'],
						'wallet' => $payments->items[$x]['wallet'],
						'vpa' => $payments->items[$x]['vpa'],
						'email' => $payments->items[$x]['email'],
						'contact' => $payments->items[$x]['contact'],
						'notes' => $payments->items[$x]['notes'],
						'fee' => $payments->items[$x]['fee'],
						'tax' => $payments->items[$x]['tax'],
						'error_code' => $payments->items[$x]['error_code'],
						'error_description' => $payments->items[$x]['error_description'],
						'created_at' => gmdate("Y-m-d H:i:s", $payments->items[$x]['created_at']),
					);
				}
			
			}
			
			echo json_encode($m_array);
		} catch(Exception $e) {
			echo json_encode(110);
		}
	}
}
?>
