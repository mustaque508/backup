<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class role extends CI_Controller 
{

    //create role
    public function create_role()
    {
        //  // $_SERVER['HTTP_REFERER'] avoid direct access...
        //  if(!isset($_SERVER['HTTP_REFERER']))
        //  return redirect('index.php/Userc/login');

         // get modules
         $get_data['module_data']=$this->role_model->get_modules();
         
        //type
        $get_data['type']="create";

        $this->load->view('header');
        $this->load->view('sidebar');
        $this->load->view('create_role',$get_data);
        $this->load->view('footer');
    }

    //delete or update role
    public function edit_delete_role()
    {
        //  // $_SERVER['HTTP_REFERER'] avoid direct access...
        //  if(!isset($_SERVER['HTTP_REFERER']))
        //  return redirect('index.php/Userc/login');
         
        // get modules
         $get_data['module_data']=$this->role_model->get_modules();

       //type 
       $get_data['type']="update_delete";

        $this->load->view('header');
        $this->load->view('sidebar');
        $this->load->view('create_role',$get_data);
        $this->load->view('footer');

    }

    //get all role_names
    public function getrole_name()
    {
        if(!empty($this->role_model->get_rolenames("")))
        {
           $roles=$this->role_model->get_rolenames("");

            echo json_encode($roles);//pass rolenames to view[create_role]
        }
        else
        {
            echo json_encode(110);//fail to fetch role names
        }
    }

    // get role-details based on role-id
    public function getrole_details()
    {
        $role_id=$this->input->post('role_id');
        $result=$this->role_model->getrole_details($role_id);
        if(!empty($result))
        {
            echo json_encode($result);
        }
        else
        {
            echo json_encode(110);//failed to fetch role details based on role-id
        }
    }


    // store role details
    public function storeData()
    {
        // common validation  for userdata
       if($this->input->post("Type")=="create" || $this->input->post("Type")=="update_delete")
       {
            $this->form_validation->set_rules('access_details','checkbox','callback_access_details_check');
       }

       // validation if Type[create]
       if($this->input->post("Type")=="create")
       {
           $this->form_validation->set_rules('role_name', 'Role Name', 'trim|required|alpha_numeric_spaces|min_length[2]|max_length[50]|is_unique[tbl_roles.role_name]',array('is_unique'=>'The %s already exist'));
       }


       // validation if Type[update_delete]
       if($this->input->post("Type")=="update_delete")
       {
            $role_names=$this->role_model->get_rolenames($this->input->post("role_id"));
            
            if(!empty($role_names))
            {
                foreach ($role_names as $row) 
                {
                    // in operation[update] if role_name has changed
                    if($row->role_name != $this->input->post("role_name"))
                    {
                         $this->form_validation->set_rules('role_name', 'Role Name', 'trim|required|alpha_numeric_spaces|min_length[2]|max_length[50]|is_unique[tbl_roles.role_name]',array('is_unique'=>'The %s already exist'));
                    }
                }
            }
       }



         // check validation is correct?
         if ($this->form_validation->run()) 
         {
            //initialize $result 
                $result=FALSE;

               // common user_data
                $get_data=array(
                    'role_name'=>$this->input->post('role_name'),
                    'role_id'=>$this->input->post('role_id'),
                    'access_details'=>$this->input->post('access_details')
                );

                 // if type[create]
                if($this->input->post("Type")=="create")
                {
                    $result=$this->role_model->store_role_details($get_data);
                }

                 // if type[update_delete]
                if($this->input->post("Type")=="update_delete")
                {
                    $result=$this->role_model->update_role_details($get_data);
                }
                
                
                if($result)
                {
                    $result=array(
                        'success'=>true,
                        'response'=>201
                    );
                    echo json_encode($result);
                }
                else
                {
                    $result=array(
                        'success'=>true,
                        'response'=>110
                    );
                    echo json_encode($result);
                }


         }
         else
         {
             
              // display validationerror message within same page    
              $errors=array(
                'error'=>true,
                'rolename_error'=>form_error('role_name'),
                'access_details_error'=>form_error('access_details')
            );
            echo json_encode($errors);
         }
    }


    // delete role based on role_id
    public function deleteRecord()
    {
        $role_id=$this->input->post('role_id');

        $result=$this->role_model->delete_role_details($role_id);

        // return value
        // echo (($result) ?  json_encode(210):json_encode(110));

        if($result)
        {
                echo json_encode(201);//succcessfully deleted
        }
        else
        {
            echo json_encode(110);//failed to delete record
        }
    }



    // access details validation
        public function access_details_check($str)
        {
           
            //operation Type
            $opt_type=$this->input->post("Type");

            $str=$this->input->post('access_details');
            if(empty($str))
            {
                $this->form_validation->set_message('access_details_check','The {field} field is required');
                return FALSE;
            }
            else
            {  
                if($opt_type=="create")
                {
                    return TRUE;
                }

                if($opt_type=="update_delete")
                {
                    // initialize
                     $IsEmpty=0;

                    for ($i=0; $i <count($str) ; $i++) 
                    { 
                        if(!($str[$i]['read_access']==0 && $str[$i]['write_access']==0 && $str[$i]['delete_access']==0))
                        {
                            $IsEmpty=1;
                            break;
                        }
                        else
                        { 
                            $IsEmpty=0;
                        }
                    }

                    if($IsEmpty==0)
                    {
                        $this->form_validation->set_message('access_details_check','The {field} field is required');
                        return FALSE;
                    }
                    else
                    {   
                        return TRUE;
                    }
            

                }


            }

            
        }
  

}

?>