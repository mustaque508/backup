<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Invoice_controller extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	
	public function index()
	{
		$invoice_no = "";
		if(isset($_GET['invoice_no'])) {
			$invoice_no = $_GET['invoice_no'];
			$invoice_no = $this->filter_field($invoice_no);
		}

		$data['new_invoice_no'] = $invoice_no;

		$this->load->model('Invoice_model');
		$data['invoices'] = $this->Invoice_model->get_invoices();

		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('Invoices/view_invoice_new', $data);    
		$this->load->view('footer');
	}	

	public function create_invoice()
	{
		$this->load->model('Customer_model');
		$data['customers'] = $this->Customer_model->get_customers();

		$this->load->model('Product_model');
		$data['products'] = $this->Product_model->get_products();

		$this->load->model('StateGSTCode_modal');
		$data['statesgstcode'] = $this->StateGSTCode_modal->get_stategstcode();

		$this->load->model('Quotation_model');
		$data['quotations'] = $this->Quotation_model->get_quotations();

		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('Invoices/create_invoice', $data);    
		$this->load->view('footer');	

	}

	public function edit_invoice_view()
	{
		$this->load->model('Invoice_model');
		$data['invoices'] = $this->Invoice_model->get_invoices();

		$this->load->model('Customer_model');
		$data['customers'] = $this->Customer_model->get_customers();

		$this->load->model('Product_model');
		$data['products'] = $this->Product_model->get_products();

		$this->load->model('StateGSTCode_modal');
		$data['statesgstcode'] = $this->StateGSTCode_modal->get_stategstcode();

		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('Invoices/edit_invoice', $data);    
		$this->load->view('footer');			
	}

	public function view_invoice()
	{
		$invoice_no = "";
		if(isset($_GET['invoice_no'])) {
			$invoice_no = $_GET['invoice_no'];
			$invoice_no = $this->filter_field($invoice_no);
		}

		$data['new_invoice_no'] = $invoice_no;

		$this->load->model('Invoice_model');
		$data['invoices'] = $this->Invoice_model->get_invoices();

		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('Invoices/view_invoice_new', $data);    
		$this->load->view('footer');
	}	
	
	public function get_invoice_details()
	{
		$invoice_no = $_GET['invoice_no'];
		$invoice_no = $this->filter_field($invoice_no);
		
		$this->load->model('Invoice_model');
		$data = $this->Invoice_model->get_selected_invoices($invoice_no);
		
		if (!is_int($data))
		{
			if ($data->num_rows() > 0){
				echo json_encode($data->result());
			} else {
				echo json_encode(110);
			}
		}
		else
		{
			echo json_encode(110);
		}		
	}

	public function get_invoice_item_details()
	{
		$invoice_no = $_GET['invoice_no'];
		$invoice_no = $this->filter_field($invoice_no);
		
		$this->load->model('Invoice_model');
		$data = $this->Invoice_model->get_invoice_item_details($invoice_no);

		//echo json_encode($data);
		//return;
				
		if (!is_int($data))
		{
			if ($data->num_rows() > 0){
				echo json_encode($data->result());
			} else {
				echo json_encode(111);
			}
		}
		else
		{
			echo json_encode(110);
		}		
	}

	public function get_invoices()
	{
		$this->load->model('Invoice_model');
		$data = $this->Invoice_model->get_invoices();
		
		if (!is_int($data))
		{
			if ($data->num_rows() > 0){
				echo json_encode($data->result());
			} else {
				echo json_encode(110);
			}
		}
		else
		{
			echo json_encode(110);
		}
	}

	public function save_invoice()
	{
		//// Customer Info
		$state = $_GET['state'];
		$code = $_GET['code'];
		$cust_gstin = $_GET['cust_gstin'];
		$currency = $_GET['currency'];
		$customer_id = $_GET['customer_id'];

		//// Invoice Details
		$invoice_no = $_GET['invoice_no'];
		$invoice_date = $_GET['invoice_date']; // $('#collected_datetime').data('datetimepicker');
		$order_no = $_GET['order_no'];
		$order_date = $_GET['order_date'];
		$project_job = $_GET['project_job'];
		$hsnsac_code = $_GET['hsnsac_code'];

		//// Purchased Details

		//// Amount Details
		$total_beforegst = $_GET['total_beforegst'];
		//$igst_percentage = $_GET['txt_igst_percentage'];
		$igst = $_GET['igst'];
		//$sgst_percentage = $_GET['txt_sgst_percentage'];
		$sgst = $_GET['sgst'];
		//$cgst_percentage = $_GET['txt_cgst_percentage'];
		$cgst = $_GET['cgst'];
		//$r_add = $_GET['txt_add'];
		//$r_less = $_GET['txt_less'];
		$round_off = $_GET['round_off'];
		$total_aftergst = $_GET['total_aftergst'];

		// Apply Filter
		$state = $this->filter_field($state);
		$code = $this->filter_field($code);
		$cust_gstin = $this->filter_field($cust_gstin);
		$currency = $this->filter_field($currency);
		$customer_id = $this->filter_field($customer_id);

		//// Invoice Details
		$invoice_no = $this->filter_field($invoice_no);
		$invoice_date = $this->filter_field($invoice_date); // $('#collected_datetime').data('datetimepicker');
		$order_no = $this->filter_field($order_no);
		$order_date = $this->filter_field($order_date);
		$project_job = $this->filter_field($project_job);
		$hsnsac_code = $this->filter_field($hsnsac_code);

		//// Purchased Details

		//// Amount Details
		$total_beforegst = $this->filter_field($total_beforegst);
		//$igst_percentage = $this->filter_field($txt_igst_percentage);
		$igst = $this->filter_field($igst);
		//$sgst_percentage = $this->filter_field($txt_sgst_percentage);
		$sgst = $this->filter_field($sgst);
		//$cgst_percentage = $this->filter_field($txt_cgst_percentage);
		$cgst = $this->filter_field($cgst);
		//$r_add = $this->filter_field($txt_add);
		//$r_less = $this->filter_field($txt_less);
		$round_off = $this->filter_field($round_off);
		$total_aftergst = $this->filter_field($total_aftergst);

		//// Check if invoice number already exists
		$this->load->model('Invoice_model');
		$is_exists = $this->Invoice_model->is_invoice_number_exists($invoice_no);
		
		if ($is_exists){
			echo json_encode(2);
		}else{
			//// Load invoice model		
			$data = $this->Invoice_model->save_invoice($state, $code, $cust_gstin, $currency, $customer_id, 
												$invoice_no, $invoice_date, $order_no, $order_date, $project_job, $hsnsac_code, 
												$total_beforegst, $igst, $sgst, $cgst, $round_off, $total_aftergst);
			echo json_encode($data);
		}		
	}

	public function edit_invoice()
	{
		//// Customer Info
		$state = $_GET['state'];
		$code = $_GET['code'];
		$cust_gstin = $_GET['cust_gstin'];
		$currency = $_GET['currency'];
		$customer_id = $_GET['customer_id'];

		//// Invoice Details
		$invoice_no = $_GET['invoice_no'];
		$invoice_date = $_GET['invoice_date']; // $('#collected_datetime').data('datetimepicker');
		$order_no = $_GET['order_no'];
		$order_date = $_GET['order_date'];
		$project_job = $_GET['project_job'];
		$hsnsac_code = $_GET['hsnsac_code'];

		//// Purchased Details

		//// Amount Details
		$total_beforegst = $_GET['total_beforegst'];
		//$igst_percentage = $_GET['txt_igst_percentage'];
		$igst = $_GET['igst'];
		//$sgst_percentage = $_GET['txt_sgst_percentage'];
		$sgst = $_GET['sgst'];
		//$cgst_percentage = $_GET['txt_cgst_percentage'];
		$cgst = $_GET['cgst'];
		//$r_add = $_GET['txt_add'];
		//$r_less = $_GET['txt_less'];
		$round_off = $_GET['round_off'];
		$total_aftergst = $_GET['total_aftergst'];

		// Apply Filter
		$state = $this->filter_field($state);
		$code = $this->filter_field($code);
		$cust_gstin = $this->filter_field($cust_gstin);
		$customer_id = $this->filter_field($customer_id);

		//// Invoice Details
		$invoice_no = $this->filter_field($invoice_no);
		$invoice_date = $this->filter_field($invoice_date); // $('#collected_datetime').data('datetimepicker');
		$order_no = $this->filter_field($order_no);
		$order_date = $this->filter_field($order_date);
		$project_job = $this->filter_field($project_job);
		$hsnsac_code = $this->filter_field($hsnsac_code);

		//// Purchased Details

		//// Amount Details
		$total_beforegst = $this->filter_field($total_beforegst);
		//$igst_percentage = $this->filter_field($txt_igst_percentage);
		$igst = $this->filter_field($igst);
		//$sgst_percentage = $this->filter_field($txt_sgst_percentage);
		$sgst = $this->filter_field($sgst);
		//$cgst_percentage = $this->filter_field($txt_cgst_percentage);
		$cgst = $this->filter_field($cgst);
		//$r_add = $this->filter_field($txt_add);
		//$r_less = $this->filter_field($txt_less);
		$round_off = $this->filter_field($round_off);
		$total_aftergst = $this->filter_field($total_aftergst);

		//// Check if invoice number already exists
		//$this->load->model('Invoice_model');
		//$is_exists = $this->Invoice_model->is_invoice_number_exists($invoice_no);
		
		//if ($is_exists){
		//	echo json_encode(2);
		//}else{
			//// Load invoice model	
			$this->load->model('Invoice_model');
			$data = $this->Invoice_model->edit_invoice($state, $code, $cust_gstin, $currency, $customer_id, 
												$invoice_no, $invoice_date, $order_no, $order_date, $project_job, $hsnsac_code, 
												$total_beforegst, $igst, $sgst, $cgst, $round_off, $total_aftergst);
			echo json_encode($data);
		//}		
	}

	public function save_invoice_items()
	{
		$invoice_no = $_GET['invoice_no'];
		$product_id = $_GET['product_id'];
		$description = $_GET['description'];
		$rate = $_GET['rate'];

		$warranty = $_GET['warranty'];
		$amc_percentage = $_GET['amc_percentage'];

		$quantity = $_GET['quantity'];

		// Apply Filter
		$invoice_no = $this->filter_field($invoice_no);
		$product_id = $this->filter_field($product_id);
		$description = $this->filter_field($description);
		$rate = $this->filter_field($rate);
		$warranty = $this->filter_field($warranty);
		$amc_percentage = $this->filter_field($amc_percentage);
		$quantity = $this->filter_field($quantity);
				
		//// Load invoice model
		$this->load->model('Invoice_model');
		$data = $this->Invoice_model->save_invoice_items($invoice_no, $product_id, $description, $rate, $warranty, $amc_percentage,  $quantity);
		
		echo json_encode($data);		
	}

	public function delete_invoice_items()
	{
		$invoice_no = $_GET['invoice_no'];
		
		// Apply Filter
		$invoice_no = $this->filter_field($invoice_no);
		
		//// Load invoice model
		$this->load->model('Invoice_model');
		$data = $this->Invoice_model->delete_invoice_items($invoice_no);
		
		echo json_encode($data);		
	}

	// Filter a field
	function filter_field($field){
		$field = htmlspecialchars($field);
		$field = strip_tags($field);
		$field = addslashes($field);
		$field = filter_var($field, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);
			
		return $field;
	}


}
?>
