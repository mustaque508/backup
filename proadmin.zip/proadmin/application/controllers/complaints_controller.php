<?php

if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class complaints_controller extends CI_Controller 
{
    public function index()
	{
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('complaints');    
		$this->load->view('footer');			
	}

	// get all complaint_details
	public function get_data()
	{
		// $couponcode = $_GET['couponcode'];
		// $vendor_id = $_GET['vendor_id'];//VendorID_CustomerID
		// $isused = $_GET['isused'];
		$complaintno=$this->input->get("complaintno");
		$username=$this->input->get("username");
		$serialkey=$this->input->get("serialkey");
		$fromDateTime=$this->input->get("fromDateTime");
		$toDateTime=$this->input->get("toDateTime");
		$contact_no=$this->input->get("contact_no");
		
		$this->load->model('complaints_model');
		$data = $this->complaints_model->get_data($complaintno,$username,$serialkey,$fromDateTime,$toDateTime,$contact_no);
		
		if (!is_int($data))
		{
			if ($data->num_rows() > 0){
				echo json_encode($data->result());
			} else {
				echo json_encode(110);
			}
		}
		else
		{
			echo json_encode(110);
		}
	}


	//get complaint history
	public function get_complaint_history()
	{
		$complaint_no=$this->input->get("complaint_no");
		// echo json_encode($complaint_no);
		$this->load->model('complaints_model');
		$data=$this->complaints_model->get_complaint_history($complaint_no);

		if (!is_int($data))
		{
			if ($data->num_rows() > 0){
				echo json_encode($data->result());
			} else {
				echo json_encode(110);
			}
		}
		else
		{
			echo json_encode(110);
		}

	}

	//store complaint history
	public function store_complaint_history()
	{
		sleep(1);
		$getData=array(
			'ComplaintNo'=>$this->input->post("ComplaintNo"),
			'ActionTaken'=>$this->input->post("ActionTaken"),
			'ActionDate'=>$this->input->post("ActionDate"),
			'ActionStatus'=>$this->input->post("ActionStatus"),
			'Remark'=>$this->input->post("Remark"),
			'userid'=>$this->input->post("userid")
		);

		
		
		
		$this->load->model('complaints_model');
		$result=$this->complaints_model->store_complaint_history($getData);

		if($result==TRUE)
		{
			echo json_encode(201);//submitted successfully
		}
		else
		{
			echo json_encode(110);//failed to submit
		}

		


	}
}

?>