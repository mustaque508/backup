<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class user extends CI_Controller 
{

    //create user
    public function create_user()
    {
        // // $_SERVER['HTTP_REFERER'] avoid direct access...
        //     if(!isset($_SERVER['HTTP_REFERER']))
        //         return redirect('index.php/Userc/login');

        // get role details
        $get_data['role_data']=$this->user_model->get_roleDetails();

        //type
        $get_data['type']='create';

        if(!empty($get_data))
        {
            $this->load->view('header');
            $this->load->view('sidebar');
            $this->load->view('create_user',$get_data);
            $this->load->view('footer');
        }
        else
        {
            echo "  table roles is empty ";
        }
        
    }


    //update or delete user
    public function edit_delete_user()
    {
        //  // $_SERVER['HTTP_REFERER'] avoid direct access...
        //     if(!isset($_SERVER['HTTP_REFERER']))
        //     return redirect('index.php/Userc/login');

        //  // get role details
        //  $get_data['user_data']=$this->user_model->getuser_name('');
        
         // get role details
         $get_data['role_data']=$this->user_model->get_roleDetails();

         //type
         $get_data['type']='update_delete';
 
         if(!empty($get_data))
         {
             $this->load->view('header');
             $this->load->view('sidebar');
             $this->load->view('create_user',$get_data);
             $this->load->view('footer');
         }
         else
         {
             echo "  table roles is empty ";
         }
    }

    //get all user_names
    public function getUserDetails()
    {
        if(!empty($this->user_model->getUserDetails("")))
        {
           $users=$this->user_model->getUserDetails("");

            echo json_encode($users);//pass rolenames to view[create_role]
        }
        else
        {
            echo json_encode(110);//fail to fetch role names
        }
    }

    // delete user
    public function deleteRecord()
    {
        // echo json_encode($this->input->post('user_id'));
        if(!empty($this->input->post('user_id')))
        {
            $user_id=$this->input->post('user_id');
            $result=$this->user_model->delete_Details($user_id);

            if($result)
            {
                echo json_encode(201);//succcessfully deleted

            }
            else
            {
                echo json_encode(110);//failed to delete record
            }
        }
    }



     // get user_details based on user_id
     public function getData_id()
     {
         $user_id=$this->input->post('user_id');
         $result=$this->user_model->getUserDetails($user_id);
         
         if(!empty($result))
         {
             echo json_encode($result);
         }
         else
         {
             echo json_encode(110);//if failed
         }
     }

    // validate user data
    public function validateData()
    {
        // common validation  for userdata
            if($this->input->post("Type")=="create" || $this->input->post("Type")=="update_delete")
            {
                $this->form_validation->set_rules('name', 'Name', 'trim|required|alpha_numeric_spaces|min_length[2]|max_length[50]|callback_name_check');
                $this->form_validation->set_rules('role', 'role','required');
                $this->form_validation->set_rules('password', 'Password', 'min_length[8]|callback_password_check');
                $this->form_validation->set_rules('Cpassword', 'Confirm Password', 'required|matches[password]',array('matches'=>'mismatch password'));
            }

        
        // validation if Type[create]
            if($this->input->post("Type")=="create")
            {
                $this->form_validation->set_rules('email_id', 'Email address', 'required|valid_email|is_unique[tbl_users.email]',array('is_unique'=>'The %s already exist'));
                $this->form_validation->set_rules('contact', 'Contact number', 'callback_contact_check|is_unique[tbl_users.contact_no]',array('is_unique'=>'The %s already exist'));
            }


        //validation if Type[update_delete]
            if($this->input->post("Type")=="update_delete")
            {
                $user_id=$this->input->post('user_id');
                $result=$this->user_model->getUserDetails($user_id);
                if(!empty($result))
                {
                    foreach ($result as $row) 
                    {
                        // in operation[update] if email_id has changed
                            if($row->email !=($this->input->post('email_id')))
                            {
                                $this->form_validation->set_rules('email_id', 'Email address', 'required|valid_email|is_unique[tbl_users.email]',array('is_unique'=>'The %s already exist'));
                            }

                        // in operation[update] if contact_no has changed
                            if($row->contact_no !=($this->input->post('contact')))
                            {
                                $this->form_validation->set_rules('contact', 'Contact number', 'callback_contact_check|is_unique[tbl_users.contact_no]',array('is_unique'=>'The %s already exist'));
                            }
                    }
                }
               
            }

        // check validation is correct?
        if ($this->form_validation->run()) 
        {

            // common user_data
                $user_data=array(
                    'validation'=>true,
                    'user_name'=>$this->input->post('name'),
                    'password'=>base64_encode($this->input->post('password')),
                    'contact_no'=>$this->input->post('contact'),
                    'role_id'=>$this->input->post('role'),
                    'email'=>$this->input->post('email_id'),
                    'Type'=>$this->input->post('Type')

                );

                echo json_encode($user_data);

           
            
        }

        else
        {
            // display validationerror message within same page    
                $errors=array(
                    'error'=>true,
                    'name_error'=>form_error('name'),
                    'email_error'=>form_error('email_id'),
                    'contact_error'=>form_error('contact'),
                    'role_error'=>form_error('role'),
                    'password_error'=>form_error('password'),
                    'cpassword_error'=>form_error('Cpassword')
                );
                echo json_encode($errors);
            
        }

    
        
    }

    // name validation
    public function name_check($str)
    {
        

        // check name should not contain more than one white space consecutively
            if(preg_match('/([\s]{2})/',$str))
            {
                $this->form_validation->set_message('name_check','The Name field should not contain more than one white space consecutively');
                return FALSE;
            }

        // check name only contain alphabetic letters
            else if(preg_match('/([0-9])/',$str))
            {
                $this->form_validation->set_message('name_check','The Name field only contain alphabetic letters');
                return FALSE;
            }

        // check name should not contain more than two letters consecutively
            else if(preg_match('/([a-zA-Z])\1{2,}/',str_replace(' ','',$str)))
            {
                $this->form_validation->set_message('name_check','The Name field should not contain more than two repeated letters consecutively ');
                return FALSE;
            }
        
        // if success
            else
            {
                return TRUE;
            }
    }

     // contact number validation 
     public function contact_check($str)
     {
         if(strlen($str)<5)
         {
             
             $this->form_validation->set_message('contact_check',' The Contact number field is required');
             return FALSE;
         }

         else
         {
             return TRUE;
         }
     }
    
     // password validation
     public function password_check($str)
     {
         //  check password empty?
             if(trim($str)=="")
             {
                 $this->form_validation->set_message('password_check','The Password field is required ');
                 return FALSE;
             }
         

         // check password contain atleast one numeric character    
              else if(!preg_match("/[0-9]+/",$str))
             {
                 $this->form_validation->set_message('password_check','The Password must include atleast one numeric character');
                 return FALSE;
             }

         // check password contain atleast one alphabetic letter
             else if(!preg_match("/[a-z]+/",$str))
             {
                 $this->form_validation->set_message('password_check','The Password must include atleast one Alphabetic letter');
                 return FALSE;
             }

         // check password contain atleast one capital letter
             else if(!preg_match("/[A-Z]+/",$str))
             {
                 $this->form_validation->set_message('password_check','The Password must include atleast one capital letter');
                 return FALSE;
             }

         // check password contain atleast one special character
             else if(!preg_match('/[\W]+/',$str))
             {
                 $this->form_validation->set_message('password_check','The Password atleast  contain one special character');
                 return FALSE;
             }

         // check password should not contain any white space
         else if(preg_match('/[\s]/',$str))
         {
             $this->form_validation->set_message('password_check','The Password should not contain white space');
             return FALSE;
         }

         //  if success
         else
         {
             return TRUE;
         }
     }


    //  store user details
     public function storeDetails()
     {
             // common user_data
             $user_data=array(
                'user_name'=>$this->input->post('name'),
                'password'=>base64_encode($this->input->post('password')),
                'contact_no'=>$this->input->post('contact'),
                'role_id'=>$this->input->post('role'),
                'email'=>$this->input->post('email_id')
            );


         // if type[create]
         if($this->input->post('Type')=='create')
         {
             $response=$this->user_model->storeData($user_data);
             if($response==TRUE)
             {
                 //submitted successfully
                 $result=array(
                     'success'=>true,
                     'response'=>201
                 );
             }
             else
             {
                 //failed to submit form
                 $result=array(
                     'success'=>true,
                     'response'=>110
                 );
             }
             echo json_encode($result);
         
         }

          // if type[update_delete]
          if($this->input->post('Type')=='update_delete')
          {
             $user_id=$this->input->post('user_id');
              $response=$this->user_model->update_Details($user_data,$user_id);
              
              if($response==TRUE)
              {
                  //updated successfully
                  $result=array(
                      'success'=>true,
                      'response'=>201
                  );
              }
              else
              {
                  //failed to update record
                  $result=array(
                      'success'=>true,
                      'response'=>110
                  );
              }
              echo json_encode($result);
          }
          
     }

   
}


?>