<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<div class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark">Contact Us</h1>
				</div><!-- /.col -->
				<div class="col-sm-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item"><a href="#">Home</a></li>
						<li class="breadcrumb-item active">Contact Us</li>
					</ol>
				</div><!-- /.col -->
			</div><!-- /.row -->
		</div><!-- /.container-fluid -->
	</div>
	<!-- /.content-header -->

	<!-- Main content -->
	<section class="content">
		<div class="container-fluid">
			<div class="card">
				<div class="card-header">
					<h3 class="card-title">Search by</h3>
					<div class="card-tools">
						<button type="button" class="btn btn-tool" data-card-widget="collapse">
							<i class="fas fa-minus"></i>
						</button>
					</div>
				</div>
				<div class="card-body">
					<div class="row">								
						<div class="col-md-6">
							<div class="form-group">
								<label>Contacted period:</label>
								<div class="input-group">
									<div class="input-group-prepend">
										<span class="input-group-text"><i class="far fa-clock"></i></span>
									</div>
									<input type="text" class="form-control form-control-sm float-right" id="registered_dt">
								</div>
								<!-- /.input group -->
							</div>
						</div>
					</div>
				</div>
				<div class="card-footer">
					<div class="col-lg-6 col-6">
						<button type="button" class="btn btn-primary" id="btn_search" name="btn_search" onclick="onSearchClick()">Search</button>

					<!-- reset button -->
						<button type="button" class="btn btn-primary ml-1" id="btn_reset" name="btn_reset" onclick="reset_form()">Reset</button>
					</div>					
				</div>
			</div>
			<!-- <div class="row">

			</div> -->

			<div class="row">
				<section class="col-lg-12 connectedSortable">
					<!-- Custom tabs (Charts with tabs)-->
					<div class="card">
						<div class="card-header">
							<h3 class="card-title">
								<!-- <i class="nav-icon fa fa-bell"></i> -->
								Contacted List
							</h3>
							<div class="card-tools">
								<button type="button" class="btn btn-tool" data-card-widget="collapse">
									<i class="fas fa-minus"></i>
								</button>
								<!--
						  <button type="button" class="btn btn-tool" data-card-widget="remove">
							<i class="fas fa-times"></i>
						  </button>
						  -->
							</div>
						</div><!-- /.card-header -->
						<div class="card-body">
							<table id="contact_us_details" class="table-md table-striped table-bordered" style="cursor:pointer">
							</table>
						</div><!-- /.card-body -->
						<div id="loader" class="overlay" style="display: none;">
							<i class="fas fa-3x fa-sync-alt fa-spin"></i>
							<div class="text-bold pt-2">Loading please wait ...</div>
							<br><br>
						</div>
					</div>
					<!-- /.card -->
				</section>
			</div>
		</div><!-- /.container-fluid -->
	</section>
	<!-- /.content -->
</div>
<!-- /.content-wrapper -->

<!-- jQuery -->
<script src="<?php echo base_url(); ?>plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url(); ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- overlayScrollbars -->
<script src="<?php echo base_url(); ?>plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url(); ?>dist/js/adminlte.js"></script>
<!-- InputMask -->
<script src="<?php echo base_url(); ?>plugins/moment/moment.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>
<!-- date-range-picker -->
<script src="<?php echo base_url(); ?>plugins/daterangepicker/daterangepicker.js"></script>

<!-- DataTables -->
<script src="<?php echo base_url(); ?>plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>

<script type="text/javascript">
	var oTable;

	//Date range picker with time picker
	$('#registered_dt').daterangepicker({
		timePicker: true,
		timePickerIncrement: 1,
		locale: {
			format: 'DD/MM/YYYY hh:mm A'
		}
	})

	function toTimestamp(strDate) {
		var datum = Date.parse(strDate);
		return datum / 1000;
	}

	function onSearchClick() {

		var fromDateTime = $('#registered_dt').data('daterangepicker').startDate.format('YYYY-MM-DD hh:mm A');
		var toDateTime = $('#registered_dt').data('daterangepicker').endDate.format('YYYY-MM-DD hh:mm A');

		if (oTable != null && oTable != "undefined") {
			$('#contact_us_details').dataTable().fnClearTable();
		}

		var fromDateTimeUnixValue = 0;
		var toDateTimeUnixValue = 0;

		if (fromDateTime) {
			fromDateTimeUnixValue = toTimestamp(fromDateTime);
		} else {
			alert("Please select from date first.");
			return;
		}

		if (toDateTime) {
			toDateTimeUnixValue = toTimestamp(toDateTime);
		} else {
			alert("Please select to date first.");
			return;
		}	

		var loader = document.getElementById("loader");
		loader.style.display = "block";

		$.ajax({
			type: "GET",
			url: "<?php echo base_url(); ?>index.php/Contact_us_controller/get_data",
			data: {
				"from_timestamp": fromDateTime,
				"to_timestamp": toDateTime
			}
		}).done(function(data) {
			if (data != 110) {
				var json_obj = jQuery.parseJSON(data);
				if (json_obj.length > 0) {
					var mGridData = [];
					for (var row = 0; row < json_obj.length; row++) {
						var id = json_obj[row].id;
						var f_name = json_obj[row].f_name;
						var contact_no = json_obj[row].contact_no;
						var f_email = json_obj[row].f_email;
						var subject = json_obj[row].subject;
						var message = json_obj[row].message;
						var contacted_on = json_obj[row].contacted_on;

						mGridData.push([(row + 1), id, f_name, contact_no, f_email, subject, message, contacted_on]);
					}

					if (oTable == null || oTable == "undefined") {
						oTable = $('#contact_us_details').dataTable({

							"sScrollX": "100%",
							"sScrollXInner": "110%",

							"initComplete": function() {
								$("#contact_us_details").on("click", "tr[role='row']", function() {
									//$("#contact_us_details tbody tr").removeClass('row_selected');
									//$(this).addClass('row_selected');

									////var index = $(this).index();
									//var selected_razorpay_order_id = $(this).children('td:last-child').text();
									//window.location.href = "<?php echo base_url(); ?>index.php/Payment?razorpay_order_id=" + selected_razorpay_order_id + "";
								});
							},
							"aoColumns": [{
										"sTitle": "Sl No"
									},
									{
										"sTitle": "ID",
										"visible": false
									},
									{
										"sTitle": "Full Name"
									},
									{
										"sTitle": "Contact No"
									},
									{
										"sTitle": "Email ID"
									},
									{
										"sTitle": "Subject"
									},
									{
										"sTitle": "Message"
									},
									{
										"sTitle": "Contacted On"
									}
							]
						});
					}

					$('#contact_us_details').dataTable().fnAddData(mGridData);
				} else {
					alert("No records found.");
				}
			} else {
				alert("No records found.");
			}

			loader.style.display = "none";
		});
	}

	//reset input fields onclick
		function reset_form()
		{
			console.log("reset button clicked.");
			$('#registered_dt').val('');
			// $('#installationForm')[0].reset();

		}

	$(document).ready(function() {
	});
</script>