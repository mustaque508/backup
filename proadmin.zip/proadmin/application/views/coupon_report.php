<!-- <?php

		foreach ($offers as $value) {
			echo $value->OfferName;
		}
		print_r($offers);
		?>

<?php

 //var_dump($offers);

?> -->

<div class="content-wrapper">

	<div class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark">Coupon Reports</h1>
				</div><!-- /.col -->
				<div class="col-sm-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item"><a href="#">Home</a></li>
						<li class="breadcrumb-item active">Coupon Reports</li>
					</ol>
				</div>
			</div>
		</div>
	</div>

	<section class="content">
		<div class="container-fluid">
			<div class=row>
				<div class="col-md-12">
					<div class="card">
						<div class="card-header">
							<h3 class="card-title"><strong>Search</strong></h3>
							<div class="card-tools">
								<button type="button" class="btn btn-tool" data-card-widget="collapse">
									<i class="fas fa-minus"></i>
								</button>
							</div>
						</div>
						<div class="card-body ">
							<div class="row">
								<div class="col-sm-6">
									<div class="form-group">
										<label>Coupon Code:</label>
										<div class="input-group ">
											<input type="text" class="form-control form-control-sm " id="Coupon_code" name="Coupon_code" />
										</div>
									</div>
								</div>
								<div class="col-sm-6">
									<div class="form-group">
										<label>Vendor :</label>
										<select class="form-control form-control-sm float-right" id="vendor" name="vendor">
											<option value="0">Select option</option>
											<?php
											// foreach ($vendors->result_array() as $row)
											// {
											//     echo "<option value='".$row['Vendor_Name']."'>".$row['Vendor_Name'] ."</option>";	
											// }

											foreach ($vendors as  $value) {
												echo "<option value='" . $value->Vendor_ID . "'>" . $value->Vendor_Name . "</option>";
											}
											?>
										</select>
									</div>
								</div>
							</div>

							<div class="row">
								
								<!-- from date and time -->
								<div class="col-sm-6">
										<div class="form-group">
											<label>From date and time:</label>
												<div class="input-group">
													<div class="input-group-prepend">
														<span class="input-group-text"><i class="far fa-clock"></i></span>
													</div>
													<input type="text" class="form-control form-control-sm float-right" id="from_timestamp">
												</div>
										</div>
								</div>


								<!-- select offer -->
								<div class="col-sm-6">
									<div class="form-group">
										<label>Offer Name :</label>
										<select class="form-control form-control-sm float-right" id="offer" name="offer">
											<option value="">Select option</option>
											<?php
											// foreach ($vendors->result_array() as $row)
											// {
											//     echo "<option value='".$row['Vendor_Name']."'>".$row['Vendor_Name'] ."</option>";	
											// }

											foreach ($offers as  $value) {

												echo "<option>" . $value->OfferName . "</option>";
											}
											?>
										</select>
									</div>
								</div>
							</div>
						</div>
						<div class="card-footer">
							<div class="row">
								<div class="col-sm-6">
									<button type="button" class="btn btn-primary" id="btn_search" name="btn_search" onclick="onSearchClick()">Search</button>
									<!-- reset button -->
									<button type="button" class="btn btn-primary ml-1" id="btn_reset" name="btn_reset" onclick="reset_form()">Reset</button>

									<input class="ml-3" type="checkbox" id="checkbox" name="checkbox" >
									<label for="checkbox">
										show only used coupon codes
									</label>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<!-- result -->
			<div class="row">
				<section class="col-lg-12 connectedSortable">
					<!-- Custom tabs (Charts with tabs)-->
					<div class="card">
						<div class="card-header">
							<h3 class="card-title">
								<!-- <i class="nav-icon fa fa-bell"></i> -->
								Result
							</h3>
							<div class="card-tools">
								<button type="button" class="btn btn-tool" data-card-widget="collapse">
									<i class="fas fa-minus"></i>
								</button>
								<!--
						  <button type="button" class="btn btn-tool" data-card-widget="remove">
							<i class="fas fa-times"></i>
						  </button>
						  -->
							</div>
						</div><!-- /.card-header -->
						<div class="card-body">
							<table id="report" class="table-sm table-striped table-bordered table-hover dataTable dtr-inline" role="grid" style="cursor:pointer">
							</table>
						</div><!-- /.card-body -->
						<div id="loader" class="overlay" style="display: none;">
							<i class="fas fa-3x fa-sync-alt fa-spin"></i>
							<div class="text-bold pt-2">Loading please wait ...</div>
							<br><br>
						</div>
					</div>
					<!-- /.card -->
				</section>
			</div>

			<!-- Modal -->
			<div class="modal fade" id="myModal" role="dialog">
				<div class="modal-dialog">

					<!-- Modal content-->
					<div class="modal-content">
						<div class="modal-header">
							<!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->
							<h4 class="modal-title">Top Record</h4>
						</div>
						<div class="modal-body">

						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
						</div>
					</div>

				</div>
			</div>



	</section>
</div>

<!-- jQuery -->
<script src="<?php echo base_url(); ?>plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url(); ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- overlayScrollbars -->
<script src="<?php echo base_url(); ?>plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url(); ?>dist/js/adminlte.js"></script>
<!-- InputMask -->
<script src="<?php echo base_url(); ?>plugins/moment/moment.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>
<!-- date-range-picker -->
<script src="<?php echo base_url(); ?>plugins/daterangepicker/daterangepicker.js"></script>

<!-- DataTables -->
<script src="<?php echo base_url(); ?>plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>


<script type="text/javascript">
	var oReport;
	var used;

	$(document).ready(function() {
		console.log("document loaded");
		$('#from_timestamp').val('');
	
	});

	//Date range picker with time picker
	$('#from_timestamp').daterangepicker(
	{
			timePicker: true,
			timePickerIncrement: 1,
			locale: {
				format: 'DD/MM/YYYY hh:mm A'
			}
	});

	function onSearchClick() {
		if (oReport != null && oReport != "undefined") {
			$('#report').dataTable().fnClearTable();
		}

		var vendorid = document.getElementById("vendor").value;
		// console.log(vendorid);

		var offername= document.getElementById("offer").value;
		// console.log(offername);

		var fromDateTime = $('#from_timestamp').data('daterangepicker').startDate.format('YYYY-MM-DD hh:mm A');
		var toDateTime = $('#from_timestamp').data('daterangepicker').endDate.format('YYYY-MM-DD hh:mm A');

		// check date input field is empty
		if($('#from_timestamp').val()==''){
			fromDateTime='';
			toDateTime='';
		}

		// console.log(fromDateTime);
		// console.log(toDateTime);
		var ischecked = document.getElementById("checkbox").checked;
		// console.log(ischecked);
		var couponecode = document.getElementById("Coupon_code").value;
		var vendor_id = vendorid; //document.getElementById("vendor_id").value;
		var isused = ischecked;//document.getElementById("checkbox").value;

		// console.log(isused);

		var loader = document.getElementById("loader");
		loader.style.display = "block";

		$.ajax({
			type: "GET",
			url: "<?php echo base_url(); ?>index.php/coupon_controller/get_data",
			data: {
				"couponcode": couponecode,
				"vendor_id": vendor_id,
				"isused": isused,
				"fromDateTime": fromDateTime,
				"toDateTime":toDateTime,
				"offername":offername

			}
		}).done(function(data) {
			
			if (data != 110) {
				var json_obj = jQuery.parseJSON(data);
				if (json_obj.length > 0) {
					var mGridData = [];
					for (var row = 0; row < json_obj.length; row++) {

						var CouponCode = json_obj[row].CouponCode;

						var VendorID_CustomerID = json_obj[row].VendorID_CustomerID;
						var Vendor_Name = json_obj[row].Vendor_Name;

						var CouponValue = json_obj[row].CouponValue;
						

						var Product_Name = json_obj[row].Product_Name;
						var Edition = json_obj[row].Edition;
						var IsUsed = json_obj[row].IsUsed;
						
						// new added
						var CouponOfferprice = json_obj[row].CouponOfferPrice;
						var OfferName =json_obj[row].OfferName;
						var SerialKey =json_obj[row].SerialKey;
						var CouponUsedDate=json_obj[row].CouponUsedDate;

						mGridData.push([(row + 1), CouponCode, VendorID_CustomerID, Vendor_Name, CouponValue, CouponOfferprice, Product_Name, Edition,
							IsUsed,OfferName,SerialKey,CouponUsedDate
						]);
					}


					if (oReport == null || oReport == "undefined") {
						oReport = $('#report').dataTable({

							"sScrollX": "100%",
							"sScrollXInner": "110%",

							"initComplete": function() {
								$("#report").on("click", "tr[role='row']", function() {
									//$("#report tbody tr").removeClass('row_selected');        
									//$(this).addClass('row_selected');

									////var index = $(this).index();
									//var selected_razorpay_order_id = $(this).children('td:last-child').text();
									//window.location.href = "<?php echo base_url(); ?>index.php/Payment?razorpay_order_id=" + selected_razorpay_order_id + "";
								});
							},
							"aoColumns": [{
									"sTitle": "Sl No"
								},
								{
									"sTitle": "CouponCode",
									"sWidth": "20%"
								},
								{
									"sTitle": "VendorID_CustomerID",
									"sWidth": "10%"
								},
								{
									"sTitle": "Vendor_Name"
								},
								{
									"sTitle": "CouponValue"
								},
								{
									"sTitle": "CouponOfferprice"
								},
								{
									"sTitle": "Product_Name"
								},
								{
									"sTitle": "Edition"
								},
								{
									"sTitle": "IsUsed"
								},
								{
									"sTitle": "OfferName"
								},
								{
									"sTitle": "SerialKey"
								},
								{
									"sTitle": "CouponUsedDate"
								}
							]
						});
					}

					$('#report').dataTable().fnAddData(mGridData);
				} else {
					alert("No records found.");
				}
			} else {
				alert("No records found.");
			}

			loader.style.display = "none";
		});
	}

	function loadModal(mGridData) {
		var response = "<table border='1' width='100%'>";

		// response += "<tr><td>ID : </td><td>" + mGridData[0][1] + "</td></tr>";
		response += "<tr><td>CouponCode : </td><td>" + mGridData[0][1] + "</td></tr>";
		response += "<tr><td>VendorID_CustomerID : </td><td>" + mGridData[0][2] + "</td></tr>";
		response += "<tr><td>Vendor_Name : </td><td>" + mGridData[0][3] + "</td></tr>";
		response += "<tr><td>CouponValue : </td><td>" + mGridData[0][4] + "</td></tr>";
		response += "<tr><td>CouponOfferprice : </td><td>" + mGridData[0][5] + "</td></tr>";
		// response += "<tr><td>SubscriptionName : </td><td>" + mGridData[0][7] + "</td></tr>";
		response += "<tr><td>Product_Name : </td><td>" + mGridData[0][6] + "</td></tr>";
		response += "<tr><td>Edition : </td><td>" + mGridData[0][7] + "</td></tr>";
		response += "<tr><td>IsUsed : </td><td>" + mGridData[0][8] + "</td></tr>";
		response += "<tr><td>OfferName : </td><td>" + mGridData[0][9] + "</td></tr>";
		response += "<tr><td>SerialKey : </td><td>" + mGridData[0][10] + "</td></tr>";
		response += "<tr><td>CouponUsedDate : </td><td>" + mGridData[0][11] + "</td></tr>";

		/*
		response += "<tr><td>InstalledKeyID : </td><td>"+ mGridData[0][14] +"</td></tr>"; 
		response += "<tr><td>ServerSerialKey : </td><td>"+ mGridData[0][15] +"</td></tr>"; 
		response += "<tr><td>ClientUserID : </td><td>"+ mGridData[0][16] +"</td></tr>"; 
		response += "<tr><td>PCName : </td><td>"+ mGridData[0][17] +"</td></tr>"; 
		response += "<tr><td>MACAddress : </td><td>"+ mGridData[0][18] +"</td></tr>"; 
		response += "<tr><td>HDDAddress : </td><td>"+ mGridData[0][19] +"</td></tr>"; 
		response += "<tr><td>IPAddress : </td><td>"+ mGridData[0][20] +"</td></tr>"; 
		response += "<tr><td>Latitude : </td><td>"+ mGridData[0][21] +"</td></tr>"; 
		response += "<tr><td>Longitude : </td><td>"+ mGridData[0][22] +"</td></tr>"; 
		response += "<tr><td>Address : </td><td>"+ mGridData[0][23] +"</td></tr>"; 
		response += "<tr><td>IsBlocked : </td><td>"+ mGridData[0][24] +"</td></tr>"; 
		response += "<tr><td>ClientID : </td><td>"+ mGridData[0][25] +"</td></tr>"; 
		response += "<tr><td>SubscriptionDate : </td><td>"+ mGridData[0][26] +"</td></tr>"; 
		response += "<tr><td>SubscriptionType : </td><td>"+ mGridData[0][27] +"</td></tr>"; 
		response += "<tr><td>HasUnInstalled : </td><td>"+ mGridData[0][28] +"</td></tr>"; 
		response += "<tr><td>UnInstalledDate : </td><td>"+ mGridData[0][29] +"</td></tr>"; 
		response += "<tr><td>UnInstalledBy : </td><td>"+ mGridData[0][30] +"</td></tr>"; 
		*/

		response += "</table>";

		$('.modal-body').html(response);

		// Display Modal
		$('#myModal').modal('show');
	}

	//form reset
	function reset_form() 
	{
		$('#Coupon_code').val('');
		$('#vendor').val('0');
		$('#offer').val('');
		$('#from_timestamp').val('');
		$('#checkbox').prop('checked',false);

		// clear result grid
		if (oReport != null && oReport != "undefined")
		 {
			$('#report').dataTable().fnClearTable();
		 }

		console.log("reset button clicked...");

	}
</script>