	
	<?php
	
		$from_timestamp = $_POST["from_timestamp"];
		$to_timestamp = $_POST["to_timestamp"];
		$top_records = $_POST["top_records"];

		use Razorpay\Api\Api;

		require_once("razorpay-php/config.php");
		require_once("razorpay-php/Razorpay.php");		

		$api = new Api($keyId, $keySecret);
		
		//echo "FROM : " . $from_timestamp . "<br><br>";
		//echo "To : " . $to_timestamp . "<br><br>";

		$params = array(
			'count' => $top_records,
			'skip'  => 0,
			'from'  => $from_timestamp,
			'to'  => $to_timestamp
		);

		//$payments = $api->Order->all($params);		
		$payments = $api->payment->all($params);
		
		//echo $payments->entity . "<br><br>";
		//echo count($payments->items) . "<br><br>";
		//print_r ($payments->items[0]) . "<br><br>";
		//print_r($payments->items[0]["id"]); // ["id"]
		
		//$resp = '{"attributes":{"entity":"collection","count":10,"items":[{},{},{},{},{},{},{},{},{},{}]}}';
		
		//echo "<br><br><br>";
		
		//var_dump($payments);
		
		//$vars = get_object_vars ($payments->items);
		//echo count($vars);
		
		//$array = (array) $payments->items[0];
		//echo json_encode($array);

		$m_array = array();
		$t_count = $payments->count;
		
		//echo "<br><br>" . $payments->items[0]["id"];
		//echo $t_count;
		
		for ($x = 0; $x < $t_count; $x++) {
			$m_array[] = array(
				'id' => $payments->items[$x]['id'],
				'entity' => $payments->items[$x]['entity'],
				'amount' => $payments->items[$x]['amount'],
				'currency' => $payments->items[$x]['currency'],
				'status' => $payments->items[$x]['status'],
				'order_id' =>$payments->items[$x]['order_id'],
				'invoice_id' => $payments->items[$x]['invoice_id'],
				'international' => $payments->items[$x]['international'],
				'method' => $payments->items[$x]['method'],
				'amount_refunded' => $payments->items[$x]['amount_refunded'],
				'refund_status' => $payments->items[$x]['refund_status'],
				'captured' => $payments->items[$x]['captured'],
				'description' => $payments->items[$x]['description'],
				'card_id' => $payments->items[$x]['card_id'],
				'bank' => $payments->items[$x]['bank'],
				'wallet' => $payments->items[$x]['wallet'],
				'vpa' => $payments->items[$x]['vpa'],
				'email' => $payments->items[$x]['email'],
				'contact' => $payments->items[$x]['contact'],
				'notes' => $payments->items[$x]['notes'],
				'fee' => $payments->items[$x]['fee'],
				'tax' => $payments->items[$x]['tax'],
				'error_code' => $payments->items[$x]['error_code'],
				'error_description' => $payments->items[$x]['error_description'],
				'created_at' => gmdate("Y-m-d H:i:s", $payments->items[$x]['created_at']),
			);
		}
		
		echo json_encode($m_array);
	?>