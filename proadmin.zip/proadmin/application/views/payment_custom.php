<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper bg-light">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">RazorPay</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">RazorPay</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
		  	<div class="card">
			  	<div class="card-header">
					<h3 class="card-title">Search by</h3>
					<div class="card-tools">
						<button type="button" class="btn btn-tool" data-card-widget="collapse">
							<i class="fas fa-minus"></i>
						</button>
					</div>
				</div>

				<div class="card-body">
					<div class="row">
						<div class="col-md-3">
							<div class="form-group">
								<label>Mobile Number</label>
								<div class="input-group">
									<input type="text" class="form-control form-control-sm" id="mobile_no" name="mobile_no" />
								</div>
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<label>Email ID</label>
								<div class="input-group">
									<input type="text" class="form-control form-control-sm" id="email_id" name="email_id" />
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label>Search by Mobile Number OR Email ID</label>
								<div class="input-group">
									<button type="button" class="btn btn-primary form-control-sm" id="btn_search" name="btn_search" onclick="onSearchClick()">Search</button>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<!-- search by period -->
						<div class="col-md-6">
							<div class="form-group">
								<label>Search by Period:</label>
								<div class="input-group input-group-sm">
									<div class="input-group-prepend">
										<span class="input-group-text"><i class="far fa-clock"></i></span>
									</div>
									<input type="text" class="form-control float-right" id="registered_dt">
									<span class="input-group-append">
										<button type="button" class="btn btn-primary "  
											id="btn_search_with_period" 
											name="btn_search_with_period" onclick="onClickSearchWithPeriod()">
											Go
										</button>	
									</span>
								</div>						
							</div>
						</div>	

						<!-- search by order id -->
						<div class="col-md-3">
							<div class="form-group">
								<label>Search by RazorPay Order ID:</label>
								<div class="input-group input-group-sm">	
										<div class="input-group-prepend">
											<span class="input-group-text"><i class="far fa-id-card"></i></span>
										</div>					
									<input type="text" class="form-control" id="razorpay_order_id" name="razorpay_order_id"/>
									<span class="input-group-append">
										<button type="button" class="btn btn-primary" 
											id="btn_search_with_order_id" 
											name="btn_search_with_order_id" onclick="onClickSearchWithOrderID()">
											Go
										</button>	
									</span>						
								</div>
							</div>
						</div>

						<!-- search by payment_id -->
						<div class="col-md-3">
							<div class="form-group">
								<label>Search by RazorPay Payment ID:</label>
								<div class="input-group input-group-sm">	
										<div class="input-group-prepend">
											<span class="input-group-text"><i class="far fa-id-card"></i></span>
										</div>					
									<input type="text" class="form-control" id="razorpay_payment_id" name="razorpay_payment_id"/>
									<span class="input-group-append">
										<button type="button" class="btn btn-primary" 
											id="btn_search_with_order_id" 
											name="btn_search_with_order_id" onclick="onClickSearchWithPaymentID()">
											Go
										</button>	
									</span>						
								</div>
							</div>
						</div>

					</div>					
				</div>				
			</div>
				
			<!-- user info -->
			<div class="row">
				<section class="col-lg-12 connectedSortable">
					<!-- Custom tabs (Charts with tabs)-->
					<div class="card">
					  <div class="card-header">
						<h3 class="card-title">
						  <!-- <i class="nav-icon fa fa-bell"></i> -->
						  User Information
						</h3>
						<div class="card-tools">
						  <button type="button" class="btn btn-tool" data-card-widget="collapse">
							<i class="fas fa-minus"></i>
						  </button>               
						  <!--
						  <button type="button" class="btn btn-tool" data-card-widget="remove">
							<i class="fas fa-times"></i>
						  </button>
						  -->
						</div>
					  </div><!-- /.card-header -->
					  <div class="card-body ">
						<table id="gridDataTableUserInfo" 
							class="table-sm table-striped table-bordered table-hover dataTable dtr-inline"
							role="grid" 
							style="cursor:pointer" >											
						</table>
					  </div><!-- /.card-body -->
						<div id="loaderUserInfo" class="overlay" style="display: none;">
							<i class="fas fa-3x fa-sync-alt fa-spin"></i>
							<div class="text-bold pt-2">Loading please wait ...</div>
							<br><br>
						</div>
					</div>
					<!-- /.card -->
				</section>			  
			</div>

			<!-- order list -->
			<div class="row">
				<section class="col-lg-12 connectedSortable">
					<!-- Custom tabs (Charts with tabs)-->
					<div class="card">
					  <div class="card-header">
						<h3 class="card-title">
						  <!-- <i class="nav-icon fa fa-bell"></i> -->
						  Orders List
						</h3>
						<div class="card-tools">
						  <button type="button" class="btn btn-tool" data-card-widget="collapse">
							<i class="fas fa-minus"></i>
						  </button>               
						  <!--
						  <button type="button" class="btn btn-tool" data-card-widget="remove">
							<i class="fas fa-times"></i>
						  </button>
						  -->
						</div>
					  </div><!-- /.card-header -->
					  <div class="card-body ">
						<table id="gridDataTableOrder" 
							class="table-sm table-striped table-bordered table-hover dataTable dtr-inline"
							role="grid" 
							style="cursor:pointer" >											
						</table>
					  </div><!-- /.card-body -->
						<div id="loaderOrder" class="overlay" style="display: none;">
							<i class="fas fa-3x fa-sync-alt fa-spin"></i>
							<div class="text-bold pt-2">Loading please wait ...</div>
							<br><br>
						</div>
					</div>
					<!-- /.card -->
				</section>			  
			</div>

			<!-- payment list -->
			<div class="row">
				<section class="col-lg-12 connectedSortable">
					<!-- Custom tabs (Charts with tabs)-->
					<div class="card">
					  <div class="card-header">
						<h3 class="card-title">
						  <!-- <i class="nav-icon fa fa-bell"></i> -->
						  Payments List
						</h3>
						<div class="card-tools">
						  <button type="button" class="btn btn-tool" data-card-widget="collapse">
							<i class="fas fa-minus"></i>
						  </button>               
						  <!--
						  <button type="button" class="btn btn-tool" data-card-widget="remove">
							<i class="fas fa-times"></i>
						  </button>
						  -->
						</div>
					  </div><!-- /.card-header -->
					  <div class="card-body">
						<table id="gridDataTablePayment" 
							class="table-sm table-striped table-bordered table-hover dataTable dtr-inline" 
							role="grid" 
							style="cursor:pointer">											
						</table>
					  </div><!-- /.card-body -->
						<div id="loaderPayment" class="overlay" style="display: none;">
							<i class="fas fa-3x fa-sync-alt fa-spin"></i>
							<div class="text-bold pt-2">Loading please wait ...</div>
							<br><br>
						</div>
					</div>
					<!-- /.card -->
				</section>			  
			</div>	
		</div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  
	<!-- jQuery -->
	<script src="<?php echo base_url(); ?>plugins/jquery/jquery.min.js"></script>	
	<!-- Bootstrap 4 -->
	<script src="<?php echo base_url(); ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>	
	<!-- overlayScrollbars -->
	<script src="<?php echo base_url(); ?>plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
	<!-- AdminLTE App -->
	<script src="<?php echo base_url(); ?>dist/js/adminlte.js"></script>
	<!-- InputMask -->
	<script src="<?php echo base_url(); ?>plugins/moment/moment.min.js"></script>
	<script src="<?php echo base_url(); ?>plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>
	<!-- date-range-picker -->
	<script src="<?php echo base_url(); ?>plugins/daterangepicker/daterangepicker.js"></script>	
	
	<!-- DataTables -->
	<script src="<?php echo base_url(); ?>plugins/datatables/jquery.dataTables.min.js"></script>
	<script src="<?php echo base_url(); ?>plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
	<script src="<?php echo base_url(); ?>plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
	<script src="<?php echo base_url(); ?>plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
		

	<script type="text/javascript">		
		var oTableUserInfo;
		var oTableOrder;
		var oTablePayment;
		var selected_razorpay_order_id = "";
			
		//Date range picker with time picker
		$('#registered_dt').daterangepicker({
		  timePicker: true,
		  timePickerIncrement: 1,
		  locale: {
			format: 'DD/MM/YYYY hh:mm A'
		  }
		})
		
		function toTimestamp(strDate){
			var datum = Date.parse(strDate);
			return datum/1000;
		}

		function onSearchClick(){
			clearAllTables();

			var mobile_no = document.getElementById("mobile_no").value;
			var email_id = document.getElementById("email_id").value;

			getDataUserInfo(mobile_no, email_id, 0, 0, "");
		}
			
		function onClickSearchWithPeriod() {
			var fromDateTime = $('#registered_dt').data('daterangepicker').startDate.format('YYYY-MM-DD hh:mm A');
			var toDateTime = $('#registered_dt').data('daterangepicker').endDate.format('YYYY-MM-DD hh:mm A');			
			
			var fromDateTimeUnixValue = 0;
			var toDateTimeUnixValue = 0;
			
			if(fromDateTime){
				fromDateTimeUnixValue = toTimestamp(fromDateTime);
			} else {
				alert("Please select from date first.");
				return;
			}
			
			if(toDateTime){
				toDateTimeUnixValue = toTimestamp(toDateTime);
			} else {
				alert("Please select to date first.");
				return;
			}
			
			getDataUserInfo("", "", fromDateTime, toDateTime, "");
			getDataOrder(fromDateTimeUnixValue, toDateTimeUnixValue, "");
			getDataPayment(fromDateTimeUnixValue, toDateTimeUnixValue, "");
		}
		
		function onClickSearchWithOrderID() {
			var entered_order_id = document.getElementById("razorpay_order_id").value;
			selected_razorpay_order_id = entered_order_id;
						
			getDataUserInfo("", "", 0, 0, entered_order_id);
			getDataOrder(0, 0, entered_order_id);
			getDataPayment(0, 0, entered_order_id);			
		}

		function onClickSearchWithPaymentID()
		{
			var payment_id = document.getElementById("razorpay_payment_id").value;
			getDataUserInfo("", "", 0, 0,"", payment_id);
			getDataOrder(0, 0, "",payment_id);
			getDataPayment(0, 0, "", payment_id);	

		}
		
		

		function getDataUserInfo(mobile_no, email_id, fromDateTime, toDateTime, sOrderID = "",payment_id=""){
			if (oTableUserInfo != null && oTableUserInfo != "undefined"){
				$('#gridDataTableUserInfo').dataTable().fnClearTable();
			}
			
			var loaderUserInfo = document.getElementById("loaderUserInfo");
			loaderUserInfo.style.display = "block";


			if(payment_id != "")
			{
				$.ajax({
					type:"GET",
					url:"<?php echo base_url();?>index.php/Payment/get_order_id",
					data:{
						'payment_id':payment_id
					},
					success:function(response){
						if(response!=110){
							getUserDetails(mobile_no,email_id,fromDateTime,toDateTime,JSON.parse(response));		
						}
					}
				});
				
			}
			else
			{
				getUserDetails(mobile_no,email_id,fromDateTime,toDateTime,sOrderID);
			}
		
			

			
		}
		

		// get user_details
		function getUserDetails(mobile_no,email_id,fromDateTime,toDateTime,sOrderID)
		{
			console.log(sOrderID);
			$.ajax({ 
			   type: "GET", 			   
			   url: "<?php echo base_url(); ?>index.php/Download_controller/get_downloads_by_cust_info",
			   data: { "mobile_no" : mobile_no, "email_id" : email_id, "from_timestamp" : fromDateTime, "to_timestamp" : toDateTime, "order_id" : sOrderID }
			}).done(function( data ) {
				if (data != 110){
					var json_obj = jQuery.parseJSON(data);
					if (json_obj.length > 0){							
						var mGridData = [];	
						
						for(var row = 0; row < json_obj.length; row++){						
							var id = json_obj[row].id;
							var full_name = json_obj[row].full_name;
							var contact_no = json_obj[row].contact_no;
							var dept_email_id = json_obj[row].dept_email_id;
							var department = json_obj[row].department;
							var designation = json_obj[row].designation;
							var address = json_obj[row].address;
							var created_dt = json_obj[row].created_dt;
							var serial_key = json_obj[row].serial_key;
							var installed_dt = json_obj[row].installed_dt;
							var status = json_obj[row].status;
							var razorpay_order_id = json_obj[row].razorpay_order_id;

							mGridData.push([(row + 1), id, full_name, contact_no, dept_email_id, department, designation, address, created_dt, serial_key, installed_dt, status, razorpay_order_id]);
						}

						if (oTableUserInfo == null || oTableUserInfo == "undefined"){
							oTableUserInfo = $('#gridDataTableUserInfo').dataTable( {
								oSearch: {
									//sSearch: selected_razorpay_order_id
								},
								"sScrollX": "100%",
								"sScrollXInner": "110%",
																	
								"initComplete": function () {
									$("#gridDataTableUserInfo").on("click", "tr[role='row']", function(){
										$("#gridDataTableUserInfo tbody tr").removeClass('row_selected');        
										$(this).addClass('row_selected');
						
										////var index = $(this).index();
										var sOrderID = $(this).children('td:nth-child(12)').text();
										
										if (sOrderID != ""){
											getDataOrder(0, 0, sOrderID);
											getDataPayment(0, 0, sOrderID);
										}else{
											alert("Invalid order id selected.");
										}
									});
								},
								"aoColumns": [{
										"sTitle": "Sl No"
									},
									{
										"sTitle": "ID",
										"visible": false
									},
									{
										"sTitle": "Full Name"
									},
									{
										"sTitle": "Contact No"
									},
									{
										"sTitle": "Dept Email ID"
									},
									{
										"sTitle": "Department"
									},
									{
										"sTitle": "Designation"
									},
									{
										"sTitle": "Address"
									},
									{
										"sTitle": "Created_dt"
									},
									{
										"sTitle": "Serial Key"
									},
									{
										"sTitle": "Installed DT"
									},
									{
										"sTitle": "Status"
									},
									{
										"sTitle": "RazorPay Order ID"
									}
								]
							} );
						}
													
						$('#gridDataTableUserInfo').dataTable().fnAddData(mGridData);
						//oTableUserInfo.oSearch( 'initial search value' ).draw();
						//$('#gridDataTableUserInfo').dataTable().columns(3).search("pay_fzf").draw();
					}else{
						//document.getElementById('last_alert_generated_dt').value = "No records found";
						//document.getElementById('no_of_violators').value = "No records found";
					}
				}else{
					alert("Either error occured or no order(s) found.");
				}
				
				loaderUserInfo.style.display = "none";				
			});
		}
		
		function getDataOrder(fromDateTime = 0, toDateTime = 0, sOrderID = "",payment_id=""){
			if (oTableOrder != null && oTableOrder != "undefined"){
				$('#gridDataTableOrder').dataTable().fnClearTable();
			}
			
			var loaderOrder = document.getElementById("loaderOrder");
			loaderOrder.style.display = "block";
			
			$.ajax({ 
			   type: "GET", 			   
			   url: "<?php echo base_url(); ?>index.php/Payment/get_orders",
			   data: { "from_timestamp" : fromDateTime, "to_timestamp" : toDateTime, "order_id" : sOrderID,"payment_id":payment_id  }
			}).done(function( data ) {
				if (data != 110){
					var json_obj = jQuery.parseJSON(data);
					if (json_obj.length > 0){							
						var mGridData = [];	
						for(var row = 0; row < json_obj.length; row++){						
							var id = json_obj[row].id;
							var entity = json_obj[row].entity;
							
							var amount = json_obj[row].amount;
							try {
								amount = parseFloat(amount) / 100;
							} catch (err) {
								console.log(err);
							}
							
							var amount_paid = json_obj[row].amount_paid;
							try {
								amount_paid = parseFloat(amount_paid) / 100;
							} catch (err) {
								console.log(err);
							}

							var amount_due = json_obj[row].amount_due;
							var currency = json_obj[row].currency;
							var receipt = json_obj[row].receipt;
							var status = json_obj[row].status;
							var attempts = json_obj[row].attempts;
							var created_at = json_obj[row].created_at;
														
							mGridData.push([(row + 1), id, entity, amount, amount_paid, amount_due, currency, receipt, status, attempts, created_at]);
						}	

						if (oTableOrder == null || oTableOrder == "undefined"){
							oTableOrder = $('#gridDataTableOrder').dataTable( {
								oSearch: {
									//sSearch: selected_razorpay_order_id
								},
								"sScrollX": "100%",
								"sScrollXInner": "110%",
																	
								"initComplete": function () {
									$("#gridDataTableOrder").on("click", "tr[role='row']", function(){
										//$("#gridDataTableOrder tbody tr").removeClass('row_selected');        
										//$(this).addClass('row_selected');
						
										////var index = $(this).index();
										//var sOrderID = $(this).children('td:nth-child(2)').text();
										//getDataPayment(0, 0, 50, sOrderID);									
									});
								},
								"aoColumns": [
									{ "sTitle": "Sl No" },
									{ "sTitle": "Order ID" },
									{ "sTitle": "Entity" },
									{ "sTitle": "Amount" },
									{ "sTitle": "Amount Paid" },
									{ "sTitle": "Amount Due" },
									{ "sTitle": "Currency" },
									{ "sTitle": "Receipt" },
									{ "sTitle": "Status" },
									{ "sTitle": "Attempts" },
									{ "sTitle": "Created At" }
								]
							} );
						}
													
						$('#gridDataTableOrder').dataTable().fnAddData(mGridData);
						//oTableOrder.oSearch( 'initial search value' ).draw();
						//$('#gridDataTableOrder').dataTable().columns(3).search("pay_fzf").draw();
					}else{
						//document.getElementById('last_alert_generated_dt').value = "No records found";
						//document.getElementById('no_of_violators').value = "No records found";
					}
				}else{
					alert("Either error occured or no order(s) found.");
				}
				
				loaderOrder.style.display = "none";
			});
		}
		
		function getDataPayment(fromDateTime = 0, toDateTime = 0, selected_order_id = "", payment_id=""){
			if (oTablePayment != null && oTablePayment != "undefined"){
				$('#gridDataTablePayment').dataTable().fnClearTable();
			}
			
			var loaderPayment = document.getElementById("loaderPayment");
			loaderPayment.style.display = "block";
			
			$.ajax({ 
			   type: "GET", 			   
			   url: "<?php echo base_url(); ?>index.php/Payment/get_payments",
			   data: { "from_timestamp" : fromDateTime, "to_timestamp" : toDateTime, "selected_order_id" : selected_order_id ,"payment_id":payment_id }
			}).done(function( data ) {
				if (data != 110){
					var json_obj = jQuery.parseJSON(data);
					if (json_obj.length > 0){							
						var mGridData = [];	
						for(var row = 0; row < json_obj.length; row++){						
							var id = json_obj[row].id;
							var entity = json_obj[row].entity;
							
							var amount = json_obj[row].amount;
							try {
								amount = parseFloat(amount) / 100;
							} catch (err) {
								console.log(err);
							}
							
							var currency = json_obj[row].currency;
							var status = json_obj[row].status;
							var order_id = json_obj[row].order_id;
							var invoice_id = json_obj[row].invoice_id;
							var international = json_obj[row].international;
							var method = json_obj[row].method;
							var amount_refunded = json_obj[row].amount_refunded;
							var refund_status = json_obj[row].refund_status;
							var captured = json_obj[row].captured;
							var description = json_obj[row].description;
							var card_id = json_obj[row].card_id;								
							var bank = json_obj[row].bank;
							var wallet = json_obj[row].wallet;
							var vpa = json_obj[row].vpa;
							var email = json_obj[row].email;
							var contact = json_obj[row].contact;
							var fee = json_obj[row].fee;
							var tax = json_obj[row].tax;
							var error_code = json_obj[row].error_code;
							var error_description = json_obj[row].error_description;
							var created_at = json_obj[row].created_at; 
							
							mGridData.push([(row + 1), id, entity, amount, currency, status, order_id, invoice_id, international, method, amount_refunded, refund_status, captured,
											description, card_id, bank, wallet, vpa, email, contact, fee, tax, error_code, error_description, created_at]);
						}	

						if (oTablePayment == null || oTablePayment == "undefined"){
							oTablePayment = $('#gridDataTablePayment').dataTable( {
								oSearch: {
									//sSearch: selected_razorpay_order_id
								},
								"sScrollX": "100%",
								"sScrollXInner": "110%",
																	
								"initComplete": function () {
									$("#gridDataTablePayment").on("click", "tr[role='row']", function(){
										//$("#gridDataTablePayment tbody tr").removeClass('row_selected');        
										//$(this).addClass('row_selected');
						
										////var index = $(this).index();
										//var sIndex = $(this).children('td:first-child').text();
										//var index = parseInt(sIndex) - 1;									
									});
								},
								"aoColumns": [
									{ "sTitle": "Sl No" },
									{ "sTitle": "Payment ID" },
									{ "sTitle": "Entity" },
									{ "sTitle": "Amount" },
									{ "sTitle": "Currency" },
									{ "sTitle": "Status" },
									{ "sTitle": "Order ID" },
									{ "sTitle": "Invoice ID" },
									{ "sTitle": "International" },
									{ "sTitle": "Method" },
									{ "sTitle": "Amount Refunded" },
									{ "sTitle": "Refund Status" },
									{ "sTitle": "Captured" },
									{ "sTitle": "Description" },
									{ "sTitle": "Card ID" },								
									{ "sTitle": "Bank" },
									{ "sTitle": "Wallet" },
									{ "sTitle": "VPA" },
									{ "sTitle": "Email" },
									{ "sTitle": "Contact" },
									{ "sTitle": "Fee" },
									{ "sTitle": "Tax" },
									{ "sTitle": "Error Code" },
									{ "sTitle": "Error Description" },
									{ "sTitle": "Created At" }
								]
							} );
						}
													
						$('#gridDataTablePayment').dataTable().fnAddData(mGridData);
						//oTablePayment.oSearch( 'initial search value' ).draw();
						//$('#gridDataTablePayment').dataTable().columns(3).search("pay_fzf").draw();
					}else{
						//document.getElementById('last_alert_generated_dt').value = "No records found";
						//document.getElementById('no_of_violators').value = "No records found";
					}
				}else{
					alert("Either error occured or no payment(s) found.");
				}
				
				loaderPayment.style.display = "none";
			});
		}
		
		function clearAllTables(){
			if (oTableUserInfo != null && oTableUserInfo != "undefined"){
				$('#gridDataTableUserInfo').dataTable().fnClearTable();
			}

			if (oTableOrder != null && oTableOrder != "undefined"){
				$('#gridDataTableOrder').dataTable().fnClearTable();
			}

			if (oTablePayment != null && oTablePayment != "undefined"){
				$('#gridDataTablePayment').dataTable().fnClearTable();
			}
		}
	</script>	