<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<div class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark">Customer Care</h1>
				</div><!-- /.col -->
				<div class="col-sm-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item"><a href="#">Home</a></li>
						<li class="breadcrumb-item active">Customer Care</li>
					</ol>
				</div><!-- /.col -->
			</div><!-- /.row -->
		</div><!-- /.container-fluid -->
	</div>
	<!-- /.content-header -->

	<!-- Main content -->
	<section class="content">
		<div class="container-fluid">
			<div class=row>
				<div class="col-md-8">
					<div class="card">
						<div class="card-header">
							<h3 class="card-title"><strong>Desktop</strong> Search</h3>
							<div class="card-tools">
								<button type="button" class="btn btn-tool" data-card-widget="collapse">
									<i class="fas fa-minus"></i>
								</button>
							</div>
						</div>
						<div class="card-body ">
							<div class="row">
								<div class="col-sm-3">
									<div class="form-group">
										<label>Maintenance Code:</label>
										<div class="input-group ">
											<input type="text" class="form-control form-control-sm " id="maintenance_code" name="maintenance_code" />
										</div>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="form-group">
										<label>Serial Key:</label>
										<div class="input-group ">
											<input type="text" class="form-control form-control-sm" id="serial_key" name="serial_key" />
										</div>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="form-group">
										<label>Mobile Number:</label>
										<div class="input-group ">
											<input type="text" class="form-control form-control-sm" id="mobile_no" name="mobile_no" />
										</div>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="form-group">
										<label>Email Id:</label>
										<div class="input-group ">
											<input type="email" class="form-control form-control-sm" id="email_id" name="email_id" ></input>								
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="card-footer">
							<div class="row">
								<div class="col-sm-6">
									<button type="button" class="btn btn-primary" id="btn_search" name="btn_search" onclick="onSearchClick()">Search</button>
									<!-- reset button -->
										<button type="button" class="btn btn-primary ml-1" id="btn_reset" name="btn_reset" onclick="reset_form()">Reset</button>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="col-md-4"> 
					<div class="card">
						<div class="card-header">
							<h3 class="card-title"><strong>Mobile App</strong> Search</h3>
							<div class="card-tools">
								<button type="button" class="btn btn-tool" data-card-widget="collapse">
									<i class="fas fa-minus"></i>
								</button>
							</div>
						</div>
						<div class="card-body ">
							<div class="row">
								<div class="col-sm-6">
									<div class="form-group">
										<label>Mobile Number:</label>
										<div class="input-group ">
											<input type="text" class="form-control form-control-sm" id="mobile" name="mobile_no" />
										</div>
									</div>
								</div>
								<div class="col-sm-6">
									<div class="form-group">
										<label>Email Id:</label>
										<div class="input-group ">
											<input type="email" class="form-control form-control-sm" id="email" name="email_id" ></input>								
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="card-footer">
							<div class="row">
								<div class="col-sm-6">
									<button type="button" class="btn btn-primary" id="btn_androidsearch" name="btn_androidsearch" onclick="onAndroidSearchClick()">Search</button>
									<!-- reset button -->
									<button type="button" class="btn btn-primary ml-1" id="btn_reset" name="btn_reset" onclick="reset_mobile_form()">Reset</button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<!-- <br> -->
			<div class="row">
				<section class="col-lg-12 connectedSortable">
					<!-- Custom tabs (Charts with tabs)-->
					<div class="card">
						<div class="card-header">
							<h3 class="card-title">
								<!-- <i class="nav-icon fa fa-bell"></i> -->
								Result
							</h3>
							<div class="card-tools">
								<button type="button" class="btn btn-tool" data-card-widget="collapse">
									<i class="fas fa-minus"></i>
								</button>
								<!--
						  <button type="button" class="btn btn-tool" data-card-widget="remove">
							<i class="fas fa-times"></i>
						  </button>
						  -->
							</div>
						</div><!-- /.card-header -->
						<div class="card-body">
							<table id="report" 
							class="table-sm table-striped table-bordered table-hover dataTable dtr-inline" 
							role="grid" 
							style="cursor:pointer">
							</table>
						</div><!-- /.card-body -->
						<div id="loader" class="overlay" style="display: none;">
							<i class="fas fa-3x fa-sync-alt fa-spin"></i>
							<div class="text-bold pt-2">Loading please wait ...</div>
							<br><br>
						</div>
					</div>
					<!-- /.card -->
				</section>
			</div>

			<!-- mobile search display -->
					<div class="row">
								<section class="col-lg-12 connectedSortable">
									<!-- Custom tabs (Charts with tabs)-->
									<div class="card">
										<div class="card-header">
											<h3 class="card-title">
												<!-- <i class="nav-icon fa fa-bell"></i> -->
												Mobile Result
											</h3>
											<div class="card-tools">
												<button type="button" class="btn btn-tool" data-card-widget="collapse">
													<i class="fas fa-minus"></i>
												</button>
												<!--
										<button type="button" class="btn btn-tool" data-card-widget="remove">
											<i class="fas fa-times"></i>
										</button>
										-->
											</div>
										</div><!-- /.card-header -->
										<div class="card-body">
											<table id="mobile_report" 
											class="table-sm table-striped table-bordered table-hover dataTable dtr-inline" 
											role="grid" 
											style="cursor:pointer">
											</table>
										</div><!-- /.card-body -->
										<div id="loader" class="overlay" style="display: none;">
											<i class="fas fa-3x fa-sync-alt fa-spin"></i>
											<div class="text-bold pt-2">Loading please wait ...</div>
											<br><br>
										</div>
									</div>
									<!-- /.card -->
								</section>
					</div>


						<!-- Modal -->
						<div class="modal fade" id="myModal" role="dialog">
							<div class="modal-dialog ">
								<!-- Modal content-->
								<div class="modal-content">
									<div class="modal-header">
										<!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->
										<h4 class="modal-title">Latest Record</h4>
									</div>
									<!-- <div class="card"> -->
										<div class="modal-body">

										</div>
									<!-- </div> -->
									<div class="modal-footer">
										<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
									</div>
								</div>
							</div>
						</div>

						<!--
						<div class="row">
							<section class="col-lg-12 connectedSortable">
								<div class="card">
								<div class="card-header">
									<h3 class="card-title">
									<i class="nav-icon fa fa-bell"></i>
									History
									</h3>
									<div class="card-tools">
									<button type="button" class="btn btn-tool" data-card-widget="collapse">
										<i class="fas fa-minus"></i>
									</button>               
									</div>
								</div>
								<div class="card-body">
									<table id="report_history" class="table table-striped table-bordered" style="cursor:pointer">											
									</table>
								</div>
									<div id="loader_history" class="overlay" style="display: none;">
										<i class="fas fa-3x fa-sync-alt fa-spin"></i>
										<div class="text-bold pt-2">Loading please wait ...</div>
										<br><br>
									</div>
								</div>
							</section>			  
						</div>
						-->
					</div><!-- /.container-fluid -->
				</section>
				<!-- /.content -->
			</div>
<!-- /.content-wrapper -->

<!-- jQuery -->
<script src="<?php echo base_url(); ?>plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url(); ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- overlayScrollbars -->
<script src="<?php echo base_url(); ?>plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url(); ?>dist/js/adminlte.js"></script>
<!-- InputMask -->
<script src="<?php echo base_url(); ?>plugins/moment/moment.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>
<!-- date-range-picker -->
<script src="<?php echo base_url(); ?>plugins/daterangepicker/daterangepicker.js"></script>

<!-- DataTables -->
<script src="<?php echo base_url(); ?>plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>

<script type="text/javascript">
	var oReport;
	var oReportHistory;
	var mobile_report;//for mobile search

	function onSearchClick() {
		if (oReport != null && oReport != "undefined") {
			$('#report').dataTable().fnClearTable();
		}

		var maintenanceCode = document.getElementById("maintenance_code").value;
		var serialKey = document.getElementById("serial_key").value;
		var mobileNo = document.getElementById("mobile_no").value;
		var email_id = document.getElementById("email_id").value;

		var loader = document.getElementById("loader");
		loader.style.display = "block";

		$.ajax({
			type: "GET",
			url: "<?php echo base_url(); ?>index.php/CustomerCare_controller/get_data",
			data: {
				"maintenance_code": maintenanceCode,
				"serial_key": serialKey,
				"mobile_no": mobileNo,
				"email_id": email_id
			}
		}).done(function(data) {
			if (data != 110) {
				var json_obj = jQuery.parseJSON(data);
				if (json_obj.length > 0) {
					var mGridData = [];
					for (var row = 0; row < json_obj.length; row++) {
						var Maintenance_code = json_obj[row].Maintenance_code;
						var SerialKey = json_obj[row].SerialKey;

						var Edition = json_obj[row].Edition;
						var Product = json_obj[row].Product;

						var Subs_AMC_Type = json_obj[row].Subs_AMC_Type;
						var Subs_AMC_Date = json_obj[row].Subs_AMC_Date;
						var ExpiryDate = json_obj[row].ExpiryDate;
						var Status = json_obj[row].Status;
						var RemainingDays = json_obj[row].RemainingDays;
						var InstalledDate = json_obj[row].InstalledDate;

						var EmailID = json_obj[row].EmailID;
						var PhoneNo = json_obj[row].PhoneNo;
						var UserName = json_obj[row].UserName;

						var InstalledKeyID = json_obj[row].InstalledKeyID;
						var ServerSerialKey = json_obj[row].ServerSerialKey;

						//var Status = json_obj[row].Status; 
						var ClientUserID = json_obj[row].ClientUserID;
						var PCName = json_obj[row].PCName;
						var MACAddress = json_obj[row].MACAddress;
						var HDDAddress = json_obj[row].HDDAddress;

						var IPAddress = json_obj[row].IPAddress;
						var Latitude = json_obj[row].Latitude;
						var Longitude = json_obj[row].Longitude;
						var Address = json_obj[row].Address;
						var IsBlocked = json_obj[row].IsBlocked;

						var ClientID = json_obj[row].ClientID;
						var SubscriptionDate = json_obj[row].SubscriptionDate;
						var SubscriptionType = json_obj[row].SubscriptionType;
						var HasUnInstalled = json_obj[row].HasUnInstalled;
						var UnInstalledDate = json_obj[row].UnInstalledDate;
						var UnInstalledBy = json_obj[row].UnInstalledBy;

						mGridData.push([(row + 1), Maintenance_code, SerialKey, Edition, Product, Subs_AMC_Type, Subs_AMC_Date, ExpiryDate, Status, RemainingDays, InstalledDate,
							EmailID, PhoneNo, UserName, InstalledKeyID, ServerSerialKey, ClientUserID, PCName, MACAddress, HDDAddress, IPAddress, Latitude, Longitude,
							Address, IsBlocked, ClientID, SubscriptionDate, SubscriptionType, HasUnInstalled, UnInstalledDate, UnInstalledBy
						]);
					}

					loadModal(mGridData);

					if (oReport == null || oReport == "undefined") {
						oReport = $('#report').dataTable({

							"sScrollX": "100%",
							"sScrollXInner": "110%",

							"initComplete": function() {
								$("#report").on("click", "tr[role='row']", function() {
									//$("#report tbody tr").removeClass('row_selected');        
									//$(this).addClass('row_selected');

									////var index = $(this).index();
									//var selected_razorpay_order_id = $(this).children('td:last-child').text();
									//window.location.href = "<?php echo base_url(); ?>index.php/Payment?razorpay_order_id=" + selected_razorpay_order_id + "";
								});
							},
							"aoColumns": [{
									"sTitle": "Sl No"
								},
								{
									"sTitle": "Maintenance_code"
								},
								{
									"sTitle": "SerialKey"
								},
								{
									"sTitle": "Edition"
								},
								{
									"sTitle": "Product"
								},
								{
									"sTitle": "Subs_AMC_Type"
								},
								{
									"sTitle": "Subs_AMC_Date"
								},
								{
									"sTitle": "ExpiryDate"
								},
								{
									"sTitle": "Status"
								},
								{
									"sTitle": "RemainingDays"
								},
								{
									"sTitle": "InstalledDate"
								},
								{
									"sTitle": "EmailID"
								},
								{
									"sTitle": "PhoneNo"
								},
								{
									"sTitle": "UserName"
								},
								{
									"sTitle": "InstalledKeyID"
								},
								{
									"sTitle": "ServerSerialKey"
								},
								{
									"sTitle": "ClientUserID"
								},
								{
									"sTitle": "PCName"
								},
								{
									"sTitle": "MACAddress"
								},
								{
									"sTitle": "HDDAddress"
								},
								{
									"sTitle": "IPAddress"
								},
								{
									"sTitle": "Latitude"
								},
								{
									"sTitle": "Longitude"
								},
								{
									"sTitle": "Address"
								},
								{
									"sTitle": "IsBlocked"
								},
								{
									"sTitle": "ClientID"
								},
								{
									"sTitle": "SubscriptionDate"
								},
								{
									"sTitle": "SubscriptionType"
								},
								{
									"sTitle": "HasUnInstalled"
								},
								{
									"sTitle": "UnInstalledDate"
								},
								{
									"sTitle": "UnInstalledBy"
								}
							]
						});
					}

					$('#report').dataTable().fnAddData(mGridData);
				} else {
					alert("No records found.");
				}
			} else {
				alert("No records found.");
			}

			loader.style.display = "none";
		});
	}

	function loadModal(mGridData) {
		var response = "";
		var remDays = 0;
		var fontColor = "black";
		var prompt = "";

		try {
			remDays = parseFloat(mGridData[0][9]);
		}
		catch(err) {
			remDays = 0;
		}
		
		if (remDays < 0){
			prompt = "Already Expired!";
			fontColor = "red";
		}else if (remDays > 0 && remDays<=30){
			prompt = "Expire In " + remDays + " Days!";
			fontColor = "orange";
		}else{
			prompt = "Not Expired!";
			fontColor = "lime";
		}

		response += "<p style='color:"+ fontColor +"'>"+ prompt +"</p>";
		response += "<table border='1' width='100%'>";
		response += "<tr><td>Maintenance_code : </td><td bgcolor='" + fontColor + "'>" + mGridData[0][1] + "</td></tr>";
		response += "<tr><td>SerialKey : </td><td bgcolor='" + fontColor + "'>" + mGridData[0][2] + "</td></tr>";
		response += "<tr><td>Edition : </td><td bgcolor='" + fontColor + "'>" + mGridData[0][3] + "</td></tr>";
		response += "<tr><td>Product : </td><td bgcolor='" + fontColor + "'>" + mGridData[0][4] + "</td></tr>";
		response += "<tr><td>Subs_AMC_Type : </td><td bgcolor='" + fontColor + "'>" + mGridData[0][5] + "</td></tr>";
		response += "<tr><td>Subs_AMC_Date : </td><td bgcolor='" + fontColor + "'>" + mGridData[0][6] + "</td></tr>";
		response += "<tr><td>ExpiryDate : </td><td bgcolor='" + fontColor + "'>" + mGridData[0][7] + "</td></tr>";
		response += "<tr><td>Status : </td><td bgcolor='" + fontColor + "'>" + mGridData[0][8] + "</td></tr>";
		response += "<tr><td>RemainingDays : </td><td bgcolor='" + fontColor + "'>" + remDays + "</td></tr>";
		response += "<tr><td>InstalledDate : </td><td bgcolor='" + fontColor + "'>" + mGridData[0][10] + "</td></tr>";
		response += "<tr><td>EmailID : </td><td bgcolor='" + fontColor + "'>" + mGridData[0][11] + "</td></tr>";
		response += "<tr><td>PhoneNo : </td><td bgcolor='" + fontColor + "'>" + mGridData[0][12] + "</td></tr>";
		response += "<tr><td>UserName : </td><td bgcolor='" + fontColor + "'>" + mGridData[0][13] + "</td></tr>";

		/*
		response += "<tr><td>InstalledKeyID : </td><td>"+ mGridData[0][14] +"</td></tr>"; 
		response += "<tr><td>ServerSerialKey : </td><td>"+ mGridData[0][15] +"</td></tr>"; 
		response += "<tr><td>ClientUserID : </td><td>"+ mGridData[0][16] +"</td></tr>"; 
		response += "<tr><td>PCName : </td><td>"+ mGridData[0][17] +"</td></tr>"; 
		response += "<tr><td>MACAddress : </td><td>"+ mGridData[0][18] +"</td></tr>"; 
		response += "<tr><td>HDDAddress : </td><td>"+ mGridData[0][19] +"</td></tr>"; 
		response += "<tr><td>IPAddress : </td><td>"+ mGridData[0][20] +"</td></tr>"; 
		response += "<tr><td>Latitude : </td><td>"+ mGridData[0][21] +"</td></tr>"; 
		response += "<tr><td>Longitude : </td><td>"+ mGridData[0][22] +"</td></tr>"; 
		response += "<tr><td>Address : </td><td>"+ mGridData[0][23] +"</td></tr>"; 
		response += "<tr><td>IsBlocked : </td><td>"+ mGridData[0][24] +"</td></tr>"; 
		response += "<tr><td>ClientID : </td><td>"+ mGridData[0][25] +"</td></tr>"; 
		response += "<tr><td>SubscriptionDate : </td><td>"+ mGridData[0][26] +"</td></tr>"; 
		response += "<tr><td>SubscriptionType : </td><td>"+ mGridData[0][27] +"</td></tr>"; 
		response += "<tr><td>HasUnInstalled : </td><td>"+ mGridData[0][28] +"</td></tr>"; 
		response += "<tr><td>UnInstalledDate : </td><td>"+ mGridData[0][29] +"</td></tr>"; 
		response += "<tr><td>UnInstalledBy : </td><td>"+ mGridData[0][30] +"</td></tr>"; 
		*/

		response += "</table>";

		$('.modal-body').html(response);

		// Display Modal
		$('#myModal').modal('show');
	}

	function onHistoryClick() {
		if (oReport != null && oReport != "undefined") {
			$('#report').dataTable().fnClearTable();
		}

		var maintenanceCode = document.getElementById("maintenance_code").value;
		var serialKey = document.getElementById("serial_key").value;
		var mobileNo = document.getElementById("mobile_no").value;
		var email_id = document.getElementById("email_id").value;

		var loader = document.getElementById("loader");
		loader.style.display = "block";

		$.ajax({
			type: "GET",
			url: "<?php echo base_url(); ?>index.php/CustomerCare_controller/get_data",
			data: {
				"maintenance_code": maintenanceCode,
				"serial_key": serialKey,
				"mobile_no": mobileNo,
				"email_id": email_id
			}
		}).done(function(data) {
			if (data != 110) {
				var json_obj = jQuery.parseJSON(data);
				if (json_obj.length > 0) {
					var mGridData = [];
					for (var row = 0; row < json_obj.length; row++) {
						var Maintenance_code = json_obj[row].Maintenance_code;
						var SerialKey = json_obj[row].SerialKey;

						var Edition = json_obj[row].Edition;
						var Product = json_obj[row].Product;

						var Subs_AMC_Type = json_obj[row].Subs_AMC_Type;
						var Subs_AMC_Date = json_obj[row].Subs_AMC_Date;
						var ExpiryDate = json_obj[row].ExpiryDate;
						var Status = json_obj[row].Status;
						var RemainingDays = json_obj[row].RemainingDays;
						var InstalledDate = json_obj[row].InstalledDate;

						var EmailID = json_obj[row].EmailID;
						var PhoneNo = json_obj[row].PhoneNo;
						var UserName = json_obj[row].UserName;

						var InstalledKeyID = json_obj[row].InstalledKeyID;
						var ServerSerialKey = json_obj[row].ServerSerialKey;

						//var Status = json_obj[row].Status; 
						var ClientUserID = json_obj[row].ClientUserID;
						var PCName = json_obj[row].PCName;
						var MACAddress = json_obj[row].MACAddress;
						var HDDAddress = json_obj[row].HDDAddress;

						var IPAddress = json_obj[row].IPAddress;
						var Latitude = json_obj[row].Latitude;
						var Longitude = json_obj[row].Longitude;
						var Address = json_obj[row].Address;
						var IsBlocked = json_obj[row].IsBlocked;

						var ClientID = json_obj[row].ClientID;
						var SubscriptionDate = json_obj[row].SubscriptionDate;
						var SubscriptionType = json_obj[row].SubscriptionType;
						var HasUnInstalled = json_obj[row].HasUnInstalled;
						var UnInstalledDate = json_obj[row].UnInstalledDate;
						var UnInstalledBy = json_obj[row].UnInstalledBy;

						mGridData.push([(row + 1), Maintenance_code, SerialKey, Edition, Product, Subs_AMC_Type, Subs_AMC_Date, ExpiryDate, Status, RemainingDays, InstalledDate,
							EmailID, PhoneNo, UserName, InstalledKeyID, ServerSerialKey, ClientUserID, PCName, MACAddress, HDDAddress, IPAddress, Latitude, Longitude,
							Address, IsBlocked, ClientID, SubscriptionDate, SubscriptionType, HasUnInstalled, UnInstalledDate, UnInstalledBy
						]);
					}

					if (oReport == null || oReport == "undefined") {
						oReport = $('#report').dataTable({

							"sScrollX": "100%",
							"sScrollXInner": "110%",

							"initComplete": function() {
								$("#report").on("click", "tr[role='row']", function() {
									//$("#report tbody tr").removeClass('row_selected');        
									//$(this).addClass('row_selected');

									////var index = $(this).index();
									//var selected_razorpay_order_id = $(this).children('td:last-child').text();
									//window.location.href = "<?php echo base_url(); ?>index.php/Payment?razorpay_order_id=" + selected_razorpay_order_id + "";
								});
							},
							"aoColumns": [{
									"sTitle": "Sl No"
								},
								{
									"sTitle": "Maintenance_code"
								},
								{
									"sTitle": "SerialKey"
								},
								{
									"sTitle": "Edition"
								},
								{
									"sTitle": "Product"
								},
								{
									"sTitle": "Subs_AMC_Type"
								},
								{
									"sTitle": "Subs_AMC_Date"
								},
								{
									"sTitle": "ExpiryDate"
								},
								{
									"sTitle": "Status"
								},
								{
									"sTitle": "RemainingDays"
								},
								{
									"sTitle": "InstalledDate"
								},
								{
									"sTitle": "EmailID"
								},
								{
									"sTitle": "PhoneNo"
								},
								{
									"sTitle": "UserName"
								},
								{
									"sTitle": "InstalledKeyID"
								},
								{
									"sTitle": "ServerSerialKey"
								},
								{
									"sTitle": "ClientUserID"
								},
								{
									"sTitle": "PCName"
								},
								{
									"sTitle": "MACAddress"
								},
								{
									"sTitle": "HDDAddress"
								},
								{
									"sTitle": "IPAddress"
								},
								{
									"sTitle": "Latitude"
								},
								{
									"sTitle": "Longitude"
								},
								{
									"sTitle": "Address"
								},
								{
									"sTitle": "IsBlocked"
								},
								{
									"sTitle": "ClientID"
								},
								{
									"sTitle": "SubscriptionDate"
								},
								{
									"sTitle": "SubscriptionType"
								},
								{
									"sTitle": "HasUnInstalled"
								},
								{
									"sTitle": "UnInstalledDate"
								},
								{
									"sTitle": "UnInstalledBy"
								}
							]
						});
					}

					$('#report').dataTable().fnAddData(mGridData);
				} else {
					alert("No records found.");
				}
			} else {
				alert("No records found.");
			}

			loader.style.display = "none";
		});
	}

	// search in case mobile
	function onAndroidSearchClick()
	{
		if (mobile_report != null && mobile_report != "undefined") {
			$('#mobile_report').dataTable().fnClearTable();
		}

		// get input values
		var mobile= document.getElementById("mobile").value;
		var email= document.getElementById("email").value;
		

		var loader = document.getElementById("loader");
		loader.style.display = "block";

		// send input values to API
		$.ajax({
			type: "GET",
			url: "<?php echo base_url(); ?>index.php/CustomerCare_controller/getdata_api",
			data: {
				"mobile": mobile,
				"email": email,
				
			}
			
		}).done(function(data) {
			var json_obj=JSON.parse(data);//get value in JSON object format
			console.log(json_obj);//data inthe form of objects

			
			// check the status of client
			if(json_obj.status=="Unregistered"){
				console.log(Object.keys(json_obj).length);
				alert("No records found.");
			}
			else
			{
				var json_array= new Array(json_obj);//store in array
				console.log(json_array);//data inthe form of array
				console.log(json_array.length);
				for(var row=0; row<json_array.length; row++)
				{
					var mobile_mGridData = [];

						var id =json_array[row].id;
						
						var name = json_array[row].name;

						var mobile = json_array[row].mobile;
						var email = json_array[row].email;

						var designation = json_array[row].designation;
						var state = json_array[row].state;
						var status = json_array[row].status;
						var expiry_date = json_array[row].expiry_date;
						var description = json_array[row].description;
						var subs_type_id = json_array[row].subs_type_id;
						var country = json_array[row].country;

						mobile_mGridData.push([(row+1), id, name, mobile, email, designation, state, status, expiry_date, description, subs_type_id,
						country
						]);
				

					mobile_loadModal(mobile_mGridData);

					if (mobile_report== null || mobile_report == "undefined") {
						mobile_report = $('#mobile_report').dataTable({

							"sScrollX": "100%",
							"sScrollXInner": "110%",

							// "initComplete": function() {
							// 	$("#report").on("click", "tr[role='row']", function() {
							// 		//$("#report tbody tr").removeClass('row_selected');        
							// 		//$(this).addClass('row_selected');

							// 		////var index = $(this).index();
							// 		//var selected_razorpay_order_id = $(this).children('td:last-child').text();
							// 		//window.location.href = "<?php echo base_url(); ?>index.php/Payment?razorpay_order_id=" + selected_razorpay_order_id + "";
							// 	});
							// },
							"aoColumns": [{
									"sTitle": "Sl No"
								},
								{
									"sTitle": "Id"
								},
								{
									"sTitle": "UserName"
								},
								{
									"sTitle": "PhoneNo"
								},
								{
									"sTitle": "EmailID"
								},
								{
									"sTitle": "Designation"
								},
								{
									"sTitle": "State"
								},
								{
									"sTitle": "Status"
								},
								{
									"sTitle": "ExpiryDate"
								},
								{
									"sTitle": "Description"
								},
								{
									"sTitle": "Subs_type_id"
								},
								{
									"sTitle": "Country"
								}
								
							]
						});
					}

					$('#mobile_report').dataTable().fnAddData(mobile_mGridData);
				}
			
				
			}

			loader.style.display = "none";
			console.log("success");
		});
	}

	// mobile search
	function mobile_loadModal(mobile_mGridData)
	{
			var response = "";
			var remDays = 0;
			var fontColor = "black";
			var prompt = "";

		
			try {
				
				// get expiry date
				client_date = mobile_mGridData[0][8];
				var new_date=moment(client_date,"DD/MM/YYYY").format("MM/DD/YYYY");//convert Expiry_date format into MM/DD/YYYY to find REM_Days
		
				// get current date
				var Current_Date=new Date();
				var Expiry_date=new Date(new_date);

				console.log("current_date = " +Current_Date);
				console.log("Expiry_date = " +Expiry_date);

				// calculate remaining days
				var diff=Expiry_date-Current_Date;
				var Days=1000*60*60*24;
				var remDays=Math.floor(diff/Days);
				console.log("remaining days = " +remDays);
				
				
			}
			catch(err) {
				remDays = 0;
			}
			
			if (remDays < 0)
			{
				prompt = "Already Expired!";
				fontColor = "red";
			}
			else if (remDays > 0 && remDays<=30)
			{
				prompt = "Expire In " + remDays + " Days!";
				fontColor = "orange";
			}
			else
			{ 
				prompt = "Not Expired!";
				fontColor = "lime";
			}

			response += "<p style='color:"+ fontColor +"'>"+ prompt +"</p>";
			response += "<table border='1' width='100%'>";
			response += "<tr><td>Id : </td><td bgcolor='" + fontColor + "'>" + mobile_mGridData[0][1] + "</td></tr>";
			response += "<tr><td>UserName : </td><td bgcolor='" + fontColor + "'>" + mobile_mGridData[0][2] + "</td></tr>";
			response += "<tr><td>PhoneNo : </td><td bgcolor='" + fontColor + "'>" + mobile_mGridData[0][3] + "</td></tr>";
			response += "<tr><td>EmailID : </td><td bgcolor='" + fontColor + "'>" + mobile_mGridData[0][4] + "</td></tr>";
			response += "<tr><td>Designation : </td><td bgcolor='" + fontColor + "'>" + mobile_mGridData[0][5] + "</td></tr>";
			response += "<tr><td>State : </td><td bgcolor='" + fontColor + "'>" + mobile_mGridData[0][6] + "</td></tr>";
			response += "<tr><td>Status  : </td><td bgcolor='" + fontColor + "'>" + mobile_mGridData[0][7] + "</td></tr>";
			response += "<tr><td>ExpiryDate : </td><td bgcolor='" + fontColor + "'>" + mobile_mGridData[0][8] + "</td></tr>";
			response += "<tr><td>Description : </td><td bgcolor='" + fontColor + "'>" + mobile_mGridData[0][9] + "</td></tr>";
			response += "<tr><td>Subs_type_id : </td><td bgcolor='" + fontColor + "'>" + mobile_mGridData[0][10] + "</td></tr>";
			response += "<tr><td>Country : </td><td bgcolor='" + fontColor + "'>" + mobile_mGridData[0][11] + "</td></tr>";


			/*
			response += "<tr><td>InstalledKeyID : </td><td>"+ mGridData[0][14] +"</td></tr>"; 
			response += "<tr><td>ServerSerialKey : </td><td>"+ mGridData[0][15] +"</td></tr>"; 
			response += "<tr><td>ClientUserID : </td><td>"+ mGridData[0][16] +"</td></tr>"; 
			response += "<tr><td>PCName : </td><td>"+ mGridData[0][17] +"</td></tr>"; 
			response += "<tr><td>MACAddress : </td><td>"+ mGridData[0][18] +"</td></tr>"; 
			response += "<tr><td>HDDAddress : </td><td>"+ mGridData[0][19] +"</td></tr>"; 
			response += "<tr><td>IPAddress : </td><td>"+ mGridData[0][20] +"</td></tr>"; 
			response += "<tr><td>Latitude : </td><td>"+ mGridData[0][21] +"</td></tr>"; 
			response += "<tr><td>Longitude : </td><td>"+ mGridData[0][22] +"</td></tr>"; 
			response += "<tr><td>Address : </td><td>"+ mGridData[0][23] +"</td></tr>"; 
			response += "<tr><td>IsBlocked : </td><td>"+ mGridData[0][24] +"</td></tr>"; 
			response += "<tr><td>ClientID : </td><td>"+ mGridData[0][25] +"</td></tr>"; 
			response += "<tr><td>SubscriptionDate : </td><td>"+ mGridData[0][26] +"</td></tr>"; 
			response += "<tr><td>SubscriptionType : </td><td>"+ mGridData[0][27] +"</td></tr>"; 
			response += "<tr><td>HasUnInstalled : </td><td>"+ mGridData[0][28] +"</td></tr>"; 
			response += "<tr><td>UnInstalledDate : </td><td>"+ mGridData[0][29] +"</td></tr>"; 
			response += "<tr><td>UnInstalledBy : </td><td>"+ mGridData[0][30] +"</td></tr>"; 
			*/

			response += "</table>";

			$('.modal-body').html(response);

			// Display Modal
			$('#myModal').modal('show');
	}


	//form reset[desktop search]
	function reset_form() 
	{
		$('#maintenance_code').val('');
		$('#serial_key').val('');
		$('#mobile_no').val('');
		$('#email_id').val('');
		// clear result grid
		if (oReport != null && oReport != "undefined")
		 {
			$('#report').dataTable().fnClearTable();
		 }
		console.log("reset button clicked...");
	}

	//form reset[desktop search]
	function reset_mobile_form() 
	{
		$('#mobile').val('');
		$('#email').val('');
		
		// clear result grid
		if (mobile_report != null && mobile_report != "undefined")
		 {
			$('#mobile_report').dataTable().fnClearTable();
		 }
	
		console.log("reset button clicked...");
	}


</script>