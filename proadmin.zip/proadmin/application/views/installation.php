<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark">Installation</h1>
				</div><!-- /.col -->
				<div class="col-sm-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item"><a href="#">Home</a></li>
						<li class="breadcrumb-item active">Installations</li>
					</ol>
				</div><!-- /.col -->
			</div><!-- /.row -->
		</div><!-- /.container-fluid -->
	</section>
	<!-- /.content-header -->

	<!-- Main content -->
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				
				<div class="col-md-12">

					<div class="card">
						<div class="card-header">
							<h3 class="card-title">Search by</h3>
							<div class="card-tools">
								<button type="button" class="btn btn-tool" data-card-widget="collapse">
									<i class="fas fa-minus"></i>
								</button>
							</div>
						</div>
						<form role="form" id="installationForm">
							<div class="card-body">
								<div class="row">
									<!-- <div class="col-md-3">
										<div class="form-group">
											<label>Product</label>
											<select class="form-control form-control-sm float-right" id="com_product" name="com_product">
											<option value="0">Select option</option>
												<?php 
													foreach ($products->result_array() as $row)
													{
														echo "<option value='".$row['Product_Name']."'>".$row['Product_Name'] ."</option>";	
													}
												?>
											</select>
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label>Edition</label>
											<select class="form-control form-control-sm float-right" id="com_edition" name="com_edition">
												<option value="0" selected></option>													
											</select>
										</div>
									</div> -->
									<div class="col-md-6">
										<div class="form-group">
											<label for="InstallationDate">Installation Date</label>
											<div class="input-group">
												<div class="input-group-prepend">
													<span class="input-group-text"><i class="far fa-clock"></i></span>
												</div>
												<input type="text" class="form-control form-control-sm float-right" id="registered_dt">
											</div>
										</div>
									</div>
								</div>

								<div class="row">
									<div class="col-md-3">
										<div class="form-group">
											<label>Maintenance Code</label>
											<div class="input-group">
												<input type="text" class="form-control form-control-sm" id="maintenance_code" name="maintenance_code" />
											</div>
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label>Serial Key</label>
											<div class="input-group">
												<input type="text" class="form-control form-control-sm" id="serial_key" name="serial_key" />
											</div>
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label>Mobile Number</label>
											<div class="input-group">
												<input type="text" class="form-control form-control-sm" id="mobile_no" name="mobile_no" />
											</div>
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label for="inputforEmailid">Email Id</label>
											<input type="email" name="email_id" 
											class="form-control form-control-sm" id="email_id">
										</div>
										<!-- <div class="form-group">
											<label>Email :</label>
											<div class="input-group">
												<input type="email" 
												class="form-control form-control-sm" id="email_id" 
												name="email_id" >
											</div>
										</div> -->
									</div>
								</div>
							</div>
						</form>

						<div class="card-footer">
							<!-- <div class="col-md-6"> -->
							<button type="button" class="btn btn-primary" id="btn_search" name="btn_search" onclick="onSearchClick()">Search</button>

							<!-- reset button -->
							<button type="button" class="btn btn-primary ml-1" id="btn_reset" name="btn_reset" onclick="reset_form()">Reset</button>
							<!-- </div> -->
						</div>
					</div>

					<!-- result -->
					<div class="row">
						<section class="col-lg-12 connectedSortable">
							<!-- Custom tabs (Charts with tabs)-->
							<div class="card">
								<div class="card-header">
									<h3 class="card-title">
										<!-- <i class="nav-icon fa fa-bell"></i> -->
										Result
									</h3>
									<div class="card-tools">
										<button type="button" class="btn btn-tool" data-card-widget="collapse">
											<i class="fas fa-minus"></i>
										</button>
										<!--
								<button type="button" class="btn btn-tool" data-card-widget="remove">
									<i class="fas fa-times"></i>
								</button>
								-->
									</div>
								</div><!-- /.card-header -->
								<div class="card-body">
									<table id="report" class="table-md table-striped table-bordered" style="cursor:pointer">
									</table>
								</div><!-- /.card-body -->
								<div id="loader" class="overlay" style="display: none;">
									<i class="fas fa-3x fa-sync-alt fa-spin"></i>
									<div class="text-bold pt-2">Loading please wait ...</div>
									<br><br>
								</div>
							</div>
							<!-- /.card -->
						</section>
					</div>

					<!-- Modal -->
					<div class="modal fade" id="myModal" role="dialog">
						<div class="modal-dialog">

							<!-- Modal content-->
							<div class="modal-content">
								<div class="modal-header">
									<!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->
									<h4 class="modal-title">Top Record</h4>
								</div>
								<div class="modal-body">

								</div>
								<div class="modal-footer">
									<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								</div>
							</div>

						</div>
					</div>

					<!--
					<div class="row">
						<section class="col-lg-12 connectedSortable">
							<div class="card">
							<div class="card-header">
								<h3 class="card-title">
								<i class="nav-icon fa fa-bell"></i>
								History
								</h3>
								<div class="card-tools">
								<button type="button" class="btn btn-tool" data-card-widget="collapse">
									<i class="fas fa-minus"></i>
								</button>               
								</div>
							</div>
							<div class="card-body">
								<table id="report_history" class="table table-striped table-bordered" style="cursor:pointer">											
								</table>
							</div>
								<div id="loader_history" class="overlay" style="display: none;">
									<i class="fas fa-3x fa-sync-alt fa-spin"></i>
									<div class="text-bold pt-2">Loading please wait ...</div>
									<br><br>
								</div>
							</div>
						</section>			  
					</div>
					-->
				</div>
			</div>
		</div><!-- /.container-fluid -->
	</section>
	<!-- /.content -->
</div>
<!-- /.content-wrapper -->

<!-- jQuery -->
<script src="<?php echo base_url(); ?>plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url(); ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- overlayScrollbars -->
<script src="<?php echo base_url(); ?>plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url(); ?>dist/js/adminlte.js"></script>
<!-- InputMask -->
<script src="<?php echo base_url(); ?>plugins/moment/moment.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>
<!-- date-range-picker -->
<script src="<?php echo base_url(); ?>plugins/daterangepicker/daterangepicker.js"></script>

<!-- DataTables -->
<script src="<?php echo base_url(); ?>plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>

<script type="text/javascript">
	var oReport;
	var oReportHistory;
	//Date range picker with time picker
	$('#registered_dt').daterangepicker({
		timePicker: true,
		timePickerIncrement: 1,
		locale: {
			format: 'DD/MM/YYYY hh:mm A'
		}
	});

	// $('#com_product').change(function(){
	// 	var selectedProductName = $(this).val(); 
	// 	//alert(cust_id);

	// 	var select = document.getElementById("com_edition");
	// 	select.options.length = 0;

	// 	$.ajax({ 
	// 		type: "GET", 			   
	// 		url: "<?php echo base_url(); ?>index.php/Product_controller/get_product_editions",
	// 		data: { 
	// 			// Customer Information
	// 			"product_name" : selectedProductName
	// 		}
	// 	}).done(function( data ) {
	// 		if (data != 110){
	// 			var json_obj = jQuery.parseJSON(data);
	// 			if (json_obj.length > 0){
	// 				for(var i=0; i<json_obj.length; i++){
	// 					var option = document.createElement("option");
	// 					option.value = json_obj[i].Edition;
	// 					option.text = json_obj[i].Edition;
	// 					select.appendChild(option);
	// 				}
	// 			}
	// 		}
	// 	});
	// })

	function onSearchClick() {
		if (oReport != null && oReport != "undefined") {
			$('#report').dataTable().fnClearTable();
		}

		// var selProductName = document.getElementById("com_product").value;
		// var selEdition = document.getElementById("com_edition").value;

		var fromDateTime = $('#registered_dt').data('daterangepicker').startDate.format('YYYY-MM-DD hh:mm A');
		var toDateTime = $('#registered_dt').data('daterangepicker').endDate.format('YYYY-MM-DD hh:mm A');

		// check date input field is empty
		if($('#registered_dt').val()==''){
			fromDateTime='';
			toDateTime='';
		}
		var maintenanceCode = document.getElementById("maintenance_code").value;
		var serialKey = document.getElementById("serial_key").value;
		var mobileNo = document.getElementById("mobile_no").value;
		var email_id = document.getElementById("email_id").value;

		var loader = document.getElementById("loader");
		loader.style.display = "block";

		$.ajax({
			type: "GET",
			url: "<?php echo base_url(); ?>index.php/Installation_controller/get_data",
			data: {
				// "product_name" : selProductName,
				// "edition" : selEdition,
				"from_timestamp": fromDateTime,
				"to_timestamp": toDateTime,
				"maintenance_code": maintenanceCode,
				"serial_key": serialKey,
				"mobile_no": mobileNo,
				"email_id": email_id
			}
		}).done(function(data) {
			if (data != 110) {
				var json_obj = jQuery.parseJSON(data);
				if (json_obj.length > 0) {
					var mGridData = [];
					for (var row = 0; row < json_obj.length; row++) {
						var Maintenance_code = json_obj[row].Maintenance_code;
						var SerialKey = json_obj[row].SerialKey;

						var Edition = json_obj[row].Edition;
						var Product = json_obj[row].Product;

						var Subs_AMC_Type = json_obj[row].Subs_AMC_Type;
						var Subs_AMC_Date = json_obj[row].Subs_AMC_Date;
						var ExpiryDate = json_obj[row].ExpiryDate;
						var Status = json_obj[row].Status;
						var RemainingDays = json_obj[row].RemainingDays;
						var InstalledDate = json_obj[row].InstalledDate;

						var EmailID = json_obj[row].EmailID;
						var PhoneNo = json_obj[row].PhoneNo;
						var UserName = json_obj[row].UserName;

						var InstalledKeyID = json_obj[row].InstalledKeyID;
						var ServerSerialKey = json_obj[row].ServerSerialKey;

						//var Status = json_obj[row].Status; 
						var ClientUserID = json_obj[row].ClientUserID;
						var PCName = json_obj[row].PCName;
						var MACAddress = json_obj[row].MACAddress;
						var HDDAddress = json_obj[row].HDDAddress;

						var IPAddress = json_obj[row].IPAddress;
						var Latitude = json_obj[row].Latitude;
						var Longitude = json_obj[row].Longitude;
						var Address = json_obj[row].Address;
						var IsBlocked = json_obj[row].IsBlocked;

						var ClientID = json_obj[row].ClientID;
						var SubscriptionDate = json_obj[row].SubscriptionDate;
						var SubscriptionType = json_obj[row].SubscriptionType;
						var HasUnInstalled = json_obj[row].HasUnInstalled;
						var UnInstalledDate = json_obj[row].UnInstalledDate;
						var UnInstalledBy = json_obj[row].UnInstalledBy;

						mGridData.push([(row + 1), Maintenance_code, SerialKey, Edition, Product, Subs_AMC_Type, Subs_AMC_Date, ExpiryDate, Status, RemainingDays, InstalledDate,
							EmailID, PhoneNo, UserName, InstalledKeyID, ServerSerialKey, ClientUserID, PCName, MACAddress, HDDAddress, IPAddress, Latitude, Longitude,
							Address, IsBlocked, ClientID, SubscriptionDate, SubscriptionType, HasUnInstalled, UnInstalledDate, UnInstalledBy
						]);
					}

					//loadModal(mGridData);

					if (oReport == null || oReport == "undefined") {
						oReport = $('#report').dataTable({

							"sScrollX": "100%",
							"sScrollXInner": "110%",

							"initComplete": function() {
								$("#report").on("click", "tr[role='row']", function() {
									//$("#report tbody tr").removeClass('row_selected');        
									//$(this).addClass('row_selected');

									////var index = $(this).index();
									//var selected_razorpay_order_id = $(this).children('td:last-child').text();
									//window.location.href = "<?php echo base_url(); ?>index.php/Payment?razorpay_order_id=" + selected_razorpay_order_id + "";
								});
							},
							"aoColumns": [{
									"sTitle": "Sl No"
								},
								{
									"sTitle": "Maintenance_code"
								},
								{
									"sTitle": "SerialKey"
								},
								{
									"sTitle": "Edition"
								},
								{
									"sTitle": "Product"
								},
								{
									"sTitle": "Subs_AMC_Type"
								},
								{
									"sTitle": "Subs_AMC_Date"
								},
								{
									"sTitle": "ExpiryDate"
								},
								{
									"sTitle": "Status"
								},
								{
									"sTitle": "RemainingDays"
								},
								{
									"sTitle": "InstalledDate"
								},
								{
									"sTitle": "EmailID"
								},
								{
									"sTitle": "PhoneNo"
								},
								{
									"sTitle": "UserName"
								},
								{
									"sTitle": "InstalledKeyID"
								},
								{
									"sTitle": "ServerSerialKey"
								},
								{
									"sTitle": "ClientUserID"
								},
								{
									"sTitle": "PCName"
								},
								{
									"sTitle": "MACAddress"
								},
								{
									"sTitle": "HDDAddress"
								},
								{
									"sTitle": "IPAddress"
								},
								{
									"sTitle": "Latitude"
								},
								{
									"sTitle": "Longitude"
								},
								{
									"sTitle": "Address"
								},
								{
									"sTitle": "IsBlocked"
								},
								{
									"sTitle": "ClientID"
								},
								{
									"sTitle": "SubscriptionDate"
								},
								{
									"sTitle": "SubscriptionType"
								},
								{
									"sTitle": "HasUnInstalled"
								},
								{
									"sTitle": "UnInstalledDate"
								},
								{
									"sTitle": "UnInstalledBy"
								}
							]
						});
					}

					$('#report').dataTable().fnAddData(mGridData);
				} else {
					alert("No records found.");
				}
			} else {
				alert("No records found.");
			}

			loader.style.display = "none";
		});
	}

	function loadModal(mGridData) {
		var response = "<table border='1' width='100%'>";

		response += "<tr><td>Maintenance_code : </td><td>" + mGridData[0][1] + "</td></tr>";
		response += "<tr><td>SerialKey : </td><td>" + mGridData[0][2] + "</td></tr>";
		response += "<tr><td>Edition : </td><td>" + mGridData[0][3] + "</td></tr>";
		response += "<tr><td>Product : </td><td>" + mGridData[0][4] + "</td></tr>";
		response += "<tr><td>Subs_AMC_Type : </td><td>" + mGridData[0][5] + "</td></tr>";
		response += "<tr><td>Subs_AMC_Date : </td><td>" + mGridData[0][6] + "</td></tr>";
		response += "<tr><td>ExpiryDate : </td><td>" + mGridData[0][7] + "</td></tr>";
		response += "<tr><td>Status : </td><td>" + mGridData[0][8] + "</td></tr>";
		response += "<tr><td>RemainingDays : </td><td>" + mGridData[0][9] + "</td></tr>";
		response += "<tr><td>InstalledDate : </td><td>" + mGridData[0][10] + "</td></tr>";
		response += "<tr><td>EmailID : </td><td>" + mGridData[0][11] + "</td></tr>";
		response += "<tr><td>PhoneNo : </td><td>" + mGridData[0][12] + "</td></tr>";
		response += "<tr><td>UserName : </td><td>" + mGridData[0][13] + "</td></tr>";

		/*
		response += "<tr><td>InstalledKeyID : </td><td>"+ mGridData[0][14] +"</td></tr>"; 
		response += "<tr><td>ServerSerialKey : </td><td>"+ mGridData[0][15] +"</td></tr>"; 
		response += "<tr><td>ClientUserID : </td><td>"+ mGridData[0][16] +"</td></tr>"; 
		response += "<tr><td>PCName : </td><td>"+ mGridData[0][17] +"</td></tr>"; 
		response += "<tr><td>MACAddress : </td><td>"+ mGridData[0][18] +"</td></tr>"; 
		response += "<tr><td>HDDAddress : </td><td>"+ mGridData[0][19] +"</td></tr>"; 
		response += "<tr><td>IPAddress : </td><td>"+ mGridData[0][20] +"</td></tr>"; 
		response += "<tr><td>Latitude : </td><td>"+ mGridData[0][21] +"</td></tr>"; 
		response += "<tr><td>Longitude : </td><td>"+ mGridData[0][22] +"</td></tr>"; 
		response += "<tr><td>Address : </td><td>"+ mGridData[0][23] +"</td></tr>"; 
		response += "<tr><td>IsBlocked : </td><td>"+ mGridData[0][24] +"</td></tr>"; 
		response += "<tr><td>ClientID : </td><td>"+ mGridData[0][25] +"</td></tr>"; 
		response += "<tr><td>SubscriptionDate : </td><td>"+ mGridData[0][26] +"</td></tr>"; 
		response += "<tr><td>SubscriptionType : </td><td>"+ mGridData[0][27] +"</td></tr>"; 
		response += "<tr><td>HasUnInstalled : </td><td>"+ mGridData[0][28] +"</td></tr>"; 
		response += "<tr><td>UnInstalledDate : </td><td>"+ mGridData[0][29] +"</td></tr>"; 
		response += "<tr><td>UnInstalledBy : </td><td>"+ mGridData[0][30] +"</td></tr>"; 
		*/

		response += "</table>";

		$('.modal-body').html(response);

		// Display Modal
		$('#myModal').modal('show');
	}

	function onHistoryClick() {
		if (oReport != null && oReport != "undefined") {
			$('#report').dataTable().fnClearTable();
		}

		var maintenanceCode = document.getElementById("maintenance_code").value;
		var serialKey = document.getElementById("serial_key").value;
		var mobileNo = document.getElementById("mobile_no").value;
		var email_id = document.getElementById("email_id").value;

		var loader = document.getElementById("loader");
		loader.style.display = "block";

		$.ajax({
			type: "GET",
			url: "<?php echo base_url(); ?>index.php/CustomerCare_controller/get_data",
			data: {
				"maintenance_code": maintenanceCode,
				"serial_key": serialKey,
				"mobile_no": mobileNo,
				"email_id": email_id
			}
		}).done(function(data) {
			if (data != 110) {
				var json_obj = jQuery.parseJSON(data);
				if (json_obj.length > 0) {
					var mGridData = [];
					for (var row = 0; row < json_obj.length; row++) {
						var Maintenance_code = json_obj[row].Maintenance_code;
						var SerialKey = json_obj[row].SerialKey;

						var Edition = json_obj[row].Edition;
						var Product = json_obj[row].Product;

						var Subs_AMC_Type = json_obj[row].Subs_AMC_Type;
						var Subs_AMC_Date = json_obj[row].Subs_AMC_Date;
						var ExpiryDate = json_obj[row].ExpiryDate;
						var Status = json_obj[row].Status;
						var RemainingDays = json_obj[row].RemainingDays;
						var InstalledDate = json_obj[row].InstalledDate;

						var EmailID = json_obj[row].EmailID;
						var PhoneNo = json_obj[row].PhoneNo;
						var UserName = json_obj[row].UserName;

						var InstalledKeyID = json_obj[row].InstalledKeyID;
						var ServerSerialKey = json_obj[row].ServerSerialKey;

						//var Status = json_obj[row].Status; 
						var ClientUserID = json_obj[row].ClientUserID;
						var PCName = json_obj[row].PCName;
						var MACAddress = json_obj[row].MACAddress;
						var HDDAddress = json_obj[row].HDDAddress;

						var IPAddress = json_obj[row].IPAddress;
						var Latitude = json_obj[row].Latitude;
						var Longitude = json_obj[row].Longitude;
						var Address = json_obj[row].Address;
						var IsBlocked = json_obj[row].IsBlocked;

						var ClientID = json_obj[row].ClientID;
						var SubscriptionDate = json_obj[row].SubscriptionDate;
						var SubscriptionType = json_obj[row].SubscriptionType;
						var HasUnInstalled = json_obj[row].HasUnInstalled;
						var UnInstalledDate = json_obj[row].UnInstalledDate;
						var UnInstalledBy = json_obj[row].UnInstalledBy;

						mGridData.push([(row + 1), Maintenance_code, SerialKey, Edition, Product, Subs_AMC_Type, Subs_AMC_Date, ExpiryDate, Status, RemainingDays, InstalledDate,
							EmailID, PhoneNo, UserName, InstalledKeyID, ServerSerialKey, ClientUserID, PCName, MACAddress, HDDAddress, IPAddress, Latitude, Longitude,
							Address, IsBlocked, ClientID, SubscriptionDate, SubscriptionType, HasUnInstalled, UnInstalledDate, UnInstalledBy
						]);
					}

					if (oReport == null || oReport == "undefined") {
						oReport = $('#report').dataTable({

							"sScrollX": "100%",
							"sScrollXInner": "110%",

							"initComplete": function() {
								$("#report").on("click", "tr[role='row']", function() {
									//$("#report tbody tr").removeClass('row_selected');        
									//$(this).addClass('row_selected');

									////var index = $(this).index();
									//var selected_razorpay_order_id = $(this).children('td:last-child').text();
									//window.location.href = "<?php echo base_url(); ?>index.php/Payment?razorpay_order_id=" + selected_razorpay_order_id + "";
								});
							},
							"aoColumns": [{
									"sTitle": "Sl No"
								},
								{
									"sTitle": "Maintenance_code"
								},
								{
									"sTitle": "SerialKey"
								},
								{
									"sTitle": "Edition"
								},
								{
									"sTitle": "Product"
								},
								{
									"sTitle": "Subs_AMC_Type"
								},
								{
									"sTitle": "Subs_AMC_Date"
								},
								{
									"sTitle": "ExpiryDate"
								},
								{
									"sTitle": "Status"
								},
								{
									"sTitle": "RemainingDays"
								},
								{
									"sTitle": "InstalledDate"
								},
								{
									"sTitle": "EmailID"
								},
								{
									"sTitle": "PhoneNo"
								},
								{
									"sTitle": "UserName"
								},
								{
									"sTitle": "InstalledKeyID"
								},
								{
									"sTitle": "ServerSerialKey"
								},
								{
									"sTitle": "ClientUserID"
								},
								{
									"sTitle": "PCName"
								},
								{
									"sTitle": "MACAddress"
								},
								{
									"sTitle": "HDDAddress"
								},
								{
									"sTitle": "IPAddress"
								},
								{
									"sTitle": "Latitude"
								},
								{
									"sTitle": "Longitude"
								},
								{
									"sTitle": "Address"
								},
								{
									"sTitle": "IsBlocked"
								},
								{
									"sTitle": "ClientID"
								},
								{
									"sTitle": "SubscriptionDate"
								},
								{
									"sTitle": "SubscriptionType"
								},
								{
									"sTitle": "HasUnInstalled"
								},
								{
									"sTitle": "UnInstalledDate"
								},
								{
									"sTitle": "UnInstalledBy"
								}
							]
						});
					}

					$('#report').dataTable().fnAddData(mGridData);
				} else {
					alert("No records found.");
				}
			} else {
				alert("No records found.");
			}

			loader.style.display = "none";
		});
	}


	//reset input fields onclick
	 	 function reset_form()
		{
			console.log("reset button clicked.");
			// $('#com_edition').val('0');
			// $('#com_product').val('0');
			// $('#registered_dt').val('');
			// $('#maintenance_code').val('');
			// $('#serial_key').val('');
			// $('#mobile_no').val('');
			// $('#email_id').val('');
			$('#installationForm')[0].reset();
			// clear result grid
			if (oReport != null && oReport != "undefined")
			{
				$('#report').dataTable().fnClearTable();
			}

		}

	// $(document).ready(function() {
	// 	document.getElementById("com_product").selectedIndex = "0";
	// 	//$('#datetimepicker1').datetimepicker();
	// 	//$('#datetimepicker2').datetimepicker();	

	// });


</script>