<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-light-indigo elevation-2 d-flex flex-column position-fixed h-100">
	<!-- Brand Logo -->
	<a href="#" class="brand-link">
		<div class="row flex-column mr-auto">
			<img src="<?php echo base_url(); ?>dist/img/phoenix1.svg" alt="Prosoft Logo"
			class="brand-image elevation-0 w-25  align-self-center">
			<span class="brand-text font-weight-light ml-2  align-self-center" >Phoenix</span>
		</div>
		
	</a>

	<!-- Sidebar -->
	<div class="sidebar h-auto">
		<!-- Sidebar user panel (optional) -->
		<div class="user-panel mt-3 pb-3 mb-3 d-flex">
			<div class="image">
				<img src="<?php echo base_url(); ?>dist/img/avatar5.png" class="img-circle elevation-2" alt="User Image">
			</div>
			<div class="info">
				<a href="#" class="d-block"><?php echo $this->session->userdata('user_name'); ?></a>
			</div>
		</div>

		<!-- Sidebar Menu -->
		<nav class="mt-2">
			<ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
				<!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->

		
			   <?php
				if ($this->session->userdata('role_name') === "Admin" || $this->session->userdata('role_name') === "Support")
				 {
				?>
					<li class="nav-item">
						<a href="<?php echo base_url(); ?>index.php/CustomerCare_controller" class="nav-link">
							<i class="nav-icon fa fa-phone-square-alt"></i>
							<p>
								Customer Care
								<!--<span class="right badge badge-danger">New</span>-->
							</p>
						</a>
					</li>


					<!-- complaints -->
					<li class="nav-item">
						<a href="<?php echo base_url(); ?>index.php/complaints_controller" class="nav-link">
							<!-- <i class="nav-icon fa fa-phone-square-alt"></i> -->
							<i class="nav-icon fa fa-comments"></i>
							<p>
								Complaints
								<!--<span class="right badge badge-danger">New</span>-->
							</p>
						</a>
					</li>


					<li class="nav-item">
						<a href="<?php echo base_url(); ?>index.php/Installation_controller" class="nav-link">
							<i class="nav-icon fa fa-key"></i>
							<p>
								Installations
								<!--<span class="right badge badge-danger">New</span>-->
							</p>
						</a>
					</li>
				<?php
				}
				?>

				<?php 
				 if($this->session->userdata('role_name') === "Admin" || $this->session->userdata('role_name') === "Sales")
				{
				?>
					<li class="nav-item">
						<a href="<?php echo base_url(); ?>index.php/Contact_us_controller" class="nav-link">
							<i class="nav-icon fa fa-comment"></i>
							<p>
								Contact Us
							</p>
						</a>
					</li>

				<?php 
				}
				?>
					
				

				<?php
				if ($this->session->userdata('role_name') === "Admin" || $this->session->userdata('role_name') === "Sales") 
				{
				?>
					<li class="nav-item">
						<a href="<?php echo base_url(); ?>index.php/Download_controller" class="nav-link">
							<i class="nav-icon fa fa-download"></i>
							<p>
								Downloads
								<!--<span class="right badge badge-danger">New</span>-->
							</p>
						</a>
					</li>
				<?php
				}
				?>

				<?php
				if ($this->session->userdata('role_name') === "Admin" || $this->session->userdata('role_name') === "OfficeAdmin" ) 
				{
				?>
					<li class="nav-item has-treeview">
						<a href="#" class="nav-link">
							<i class="nav-icon fa fa-calculator"></i>
							<p>
								Invoice
								<i class="right fas fa-angle-down"></i>
							</p>
						</a>
						<ul class="nav nav-treeview">
							<li class="nav-item">
								<a href="<?php echo base_url(); ?>index.php/Invoice_controller/create_invoice" class="nav-link">
									<i class="nav-icon fa fa-plus ml-3"></i>
									<p>Create Invoice</p>
								</a>
							</li>
							<li class="nav-item">
								<a href="<?php echo base_url(); ?>index.php/Invoice_controller/edit_invoice_view" class="nav-link">
									<i class="nav-icon fa fa-edit ml-3"></i>
									<p>Edit Invoice</p>
								</a>
							</li>
							<li class="nav-item">
								<a href="<?php echo base_url(); ?>index.php/Invoice_controller" class="nav-link">
									<i class="nav-icon fa fa-eye ml-3"></i>
									<p>View Invoice</p>
								</a>
							</li>			
						</ul>
					</li>
					
					<li class="nav-item has-treeview">
						<a href="#" class="nav-link">
							<i class="nav-icon fa fa-paperclip"></i>
							<p>
								Quotation
								<i class="right fas fa-angle-down"></i>
							</p>
						</a>
						<ul class="nav nav-treeview">
							<li class="nav-item">
								<a href="<?php echo base_url(); ?>index.php/Quotation_controller/create_quotation" class="nav-link">
									<i class="nav-icon fa fa-plus ml-3"></i>
									<p>Create Quotation</p>
								</a>
							</li>
							<li class="nav-item">
								<a href="<?php echo base_url(); ?>index.php/Quotation_controller/revise_quotation" class="nav-link">
									<i class="nav-icon fa fa-edit ml-3"></i>
									<p>Revised Quotation</p>
								</a>
							</li>
							<li class="nav-item">
								<a href="<?php echo base_url(); ?>index.php/Quotation_controller" class="nav-link">
									<i class="nav-icon fa fa-eye ml-3"></i>
									<p>View Quotation</p>
								</a>
							</li>			
						</ul>
					</li>
					
				<?php
				}
				?>

				<?php
				if ($this->session->userdata('role_name') === "Admin" || $this->session->userdata('role_name') === "OfficeAdmin" ) {
				?>

					<!-- <li class="nav-item">
					<a href="<?php echo base_url(); ?>index.php/Userc/index" class="nav-link">
						<i class="nav-icon fas fa-tachometer-alt"></i>
						<p>
							Dashboard
							<span class="right badge badge-danger">New</span>
						</p>
					</a>
				</li> -->
					<li class="nav-item">
						<a href="<?php echo base_url(); ?>index.php/Payment/custom_reports" class="nav-link">
							<i class="nav-icon fa fa-money-bill-wave"></i>
							<p>
								RazorPay
								<!--<span class="right badge badge-danger">New</span>-->
							</p>
						</a>
					</li>
				<?php
				}
				?>

				<?php
					if ($this->session->userdata('role_name') === "Admin" || $this->session->userdata('role_name') === "Sales" ||$this->session->userdata('role_name') === "OfficeAdmin" ) {
				?>
					<li class="nav-item">
						<a href="<?php echo base_url(); ?>index.php/coupon_controller" class="nav-link">
							<i class="nav-icon fa fa-receipt"></i>
							<p>
								Coupon Codes
								<!--<span class="right badge badge-danger">New</span>-->
							</p>
						</a>
					</li>

				<?php
				}
				?>

				<?php
					if ($this->session->userdata('role_name') === "Admin" || $this->session->userdata('role_name') === "OfficeAdmin" ) {
				?>

					<li class="nav-item has-treeview">
						<a href="#" class="nav-link">
							<i class="nav-icon fa fa-business-time"></i>
							<p>
								Reports
								<i class="right fas fa-angle-down"></i>
							</p>
						</a>
						<ul class="nav nav-treeview">
							<!-- <li class="nav-item">
								<a href="<?php echo base_url(); ?>index.php/monthly_sales_controller" class="nav-link">
									<i class="nav-icon fa fa-calendar ml-3"></i>
									<p>Monthly Sales</p>
								</a>
							</li> -->

							<li class="nav-item">
								<a href="<?php echo base_url(); ?>index.php/monthly_sales_controller" class="nav-link">
									<i class="nav-icon fa fa-calendar ml-3"></i>
									<p>Monthly Sales</p>
								</a>
							</li>

							<li class="nav-item">
								<a href="<?php echo base_url(); ?>index.php/Invoice_controller/edit_invoice_view" class="nav-link">
									<i class="nav-icon fa fa-calendar ml-3"></i>
									<p>Monthly Quotations</p>
								</a>
							</li>
							<li class="nav-item">
								<a href="<?php echo base_url(); ?>index.php/Invoice_controller" class="nav-link">
									<i class="nav-icon fa fa-eye ml-3"></i>
									<p>Monthly Tax Report</p>
								</a>
							</li>


							<!-- <li class="nav-item">
								<a href="<?php echo base_url(); ?>index.php/coupon_controller" class="nav-link">
									<i class="nav-icon fa fa-eye ml-3"></i>
									<p>Coupon Report</p>
								</a>
							</li>			 -->
						</ul>
					</li>

				<?php
				}
				?>

			<?php
			 if($this->session->userdata('role_name') === "Admin")
			 {
			?>
			<li class="nav-item has-treeview">
						<a href="#" class="nav-link">
							<i class="nav-icon fa fa-cog"></i>
							<p>
								Setting
								<i class="right fas fa-angle-down"></i>
							</p>
						</a>
						
						<!-- user setting -->
						<ul class="nav nav-treeview">
							<li class="nav-item has-treeview">
								<a href="#" class="nav-link">
									<i class="nav-icon fas fa-user text-dark ml-3"></i>
									<p class="text-dark">
										Users
									<i class="right fas fa-angle-down"></i>
									</p>
								</a>

								<ul class="nav nav-treeview">

										<!-- create user -->
										<li class="nav-item">
											<a href="<?php echo base_url(); ?>index.php/user-create-user" class="nav-link">
												<i class="nav-icon fa fa-user-plus ml-4"></i>
												<p>
													Create User
												</p>
											</a>
										</li>

										<!-- update/delete user -->
										<li class="nav-item">
											<a href="<?php echo base_url(); ?>index.php/user-edit-delete-user" class="nav-link">
												<i class="nav-icon fas fa-user-minus ml-4"></i>
												<p>
													Edit/Delete User
												</p>
											</a>
										</li>
								</ul>
							</li>
						</ul>


						<!-- role setting -->
						<ul class="nav nav-treeview">
							<li class="nav-item has-treeview">
								<a href="#" class="nav-link">
									<i class="nav-icon fas fa-tasks text-dark ml-3"></i>
									<p class="text-dark">
										Roles
									<i class="right fas fa-angle-down"></i>
									</p>
								</a>

								<ul class="nav nav-treeview">

										<!-- create role -->
										<li class="nav-item">
											<a href="<?php echo base_url(); ?>index.php/role-create-role" class="nav-link">
												<i class="nav-icon fa  fa fa-plus ml-4"></i>
												<p>
													Create Role
												</p>
											</a>
										</li>

										<!-- update/delete role -->
										<li class="nav-item">
											<a href="<?php echo base_url(); ?>index.php/role-edit-delete-role" class="nav-link">
												<i class="nav-icon fas fa-trash-alt ml-4"></i>
												<p>
													Edit/Delete Role
												</p>
											</a>
										</li>
								</ul>
							</li>
						</ul>
						
			</li>
				
			<?php
			 }
			?>

				<li class="nav-item">
					<a href="<?php echo base_url(); ?>index.php/userc/signout" class="nav-link">
						<i class="nav-icon fa ion-power"></i>
						<p>
							Logout
							<!--<span class="right badge badge-danger">New</span>-->
						</p>
					</a>
				</li>
			</ul>
		</nav>
		<!-- /.sidebar-menu -->
	</div>

	<!-- <div class="user-panel mt-3 pb-3 mb-3 d-flex" style="border:1px solid black;">
	</div> -->

	<div class="container-fluid" style="margin-top:5rem;">
		<!-- <div class="row mt-3 pb-3 mb-3 d-flex"> -->
			<div class="row flex-column mr-auto position-absolute fixed-bottom">

				<!-- <a  href="https://prosoftesolutions.com"  target="_blank"> -->
					<img  src="<?php echo base_url(); ?>dist/img/Prosoft_LogoBlue.png"
						alt="Prosoft Logo" class="mt-2 mb-1 align-self-center" style="width:40%;">
				<!-- </a> -->
				<!-- <span>
					<h6>Prosoft e-Solutions India Pvt. Ltd.</h6>
				</span> -->
		<!-- </div> -->
	</div>
	<!-- /.sidebar -->
</aside>

<!-- jQuery -->
<script src="<?php echo base_url(); ?>plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url(); ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>


<!-- <script>
	$(document).ready(function(){
		var isclicked;
		//on button click
		$('#pushmenu').on('click',function(){
			console.log($('.main-sidebar').width());
			if($('.main-sidebar').width()==250)
			{
				$('.brand-text').hide();
				$('.main-sidebar .container-fluid').css('margin-top','2rem');
				isclicked=true;
				
			}
			else
			{
				$('.main-sidebar .container-fluid').css('margin-top','5rem');
				$('.brand-text').show();
				isclicked=false;
				
			}
			
		});


		//on hover sidebar
		$('.main-sidebar').on('mouseover',function(){
			if(isclicked==true)
			{
				$('.main-sidebar .container-fluid').css('margin-top','5rem');
				$('.brand-text').show();
			}
			
		});

		$('.main-sidebar').on('mouseout',function(){
			if(isclicked==true)
			{
				$('.brand-text').hide();
				$('.main-sidebar .container-fluid').css('margin-top','2rem');
			}
			
		});

		// $('.main-sidebar').on('mouseout',function(){
		// 	console.log("tested");
		// });
	});

</script> -->
