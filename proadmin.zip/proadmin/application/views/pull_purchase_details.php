	
	<?php
	
		//$servername = "localhost";
		//$username = "root";
		//$password = "";
		//$dbname = "prosoft_db";
		
		
		$servername = "localhost";
		$username = "prosoft";
		$password = "#Ack7H!S#Ack7H!S";
		$dbname = "prosoft_db"; 
		
		
		$from_timestamp = $_POST["from_timestamp"];
		$to_timestamp = $_POST["to_timestamp"];
		$top_records = $_POST["top_records"];		
		
		$jqxData = array();

		// Create connection
		$conn = new mysqli($servername, $username, $password, $dbname);
		// Check connection
		if ($conn->connect_error) {
		  die("Connection failed: " . $conn->connect_error);
		}

		$sql = "SELECT `id`, `full_name`, `contact_no`, `dept_email_id`, `department`, `designation`, `address`, `created_dt`, `serial_key`, `installed_dt`
				FROM tbl_user_info
				WHERE UNIX_TIMESTAMP(`created_dt`) BETWEEN ". $from_timestamp ." AND ". $to_timestamp ."
				LIMIT ". $top_records .""				
				;
				//WHERE `created_dt` >= ". $from_timestamp ." AND `created_dt` <= ". $to_timestamp ."
		$result = $conn->query($sql);

		if ($result->num_rows > 0) {
			// output data of each row
			while($row1 = $result->fetch_assoc()) {
				$jqxData[] = array('id' => $row1["id"], 'full_name' => $row1["full_name"], 'contact_no' => $row1["contact_no"], 
									'dept_email_id' => $row1["dept_email_id"], 'department' => $row1["department"], 'designation' => $row1["designation"], 
									'address' => $row1["address"], 'created_dt' => $row1["created_dt"], 'serial_key' => $row1["serial_key"], 'installed_dt' => $row1["installed_dt"]);
			}
			echo json_encode($jqxData);
		} else {
			echo json_encode(110);
		}
		$conn->close();
	?>