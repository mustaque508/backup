


<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <!-- if type is create -->
                    <?php 
                        if($type=="create")
                        {
                        ?>
                    <h1 class="m-0 text-dark">Create Role</h1>
                    <?php
                        }
                        ?>
                    <!-- if type is update_delete -->
                    <?php 
                        if($type=="update_delete")
                        {
                        ?>
                    <h1 class="m-0 text-dark">Edit/Delete Role</h1>
                    <?php
                        }
                        ?>
                </div>
                <!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <!-- if type is create -->
                        <?php 
                            if($type=="create")
                            {
                            ?>
                        <li class="breadcrumb-item active">Create Role</li>
                        <?php
                            }
                            ?>
                        <!-- if type is update_delete -->
                        <?php
                            if($type=="update_delete")
                            {
                            ?>
                        <li class="breadcrumb-item active">Edit/Delete Role</li>
                        <?php
                            }
                            ?>
                    </ol>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="card w-100">
                    <div class="card-body">
                        <form id="submit_form" class="form-group">
                            <!-- if type is update_delete -->
                            <?php
                                if($type=="update_delete")
                                {
                                ?>
                            <!-- select username -->
                            <div class="form-group mt-4 mb-4">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="row">
                                            <div class="d-flex align-items-center">
                                                <label for="select_role" class="h6 font-weight-normal">Select Role</label>
                                            </div>
                                            <div class="col-6 d-flex align-items-center">
                                                <select class="form-select form-control" id="select_role" name="select_role" value="<?php echo set_value('select_user');?>" required>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                                }
                                ?>
                            <!-- role name -->
                            <label for="name" class="h6 font-weight-normal">Role Name</label>
                            <div class="form-group">
                                <input type="text" class="form-control" id="role_name" name="role_name" value="<?php echo set_value('role_name');?>">
                                <span id="rolename_error" class="text-danger"></span>
                            </div>
                            <!-- module rights -->
                            <div class="form-group mt-4">
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th scope="col" class='d-none'>Role Id</th>
                                                <th scope="col">Module Name</th>
                                                <th scope="col" class="text-center">Read Access</th>
                                                <th scope="col" class="text-center">Write Access</th>
                                                <th scope="col" class="text-center">Delete Access</th>
                                                <th scope="col" class="d-none">Module Id</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td rowspan="21" id="role_id" class='d-none'></td>
                                            </tr>
                                            <?php
                                                foreach ($module_data as $value) 
                                                {
                                                ?>
                                            <tr class="access_details" style="cursor:pointer">
                                                <td id="module_name" style="cursor:auto"><?php echo $value->module_name;?></td>
                                                <td class="text-center"><input type="checkbox" id="read_access" name="read_access" value='<?php echo $value->module_id;?>'/></td>
                                                <td class="text-center"><input type="checkbox" id="write_access" name="write_access" value='<?php echo $value->module_id;?>'/></td>
                                                <td class="text-center"><input type="checkbox" id="delete_access" name="delete_access" value='<?php echo $value->module_id;?>'/></td>
                                                <td class="text-center d-none"><input type="checkbox" name="access_details"/></td>
                                                <!--checkbox validation -->
                                                <td id="module_id" class="d-none"><?php echo $value->module_id;?></td>
                                            </tr>
                                            <?php
                                                }
                                                ?>
                                        </tbody>
                                    </table>
                                </div>
                                <span id="access_details_error" class="text-danger"></span>
                            </div>
                            <!-- save button -->
                            <div class="col-sm-12">
                                <!-- if type is create -->
                                <?php
                                    if($type=="create")
                                    {
                                    ?>
                                <button type="submit" class="btn btn-success" id="form_submit">Save</button>
                                <?php
                                    }
                                    ?>
                                <!-- if type is update_delete -->
                                <?php
                                    if($type=="update_delete")
                                    {
                                    ?>
                                <button type="submit" class="btn btn-primary" id="form_submit">Update</button>
                                <button type="button" class="btn btn-danger" id="delete">Delete</button>
                                <?php
                                    }
                                    ?>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<!-- toaster.js -->
<script src="<?php echo base_url();?>dist/js/toasty.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url(); ?>dist/js/adminlte.js"></script>

<script>

//global variables
var array = [];
var read_access, write_access, delete_access, module_id;

//Type of operation
var opt_type = '<?php echo $type ?>';

//generate GUID[globally unique Identifier]
function createGUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    var r = Math.random() * 16 | 0,
      v = c == 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

// display GUID as a role_id
$(document).ready(function () {

  if (opt_type == "create") {
    var GUID = createGUID();
    $('#role_id').html(GUID);
    console.log(GUID);
  }

  if (opt_type == "update_delete") {
    // call function to get role_names
    get_role_names();
  }

});


//get access_details if type[create]
$('.table tbody .access_details').on('click', function () {


  $(this).find('input[name="read_access"]').each(function () {
    if ($(this).prop('checked') == true) {
      read_access = 1;
    }
    else if ($(this).prop('checked') == false) {
      read_access = 0;
    }
  });

  $(this).find('input[name="write_access"]').each(function () {
    if ($(this).prop('checked') == true) {
      write_access = 1;
    }
    else if ($(this).prop('checked') == false) {
      write_access = 0;
    }
  });

  $(this).find('input[name="delete_access"]').each(function () {
    if ($(this).prop('checked') == true) {
      delete_access = 1;
    }
    else if ($(this).prop('checked') == false) {
      delete_access = 0;
    }
  });


  array.push({
    'module_id': $(this).find("#module_id").text(),
    'read_access': read_access,
    'write_access': write_access,
    'delete_access': delete_access
  });

});


// automatically click checkbox when table[td] is clicked
$('.table tbody .access_details td').on('click',function(){
    var checkbox=$(this).find('input[type="checkbox"]');
   
    if(checkbox.prop('checked')==false)
    {
      checkbox.prop('checked',true);
    }
    else
    {
      checkbox.prop('checked',false);
    }
});

//get role_names [if type is update_delete]
function get_role_names() {

  // fetch role_names
  $.ajax({
    url: "<?php echo base_url(); ?>index.php/role/getrole_name",
    dataType: "json",
    success: function (response) {
      if (response != 110) {
        // display rolenames,role_id in select dropdownList
        var role_details = '<option value="">select option</option>';

        for (var index = 0; index < response.length; index++) {
          role_details += '<option value="' + response[index].role_id + '">' + response[index].role_name + '</option>';
        }
        $('#select_role').html(role_details);


      }
      else {
        alert("unable to fetch role names");
      }

    },

    // error occured when fetching rolenames
    error: function (error) {
      alert("unable to fetch role names");
    }
  });

}


// get role details based on selected role name
$('#select_role').change(function () {
  console.log($('#select_role option:selected').val());

  if ($('#select_role option:selected').val() == '') {
    //  reset all fields
    $('#rolename_error').html('');
    $('#access_details_error').html('');
    $('#submit_form')[0].reset();
    $('#form_submit').attr('disabled', false);
    return;
  }

  // initially set all checkbox to [unchecked]
  $('.table tbody .access_details').each(function () {
    $(this).find('input[type="checkbox"]').each(function () {
      $(this).prop("checked", false);
    });
  });

  $.ajax({
    type: "POST",
    url: "<?php echo base_url(); ?>index.php/role/getrole_details",
    dataType: "json",
    data: {
      'role_id': $('#select_role option:selected').val()
    },
    success: function (response) {
      if (response != 110) {
        console.log(response);

        for (var index = 0; index < response.length; index++) {
          // display role-name and role-id
          $('#role_name').val(response[index].role_name);
          $('#role_id').text(response[index].role_id);


          // display access_details
          $('.table tbody .access_details').each(function () {
            // [access_type="read_access"]
            $(this).find('#read_access').each(function () {
              if ($(this).val() == response[index].module_id) {

                if (response[index].read_access == 1) {
                  $(this).prop("checked", true);
                }
                else {
                  $(this).prop("checked", false);
                }
              }

            });


            // [access_type="write_access"]
            $(this).find('#write_access').each(function () {
              if ($(this).val() == response[index].module_id) {

                if (response[index].write_access == 1) {
                  $(this).prop("checked", true);
                }
                else {
                  $(this).prop("checked", false);
                }
              }


            });


            // [access_type="delete_access"]
            $(this).find('#delete_access').each(function () {
              if ($(this).val() == response[index].module_id) {

                if (response[index].delete_access == 1) {
                  $(this).prop("checked", true);
                }
                else {
                  $(this).prop("checked", false);
                }
              }
            });

          });

          array.push({
            'module_id': response[index].module_id,
            'read_access': response[index].read_access,
            'write_access': response[index].write_access,
            'delete_access': response[index].delete_access
          });

        }


      }
      else {
        alert("data not found based on selected role-name");
      }
    },

    // error occured when fetching role_details based on role_id
    error: function (error) {
      alert("unable to fetch role_details based on role-id");
    }
  });

});


// submit form
$('#submit_form').on('submit', function (event) {
  event.preventDefault();

  // // Display the list of array objects 
  //     console.log("before :" ,array); 

  // Declare a new array 
  var access_details = [];

  // Declare an empty object 
  var uniqueObject = {};

  // Loop for the array elements 
  for (var i in array) {

    // Extract the module_id 
    objTitle = array[i]['module_id'];

    // Use the module_id as the index 
    uniqueObject[objTitle] = array[i];
  }

  // Loop to push unique object into array 
  for (i in uniqueObject) {


    if (opt_type == "create") {
      // check if [read_access==write_access==delete_access==0] then don't store this values
      if (!(uniqueObject[i].read_access == 0 && uniqueObject[i].write_access == 0 && uniqueObject[i].delete_access == 0)) {
        access_details.push(uniqueObject[i]);
      }
    }

    if (opt_type == "update_delete") {
      access_details.push(uniqueObject[i]);
    }


  }


  // Display the list of array objects 
  console.log("after :", access_details);


  //store role details in database
  $.ajax({
    type: 'POST',
    url: "<?php echo base_url(); ?>index.php/role/storeData",
    dataType: "json", //important 
    data: {
      'role_name': $('#role_name').val(),
      'role_id': $('#role_id').text(),
      'access_details': access_details,
      'Type': opt_type
    },
    success: function (data) {
      if (data.success) {
        // reset errors
        $('#rolename_error').html('');
        $('#access_details_error').html('');

        // successfully saved
        if (data.response == 201) {
          //reset form and intialize array to empty
          $('#submit_form')[0].reset();
          array = [];


          //regenerate GUID if type is [create]
          if (opt_type == "create") {
            var GUID = createGUID();
            $('#role_id').html(GUID);
          }

          // recall function[get get_role_names()]
          if (opt_type == "update_delete") {
            get_role_names();
          }

          var options = {
            autoClose: true,
            progressBar: true
          }

          var toast = new Toasty(options);
          toast.configure(options);

          if (opt_type == "create") {
            toast.success("Your record saved successfully");
          }

          if (opt_type == "update_delete") {
            toast.success("Your record updated successfully");
          }


        }

        // failed to save
        else if (data.response == 110) {
          var options = {
            autoClose: true,
            progressBar: true
          }

          var toast = new Toasty(options);
          toast.configure(options);

          if (opt_type == "create") {
            toast.error("Sorry !!!! Unable to save your record..");
          }

          if (opt_type == "update_delete") {
            toast.error("Sorry !!!! Unable to update your record..");
          }

        }

      }

      else if (data.error) {
        $('#form_submit').attr('disabled', true);
        // name-error
        if (data.rolename_error != '') {
          $('#rolename_error').html(data.rolename_error);
          $('#role_name').keyup(function () {
            $('#form_submit').attr('disabled', false);
          });
        }
        else {
          $('#rolename_error').html('');
        }


        if (data.access_details_error != '') {
          $('#access_details_error').html(data.access_details_error);
          $('input[type="checkbox"]').change(function () {
            $('#form_submit').attr('disabled', false);
          });
        }
        else {
          $('#access_details_error').html('');
        }


      }

    },

    // if error occured
    error: function (error) {
      console.log("error : ", error);
    }
  });

});


// delete role
$('#delete').on('click', function () {
  if ($('#select_role').val() == '') {
    $('#select_role')[0].setCustomValidity("Please select an item in the list");
    $('#select_role')[0].reportValidity();
  }
  else {
    console.log($('#select_role option:selected').val());
    var cofirmation = confirm(" Are you sure ? ");

    if (cofirmation == true) {
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>index.php/role/deleteRecord",
        dataType: "json",
        data: {
          'role_id': $('#select_role option:selected').val()
        },
        success: function (response) {
          console.log(response);
          //success
          if (response == 201) {
            var options = {
              autoClose: true,
              progressBar: true
            }

            var toast = new Toasty(options);
            toast.configure(options);
            toast.success("Your record deleted successfully");
            console.log('success');

            $('#submit_form')[0].reset();

            // recall function[get get_role_names()]
            get_role_names();

          }
          //fail
          else if (response == 110) {
            var options = {
              autoClose: true,
              progressBar: true
            }

            var toast = new Toasty(options);
            toast.configure(options);
            toast.error("Sorry !!!! Unable to delete your record..");
            console.log('fail');
          }

        },
        error: function (error) {
          console.log(error);
        }
      });
    }

  }

  event.preventDefault();
});

</script>