<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Purchase</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Purchase</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
			<div class="row">
				<div class="col-lg-6 col-6">
					<div class="form-group">
					  <label>From:</label>
					  <div class="input-group">
						<div class="input-group-prepend">
						  <span class="input-group-text"><i class="far fa-clock"></i></span>
						</div>
						<input type="text" class="form-control float-right" id="registered_dt">
					  </div>
					  <!-- /.input group -->
					</div>
				</div>
				<div class="col-lg-6 col-6">
					<div class="form-group">
					  <label>Top Records :</label>
					  <div class="input-group">						
						<input type="text" class="form-control" id="top_records" name="top_records"/>
					  </div>
					  <!-- /.input group -->
					</div>
				</div>
			</div>
			<div class="row">				
				<div class="col-lg-6 col-6">					
					<button type="button" class="btn btn-primary" id="btn_search" name="btn_search" onclick="onSearchClick()">Search</button>					
				</div>
			</div>
			<br>
			<div class="row">
				<section class="col-lg-12 connectedSortable">
					<!-- Custom tabs (Charts with tabs)-->
					<div class="card">
					  <div class="card-header">
						<h3 class="card-title">
						  <i class="nav-icon fa fa-bell"></i>
						  Purchases List
						</h3>
						<div class="card-tools">
						  <button type="button" class="btn btn-tool" data-card-widget="collapse">
							<i class="fas fa-minus"></i>
						  </button>               
						  <!--
						  <button type="button" class="btn btn-tool" data-card-widget="remove">
							<i class="fas fa-times"></i>
						  </button>
						  -->
						</div>
					  </div><!-- /.card-header -->
					  <div class="card-body">
						<table id="purchase_details" class="table table-striped table-bordered" style="cursor:pointer">											
						</table>
					  </div><!-- /.card-body -->
						<div id="loader" class="overlay" style="display: none;">
							<i class="fas fa-3x fa-sync-alt fa-spin"></i>
							<div class="text-bold pt-2">Loading please wait ...</div>
							<br><br>
						</div>
					</div>
					<!-- /.card -->
				</section>			  
			</div>	
		</div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  
	<!-- jQuery -->
	<script src="<?php echo base_url(); ?>plugins/jquery/jquery.min.js"></script>	
	<!-- Bootstrap 4 -->
	<script src="<?php echo base_url(); ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>	
	<!-- overlayScrollbars -->
	<script src="<?php echo base_url(); ?>plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
	<!-- AdminLTE App -->
	<script src="<?php echo base_url(); ?>dist/js/adminlte.js"></script>
	<!-- InputMask -->
	<script src="<?php echo base_url(); ?>plugins/moment/moment.min.js"></script>
	<script src="<?php echo base_url(); ?>plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>
	<!-- date-range-picker -->
	<script src="<?php echo base_url(); ?>plugins/daterangepicker/daterangepicker.js"></script>	
	
	<!-- DataTables -->
	<script src="<?php echo base_url(); ?>plugins/datatables/jquery.dataTables.min.js"></script>
	<script src="<?php echo base_url(); ?>plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
	<script src="<?php echo base_url(); ?>plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
	<script src="<?php echo base_url(); ?>plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>

	<script type="text/javascript">		
		var oTable;
				
		//Date range picker with time picker
		$('#registered_dt').daterangepicker({
		  timePicker: true,
		  timePickerIncrement: 1,
		  locale: {
			format: 'DD/MM/YYYY hh:mm A'
		  }
		})
		
		function toTimestamp(strDate){
			var datum = Date.parse(strDate);
			return datum/1000;
		}
		
		function onSearchClick() {
			
			var fromDateTime = $('#registered_dt').data('daterangepicker').startDate.format('YYYY-MM-DD hh:mm A');
			var toDateTime = $('#registered_dt').data('daterangepicker').endDate.format('YYYY-MM-DD hh:mm A');
			
			if (oTable != null && oTable != "undefined"){
				$('#purchase_details').dataTable().fnClearTable();
			}
			
			var fromDateTimeUnixValue = 0;
			var toDateTimeUnixValue = 0;
			
			if(fromDateTime){
				fromDateTimeUnixValue = toTimestamp(fromDateTime);
			} else {
				alert("Please select from date first.");
				return;
			}
			
			if(toDateTime){
				toDateTimeUnixValue = toTimestamp(toDateTime);
			} else {
				alert("Please select to date first.");
				return;
			}
			
			//alert(fromDateTimeUnixValue + " " + toDateTimeUnixValue);
			
			var top_records = document.getElementById("top_records").value;
			if (top_records === null || top_records === "" || top_records === "undefined"){
				top_records = 50;
			}
			
			var loader = document.getElementById("loader");
			loader.style.display = "block";
			
			$.ajax({ 
			   type: "GET", 			   
			   url: "<?php echo base_url(); ?>index.php/Purchase/get_all_purchases",
			   data: { "top_records" : top_records, "from_timestamp" : fromDateTimeUnixValue, "to_timestamp" : toDateTimeUnixValue  }
			}).done(function( data ) {
				if (data != 110){
					var json_obj = jQuery.parseJSON(data);
					if (json_obj.length > 0){							
						var mGridData = [];	
						for(var row = 0; row < json_obj.length; row++){						
							var id = json_obj[row].id; 
							var full_name = json_obj[row].full_name; 
							var contact_no = json_obj[row].contact_no; 
							var dept_email_id = json_obj[row].dept_email_id; 
							var department = json_obj[row].department; 
							var designation = json_obj[row].designation; 
							var address = json_obj[row].address; 
							var created_dt = json_obj[row].created_dt; 
							var serial_key = json_obj[row].serial_key; 
							var installed_dt = json_obj[row].installed_dt;
							var status = json_obj[row].status;
							var razorpay_order_id = json_obj[row].razorpay_order_id;
							
							mGridData.push([(row + 1), id, full_name, contact_no, dept_email_id, department, designation, address, created_dt, serial_key, installed_dt, status, razorpay_order_id]);
						}	

						if (oTable == null || oTable == "undefined"){
							oTable = $('#purchase_details').dataTable( {
								
								"sScrollX": "100%",
								"sScrollXInner": "110%",
																	
								"initComplete": function () {
									$("#purchase_details").on("click", "tr[role='row']", function(){
										$("#purchase_details tbody tr").removeClass('row_selected');        
										$(this).addClass('row_selected');
						
										//var index = $(this).index();
										var selected_razorpay_order_id = $(this).children('td:last-child').text();
										window.location.href = "<?php echo base_url(); ?>index.php/Payment?razorpay_order_id=" + selected_razorpay_order_id + "";
									});
								},
								"aoColumns": [
									{ "sTitle": "Sl No" },
									{ "sTitle": "ID", "visible": false }, 
									{ "sTitle": "Full Name" }, 
									{ "sTitle": "Contact No" }, 
									{ "sTitle": "Dept Email ID" }, 
									{ "sTitle": "Department" }, 
									{ "sTitle": "Designation" }, 
									{ "sTitle": "Address" }, 
									{ "sTitle": "Created_dt" }, 
									{ "sTitle": "Serial Key" }, 
									{ "sTitle": "Installed DT" },
									{ "sTitle": "Status" },
									{ "sTitle": "RazorPay Order ID" }
								]
							} );
						}
													
						$('#purchase_details').dataTable().fnAddData(mGridData);
					}else{
						alert("No records found.");
					}
				}else{
					alert("No records found.");
				}
				
				loader.style.display = "none";
			});
		}
		
		$(document).ready(function() {

			//$('#datetimepicker1').datetimepicker();
			//$('#datetimepicker2').datetimepicker();					
			
		} );
	</script>