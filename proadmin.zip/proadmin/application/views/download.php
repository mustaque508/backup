<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<div class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark">Downloads</h1>
				</div><!-- /.col -->
				<div class="col-sm-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item"><a href="#">Home</a></li>
						<li class="breadcrumb-item active">Downloads</li>
					</ol>
				</div><!-- /.col -->
			</div><!-- /.row -->
		</div><!-- /.container-fluid -->
	</div>
	<!-- /.content-header -->

	<!-- Main content -->
	<section class="content">
		<div class="container-fluid">
			<div class="card">
				<div class="card-header">
					<h3 class="card-title">Search by</h3>
					<div class="card-tools">
						<button type="button" class="btn btn-tool" data-card-widget="collapse">
							<i class="fas fa-minus"></i>
						</button>
					</div>
				</div>
				<div class="card-body">
					<div class="row">								
						<!-- <div class="col-md-3">
							<div class="form-group">
								<label>Product</label>
								<select class="form-control form-control-sm float-right" id="com_product" name="com_product">
									<?php 
										foreach ($products->result_array() as $row)
										{
											echo "<option value='".$row['Product_Name']."'>".$row['Product_Name'] ."</option>";	
										}	
									?>
								</select>
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<label>Edition</label>
								<select class="form-control form-control-sm float-right" id="com_edition" name="com_edition">																				
								</select>
							</div>
						</div> -->
						<div class="col-md-6">
							<div class="form-group">
								<label>Download's Period:</label>
								<div class="input-group">
									<div class="input-group-prepend">
										<span class="input-group-text"><i class="far fa-clock"></i></span>
									</div>
									<input type="text" class="form-control form-control-sm float-right" id="registered_dt">
								</div>
								<!-- /.input group -->
							</div>
						</div>

						<div class="col-md-6">
							<div class="form-group">
								<input type="checkbox" id="chktrial" name="chktrial">
								<label for="chktrial">
									Trial Downloads
								</label>
							</div>
							<div class="form-group">
								<input  type="checkbox" id="chkpurchased" name="chkpurchased">
								<label for="chkpurchased">
									Purchased Online
								</label>
							</div>
						</div>

					</div>
				</div>
				<div class="card-footer">
					<div class="col-lg-6 col-6">
						<button type="button" class="btn btn-primary" id="btn_search" name="btn_search" onclick="onSearchClick()">Search</button>
						<!-- reset button -->
						<button type="button" class="btn btn-primary ml-1" id="btn_reset" name="btn_reset" onclick="reset_form()">Reset</button>
					</div>					
				</div>
			</div>
			<!-- <div class="row">

			</div> -->

			<div class="row">
				<section class="col-lg-12 connectedSortable">
					<!-- Custom tabs (Charts with tabs)-->
					<div class="card">
						<div class="card-header">
							<h3 class="card-title">
								<!-- <i class="nav-icon fa fa-bell"></i> -->
								Downloads List
							</h3>
							<div class="card-tools">
								<button type="button" class="btn btn-tool" data-card-widget="collapse">
									<i class="fas fa-minus"></i>
								</button>
								<!--
						  <button type="button" class="btn btn-tool" data-card-widget="remove">
							<i class="fas fa-times"></i>
						  </button>
						  -->
							</div>
						</div><!-- /.card-header -->
						<div class="card-body">
							<!-- <table id="purchase_details" class="table-md table-striped table-bordered" style="cursor:pointer">
							</table> -->


							<table id="purchase_details" 
							class="table-sm table-striped table-bordered table-hover dataTable dtr-inline" 
							role="grid" 
							style="cursor:pointer">
							</table>

						</div><!-- /.card-body -->
						<div id="loader" class="overlay" style="display: none;">
							<i class="fas fa-3x fa-sync-alt fa-spin"></i>
							<div class="text-bold pt-2">Loading please wait ...</div>
							<br><br>
						</div>
					</div>
					<!-- /.card -->
				</section>
			</div>
		</div><!-- /.container-fluid -->
	</section>
	<!-- /.content -->
</div>
<!-- /.content-wrapper -->

<!-- jQuery -->
<script src="<?php echo base_url(); ?>plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url(); ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- overlayScrollbars -->
<script src="<?php echo base_url(); ?>plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url(); ?>dist/js/adminlte.js"></script>
<!-- InputMask -->
<script src="<?php echo base_url(); ?>plugins/moment/moment.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>
<!-- date-range-picker -->
<script src="<?php echo base_url(); ?>plugins/daterangepicker/daterangepicker.js"></script>

<!-- DataTables -->
<script src="<?php echo base_url(); ?>plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>

<script type="text/javascript">
	var oTable;

	//Date range picker with time picker
	$('#registered_dt').daterangepicker({
		timePicker: true,
		timePickerIncrement: 1,
		locale: {
			format: 'DD/MM/YYYY hh:mm A'
		}
	})

	function toTimestamp(strDate) {
		var datum = Date.parse(strDate);
		return datum / 1000;
	}

	$('#com_product').change(function(){
		var selectedProductName = $(this).val(); 
		//alert(cust_id);

		var select = document.getElementById("com_edition");
		select.options.length = 0;

		$.ajax({ 
			type: "GET", 			   
			url: "<?php echo base_url(); ?>index.php/Product_controller/get_product_editions",
			data: { 
				// Customer Information
				"product_name" : selectedProductName
			}
		}).done(function( data ) {
			if (data != 110){
				var json_obj = jQuery.parseJSON(data);
				if (json_obj.length > 0){
					for(var i=0; i<json_obj.length; i++){
						var option = document.createElement("option");
						option.value = json_obj[i].Edition;
						option.text = json_obj[i].Edition;
						select.appendChild(option);
					}
				}
			}
		});
	})	

	function onSearchClick() {

		var fromDateTime = $('#registered_dt').data('daterangepicker').startDate.format('YYYY-MM-DD hh:mm A');
		var toDateTime = $('#registered_dt').data('daterangepicker').endDate.format('YYYY-MM-DD hh:mm A');
		
		var onlytrial = document.getElementById("chktrial").checked;
		var onlypurchased = document.getElementById("chkpurchased").checked;

		if (oTable != null && oTable != "undefined") {
			$('#purchase_details').dataTable().fnClearTable();
		}

		var fromDateTimeUnixValue = 0;
		var toDateTimeUnixValue = 0;

		if (fromDateTime) {
			fromDateTimeUnixValue = toTimestamp(fromDateTime);
		} else {
			alert("Please select from date first.");
			return;
		}

		if (toDateTime) {
			toDateTimeUnixValue = toTimestamp(toDateTime);
		} else {
			alert("Please select to date first.");
			return;
		}

		// var selProduct = document.getElementById("com_product");
		// var selProductValue = selProduct.options[selProduct.selectedIndex].value;

		// var selEdition = document.getElementById("com_edition");
		// var selEditionValue = selEdition.options[selEdition.selectedIndex].value;

		//alert(fromDateTimeUnixValue + " " + toDateTimeUnixValue);		

		var loader = document.getElementById("loader");
		loader.style.display = "block";

		$.ajax({
			type: "GET",
			url: "<?php echo base_url(); ?>index.php/Download_controller/get_downloads_by_status",
			data: {

				"from_timestamp": fromDateTime,
				"to_timestamp": toDateTime,
				"onlytrial": onlytrial,
				"onlypurchased": onlypurchased
			}
		}).done(function(data) {
			if (data != 110) {
				var json_obj = jQuery.parseJSON(data);
				if (json_obj.length > 0) {
					var mGridData = [];
					for (var row = 0; row < json_obj.length; row++) {
						var id = json_obj[row].id;
						var full_name = json_obj[row].full_name;
						var contact_no = json_obj[row].contact_no;
						var dept_email_id = json_obj[row].dept_email_id;
						var department = json_obj[row].department;
						var designation = json_obj[row].designation;
						var address = json_obj[row].address;
						var created_dt = json_obj[row].created_dt;
						var serial_key = json_obj[row].serial_key;
						var installed_dt = json_obj[row].installed_dt;
						var status = json_obj[row].status;
						var razorpay_order_id = json_obj[row].razorpay_order_id;

						mGridData.push([(row + 1), id, full_name, contact_no, dept_email_id, department, designation, address, created_dt, serial_key, installed_dt, status, razorpay_order_id]);
					}

					if (oTable == null || oTable == "undefined") {
						oTable = $('#purchase_details').dataTable({

							"sScrollX": "100%",
							"sScrollXInner": "110%",

							"initComplete": function() {
								$("#purchase_details").on("click", "tr[role='row']", function() {
									// $("#purchase_details tbody tr").removeClass('row_selected');
									// $(this).addClass('row_selected');

									// //var index = $(this).index();
									// var selected_razorpay_order_id = $(this).children('td:last-child').text();
									// window.location.href = "<?php echo base_url(); ?>index.php/Payment?razorpay_order_id=" + selected_razorpay_order_id + "";
								});
							},
							"aoColumns": [{
									"sTitle": "Sl No"
								},
								{
									"sTitle": "ID",
									"visible": false
								},
								{
									"sTitle": "Full Name"
								},
								{
									"sTitle": "Contact No"
								},
								{
									"sTitle": "Dept Email ID"
								},
								{
									"sTitle": "Department"
								},
								{
									"sTitle": "Designation"
								},
								{
									"sTitle": "Address"
								},
								{
									"sTitle": "Created_dt"
								},
								{
									"sTitle": "Serial Key"
								},
								{
									"sTitle": "Installed DT"
								},
								{
									"sTitle": "Status"
								},
								{
									"sTitle": "RazorPay Order ID"
								}
							]
						});
					}

					$('#purchase_details').dataTable().fnAddData(mGridData);
				} else {
					alert("No records found.");
				}
			} else {
				alert("No records found.");
			}

			loader.style.display = "none";
		});
	}

	$(document).ready(function() {
		document.getElementById("com_product").selectedIndex = "-1";
		//$('#datetimepicker1').datetimepicker();
		//$('#datetimepicker2').datetimepicker();					

	});

	//form reset
	function reset_form() 
	{
		$('#registered_dt').val('');
		console.log("reset button clicked...");

	}

</script>