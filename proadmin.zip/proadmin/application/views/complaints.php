
<div class="content-wrapper">
    <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">Complaints</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active">Complaints</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
    </div>

    <section class="content">
        <div class="container-fluid">
            <div class=row>
				<div class="col-md-12">
					<div class="card">
						<div class="card-header">
							<h3 class="card-title">Search</h3>
							<div class="card-tools">
								<button type="button" class="btn btn-tool" data-card-widget="collapse">
									<i class="fas fa-minus"></i>
								</button>
							</div>
						</div>
						<div class="card-body ">
							<div class="row">
								<div class="col-sm">
									<div class="form-group">
										<label>Complaint No:</label>
										<div class="input-group ">
											<input type="text" class="form-control form-control-sm " id="complaintno" name="complaintno" />
										</div>
									</div>
								</div>

                                <div class="col-sm">
									<div class="form-group">
										<label>Username:</label>
										<div class="input-group ">
											<input type="text" class="form-control form-control-sm " id="username" name="username" />
										</div>
									</div>
								</div>

								<div class="col-sm">
									<div class="form-group">
										<label>Serial Key:</label>
										<div class="input-group ">
											<input type="text" class="form-control form-control-sm" id="serialkey" name="serialkey" />
										</div>
									</div>
								</div>

								<div class="col-sm">
									<div class="form-group">
										<label>Contact No:</label>
										<div class="input-group ">
											<input type="tel" class="form-control form-control-sm" id="contact_no" name="contact_no" />
										</div>
									</div>
								</div>

								<div class="col-sm">
									<div class="form-group">
										<label>From date and time:</label>
											<div class="input-group">
												<div class="input-group-prepend">
													<span class="input-group-text"><i class="far fa-clock"></i></span>
												</div>
												<input type="text" class="form-control form-control-sm float-right" id="from_timestamp">
											</div>
									</div>
								</div>
								<!-- <div class="col-sm">
									<div class="form-group">
										<label>To date and time:</label>
										<div class="input-group ">
											<input type="datetime-local" class="form-control form-control-sm" id="to_timestamp" name="to_timestamp" ></input>								
										</div>
									</div>
								</div> -->
							</div>
						</div>
						<div class="card-footer">
							<div class="row">
								<div class="col-sm-6">
									<button type="button" class="btn btn-primary" id="btn_search" name="btn_search" onclick="onSearchClick()">Search</button>		
								<!-- reset button -->
									<button type="button" class="btn btn-primary ml-1" id="btn_reset" name="btn_reset" onclick="reset_form()">Reset</button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

            <!-- result -->
			<div class="row">
				<section class="col-lg-12 connectedSortable">
					<!-- Custom tabs (Charts with tabs)-->
					<div class="card">
						<div class="card-header">
							<h3 class="card-title">
								<!-- <i class="nav-icon fa fa-bell"></i> -->
								Result
							</h3>
							<div class="card-tools">
								<button type="button" class="btn btn-tool" data-card-widget="collapse">
									<i class="fas fa-minus"></i>
								</button>
								<!--
						  <button type="button" class="btn btn-tool" data-card-widget="remove">
							<i class="fas fa-times"></i>
						  </button>
						  -->
							</div>
						</div><!-- /.card-header -->
						<div class="card-body reset_grid">
							<table id="report" 
							class="table-sm table-striped table-bordered table-hover dataTable dtr-inline" 
							role="grid" 
							style="cursor:pointer">
							</table>
						</div><!-- /.card-body -->
						<div id="loader" class="overlay" style="display: none;">
							<i class="fas fa-3x fa-sync-alt fa-spin"></i>
							<div class="text-bold pt-2">Loading please wait ...</div>
							<br><br>
						</div>
					</div>
					<!-- /.card -->
				</section>
			</div>

			   <!-- complaint_history -->
			   <div class="row">
				<section class="col-lg-12 connectedSortable">
					<!-- Custom tabs (Charts with tabs)-->
					<div class="card">
						<div class="card-header">
							<h3 class="card-title">
								<!-- <i class="nav-icon fa fa-bell"></i> -->
								Complaint history
							</h3>
							<div class="card-tools">
								<button type="button" class="btn btn-tool" data-card-widget="collapse">
									<i class="fas fa-minus"></i>
								</button>
								<!--
						  <button type="button" class="btn btn-tool" data-card-widget="remove">
							<i class="fas fa-times"></i>
						  </button>
						  -->
							</div>
						</div><!-- /.card-header -->
						<div class="card-body reset_grid">
							<table id="history_report" 
							class="table-sm table-striped table-bordered table-hover dataTable dtr-inline" 
							role="grid" 
							style="cursor:pointer">
							</table>
						</div><!-- /.card-body -->
						<div id="loader" class="overlay" style="display: none;">
							<i class="fas fa-3x fa-sync-alt fa-spin"></i>
							<div class="text-bold pt-2">Loading please wait ...</div>
							<br><br>
						</div>
					</div>
					<!-- /.card -->
				</section>
			</div>

			<!-- modal -->
			<div class="modal fade" id="myModal" role="dialog">
				<div class="modal-dialog">

					<!-- Modal content-->
					<div class="modal-content">
						<div class="modal-header">
							<!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->
							<h4 class="modal-title">Action</h4>
						</div>
						<div class="modal-body">

						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal" id="modal">Close</button>
						</div>
					</div>

				</div>
			</div>

        </div>
    </section>
</div>

<!-- jQuery -->
<script src="<?php echo base_url(); ?>plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url(); ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- overlayScrollbars -->
<script src="<?php echo base_url(); ?>plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url(); ?>dist/js/adminlte.js"></script>
<!-- InputMask -->
<script src="<?php echo base_url(); ?>plugins/moment/moment.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>
<!-- date-range-picker -->
<script src="<?php echo base_url(); ?>plugins/daterangepicker/daterangepicker.js"></script>

<!-- DataTables -->
<script src="<?php echo base_url(); ?>plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>


<!-- toaster.js -->
<script src="<?php echo base_url();?>dist/js/toasty.js"></script>


<script type="text/javascript">

	// golbal variables
		var oReport;
		var used;
		var history_report;
		var complaintno;

		//Date range picker with time picker
		$('#from_timestamp').daterangepicker(
		{
			timePicker: true,
			timePickerIncrement: 1,
			locale: {
				format: 'DD/MM/YYYY hh:mm A'
		}
	});
	

	
	// search function for complaint
	function onSearchClick() 
	{
		if (oReport != null && oReport != "undefined") {
			$('#report').dataTable().fnClearTable();
		}

		complaintno = document.getElementById("complaintno").value;
		var username = document.getElementById("username").value;
		var serialkey = document.getElementById("serialkey").value;
		// var from_timestamp = moment(document.getElementById("from_timestamp").value).format('YYYY-MM-DD h:mm:ss a');
		var fromDateTime = $('#from_timestamp').data('daterangepicker').startDate.format('YYYY-MM-DD hh:mm A');
		var toDateTime = $('#from_timestamp').data('daterangepicker').endDate.format('YYYY-MM-DD hh:mm A');

		// check date input field is empty
		if($('#from_timestamp').val()==''){
			fromDateTime='';
			toDateTime='';
		}
		// var to_timestamp =  moment(document.getElementById("to_timestamp").value).format('YYYY-MM-DD h:mm:ss a');
		var contact_no = document.getElementById("contact_no").value;
		// var vendor_id = vendorid; //document.getElementById("vendor_id").value;
		// var isused = ischecked;//document.getElementById("checkbox").value;


		var loader = document.getElementById("loader");
		loader.style.display = "block";
	
		// console.log(fromDateTime);
		$.ajax({
			type: "GET",
			url: "<?php echo base_url(); ?>index.php/complaints_controller/get_data",
			data: {
				"complaintno": complaintno,
				"username": username,
				"serialkey": serialkey,
				"fromDateTime": fromDateTime,
				"toDateTime":toDateTime,
				"contact_no":contact_no

			}
		}).done(function(data) {

			// console.log(data);
			if (data != 110) {
				var json_obj = jQuery.parseJSON(data);
				if (json_obj.length > 0) {
					var mGridData = [];
					for (var row = 0; row < json_obj.length; row++) {

						var ComplaintNo = json_obj[row].ComplaintNo;

						var Comp_date_time = new moment(json_obj[row].Comp_date_time).format('DD-MM-YYYY h:mm:ss a');
						var Complaint = json_obj[row].Complaint;

						var Status = json_obj[row].Status==0 ? 'open' : 'close';
						var Name = json_obj[row].Name;

						var userid = json_obj[row].userid;
						var Serial_key = json_obj[row].Serial_key;
						var Contact = json_obj[row].Contact;
						var Email = json_obj[row].Email;

						// mGridData.push([(row + 1), userid,ComplaintNo, Complaint, Comp_date_time, 
						//  Status, Name, Email, Contact, Serial_key   
							
						// ]);

						mGridData.push([(row + 1),"<button type='button' onmouseover='disableonclick()' onmouseout='enableonclick()' class='btn btn-danger' id='action' name='action' onclick='take_action()'>Action</button>",ComplaintNo, Complaint, Comp_date_time, 
						 Status, Name, Email, Contact, Serial_key,userid   
							
						]);
					}


					if (oReport == null || oReport == "undefined") {
						oReport = $('#report').dataTable({

							"sScrollX": "100%",
							"sScrollXInner": "110%",

							"initComplete": function() {
								$("#report").on("click", "tr[role='row']", function() {
									//$("#report tbody tr").removeClass('row_selected');        
									//$(this).addClass('row_selected');

									////var index = $(this).index();
									//var selected_razorpay_order_id = $(this).children('td:last-child').text();
									//window.location.href = "<?php echo base_url(); ?>index.php/Payment?razorpay_order_id=" + selected_razorpay_order_id + "";
								});
							},
							"aoColumns": [{
									"sTitle": "Sl No"
								},
								{
									"sTitle": "Take Action",
									"sWidth": "12%"
								},
								{
									"sTitle": "Complaint No",
									"sWidth": "15%"
									
								},
								{
									"sTitle": "Complaint",
									"sWidth": "15%"
								},
								{
									"sTitle": "Complate Date_time",
									"sWidth": "25%"
								},
								{
									"sTitle": "Status",
									"sWidth": "10%"
									
								},
								{
									"sTitle": "User Name",
									"sWidth": "12%"
								},
								{
									"sTitle": "Email Id"
								},
								{
									"sTitle": "Contact No"
								},
								{
									"sTitle": "Serial Key"
								}
							
								
							]
						});
					}

					$('#report').dataTable().fnAddData(mGridData);
				} else {
					alert("No records found.");
				}
			} else {
				alert("No records found.");
			}

			loader.style.display = "none";
		});
	}


	//form reset
	function reset_form() 
	{
		$('#complaintno').val('');
		$('#username').val('');
		$('#serialkey').val('');
		$('#contact_no').val('');
		$('#from_timestamp').val('');
		// clear result grid
		if (oReport != null && oReport != "undefined")
		 {
			$('#report').dataTable().fnClearTable();
		 }

		//  clear complaint_history grid
		if (history_report != null && history_report != "undefined") {
			$('#history_report').dataTable().fnClearTable();
		}
		console.log("reset button clicked...");

	}

	// complaint history
	$('#report').on('click','tbody tr',function()
	{
		if (history_report != null && history_report != "undefined") {
			$('#history_report').dataTable().fnClearTable();
		}

			var complaint_no=$('#report').DataTable().row(this).data()[2];
			console.log("selected complaint_no : " +complaint_no);


			var loader = document.getElementById("loader");
			loader.style.display = "block";

			$.ajax({
			type: "GET",
			url: "<?php echo base_url(); ?>index.php/complaints_controller/get_complaint_history",
			data: {
				"complaint_no": complaint_no

			}
		}).done(function(data) {

			console.log(data);
			if (data != 110) {
				var json_obj = jQuery.parseJSON(data);
				if (json_obj.length > 0) {
					var mGridData = [];
					for (var row = 0; row < json_obj.length; row++) {

						var ComplaintNo = json_obj[row].ComplaintNo;

						var ActionTaken = json_obj[row].ActionTaken;

			
						var ActionDate = new moment(json_obj[row].ActionDate).format('MM-DD-YYYY h:mm:ss a');

						var ActionStatus = json_obj[row].ActionStatus;
						var Remark = json_obj[row].Remark;
					
						mGridData.push([(row + 1),ComplaintNo, ActionTaken, ActionDate, 
						ActionStatus, Remark
							
						]);
					}


					if (history_report == null || history_report == "undefined") {
						history_report = $('#history_report').dataTable({

							"sScrollX": "100%",
							"sScrollXInner": "110%",

							"initComplete": function() {
								$("#history_report").on("click", "tr[role='row']", function() {
									//$("#report tbody tr").removeClass('row_selected');        
									//$(this).addClass('row_selected');

									////var index = $(this).index();
									//var selected_razorpay_order_id = $(this).children('td:last-child').text();
									//window.location.href = "<?php echo base_url(); ?>index.php/Payment?razorpay_order_id=" + selected_razorpay_order_id + "";
								});
							},
							"aoColumns": [{
									"sTitle": "Sl No"
								},
								// {
								// 	"sTitle": "User Id", "sWidth":"1%"
								// },
								{
									"sTitle": "Complaint No",
								
								},
								{
									"sTitle": "ActionTaken"
								},
								{
									"sTitle": "ActionDate"
								},
								{
									"sTitle": "ActionStatus",
								
								},
								{
									"sTitle": "Remark",
								
								}
								
							]
						});
					}

					$('#history_report').dataTable().fnAddData(mGridData);
				} else {
					alert("No records found.");
				}
			} else {
				alert("No records found.");
			}

			loader.style.display = "none";
		
		});
	});



	

	// function loadModal(mGridData) {
	// 	var response = "<table border='1' width='100%'>";

	// 	// response += "<tr><td>ID : </td><td>" + mGridData[0][1] + "</td></tr>";
	// 	response += "<tr><td>User Id : </td><td>" + mGridData[0][1] + "</td></tr>";
	// 	response += "<tr><td>Complaint No : </td><td>" + mGridData[0][6] + "</td></tr>";
	// 	response += "<tr><td>Complaint : </td><td>" + mGridData[0][7] + "</td></tr>";
	// 	response += "<tr><td>Complate Date : </td><td>" + mGridData[0][8] + "</td></tr>";
	// 	response += "<tr><td>Status : </td><td>" + mGridData[0][8] + "</td></tr>";
	// 	response += "<tr><td>User Name : </td><td>" + mGridData[0][2] + "</td></tr>";
	// 	response += "<tr><td>Email Id : </td><td>" + mGridData[0][3] + "</td></tr>";
	// 	response += "<tr><td>Contact No : </td><td>" + mGridData[0][4] + "</td></tr>";
	// 	response += "<tr><td>Serial Key : </td><td>" + mGridData[0][5] + "</td></tr>";
	// 	// response += "<tr><td>SubscriptionName : </td><td>" + mGridData[0][7] + "</td></tr>";

	// 	/*
	// 	response += "<tr><td>InstalledKeyID : </td><td>"+ mGridData[0][14] +"</td></tr>"; 
	// 	response += "<tr><td>ServerSerialKey : </td><td>"+ mGridData[0][15] +"</td></tr>"; 
	// 	response += "<tr><td>ClientUserID : </td><td>"+ mGridData[0][16] +"</td></tr>"; 
	// 	response += "<tr><td>PCName : </td><td>"+ mGridData[0][17] +"</td></tr>"; 
	// 	response += "<tr><td>MACAddress : </td><td>"+ mGridData[0][18] +"</td></tr>"; 
	// 	response += "<tr><td>HDDAddress : </td><td>"+ mGridData[0][19] +"</td></tr>"; 
	// 	response += "<tr><td>IPAddress : </td><td>"+ mGridData[0][20] +"</td></tr>"; 
	// 	response += "<tr><td>Latitude : </td><td>"+ mGridData[0][21] +"</td></tr>"; 
	// 	response += "<tr><td>Longitude : </td><td>"+ mGridData[0][22] +"</td></tr>"; 
	// 	response += "<tr><td>Address : </td><td>"+ mGridData[0][23] +"</td></tr>"; 
	// 	response += "<tr><td>IsBlocked : </td><td>"+ mGridData[0][24] +"</td></tr>"; 
	// 	response += "<tr><td>ClientID : </td><td>"+ mGridData[0][25] +"</td></tr>"; 
	// 	response += "<tr><td>SubscriptionDate : </td><td>"+ mGridData[0][26] +"</td></tr>"; 
	// 	response += "<tr><td>SubscriptionType : </td><td>"+ mGridData[0][27] +"</td></tr>"; 
	// 	response += "<tr><td>HasUnInstalled : </td><td>"+ mGridData[0][28] +"</td></tr>"; 
	// 	response += "<tr><td>UnInstalledDate : </td><td>"+ mGridData[0][29] +"</td></tr>"; 
	// 	response += "<tr><td>UnInstalledBy : </td><td>"+ mGridData[0][30] +"</td></tr>"; 
	// 	*/

	// 	response += "</table>";

	// 	$('.modal-body').html(response);

	// 	// Display Modal
	// 	$('#myModal').modal('show');
	// }
	

	


	//take action
	function take_action() 
	{

		var current_date_time=moment(new Date()).format('DD-MM-YYYY h:mm:ss a');

		var response="<form method='post' onsubmit='submit_action(event)'><div class='row'>";

		response +="<div class='col-sm-3 mb-3'><label for='complaint_no'>Complaint No  </label></div>";
		response +="<div class='col-sm-9 mb-3'><input type='text' id='complaint_no' class='form-control' value='"+complaintno+"' readonly/></div>";
		response +="<div class='col-sm-3  mb-3'><label for='action_taken'>ActionTaken </label></div>";
		response +="<div class='col-sm-9 mb-3'><input type='text' class='form-control' id='action_taken' required/></div>";
		response +="<div class='col-sm-3  mb-3'><label for='current_date'>ActionDate </label></div>";
		response +="<div class='col-sm-9 mb-3'><input type='text' class='form-control' id='current_date' value='"+current_date_time+"'/></div>";
		response +="<div class='col-sm-3  mb-3'><label for='status'>ActionStatus </label></div>";
		response +="<div class='col-sm-9 mb-3'><select id='status' class='form-control' required><option value=''>Select option</option><option value='1'>Under Progress</option><option value='2'>Open</option><option value='3'>Closed</option></select></div>";
		response +="<div class='col-sm-3  mb-3'><label for='remark'>Remark</label></div>";
		response +="<div class='col-sm-9 mb-3'><input type='text' id='remark' class='form-control'/></div>";
		response +="<div class='col-sm-12 d-flex justify-content-center'><button type='submit' class='btn btn-success px-4' id='save'>Save</button></div>";
		response +="</div></form>";


		$('.modal-body').html(response);
		$('#myModal').modal('show');
	}

	// on mouseover [Action button]
	function disableonclick(){
		$('#report tbody tr').prop('disabled',true);
		
	}

	// on mouseout [Action button]
	function enableonclick(){
		$('#report tbody tr').prop('disabled',false);
	}

	//on mouseover[result grid] [get comaplint_no]
	$('#report').on('mouseover','tbody tr',function(){
			complaintno=$('#report').DataTable().row(this).data()[2];
	});	



	//submit Action form
		function submit_action(event)
		{
			$('#save').attr('disabled',true);
			event.preventDefault();
			

			// get user_details
				var complaint_no=document.getElementById("complaint_no").value;
				var action_taken=document.getElementById("action_taken").value;
				var action_date=document.getElementById("current_date").value;
				var e=document.getElementById("status");
				var action_status=e.options[e.selectedIndex].text;
				var remark=document.getElementById("remark").value;
				var user_id=$('#report').DataTable().row($('#report tbody tr')).data()[10];

				console.log("complaint_no : "+complaint_no);
				console.log("action_taken : "+action_taken);
				console.log("action_date : "+action_date);
				console.log("status : "+action_status);
				console.log("remark : "+remark);
				console.log("user id :" +user_id)
			
		
			$.ajax({
				type: "POST",
				url: "<?php echo base_url(); ?>index.php/complaints_controller/store_complaint_history",
				data: {
					"ComplaintNo":complaint_no,
					"ActionTaken":action_taken,
					"ActionDate":action_date,
					"ActionStatus":action_status,
					"Remark":remark,
					"userid":user_id
				},
				success:function(response){
					if(response==201)
					{
                        var options ={
                                        autoClose: true,
                                        progressBar: true
									 }
									 
                        var toast = new Toasty(options);
                        toast.configure(options);
                        toast.success("Your record saved successfully");
                        console.log("success");
						jQuery(function(){
							jQuery('#modal').click();
						});
                            
                                
					}
					else if(response==110){
						var options = {
                                        autoClose: true,
                                        progressBar: true
									  }
									  
                        var toast = new Toasty(options);
                        toast.configure(options);
                        toast.error("Sorry !!!! Unable to save your record..");
                        console.log("fail");
						jQuery(function(){
							jQuery('#modal').click();
						});
					}
				}

				
			});

		}



</script>