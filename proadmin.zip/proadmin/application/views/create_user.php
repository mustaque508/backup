


<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <!-- if type is create -->
                    <?php
                        if($type=="create")
                        {
                        ?>
                    <h1 class="m-0 text-dark">Create User</h1>
                    <?php
                        }
                        ?>
                    <!-- if type is update_delete -->
                    <?php
                        if($type=="update_delete")
                        {
                        ?>
                    <h1 class="m-0 text-dark">Edit/Delete User</h1>
                    <?php
                        }
                        ?>
                </div>
                <!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <!-- if type is create -->
                        <?php 
                            if($type=="create")
                            {
                            ?>
                        <li class="breadcrumb-item active">Create User</li>
                        <?php
                            }
                            ?>
                        <!-- if type is update_delete -->
                        <?php 
                            if($type=="update_delete")
                            {
                            ?>
                        <li class="breadcrumb-item active">Edit/Delete User</li>
                        <?php
                            }
                            ?>
                    </ol>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col">
                    <div class="card">
                        <div class="card-body">
                            <form id="submit_form" class="form-group ">
                                <!-- if type is update_delete -->
                                <?php
                                    if($type=="update_delete")
                                    {
                                    ?>
                                <!-- select username -->
                                <div class="form-group mt-4 mb-4">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="row">
                                                <div class="d-flex align-items-center">
                                                    <label for="select_user" class="h6 font-weight-normal">Select User</label>
                                                </div>
                                                <div class="col-6 d-flex align-items-center">
                                                    <select class="form-select form-control" id="select_user" name="select_user" value="<?php echo set_value('select_user');?>" required >
                                                        <!-- <option value="">select option</option> -->
                                                        <!-- <?php
                                                            foreach ($user_data as  $value) {
                                                                echo "<option value='" . $value->user_id . "'>" . $value->user_name . "</option>";
                                                            }
                                                            ?> -->
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                    }
                                    ?>
                                <!-- user name -->
                                <label for="name" class="h6 font-weight-normal">Your Name</label>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="name" name="name" value="<?php echo set_value('name');?>">
                                    <span id="name_error" class="text-danger"></span>
                                </div>
                                <!-- email -Id -->
                                <label for="email_id" class="h6 font-weight-normal">Email Address</label>
                                <div class="form-group">
                                    <input type="email" class="form-control" id="email_id" name="email_id" value="<?php echo set_value('email_id');?>" >
                                    <span id="email_error" class="text-danger"></span>
                                </div>
                                <!-- contact number -->
                                <label for="contact" class="h6 font-weight-normal">Contact Number</label>
                                <div class="form-group">
                                    <input type="tel" class="form-control" id="contact" name="contact" value="<?php echo set_value('contact');?>">
                                    <span id="contact_error" class="text-danger"></span>
                                    <span id="error" class="text-danger"></span>
                                </div>
                                <!-- roles -->
                                <label for="role" class="h6 font-weight-normal">Your role </label>
                                <div class="form-group">
                                    <select class="form-select form-control" id="role" name="role" value="<?php echo set_value('role');?>" >
                                        <option value="">select option</option>
                                        <?php
                                            foreach ($role_data as  $value) {
                                                echo "<option value='" . $value->role_id . "'>" . $value->role_name . "</option>";
                                            }
                                            ?>
                                    </select>
                                    <span id="role_error" class="text-danger"></span>
                                </div>
                                <!-- password -->
                                <label for="password" class="h6 font-weight-normal">Password</label>
                                <div class="form-group">
                                    <div class="input-group">
                                        <input type="password" id="password" class="form-control" name="password" value="<?php echo set_value('password');?>" >
                                        <div class="input-group-prepend d-flex align-items-center">
                                            <span class="input-group-text form-control">
                                            <i class="fa fa-info-circle" aria-hidden="true" style="color:#0A3FFF; cursor:pointer" id="pass_rules" data-toggle="popover" title=" The password must include" data-content></i>   
                                            </span>
                                        </div>
                                    </div>
                                    <span id="password_error" class="text-danger"></span>
                                </div>
                                <!-- password rules -->
                                <div class="hide" style="display:none;">
                                    <ul class="list-unstyled">
                                        <li>length should be minimum 8 characters.</li>
                                        <li>atleast one numeric character.</li>
                                        <li>atleast one Alphabetic letter.</li>
                                        <li>atleast one capital letter.</li>
                                        <li>one special character.</li>
                                        <li>should not contain white space.</li>
                                    </ul>
                                </div>
                                <!-- confirm-password -->
                                <label for="Cpassword" class="h6 font-weight-normal"> Confirm Password</label>
                                <div class="form-group">
                                    <input type="password" class="form-control" id="Cpassword" name="Cpassword" value="<?php echo set_value('Cpassword');?>" >
                                    <span id="cpassword_error" class="text-danger"></span>
                                </div>
                                <!-- save button -->
                                <div class="col-sm-12">
                                    <!-- if type is create -->
                                    <?php
                                        if($type=="create")
                                        {
                                        ?>
                                    <button type="submit" class="btn btn-success" id="form_submit">Save</button>
                                    <?php
                                        }
                                        ?>
                                    <!-- if type is update_delete -->
                                    <?php
                                        if($type=="update_delete")
                                        {
                                        ?>
                                    <button type="submit" class="btn btn-primary" id="form_submit" >Update</button>
                                    <button type="button" class="btn btn-danger" id="delete">Delete</button>
                                    <?php
                                        }
                                        ?>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div>


</section>
<!-- toaster.js -->
<script src="<?php echo base_url();?>dist/js/toasty.js"></script>

<!-- AdminLTE App -->
<script src="<?php echo base_url(); ?>dist/js/adminlte.js"></script>



<script>

//Type of operation
  var opt_type = '<?php echo $type ?>';

// popover for password rules
$(document).ready(function () {


  // show password rules
  $('#pass_rules').mouseover(function () {

    $('#pass_rules').attr('data-content', $('.hide').html());
    // $('[data-toggle="popover"]').css('border','1px solid black');
    $('#pass_rules').popover({
      html: true,
      placement: 'right'
    });
    $('#pass_rules').popover('show');
  });

  // hide password rules
  $('#pass_rules').mouseout(function () {
    $('#pass_rules').popover('hide');
  });

  if (opt_type == "update_delete") {
    // call function to get role_names
    get_user_names();
  }
});


//get role_names [if type is update_delete]
function get_user_names() {

  // fetch role_names
  $.ajax({
    url: "<?php echo base_url(); ?>index.php/user/getUserDetails",
    dataType: "json",
    success: function (response) {
      if (response != 110) {
        // display rolenames,role_id in select dropdownList
        var user_details = '<option value="">select option</option>';

        for (var index = 0; index < response.length; index++) {
          user_details += '<option value="' + response[index].user_id + '">' + response[index].user_name + '</option>';
        }
        $('#select_user').html(user_details);


      }
      else {
        alert("unable to fetch role names");
      }

    },

    // error occured when fetching rolenames
    error: function (error) {
      alert("unable to fetch role names");
    }
  });

}

// get user details based on selected user name
$('#select_user').change(function () {

  console.log($('#select_user option:selected').val());

  if ($('#select_user option:selected').val() == '') {
    //  reset all fields
    $('#name_error').html('');
    $('#email_error').html('');
    $('#contact_error').html('');
    $('#role_error').html('');
    $('#password_error').html('');
    $('#cpassword_error').html('');
    $('#submit_form')[0].reset();
    $('#form_submit').attr('disabled', false);
    return;
  }

  $.ajax({
    type: "POST",
    url: "<?php echo base_url(); ?>index.php/user/getData_id",
    data: {
      'user_id': $('#select_user option:selected').val()
    },
    success: function (response) {
      var json_obj = jQuery.parseJSON(response);
      if (json_obj.length > 0) {
        for (var row = 0; row < json_obj.length; row++) {
          $('#name').val(json_obj[row].user_name);
          $('#email_id').val(json_obj[row].email);
          $('#contact').val(json_obj[row].contact_no);
          $('#role').val(json_obj[row].role_id);
          $('#password').val(atob(json_obj[row].password)); //atob()=>base64 decode function in js
          $('#Cpassword').val(atob(json_obj[row].password)); //atob()=>base64 decode function in js
        }

      }
      else {
        alert("data not found based on selected name");
      }
    },
    error: function (error) {
      alert("SORRY !!!! unable to fech data based on selected name");
    }
  });
});

// submit form
$('#submit_form').on('submit', function (event) {


  //common function
  $.ajax({
    type: "POST",
    url: "<?php echo base_url(); ?>index.php/user/validateData",
    dataType: "json", //important 
    data: {
      'name': $('#name').val(),
      'email_id': $('#email_id').val(),
      'contact': $('#contact').val(),
      'role': $('#role').val(),
      'password': $('#password').val(),
      'Cpassword': $('#Cpassword').val(),
      'Type': opt_type,
      'user_id': $('#select_user option:selected').val()
    },
    success: function (data) {

      if (data.validation == true) {
        // reset errors
        $('#name_error').html('');
        $('#email_error').html('');
        $('#contact_error').html('');
        $('#role_error').html('');
        $('#password_error').html('');
        $('#cpassword_error').html('');

        //check contact error[countycode.js] is display=none?
        if ($('#error').css('display') == 'none') {
          $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>index.php/user/storeDetails",
            dataType: "json", //important
            data: {
              'name': $('#name').val(),
              'email_id': $('#email_id').val(),
              'contact': $('#contact').val(),
              'role': $('#role').val(),
              'password': $('#password').val(),
              'user_id': $('#select_user option:selected').val(),
              'Type': opt_type
            },
            success: function (data) {
              if (data.success) {
                // if($('#error').text()=='')
                // {
                //     $('#submit_form')[0].reset();
                // }

                $('#submit_form')[0].reset();

                // successfully saved
                if (data.response == 201) {
                  var options = {
                    autoClose: true,
                    progressBar: true
                  }

                  var toast = new Toasty(options);
                  toast.configure(options);

                  if (opt_type == "create") {

                    toast.success("Your record saved successfully");
                  }

                  if (opt_type == "update_delete") {
                    // recall function[get_user_names()]
                    get_user_names();

                    toast.success("Your record updated successfully");

                  }

                  console.log('success');
                }

                // failed to save
                if (data.response == 110) {
                  var options = {
                    autoClose: true,
                    progressBar: true
                  }

                  var toast = new Toasty(options);
                  toast.configure(options);

                  if (opt_type == "create") {
                    toast.error("Sorry !!!! Unable to save your record..");
                  }

                  if (opt_type == "update_delete") {
                    toast.error("Sorry !!!! Unable to update your record..");
                  }


                  console.log('fail');
                }

              }
            },
            error: function (error) {
              console.log(error);
            }
          });

        }

      }
      else if (data.error) {
        $('#form_submit').attr('disabled', true);

        // name-error
        if (data.name_error != '') {
          $('#name_error').html(data.name_error);
          $('#name').keyup(function () {
            $('#form_submit').attr('disabled', false);
          });
        }
        else {
          $('#name_error').html('');
        }


        // email-error
        if (data.email_error != '') {
          $('#email_error').html(data.email_error);
          $('#email_id').keyup(function () {
            $('#form_submit').attr('disabled', false);
          });
        }
        else {
          $('#email_error').html('');
        }

        // contact-error
        if (data.contact_error != '') {
          $('#contact_error').html(data.contact_error);
          $('#error').css('display', 'none');
          $('#contact').keyup(function () {
            $('#form_submit').attr('disabled', false);
          });
        }
        else {
          $('#contact_error').html('');
        }


        // role-error
        if (data.role_error != '') {
          $('#role_error').html(data.role_error);
          $('#role').change(function () {
            $('#form_submit').attr('disabled', false);
          });
        }
        else {
          $('#role_error').html('');
        }

        // password-error
        if (data.password_error != '') {
          $('#password_error').html(data.password_error);
          $('#password').keyup(function () {
            $('#form_submit').attr('disabled', false);
          });
        }
        else {
          $('#password_error').html('');
        }

        // confirm password-error
        if (data.cpassword_error != '') {
          $('#cpassword_error').html(data.cpassword_error);
          $('#Cpassword').keyup(function () {
            $('#form_submit').attr('disabled', false);
          });
        }
        else {
          $('#cpassword_error').html('');
        }
      }
    },
    error: function (error) {
      alert(error);
    }
  });
  event.preventDefault();

});


//delete user
$('#delete').on('click', function (event) {
  if ($('#select_user').val() == '') {
    $('#select_user')[0].setCustomValidity("Please select an item in the list");
    $('#select_user')[0].reportValidity();
  }
  else {
    console.log($('#select_user option:selected').val());
    var cofirmation = confirm("Are you sure ?");
    if (cofirmation == true) {
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>index.php/user/deleteRecord",
        dataType: "json",
        data: {
          'user_id': $('#select_user option:selected').val()
        },
        success: function (response) {
          //success
          if (response == 201) {
            // recall function[get_user_names()]
            get_user_names();

            var options = {
              autoClose: true,
              progressBar: true
            }

            var toast = new Toasty(options);
            toast.configure(options);
            toast.success("Your record deleted successfully");
            console.log('success');
            $('#submit_form')[0].reset();

          }
          //fail
          else if (response == 110) {
            var options = {
              autoClose: true,
              progressBar: true
            }

            var toast = new Toasty(options);
            toast.configure(options);
            toast.error("Sorry !!!! Unable to delete your record..");
            console.log('fail');
          }

        },
        error: function (error) {
          console.log(error);
        }
      });
    }

  }
  event.preventDefault();
});


</script>