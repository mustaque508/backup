<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Payments - RazorPay</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Payments</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
			<div class="row">
				<div class="col-lg-6 col-6">
					<div class="form-group">
					  <label>Payment's Period:</label>
					  <div class="input-group">
						<div class="input-group-prepend">
						  <span class="input-group-text"><i class="far fa-clock"></i></span>
						</div>
						<input type="text" class="form-control float-right" id="registered_dt">
					  </div>
					  <!-- /.input group -->
					</div>
				</div>
				<div class="col-lg-6 col-6">
					<div class="form-group">
					  <label>RazorPay Order ID :</label>
					  <div class="input-group">						
						<input type="text" class="form-control" id="razorpay_order_id" name="razorpay_order_id" readonly/>
					  </div>
					  <!-- /.input group -->
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-6 col-6">
					<div class="form-group">
					  <label>Top Records :</label>
					  <div class="input-group">						
						<input type="text" class="form-control" id="top_records" name="top_records"/>
					  </div>
					  <!-- /.input group -->
					</div>
				</div>				
				<div class="col-lg-6 col-6">		
					<br>
					<button type="button" class="btn btn-primary" id="btn_search" name="btn_search" onclick="onSearchClick()">Search</button>					
				</div>
			</div>
			<div class="row">
				<section class="col-lg-12 connectedSortable">
					<!-- Custom tabs (Charts with tabs)-->
					<div class="card">
					  <div class="card-header">
						<h3 class="card-title">
						  <i class="nav-icon fa fa-bell"></i>
						  Orders List
						</h3>
						<div class="card-tools">
						  <button type="button" class="btn btn-tool" data-card-widget="collapse">
							<i class="fas fa-minus"></i>
						  </button>               
						  <!--
						  <button type="button" class="btn btn-tool" data-card-widget="remove">
							<i class="fas fa-times"></i>
						  </button>
						  -->
						</div>
					  </div><!-- /.card-header -->
					  <div class="card-body">
						<table id="gridDataTableOrder" class="table table-striped table-bordered" style="cursor:pointer">											
						</table>
					  </div><!-- /.card-body -->
						<div id="loaderOrder" class="overlay" style="display: none;">
							<i class="fas fa-3x fa-sync-alt fa-spin"></i>
							<div class="text-bold pt-2">Loading please wait ...</div>
							<br><br>
						</div>
					</div>
					<!-- /.card -->
				</section>			  
			</div>	
			<div class="row">
				<section class="col-lg-12 connectedSortable">
					<!-- Custom tabs (Charts with tabs)-->
					<div class="card collapsed-card">
					  <div class="card-header">
						<h3 class="card-title">
						  <i class="nav-icon fa fa-bell"></i>
						  Payments List
						</h3>
						<div class="card-tools">
						  <button type="button" class="btn btn-tool" data-card-widget="collapse">
							<i class="fas fa-minus"></i>
						  </button>               
						  <!--
						  <button type="button" class="btn btn-tool" data-card-widget="remove">
							<i class="fas fa-times"></i>
						  </button>
						  -->
						</div>
					  </div><!-- /.card-header -->
					  <div class="card-body">
						<table id="gridDataTablePayment" class="table table-striped table-bordered" style="cursor:pointer">											
						</table>
					  </div><!-- /.card-body -->
						<div id="loaderPayment" class="overlay" style="display: none;">
							<i class="fas fa-3x fa-sync-alt fa-spin"></i>
							<div class="text-bold pt-2">Loading please wait ...</div>
							<br><br>
						</div>
					</div>
					<!-- /.card -->
				</section>			  
			</div>	
		</div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  
	<!-- jQuery -->
	<script src="<?php echo base_url(); ?>plugins/jquery/jquery.min.js"></script>	
	<!-- Bootstrap 4 -->
	<script src="<?php echo base_url(); ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>	
	<!-- overlayScrollbars -->
	<script src="<?php echo base_url(); ?>plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
	<!-- AdminLTE App -->
	<script src="<?php echo base_url(); ?>dist/js/adminlte.js"></script>
	<!-- InputMask -->
	<script src="<?php echo base_url(); ?>plugins/moment/moment.min.js"></script>
	<script src="<?php echo base_url(); ?>plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>
	<!-- date-range-picker -->
	<script src="<?php echo base_url(); ?>plugins/daterangepicker/daterangepicker.js"></script>	
	
	<!-- DataTables -->
	<script src="<?php echo base_url(); ?>plugins/datatables/jquery.dataTables.min.js"></script>
	<script src="<?php echo base_url(); ?>plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
	<script src="<?php echo base_url(); ?>plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
	<script src="<?php echo base_url(); ?>plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
		

	<script type="text/javascript">		
		var oTableOrder;
		var oTablePayment;
		var selected_razorpay_order_id = "";
			
		//Date range picker with time picker
		$('#registered_dt').daterangepicker({
		  timePicker: true,
		  timePickerIncrement: 1,
		  locale: {
			format: 'DD/MM/YYYY hh:mm A'
		  }
		})
		
		function toTimestamp(strDate){
			var datum = Date.parse(strDate);
			return datum/1000;
		}
			
		function onSearchClick() {
			var fromDateTime = $('#registered_dt').data('daterangepicker').startDate.format('YYYY-MM-DD hh:mm A');
			var toDateTime = $('#registered_dt').data('daterangepicker').endDate.format('YYYY-MM-DD hh:mm A');			
			
			var fromDateTimeUnixValue = 0;
			var toDateTimeUnixValue = 0;
			
			if(fromDateTime){
				fromDateTimeUnixValue = toTimestamp(fromDateTime);
			} else {
				alert("Please select from date first.");
				return;
			}
			
			if(toDateTime){
				toDateTimeUnixValue = toTimestamp(toDateTime);
			} else {
				alert("Please select to date first.");
				return;
			}
			
			//alert(fromDateTimeUnixValue + " " + toDateTimeUnixValue);
			
			var top_records = document.getElementById("top_records").value;
			if (top_records === null || top_records === "" || top_records === "undefined"){
				top_records = 50;
			}
			
			//getDataOrder(fromDateTimeUnixValue, toDateTimeUnixValue, top_records);
			getDataPayment(fromDateTimeUnixValue, toDateTimeUnixValue, top_records);
		}
		
		function getDataOrder(fromDateTime = 0, toDateTime = 0, topRecords = 50){
			if (oTableOrder != null && oTableOrder != "undefined"){
				$('#gridDataTableOrder').dataTable().fnClearTable();
			}
			
			var loaderOrder = document.getElementById("loaderOrder");
			loaderOrder.style.display = "block";
			
			$.ajax({ 
			   type: "GET", 			   
			   url: "<?php echo base_url(); ?>index.php/Payment/get_order_with_id",
			   data: { "order_id" : selected_razorpay_order_id  }
			}).done(function( data ) {
				if (data != 110){
					var json_obj = jQuery.parseJSON(data);
					if (json_obj.length > 0){							
						var mGridData = [];	
						for(var row = 0; row < json_obj.length; row++){						
							var id = json_obj[row].id;
							var entity = json_obj[row].entity;
							
							var amount = json_obj[row].amount;
							try {
								amount = parseFloat(amount) / 100;
							} catch (err) {
								console.log(err);
							}
							
							var amount_paid = json_obj[row].amount_paid;
							var amount_due = json_obj[row].amount_due;
							var currency = json_obj[row].currency;
							var receipt = json_obj[row].receipt;
							var status = json_obj[row].status;
							var attempts = json_obj[row].attempts;
							var created_at = json_obj[row].created_at;
														
							mGridData.push([(row + 1), id, entity, amount, amount_paid, amount_due, currency, receipt, status, attempts, created_at]);
						}	

						if (oTableOrder == null || oTableOrder == "undefined"){
							oTableOrder = $('#gridDataTableOrder').dataTable( {
								oSearch: {
									//sSearch: selected_razorpay_order_id
								},
								"sScrollX": "100%",
								"sScrollXInner": "110%",
																	
								"initComplete": function () {
									$("#gridDataTableOrder").on("click", "tr[role='row']", function(){
										$("#gridDataTableOrder tbody tr").removeClass('row_selected');        
										$(this).addClass('row_selected');
						
										////var index = $(this).index();
										var sOrderID = $(this).children('td:nth-child(2)').text();
										getDataPayment(0, 0, 50, sOrderID);									
									});
								},
								"aoColumns": [
									{ "sTitle": "Sl No" },
									{ "sTitle": "Order ID" },
									{ "sTitle": "Entity" },
									{ "sTitle": "Amount" },
									{ "sTitle": "Amount Paid" },
									{ "sTitle": "Amount Due" },
									{ "sTitle": "Currency" },
									{ "sTitle": "Receipt" },
									{ "sTitle": "Status" },
									{ "sTitle": "Attempts" },
									{ "sTitle": "Created At" }
								]
							} );
						}
													
						$('#gridDataTableOrder').dataTable().fnAddData(mGridData);
						//oTableOrder.oSearch( 'initial search value' ).draw();
						//$('#gridDataTableOrder').dataTable().columns(3).search("pay_fzf").draw();
					}else{
						//document.getElementById('last_alert_generated_dt').value = "No records found";
						//document.getElementById('no_of_violators').value = "No records found";
					}
				}else{
					alert("No order(s) found for the given order id = " + selected_razorpay_order_id);
				}
				
				loaderOrder.style.display = "none";
			});
		}
		
		function getDataPayment(fromDateTime = 0, toDateTime = 0, topRecords = 50, selected_order_id = ""){
			if (oTablePayment != null && oTablePayment != "undefined"){
				$('#gridDataTablePayment').dataTable().fnClearTable();
			}
			
			var loaderPayment = document.getElementById("loaderPayment");
			loaderPayment.style.display = "block";
			
			$.ajax({ 
			   type: "GET", 			   
			   url: "<?php echo base_url(); ?>index.php/Payment/get_all_payments",
			   data: { "top_records" : topRecords, "from_timestamp" : fromDateTime, "to_timestamp" : toDateTime, "selected_order_id" : selected_order_id  }
			}).done(function( data ) {
				if (data != 110){
					var json_obj = jQuery.parseJSON(data);
					if (json_obj.length > 0){							
						var mGridData = [];	
						for(var row = 0; row < json_obj.length; row++){						
							var id = json_obj[row].id;
							var entity = json_obj[row].entity;
							
							var amount = json_obj[row].amount;
							try {
								amount = parseFloat(amount) / 100;
							} catch (err) {
								console.log(err);
							}
							
							var currency = json_obj[row].currency;
							var status = json_obj[row].status;
							var order_id = json_obj[row].order_id;
							var invoice_id = json_obj[row].invoice_id;
							var international = json_obj[row].international;
							var method = json_obj[row].method;
							var amount_refunded = json_obj[row].amount_refunded;
							var refund_status = json_obj[row].refund_status;
							var captured = json_obj[row].captured;
							var description = json_obj[row].description;
							var card_id = json_obj[row].card_id;								
							var bank = json_obj[row].bank;
							var wallet = json_obj[row].wallet;
							var vpa = json_obj[row].vpa;
							var email = json_obj[row].email;
							var contact = json_obj[row].contact;
							var fee = json_obj[row].fee;
							var tax = json_obj[row].tax;
							var error_code = json_obj[row].error_code;
							var error_description = json_obj[row].error_description;
							var created_at = json_obj[row].created_at; 
							
							mGridData.push([(row + 1), id, entity, amount, currency, status, order_id, invoice_id, international, method, amount_refunded, refund_status, captured,
											description, card_id, bank, wallet, vpa, email, contact, fee, tax, error_code, error_description, created_at]);
						}	

						if (oTablePayment == null || oTablePayment == "undefined"){
							oTablePayment = $('#gridDataTablePayment').dataTable( {
								oSearch: {
									//sSearch: selected_razorpay_order_id
								},
								"sScrollX": "100%",
								"sScrollXInner": "110%",
																	
								"initComplete": function () {
									$("#gridDataTablePayment").on("click", "tr[role='row']", function(){
										//$("#gridDataTablePayment tbody tr").removeClass('row_selected');        
										//$(this).addClass('row_selected');
						
										////var index = $(this).index();
										//var sIndex = $(this).children('td:first-child').text();
										//var index = parseInt(sIndex) - 1;									
									});
								},
								"aoColumns": [
									{ "sTitle": "Sl No" },
									{ "sTitle": "Payment ID" },
									{ "sTitle": "Entity" },
									{ "sTitle": "Amount" },
									{ "sTitle": "Currency" },
									{ "sTitle": "Status" },
									{ "sTitle": "Order ID" },
									{ "sTitle": "Invoice ID" },
									{ "sTitle": "International" },
									{ "sTitle": "Method" },
									{ "sTitle": "Amount Refunded" },
									{ "sTitle": "Refund Status" },
									{ "sTitle": "Captured" },
									{ "sTitle": "Description" },
									{ "sTitle": "Card ID" },								
									{ "sTitle": "Bank" },
									{ "sTitle": "Wallet" },
									{ "sTitle": "VPA" },
									{ "sTitle": "Email" },
									{ "sTitle": "Contact" },
									{ "sTitle": "Fee" },
									{ "sTitle": "Tax" },
									{ "sTitle": "Error Code" },
									{ "sTitle": "Error Description" },
									{ "sTitle": "Created At" }
								]
							} );
						}
													
						$('#gridDataTablePayment').dataTable().fnAddData(mGridData);
						//oTablePayment.oSearch( 'initial search value' ).draw();
						//$('#gridDataTablePayment').dataTable().columns(3).search("pay_fzf").draw();
					}else{
						//document.getElementById('last_alert_generated_dt').value = "No records found";
						//document.getElementById('no_of_violators').value = "No records found";
					}
				}else{
					// Show alert message here
				}
				
				loaderPayment.style.display = "none";
			});
		}
		
		$(document).ready(function() {
			selected_razorpay_order_id = "<?php echo $razorpay_order_id; ?>";
			document.getElementById("razorpay_order_id").value = selected_razorpay_order_id;	

			getDataOrder();
			getDataPayment();
		} );
	</script>	