<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Create Invoice</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Create Invoice</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-12">                    
                    <!-- Quotation Selection -->
                    <div class="form-group row no-print" id="quotation_div">
                        <label for="com_quot_no" class="col-sm-2 col-form-label" id="lbl_for_quot_no" name="lbl_for_quot_no">
                            Select Quotation :</label>
                        <div class="col-sm-4">
                            <select class="form-control" id="com_quot_no" name="com_quot_no">
                                <?php
								if ($quotations != 0){
									foreach ($quotations->result_array() as $row) {
										echo "<option value=" . $row['Quotation_No'] . ">" . $row['Quotation_No'] . "</option>";
									}
								}
                                ?>
                            </select>
                        </div>
                    </div>
				</div>
				<section class="col-lg-6 connectedSortable">
					<div class="card">
						<div class="card-header">
							<h3 class="card-title">
								<i class="nav-icon fa fa-bell"></i>
								Customer Details
							</h3>
							<div class="card-tools">
								<button type="button" class="btn btn-tool" data-card-widget="collapse">
									<i class="fas fa-minus"></i>
								</button>
							</div>
						</div><!-- /.card-header -->
						<div class="card-body">
							<div class="form-group row">
								<label for="com_state" class="col-sm-2 col-form-label">State* :</label>
								<div class="col-sm-4">

									<select class="form-control" id="com_state" name="com_state">
										<?php 
											foreach ($statesgstcode->result_array() as $row)
											{
												echo "<option value='".$row['Code']."'>".$row['State']."</option>";	
											}
										?>
									</select>	

								</div>
								<label for="txt_code" class="col-sm-2 col-form-label">Code :</label>
								<div class="col-sm-4">
									<input class="form-control" type="text" placeholder="Code" id="txt_code" name="txt_code">
								</div>
							</div>																						
							<div class="form-group row">
								<label for="txt_gstin" class="col-sm-2 col-form-label">GSTIN* :</label>
								<div class="col-sm-4">
									<input class="form-control" type="text" placeholder="GSTIN" id="txt_gstin" name="txt_gstin">
								</div>							
								<label for="com_currency" class="col-sm-3 col-form-label">Currency* :</label>
								<div class="col-sm-3">
									<select class="form-control" id="com_currency" name="com_currency">
										<option value="INR">INR</option>
										<option value="USD">USD</option>
										<option value="GBP">GBP</option>
									</select>
								</div>
							</div>
							<div class="form-group row">
								<label for="com_cust" class="col-sm-2 col-form-label">To* :</label>
								<div class="col-sm-9">
									<select class="form-control" id="com_cust" name="com_cust">
										<?php 
											foreach ($customers->result_array() as $row)
											{
												echo "<option value=".$row['Customer_ID'].">".$row['Customer_Name'] ."</option>";	
											}
										?>
									</select>									
								</div>
								<button type="button" id="btn_add_cust" data-toggle="modal" data-target="#modal_customer_details" class="btn btn-info">
								+
								</button>  
							</div>
							<div class="row">		
								<div class="col-2">
								</div>
								<div class="col-10">
									<div class="form-group">										
										<textarea class="form-control" rows="5" placeholder="Customer Information" id="txt_customer_info" name="txt_customer_info"></textarea>
									</div>
								</div>
							</div>
						</div><!-- /.card-body -->						
					</div>
					<!-- /.card -->
				</section>	
				<section class="col-lg-6 connectedSortable">
					<div class="card">
						<div class="card-header">
							<h3 class="card-title">
								<i class="nav-icon fa fa-bell"></i>
								Invoice Details
							</h3>
							<div class="card-tools">
								<button type="button" class="btn btn-tool" data-card-widget="collapse">
									<i class="fas fa-minus"></i>
								</button>
							</div>
						</div><!-- /.card-header -->
						<div class="card-body">
							<div class="form-group row">
								<label for="inputEmail3" class="col-sm-4 col-form-label">Invoice No* :</label>
								<div class="col-sm-8">
									<input class="form-control" type="text" placeholder="Invoice No" id="txt_invoiceno" name="txt_invoiceno">
								</div>
							</div>
							<div class="form-group row">
								<label for="inputPassword3" class="col-sm-4 col-form-label">Invoice Date* :</label>
								<div class="col-sm-8">
									<div class="input-group date" id="invoice_date" data-target-input="nearest">
										<input type="text" class="form-control datetimepicker-input" data-target="#timepicker" id="invoice_dt" name="invoice_dt"/>
										<div class="input-group-append" data-target="#invoice_date" data-toggle="datetimepicker">
											<div class="input-group-text"><i class="far fa-clock"></i></div>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group row">
								<label for="inputPassword3" class="col-sm-4 col-form-label">Order No* :</label>
								<div class="col-sm-8">
									<input class="form-control" type="text" placeholder="Order No" id="txt_orderno" name="txt_orderno">
								</div>
							</div>
							<div class="form-group row">
								<label for="inputPassword3" class="col-sm-4 col-form-label">Order Date* :</label>
								<div class="col-sm-8">
									<div class="input-group date" id="dated" data-target-input="nearest">
										<input type="text" class="form-control datetimepicker-input" data-target="#timepicker" id="order_dt" name="order_dt"/>
										<div class="input-group-append" data-target="#dated" data-toggle="datetimepicker">
											<div class="input-group-text"><i class="far fa-clock"></i></div>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group row">
								<label for="inputPassword3" class="col-sm-4 col-form-label">Project/JOB :</label>
								<div class="col-sm-8">
									<input class="form-control" type="text" placeholder="Project/JOB" id="txt_projectjob" name="txt_projectjob">
								</div>
							</div>
							<div class="form-group row">
								<label for="inputPassword3" class="col-sm-4 col-form-label">HSN/SAC CODE :</label>
								<div class="col-sm-8">
									<input class="form-control" type="text" placeholder="HSN/SAC CODE" id="txt_hsnsac_code" name="txt_hsnsac_code">
								</div>
							</div>							
						</div><!-- /.card-body -->						
					</div>
					<!-- /.card -->
				</section>
			</div>	
			<div class="row">
				<section class="col-lg-12 connectedSortable">
					<div class="card">
						<div class="card-header">
							<h3 class="card-title">
								<i class="nav-icon fa fa-bell"></i>
								Item Details*
							</h3>
							<div class="card-tools">
								<button type="button" class="btn btn-tool" data-card-widget="collapse">
									<i class="fas fa-minus"></i>
								</button>
							</div>
						</div><!-- /.card-header -->
						<div class="card-body">
							<table id="purchase_details" class="table table-bordered table-hover">										
							</table>
							<button type="button" id="add_row" data-toggle="modal" data-target="#modal_purchased_details" class="btn btn-info btn-lg" style="width:200px; line-height: 10px;">Add Row</button>  
							<!--<div class="col-12">
								<div class="table-responsive">
									<table class="table" style="border: 2px solid lightgrey;">
										<tr>
											<th>SL No</th>
											<th>ITEM DESCRIPTION</th>
											<th>RATE</th>
											<th>QTY</th>
											<th>AMOUNT</th>
										</tr>
										<tr>
											<td>1</td>
											<td>C5 CDR ANALYZER</td>
											<td>117000</td>
											<td>1</td>
											<td>117000</td>
										</tr>
									</table>
								</div>
							</div>-->
						</div><!-- /.card-body -->						
					</div>
					<!-- /.card -->
				</section>
			</div>
			<div class="row">
				<section class="col-lg-12 connectedSortable">
					<div class="card">
						<div class="card-header">
							<h3 class="card-title">
								<i class="nav-icon fa fa-bell"></i>
								Amount Details
							</h3>							
						</div><!-- /.card-header -->
						<div class="card-body">
							<div class="row">
								<div class="col-6">
									<!-- Rupees in words -->
								</div>
								<div class="col-6">
									<div class="table-responsive">
										<table class="table" style="border: 2px solid lightgrey;">
											<tr>												
												<td>
													<div class="row">
														<label for="txt_totalbeforegst" class="col-sm-5 col-form-label">Total Before GST :</label>
														<div class="col-sm-2">
															
														</div>
														<div class="col-sm-5">
															<input class="form-control" type="text" placeholder="Total Before GST" id="txt_totalbeforegst" name="txt_totalbeforegst">
														</div>
													</div>
												</td>																				
											</tr>
											<tr>
												<td>
													<div class="row">
														<label for="txt_igst" class="col-sm-5 col-form-label">I GST @ % OF :</label>
														<div class="col-sm-2">
															<input class="form-control" type="text" placeholder="%" id="txt_igst_percentage" name="txt_igst_percentage" onchange="cal_igst()">
														</div>
														<div class="col-sm-5">
															<input class="form-control" type="text" placeholder="I GST @ % OF" id="txt_igst" name="txt_igst">
														</div>
													</div>
												</td>
											</tr>
											<tr>
												<td>
													<div class="row">
														<label for="txt_sgst" class="col-sm-5 col-form-label">S GST @ % OF :</label>
														<div class="col-sm-2">
															<input class="form-control" type="text" placeholder="%" id="txt_sgst_percentage" name="txt_sgst_percentage" onchange="cal_sgst()">
														</div>
														<div class="col-sm-5">
															<input class="form-control" type="text" placeholder="S GST @ % OF" id="txt_sgst" name="txt_sgst">
														</div>
													</div>
												</td>
											</tr>
											<tr>
												<td>
													<div class="row">
														<label for="txt_cgst" class="col-sm-5 col-form-label">C GST @ % OF :</label>
														<div class="col-sm-2">
															<input class="form-control" type="text" placeholder="%" id="txt_cgst_percentage" name="txt_cgst_percentage" onchange="cal_cgst()">
														</div>
														<div class="col-sm-5">
															<input class="form-control" type="text" placeholder="C GST @ % OF" id="txt_cgst" name="txt_cgst">
														</div>
													</div>
												</td>
											</tr>
											<tr>
												<td>
													<div class="row">
														<label for="txt_roundedoff" class="col-sm-5 col-form-label">Rounded off :</label>
														<div class="col-sm-2">
															<label for="txt_roundedoff" class="col-form-label">+/-</label>
														</div>
														<div class="col-sm-5">
															<input class="form-control" type="text" placeholder="Rounded off" id="txt_roundedoff" name="txt_roundedoff" onchange="cal_roundedoff()">
														</div>
													</div>
												</td>
											</tr>
											<tr>
												<td>
													<div class="row">
														<label for="txt_igst" class="col-sm-5 col-form-label" id="lbl_total_after_gst" name="lbl_total_after_gst"></label>
														<div class="col-sm-2">															
														</div>
														<div class="col-sm-5">
															<input class="form-control" type="text" placeholder="Total after GST" id="txt_totalaftergst" name="txt_totalaftergst">
														</div>
													</div>
												</td>
											</tr>
											
										</table>
									</div>
									<!--<div class="col-sm-12">
										<div class="form-group row">
											<label for="inputEmail3" class="col-sm-4 col-form-label">Total Before GST :</label>
											<div class="col-sm-8">
												<input class="form-control" type="text" placeholder="Total Before GST" id="txt_totalbeforegst" name="txt_totalbeforegst">
											</div>
										</div>									
										<div class="form-group row">
											<label for="inputEmail3" class="col-sm-4 col-form-label">I GST @ % OF :</label>
											<div class="col-sm-8">
												<input class="form-control" type="text" placeholder="Total Before GST" id="txt_igst" name="txt_igst">
											</div>
										</div>
									</div>-->
								</div>
							</div>
						</div><!-- /.card-body -->
						<div class="card-footer">
							<!-- <a href="invoice-print.html" target="_blank" class="btn btn-default"><i class="fas fa-print"></i> Print</a> -->
							<button class="btn btn-primary float-right"
									id="btn_save_print" style="color:white"> 
								Save & Print 
							</button> 
						</div>
						<div id="loader" class="overlay" style="display: none;">
							<i class="fas fa-3x fa-sync-alt fa-spin"></i>
							<div class="text-bold pt-2">Loading please wait ...</div>
							<br><br>
						</div>
					</div>
					<!-- /.card -->
				</section>
			</div>
		</div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  
	<!-- jQuery -->
	<script src="<?php echo base_url();?>plugins/jquery/jquery.min.js"></script>
	<!-- Bootstrap 4 -->
	<script src="<?php echo base_url();?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
	<script src="<?php echo base_url();?>plugins/select2/js/select2.full.min.js"></script>
	<!-- Bootstrap4 Duallistbox -->
	<script src="<?php echo base_url();?>plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js"></script>
	<!-- InputMask -->
	<script src="<?php echo base_url();?>plugins/moment/moment.min.js"></script>
	<script src="<?php echo base_url();?>plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>
	<!-- date-range-picker -->
	<script src="<?php echo base_url();?>plugins/daterangepicker/daterangepicker.js"></script>
	<!-- Tempusdominus Bootstrap 4 -->
	<script src="<?php echo base_url();?>plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>	
	<!-- overlayScrollbars -->
	<script src="<?php echo base_url();?>plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
	
	<!-- DataTables -->
	<script src="<?php echo base_url();?>plugins/datatables/jquery.dataTables.min.js"></script>
	<script src="<?php echo base_url();?>plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
	<script src="<?php echo base_url();?>plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
	<script src="<?php echo base_url();?>plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
	
	<!-- AdminLTE App -->
	<script src="<?php echo base_url();?>dist/js/adminlte.js"></script>

	<script type="text/javascript">		
		var oTable;
		var dsPurchasedDetails = [];
		var selectedCurrency = "INR";
		var selectedCurrencySymbol = "&#x20B9;";
		var selectedCustomerID = "";
		var selectedProductID = "";
		
		var selectedState = "";
		var selectedCode = "";

		//// #####################################################################################################
		//// Init controls start
		//Date range picker with time picker
		$('#registered_dt').daterangepicker({
		  timePicker: true,
		  timePickerIncrement: 1,
		  locale: {
			format: 'DD/MM/YYYY hh:mm A'
		  }
		})		

		// Datepicker
		$('#invoice_date').datetimepicker({
		  //format: 'LT'
		  timePicker: false,
		  format: 'DD-MM-YYYY'
		})

		// Datepicker
		$('#dated').datetimepicker({
		  //format: 'LT'
		  timePicker: false,
		  format: 'DD-MM-YYYY'
		})

		var purchaseDetails = $('#purchase_details').dataTable( {
			"bSort": false, 
			"bPaginate": false,
			"bLengthChange": false,
			"bFilter": false,
			"bInfo": false,
			"bAutoWidth": false,
																	
			"initComplete": function () {
				$("#purchase_details").on("click", "tr[role='row']", function(){
					//$("#purchase_details tbody tr").removeClass('row_selected');        
					//$(this).addClass('row_selected');
						
					////var index = $(this).index();
					//var selected_razorpay_order_id = $(this).children('td:last-child').text();
					//window.location.href = "<?php echo base_url(); ?>index.php/Payment?razorpay_order_id=" + selected_razorpay_order_id + "";
				});
			},
			"columnDefs":[  
				{  
					"targets":[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],  
					"orderable":false, 
					"searchable": false
				},
				{
					"targets": [2],
					"visible": true //false
				}  
			],
			"aoColumns": [
				{ "sTitle": "Edit", "mData": "update_btn" },
				{ "sTitle": "Delete", "mData": "delete_btn" },
				{ "sTitle": "Sl No", "mData": "slNo" },
				{ "sTitle": "ID", "mData": "id", "visible": false }, 
				{ "sTitle": "ProductID", "mData": "product_id", "visible": false }, 
				{ "sTitle": "Product Name", "mData": "product_name" }, 
				{ "sTitle": "Description", "mData": "description" }, 
				{ "sTitle": "Rate ("+ selectedCurrencySymbol +")", "mData": "rate" }, 
				{ "sTitle": "Warranty", "mData": "warranty", "visible": false },
				{ "sTitle": "AMC Percentage", "mData": "amc_percentage", "visible": false },
				{ "sTitle": "Qty", "mData": "qty" }, 
				{ "sTitle": "AMC Amount", "mData": "amc_amount" }, 
				{ "sTitle": "Amount", "mData": "amount" }
			]
		} );

		$('#purchase_details').dataTable().fnClearTable();

		//// Init controls end
		//// #####################################################################################################

		//// #####################################################################################################
		//// Events start
		$('#com_currency').change(function(){
			selectedCurrency = $(this).val();
			var arrCurrency = { "INR": "&#x20B9;", "USD": "&#36;", "GBP": "&pound;" }; 
			selectedCurrencySymbol = arrCurrency[selectedCurrency];

			if (purchaseDetails != null && purchaseDetails != "undefined"){
				var mHeader = $('#purchase_details tr:eq(0) th:eq(5)');
				$(mHeader ).html("Rate ("+ selectedCurrencySymbol +")");
				//$('#purchase_details tr:eq(0) th:eq(5)').text("Rate123 ("+ selectedCurrencySymbol +")");
				//$('#purchase_details tr:eq(0) th:eq(5)').text("Rate (<span>"+ selectedCurrencySymbol +"</span>)");
			}
			
			document.getElementById("lbl_total_after_gst").innerHTML = "Total after GST : ("+ selectedCurrencySymbol +")";
		})

		$('#com_quot_no').change(function() {
			selectedQuotation = $(this).val();
			if (selectedQuotation != ""){
				loadQuotation(selectedQuotation);
			}
		})

		$('#com_state').change(function(){
			//selectedState = $(this).val();
			//selectedCode = $('#com_state').find('option[value="' + selectedState + '"]').attr('Code');

			  var x = document.getElementById("com_state");
			  var value = document.getElementById("com_state").value;
			  var text = x.options[x.selectedIndex].text
			  selectedCode = value;
			  selectedState = text;
			  document.getElementById("txt_code").value = value;// = "VALUE : " + value + "<br>Text : " + text;

		
			if (selectedState.toLowerCase() == "karnataka"){
				document.getElementById("txt_igst_percentage").value = "0";
				document.getElementById("txt_sgst_percentage").value = "9";
				document.getElementById("txt_cgst_percentage").value = "9";
			}else{
				document.getElementById("txt_igst_percentage").value = "18";
				document.getElementById("txt_sgst_percentage").value = "0";
				document.getElementById("txt_cgst_percentage").value = "0";
			}

			cal_total();
		})

		$('#com_cust').change(function(){
			selectedCustomerID = $(this).val(); 
			//alert(cust_id);

			$.ajax({ 
				type: "GET", 			   
				url: "<?php echo base_url(); ?>index.php/Customer_controller/get_customer_details",
				data: { 
					// Customer Information
					"customer_id" : selectedCustomerID
				}
			}).done(function( data ) {
				if (data != 110){
					var json_obj = jQuery.parseJSON(data);
					if (json_obj.length > 0){
						var address = unescapeHTML(json_obj[0].Customer_Address);												
						var cust_info = json_obj[0].Customer_Name + "\n" + address.replace(/<br>/g, "\n");

						document.getElementById("txt_gstin").value = json_obj[0].GSTIN_No;
						document.getElementById("txt_customer_info").innerHTML = cust_info;
					}
				}
			});
		})	

		// Save and Print button click
		$('#btn_save_print').click(function(){
			save();
		})

		//// ----------------------------------------------------------------------------------------------------
		//// Customer Details Modal Start
		// Add customer row button click
		$('#btn_add_cust').click(function(){  
           $('#form_customer_details')[0].reset();  
           $('.modal-title').text("Add Customer");  
           $('#action_submit_customer').val("Add");               
		})

		// Perform Add operation
		$(document).on('submit', '#form_customer_details', function(event){  
			event.preventDefault();  
			
			var um_fd_cust_id = create_GUID(); // $('#um_fd_cust_id').val();
			var um_fd_cust_name = $('#um_fd_cust_name').val();
			var um_fd_address = $('#um_fd_address').val();
			um_fd_address = um_fd_address.replace(/\n/g, "<br>");

			var um_fd_city = $('#um_fd_city').val();
			var um_fd_state = $('#um_fd_state').val();
			var um_fd_country = $('#um_fd_country').val();
			var um_fd_gstin = $('#um_fd_gstin').val();
			var um_fd_pan = $('#um_fd_pan').val();
			var um_fd_tan = $('#um_fd_tan').val();
			   
			if(um_fd_cust_id != '' && um_fd_cust_name != '' && 
				um_fd_address != '' && um_fd_city != '' && um_fd_state != '' && um_fd_country != '' &&
				um_fd_gstin != '' && um_fd_pan != '' && um_fd_tan != '')  
			{  
				var action = $('#action_submit_customer').val();
				
				var uID = "unique_cust_id"; // getUniqueRowID(dsPurchasedDetails);
				var mdata = {						
					"customer_id" : um_fd_cust_id,
					"customer_name" : um_fd_cust_name,
					"address" : um_fd_address,
					"city" : um_fd_city,
					"state" : um_fd_state,
					"country" : um_fd_country,
					"gstin" : um_fd_gstin,
					"pan" : um_fd_pan,
					"tan" : um_fd_tan
				};

				$.ajax({ 
				   type: "GET", 			   
				   url: "<?php echo base_url(); ?>index.php/Customer_controller/save_customer",
				   data: mdata
				}).done(function( data ) {
					if (data == "1"){
						cust_select = document.getElementById('com_cust');
						cust_select.options[cust_select.options.length] = new Option(um_fd_cust_name, um_fd_cust_id);
						
						alert("New customer successfully created.");
					}else{
						alert("Failed to save customer because of the error :\n" + data);
					}					
				});
				
				$('#form_customer_details')[0].reset();  
				$('#modal_customer_details').modal('hide'); 				
			}  
			else  
			{  
				alert("All fields are required.");  
			}  
		});		
		//// Customer Details Modal End
		//// ----------------------------------------------------------------------------------------------------

		//// ----------------------------------------------------------------------------------------------------
		//// Purchase Details Modal Start
		// Perform Add OR Edit operation
		$(document).on('submit', '#form_purchased_details', function(event){  
			event.preventDefault();  
			
			var um_fd_product_id = $('#um_fd_product_id').val();
			var um_fd_product_name = $('#um_fd_product_name').val();
			var um_fd_description = $('#um_fd_description').val();
			um_fd_description = um_fd_description.replace(/\n/g, "<br>");

			var um_fd_rate = $('#um_fd_rate').val();
			var um_fd_warranty = $('#um_fd_warranty').val();
			var um_fd_amc_percentage = $('#um_fd_amc_percentage').val();
			var um_fd_qty = $('#um_fd_qty').val();
			   
			if(um_fd_product_id != '' && um_fd_product_name != '' && um_fd_description != '' && um_fd_rate != ''  
				&& um_fd_warranty != '' && um_fd_warranty != null  && um_fd_amc_percentage != '' && um_fd_qty != '')  
			{  
				var m_warranty = parseFloat(um_fd_warranty);
				var m_rate = parseFloat(um_fd_rate);
				var m_qty = parseFloat(um_fd_qty);
				var m_amc_amount = 0;
				var m_amount = 0;				

				if (m_warranty == 1){
					m_amount = parseFloat(um_fd_rate) * parseFloat(um_fd_qty);
				}else{
					var m_amc_percentage = parseFloat(um_fd_amc_percentage); // Entered amc percentage
					var percentage_on_product_rate = ((m_rate * m_qty) * m_amc_percentage) / 100; // Amc percentage based on product rate * quantity
					var m_amc_amount = (m_warranty - 1) * percentage_on_product_rate; // total amc percenatage amount = (no of years - 1) * amc percentage amount
					m_amount = (parseFloat(um_fd_rate) * parseFloat(um_fd_qty)) + m_amc_amount; // Amount = (Product rate * Quantity) + AMC amount
				}

				var action = $('#action_submit').val();
				var newRow = [];

				if (action == "Add"){
					var uID = getUniqueRowID(dsPurchasedDetails);

					newRow.push({ 
						"update_btn": '<button type="button" name="update" id='+ uID +' class="btn btn-warning btn-xs update">Update</button>',
						"delete_btn": '<button type="button" name="delete" id='+ uID +' class="btn btn-danger btn-xs delete">Delete</button>',						
						"slNo" : uID,
						"id" : uID,
						"product_id" : um_fd_product_id,
						"product_name" : um_fd_product_name,
						"description" : um_fd_description,
						"rate" : um_fd_rate,
						"warranty" : um_fd_warranty,
						"amc_percentage" : um_fd_amc_percentage,
						"qty" : um_fd_qty,
						"amc_amount" : m_amc_amount,
						"amount" : m_amount
					});		
					
					$('#purchase_details').dataTable().fnAddData(newRow);
					dsPurchasedDetails.push(newRow[0]);

				}else{
					var uID = $('#um_fd_id').val();
					var parsedID = parseInt(uID);					
					
					newRow.push({ 
						"update_btn": '<button type="button" name="update" id='+ parsedID +' class="btn btn-warning btn-xs update">Update</button>',
						"delete_btn": '<button type="button" name="delete" id='+ parsedID +' class="btn btn-danger btn-xs delete">Delete</button>',						
						"slNo" : parsedID,
						"id" : parsedID,
						"product_id" : um_fd_product_id,
						"product_name" : um_fd_product_name,
						"description" : um_fd_description,
						"rate" : um_fd_rate,
						"warranty" : um_fd_warranty,
						"amc_percentage" : um_fd_amc_percentage,
						"qty" : um_fd_qty,
						"amc_amount" : m_amc_amount,
						"amount" : m_amount
					});
					
					//var index = dsPurchasedDetails.findIndex(e => e.id === parsedID);
					//$('#purchase_details').dataTable().fnDeleteRow(index);
					dsPurchasedDetails = dsPurchasedDetails.filter(e => e.id !== parsedID)
					dsPurchasedDetails.push(newRow[0]);
					dsPurchasedDetails.sort(function(a,b) {
						return a.id - b.id;
					});

					$('#purchase_details').dataTable().fnClearTable();
					$('#purchase_details').dataTable().fnAddData(dsPurchasedDetails);					
				}
				
				$('#form_purchased_details')[0].reset();  
				$('#modal_purchased_details').modal('hide'); 
					
				//$('#purchase_details').dataTable().fnSort( [ [2, 'asc'] ] );				

				var t_amount = 0;
				if (dsPurchasedDetails.length > 0){
					for(var i = 0; i < dsPurchasedDetails.length; i++){
						t_amount += dsPurchasedDetails[i].amount;
					}
				}

				document.getElementById("txt_totalbeforegst").value = t_amount;

				cal_total();
			}  
			else  
			{  
				alert("All fields are required.");  
			}  
		});

		// Perform Update Operation
		$(document).on('click', '.update', function(){ 
			var uID = $(this).attr("id");
			var parsedID = parseInt(uID);
			var data = dsPurchasedDetails.filter(function(item) { return item.id === parsedID; });			
			
			$('#modal_purchased_details').modal('show');
			
			$('#um_fd_product_id').val(data[0].product_id);
			$('#um_fd_product_name').val(data[0].product_name);
			$('#um_fd_description').val(data[0].description);
			$('#um_fd_rate').val(data[0].rate);
			$('#um_fd_qty').val(data[0].qty);			
			$('#um_fd_id').val(parsedID);
			
			$('.modal-title').text("Edit User");		
			
			//$('#um_fd_pimage_path').html(data.pimage_path);  
			$('#action_submit').val("Edit");		   
		});
		
		// Perform Delete Operation
		$(document).on('click', '.delete', function(){  
			var rowID = $(this).attr("id");
			var parsedID = parseInt(rowID);
		   
			if(confirm("Are you sure you want to delete this?"))  
			{  
				var index = dsPurchasedDetails.findIndex(e => e.id === parsedID);
				$('#purchase_details').dataTable().fnDeleteRow(index);
				dsPurchasedDetails = dsPurchasedDetails.filter(e => e.id !== parsedID)

				var t_amount = 0;
				if (dsPurchasedDetails.length > 0){
					for(var i = 0; i < dsPurchasedDetails.length; i++){
						t_amount += dsPurchasedDetails[i].amount;
					}
				}

				document.getElementById("txt_totalbeforegst").value = t_amount;
				cal_total();
			}  
			else  
			{  
				return false;       
			}  
		});

		$(document).on('change', '#um_fd_product_id', function(event){
			selectedProductID = $(this).val(); 
			$.ajax({ 
				type: "GET", 			   
				url: "<?php echo base_url(); ?>index.php/Product_controller/get_product_details",
				data: { 
					// Customer Information
					"product_id" : selectedProductID
				}
			}).done(function( data ) {
				if (data != 110){
					var json_obj = jQuery.parseJSON(data);
					if (json_obj.length > 0){			
						document.getElementById("um_fd_product_name").value = json_obj[0].Product_Name;
						var prodDesc = unescapeHTML(json_obj[0].Product_Desc);
						document.getElementById("um_fd_description").value = prodDesc.replace(/<br>/g, "\n");
						document.getElementById("um_fd_rate").value = json_obj[0].Rate;						
					}
				}
			});
		});		
		
		// Add row button click
		$('#add_row').click(function(){
			$('#form_purchased_details')[0].reset();  
			$('.modal-title').text("Add Item");  
			$('#action_submit').val("Add");     
			//$('#um_fd_product_id').selectedIndex = "-1";
			$('#form_purchased_details').find("select").val('').end();
		})
		//// Purchase Details Modal END
		//// ----------------------------------------------------------------------------------------------------

		//// ----------------------------------------------------------------------------------------------------
		//// Product Details Modal Start
		// Add product row button click
		$('#btn_add_product').click(function(){  
           $('#form_product_details')[0].reset();  
           $('.modal-title').text("Add Product");  
           $('#action_submit_product').val("Add");               
		})

		// Perform Add operation
		$(document).on('submit', '#form_product_details', function(event){  
			event.preventDefault();  
			
			var um_fd_prod_id = create_GUID(); // $('#um_fd_cust_id').val();
			var um_fd_prod_name = $('#um_fd_prod_name').val();
			var um_fd_prod_desc = $('#um_fd_prod_desc').val();
			um_fd_prod_desc = um_fd_prod_desc.replace(/\n/g, "<br>");

			var um_fd_prod_rate = $('#um_fd_prod_rate').val();
			var um_fd_edition = $('#um_fd_edition').val();
			   
			if(um_fd_prod_id != '' && um_fd_prod_name != '' && 
				um_fd_prod_desc != '' && um_fd_prod_rate != '' && um_fd_edition != '')  
			{  
				var action = $('#action_submit_product').val();
				
				var uID = "unique_cust_id"; // getUniqueRowID(dsPurchasedDetails);
				var mdata = {						
					"product_id" : um_fd_prod_id,
					"product_name" : um_fd_prod_name,
					"product_desc" : um_fd_prod_desc,
					"rate" : um_fd_prod_rate,
					"edition" : um_fd_edition
				};

				$.ajax({ 
				   type: "GET", 			   
				   url: "<?php echo base_url(); ?>index.php/Product_controller/save_product",
				   data: mdata
				}).done(function( data ) {
					if (data == "1"){
						prod_select = document.getElementById('um_fd_product_id');
						prod_select.options[prod_select.options.length] = new Option(um_fd_prod_name + " ("+ um_fd_edition +")", um_fd_prod_id);
						
						alert("New product successfully created.");
					}else{
						alert("Failed to save product because of the error :\n" + data);
					}					
				});
				
				$('#form_product_details')[0].reset();  
				$('#modal_product_details').modal('hide'); 				
			}  
			else  
			{  
				alert("All fields are required.");  
			}  
		});		
		//// Product Details Modal End
		//// ----------------------------------------------------------------------------------------------------

		//// Events end
		//// #####################################################################################################
		
		//// #####################################################################################################
		//// Functions start
		function loadQuotation(selectedQuotation) {
			// Clear all invoice items list
			// Purchased Details
			if (purchaseDetails != null && purchaseDetails != "undefined"){
				$('#purchase_details').dataTable().fnClearTable();
			}

			// Clear all fields
			document.getElementById("com_state").value = "";
			document.getElementById("txt_code").value = "";
			document.getElementById("txt_gstin").value = "";
			document.getElementById("com_currency").value = "";
			document.getElementById("txt_customer_info").innerHTML = "";
			
			// Invoice Details
			document.getElementById("txt_invoiceno").value = "";
			document.getElementById("invoice_dt").value = "";
			document.getElementById("txt_orderno").value = "";
			document.getElementById("order_dt").value = "";
			document.getElementById("txt_projectjob").value = "";
			document.getElementById("txt_hsnsac_code").value = "";
			
			// Amount Details
			document.getElementById("txt_totalbeforegst").value = "";
			document.getElementById("txt_igst_percentage").value = "";
			document.getElementById("txt_igst").value = "";
			document.getElementById("txt_sgst_percentage").value = "";
			document.getElementById("txt_sgst").value = "";
			document.getElementById("txt_cgst_percentage").value = "";
			document.getElementById("txt_cgst").value = "";
			document.getElementById("txt_roundedoff").value = "";			
			document.getElementById("txt_totalaftergst").value = "";

			var mdata = {
				"quotation_no": selectedQuotation
			};

			$.ajax({
				type: "GET",
				url: "<?php echo base_url(); ?>index.php/Quotation_controller/get_quotation_details",
				data: mdata
			}).done(function(data) {
				if (data != 110) {
					var json_obj = jQuery.parseJSON(data);
					if (json_obj.length > 0) {
						selectedCode = json_obj[0].Code;
						selectedState = json_obj[0].State;

						document.getElementById('com_state').value = json_obj[0].Code;
						document.getElementById('txt_code').value = json_obj[0].Code;
						document.getElementById('txt_gstin').value = json_obj[0].Customer_GSTIN_No;
						document.getElementById('com_currency').value = json_obj[0].Currency;
						document.getElementById('com_cust').value = json_obj[0].Customer_ID;	
						selectedCustomerID = json_obj[0].Customer_ID;
						
						var unescapedAddress = unescapeHTML(json_obj[0].Customer_Address);												
						var cust_info = json_obj[0].Customer_Name + "\n" + unescapedAddress.replace(/<br>/g, "\n");
						
						document.getElementById('txt_customer_info').innerHTML = cust_info;

						/*
						document.getElementById('txt_quotationno').value = json_obj[0].Quotation_No;
						
						var invDateString = json_obj[0].Quotation_Date; // Quotation Date
						invDateString = invDateString.replace(" 00:00:00.000", "");
						var invDate = invDateString.split("-");
						document.getElementById('quotation_dt').value = invDate[2] + "-" + invDate[1] + "-" + invDate[0];
						
						document.getElementById('txt_referenceno').value = json_obj[0].Reference_No;
						
						var ordDateString = json_obj[0].Reference_Date; // Reference Date
						ordDateString = ordDateString.replace(" 00:00:00.000", "");
						var ordDate = ordDateString.split("-"); // Order Date
						document.getElementById('reference_dt').value = ordDate[2] + "-" + ordDate[1] + "-" + ordDate[0];

						document.getElementById('txt_preparedby').value = json_obj[0].PreparedBy;
						*/

						document.getElementById('txt_projectjob').value = json_obj[0].Project_Job;
						document.getElementById('txt_hsnsac_code').value = json_obj[0].HSN_SAC_Code;

						document.getElementById('txt_totalbeforegst').value = json_obj[0].Total_Before_GST;
						document.getElementById('txt_igst_percentage').value = json_obj[0].IGST;
						document.getElementById('txt_igst').value = "0";
						document.getElementById('txt_sgst_percentage').value = json_obj[0].SGST;
						document.getElementById('txt_sgst').value = "0";
						document.getElementById('txt_cgst_percentage').value = json_obj[0].CGST;
						document.getElementById('txt_cgst').value = "0";

						var rOff = json_obj[0].Round_Off;
						document.getElementById('txt_roundedoff').value = rOff;
						
						document.getElementById('txt_totalaftergst').value = json_obj[0].Total_After_GST;						
					}
				} else {
					alert("Failed to get quotation details because of the error :\n" + data);
				}
			});

			dsPurchasedDetails = [];

			$.ajax({
				type: "GET",
				url: "<?php echo base_url(); ?>index.php/Quotation_controller/get_quotation_item_details",
				data: mdata
			}).done(function(data) {
				if (data == 110) {
					alert("No quotation items found.");
				} else if (data == 111) {
					alert("Failed to get quotation item details because of the error :\n" + data);
				} else {
					var json_obj = jQuery.parseJSON(data);
					if (json_obj.length > 0) {
						for (var row = 0; row < json_obj.length; row++) {
							var id = getUniqueRowID(dsPurchasedDetails);							
							var product_id = json_obj[row].Product_ID;
							var product_name = json_obj[row].Product_Name;
							var description = json_obj[row].Description;
							var rate = json_obj[row].Rate;
							var warranty = json_obj[row].Warranty;
							var amc_percentage = json_obj[row].AMC_Percentage;
							var qty = json_obj[row].Quantity;
							var m_amc_amount = 0;
							var m_amount = 0;				

							if (warranty == 1){
								m_amount = parseFloat(rate) * parseFloat(qty);
							}else{
								var m_amc_percentage = parseFloat(amc_percentage); // Entered amc percentage
								var percentage_on_product_rate = ((rate * qty) * m_amc_percentage) / 100; // Amc percentage based on product rate * quantity
								var m_amc_amount = (warranty - 1) * percentage_on_product_rate; // total amc percenatage amount = (no of years - 1) * amc percentage amount
								m_amount = (parseFloat(rate) * parseFloat(qty)) + m_amc_amount; // Amount = (Product rate * Quantity) + AMC amount
							}

							var newRow = [];
							newRow.push({ 
								"update_btn": '<button type="button" name="update" id='+ id +' class="btn btn-warning btn-xs update">Update</button>',
								"delete_btn": '<button type="button" name="delete" id='+ id +' class="btn btn-danger btn-xs delete">Delete</button>',						
								"slNo" : id,
								"id" : id,
								"product_id" : product_id,
								"product_name" : product_name,
								"description" : description,
								"rate" : rate,
								"warranty" : warranty,
								"amc_percentage" : amc_percentage,
								"qty" : qty,
								"amc_amount" : m_amc_amount,
								"amount" : m_amount
							});
																		
							dsPurchasedDetails.push(newRow[0]);
						}

						$('#purchase_details').dataTable().fnAddData(dsPurchasedDetails);
						
						var t_amount = 0;
						if (dsPurchasedDetails.length > 0){
							for(var i = 0; i < dsPurchasedDetails.length; i++){
								t_amount += dsPurchasedDetails[i].amount;
							}
						}

						document.getElementById("txt_totalbeforegst").value = t_amount;
						
						cal_total();
					} else {
						alert("No records found.");
					}
				}
			});
		}

		function save() {
			// Customer Details
			 
			var state = selectedState; //document.getElementById("com_state").value;
			var code = selectedCode; //document.getElementById("txt_code").value;
			var cust_gstin = document.getElementById("txt_gstin").value;
			var currency = selectedCurrency; // document.getElementById("com_currency").value;
			//var customer_info = document.getElementById("txt_customer_info").value;
			
			// Invoice Details
			var invoice_no = document.getElementById("txt_invoiceno").value;
			var invoice_date = document.getElementById("invoice_dt").value;
			var order_no = document.getElementById("txt_orderno").value;
			var dated = document.getElementById("order_dt").value;
			var projectjob = document.getElementById("txt_projectjob").value;
			var hsnsac_code = document.getElementById("txt_hsnsac_code").value;

			// Purchased Details


			// Amount Details
			var total_beforegst = document.getElementById("txt_totalbeforegst").value;
			var igst_percentage = document.getElementById("txt_igst_percentage").value;
			var igst_amount = document.getElementById("txt_igst").value;
			var sgst_percentage = document.getElementById("txt_sgst_percentage").value;
			var sgst_amount = document.getElementById("txt_sgst").value;
			var cgst_percentage = document.getElementById("txt_cgst_percentage").value;
			var cgst_amount = document.getElementById("txt_cgst").value;
			var round_off = document.getElementById("txt_roundedoff").value;			
			var total_aftergst = document.getElementById("txt_totalaftergst").value;	
			
			//// Validations
			if (state == ""){
				alert("State cannot be empty.");
				return;
			}

			if (cust_gstin == ""){
				alert("GSTIN cannot be empty.");
				return;
			}

			if (currency == ""){
				alert("Currency cannot be empty.");
				return;
			}
						
			if (selectedCustomerID == ""){
				alert("Please select a customer.");
				return;
			}

			if (invoice_no == ""){
				alert("Invoice number cannot be empty.");
				return;
			}

			if (invoice_date == ""){
				alert("Invoice date cannot be empty.");
				return;
			}else{
				var invDate = invoice_date.split("-"); // Invoice Date
				invoice_date = invDate[2] + "-" + invDate[1] + "-" + invDate[0];
			}

			if (order_no == ""){
				alert("Order number cannot be empty.");
				return;
			}

			if (dated == ""){
				alert("Order date cannot be empty.");
				return;
			}else{
				var ordDate = dated.split("-"); // Order Date
				dated = ordDate[2] + "-" + ordDate[1] + "-" + ordDate[0];
			}

			if (dsPurchasedDetails.length <= 0){
				alert("Please add atleast one invoice item.");
				return;
			}
			
			var loader = document.getElementById("loader");
			loader.style.display = "block";

			var mdata = { 
				//// Customer Information
				"state" : state,
				"code" : code,
				"cust_gstin" : cust_gstin,
				"currency" : currency,
				"customer_id" : selectedCustomerID,

				//// Invoice Details
				"invoice_no" : invoice_no,
				"invoice_date" : invoice_date,
				"order_no" : order_no,
				"order_date" : dated,
				"project_job" : projectjob,
				"hsnsac_code" : hsnsac_code,

				//// Purchased Details

				//// Amount Details
				"total_beforegst" : total_beforegst,
				//"igst_percentage" : txt_igst_percentage,
				"igst" : igst_percentage,
				//"sgst_percentage" : txt_sgst_percentage,
				"sgst" : sgst_percentage,
				//"cgst_percentage" : txt_cgst_percentage,
				"cgst" : cgst_percentage,
				//"r_add" : txt_add,
				//"r_less" : txt_less,
				"round_off" : round_off,
				"total_aftergst" : total_aftergst	   
			};
			
			$.ajax({ 
			   type: "GET", 			   
			   url: "<?php echo base_url(); ?>index.php/Invoice_controller/save_invoice",
			   data: mdata
			}).done(function( data ) {
				if (data == "1"){
					
					//Save invoice items into db
					save_invoice_items(invoice_no);

					// Clear table after saving records
					if (purchaseDetails != null && purchaseDetails != "undefined"){
						$('#purchase_details').dataTable().fnClearTable();
					}	

					document.getElementById("com_state").value = "";
					document.getElementById("txt_code").value = "";
					document.getElementById("txt_gstin").value = "";
					document.getElementById("com_currency").value = "";
					document.getElementById("txt_customer_info").value = "";
			
					// Invoice Details
					document.getElementById("txt_invoiceno").value = "";
					document.getElementById("invoice_dt").value = "";
					document.getElementById("txt_orderno").value = "";
					document.getElementById("order_dt").value = "";
					document.getElementById("txt_projectjob").value = "";
					document.getElementById("txt_hsnsac_code").value = "";

					// Purchased Details


					// Amount Details
					document.getElementById("txt_totalbeforegst").value = "";
					document.getElementById("txt_igst_percentage").value = "";
					document.getElementById("txt_igst").value = "";
					document.getElementById("txt_sgst_percentage").value = "";
					document.getElementById("txt_sgst").value = "";
					document.getElementById("txt_cgst_percentage").value = "";
					document.getElementById("txt_cgst").value = "";
					document.getElementById("txt_roundedoff").value = "";			
					document.getElementById("txt_totalaftergst").value = "";

					alert("Invoice successfully created.");
					window.location.replace("<?php echo base_url(); ?>index.php/Invoice_controller?invoice_no=" + invoice_no + "");
				}else if (data == "2"){
					alert("Invoice number already exists.");
				}else{
					alert("Failed to save invoice because of the error :\n" + data);
				}
				
				loader.style.display = "none";
			});
		}

		function save_invoice_items(invoice_no){
			dsPurchasedDetails.sort(function(a,b) {
				return a.id - b.id;
			});

			if (dsPurchasedDetails.length > 0){
				for(var i = 0; i < dsPurchasedDetails.length; i++){
					var product_id = dsPurchasedDetails[i].product_id;
					var description = dsPurchasedDetails[i].description;
					var rate = dsPurchasedDetails[i].rate;
					var warranty = dsPurchasedDetails[i].warranty;
					var amc_percentage = dsPurchasedDetails[i].amc_percentage;
					var qty = dsPurchasedDetails[i].qty;
					//var amount = dsPurchasedDetails[i].amount;
							
					$.ajax({
						method: "GET",
						url: '<?php echo base_url();?>index.php/Invoice_controller/save_invoice_items',
						data: {
							"invoice_no" : invoice_no,
							"product_id" : product_id,
							"description" : description,
							"rate" : rate,
							"warranty" : warranty,
							"amc_percentage" : amc_percentage,
							"quantity" : qty
						},
						cache: false,
						success: function (data, status, xhr) {
							var res = status;
							// insert command is executed.
							//alert(data);
							//commit(true);
						},
						error: function(jqXHR, textStatus, errorThrown)
						{
							var error = errorThrown;
							//alert(data);
							//commit(false);
						}
					});
				}
				
				dsPurchasedDetails = [];
			}
		}

		function getUniqueRowID(GridData){
			var id = 1;
			if (GridData.length > 0){
				id = GridData[GridData.length - 1]["id"];
				
				while(GridData.some(el => el.id === id)){
					id = id + 1;
				}
			}
			
			return id;
		}

		function create_GUID(){
			var dt = new Date().getTime();
			var guid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
				var r = (dt + Math.random()*16)%16 | 0;
				dt = Math.floor(dt/16);
				return (c=='x' ? r :(r&0x3|0x8)).toString(16);
			});
			return guid;
		}

		//// Calculations
		function cal_igst() {
			var total_beforegst = document.getElementById("txt_totalbeforegst").value;
			var igst_percentage = document.getElementById("txt_igst_percentage").value;

			var igst_per_amount = (parseFloat(total_beforegst) * parseFloat(igst_percentage)) / 100;			
			document.getElementById("txt_igst").value = igst_per_amount;

			cal_total();
		}

		function cal_sgst() {
			var total_beforegst = document.getElementById("txt_totalbeforegst").value;
			var sgst_percentage = document.getElementById("txt_sgst_percentage").value;

			var sgst_per_amount = (parseFloat(total_beforegst) * parseFloat(sgst_percentage)) / 100;			
			document.getElementById("txt_sgst").value = sgst_per_amount;

			cal_total();
		}

		function cal_cgst() {
			var total_beforegst = document.getElementById("txt_totalbeforegst").value;
			var cgst_percentage = document.getElementById("txt_cgst_percentage").value;

			var cgst_per_amount = (parseFloat(total_beforegst) * parseFloat(cgst_percentage)) / 100;			
			document.getElementById("txt_cgst").value = cgst_per_amount;

			cal_total();
		}

		function cal_roundedoff() {
			var total_beforegst = document.getElementById("txt_totalbeforegst").value;
			var cgst_percentage = document.getElementById("txt_cgst_percentage").value;

			var cgst_per_amount = (parseFloat(total_beforegst) * parseFloat(cgst_percentage)) / 100;			
			document.getElementById("txt_cgst").value = cgst_per_amount;

			cal_total();
		}

		function cal_total() {
			var total_beforegst = document.getElementById("txt_totalbeforegst").value;
			var igst = "0";
			var sgst = "0";
			var cgst = "0";

			if (isValidNumbericValue(total_beforegst)){
				// Calculate igst
				var igst_percentage = document.getElementById("txt_igst_percentage").value;
				if (isValidNumbericValue(igst_percentage)){
					igst = (parseFloat(total_beforegst) * parseFloat(igst_percentage)) / 100;			
					document.getElementById("txt_igst").value = igst;
				}else{
					document.getElementById("txt_igst").value = "0";
				}

				// Calculate sgst
				var sgst_percentage = document.getElementById("txt_sgst_percentage").value;
				if (isValidNumbericValue(sgst_percentage)){
					sgst = (parseFloat(total_beforegst) * parseFloat(sgst_percentage)) / 100;			
					document.getElementById("txt_sgst").value = sgst;
				}else{
					document.getElementById("txt_sgst").value = "0";
				}

				// Calculate cgst
				var cgst_percentage = document.getElementById("txt_cgst_percentage").value;
				if (isValidNumbericValue(cgst_percentage)){
					cgst = (parseFloat(total_beforegst) * parseFloat(cgst_percentage)) / 100;			
					document.getElementById("txt_cgst").value = cgst;
				}else{
					document.getElementById("txt_cgst").value = "0";
				}
			}else{
				total_beforegst = "0";
			}			

			var round_off = document.getElementById("txt_roundedoff").value;
			if (round_off == undefined || round_off == ""){
				round_off = "0";
			}

			// Add total amount
			var total = (parseFloat(total_beforegst) + parseFloat(igst) + parseFloat(sgst) + parseFloat(cgst)) + parseFloat(round_off);
			document.getElementById("txt_totalaftergst").value = total;
		}

		function isValidNumbericValue(value){
			if (value != undefined && value != "" && parseFloat(value) > 0){
				return true;
			}else{
				return false;
			}
		}

		function unescapeHTML(escapedHTML) {
			if (escapedHTML == undefined || escapedHTML == "")
				return "";
			else
				return escapedHTML.replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&');
		}
		
		//// Functions End
		//// #####################################################################################################

		$(document).ready(function() {
			document.getElementById("com_state").selectedIndex = "-1";
			document.getElementById("com_cust").selectedIndex = "-1";
			//document.getElementById("com_currency").selectedIndex = "-1";
			//document.getElementById("um_fd_product_id").selectedIndex = "-1";	
			
			document.getElementById("com_quot_no").selectedIndex = "-1";
			
			document.getElementById("lbl_total_after_gst").innerHTML = "Total after GST : ("+ selectedCurrencySymbol +")";
		} );
	</script>

	<div id="modal_customer_details" class="modal fade">  
		<div class="modal-dialog">  
			<form method="post" id="form_customer_details">  
				<div class="modal-content">  
					<div class="modal-header">  
						<!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->
						<h4 class="modal-title">Add Customer</h4>  
					</div>  
					<div class="modal-body">
						<div class="row">
							<div class="col-md-12">								
								<!--<div class="form-group"><label for="um_fd_cust_id" class="col-sm-4 control-label">Customer ID</label><div class="col-sm-12"><input type="text" class="form-control" id="um_fd_cust_id" placeholder="Customer ID"></div></div>-->
								<div class="form-group"><label for="um_fd_cust_name" class="col-sm-4 control-label">Customer Name*</label><div class="col-sm-12"><input type="text" class="form-control" id="um_fd_cust_name" placeholder="Customer Name"></div></div>
								<div class="form-group"><label for="um_fd_address" class="col-sm-4 control-label">Address*</label><div class="col-sm-12"><textarea class="form-control" rows="3" id="um_fd_address" placeholder="Address"></textarea></div></div>
								<div class="form-group"><label for="um_fd_city" class="col-sm-4 control-label">City*</label><div class="col-sm-12"><input type="text" class="form-control" id="um_fd_city" placeholder="City"></div></div>
								<div class="form-group"><label for="um_fd_state" class="col-sm-4 control-label">State*</label><div class="col-sm-12"><input type="text" class="form-control" id="um_fd_state" placeholder="state"></div></div>
								<div class="form-group"><label for="um_fd_country" class="col-sm-4 control-label">Country*</label><div class="col-sm-12"><input type="text" class="form-control" id="um_fd_country" placeholder="Country"></div></div>
								<div class="form-group"><label for="um_fd_gstin" class="col-sm-4 control-label">GSTIN No*</label><div class="col-sm-12"><input type="text" class="form-control" id="um_fd_gstin" placeholder="GSTIN No"></div></div>
								<div class="form-group"><label for="um_fd_pan" class="col-sm-4 control-label">PAN No*</label><div class="col-sm-12"><input type="text" class="form-control" id="um_fd_pan" placeholder="PAN No"></div></div>
								<div class="form-group"><label for="um_fd_tan" class="col-sm-4 control-label">TAN No*</label><div class="col-sm-12"><input type="text" class="form-control" id="um_fd_tan" placeholder="TAN No"></div></div>
							</div>
						</div>
					</div>  
					<div class="modal-footer">						
						<input type="submit" name="action_submit_customer" id="action_submit_customer" class="btn btn-success" value="Add" />  
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
					</div>
				</div>  
			</form>  
		</div>  
	</div>

	<div id="modal_purchased_details" class="modal fade">  
		<div class="modal-dialog">  
			<form method="post" id="form_purchased_details">  
				<div class="modal-content">  
					<div class="modal-header">  
						<!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->
						<h4 class="modal-title">Add Item</h4>  
					</div>  
					<div class="modal-body">
						<div class="row">
							<div class="col-md-12">								
								<div class="form-group row">
									<label for="um_fd_product_id" class="col-sm-2 col-form-label">Product</label>
									<div class="col-sm-9">
										<!---->
										<select class="form-control" id="um_fd_product_id" name="um_fd_product_id">
											<?php 
												foreach ($products->result_array() as $row)
												{
													echo "<option value=".$row['Product_ID'].">".$row['Product_Name']." (".$row['Edition'].")"."</option>";	
												}
											?>
										</select>
									</div>
									<button type="button" id="btn_add_product" data-toggle="modal" data-target="#modal_product_details" class="btn btn-info">
									+
									</button>
								</div>

								<input type="hidden" class="form-control" id="um_fd_product_name" placeholder="Product Name">
								<!-- <div class="form-group"><label for="um_fd_product_version" class="col-sm-4 control-label">Product Version</label><div class="col-sm-12"><input type="text" class="form-control" id="um_fd_product_version" ></div></div> -->

								<div class="form-group"><label for="um_fd_description" class="col-sm-4 control-label">Description</label><div class="col-sm-12"><textarea class="form-control" rows="3" id="um_fd_description" placeholder="Description"></textarea></div></div>
								<div class="form-group"><label for="um_fd_rate" class="col-sm-4 control-label">Rate</label><div class="col-sm-12"><input type="text" class="form-control" id="um_fd_rate" placeholder="Rate"></div></div>
								
								<div class="form-group">
									<label for="um_fd_warranty" class="col-sm-4 col-form-label">Warranty</label>
									<div class="col-sm-12">
										<!---->
										<select class="form-control" id="um_fd_warranty" name="um_fd_warranty">
											<option value="1">1 Year</option>
											<option value="2">2 Years</option>
											<option value="3">3 Years</option>
											<option value="4">4 Years</option>
											<option value="5">5 Years</option>
										</select>
									</div>									
								</div>
								<div class="form-group"><label for="um_fd_amc_percentage" class="col-sm-4 control-label">AMC (%)</label><div class="col-sm-12"><input type="text" class="form-control" id="um_fd_amc_percentage" placeholder="AMC Percentage" value="10"></div></div>
								<div class="form-group"><label for="um_fd_qty" class="col-sm-4 control-label">Quantity</label><div class="col-sm-12"><input type="text" class="form-control" id="um_fd_qty" placeholder="Quantity"></div></div>
							</div>
						</div>
					</div>  
					<div class="modal-footer">  
						<input type="hidden" name="um_fd_id" id="um_fd_id" />
						<input type="hidden" name="um_fd_mobile_number" id="um_fd_mobile_number" />
						<input type="hidden" name="um_fd_userid" id="um_fd_userid" />
						<input type="hidden" name="um_fd_createddate" id="um_fd_createddate" />
						<input type="hidden" name="um_fd_zone" id="um_fd_zone" />
						<input type="submit" name="action_submit" id="action_submit" class="btn btn-success" value="Add" />  
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
					</div>
				</div>  
			</form>  
		</div>  
	</div>

	<div id="modal_product_details" class="modal fade">  
		<div class="modal-dialog">  
			<form method="post" id="form_product_details">  
				<div class="modal-content">  
					<div class="modal-header">  
						<!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->
						<h4 class="modal-title">Add Product</h4>  
					</div>  
					<div class="modal-body">
						<div class="row">
							<div class="col-md-12">								
								<!--<div class="form-group"><label for="um_fd_cust_id" class="col-sm-4 control-label">Customer ID</label><div class="col-sm-12"><input type="text" class="form-control" id="um_fd_cust_id" placeholder="Customer ID"></div></div>-->
								<div class="form-group"><label for="um_fd_prod_name" class="col-sm-4 control-label">Product Name*</label><div class="col-sm-12"><input type="text" class="form-control" id="um_fd_prod_name" placeholder="Product Name"></div></div>
								<!-- <div class="form-group"><label for="um_fd_prod_version" class="col-sm-4 control-label">Product Version*</label><div class="col-sm-12"><input type="text" class="form-control" id="um_fd_prod_version" placeholder="Product Version"></div></div> -->
								<div class="form-group"><label for="um_fd_prod_desc" class="col-sm-4 control-label">Description*</label><div class="col-sm-12"><textarea rows="3" class="form-control" id="um_fd_prod_desc" placeholder="Description"></textarea></div></div>
								<div class="form-group"><label for="um_fd_prod_rate" class="col-sm-4 control-label">Rate*</label><div class="col-sm-12"><input type="text" class="form-control" id="um_fd_prod_rate" placeholder="Rate"></div></div>
								<div class="form-group"><label for="um_fd_edition" class="col-sm-4 control-label">Edition*</label><div class="col-sm-12"><input type="text" class="form-control" id="um_fd_edition" placeholder="Edition"></div></div>								
							</div>
						</div>
					</div>  
					<div class="modal-footer">						
						<input type="submit" name="action_submit_product" id="action_submit_product" class="btn btn-success" value="Add" />  
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
					</div>
				</div>  
			</form>  
		</div>  
	</div>