<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <!--<h1 class="m-0 text-dark">View Invoice</h1>-->
          </div><!-- /.col -->
          <div class="col-sm-6">
            <!--<ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">View Invoice</li>
            </ol>-->
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

	<style>
		
		table, th, td {
			border: 1px solid lightgrey;
			border-collapse: collapse;
			font-size:10px;
		}
		th, td {
			padding: 0px;
			text-align: left;    
		}
	</style>

    <!-- Main content -->
    <section class="content">
		<div class="container-fluid">
			<div class="form-group row" id="invoice_div">
				<label for="com_inv_no" class="col-sm-2 col-form-label" id="lbl_for_inv_no" name="lbl_for_inv_no">Invoice No :</label>
				<div class="col-sm-4">
					<select class="form-control" id="com_inv_no" name="com_inv_no">
						<?php 
							foreach ($invoices->result_array() as $row)
							{
								echo "<option value=".$row['Invoice_No'].">".$row['Invoice_No'] ."</option>";	
							}	
						?>
					</select>
				</div>
			</div>
			<div class="row">
				<section class="col-lg-3 connectedSortable">
				</section>
				<section class="col-lg-6 connectedSortable">
					<div class="col-sm-6 col-form-label"><b>TAX INVOICE</b></div>
					<div class="col-sm-6 col-form-label">GSTIN : 29AAFCP3322E1ZN</div>
				</section>
				<section class="col-lg-3 connectedSortable">
					<div class="col-sm-6 col-form-label">[ ] ORIGINAL</div>
					<div class="col-sm-6 col-form-label">[ ] DUPLICATE</div>
					<div class="col-sm-6 col-form-label">[ ] TRIPLICATE</div>
				</section>
			</div>
			<div class="row">
				<section class="col-lg-6 connectedSortable">
					<label class="col-form-label">Bill To</label>
					<div class="table-responsive">
						<table class="table" style="height:150px;">
							<tr>												
								<td>
									<label class="col-form-label">State</label>
								</td>
								<td>
									<label class="col-form-label" id="lbl_state" name="lbl_state"></label>
								</td>
								<td>
									<label class="col-form-label">Code</label>
								</td>
								<td>
									<label class="col-form-label" id="lbl_code" name="lbl_code"></label>
								</td>
							</tr>
							<tr>
								<td>
									<label class="col-form-label">GSTIN</label>
								</td>
								<td colspan="3">
									<label class="col-form-label" id="lbl_gstin" name="lbl_gstin"></label>
								</td>
							</tr>
							<tr>
								<td rowspan="2" colspan="4">
									<p><b>To,<br><label class="col-form-label" id="lbl_cust_name" name="lbl_cust_name"></label></b></p>
									<p><label class="col-form-label" id="lbl_cust_address" name="lbl_cust_address"></label></p>
								</td>
							</tr>
							<tr>
								
							</tr>							
						</table>
					</div>	
				</section>					
				<section class="col-lg-6 connectedSortable">	
					<label class="col-form-label">Invoice Details</label>
					<div class="table-responsive">
						<table class="table">
							<tr>												
								<td>
									<label class="col-form-label">Invoice No</label>
								</td>
								<td>
									<label class="col-form-label" id="lbl_inv_no" name="lbl_inv_no"></label>
								</td>								
							</tr>
							<tr>	
								<td>
									<label class="col-form-label">Invoice Date</label>
								</td>
								<td>
									<label class="col-form-label" id="lbl_inv_date" name="lbl_inv_date"></label>
								</td>								
							</tr>	
							<tr>	
								<td>
									<label class="col-form-label">Order No</label>
								</td>
								<td>
									<label class="col-form-label" id="lbl_order_no" name="lbl_order_no"></label>
								</td>								
							</tr>
							<tr>	
								<td>
									<label class="col-form-label">Dated</label>
								</td>
								<td>
									<label class="col-form-label" id="lbl_dated" name="lbl_dated"></label>
								</td>								
							</tr>
							<tr>	
								<td>
									<label class="col-form-label">Project/Job</label>
								</td>
								<td>
									<label class="col-form-label" id="lbl_project_job" name="lbl_project_job"></label>
								</td>								
							</tr>
							<tr>	
								<td>
									<label class="col-form-label">HSN/SAC CODE</label>
								</td>
								<td>
									<label class="col-form-label" id="lbl_hsn_sac_code" name="lbl_hsn_sac_code"></label>
								</td>								
							</tr>
						</table>
					</div>	
				</section>
			</div>	
			<div class="row">
				<section class="col-lg-12 connectedSortable">
					<div class="table-responsive">
						<table class="table" id="itemsTable" name="itemsTable">
							<thead>
								<tr>
									<th>SLNo.</th>
									<th>ITEM DESCRIPTION</th>
									<th>RATE</th>
									<th>QTY</th>
									<th>AMOUNT</th>
								</tr>
							</thead>
							
						</table>
					</div>
				</section>
			</div>
			<div class="row">
				<section class="col-lg-12 connectedSortable">
					<div class="table-responsive">
						<table class="table">
							<tr>
								<td rowspan="6">
									<label class="col-form-label">Rupees One Lakh Thirty Eight Thousand Sixty and Paise Zero Only</label>
								</td>
								<td colspan="2">
									<label class="col-form-label">Total Before GST</label>
								</td>								
								<td>
									<label class="col-form-label" id="lbl_total_before_gst" name="lbl_total_before_gst"></label>
								</td>
							</tr>	
							<tr>								
								<td>
									<label class="col-form-label">IGST @ % OF</label>
								</td>
								<td>
									<label class="col-form-label" id="lbl_igst_perc" name="lbl_igst_perc"></label>
								</td>
								<td>
									<label class="col-form-label" id="lbl_igst_value" name="lbl_igst_value"></label>
								</td>
							</tr>
							<tr>								
								<td>
									<label class="col-form-label">SGST @ % OF</label>
								</td>
								<td>
									<label class="col-form-label" id="lbl_sgst_perc" name="lbl_sgst_perc"></label>
								</td>
								<td>
									<label class="col-form-label" id="lbl_sgst_value" name="lbl_sgst_value"></label>
								</td>
							</tr>
							<tr>								
								<td>
									<label class="col-form-label">CGST @ % OF</label>
								</td>
								<td>
									<label class="col-form-label" id="lbl_cgst_perc" name="lbl_cgst_perc"></label>
								</td>
								<td>
									<label class="col-form-label" id="lbl_cgst_value" name="lbl_cgst_value"></label>
								</td>
							</tr>
							<tr>								
								<td rowspan="2">
									<label class="col-form-label">Rounded off</label>
								</td>
								<td>
									<label class="col-form-label">Add</label>
								</td>
								<td>
									<label class="col-form-label" id="lbl_rounded_off_add" name="lbl_rounded_off_add"></label>
								</td>
							</tr>
							<tr>								
								<td>
									<label class="col-form-label">Less</label>
								</td>
								<td>
									<label class="col-form-label" id="lbl_rounded_off_less" name="lbl_rounded_off_less"></label>
								</td>
							</tr>
							<tr>
								<td>
									<label class="col-form-label">This is a computer generated letter, no signature is required</label>
								</td>
								<td colspan="2">
									<label class="col-form-label">Total after GST</label>
								</td>
								
								<td>
									<label class="col-form-label" id="lbl_total_after_gst" name="lbl_total_after_gst"></label>
								</td>
							</tr>
						</table>
					</div>	
				</section>
			</div>
			<div class="row">
				<section class="col-lg-6 connectedSortable">
					<p>
						TERMS OF PAYMENT: By account payee Demand Draft/Cheque/NEFT/RTGS drawn in favour of 
						Prosoft e-Solutions India Pvt. Ltd. ( Payable at Karnataka Belgaum )<br>
						Beneficiary Name : Prosoft e-Solutions India Pvt Ltd.<br>
						Account No : 370301010041231 IFSC Code : UBIN0537039<br>
						Bank : Union Bank Of India Branch : Market Yard, Nehru Nagar Belgaum<br><br>
						<b>GSTIN : 29AAFCP3322E1ZN<br>PAN No.: AAFCP3322E</b>
					</p>
				</section>
				<section class="col-lg-6 connectedSortable">
					<label class="col-form-label">FOR Prosoft e-Solutions India Pvt. Ltd.</label>
				</section>
			</div>
			<hr style="height:2px;border-width:0;color:gray;background-color:gray">
			<div class="row">
				<section class="col-lg-6 connectedSortable">
					<p>
						<b>PROSOFT e-SOLUTIONS INDIA PVT. LTD</b><br>
						PROSOFT HOUSE, BEL-HEIGHTS APARTMENT, 2nd FLOOR, 303 & 304 CTS NO. 2523/2<br>
						ANNAPURNAWADI, AZAM NAGAR, BELGAUM-590010 | KARNATAKA | INDIA |<br>
						Contact No. +91 9743577121, 9019858560
					</p>
				</section>
				<section class="col-lg-6 connectedSortable">
					<img src="<?php echo base_url(); ?>dist/img/credit/visa.png" alt="Visa">
					<img src="<?php echo base_url(); ?>dist/img/credit/mastercard.png" alt="Mastercard">
					<img src="<?php echo base_url(); ?>dist/img/credit/american-express.png" alt="American Express">
				</section>
			</div>
			<div class="row" id="print_btn_div" name="print_btn_div">
				<section class="col-lg-6 connectedSortable">
					<button class="btn btn-primary float-right"
							id="btn_print" name="btn_print" style="color:white"> 
						Print 
					</button>
				</section>
			</div>
		</div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  
	<!-- jQuery -->
	<script src="<?php echo base_url();?>plugins/jquery/jquery.min.js"></script>
	<!-- Bootstrap 4 -->
	<script src="<?php echo base_url();?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
	<script src="<?php echo base_url();?>plugins/select2/js/select2.full.min.js"></script>
	<!-- Bootstrap4 Duallistbox -->
	<script src="<?php echo base_url();?>plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js"></script>
	<!-- InputMask -->
	<script src="<?php echo base_url();?>plugins/moment/moment.min.js"></script>
	<script src="<?php echo base_url();?>plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>
	<!-- date-range-picker -->
	<script src="<?php echo base_url();?>plugins/daterangepicker/daterangepicker.js"></script>
	<!-- Tempusdominus Bootstrap 4 -->
	<script src="<?php echo base_url();?>plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>	
	<!-- overlayScrollbars -->
	<script src="<?php echo base_url();?>plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
	
	<!-- DataTables -->
	<script src="<?php echo base_url();?>plugins/datatables/jquery.dataTables.min.js"></script>
	<script src="<?php echo base_url();?>plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
	<script src="<?php echo base_url();?>plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
	<script src="<?php echo base_url();?>plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
	
	<!-- AdminLTE App -->
	<script src="<?php echo base_url();?>dist/js/adminlte.js"></script>

	<script type="text/javascript">
		//// #####################################################################################################
		//// Events start
		$('#com_inv_no').change(function(){
			selectedInvoice = $(this).val();				
			loadInvoice(selectedInvoice);
		})		

		function loadInvoice(selectedInvoice){
			// Clear all invoice items list
			var myTable = document.getElementById("itemsTable");
			var rowCount = myTable.rows.length;
			for (var x=rowCount-1; x>0; x--) {
			   myTable.deleteRow(x);
			}

			// Clear all fields
			document.getElementById('lbl_state').innerHTML = "";
			document.getElementById('lbl_code').innerHTML = "";
			document.getElementById('lbl_gstin').innerHTML = "";
			document.getElementById('lbl_cust_name').innerHTML = "";
			document.getElementById('lbl_cust_address').innerHTML = "";

			document.getElementById('lbl_inv_no').innerHTML = "";
			document.getElementById('lbl_inv_date').innerHTML = "";
			document.getElementById('lbl_order_no').innerHTML = "";
			document.getElementById('lbl_dated').innerHTML = "";
			document.getElementById('lbl_project_job').innerHTML = "";
			document.getElementById('lbl_hsn_sac_code').innerHTML = "";

			document.getElementById('lbl_total_before_gst').innerHTML = "0";
			document.getElementById('lbl_igst_perc').innerHTML = "0";
			document.getElementById('lbl_igst_value').innerHTML = "0";
			document.getElementById('lbl_sgst_perc').innerHTML = "0";
			document.getElementById('lbl_sgst_value').innerHTML = "0";
			document.getElementById('lbl_cgst_perc').innerHTML = "0";
			document.getElementById('lbl_cgst_value').innerHTML = "0";
			
			var mdata = {
				"invoice_no" : selectedInvoice	   
			};
			
			$.ajax({ 
			   type: "GET", 			   
			   url: "<?php echo base_url(); ?>index.php/Invoice_controller/get_invoice_details",
			   data: mdata
			}).done(function( data ) {
				if (data != 110){
					var json_obj = jQuery.parseJSON(data);
					if (json_obj.length > 0){						
						document.getElementById('lbl_state').innerHTML = json_obj[0].State;
						document.getElementById('lbl_code').innerHTML = json_obj[0].Code;
						document.getElementById('lbl_gstin').innerHTML = json_obj[0].Customer_GSTIN_No;
						document.getElementById('lbl_cust_name').innerHTML = json_obj[0].Customer_Name;
						document.getElementById('lbl_cust_address').innerHTML = json_obj[0].Customer_Address;

						document.getElementById('lbl_inv_no').innerHTML = json_obj[0].Invoice_No;
						document.getElementById('lbl_inv_date').innerHTML = new Date(json_obj[0].Invoice_Date).toDateString();
						document.getElementById('lbl_order_no').innerHTML = json_obj[0].Order_No;
						document.getElementById('lbl_dated').innerHTML = new Date(json_obj[0].Order_Date).toDateString();
						document.getElementById('lbl_project_job').innerHTML = json_obj[0].Project_Job;
						document.getElementById('lbl_hsn_sac_code').innerHTML = json_obj[0].HSN_SAC_Code;

						document.getElementById('lbl_total_before_gst').innerHTML = json_obj[0].Total_Before_GST;
						document.getElementById('lbl_igst_perc').innerHTML = json_obj[0].IGST;
						document.getElementById('lbl_igst_value').innerHTML = "0";
						document.getElementById('lbl_sgst_perc').innerHTML = json_obj[0].SGST;
						document.getElementById('lbl_sgst_value').innerHTML = "0";
						document.getElementById('lbl_cgst_perc').innerHTML = json_obj[0].CGST;
						document.getElementById('lbl_cgst_value').innerHTML = "0";
						
						var rOff = json_obj[0].Round_Off;
						if (parseFloat(rOff) > 0){
							document.getElementById('lbl_rounded_off_add').innerHTML = rOff;
							document.getElementById('lbl_rounded_off_less').innerHTML = "0";
						}else{
							document.getElementById('lbl_rounded_off_add').innerHTML = "0";
							document.getElementById('lbl_rounded_off_less').innerHTML = rOff;
						}
						
						document.getElementById('lbl_total_after_gst').innerHTML = json_obj[0].Total_After_GST;

						cal_total();
					}
				}else{
					alert("Failed to get invoice details because of the error :\n" + data);
				}				
			});

			$.ajax({ 
			   type: "GET", 			   
			   url: "<?php echo base_url(); ?>index.php/Invoice_controller/get_invoice_item_details",
			   data: mdata
			}).done(function( data ) {
				if (data == 110){
					alert("No invoice items found.");
				}else if(data == 111){
					alert("Failed to get invoice item details because of the error :\n" + data);
				}else{
					var json_obj = jQuery.parseJSON(data);
					if (json_obj.length > 0){
						if ($("#itemsTable tbody").length == 0) {
							$("#itemsTable").append("<tbody></tbody>");
						}

						for(var i=0; i<json_obj.length; i++){
							$("#itemsTable tbody").append("<tr>" +
																"<td>"+ (i + 1) +"</td>" +
																"<td><b>"+ json_obj[i].Product_Name +"</b><br>"+ json_obj[i].Product_Desc +"</td>" +
																"<td>"+ json_obj[i].Rate +"</td>" +
																"<td>"+ json_obj[i].Quantity +"</td>" +
																"<td>"+ parseFloat(json_obj[i].Rate) * parseFloat(json_obj[i].Quantity) +"</td>" +
														"</tr>");
						}
					}
				}				
			});
		}

		$('#btn_print').click(function(){
			var invoice_div = document.getElementById("invoice_div");
			var print_btn_div = document.getElementById("print_btn_div");

			invoice_div.style.display = "none";
			print_btn_div.style.display = "none";

			window.print();

			invoice_div.style.display = "block";
			print_btn_div.style.display = "block";
		})

		//// Calculations		
		function cal_total() {
			var total_beforegst = document.getElementById("lbl_total_before_gst").innerHTML;
			var igst = "0";
			var sgst = "0";
			var cgst = "0";

			if (isValidNumbericValue(total_beforegst)){
				// Calculate igst
				var igst_percentage = document.getElementById("lbl_igst_perc").innerHTML;
				if (isValidNumbericValue(igst_percentage)){
					igst = (parseFloat(total_beforegst) * parseFloat(igst_percentage)) / 100;			
					document.getElementById("lbl_igst_value").innerHTML = igst;
				}else{
					document.getElementById("lbl_igst_value").innerHTML = "0";
				}

				// Calculate sgst
				var sgst_percentage = document.getElementById("lbl_sgst_perc").innerHTML;
				if (isValidNumbericValue(sgst_percentage)){
					sgst = (parseFloat(total_beforegst) * parseFloat(sgst_percentage)) / 100;			
					document.getElementById("lbl_sgst_value").innerHTML = sgst;
				}else{
					document.getElementById("lbl_sgst_value").innerHTML = "0";
				}

				// Calculate cgst
				var cgst_percentage = document.getElementById("lbl_cgst_perc").innerHTML;
				if (isValidNumbericValue(cgst_percentage)){
					cgst = (parseFloat(total_beforegst) * parseFloat(cgst_percentage)) / 100;			
					document.getElementById("lbl_cgst_value").innerHTML = cgst;
				}else{
					document.getElementById("lbl_cgst_value").innerHTML = "0";
				}
			}else{
				total_beforegst = "0";
			}			

			var round_off_add = document.getElementById("lbl_rounded_off_add").innerHTML;
			if (round_off_add == undefined || round_off_add == ""){
				round_off_add = "0";
			}

			var round_off_less = document.getElementById("lbl_rounded_off_less").innerHTML;
			if (round_off_less == undefined || round_off_less == ""){
				round_off_less = "0";
			}

			// Add total amount
			var total = (parseFloat(total_beforegst) + parseFloat(igst) + parseFloat(sgst) + parseFloat(cgst)) + parseFloat(round_off_add) + parseFloat(round_off_less);
			document.getElementById("lbl_total_after_gst").innerHTML = total;
		}
		
		function isValidNumbericValue(value){
			if (value != undefined && value != "" && parseFloat(value) > 0){
				return true;
			}else{
				return false;
			}
		}

		//// Functions End
		//// #####################################################################################################

		$(document).ready(function() {
			var newInvoiceNo = "<?php echo $new_invoice_no; ?>";
			//alert(newInvoiceNo);

			document.getElementById('com_inv_no').value = newInvoiceNo;
			loadInvoice(newInvoiceNo);
		} );
	</script>