			<footer class="main-footer" id="footer" name="footer">
				<div class="float-right d-none d-sm-block">
				  <b>Version</b> 1.1.0
				</div>
				<strong>Copyright &copy; 2019-2020 <a href="http://prosoftesolutions.com">Prosoft e-Solutions Ind Pvt Ltd</a>.</strong> All rights reserved
			</footer>


			

			<!-- Control Sidebar -->
			<aside class="control-sidebar control-sidebar-dark">
				<!-- Add Content Here -->
			</aside>
			<!-- /.control-sidebar -->
		</div>
		<!-- ./wrapper -->	 


		<!-- to display country code -->
			<script src="<?php echo base_url();?>dist/js/intlTelInput.js"></script>
			<script src="<?php echo base_url();?>dist/js/utils.js"></script> 
			<script src="<?php echo base_url();?>dist/js/popper.js"></script> 

		<!-- calling country code method -->
		<script src="<?php echo base_url();?>dist/js/countrycode.js"></script>

		<!-- download webpage as a pdf -->
		<script src="<?php echo base_url();?>dist/js/htmltoPdf.js"></script>

	</body>
</html>
	  
	  