<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">View Quotation</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">View Quotation</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <!-- <div class="callout callout-info">
              <h5><i class="fas fa-info"></i> Note:</h5>
              This page has been enhanced for printing. Click the print button at the bottom of the quotation to test.
            </div> -->

                    <!-- Quotation Selection -->
                    <div class="form-group row no-print" id="quotation_div">
                        <label for="com_quot_no" class="col-sm-2 col-form-label" id="lbl_for_quot_no" name="lbl_for_quot_no">
                            Select Quotation :</label>
                        <div class="col-sm-4">
                            <select class="form-control" id="com_quot_no" name="com_quot_no">
                                <?php
								if ($quotations != 0){
									foreach ($quotations->result_array() as $row) {
										echo "<option value=" . $row['Quotation_No'] . ">" . $row['Quotation_No'] . "</option>";
									}
								}
                                ?>
                            </select>
                        </div>
                    </div>

                    <!-- Main content -->
                    <div class="invoice p-3 mb-3">
                       <!-- prosoft title & logo -->
                       <div class="row">
                            <div class="col-md-6">
                                <img style="width: 80px;" src="<?php echo base_url(); ?>dist/img/Prosoft_LogoBlue.png" alt="logo">
                            </div>
                            <div class="col-md-6">
                                <div class="float-right small">
                                    <div>
                                    <h5 style="margin-bottom: 0; color: #0A3FFF">Prosoft e-Solutions India Pvt. Ltd.</h5>
                                    <small>www.prosoftesolutions.com | info@prosoftesolutions.com</small><br>
                                    <small>A N - I S O 9 0 0 1 - 2 0 1 5 - C E R T I F I E D - C O M P A N Y</small><br>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- title row tax quotation -->
                        <div class="row mt-3">
                            <div class="col-md-12 pl-5 text-center ">
                                <h4 class="text-bold">QUOTATION</h4>
                            </div>
                            <!-- <div class="col-md-1 small">
                                <div class="float-right">
                                    <small>[ ] ORIGINAL</small><br>
                                    <small>[ ] DUPLICATE</small><br>
                                    <small>[ ] TRIPLICATE</small><br>
                                </div>
                            </div> -->
                        </div>

                        <!-- quotation info row -->
                        <div class="row mt-3">

                            <div class="col-md-6 table-responsive ">
                                <label class="quotation-col">Quotation To</label>
                                <div class="card-body p-0">


                                    <table class="table table-bordered table-sm">

                                        <tr>
                                            <th class="h6 text-bold" style="width: 10%">State:</th>
                                            <td class="h6" id="lbl_state"></td>
                                            <td class="h6 text-bold" style="width: 10%">Code:</td>
                                            <td class="h6" id="lbl_code"></td>
                                        </tr>
                                        <tr>
                                            <th class="h6 text-bold" style="width: 10%">GSTN:</th>
                                            <td class="h6" id="lbl_gstin"></td>

											<td class="h6 text-bold" style="width: 10%">Currency:</td>
                                            <td class="h6" id="lbl_currency"></td>
                                        </tr>
                                        <tr style="height: 118px;">
                                            <td colspan="4">
                                                <p class="h6">To,</p>
                                                <p class="h6 text-bold" id="lbl_cust_name"></p>
                                                <p class="h6" id="lbl_cust_address"></p>
                                                <p id="lbl_cust_address"></p>
                                                <p id="lbl_cust_city"></p>
                                            </td>
                                        </tr>
                                    </table>

                                </div>
                            </div>
                            
                            <div class="col-md-6 table-responsive">
                                <label class="quotation-col">Quotation Details</label>
                                <div class="card-body p-0 ">


                                    <table class="table table-bordered table-sm">

                                        <tr>
                                            <th class="h6 text-bold" style="width: 40%">Quotation No:</th>
                                            <td class="h6" id="lbl_quot_no"></td>
                                        </tr>
                                        <tr>
                                            <th class="h6 text-bold">Quotation Date:</th>
                                            <td class="h6" id="lbl_quot_date"></td>
                                        </tr>
                                        <tr>
                                            <th class="h6 text-bold">Reference No:</th>
                                            <td class="h6" id="lbl_reference_no"></td>
                                        </tr>
                                        <tr>
                                            <th class="h6 text-bold">Dated:</th>
                                            <td class="h6" id="lbl_dated"></td>
                                        </tr>
                                        <tr>
                                            <th class="h6 text-bold">Prepared By:</th>
                                            <td class="h6" id="lbl_preparedby"></td>
                                        </tr>
                                        <tr>
                                            <th class="h6 text-bold">Project/Job:</th>
                                            <td class="h6" id="lbl_project_job"></td>
                                        </tr>
                                        <tr>
                                            <th class="h6 text-bold">HSN/SAC CODE:</th>
                                            <td class="h6" id="lbl_hsn_sac_code"></td>
                                        </tr>

                                    </table>
                                </div>
                            </div>
                        </div>

                        <!-- item table row  -->
                        <div class="row mt-3">
                            <div class="col-md-12 table-responsive">

                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered table-sm" id="itemsTable" name="$('#com_quot_no">

 <!--                               <div class="card-body p-0">
                                    <table class="table table-striped" id="itemsTable" name="$('#com_quot_no">
-->

                                        <thead>
                                            <tr style="height: 10px;min-height: 5px;max-height: 10px;">
                                                <th class='h6 text-bold text-center' style="font-size: 14px;width: 5%">SL.No.</th>
                                                <th class='h6 text-bold text-center' style="font-size: 14px;width: 55%">ITEM DESCRIPTION</th>
                                                <th class='h6 text-bold text-center' id="selected_rate" style="font-size: 14px;width: 10%">RATE</th>
                                                <th class='h6 text-bold text-center' style="font-size: 14px;width: 10%">QTY.</th>
                                                <th class='h6 text-bold text-center' style="font-size: 14px;width: 10%">AMC AMOUNT</th>
                                                <th class='h6 text-bold text-center' style="font-size: 14px;width: 10%">AMOUNT</th>
                                            </tr>
                                        </thead>
                                    </table>
                                </div>
                            </div>
                        </div>
 
                        <!-- total table row  -->
                        <div class="row mt-3">
                            <div class="col-md-12 table-responsive">

                                <div class="table-responsive">
                                    <table class="table table-bordered table-sm">
                                        <tr>

<!--                                <div class="card-body p-0">
                                    <table class="table table-sm">
                                        <tr style='font-size: 14px;padding: 1px 5px 1px 1px'>
-->

                                            <td class="h6" rowspan="6">
                                                <p>Amount in Words:</p>
                                                <label class="h6" id="lbl_amt_in_words"></label>
                                            </td>
                                            <td class="h6 text-right text-bold" style='padding: 1px 1px 1px 1px' colspan="2">Total Before GST</td>
                                            <td class="h6 text-right text-bold" style='padding: 1px 1px 1px 1px' id="lbl_total_before_gst"> </td>
                                        </tr>
                                        <tr style='padding: 1px 1px 1px 1px'>
                                            <td class="h6 text-right" style='padding: 1px 1px 1px 1px' >IGST @ % OF</td>
                                            <td class="h6 text-right" style='padding: 1px 1px 1px 1px'id="lbl_igst_perc" name="lbl_igst_perc"></td>
                                            <td class="h6 text-right" style='padding: 1px 1px 1px 1px'id="lbl_igst_value" name="lbl_igst_value"></td>
                                        </tr>
                                        <tr>
                                            <td class="h6 text-right" style='padding: 1px 1px 1px 1px'>SGST @ % OF</td>
                                            <td class="h6 text-right" style='padding: 1px 1px 1px 1px' id="lbl_sgst_perc" name="lbl_sgst_perc"></td>
                                            <td class="h6 text-right" style='padding: 1px 1px 1px 1px' id="lbl_sgst_value" name="lbl_sgst_value"></td>
                                        </tr>
                                        <tr>
                                            <td class="h6 text-right" style='padding: 1px 1px 1px 1px'>CGST @ % OF</td>
                                            <td class="h6 text-right" style='padding: 1px 1px 1px 1px'id="lbl_cgst_perc" name="lbl_cgst_perc"></td>
                                            <td class="h6 text-right" style='padding: 1px 1px 1px 1px'id="lbl_cgst_value" name="lbl_cgst_value"></td>
                                        </tr>
                                        <tr>
                                            <td rowspan="2" class="h6 text-right"style='padding: 1px 1px 1px 1px'>Rounded off</td>
                                            <td class="h6 text-right small"style='padding: 1px 1px 1px 1px'>Add</td>
                                            <td class="h6 text-right" id="lbl_rounded_off_add" name="lbl_rounded_off_add"style='padding: 1px 1px 1px 1px'></td>
                                        </tr>
                                        <tr>
                                            <td class="h6  text-right small"style='padding: 1px 1px 1px 1px'>Less</td>
                                            <td class="h6 text-right" id="lbl_rounded_off_less" name="lbl_rounded_off_less"style='padding: 1px 1px 1px 1px'></td>
                                        </tr>
                                        <tr>
                                            <td>This is a computer generated quotation, no signature is required</td>
                                            <td class="h6 text-right text-bold total_after_gst" id ="total_after_gst" colspan="2">Total after GST</td>
                                            <td class="h6 text-right text-bold" id="lbl_total_after_gst" name="lbl_total_after_gst" style='padding: 1px 1px 1px 1px'></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <!-- Table row -->
                        <!-- <div class="row">
                            <div class="col-12 table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Qty</th>
                                            <th>Product</th>
                                            <th>Serial #</th>
                                            <th>Description</th>
                                            <th>Subtotal</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td>Call of Duty</td>
                                            <td>455-981-221</td>
                                            <td>El snort testosterone trophy driving gloves handsome</td>
                                            <td>$64.50</td>
                                        </tr>
                                        <tr>
                                            <td>1</td>
                                            <td>Need for Speed IV</td>
                                            <td>247-925-726</td>
                                            <td>Wes Anderson umami biodiesel</td>
                                            <td>$50.00</td>
                                        </tr>
                                        <tr>
                                            <td>1</td>
                                            <td>Monsters DVD</td>
                                            <td>735-845-642</td>
                                            <td>Terry Richardson helvetica tousled street art master</td>
                                            <td>$10.70</td>
                                        </tr>
                                        <tr>
                                            <td>1</td>
                                            <td>Grown Ups Blue Ray</td>
                                            <td>422-568-642</td>
                                            <td>Tousled lomo letterpress</td>
                                            <td>$25.99</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div> -->
                        <!-- /.row -->

                        <!-- term of payment -->

                        <div class="row mt-3">
                            
                            <div class="col-8 small">
                                <!-- <p class="lead">Terms of Payment:</p> -->
                                <!-- <img src="../../dist/img/credit/visa.png" alt="Visa">
                                <img src="../../dist/img/credit/mastercard.png" alt="Mastercard">
                                <img src="../../dist/img/credit/american-express.png" alt="American Express">
                                <img src="../../dist/img/credit/paypal2.png" alt="Paypal"> -->

                                <p class="text-muted well well-sm shadow-none" style="margin-top: 10px;">
                                    TERMS OF PAYMENT: By account payee Demand Draft/Cheque/NEFT/RTGS drawn in favour of <br> 
                                    Prosoft e-Solutions India Pvt. Ltd. (Payable at Karnataka, Belagavi )<br>
                                    Beneficiary Name : Prosoft e-Solutions India Pvt Ltd.<br>
                                    Account No : 370301010041231 IFSC Code : UBIN0537039<br>
                                    Bank : Union Bank Of India Branch : Market Yard, Nehru Nagar, Belagavi<br><br>
                                    <b>GSTIN : 29AAFCP3322E1ZN<br>PAN No.: AAFCP3322E</b>
                                </p>
                            </div>
                            <div class="col-4 mt-3">
                                <p class="h6 text-center">for <strong>  Prosoft e-Solutions India Pvt. Ltd.</strong></p>
                                    <div>
                                        <img style="width: 80px;" src="<?php echo base_url(); ?>dist/img/seal.bmp" alt="seal">
                                        <img class="ml-5" style="width: 100px;" src="<?php echo base_url(); ?>dist/img/sign.bmp" alt="sign">
                                    </div>
                                <p class="h6 text-center">Signature</p>
                            </div>
                            
                        </div>

                        <hr style="height:1px;border-width:0;color:gray;background-color:gray">

                        <div class="row">
                            <div class="col-md-6 small">
                                <p>
                                    <b>PROSOFT E-SOLUTIONS INDIA PVT. LTD</b><br>
                                    PROSOFT HOUSE, BEL-HEIGHTS APARTMENT, 3rd FLOOR, 303 CTS NO. 2523/2<br>
                                    ANNAPURNAWADI AZAM NAGAR, BELAGAVI-590010 | KARNATAKA | INDIA |<br>
                                    Contact No. : +91 9743577121, 9019858560
                                </p>
                            </div>
                            <div class="col-md-6 float-right">
                                <div class="float-right">
                                    <!-- <img src="<?php echo base_url(); ?>dist/img/credit/visa.png" alt="IAF"> -->
                                    <img style="width: 120px;"  src="<?php echo base_url(); ?>dist/img/iso.png" alt="ISO">
                                    <!-- <img src="<?php echo base_url(); ?>dist/img/credit/american-express.png" alt="ISO2"> -->
                                    <!-- <p class="small">Certificate No.: 18DQCW40</p> -->
                                </div>
                            </div>
                        </div>                        

                        <div class="row mt-3">
                            
                            <div class="col-12 small">
                                <p class="text-bold">TERMS & CONDITIONS:</p>
                                <!-- <img src="../../dist/img/credit/visa.png" alt="Visa">
                                <img src="../../dist/img/credit/mastercard.png" alt="Mastercard">
                                <img src="../../dist/img/credit/american-express.png" alt="American Express">
                                <img src="../../dist/img/credit/paypal2.png" alt="Paypal"> -->

                                <p class="text-muted well well-sm shadow-none" style="margin-top: 10px;">
                                    Time Commitment from the Vendor for service support for the problems faced under warranty : <br>

                                    • If the User communicates his problem in the prescribed format, the Vendor will acknowledge the same.<br>
                                    • If Vendor requires more details, the User is expected to provide it immediately.<br>
                                    • On receipt of complete information, the problems will be solved within 5 days through Electronic Medium (Modem). The User will get an update into his mailbox and the User will have to down load the respective update into his machine. The Vendor will send a copy of the update through courier if the modem connectivity cannot be established. It is the User’s responsibility to ensure that the software is updated with updates sent by the Vendor. <br>
                                    • Almost all the problems will be handled in this manner. In case this mechanism fails to sort out the problems, the Engineers from the Vendor will visit the site within a reasonable time limit to set right the problem. This will depend on the distance of the site from Belgaum and also the availability of the necessary transportation arrangements.<br><br>

                                    <strong>Warranty support:</strong><br>
                                    The term warranty support implies support for all the bugs noticed in the operation of the software. This will be read with the features provided in the software installed. The Vendor only limited to the installations carries out the warranty support.<br><br>

                                    <strong>NOTE:</strong> The quoted price is only inclusive of remote support. Site visit will be charged @Rs. 5000/ per day & all travel expenses has to be borne by Client - w.e. From date of AMC Order.
									<br>
									<span id="lbl_note" name="lbl_note"></span>
									<br><br>
                                    <strong>Exclusions from warranty support :</strong><br>
                                    The term warranty expressly excludes the following causes resulting in the mal-functioning of the software. <br>
                                    • Misuse of the software - This will include deletion of the software or parts thereof.<br>
                                    • Improper working and deletion of the interfacing system software such as the Operating System / Printer Drivers / Backup Tape Drive Software etc. <br>
                                    • Mal-functioning of the software on account of failure of the hardware - failure of Hard Disk / CPU / Printer etc. <br>
                                    • Mal-functioning arising out of Network failure.<br>
                                    • Corruption of the software due to any reason.<br>
                                    • Software failure due to power fluctuations leading to the corruption of data / software.<br>
                                    • All software mal-functioning arising due to non-installation of the Anti- Virus software.<br>
                                    • Any unauthorized software installations at any other site / machine done by the User without seeking the approval from the Vendor either by relocating the software on a different machine or at a different premises. <br><br>

                                    <strong>The User is expected to take periodic backups and maintain the same. The Vendor will not be liable for any loss of data due to any reason.</strong><br>

                                </p>
                            </div>
                        </div>

                        <!-- this row will not appear when printing -->
                        <div class="row no-print"  data-html2canvas-ignore="true" >
                            <div class="col-12" id="print_btn_div">
                                <!-- <a href="quotation-print.html" target="_blank" class="btn btn-success float-right">
                                    <i class="fas fa-print"></i> Print
                                </a> -->
                                <button id="btn_print" name="btn_print" type="button" class="btn btn-success float-right">
                                    <i class="fas fa-print"></i> Print
                                </button>
                                <button type="button" id="btn_genrate_pdf" class="btn btn-primary float-right" style="margin-right: 5px;">
                                    <i class="fas fa-download"></i> Generate PDF
                                </button>
                            </div>
                        </div>
                    </div>
                    <!-- /.quotation -->
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<!-- jQuery -->
<script src="<?php echo base_url(); ?>plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url(); ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/select2/js/select2.full.min.js"></script>
<!-- Bootstrap4 Duallistbox -->
<script src="<?php echo base_url(); ?>plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js"></script>
<!-- InputMask -->
<script src="<?php echo base_url(); ?>plugins/moment/moment.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>
<!-- date-range-picker -->
<script src="<?php echo base_url(); ?>plugins/daterangepicker/daterangepicker.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?php echo base_url(); ?>plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- overlayScrollbars -->
<script src="<?php echo base_url(); ?>plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>

<!-- DataTables -->
<script src="<?php echo base_url(); ?>plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>

<!-- AdminLTE App -->
<script src="<?php echo base_url(); ?>dist/js/adminlte.js"></script>

<script type="text/javascript">
    //// #####################################################################################################
    //// Events start
    $('#com_quot_no').change(function() {
        selectedQuotation = $(this).val();
		if (selectedQuotation != ""){
			loadQuotation(selectedQuotation);
		}
    })

    // change currencySymbol
		function changeCurrencySymbol (props)
		{
            selectedCurrency=props;
			var arrCurrency = { "INR": "&#x20B9;", "USD": "&#36;", "GBP": "&pound;" }; 
			selectedCurrencySymbol = arrCurrency[selectedCurrency];
			
			document.getElementById("total_after_gst").innerHTML = "Total after GST : ("+ selectedCurrencySymbol +")";
            document.getElementById("selected_rate").innerHTML ="Rate ("+ selectedCurrencySymbol +") ";
          
		}

    function loadQuotation(selectedQuotation) {

        
		//if (selectedQuotation == undefined || selectedQuotation ==""){
		//	return;
		//}

        // Clear all quotation items list
        var myTable = document.getElementById("itemsTable");
        var rowCount = myTable.rows.length;
        for (var x = rowCount - 1; x > 0; x--) {
            myTable.deleteRow(x);
        }

        // Clear all fields
        document.getElementById('lbl_state').innerHTML = "";
        document.getElementById('lbl_code').innerHTML = "";
        document.getElementById('lbl_gstin').innerHTML = "";
		document.getElementById('lbl_currency').innerHTML = "";
        document.getElementById('lbl_cust_name').innerHTML = "";
        document.getElementById('lbl_cust_address').innerHTML = "";

        document.getElementById('lbl_quot_no').innerHTML = "";
        document.getElementById('lbl_quot_date').innerHTML = "";
        document.getElementById('lbl_reference_no').innerHTML = "";
        document.getElementById('lbl_dated').innerHTML = "";
        document.getElementById('lbl_reference_no').innerHTML = "";
        
        document.getElementById('lbl_project_job').innerHTML = "";
        document.getElementById('lbl_hsn_sac_code').innerHTML = "";

        document.getElementById('lbl_total_before_gst').innerHTML = "0";
        document.getElementById('lbl_igst_perc').innerHTML = "0";
        document.getElementById('lbl_igst_value').innerHTML = "0";
        document.getElementById('lbl_sgst_perc').innerHTML = "0";
        document.getElementById('lbl_sgst_value').innerHTML = "0";
        document.getElementById('lbl_cgst_perc').innerHTML = "0";
        document.getElementById('lbl_cgst_value').innerHTML = "0";

		document.getElementById('lbl_note').innerHTML = "";

        var mdata = {
            "quotation_no": selectedQuotation
        };

        $.ajax({
            type: "GET",
            url: "<?php echo base_url(); ?>index.php/Quotation_controller/get_quotation_details",
            data: mdata
        }).done(function(data) {

            console.log(data);
            if (data != 110) {
                var json_obj = jQuery.parseJSON(data);
                if (json_obj.length > 0) {
                    document.getElementById('lbl_state').innerHTML = json_obj[0].State;
                    document.getElementById('lbl_code').innerHTML = json_obj[0].Code;
                    document.getElementById('lbl_gstin').innerHTML = json_obj[0].Customer_GSTIN_No;
					document.getElementById('lbl_currency').innerHTML = json_obj[0].Currency;

                    //change selectedCurrencySymbol
					changeCurrencySymbol(json_obj[0].Currency);

                    console.log(json_obj[0].Currency);


                    document.getElementById('lbl_cust_name').innerHTML = json_obj[0].Customer_Name;
					var unescapedAddress = unescapeHTML(json_obj[0].Customer_Address);
                    document.getElementById('lbl_cust_address').innerHTML = unescapedAddress.replace(/\n/g, "<br>");

                    document.getElementById('lbl_quot_no').innerHTML = json_obj[0].Quotation_No;

                    var quotDateString = json_obj[0].Quotation_Date;
					quotDateString = quotDateString.replace(" 00:00:00.000", "");
					var quotDate = quotDateString.split("-"); // Quotation Date
                    document.getElementById('lbl_quot_date').innerHTML = quotDate[2] + "-" + quotDate[1] + "-" + quotDate[0];

                    document.getElementById('lbl_reference_no').innerHTML = json_obj[0].Reference_No;

                    var refDateString = json_obj[0].Reference_Date;
					refDateString = refDateString.replace(" 00:00:00.000", "");
					var refDate = refDateString.split("-"); // Quotation Date
                    document.getElementById('lbl_dated').innerHTML = refDate[2] + "-" + refDate[1] + "-" + refDate[0];
					
                    document.getElementById('lbl_preparedby').innerHTML = json_obj[0].PreparedBy;

					document.getElementById('lbl_project_job').innerHTML = json_obj[0].Project_Job;
                    document.getElementById('lbl_hsn_sac_code').innerHTML = json_obj[0].HSN_SAC_Code;

                    document.getElementById('lbl_total_before_gst').innerHTML = json_obj[0].Total_Before_GST;
                    document.getElementById('lbl_igst_perc').innerHTML = json_obj[0].IGST;
                    document.getElementById('lbl_igst_value').innerHTML = "0";
                    document.getElementById('lbl_sgst_perc').innerHTML = json_obj[0].SGST;
                    document.getElementById('lbl_sgst_value').innerHTML = "0";
                    document.getElementById('lbl_cgst_perc').innerHTML = json_obj[0].CGST;
                    document.getElementById('lbl_cgst_value').innerHTML = "0";

                    var rOff = json_obj[0].Round_Off;
                    if (parseFloat(rOff) > 0) {
                        document.getElementById('lbl_rounded_off_add').innerHTML = rOff;
                        document.getElementById('lbl_rounded_off_less').innerHTML = "0";
                    } else {
                        document.getElementById('lbl_rounded_off_add').innerHTML = "0";
                        document.getElementById('lbl_rounded_off_less').innerHTML = rOff;
                    }

                    document.getElementById('lbl_total_after_gst').innerHTML = json_obj[0].Total_After_GST;

					var unescapedNote = unescapeHTML(json_obj[0].Note);												
					var m_note = unescapedNote.replace(/<br>/g, "\n");
					document.getElementById('lbl_note').innerHTML = unescapedNote;

                    cal_total();
                }
            } else {
                alert("Failed to get quotation details because of the error :\n" + data);
            }
        });

        $.ajax({
            type: "GET",
            url: "<?php echo base_url(); ?>index.php/Quotation_controller/get_quotation_item_details",
            data: mdata
        }).done(function(data) {
            console.log(data);
            if (data == 110) {
                alert("No quotation items found.");
            } else if (data == 111) {
                alert("Failed to get quotation item details because of the error :\n" + data);
            } else {
                var json_obj = jQuery.parseJSON(data);
                if (json_obj.length > 0) {
                    if ($("#itemsTable tbody").length == 0) {
                        $("#itemsTable").append("<tbody></tbody>");
                    }

                    for (var i = 0; i < json_obj.length; i++) {						
						var rate = parseFloat(json_obj[i].Rate);
						var qty = parseFloat(json_obj[i].Quantity);
						var warranty = json_obj[i].Warranty;
						var amc_percentage = json_obj[i].AMC_Percentage;
						var m_amc_amount = 0;
						var m_amount = 0;

						if (warranty == 1){
							m_amount = parseFloat(rate) * parseFloat(qty);
						}else{
							var m_amc_percentage = parseFloat(amc_percentage); // Entered amc percentage
							var percentage_on_product_rate = ((rate * qty) * m_amc_percentage) / 100; // Amc percentage based on product rate * quantity
							var m_amc_amount = (warranty - 1) * percentage_on_product_rate; // total amc percenatage amount = (no of years - 1) * amc percentage amount
							m_amount = (parseFloat(rate) * parseFloat(qty)) + m_amc_amount; // Amount = (Product rate * Quantity) + AMC amount
						}

                    

						var unescapedDesc = unescapeHTML(json_obj[i].Description);
                        $("#itemsTable tbody").append("<tr>" +
                            "<td class='h6 text-center' style='font-size: 14px;'>" + (i + 1) + "</td>" +
                            "<td class='h6' style='font-size: 14px;'><b>" + json_obj[i].Product_Name+"("+json_obj[i].Edition+")"+"</b><br>" + 
                                unescapedDesc.replace(/\n/g, "<br>") + 
                                
                                "</td>" +
                            "<td class='h6 text-right' style='font-size: 14px;'>" + json_obj[i].Rate + "</td>" +
                            "<td class='h6 text-right' style='font-size: 14px;'>" + json_obj[i].Quantity + "</td>" +
                            "<td class='h6 text-right' style='font-size: 14px;'>" + m_amc_amount + "</td>" +
                            "<td class='h6 text-right' style='font-size: 14px;'>" +  m_amount  + "</td>" +

/*
                        $("#itemsTable tbody").append("<tr style='padding: 1px 5px 1px 1px;'>" +
                            "<td class='h6 text-center' style='font-size: 14px;padding: 1px 5px 1px 1px'>" + (i + 1) + "</td>" +
                            "<td class='h6' style='font-size: 14px;padding: 1px 5px 1px 1px'><b>" + json_obj[i].Product_Name + "</b><br>" + 
                               "<p style='font-size: 12px;padding: 1px 5px 1px 1px'>" + json_obj[i].Product_Desc + "<p></td>" +
                            "<td class='h6 text-right' style='font-size: 14px;padding: 1px 5px 1px 1px'>" + json_obj[i].Rate + "</td>" +
                            "<td class='h6 text-right' style='font-size: 14px;padding: 1px 5px 1px 1px'>" + json_obj[i].Quantity + "</td>" +
                            "<td class='h6 text-right' style='font-size: 14px;padding: 1px 5px 1px 1px'>" + parseFloat(json_obj[i].Rate) * parseFloat(json_obj[i].Quantity) + "</td>" +
*/
                                                      
                            "</tr>");
                    }
                }
            }
        });
    }

    //print
    $('#btn_print').click(function() {

        if($('#com_quot_no').val() == null)
        {
				alert("Please select a quotation.");
		}
        else
        {   
            var quotation_div = document.getElementById("quotation_div");
            var print_btn_div = document.getElementById("print_btn_div");
 
		    var footer = document.getElementById("footer");
 
 

            quotation_div.style.display = "none";
            print_btn_div.style.display = "none";
            footer.style.display = "none";

            window.print();

            quotation_div.style.display = "block";
            print_btn_div.style.display = "block";
            footer.style.display = "block";
        }
       
    })

    //generate pdf
    $('#btn_genrate_pdf').click(function(){

        if($('#com_quot_no').val() == null)
        {
				alert("Please select a quotation.");
		}
        else
        {
            var invoice= document.querySelector('.invoice');

            var opt ={
                filename:'Quotation.pdf',
                pagebreak: { mode: 'avoid-all', before: '#page2el' },
                image: { type: 'jpeg', quality: 0.98 },
                jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' },
                margin:0.1
            }

            html2pdf().from(invoice).set(opt).save();
            
        }
       
    })

    //// Calculations		
    function cal_total() {
        var total_beforegst = document.getElementById("lbl_total_before_gst").innerHTML;
        var igst = "0";
        var sgst = "0";
        var cgst = "0";

        if (isValidNumbericValue(total_beforegst)) {
            // Calculate igst
            var igst_percentage = document.getElementById("lbl_igst_perc").innerHTML;
            if (isValidNumbericValue(igst_percentage)) {
                igst = (parseFloat(total_beforegst) * parseFloat(igst_percentage)) / 100;
                document.getElementById("lbl_igst_value").innerHTML = igst;
            } else {
                document.getElementById("lbl_igst_value").innerHTML = "0";
            }

            // Calculate sgst
            var sgst_percentage = document.getElementById("lbl_sgst_perc").innerHTML;
            if (isValidNumbericValue(sgst_percentage)) {
                sgst = (parseFloat(total_beforegst) * parseFloat(sgst_percentage)) / 100;
                document.getElementById("lbl_sgst_value").innerHTML = sgst;
            } else {
                document.getElementById("lbl_sgst_value").innerHTML = "0";
            }

            // Calculate cgst
            var cgst_percentage = document.getElementById("lbl_cgst_perc").innerHTML;
            if (isValidNumbericValue(cgst_percentage)) {
                cgst = (parseFloat(total_beforegst) * parseFloat(cgst_percentage)) / 100;
                document.getElementById("lbl_cgst_value").innerHTML = cgst;
            } else {
                document.getElementById("lbl_cgst_value").innerHTML = "0";
            }
        } else {
            total_beforegst = "0";
        }

        var round_off_add = document.getElementById("lbl_rounded_off_add").innerHTML;
        if (round_off_add == undefined || round_off_add == "") {
            round_off_add = "0";
        }

        var round_off_less = document.getElementById("lbl_rounded_off_less").innerHTML;
        if (round_off_less == undefined || round_off_less == "") {
            round_off_less = "0";
        }

        // Add total amount
        // var total = (parseFloat(total_beforegst) + parseFloat(igst) + parseFloat(sgst) + parseFloat(cgst)) + parseFloat(round_off_add) + parseFloat(round_off_less);
        var total=(parseFloat(total_beforegst)+ parseFloat(igst))+ parseFloat(round_off_add) + parseFloat(round_off_less);
        document.getElementById("lbl_total_after_gst").innerHTML = total;

		document.getElementById("lbl_amt_in_words").innerHTML = "Rupees " + inWords(total);		
    }

    function isValidNumbericValue(value) {
        if (value != undefined && value != "" && parseFloat(value) > 0) {
            return true;
        } else {
            return false;
        }
    }

	var a = ['','One ','Two ','Three ','Four ', 'Five ','Six ','Seven ','Eight ','Nine ','Ten ','Eleven ','Twelve ','Thirteen ','Fourteen ','Fifteen ','Sixteen ','Seventeen ','Eighteen ','Nineteen '];
	var b = ['', '', 'Twenty','Thirty','Forty','Fifty', 'Sixty','Seventy','Eighty','Ninety'];

	function inWords (num) {
		if ((num = num.toString()).length > 9) return 'overflow';
		n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
		if (!n) return; var str = '';
		str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'Crore ' : '';
		str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'Lakh ' : '';
		str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'Thousand ' : '';
		str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'Hundred ' : '';
		str += (n[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) + 'Only ' : '';
		return str;
	}

	function unescapeHTML(escapedHTML) {
		if (escapedHTML == undefined || escapedHTML == "")
			return "";
		else
			return escapedHTML.replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&');
	}

	//document.getElementById('number').onkeyup = function () {
	//	document.getElementById('words').innerHTML = inWords(document.getElementById('number').value);
	//};

    //// Functions End
    //// #####################################################################################################

    $(document).ready(function() {
        var newQuotationNo = "<?php echo $new_quotation_no; ?>";
        //alert(newQuotationNo);

        document.getElementById('com_quot_no').value = newQuotationNo;
		if (newQuotationNo != ""){
			loadQuotation(newQuotationNo);
		}        
    });
</script>
<!-- <script type="text/javascript"> 
  window.addEventListener("load", window.print());
</script> -->