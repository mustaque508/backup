<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-06 06:24:50 --> Config Class Initialized
INFO - 2021-07-06 06:24:50 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:24:51 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:24:51 --> Utf8 Class Initialized
INFO - 2021-07-06 06:24:51 --> URI Class Initialized
DEBUG - 2021-07-06 06:24:51 --> No URI present. Default controller set.
INFO - 2021-07-06 06:24:51 --> Router Class Initialized
INFO - 2021-07-06 06:24:51 --> Output Class Initialized
INFO - 2021-07-06 06:24:51 --> Security Class Initialized
DEBUG - 2021-07-06 06:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:24:51 --> Input Class Initialized
INFO - 2021-07-06 06:24:51 --> Language Class Initialized
INFO - 2021-07-06 06:24:51 --> Loader Class Initialized
INFO - 2021-07-06 06:24:51 --> Helper loaded: html_helper
INFO - 2021-07-06 06:24:51 --> Helper loaded: url_helper
INFO - 2021-07-06 06:24:51 --> Helper loaded: form_helper
INFO - 2021-07-06 06:24:52 --> Database Driver Class Initialized
INFO - 2021-07-06 06:24:53 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:24:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:24:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:24:53 --> Encryption Class Initialized
INFO - 2021-07-06 06:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:24:53 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:24:53 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:24:54 --> Model "user_model" initialized
INFO - 2021-07-06 06:24:54 --> Model "role_model" initialized
INFO - 2021-07-06 06:24:54 --> Controller Class Initialized
INFO - 2021-07-06 06:24:54 --> Helper loaded: language_helper
INFO - 2021-07-06 06:24:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:24:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\login.php
INFO - 2021-07-06 06:24:54 --> Final output sent to browser
DEBUG - 2021-07-06 06:24:54 --> Total execution time: 4.4242
INFO - 2021-07-06 06:25:04 --> Config Class Initialized
INFO - 2021-07-06 06:25:04 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:25:04 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:25:04 --> Utf8 Class Initialized
INFO - 2021-07-06 06:25:04 --> URI Class Initialized
INFO - 2021-07-06 06:25:04 --> Router Class Initialized
INFO - 2021-07-06 06:25:04 --> Output Class Initialized
INFO - 2021-07-06 06:25:04 --> Security Class Initialized
DEBUG - 2021-07-06 06:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:25:04 --> Input Class Initialized
INFO - 2021-07-06 06:25:04 --> Language Class Initialized
INFO - 2021-07-06 06:25:04 --> Loader Class Initialized
INFO - 2021-07-06 06:25:04 --> Helper loaded: html_helper
INFO - 2021-07-06 06:25:04 --> Helper loaded: url_helper
INFO - 2021-07-06 06:25:04 --> Helper loaded: form_helper
INFO - 2021-07-06 06:25:04 --> Database Driver Class Initialized
INFO - 2021-07-06 06:25:04 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:25:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:25:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:25:04 --> Encryption Class Initialized
INFO - 2021-07-06 06:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:25:04 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:25:04 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:25:04 --> Model "user_model" initialized
INFO - 2021-07-06 06:25:04 --> Model "role_model" initialized
INFO - 2021-07-06 06:25:04 --> Controller Class Initialized
INFO - 2021-07-06 06:25:04 --> Helper loaded: language_helper
INFO - 2021-07-06 06:25:04 --> Language file loaded: language/english/content_lang.php
DEBUG - 2021-07-06 06:25:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-06 06:25:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-07-06 06:25:05 --> Model "User" initialized
INFO - 2021-07-06 06:25:05 --> Config Class Initialized
INFO - 2021-07-06 06:25:05 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:25:05 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:25:05 --> Utf8 Class Initialized
INFO - 2021-07-06 06:25:05 --> URI Class Initialized
INFO - 2021-07-06 06:25:05 --> Router Class Initialized
INFO - 2021-07-06 06:25:05 --> Output Class Initialized
INFO - 2021-07-06 06:25:05 --> Security Class Initialized
DEBUG - 2021-07-06 06:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:25:05 --> Input Class Initialized
INFO - 2021-07-06 06:25:05 --> Language Class Initialized
INFO - 2021-07-06 06:25:05 --> Loader Class Initialized
INFO - 2021-07-06 06:25:05 --> Helper loaded: html_helper
INFO - 2021-07-06 06:25:05 --> Helper loaded: url_helper
INFO - 2021-07-06 06:25:05 --> Helper loaded: form_helper
INFO - 2021-07-06 06:25:05 --> Database Driver Class Initialized
INFO - 2021-07-06 06:25:05 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:25:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:25:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:25:05 --> Encryption Class Initialized
INFO - 2021-07-06 06:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:25:05 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:25:05 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:25:05 --> Model "user_model" initialized
INFO - 2021-07-06 06:25:05 --> Model "role_model" initialized
INFO - 2021-07-06 06:25:05 --> Controller Class Initialized
INFO - 2021-07-06 06:25:05 --> Helper loaded: language_helper
INFO - 2021-07-06 06:25:05 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:25:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-06 06:25:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-06 06:25:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-06 06:25:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:25:05 --> Final output sent to browser
DEBUG - 2021-07-06 06:25:05 --> Total execution time: 0.2571
INFO - 2021-07-06 06:25:14 --> Config Class Initialized
INFO - 2021-07-06 06:25:14 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:25:14 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:25:14 --> Utf8 Class Initialized
INFO - 2021-07-06 06:25:14 --> URI Class Initialized
INFO - 2021-07-06 06:25:14 --> Router Class Initialized
INFO - 2021-07-06 06:25:14 --> Output Class Initialized
INFO - 2021-07-06 06:25:14 --> Security Class Initialized
DEBUG - 2021-07-06 06:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:25:14 --> Input Class Initialized
INFO - 2021-07-06 06:25:14 --> Language Class Initialized
INFO - 2021-07-06 06:25:14 --> Loader Class Initialized
INFO - 2021-07-06 06:25:14 --> Helper loaded: html_helper
INFO - 2021-07-06 06:25:14 --> Helper loaded: url_helper
INFO - 2021-07-06 06:25:14 --> Helper loaded: form_helper
INFO - 2021-07-06 06:25:14 --> Database Driver Class Initialized
INFO - 2021-07-06 06:25:14 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:25:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:25:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:25:14 --> Encryption Class Initialized
INFO - 2021-07-06 06:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:25:14 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:25:14 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:25:14 --> Model "user_model" initialized
INFO - 2021-07-06 06:25:14 --> Model "role_model" initialized
INFO - 2021-07-06 06:25:14 --> Controller Class Initialized
INFO - 2021-07-06 06:25:14 --> Helper loaded: language_helper
INFO - 2021-07-06 06:25:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:25:14 --> Model "Quotation_model" initialized
INFO - 2021-07-06 06:25:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:25:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:25:14 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-06 06:25:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-06 06:25:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:25:14 --> Final output sent to browser
DEBUG - 2021-07-06 06:25:14 --> Total execution time: 0.5431
INFO - 2021-07-06 06:25:22 --> Config Class Initialized
INFO - 2021-07-06 06:25:22 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:25:22 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:25:22 --> Utf8 Class Initialized
INFO - 2021-07-06 06:25:22 --> URI Class Initialized
INFO - 2021-07-06 06:25:22 --> Router Class Initialized
INFO - 2021-07-06 06:25:22 --> Output Class Initialized
INFO - 2021-07-06 06:25:22 --> Security Class Initialized
DEBUG - 2021-07-06 06:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:25:22 --> Input Class Initialized
INFO - 2021-07-06 06:25:22 --> Language Class Initialized
INFO - 2021-07-06 06:25:22 --> Loader Class Initialized
INFO - 2021-07-06 06:25:22 --> Helper loaded: html_helper
INFO - 2021-07-06 06:25:22 --> Helper loaded: url_helper
INFO - 2021-07-06 06:25:22 --> Helper loaded: form_helper
INFO - 2021-07-06 06:25:22 --> Database Driver Class Initialized
INFO - 2021-07-06 06:25:22 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:25:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:25:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:25:22 --> Encryption Class Initialized
INFO - 2021-07-06 06:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:25:22 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:25:22 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:25:22 --> Model "user_model" initialized
INFO - 2021-07-06 06:25:22 --> Model "role_model" initialized
INFO - 2021-07-06 06:25:22 --> Controller Class Initialized
INFO - 2021-07-06 06:25:22 --> Helper loaded: language_helper
INFO - 2021-07-06 06:25:22 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:25:22 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:25:22 --> Model "Product_model" initialized
INFO - 2021-07-06 06:25:22 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:25:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:25:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:25:22 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-06 06:25:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:25:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:25:22 --> Final output sent to browser
DEBUG - 2021-07-06 06:25:22 --> Total execution time: 0.1910
INFO - 2021-07-06 06:26:51 --> Config Class Initialized
INFO - 2021-07-06 06:26:51 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:26:51 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:26:51 --> Utf8 Class Initialized
INFO - 2021-07-06 06:26:51 --> URI Class Initialized
INFO - 2021-07-06 06:26:51 --> Router Class Initialized
INFO - 2021-07-06 06:26:51 --> Output Class Initialized
INFO - 2021-07-06 06:26:51 --> Security Class Initialized
DEBUG - 2021-07-06 06:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:26:51 --> Input Class Initialized
INFO - 2021-07-06 06:26:51 --> Language Class Initialized
INFO - 2021-07-06 06:26:51 --> Loader Class Initialized
INFO - 2021-07-06 06:26:51 --> Helper loaded: html_helper
INFO - 2021-07-06 06:26:51 --> Helper loaded: url_helper
INFO - 2021-07-06 06:26:51 --> Helper loaded: form_helper
INFO - 2021-07-06 06:26:51 --> Database Driver Class Initialized
INFO - 2021-07-06 06:26:51 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:26:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:26:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:26:51 --> Encryption Class Initialized
INFO - 2021-07-06 06:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:26:51 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:26:51 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:26:51 --> Model "user_model" initialized
INFO - 2021-07-06 06:26:51 --> Model "role_model" initialized
INFO - 2021-07-06 06:26:51 --> Controller Class Initialized
INFO - 2021-07-06 06:26:51 --> Helper loaded: language_helper
INFO - 2021-07-06 06:26:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:26:51 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:26:51 --> Model "Product_model" initialized
INFO - 2021-07-06 06:26:51 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:26:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:26:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:26:51 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-06 06:26:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:26:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:26:51 --> Final output sent to browser
DEBUG - 2021-07-06 06:26:51 --> Total execution time: 0.0853
INFO - 2021-07-06 06:32:53 --> Config Class Initialized
INFO - 2021-07-06 06:32:53 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:32:53 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:32:53 --> Utf8 Class Initialized
INFO - 2021-07-06 06:32:53 --> URI Class Initialized
INFO - 2021-07-06 06:32:53 --> Router Class Initialized
INFO - 2021-07-06 06:32:53 --> Output Class Initialized
INFO - 2021-07-06 06:32:53 --> Security Class Initialized
DEBUG - 2021-07-06 06:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:32:53 --> Input Class Initialized
INFO - 2021-07-06 06:32:53 --> Language Class Initialized
INFO - 2021-07-06 06:32:53 --> Loader Class Initialized
INFO - 2021-07-06 06:32:53 --> Helper loaded: html_helper
INFO - 2021-07-06 06:32:53 --> Helper loaded: url_helper
INFO - 2021-07-06 06:32:53 --> Helper loaded: form_helper
INFO - 2021-07-06 06:32:53 --> Database Driver Class Initialized
INFO - 2021-07-06 06:32:53 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:32:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:32:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:32:53 --> Encryption Class Initialized
INFO - 2021-07-06 06:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:32:54 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:32:54 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:32:54 --> Model "user_model" initialized
INFO - 2021-07-06 06:32:54 --> Model "role_model" initialized
INFO - 2021-07-06 06:32:54 --> Controller Class Initialized
INFO - 2021-07-06 06:32:54 --> Helper loaded: language_helper
INFO - 2021-07-06 06:32:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:32:54 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:32:54 --> Model "Product_model" initialized
INFO - 2021-07-06 06:32:54 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:32:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:32:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:32:54 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-06 06:32:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:32:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:32:54 --> Final output sent to browser
DEBUG - 2021-07-06 06:32:54 --> Total execution time: 0.9647
INFO - 2021-07-06 06:33:07 --> Config Class Initialized
INFO - 2021-07-06 06:33:07 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:33:07 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:33:07 --> Utf8 Class Initialized
INFO - 2021-07-06 06:33:07 --> URI Class Initialized
INFO - 2021-07-06 06:33:07 --> Router Class Initialized
INFO - 2021-07-06 06:33:07 --> Output Class Initialized
INFO - 2021-07-06 06:33:07 --> Security Class Initialized
DEBUG - 2021-07-06 06:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:33:07 --> Input Class Initialized
INFO - 2021-07-06 06:33:07 --> Language Class Initialized
INFO - 2021-07-06 06:33:07 --> Loader Class Initialized
INFO - 2021-07-06 06:33:07 --> Helper loaded: html_helper
INFO - 2021-07-06 06:33:07 --> Helper loaded: url_helper
INFO - 2021-07-06 06:33:07 --> Helper loaded: form_helper
INFO - 2021-07-06 06:33:07 --> Database Driver Class Initialized
INFO - 2021-07-06 06:33:07 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:33:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:33:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:33:07 --> Encryption Class Initialized
INFO - 2021-07-06 06:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:33:07 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:33:07 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:33:07 --> Model "user_model" initialized
INFO - 2021-07-06 06:33:07 --> Model "role_model" initialized
INFO - 2021-07-06 06:33:07 --> Controller Class Initialized
INFO - 2021-07-06 06:33:07 --> Helper loaded: language_helper
INFO - 2021-07-06 06:33:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:33:07 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:33:07 --> Model "Product_model" initialized
INFO - 2021-07-06 06:33:07 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:33:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:33:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:33:07 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-06 06:33:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:33:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:33:07 --> Final output sent to browser
DEBUG - 2021-07-06 06:33:07 --> Total execution time: 0.1049
INFO - 2021-07-06 06:34:51 --> Config Class Initialized
INFO - 2021-07-06 06:34:51 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:34:51 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:34:51 --> Utf8 Class Initialized
INFO - 2021-07-06 06:34:51 --> URI Class Initialized
INFO - 2021-07-06 06:34:51 --> Router Class Initialized
INFO - 2021-07-06 06:34:51 --> Output Class Initialized
INFO - 2021-07-06 06:34:51 --> Security Class Initialized
DEBUG - 2021-07-06 06:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:34:51 --> Input Class Initialized
INFO - 2021-07-06 06:34:51 --> Language Class Initialized
INFO - 2021-07-06 06:34:51 --> Loader Class Initialized
INFO - 2021-07-06 06:34:51 --> Helper loaded: html_helper
INFO - 2021-07-06 06:34:51 --> Helper loaded: url_helper
INFO - 2021-07-06 06:34:51 --> Helper loaded: form_helper
INFO - 2021-07-06 06:34:51 --> Database Driver Class Initialized
INFO - 2021-07-06 06:34:51 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:34:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:34:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:34:51 --> Encryption Class Initialized
INFO - 2021-07-06 06:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:34:51 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:34:51 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:34:51 --> Model "user_model" initialized
INFO - 2021-07-06 06:34:51 --> Model "role_model" initialized
INFO - 2021-07-06 06:34:51 --> Controller Class Initialized
INFO - 2021-07-06 06:34:51 --> Helper loaded: language_helper
INFO - 2021-07-06 06:34:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:34:51 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:34:51 --> Model "Product_model" initialized
INFO - 2021-07-06 06:34:51 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:34:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:34:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:34:51 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-06 06:34:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:34:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:34:51 --> Final output sent to browser
DEBUG - 2021-07-06 06:34:51 --> Total execution time: 0.1069
INFO - 2021-07-06 06:35:01 --> Config Class Initialized
INFO - 2021-07-06 06:35:01 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:35:01 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:35:01 --> Utf8 Class Initialized
INFO - 2021-07-06 06:35:01 --> URI Class Initialized
INFO - 2021-07-06 06:35:01 --> Router Class Initialized
INFO - 2021-07-06 06:35:01 --> Output Class Initialized
INFO - 2021-07-06 06:35:01 --> Security Class Initialized
DEBUG - 2021-07-06 06:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:35:01 --> Input Class Initialized
INFO - 2021-07-06 06:35:01 --> Language Class Initialized
INFO - 2021-07-06 06:35:01 --> Loader Class Initialized
INFO - 2021-07-06 06:35:01 --> Helper loaded: html_helper
INFO - 2021-07-06 06:35:01 --> Helper loaded: url_helper
INFO - 2021-07-06 06:35:01 --> Helper loaded: form_helper
INFO - 2021-07-06 06:35:01 --> Database Driver Class Initialized
INFO - 2021-07-06 06:35:01 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:35:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:35:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:35:01 --> Encryption Class Initialized
INFO - 2021-07-06 06:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:35:01 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:35:01 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:35:01 --> Model "user_model" initialized
INFO - 2021-07-06 06:35:01 --> Model "role_model" initialized
INFO - 2021-07-06 06:35:01 --> Controller Class Initialized
INFO - 2021-07-06 06:35:01 --> Helper loaded: language_helper
INFO - 2021-07-06 06:35:01 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:35:01 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:35:01 --> Model "Product_model" initialized
INFO - 2021-07-06 06:35:01 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:35:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:35:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:35:01 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-06 06:35:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:35:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:35:01 --> Final output sent to browser
DEBUG - 2021-07-06 06:35:01 --> Total execution time: 0.0864
INFO - 2021-07-06 06:36:01 --> Config Class Initialized
INFO - 2021-07-06 06:36:01 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:36:01 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:36:01 --> Utf8 Class Initialized
INFO - 2021-07-06 06:36:01 --> URI Class Initialized
INFO - 2021-07-06 06:36:01 --> Router Class Initialized
INFO - 2021-07-06 06:36:01 --> Output Class Initialized
INFO - 2021-07-06 06:36:01 --> Security Class Initialized
DEBUG - 2021-07-06 06:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:36:01 --> Input Class Initialized
INFO - 2021-07-06 06:36:01 --> Language Class Initialized
INFO - 2021-07-06 06:36:01 --> Loader Class Initialized
INFO - 2021-07-06 06:36:01 --> Helper loaded: html_helper
INFO - 2021-07-06 06:36:01 --> Helper loaded: url_helper
INFO - 2021-07-06 06:36:01 --> Helper loaded: form_helper
INFO - 2021-07-06 06:36:01 --> Database Driver Class Initialized
INFO - 2021-07-06 06:36:01 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:36:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:36:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:36:01 --> Encryption Class Initialized
INFO - 2021-07-06 06:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:36:01 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:36:01 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:36:01 --> Model "user_model" initialized
INFO - 2021-07-06 06:36:01 --> Model "role_model" initialized
INFO - 2021-07-06 06:36:01 --> Controller Class Initialized
INFO - 2021-07-06 06:36:01 --> Helper loaded: language_helper
INFO - 2021-07-06 06:36:01 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:36:01 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:36:01 --> Model "Product_model" initialized
INFO - 2021-07-06 06:36:01 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:36:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:36:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:36:01 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-06 06:36:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:36:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:36:01 --> Final output sent to browser
DEBUG - 2021-07-06 06:36:01 --> Total execution time: 0.1164
INFO - 2021-07-06 06:41:37 --> Config Class Initialized
INFO - 2021-07-06 06:41:37 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:41:37 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:41:37 --> Utf8 Class Initialized
INFO - 2021-07-06 06:41:37 --> URI Class Initialized
INFO - 2021-07-06 06:41:37 --> Router Class Initialized
INFO - 2021-07-06 06:41:37 --> Output Class Initialized
INFO - 2021-07-06 06:41:37 --> Security Class Initialized
DEBUG - 2021-07-06 06:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:41:37 --> Input Class Initialized
INFO - 2021-07-06 06:41:37 --> Language Class Initialized
INFO - 2021-07-06 06:41:37 --> Loader Class Initialized
INFO - 2021-07-06 06:41:37 --> Helper loaded: html_helper
INFO - 2021-07-06 06:41:37 --> Helper loaded: url_helper
INFO - 2021-07-06 06:41:37 --> Helper loaded: form_helper
INFO - 2021-07-06 06:41:37 --> Database Driver Class Initialized
INFO - 2021-07-06 06:41:37 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:41:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:41:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:41:37 --> Encryption Class Initialized
INFO - 2021-07-06 06:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:41:37 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:41:37 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:41:37 --> Model "user_model" initialized
INFO - 2021-07-06 06:41:37 --> Model "role_model" initialized
INFO - 2021-07-06 06:41:37 --> Controller Class Initialized
INFO - 2021-07-06 06:41:37 --> Helper loaded: language_helper
INFO - 2021-07-06 06:41:37 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:41:37 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:41:37 --> Model "Product_model" initialized
INFO - 2021-07-06 06:41:37 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:41:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:41:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:41:37 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-06 06:41:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:41:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:41:37 --> Final output sent to browser
DEBUG - 2021-07-06 06:41:37 --> Total execution time: 0.1096
INFO - 2021-07-06 06:42:00 --> Config Class Initialized
INFO - 2021-07-06 06:42:00 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:42:00 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:42:00 --> Utf8 Class Initialized
INFO - 2021-07-06 06:42:00 --> URI Class Initialized
INFO - 2021-07-06 06:42:00 --> Router Class Initialized
INFO - 2021-07-06 06:42:00 --> Output Class Initialized
INFO - 2021-07-06 06:42:00 --> Security Class Initialized
DEBUG - 2021-07-06 06:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:42:00 --> Input Class Initialized
INFO - 2021-07-06 06:42:00 --> Language Class Initialized
INFO - 2021-07-06 06:42:00 --> Loader Class Initialized
INFO - 2021-07-06 06:42:00 --> Helper loaded: html_helper
INFO - 2021-07-06 06:42:00 --> Helper loaded: url_helper
INFO - 2021-07-06 06:42:00 --> Helper loaded: form_helper
INFO - 2021-07-06 06:42:00 --> Database Driver Class Initialized
INFO - 2021-07-06 06:42:00 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:42:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:42:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:42:00 --> Encryption Class Initialized
INFO - 2021-07-06 06:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:42:00 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:42:00 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:42:00 --> Model "user_model" initialized
INFO - 2021-07-06 06:42:00 --> Model "role_model" initialized
INFO - 2021-07-06 06:42:00 --> Controller Class Initialized
INFO - 2021-07-06 06:42:00 --> Helper loaded: language_helper
INFO - 2021-07-06 06:42:00 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:42:00 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:42:00 --> Model "Product_model" initialized
INFO - 2021-07-06 06:42:00 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:42:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:42:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:42:00 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-06 06:42:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:42:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:42:00 --> Final output sent to browser
DEBUG - 2021-07-06 06:42:00 --> Total execution time: 0.1088
INFO - 2021-07-06 06:42:24 --> Config Class Initialized
INFO - 2021-07-06 06:42:24 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:42:24 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:42:24 --> Utf8 Class Initialized
INFO - 2021-07-06 06:42:24 --> URI Class Initialized
INFO - 2021-07-06 06:42:24 --> Router Class Initialized
INFO - 2021-07-06 06:42:24 --> Output Class Initialized
INFO - 2021-07-06 06:42:24 --> Security Class Initialized
DEBUG - 2021-07-06 06:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:42:24 --> Input Class Initialized
INFO - 2021-07-06 06:42:24 --> Language Class Initialized
INFO - 2021-07-06 06:42:24 --> Loader Class Initialized
INFO - 2021-07-06 06:42:24 --> Helper loaded: html_helper
INFO - 2021-07-06 06:42:24 --> Helper loaded: url_helper
INFO - 2021-07-06 06:42:24 --> Helper loaded: form_helper
INFO - 2021-07-06 06:42:24 --> Database Driver Class Initialized
INFO - 2021-07-06 06:42:24 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:42:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:42:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:42:24 --> Encryption Class Initialized
INFO - 2021-07-06 06:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:42:24 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:42:24 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:42:24 --> Model "user_model" initialized
INFO - 2021-07-06 06:42:24 --> Model "role_model" initialized
INFO - 2021-07-06 06:42:24 --> Controller Class Initialized
INFO - 2021-07-06 06:42:24 --> Helper loaded: language_helper
INFO - 2021-07-06 06:42:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:42:24 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:42:24 --> Model "Product_model" initialized
INFO - 2021-07-06 06:42:24 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:42:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:42:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:42:24 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-06 06:42:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:42:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:42:24 --> Final output sent to browser
DEBUG - 2021-07-06 06:42:24 --> Total execution time: 0.0795
INFO - 2021-07-06 06:45:13 --> Config Class Initialized
INFO - 2021-07-06 06:45:13 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:45:13 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:45:13 --> Utf8 Class Initialized
INFO - 2021-07-06 06:45:13 --> URI Class Initialized
INFO - 2021-07-06 06:45:13 --> Router Class Initialized
INFO - 2021-07-06 06:45:13 --> Output Class Initialized
INFO - 2021-07-06 06:45:13 --> Security Class Initialized
DEBUG - 2021-07-06 06:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:45:13 --> Input Class Initialized
INFO - 2021-07-06 06:45:13 --> Language Class Initialized
INFO - 2021-07-06 06:45:13 --> Loader Class Initialized
INFO - 2021-07-06 06:45:13 --> Helper loaded: html_helper
INFO - 2021-07-06 06:45:13 --> Helper loaded: url_helper
INFO - 2021-07-06 06:45:13 --> Helper loaded: form_helper
INFO - 2021-07-06 06:45:13 --> Database Driver Class Initialized
INFO - 2021-07-06 06:45:13 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:45:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:45:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:45:13 --> Encryption Class Initialized
INFO - 2021-07-06 06:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:45:13 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:45:13 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:45:13 --> Model "user_model" initialized
INFO - 2021-07-06 06:45:13 --> Model "role_model" initialized
INFO - 2021-07-06 06:45:13 --> Controller Class Initialized
INFO - 2021-07-06 06:45:13 --> Helper loaded: language_helper
INFO - 2021-07-06 06:45:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:45:13 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:45:13 --> Model "Product_model" initialized
INFO - 2021-07-06 06:45:13 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:45:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:45:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:45:13 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-06 06:45:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:45:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:45:13 --> Final output sent to browser
DEBUG - 2021-07-06 06:45:13 --> Total execution time: 0.1037
INFO - 2021-07-06 06:45:39 --> Config Class Initialized
INFO - 2021-07-06 06:45:39 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:45:39 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:45:39 --> Utf8 Class Initialized
INFO - 2021-07-06 06:45:39 --> URI Class Initialized
INFO - 2021-07-06 06:45:39 --> Router Class Initialized
INFO - 2021-07-06 06:45:39 --> Output Class Initialized
INFO - 2021-07-06 06:45:39 --> Security Class Initialized
DEBUG - 2021-07-06 06:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:45:39 --> Input Class Initialized
INFO - 2021-07-06 06:45:39 --> Language Class Initialized
INFO - 2021-07-06 06:45:39 --> Loader Class Initialized
INFO - 2021-07-06 06:45:39 --> Helper loaded: html_helper
INFO - 2021-07-06 06:45:39 --> Helper loaded: url_helper
INFO - 2021-07-06 06:45:39 --> Helper loaded: form_helper
INFO - 2021-07-06 06:45:39 --> Database Driver Class Initialized
INFO - 2021-07-06 06:45:39 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:45:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:45:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:45:39 --> Encryption Class Initialized
INFO - 2021-07-06 06:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:45:39 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:45:39 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:45:39 --> Model "user_model" initialized
INFO - 2021-07-06 06:45:39 --> Model "role_model" initialized
INFO - 2021-07-06 06:45:39 --> Controller Class Initialized
INFO - 2021-07-06 06:45:39 --> Helper loaded: language_helper
INFO - 2021-07-06 06:45:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:45:39 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:45:39 --> Model "Product_model" initialized
INFO - 2021-07-06 06:45:39 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:45:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:45:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:45:39 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-06 06:45:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:45:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:45:39 --> Final output sent to browser
DEBUG - 2021-07-06 06:45:39 --> Total execution time: 0.1075
INFO - 2021-07-06 06:49:35 --> Config Class Initialized
INFO - 2021-07-06 06:49:35 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:49:35 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:49:35 --> Utf8 Class Initialized
INFO - 2021-07-06 06:49:35 --> URI Class Initialized
INFO - 2021-07-06 06:49:35 --> Router Class Initialized
INFO - 2021-07-06 06:49:35 --> Output Class Initialized
INFO - 2021-07-06 06:49:35 --> Security Class Initialized
DEBUG - 2021-07-06 06:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:49:35 --> Input Class Initialized
INFO - 2021-07-06 06:49:35 --> Language Class Initialized
INFO - 2021-07-06 06:49:35 --> Loader Class Initialized
INFO - 2021-07-06 06:49:35 --> Helper loaded: html_helper
INFO - 2021-07-06 06:49:35 --> Helper loaded: url_helper
INFO - 2021-07-06 06:49:35 --> Helper loaded: form_helper
INFO - 2021-07-06 06:49:35 --> Database Driver Class Initialized
INFO - 2021-07-06 06:49:35 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:49:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:49:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:49:35 --> Encryption Class Initialized
INFO - 2021-07-06 06:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:49:35 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:49:35 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:49:35 --> Model "user_model" initialized
INFO - 2021-07-06 06:49:35 --> Model "role_model" initialized
INFO - 2021-07-06 06:49:35 --> Controller Class Initialized
INFO - 2021-07-06 06:49:35 --> Helper loaded: language_helper
INFO - 2021-07-06 06:49:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:49:35 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:49:35 --> Model "Product_model" initialized
INFO - 2021-07-06 06:49:35 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:49:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:49:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:49:35 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 39
INFO - 2021-07-06 06:49:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:49:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:49:35 --> Final output sent to browser
DEBUG - 2021-07-06 06:49:35 --> Total execution time: 0.1102
INFO - 2021-07-06 06:49:45 --> Config Class Initialized
INFO - 2021-07-06 06:49:45 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:49:45 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:49:45 --> Utf8 Class Initialized
INFO - 2021-07-06 06:49:45 --> URI Class Initialized
INFO - 2021-07-06 06:49:45 --> Router Class Initialized
INFO - 2021-07-06 06:49:45 --> Output Class Initialized
INFO - 2021-07-06 06:49:45 --> Security Class Initialized
DEBUG - 2021-07-06 06:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:49:45 --> Input Class Initialized
INFO - 2021-07-06 06:49:45 --> Language Class Initialized
INFO - 2021-07-06 06:49:45 --> Loader Class Initialized
INFO - 2021-07-06 06:49:45 --> Helper loaded: html_helper
INFO - 2021-07-06 06:49:45 --> Helper loaded: url_helper
INFO - 2021-07-06 06:49:45 --> Helper loaded: form_helper
INFO - 2021-07-06 06:49:45 --> Database Driver Class Initialized
INFO - 2021-07-06 06:49:45 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:49:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:49:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:49:45 --> Encryption Class Initialized
INFO - 2021-07-06 06:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:49:45 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:49:45 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:49:45 --> Model "user_model" initialized
INFO - 2021-07-06 06:49:45 --> Model "role_model" initialized
INFO - 2021-07-06 06:49:45 --> Controller Class Initialized
INFO - 2021-07-06 06:49:45 --> Helper loaded: language_helper
INFO - 2021-07-06 06:49:45 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:49:45 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:49:45 --> Model "Product_model" initialized
INFO - 2021-07-06 06:49:45 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:49:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:49:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:49:45 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 39
INFO - 2021-07-06 06:49:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:49:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:49:45 --> Final output sent to browser
DEBUG - 2021-07-06 06:49:45 --> Total execution time: 0.0928
INFO - 2021-07-06 06:50:16 --> Config Class Initialized
INFO - 2021-07-06 06:50:16 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:50:16 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:50:16 --> Utf8 Class Initialized
INFO - 2021-07-06 06:50:16 --> URI Class Initialized
INFO - 2021-07-06 06:50:16 --> Router Class Initialized
INFO - 2021-07-06 06:50:16 --> Output Class Initialized
INFO - 2021-07-06 06:50:16 --> Security Class Initialized
DEBUG - 2021-07-06 06:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:50:16 --> Input Class Initialized
INFO - 2021-07-06 06:50:16 --> Language Class Initialized
INFO - 2021-07-06 06:50:16 --> Loader Class Initialized
INFO - 2021-07-06 06:50:16 --> Helper loaded: html_helper
INFO - 2021-07-06 06:50:16 --> Helper loaded: url_helper
INFO - 2021-07-06 06:50:16 --> Helper loaded: form_helper
INFO - 2021-07-06 06:50:16 --> Database Driver Class Initialized
INFO - 2021-07-06 06:50:16 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:50:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:50:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:50:16 --> Encryption Class Initialized
INFO - 2021-07-06 06:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:50:16 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:50:16 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:50:16 --> Model "user_model" initialized
INFO - 2021-07-06 06:50:16 --> Model "role_model" initialized
INFO - 2021-07-06 06:50:16 --> Controller Class Initialized
INFO - 2021-07-06 06:50:16 --> Helper loaded: language_helper
INFO - 2021-07-06 06:50:16 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:50:16 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:50:16 --> Model "Product_model" initialized
INFO - 2021-07-06 06:50:16 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:50:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:50:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:50:16 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 39
INFO - 2021-07-06 06:50:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:50:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:50:16 --> Final output sent to browser
DEBUG - 2021-07-06 06:50:16 --> Total execution time: 0.1153
INFO - 2021-07-06 06:50:19 --> Config Class Initialized
INFO - 2021-07-06 06:50:19 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:50:19 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:50:19 --> Utf8 Class Initialized
INFO - 2021-07-06 06:50:19 --> URI Class Initialized
INFO - 2021-07-06 06:50:19 --> Router Class Initialized
INFO - 2021-07-06 06:50:19 --> Output Class Initialized
INFO - 2021-07-06 06:50:19 --> Security Class Initialized
DEBUG - 2021-07-06 06:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:50:19 --> Input Class Initialized
INFO - 2021-07-06 06:50:19 --> Language Class Initialized
INFO - 2021-07-06 06:50:19 --> Loader Class Initialized
INFO - 2021-07-06 06:50:19 --> Helper loaded: html_helper
INFO - 2021-07-06 06:50:19 --> Helper loaded: url_helper
INFO - 2021-07-06 06:50:19 --> Helper loaded: form_helper
INFO - 2021-07-06 06:50:19 --> Database Driver Class Initialized
INFO - 2021-07-06 06:50:19 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:50:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:50:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:50:19 --> Encryption Class Initialized
INFO - 2021-07-06 06:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:50:19 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:50:19 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:50:19 --> Model "user_model" initialized
INFO - 2021-07-06 06:50:19 --> Model "role_model" initialized
INFO - 2021-07-06 06:50:19 --> Controller Class Initialized
INFO - 2021-07-06 06:50:19 --> Helper loaded: language_helper
INFO - 2021-07-06 06:50:19 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:50:19 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:50:19 --> Model "Product_model" initialized
INFO - 2021-07-06 06:50:19 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:50:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:50:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:50:19 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 39
INFO - 2021-07-06 06:50:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:50:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:50:19 --> Final output sent to browser
DEBUG - 2021-07-06 06:50:19 --> Total execution time: 0.0784
INFO - 2021-07-06 06:50:20 --> Config Class Initialized
INFO - 2021-07-06 06:50:20 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:50:20 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:50:20 --> Utf8 Class Initialized
INFO - 2021-07-06 06:50:20 --> URI Class Initialized
INFO - 2021-07-06 06:50:20 --> Router Class Initialized
INFO - 2021-07-06 06:50:20 --> Output Class Initialized
INFO - 2021-07-06 06:50:20 --> Security Class Initialized
DEBUG - 2021-07-06 06:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:50:20 --> Input Class Initialized
INFO - 2021-07-06 06:50:20 --> Language Class Initialized
INFO - 2021-07-06 06:50:20 --> Loader Class Initialized
INFO - 2021-07-06 06:50:20 --> Helper loaded: html_helper
INFO - 2021-07-06 06:50:20 --> Helper loaded: url_helper
INFO - 2021-07-06 06:50:20 --> Helper loaded: form_helper
INFO - 2021-07-06 06:50:20 --> Database Driver Class Initialized
INFO - 2021-07-06 06:50:20 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:50:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:50:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:50:20 --> Encryption Class Initialized
INFO - 2021-07-06 06:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:50:20 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:50:20 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:50:20 --> Model "user_model" initialized
INFO - 2021-07-06 06:50:20 --> Model "role_model" initialized
INFO - 2021-07-06 06:50:20 --> Controller Class Initialized
INFO - 2021-07-06 06:50:20 --> Helper loaded: language_helper
INFO - 2021-07-06 06:50:20 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:50:20 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:50:20 --> Model "Product_model" initialized
INFO - 2021-07-06 06:50:20 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:50:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:50:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:50:20 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 39
INFO - 2021-07-06 06:50:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:50:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:50:20 --> Final output sent to browser
DEBUG - 2021-07-06 06:50:20 --> Total execution time: 0.0771
INFO - 2021-07-06 06:50:54 --> Config Class Initialized
INFO - 2021-07-06 06:50:54 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:50:54 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:50:54 --> Utf8 Class Initialized
INFO - 2021-07-06 06:50:54 --> URI Class Initialized
INFO - 2021-07-06 06:50:54 --> Router Class Initialized
INFO - 2021-07-06 06:50:54 --> Output Class Initialized
INFO - 2021-07-06 06:50:54 --> Security Class Initialized
DEBUG - 2021-07-06 06:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:50:54 --> Input Class Initialized
INFO - 2021-07-06 06:50:54 --> Language Class Initialized
INFO - 2021-07-06 06:50:55 --> Loader Class Initialized
INFO - 2021-07-06 06:50:55 --> Helper loaded: html_helper
INFO - 2021-07-06 06:50:55 --> Helper loaded: url_helper
INFO - 2021-07-06 06:50:55 --> Helper loaded: form_helper
INFO - 2021-07-06 06:50:55 --> Database Driver Class Initialized
INFO - 2021-07-06 06:50:55 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:50:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:50:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:50:55 --> Encryption Class Initialized
INFO - 2021-07-06 06:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:50:55 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:50:55 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:50:55 --> Model "user_model" initialized
INFO - 2021-07-06 06:50:55 --> Model "role_model" initialized
INFO - 2021-07-06 06:50:55 --> Controller Class Initialized
INFO - 2021-07-06 06:50:55 --> Helper loaded: language_helper
INFO - 2021-07-06 06:50:55 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:50:55 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:50:55 --> Model "Product_model" initialized
INFO - 2021-07-06 06:50:55 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:50:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:50:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:50:55 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 39
INFO - 2021-07-06 06:50:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:50:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:50:55 --> Final output sent to browser
DEBUG - 2021-07-06 06:50:55 --> Total execution time: 0.1059
INFO - 2021-07-06 06:50:56 --> Config Class Initialized
INFO - 2021-07-06 06:50:56 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:50:56 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:50:56 --> Utf8 Class Initialized
INFO - 2021-07-06 06:50:56 --> URI Class Initialized
INFO - 2021-07-06 06:50:56 --> Router Class Initialized
INFO - 2021-07-06 06:50:56 --> Output Class Initialized
INFO - 2021-07-06 06:50:56 --> Security Class Initialized
DEBUG - 2021-07-06 06:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:50:56 --> Input Class Initialized
INFO - 2021-07-06 06:50:56 --> Language Class Initialized
INFO - 2021-07-06 06:50:56 --> Loader Class Initialized
INFO - 2021-07-06 06:50:56 --> Helper loaded: html_helper
INFO - 2021-07-06 06:50:56 --> Helper loaded: url_helper
INFO - 2021-07-06 06:50:56 --> Helper loaded: form_helper
INFO - 2021-07-06 06:50:56 --> Database Driver Class Initialized
INFO - 2021-07-06 06:50:56 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:50:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:50:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:50:56 --> Encryption Class Initialized
INFO - 2021-07-06 06:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:50:56 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:50:56 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:50:56 --> Model "user_model" initialized
INFO - 2021-07-06 06:50:56 --> Model "role_model" initialized
INFO - 2021-07-06 06:50:56 --> Controller Class Initialized
INFO - 2021-07-06 06:50:56 --> Helper loaded: language_helper
INFO - 2021-07-06 06:50:56 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:50:56 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:50:56 --> Model "Product_model" initialized
INFO - 2021-07-06 06:50:56 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:50:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:50:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:50:56 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 39
INFO - 2021-07-06 06:50:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:50:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:50:56 --> Final output sent to browser
DEBUG - 2021-07-06 06:50:56 --> Total execution time: 0.0724
INFO - 2021-07-06 06:50:57 --> Config Class Initialized
INFO - 2021-07-06 06:50:57 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:50:57 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:50:57 --> Utf8 Class Initialized
INFO - 2021-07-06 06:50:57 --> URI Class Initialized
INFO - 2021-07-06 06:50:57 --> Router Class Initialized
INFO - 2021-07-06 06:50:57 --> Output Class Initialized
INFO - 2021-07-06 06:50:57 --> Security Class Initialized
DEBUG - 2021-07-06 06:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:50:57 --> Input Class Initialized
INFO - 2021-07-06 06:50:57 --> Language Class Initialized
INFO - 2021-07-06 06:50:57 --> Loader Class Initialized
INFO - 2021-07-06 06:50:57 --> Helper loaded: html_helper
INFO - 2021-07-06 06:50:57 --> Helper loaded: url_helper
INFO - 2021-07-06 06:50:57 --> Helper loaded: form_helper
INFO - 2021-07-06 06:50:57 --> Database Driver Class Initialized
INFO - 2021-07-06 06:50:57 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:50:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:50:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:50:57 --> Encryption Class Initialized
INFO - 2021-07-06 06:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:50:57 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:50:57 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:50:57 --> Model "user_model" initialized
INFO - 2021-07-06 06:50:57 --> Model "role_model" initialized
INFO - 2021-07-06 06:50:57 --> Controller Class Initialized
INFO - 2021-07-06 06:50:57 --> Helper loaded: language_helper
INFO - 2021-07-06 06:50:57 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:50:57 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:50:57 --> Model "Product_model" initialized
INFO - 2021-07-06 06:50:57 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:50:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:50:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:50:57 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 39
INFO - 2021-07-06 06:50:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:50:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:50:57 --> Final output sent to browser
DEBUG - 2021-07-06 06:50:57 --> Total execution time: 0.0704
INFO - 2021-07-06 06:51:18 --> Config Class Initialized
INFO - 2021-07-06 06:51:18 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:51:18 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:51:18 --> Utf8 Class Initialized
INFO - 2021-07-06 06:51:18 --> URI Class Initialized
INFO - 2021-07-06 06:51:18 --> Router Class Initialized
INFO - 2021-07-06 06:51:18 --> Output Class Initialized
INFO - 2021-07-06 06:51:18 --> Security Class Initialized
DEBUG - 2021-07-06 06:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:51:18 --> Input Class Initialized
INFO - 2021-07-06 06:51:18 --> Language Class Initialized
INFO - 2021-07-06 06:51:18 --> Loader Class Initialized
INFO - 2021-07-06 06:51:18 --> Helper loaded: html_helper
INFO - 2021-07-06 06:51:18 --> Helper loaded: url_helper
INFO - 2021-07-06 06:51:18 --> Helper loaded: form_helper
INFO - 2021-07-06 06:51:18 --> Database Driver Class Initialized
INFO - 2021-07-06 06:51:18 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:51:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:51:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:51:18 --> Encryption Class Initialized
INFO - 2021-07-06 06:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:51:18 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:51:18 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:51:18 --> Model "user_model" initialized
INFO - 2021-07-06 06:51:18 --> Model "role_model" initialized
INFO - 2021-07-06 06:51:18 --> Controller Class Initialized
INFO - 2021-07-06 06:51:18 --> Helper loaded: language_helper
INFO - 2021-07-06 06:51:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:51:18 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:51:18 --> Model "Product_model" initialized
INFO - 2021-07-06 06:51:18 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:51:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:51:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:51:18 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 39
INFO - 2021-07-06 06:51:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:51:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:51:18 --> Final output sent to browser
DEBUG - 2021-07-06 06:51:18 --> Total execution time: 0.0766
INFO - 2021-07-06 06:51:27 --> Config Class Initialized
INFO - 2021-07-06 06:51:27 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:51:27 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:51:27 --> Utf8 Class Initialized
INFO - 2021-07-06 06:51:27 --> URI Class Initialized
INFO - 2021-07-06 06:51:27 --> Router Class Initialized
INFO - 2021-07-06 06:51:27 --> Output Class Initialized
INFO - 2021-07-06 06:51:27 --> Security Class Initialized
DEBUG - 2021-07-06 06:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:51:27 --> Input Class Initialized
INFO - 2021-07-06 06:51:27 --> Language Class Initialized
INFO - 2021-07-06 06:51:27 --> Loader Class Initialized
INFO - 2021-07-06 06:51:27 --> Helper loaded: html_helper
INFO - 2021-07-06 06:51:27 --> Helper loaded: url_helper
INFO - 2021-07-06 06:51:27 --> Helper loaded: form_helper
INFO - 2021-07-06 06:51:27 --> Database Driver Class Initialized
INFO - 2021-07-06 06:51:27 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:51:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:51:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:51:27 --> Encryption Class Initialized
INFO - 2021-07-06 06:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:51:27 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:51:27 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:51:27 --> Model "user_model" initialized
INFO - 2021-07-06 06:51:27 --> Model "role_model" initialized
INFO - 2021-07-06 06:51:27 --> Controller Class Initialized
INFO - 2021-07-06 06:51:27 --> Helper loaded: language_helper
INFO - 2021-07-06 06:51:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:51:27 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:51:27 --> Model "Product_model" initialized
INFO - 2021-07-06 06:51:27 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:51:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:51:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:51:27 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 39
INFO - 2021-07-06 06:51:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:51:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:51:27 --> Final output sent to browser
DEBUG - 2021-07-06 06:51:27 --> Total execution time: 0.1094
INFO - 2021-07-06 06:51:48 --> Config Class Initialized
INFO - 2021-07-06 06:51:48 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:51:48 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:51:48 --> Utf8 Class Initialized
INFO - 2021-07-06 06:51:48 --> URI Class Initialized
INFO - 2021-07-06 06:51:48 --> Router Class Initialized
INFO - 2021-07-06 06:51:48 --> Output Class Initialized
INFO - 2021-07-06 06:51:48 --> Security Class Initialized
DEBUG - 2021-07-06 06:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:51:48 --> Input Class Initialized
INFO - 2021-07-06 06:51:48 --> Language Class Initialized
INFO - 2021-07-06 06:51:48 --> Loader Class Initialized
INFO - 2021-07-06 06:51:48 --> Helper loaded: html_helper
INFO - 2021-07-06 06:51:48 --> Helper loaded: url_helper
INFO - 2021-07-06 06:51:48 --> Helper loaded: form_helper
INFO - 2021-07-06 06:51:48 --> Database Driver Class Initialized
INFO - 2021-07-06 06:51:48 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:51:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:51:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:51:48 --> Encryption Class Initialized
INFO - 2021-07-06 06:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:51:48 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:51:48 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:51:48 --> Model "user_model" initialized
INFO - 2021-07-06 06:51:48 --> Model "role_model" initialized
INFO - 2021-07-06 06:51:48 --> Controller Class Initialized
INFO - 2021-07-06 06:51:48 --> Helper loaded: language_helper
INFO - 2021-07-06 06:51:48 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:51:48 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:51:48 --> Model "Product_model" initialized
INFO - 2021-07-06 06:51:48 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:51:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:51:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:51:48 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 39
INFO - 2021-07-06 06:51:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:51:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:51:48 --> Final output sent to browser
DEBUG - 2021-07-06 06:51:48 --> Total execution time: 0.1038
INFO - 2021-07-06 06:51:49 --> Config Class Initialized
INFO - 2021-07-06 06:51:49 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:51:49 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:51:49 --> Utf8 Class Initialized
INFO - 2021-07-06 06:51:49 --> URI Class Initialized
INFO - 2021-07-06 06:51:49 --> Router Class Initialized
INFO - 2021-07-06 06:51:49 --> Output Class Initialized
INFO - 2021-07-06 06:51:49 --> Security Class Initialized
DEBUG - 2021-07-06 06:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:51:49 --> Input Class Initialized
INFO - 2021-07-06 06:51:49 --> Language Class Initialized
INFO - 2021-07-06 06:51:49 --> Loader Class Initialized
INFO - 2021-07-06 06:51:49 --> Helper loaded: html_helper
INFO - 2021-07-06 06:51:49 --> Helper loaded: url_helper
INFO - 2021-07-06 06:51:49 --> Helper loaded: form_helper
INFO - 2021-07-06 06:51:49 --> Database Driver Class Initialized
INFO - 2021-07-06 06:51:49 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:51:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:51:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:51:49 --> Encryption Class Initialized
INFO - 2021-07-06 06:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:51:49 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:51:49 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:51:49 --> Model "user_model" initialized
INFO - 2021-07-06 06:51:49 --> Model "role_model" initialized
INFO - 2021-07-06 06:51:49 --> Controller Class Initialized
INFO - 2021-07-06 06:51:49 --> Helper loaded: language_helper
INFO - 2021-07-06 06:51:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:51:49 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:51:49 --> Model "Product_model" initialized
INFO - 2021-07-06 06:51:49 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:51:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:51:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:51:49 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 39
INFO - 2021-07-06 06:51:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:51:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:51:49 --> Final output sent to browser
DEBUG - 2021-07-06 06:51:49 --> Total execution time: 0.0603
INFO - 2021-07-06 06:52:06 --> Config Class Initialized
INFO - 2021-07-06 06:52:06 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:52:06 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:52:06 --> Utf8 Class Initialized
INFO - 2021-07-06 06:52:06 --> URI Class Initialized
INFO - 2021-07-06 06:52:06 --> Router Class Initialized
INFO - 2021-07-06 06:52:06 --> Output Class Initialized
INFO - 2021-07-06 06:52:06 --> Security Class Initialized
DEBUG - 2021-07-06 06:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:52:06 --> Input Class Initialized
INFO - 2021-07-06 06:52:06 --> Language Class Initialized
INFO - 2021-07-06 06:52:06 --> Loader Class Initialized
INFO - 2021-07-06 06:52:06 --> Helper loaded: html_helper
INFO - 2021-07-06 06:52:06 --> Helper loaded: url_helper
INFO - 2021-07-06 06:52:06 --> Helper loaded: form_helper
INFO - 2021-07-06 06:52:06 --> Database Driver Class Initialized
INFO - 2021-07-06 06:52:06 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:52:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:52:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:52:06 --> Encryption Class Initialized
INFO - 2021-07-06 06:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:52:06 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:52:06 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:52:06 --> Model "user_model" initialized
INFO - 2021-07-06 06:52:06 --> Model "role_model" initialized
INFO - 2021-07-06 06:52:06 --> Controller Class Initialized
INFO - 2021-07-06 06:52:06 --> Helper loaded: language_helper
INFO - 2021-07-06 06:52:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:52:06 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:52:06 --> Model "Product_model" initialized
INFO - 2021-07-06 06:52:06 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:52:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:52:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:52:06 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 39
INFO - 2021-07-06 06:52:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:52:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:52:06 --> Final output sent to browser
DEBUG - 2021-07-06 06:52:06 --> Total execution time: 0.0754
INFO - 2021-07-06 06:53:48 --> Config Class Initialized
INFO - 2021-07-06 06:53:48 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:53:48 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:53:48 --> Utf8 Class Initialized
INFO - 2021-07-06 06:53:48 --> URI Class Initialized
INFO - 2021-07-06 06:53:48 --> Router Class Initialized
INFO - 2021-07-06 06:53:48 --> Output Class Initialized
INFO - 2021-07-06 06:53:48 --> Security Class Initialized
DEBUG - 2021-07-06 06:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:53:48 --> Input Class Initialized
INFO - 2021-07-06 06:53:48 --> Language Class Initialized
INFO - 2021-07-06 06:53:48 --> Loader Class Initialized
INFO - 2021-07-06 06:53:48 --> Helper loaded: html_helper
INFO - 2021-07-06 06:53:48 --> Helper loaded: url_helper
INFO - 2021-07-06 06:53:48 --> Helper loaded: form_helper
INFO - 2021-07-06 06:53:48 --> Database Driver Class Initialized
INFO - 2021-07-06 06:53:48 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:53:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:53:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:53:48 --> Encryption Class Initialized
INFO - 2021-07-06 06:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:53:48 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:53:48 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:53:48 --> Model "user_model" initialized
INFO - 2021-07-06 06:53:48 --> Model "role_model" initialized
INFO - 2021-07-06 06:53:48 --> Controller Class Initialized
INFO - 2021-07-06 06:53:48 --> Helper loaded: language_helper
INFO - 2021-07-06 06:53:48 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:53:48 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:53:48 --> Model "Product_model" initialized
INFO - 2021-07-06 06:53:48 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:53:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:53:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:53:48 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 34
INFO - 2021-07-06 06:53:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:53:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:53:48 --> Final output sent to browser
DEBUG - 2021-07-06 06:53:48 --> Total execution time: 0.1097
INFO - 2021-07-06 06:53:50 --> Config Class Initialized
INFO - 2021-07-06 06:53:50 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:53:50 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:53:50 --> Utf8 Class Initialized
INFO - 2021-07-06 06:53:50 --> URI Class Initialized
INFO - 2021-07-06 06:53:50 --> Router Class Initialized
INFO - 2021-07-06 06:53:50 --> Output Class Initialized
INFO - 2021-07-06 06:53:50 --> Security Class Initialized
DEBUG - 2021-07-06 06:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:53:50 --> Input Class Initialized
INFO - 2021-07-06 06:53:50 --> Language Class Initialized
INFO - 2021-07-06 06:53:50 --> Loader Class Initialized
INFO - 2021-07-06 06:53:50 --> Helper loaded: html_helper
INFO - 2021-07-06 06:53:50 --> Helper loaded: url_helper
INFO - 2021-07-06 06:53:50 --> Helper loaded: form_helper
INFO - 2021-07-06 06:53:50 --> Database Driver Class Initialized
INFO - 2021-07-06 06:53:50 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:53:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:53:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:53:50 --> Encryption Class Initialized
INFO - 2021-07-06 06:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:53:50 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:53:50 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:53:50 --> Model "user_model" initialized
INFO - 2021-07-06 06:53:50 --> Model "role_model" initialized
INFO - 2021-07-06 06:53:50 --> Controller Class Initialized
INFO - 2021-07-06 06:53:50 --> Helper loaded: language_helper
INFO - 2021-07-06 06:53:50 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:53:50 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:53:50 --> Model "Product_model" initialized
INFO - 2021-07-06 06:53:50 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:53:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:53:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:53:50 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 34
INFO - 2021-07-06 06:53:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:53:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:53:50 --> Final output sent to browser
DEBUG - 2021-07-06 06:53:50 --> Total execution time: 0.0741
INFO - 2021-07-06 06:53:51 --> Config Class Initialized
INFO - 2021-07-06 06:53:51 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:53:51 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:53:51 --> Utf8 Class Initialized
INFO - 2021-07-06 06:53:51 --> URI Class Initialized
INFO - 2021-07-06 06:53:51 --> Router Class Initialized
INFO - 2021-07-06 06:53:51 --> Output Class Initialized
INFO - 2021-07-06 06:53:51 --> Security Class Initialized
DEBUG - 2021-07-06 06:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:53:51 --> Input Class Initialized
INFO - 2021-07-06 06:53:51 --> Language Class Initialized
INFO - 2021-07-06 06:53:51 --> Loader Class Initialized
INFO - 2021-07-06 06:53:51 --> Helper loaded: html_helper
INFO - 2021-07-06 06:53:51 --> Helper loaded: url_helper
INFO - 2021-07-06 06:53:51 --> Helper loaded: form_helper
INFO - 2021-07-06 06:53:51 --> Database Driver Class Initialized
INFO - 2021-07-06 06:53:51 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:53:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:53:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:53:51 --> Encryption Class Initialized
INFO - 2021-07-06 06:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:53:51 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:53:51 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:53:51 --> Model "user_model" initialized
INFO - 2021-07-06 06:53:51 --> Model "role_model" initialized
INFO - 2021-07-06 06:53:51 --> Controller Class Initialized
INFO - 2021-07-06 06:53:51 --> Helper loaded: language_helper
INFO - 2021-07-06 06:53:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:53:51 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:53:51 --> Model "Product_model" initialized
INFO - 2021-07-06 06:53:51 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:53:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:53:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:53:51 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 34
INFO - 2021-07-06 06:53:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:53:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:53:51 --> Final output sent to browser
DEBUG - 2021-07-06 06:53:51 --> Total execution time: 0.0810
INFO - 2021-07-06 06:53:52 --> Config Class Initialized
INFO - 2021-07-06 06:53:52 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:53:52 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:53:52 --> Utf8 Class Initialized
INFO - 2021-07-06 06:53:52 --> URI Class Initialized
INFO - 2021-07-06 06:53:52 --> Router Class Initialized
INFO - 2021-07-06 06:53:52 --> Output Class Initialized
INFO - 2021-07-06 06:53:52 --> Security Class Initialized
DEBUG - 2021-07-06 06:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:53:52 --> Input Class Initialized
INFO - 2021-07-06 06:53:52 --> Language Class Initialized
INFO - 2021-07-06 06:53:52 --> Loader Class Initialized
INFO - 2021-07-06 06:53:52 --> Helper loaded: html_helper
INFO - 2021-07-06 06:53:52 --> Helper loaded: url_helper
INFO - 2021-07-06 06:53:52 --> Helper loaded: form_helper
INFO - 2021-07-06 06:53:52 --> Database Driver Class Initialized
INFO - 2021-07-06 06:53:52 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:53:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:53:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:53:52 --> Encryption Class Initialized
INFO - 2021-07-06 06:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:53:52 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:53:52 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:53:52 --> Model "user_model" initialized
INFO - 2021-07-06 06:53:52 --> Model "role_model" initialized
INFO - 2021-07-06 06:53:52 --> Controller Class Initialized
INFO - 2021-07-06 06:53:52 --> Helper loaded: language_helper
INFO - 2021-07-06 06:53:52 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:53:52 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:53:52 --> Model "Product_model" initialized
INFO - 2021-07-06 06:53:52 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:53:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:53:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:53:52 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 34
INFO - 2021-07-06 06:53:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:53:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:53:52 --> Final output sent to browser
DEBUG - 2021-07-06 06:53:52 --> Total execution time: 0.0708
INFO - 2021-07-06 06:55:55 --> Config Class Initialized
INFO - 2021-07-06 06:55:55 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:55:55 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:55:55 --> Utf8 Class Initialized
INFO - 2021-07-06 06:55:55 --> URI Class Initialized
INFO - 2021-07-06 06:55:55 --> Router Class Initialized
INFO - 2021-07-06 06:55:55 --> Output Class Initialized
INFO - 2021-07-06 06:55:55 --> Security Class Initialized
DEBUG - 2021-07-06 06:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:55:55 --> Input Class Initialized
INFO - 2021-07-06 06:55:55 --> Language Class Initialized
INFO - 2021-07-06 06:55:55 --> Loader Class Initialized
INFO - 2021-07-06 06:55:55 --> Helper loaded: html_helper
INFO - 2021-07-06 06:55:55 --> Helper loaded: url_helper
INFO - 2021-07-06 06:55:55 --> Helper loaded: form_helper
INFO - 2021-07-06 06:55:55 --> Database Driver Class Initialized
INFO - 2021-07-06 06:55:55 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:55:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:55:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:55:55 --> Encryption Class Initialized
INFO - 2021-07-06 06:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:55:55 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:55:55 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:55:55 --> Model "user_model" initialized
INFO - 2021-07-06 06:55:55 --> Model "role_model" initialized
INFO - 2021-07-06 06:55:55 --> Controller Class Initialized
INFO - 2021-07-06 06:55:55 --> Helper loaded: language_helper
INFO - 2021-07-06 06:55:55 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:55:55 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:55:55 --> Model "Product_model" initialized
INFO - 2021-07-06 06:55:55 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:55:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:55:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:55:55 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 34
INFO - 2021-07-06 06:55:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:55:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:55:55 --> Final output sent to browser
DEBUG - 2021-07-06 06:55:55 --> Total execution time: 0.1244
INFO - 2021-07-06 06:55:56 --> Config Class Initialized
INFO - 2021-07-06 06:55:56 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:55:56 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:55:56 --> Utf8 Class Initialized
INFO - 2021-07-06 06:55:56 --> URI Class Initialized
INFO - 2021-07-06 06:55:56 --> Router Class Initialized
INFO - 2021-07-06 06:55:56 --> Output Class Initialized
INFO - 2021-07-06 06:55:56 --> Security Class Initialized
DEBUG - 2021-07-06 06:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:55:56 --> Input Class Initialized
INFO - 2021-07-06 06:55:56 --> Language Class Initialized
INFO - 2021-07-06 06:55:56 --> Loader Class Initialized
INFO - 2021-07-06 06:55:56 --> Helper loaded: html_helper
INFO - 2021-07-06 06:55:56 --> Helper loaded: url_helper
INFO - 2021-07-06 06:55:56 --> Helper loaded: form_helper
INFO - 2021-07-06 06:55:56 --> Database Driver Class Initialized
INFO - 2021-07-06 06:55:56 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:55:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:55:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:55:56 --> Encryption Class Initialized
INFO - 2021-07-06 06:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:55:56 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:55:56 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:55:56 --> Model "user_model" initialized
INFO - 2021-07-06 06:55:56 --> Model "role_model" initialized
INFO - 2021-07-06 06:55:56 --> Controller Class Initialized
INFO - 2021-07-06 06:55:56 --> Helper loaded: language_helper
INFO - 2021-07-06 06:55:56 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:55:56 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:55:56 --> Model "Product_model" initialized
INFO - 2021-07-06 06:55:56 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:55:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:55:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:55:56 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 34
INFO - 2021-07-06 06:55:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:55:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:55:56 --> Final output sent to browser
DEBUG - 2021-07-06 06:55:56 --> Total execution time: 0.0711
INFO - 2021-07-06 06:56:47 --> Config Class Initialized
INFO - 2021-07-06 06:56:47 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:56:47 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:56:47 --> Utf8 Class Initialized
INFO - 2021-07-06 06:56:47 --> URI Class Initialized
INFO - 2021-07-06 06:56:47 --> Router Class Initialized
INFO - 2021-07-06 06:56:47 --> Output Class Initialized
INFO - 2021-07-06 06:56:47 --> Security Class Initialized
DEBUG - 2021-07-06 06:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:56:47 --> Input Class Initialized
INFO - 2021-07-06 06:56:47 --> Language Class Initialized
INFO - 2021-07-06 06:56:47 --> Loader Class Initialized
INFO - 2021-07-06 06:56:47 --> Helper loaded: html_helper
INFO - 2021-07-06 06:56:47 --> Helper loaded: url_helper
INFO - 2021-07-06 06:56:47 --> Helper loaded: form_helper
INFO - 2021-07-06 06:56:47 --> Database Driver Class Initialized
INFO - 2021-07-06 06:56:47 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:56:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:56:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:56:47 --> Encryption Class Initialized
INFO - 2021-07-06 06:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:56:47 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:56:47 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:56:47 --> Model "user_model" initialized
INFO - 2021-07-06 06:56:47 --> Model "role_model" initialized
INFO - 2021-07-06 06:56:47 --> Controller Class Initialized
INFO - 2021-07-06 06:56:47 --> Helper loaded: language_helper
INFO - 2021-07-06 06:56:47 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:56:47 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:56:47 --> Model "Product_model" initialized
INFO - 2021-07-06 06:56:47 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:56:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:56:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:56:47 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-06 06:56:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:56:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:56:47 --> Final output sent to browser
DEBUG - 2021-07-06 06:56:47 --> Total execution time: 0.1015
INFO - 2021-07-06 06:56:48 --> Config Class Initialized
INFO - 2021-07-06 06:56:48 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:56:48 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:56:48 --> Utf8 Class Initialized
INFO - 2021-07-06 06:56:48 --> URI Class Initialized
INFO - 2021-07-06 06:56:48 --> Router Class Initialized
INFO - 2021-07-06 06:56:48 --> Output Class Initialized
INFO - 2021-07-06 06:56:48 --> Security Class Initialized
DEBUG - 2021-07-06 06:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:56:48 --> Input Class Initialized
INFO - 2021-07-06 06:56:48 --> Language Class Initialized
INFO - 2021-07-06 06:56:48 --> Loader Class Initialized
INFO - 2021-07-06 06:56:48 --> Helper loaded: html_helper
INFO - 2021-07-06 06:56:48 --> Helper loaded: url_helper
INFO - 2021-07-06 06:56:48 --> Helper loaded: form_helper
INFO - 2021-07-06 06:56:48 --> Database Driver Class Initialized
INFO - 2021-07-06 06:56:48 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:56:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:56:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:56:48 --> Encryption Class Initialized
INFO - 2021-07-06 06:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:56:48 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:56:48 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:56:48 --> Model "user_model" initialized
INFO - 2021-07-06 06:56:48 --> Model "role_model" initialized
INFO - 2021-07-06 06:56:48 --> Controller Class Initialized
INFO - 2021-07-06 06:56:48 --> Helper loaded: language_helper
INFO - 2021-07-06 06:56:48 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:56:48 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:56:48 --> Model "Product_model" initialized
INFO - 2021-07-06 06:56:48 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:56:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:56:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:56:48 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-06 06:56:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:56:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:56:48 --> Final output sent to browser
DEBUG - 2021-07-06 06:56:48 --> Total execution time: 0.0711
INFO - 2021-07-06 06:56:59 --> Config Class Initialized
INFO - 2021-07-06 06:56:59 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:56:59 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:56:59 --> Utf8 Class Initialized
INFO - 2021-07-06 06:56:59 --> URI Class Initialized
INFO - 2021-07-06 06:56:59 --> Router Class Initialized
INFO - 2021-07-06 06:56:59 --> Output Class Initialized
INFO - 2021-07-06 06:56:59 --> Security Class Initialized
DEBUG - 2021-07-06 06:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:56:59 --> Input Class Initialized
INFO - 2021-07-06 06:56:59 --> Language Class Initialized
INFO - 2021-07-06 06:56:59 --> Loader Class Initialized
INFO - 2021-07-06 06:56:59 --> Helper loaded: html_helper
INFO - 2021-07-06 06:56:59 --> Helper loaded: url_helper
INFO - 2021-07-06 06:56:59 --> Helper loaded: form_helper
INFO - 2021-07-06 06:56:59 --> Database Driver Class Initialized
INFO - 2021-07-06 06:56:59 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:56:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:56:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:56:59 --> Encryption Class Initialized
INFO - 2021-07-06 06:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:56:59 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:56:59 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:56:59 --> Model "user_model" initialized
INFO - 2021-07-06 06:56:59 --> Model "role_model" initialized
INFO - 2021-07-06 06:56:59 --> Controller Class Initialized
INFO - 2021-07-06 06:56:59 --> Helper loaded: language_helper
INFO - 2021-07-06 06:56:59 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:56:59 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:56:59 --> Model "Product_model" initialized
INFO - 2021-07-06 06:56:59 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:56:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:56:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:56:59 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-06 06:56:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:56:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:56:59 --> Final output sent to browser
DEBUG - 2021-07-06 06:56:59 --> Total execution time: 0.0668
INFO - 2021-07-06 06:57:55 --> Config Class Initialized
INFO - 2021-07-06 06:57:55 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:57:55 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:57:55 --> Utf8 Class Initialized
INFO - 2021-07-06 06:57:55 --> URI Class Initialized
INFO - 2021-07-06 06:57:55 --> Router Class Initialized
INFO - 2021-07-06 06:57:55 --> Output Class Initialized
INFO - 2021-07-06 06:57:55 --> Security Class Initialized
DEBUG - 2021-07-06 06:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:57:55 --> Input Class Initialized
INFO - 2021-07-06 06:57:55 --> Language Class Initialized
INFO - 2021-07-06 06:57:55 --> Loader Class Initialized
INFO - 2021-07-06 06:57:55 --> Helper loaded: html_helper
INFO - 2021-07-06 06:57:55 --> Helper loaded: url_helper
INFO - 2021-07-06 06:57:55 --> Helper loaded: form_helper
INFO - 2021-07-06 06:57:55 --> Database Driver Class Initialized
INFO - 2021-07-06 06:57:55 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:57:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:57:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:57:55 --> Encryption Class Initialized
INFO - 2021-07-06 06:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:57:55 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:57:55 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:57:55 --> Model "user_model" initialized
INFO - 2021-07-06 06:57:55 --> Model "role_model" initialized
INFO - 2021-07-06 06:57:55 --> Controller Class Initialized
INFO - 2021-07-06 06:57:55 --> Helper loaded: language_helper
INFO - 2021-07-06 06:57:55 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:57:55 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:57:55 --> Final output sent to browser
DEBUG - 2021-07-06 06:57:55 --> Total execution time: 0.1078
INFO - 2021-07-06 06:58:11 --> Config Class Initialized
INFO - 2021-07-06 06:58:11 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:58:11 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:58:11 --> Utf8 Class Initialized
INFO - 2021-07-06 06:58:11 --> URI Class Initialized
INFO - 2021-07-06 06:58:11 --> Router Class Initialized
INFO - 2021-07-06 06:58:11 --> Output Class Initialized
INFO - 2021-07-06 06:58:11 --> Security Class Initialized
DEBUG - 2021-07-06 06:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:58:11 --> Input Class Initialized
INFO - 2021-07-06 06:58:11 --> Language Class Initialized
INFO - 2021-07-06 06:58:11 --> Loader Class Initialized
INFO - 2021-07-06 06:58:11 --> Helper loaded: html_helper
INFO - 2021-07-06 06:58:11 --> Helper loaded: url_helper
INFO - 2021-07-06 06:58:11 --> Helper loaded: form_helper
INFO - 2021-07-06 06:58:11 --> Database Driver Class Initialized
INFO - 2021-07-06 06:58:12 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:58:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:58:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:58:12 --> Encryption Class Initialized
INFO - 2021-07-06 06:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:58:12 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:58:12 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:58:12 --> Model "user_model" initialized
INFO - 2021-07-06 06:58:12 --> Model "role_model" initialized
INFO - 2021-07-06 06:58:12 --> Controller Class Initialized
INFO - 2021-07-06 06:58:12 --> Helper loaded: language_helper
INFO - 2021-07-06 06:58:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:58:12 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:58:12 --> Final output sent to browser
DEBUG - 2021-07-06 06:58:12 --> Total execution time: 0.0639
INFO - 2021-07-06 06:58:47 --> Config Class Initialized
INFO - 2021-07-06 06:58:47 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:58:47 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:58:47 --> Utf8 Class Initialized
INFO - 2021-07-06 06:58:47 --> URI Class Initialized
INFO - 2021-07-06 06:58:47 --> Router Class Initialized
INFO - 2021-07-06 06:58:47 --> Output Class Initialized
INFO - 2021-07-06 06:58:47 --> Security Class Initialized
DEBUG - 2021-07-06 06:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:58:47 --> Input Class Initialized
INFO - 2021-07-06 06:58:47 --> Language Class Initialized
INFO - 2021-07-06 06:58:47 --> Loader Class Initialized
INFO - 2021-07-06 06:58:47 --> Helper loaded: html_helper
INFO - 2021-07-06 06:58:47 --> Helper loaded: url_helper
INFO - 2021-07-06 06:58:47 --> Helper loaded: form_helper
INFO - 2021-07-06 06:58:47 --> Database Driver Class Initialized
INFO - 2021-07-06 06:58:47 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:58:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:58:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:58:47 --> Encryption Class Initialized
INFO - 2021-07-06 06:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:58:47 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:58:47 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:58:47 --> Model "user_model" initialized
INFO - 2021-07-06 06:58:47 --> Model "role_model" initialized
INFO - 2021-07-06 06:58:47 --> Controller Class Initialized
INFO - 2021-07-06 06:58:47 --> Helper loaded: language_helper
INFO - 2021-07-06 06:58:47 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:58:47 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:58:47 --> Model "Product_model" initialized
INFO - 2021-07-06 06:58:47 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:58:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:58:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:58:47 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-06 06:58:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:58:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:58:47 --> Final output sent to browser
DEBUG - 2021-07-06 06:58:47 --> Total execution time: 0.0848
INFO - 2021-07-06 06:59:39 --> Config Class Initialized
INFO - 2021-07-06 06:59:39 --> Hooks Class Initialized
DEBUG - 2021-07-06 06:59:39 --> UTF-8 Support Enabled
INFO - 2021-07-06 06:59:39 --> Utf8 Class Initialized
INFO - 2021-07-06 06:59:39 --> URI Class Initialized
INFO - 2021-07-06 06:59:39 --> Router Class Initialized
INFO - 2021-07-06 06:59:39 --> Output Class Initialized
INFO - 2021-07-06 06:59:39 --> Security Class Initialized
DEBUG - 2021-07-06 06:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 06:59:39 --> Input Class Initialized
INFO - 2021-07-06 06:59:39 --> Language Class Initialized
INFO - 2021-07-06 06:59:39 --> Loader Class Initialized
INFO - 2021-07-06 06:59:39 --> Helper loaded: html_helper
INFO - 2021-07-06 06:59:39 --> Helper loaded: url_helper
INFO - 2021-07-06 06:59:39 --> Helper loaded: form_helper
INFO - 2021-07-06 06:59:39 --> Database Driver Class Initialized
INFO - 2021-07-06 06:59:39 --> Form Validation Class Initialized
DEBUG - 2021-07-06 06:59:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 06:59:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 06:59:39 --> Encryption Class Initialized
INFO - 2021-07-06 06:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 06:59:39 --> Model "vendor_model" initialized
INFO - 2021-07-06 06:59:39 --> Model "coupon_model" initialized
INFO - 2021-07-06 06:59:39 --> Model "user_model" initialized
INFO - 2021-07-06 06:59:39 --> Model "role_model" initialized
INFO - 2021-07-06 06:59:39 --> Controller Class Initialized
INFO - 2021-07-06 06:59:39 --> Helper loaded: language_helper
INFO - 2021-07-06 06:59:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 06:59:39 --> Model "Customer_model" initialized
INFO - 2021-07-06 06:59:39 --> Model "Product_model" initialized
INFO - 2021-07-06 06:59:39 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 06:59:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 06:59:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 06:59:39 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-06 06:59:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 06:59:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 06:59:39 --> Final output sent to browser
DEBUG - 2021-07-06 06:59:39 --> Total execution time: 0.1062
INFO - 2021-07-06 07:01:14 --> Config Class Initialized
INFO - 2021-07-06 07:01:14 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:01:14 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:01:14 --> Utf8 Class Initialized
INFO - 2021-07-06 07:01:14 --> URI Class Initialized
INFO - 2021-07-06 07:01:14 --> Router Class Initialized
INFO - 2021-07-06 07:01:14 --> Output Class Initialized
INFO - 2021-07-06 07:01:14 --> Security Class Initialized
DEBUG - 2021-07-06 07:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:01:14 --> Input Class Initialized
INFO - 2021-07-06 07:01:14 --> Language Class Initialized
INFO - 2021-07-06 07:01:14 --> Loader Class Initialized
INFO - 2021-07-06 07:01:14 --> Helper loaded: html_helper
INFO - 2021-07-06 07:01:14 --> Helper loaded: url_helper
INFO - 2021-07-06 07:01:14 --> Helper loaded: form_helper
INFO - 2021-07-06 07:01:14 --> Database Driver Class Initialized
INFO - 2021-07-06 07:01:14 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:01:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:01:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:01:14 --> Encryption Class Initialized
INFO - 2021-07-06 07:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:01:14 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:01:14 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:01:14 --> Model "user_model" initialized
INFO - 2021-07-06 07:01:14 --> Model "role_model" initialized
INFO - 2021-07-06 07:01:14 --> Controller Class Initialized
INFO - 2021-07-06 07:01:14 --> Helper loaded: language_helper
INFO - 2021-07-06 07:01:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:01:14 --> Model "Customer_model" initialized
INFO - 2021-07-06 07:01:14 --> Model "Product_model" initialized
INFO - 2021-07-06 07:01:14 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 07:01:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 07:01:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 07:01:14 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-06 07:01:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 07:01:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 07:01:14 --> Final output sent to browser
DEBUG - 2021-07-06 07:01:14 --> Total execution time: 0.0760
INFO - 2021-07-06 07:01:39 --> Config Class Initialized
INFO - 2021-07-06 07:01:39 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:01:39 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:01:39 --> Utf8 Class Initialized
INFO - 2021-07-06 07:01:39 --> URI Class Initialized
INFO - 2021-07-06 07:01:39 --> Router Class Initialized
INFO - 2021-07-06 07:01:39 --> Output Class Initialized
INFO - 2021-07-06 07:01:39 --> Security Class Initialized
DEBUG - 2021-07-06 07:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:01:39 --> Input Class Initialized
INFO - 2021-07-06 07:01:39 --> Language Class Initialized
INFO - 2021-07-06 07:01:39 --> Loader Class Initialized
INFO - 2021-07-06 07:01:39 --> Helper loaded: html_helper
INFO - 2021-07-06 07:01:39 --> Helper loaded: url_helper
INFO - 2021-07-06 07:01:39 --> Helper loaded: form_helper
INFO - 2021-07-06 07:01:39 --> Database Driver Class Initialized
INFO - 2021-07-06 07:01:39 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:01:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:01:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:01:39 --> Encryption Class Initialized
INFO - 2021-07-06 07:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:01:39 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:01:39 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:01:39 --> Model "user_model" initialized
INFO - 2021-07-06 07:01:39 --> Model "role_model" initialized
INFO - 2021-07-06 07:01:39 --> Controller Class Initialized
INFO - 2021-07-06 07:01:39 --> Helper loaded: language_helper
INFO - 2021-07-06 07:01:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:01:39 --> Model "Customer_model" initialized
INFO - 2021-07-06 07:01:39 --> Final output sent to browser
DEBUG - 2021-07-06 07:01:39 --> Total execution time: 0.0847
INFO - 2021-07-06 07:01:54 --> Config Class Initialized
INFO - 2021-07-06 07:01:54 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:01:54 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:01:54 --> Utf8 Class Initialized
INFO - 2021-07-06 07:01:54 --> URI Class Initialized
INFO - 2021-07-06 07:01:54 --> Router Class Initialized
INFO - 2021-07-06 07:01:54 --> Output Class Initialized
INFO - 2021-07-06 07:01:54 --> Security Class Initialized
DEBUG - 2021-07-06 07:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:01:54 --> Input Class Initialized
INFO - 2021-07-06 07:01:54 --> Language Class Initialized
INFO - 2021-07-06 07:01:54 --> Loader Class Initialized
INFO - 2021-07-06 07:01:54 --> Helper loaded: html_helper
INFO - 2021-07-06 07:01:54 --> Helper loaded: url_helper
INFO - 2021-07-06 07:01:54 --> Helper loaded: form_helper
INFO - 2021-07-06 07:01:54 --> Database Driver Class Initialized
INFO - 2021-07-06 07:01:54 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:01:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:01:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:01:54 --> Encryption Class Initialized
INFO - 2021-07-06 07:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:01:54 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:01:54 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:01:54 --> Model "user_model" initialized
INFO - 2021-07-06 07:01:54 --> Model "role_model" initialized
INFO - 2021-07-06 07:01:54 --> Controller Class Initialized
INFO - 2021-07-06 07:01:54 --> Helper loaded: language_helper
INFO - 2021-07-06 07:01:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:01:54 --> Model "Customer_model" initialized
INFO - 2021-07-06 07:01:54 --> Final output sent to browser
DEBUG - 2021-07-06 07:01:54 --> Total execution time: 0.0715
INFO - 2021-07-06 07:02:34 --> Config Class Initialized
INFO - 2021-07-06 07:02:34 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:02:34 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:02:34 --> Utf8 Class Initialized
INFO - 2021-07-06 07:02:34 --> URI Class Initialized
INFO - 2021-07-06 07:02:34 --> Router Class Initialized
INFO - 2021-07-06 07:02:34 --> Output Class Initialized
INFO - 2021-07-06 07:02:34 --> Security Class Initialized
DEBUG - 2021-07-06 07:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:02:34 --> Input Class Initialized
INFO - 2021-07-06 07:02:34 --> Language Class Initialized
INFO - 2021-07-06 07:02:34 --> Loader Class Initialized
INFO - 2021-07-06 07:02:34 --> Helper loaded: html_helper
INFO - 2021-07-06 07:02:34 --> Helper loaded: url_helper
INFO - 2021-07-06 07:02:34 --> Helper loaded: form_helper
INFO - 2021-07-06 07:02:34 --> Database Driver Class Initialized
INFO - 2021-07-06 07:02:34 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:02:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:02:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:02:34 --> Encryption Class Initialized
INFO - 2021-07-06 07:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:02:34 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:02:34 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:02:34 --> Model "user_model" initialized
INFO - 2021-07-06 07:02:34 --> Model "role_model" initialized
INFO - 2021-07-06 07:02:34 --> Controller Class Initialized
INFO - 2021-07-06 07:02:34 --> Helper loaded: language_helper
INFO - 2021-07-06 07:02:34 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:02:34 --> Model "Product_model" initialized
INFO - 2021-07-06 07:02:34 --> Final output sent to browser
DEBUG - 2021-07-06 07:02:34 --> Total execution time: 0.0962
INFO - 2021-07-06 07:02:46 --> Config Class Initialized
INFO - 2021-07-06 07:02:46 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:02:46 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:02:46 --> Utf8 Class Initialized
INFO - 2021-07-06 07:02:46 --> URI Class Initialized
INFO - 2021-07-06 07:02:46 --> Router Class Initialized
INFO - 2021-07-06 07:02:46 --> Output Class Initialized
INFO - 2021-07-06 07:02:46 --> Security Class Initialized
DEBUG - 2021-07-06 07:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:02:46 --> Input Class Initialized
INFO - 2021-07-06 07:02:46 --> Language Class Initialized
INFO - 2021-07-06 07:02:46 --> Loader Class Initialized
INFO - 2021-07-06 07:02:46 --> Helper loaded: html_helper
INFO - 2021-07-06 07:02:46 --> Helper loaded: url_helper
INFO - 2021-07-06 07:02:46 --> Helper loaded: form_helper
INFO - 2021-07-06 07:02:46 --> Database Driver Class Initialized
INFO - 2021-07-06 07:02:46 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:02:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:02:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:02:46 --> Encryption Class Initialized
INFO - 2021-07-06 07:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:02:46 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:02:46 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:02:46 --> Model "user_model" initialized
INFO - 2021-07-06 07:02:46 --> Model "role_model" initialized
INFO - 2021-07-06 07:02:46 --> Controller Class Initialized
INFO - 2021-07-06 07:02:46 --> Helper loaded: language_helper
INFO - 2021-07-06 07:02:46 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:02:46 --> Model "Product_model" initialized
INFO - 2021-07-06 07:02:46 --> Final output sent to browser
DEBUG - 2021-07-06 07:02:46 --> Total execution time: 0.0646
INFO - 2021-07-06 07:03:01 --> Config Class Initialized
INFO - 2021-07-06 07:03:01 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:03:01 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:03:01 --> Utf8 Class Initialized
INFO - 2021-07-06 07:03:01 --> URI Class Initialized
INFO - 2021-07-06 07:03:01 --> Router Class Initialized
INFO - 2021-07-06 07:03:01 --> Output Class Initialized
INFO - 2021-07-06 07:03:01 --> Security Class Initialized
DEBUG - 2021-07-06 07:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:03:01 --> Input Class Initialized
INFO - 2021-07-06 07:03:01 --> Language Class Initialized
INFO - 2021-07-06 07:03:01 --> Loader Class Initialized
INFO - 2021-07-06 07:03:01 --> Helper loaded: html_helper
INFO - 2021-07-06 07:03:01 --> Helper loaded: url_helper
INFO - 2021-07-06 07:03:01 --> Helper loaded: form_helper
INFO - 2021-07-06 07:03:01 --> Database Driver Class Initialized
INFO - 2021-07-06 07:03:01 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:03:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:03:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:03:01 --> Encryption Class Initialized
INFO - 2021-07-06 07:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:03:01 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:03:01 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:03:01 --> Model "user_model" initialized
INFO - 2021-07-06 07:03:01 --> Model "role_model" initialized
INFO - 2021-07-06 07:03:01 --> Controller Class Initialized
INFO - 2021-07-06 07:03:01 --> Helper loaded: language_helper
INFO - 2021-07-06 07:03:01 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:03:01 --> Model "Quotation_model" initialized
INFO - 2021-07-06 07:03:01 --> Final output sent to browser
DEBUG - 2021-07-06 07:03:01 --> Total execution time: 0.1125
INFO - 2021-07-06 07:03:01 --> Config Class Initialized
INFO - 2021-07-06 07:03:01 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:03:01 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:03:01 --> Utf8 Class Initialized
INFO - 2021-07-06 07:03:01 --> URI Class Initialized
INFO - 2021-07-06 07:03:01 --> Router Class Initialized
INFO - 2021-07-06 07:03:01 --> Output Class Initialized
INFO - 2021-07-06 07:03:01 --> Security Class Initialized
DEBUG - 2021-07-06 07:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:03:01 --> Input Class Initialized
INFO - 2021-07-06 07:03:01 --> Language Class Initialized
INFO - 2021-07-06 07:03:01 --> Loader Class Initialized
INFO - 2021-07-06 07:03:01 --> Helper loaded: html_helper
INFO - 2021-07-06 07:03:01 --> Helper loaded: url_helper
INFO - 2021-07-06 07:03:01 --> Helper loaded: form_helper
INFO - 2021-07-06 07:03:01 --> Database Driver Class Initialized
INFO - 2021-07-06 07:03:01 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:03:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:03:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:03:01 --> Encryption Class Initialized
INFO - 2021-07-06 07:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:03:01 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:03:01 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:03:01 --> Model "user_model" initialized
INFO - 2021-07-06 07:03:01 --> Model "role_model" initialized
INFO - 2021-07-06 07:03:01 --> Controller Class Initialized
INFO - 2021-07-06 07:03:01 --> Helper loaded: language_helper
INFO - 2021-07-06 07:03:01 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:03:01 --> Model "Quotation_model" initialized
INFO - 2021-07-06 07:03:01 --> Final output sent to browser
DEBUG - 2021-07-06 07:03:01 --> Total execution time: 0.0739
INFO - 2021-07-06 07:03:07 --> Config Class Initialized
INFO - 2021-07-06 07:03:07 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:03:07 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:03:07 --> Utf8 Class Initialized
INFO - 2021-07-06 07:03:07 --> URI Class Initialized
INFO - 2021-07-06 07:03:07 --> Router Class Initialized
INFO - 2021-07-06 07:03:07 --> Output Class Initialized
INFO - 2021-07-06 07:03:07 --> Security Class Initialized
DEBUG - 2021-07-06 07:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:03:07 --> Input Class Initialized
INFO - 2021-07-06 07:03:07 --> Language Class Initialized
INFO - 2021-07-06 07:03:07 --> Loader Class Initialized
INFO - 2021-07-06 07:03:07 --> Helper loaded: html_helper
INFO - 2021-07-06 07:03:07 --> Helper loaded: url_helper
INFO - 2021-07-06 07:03:07 --> Helper loaded: form_helper
INFO - 2021-07-06 07:03:07 --> Database Driver Class Initialized
INFO - 2021-07-06 07:03:07 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:03:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:03:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:03:07 --> Encryption Class Initialized
INFO - 2021-07-06 07:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:03:07 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:03:07 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:03:07 --> Model "user_model" initialized
INFO - 2021-07-06 07:03:07 --> Model "role_model" initialized
INFO - 2021-07-06 07:03:07 --> Controller Class Initialized
INFO - 2021-07-06 07:03:07 --> Helper loaded: language_helper
INFO - 2021-07-06 07:03:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:03:07 --> Model "Quotation_model" initialized
INFO - 2021-07-06 07:03:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 07:03:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 07:03:07 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-06 07:03:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-06 07:03:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 07:03:07 --> Final output sent to browser
DEBUG - 2021-07-06 07:03:07 --> Total execution time: 0.1340
INFO - 2021-07-06 07:03:08 --> Config Class Initialized
INFO - 2021-07-06 07:03:08 --> Hooks Class Initialized
INFO - 2021-07-06 07:03:08 --> Config Class Initialized
INFO - 2021-07-06 07:03:08 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:03:08 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:03:08 --> Utf8 Class Initialized
DEBUG - 2021-07-06 07:03:08 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:03:08 --> Utf8 Class Initialized
INFO - 2021-07-06 07:03:08 --> URI Class Initialized
INFO - 2021-07-06 07:03:08 --> URI Class Initialized
INFO - 2021-07-06 07:03:08 --> Router Class Initialized
INFO - 2021-07-06 07:03:08 --> Router Class Initialized
INFO - 2021-07-06 07:03:08 --> Output Class Initialized
INFO - 2021-07-06 07:03:08 --> Output Class Initialized
INFO - 2021-07-06 07:03:08 --> Security Class Initialized
INFO - 2021-07-06 07:03:08 --> Security Class Initialized
DEBUG - 2021-07-06 07:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-06 07:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:03:08 --> Input Class Initialized
INFO - 2021-07-06 07:03:08 --> Input Class Initialized
INFO - 2021-07-06 07:03:08 --> Language Class Initialized
INFO - 2021-07-06 07:03:08 --> Language Class Initialized
INFO - 2021-07-06 07:03:08 --> Loader Class Initialized
INFO - 2021-07-06 07:03:08 --> Loader Class Initialized
INFO - 2021-07-06 07:03:08 --> Helper loaded: html_helper
INFO - 2021-07-06 07:03:08 --> Helper loaded: html_helper
INFO - 2021-07-06 07:03:08 --> Helper loaded: url_helper
INFO - 2021-07-06 07:03:08 --> Helper loaded: url_helper
INFO - 2021-07-06 07:03:08 --> Helper loaded: form_helper
INFO - 2021-07-06 07:03:08 --> Helper loaded: form_helper
INFO - 2021-07-06 07:03:08 --> Database Driver Class Initialized
INFO - 2021-07-06 07:03:08 --> Database Driver Class Initialized
INFO - 2021-07-06 07:03:08 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:03:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:03:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:03:08 --> Encryption Class Initialized
INFO - 2021-07-06 07:03:08 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:03:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:03:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:03:08 --> Encryption Class Initialized
INFO - 2021-07-06 07:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:03:08 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:03:08 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:03:08 --> Model "user_model" initialized
INFO - 2021-07-06 07:03:08 --> Model "role_model" initialized
INFO - 2021-07-06 07:03:08 --> Controller Class Initialized
INFO - 2021-07-06 07:03:08 --> Helper loaded: language_helper
INFO - 2021-07-06 07:03:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:03:08 --> Model "Quotation_model" initialized
INFO - 2021-07-06 07:03:08 --> Final output sent to browser
DEBUG - 2021-07-06 07:03:08 --> Total execution time: 0.0899
INFO - 2021-07-06 07:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:03:08 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:03:08 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:03:08 --> Model "user_model" initialized
INFO - 2021-07-06 07:03:08 --> Model "role_model" initialized
INFO - 2021-07-06 07:03:08 --> Controller Class Initialized
INFO - 2021-07-06 07:03:08 --> Helper loaded: language_helper
INFO - 2021-07-06 07:03:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:03:08 --> Model "Quotation_model" initialized
INFO - 2021-07-06 07:03:08 --> Final output sent to browser
DEBUG - 2021-07-06 07:03:08 --> Total execution time: 0.1008
INFO - 2021-07-06 07:03:31 --> Config Class Initialized
INFO - 2021-07-06 07:03:31 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:03:31 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:03:31 --> Utf8 Class Initialized
INFO - 2021-07-06 07:03:31 --> URI Class Initialized
INFO - 2021-07-06 07:03:31 --> Router Class Initialized
INFO - 2021-07-06 07:03:31 --> Output Class Initialized
INFO - 2021-07-06 07:03:31 --> Security Class Initialized
DEBUG - 2021-07-06 07:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:03:31 --> Input Class Initialized
INFO - 2021-07-06 07:03:31 --> Language Class Initialized
INFO - 2021-07-06 07:03:31 --> Loader Class Initialized
INFO - 2021-07-06 07:03:31 --> Helper loaded: html_helper
INFO - 2021-07-06 07:03:31 --> Helper loaded: url_helper
INFO - 2021-07-06 07:03:31 --> Helper loaded: form_helper
INFO - 2021-07-06 07:03:31 --> Database Driver Class Initialized
INFO - 2021-07-06 07:03:31 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:03:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:03:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:03:31 --> Encryption Class Initialized
INFO - 2021-07-06 07:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:03:31 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:03:31 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:03:31 --> Model "user_model" initialized
INFO - 2021-07-06 07:03:31 --> Model "role_model" initialized
INFO - 2021-07-06 07:03:31 --> Controller Class Initialized
INFO - 2021-07-06 07:03:31 --> Helper loaded: language_helper
INFO - 2021-07-06 07:03:31 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:03:31 --> Model "Quotation_model" initialized
INFO - 2021-07-06 07:03:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 07:03:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 07:03:31 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-06 07:03:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-06 07:03:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 07:03:31 --> Final output sent to browser
DEBUG - 2021-07-06 07:03:31 --> Total execution time: 0.0802
INFO - 2021-07-06 07:03:37 --> Config Class Initialized
INFO - 2021-07-06 07:03:37 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:03:37 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:03:37 --> Utf8 Class Initialized
INFO - 2021-07-06 07:03:37 --> URI Class Initialized
INFO - 2021-07-06 07:03:37 --> Router Class Initialized
INFO - 2021-07-06 07:03:37 --> Output Class Initialized
INFO - 2021-07-06 07:03:37 --> Security Class Initialized
DEBUG - 2021-07-06 07:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:03:37 --> Input Class Initialized
INFO - 2021-07-06 07:03:37 --> Language Class Initialized
INFO - 2021-07-06 07:03:37 --> Loader Class Initialized
INFO - 2021-07-06 07:03:37 --> Helper loaded: html_helper
INFO - 2021-07-06 07:03:37 --> Helper loaded: url_helper
INFO - 2021-07-06 07:03:37 --> Helper loaded: form_helper
INFO - 2021-07-06 07:03:37 --> Database Driver Class Initialized
INFO - 2021-07-06 07:03:37 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:03:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:03:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:03:37 --> Encryption Class Initialized
INFO - 2021-07-06 07:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:03:37 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:03:37 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:03:37 --> Model "user_model" initialized
INFO - 2021-07-06 07:03:37 --> Model "role_model" initialized
INFO - 2021-07-06 07:03:37 --> Controller Class Initialized
INFO - 2021-07-06 07:03:37 --> Helper loaded: language_helper
INFO - 2021-07-06 07:03:37 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:03:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-06 07:03:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-06 07:03:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-06 07:03:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 07:03:37 --> Final output sent to browser
DEBUG - 2021-07-06 07:03:37 --> Total execution time: 0.1231
INFO - 2021-07-06 07:24:24 --> Config Class Initialized
INFO - 2021-07-06 07:24:24 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:24:24 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:24:24 --> Utf8 Class Initialized
INFO - 2021-07-06 07:24:24 --> URI Class Initialized
DEBUG - 2021-07-06 07:24:24 --> No URI present. Default controller set.
INFO - 2021-07-06 07:24:24 --> Router Class Initialized
INFO - 2021-07-06 07:24:24 --> Output Class Initialized
INFO - 2021-07-06 07:24:24 --> Security Class Initialized
DEBUG - 2021-07-06 07:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:24:24 --> Input Class Initialized
INFO - 2021-07-06 07:24:24 --> Language Class Initialized
INFO - 2021-07-06 07:24:24 --> Loader Class Initialized
INFO - 2021-07-06 07:24:24 --> Helper loaded: html_helper
INFO - 2021-07-06 07:24:24 --> Helper loaded: url_helper
INFO - 2021-07-06 07:24:24 --> Helper loaded: form_helper
INFO - 2021-07-06 07:24:24 --> Database Driver Class Initialized
INFO - 2021-07-06 07:24:24 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:24:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:24:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:24:24 --> Encryption Class Initialized
INFO - 2021-07-06 07:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:24:24 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:24:24 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:24:24 --> Model "user_model" initialized
INFO - 2021-07-06 07:24:24 --> Model "role_model" initialized
INFO - 2021-07-06 07:24:24 --> Controller Class Initialized
INFO - 2021-07-06 07:24:24 --> Helper loaded: language_helper
INFO - 2021-07-06 07:24:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:24:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-06 07:24:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-06 07:24:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-06 07:24:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 07:24:24 --> Final output sent to browser
DEBUG - 2021-07-06 07:24:24 --> Total execution time: 0.0836
INFO - 2021-07-06 07:24:25 --> Config Class Initialized
INFO - 2021-07-06 07:24:25 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:24:25 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:24:25 --> Utf8 Class Initialized
INFO - 2021-07-06 07:24:25 --> URI Class Initialized
DEBUG - 2021-07-06 07:24:25 --> No URI present. Default controller set.
INFO - 2021-07-06 07:24:25 --> Router Class Initialized
INFO - 2021-07-06 07:24:25 --> Output Class Initialized
INFO - 2021-07-06 07:24:25 --> Security Class Initialized
DEBUG - 2021-07-06 07:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:24:25 --> Input Class Initialized
INFO - 2021-07-06 07:24:25 --> Language Class Initialized
INFO - 2021-07-06 07:24:25 --> Loader Class Initialized
INFO - 2021-07-06 07:24:25 --> Helper loaded: html_helper
INFO - 2021-07-06 07:24:25 --> Helper loaded: url_helper
INFO - 2021-07-06 07:24:25 --> Helper loaded: form_helper
INFO - 2021-07-06 07:24:25 --> Database Driver Class Initialized
INFO - 2021-07-06 07:24:25 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:24:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:24:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:24:25 --> Encryption Class Initialized
INFO - 2021-07-06 07:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:24:25 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:24:25 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:24:25 --> Model "user_model" initialized
INFO - 2021-07-06 07:24:25 --> Model "role_model" initialized
INFO - 2021-07-06 07:24:25 --> Controller Class Initialized
INFO - 2021-07-06 07:24:25 --> Helper loaded: language_helper
INFO - 2021-07-06 07:24:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:24:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-06 07:24:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-06 07:24:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-06 07:24:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 07:24:25 --> Final output sent to browser
DEBUG - 2021-07-06 07:24:25 --> Total execution time: 0.1089
INFO - 2021-07-06 07:24:29 --> Config Class Initialized
INFO - 2021-07-06 07:24:29 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:24:29 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:24:29 --> Utf8 Class Initialized
INFO - 2021-07-06 07:24:29 --> URI Class Initialized
INFO - 2021-07-06 07:24:29 --> Router Class Initialized
INFO - 2021-07-06 07:24:29 --> Output Class Initialized
INFO - 2021-07-06 07:24:29 --> Security Class Initialized
DEBUG - 2021-07-06 07:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:24:29 --> Input Class Initialized
INFO - 2021-07-06 07:24:29 --> Language Class Initialized
INFO - 2021-07-06 07:24:29 --> Loader Class Initialized
INFO - 2021-07-06 07:24:29 --> Helper loaded: html_helper
INFO - 2021-07-06 07:24:29 --> Helper loaded: url_helper
INFO - 2021-07-06 07:24:29 --> Helper loaded: form_helper
INFO - 2021-07-06 07:24:29 --> Database Driver Class Initialized
INFO - 2021-07-06 07:24:29 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:24:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:24:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:24:29 --> Encryption Class Initialized
INFO - 2021-07-06 07:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:24:29 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:24:29 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:24:29 --> Model "user_model" initialized
INFO - 2021-07-06 07:24:29 --> Model "role_model" initialized
INFO - 2021-07-06 07:24:29 --> Controller Class Initialized
INFO - 2021-07-06 07:24:29 --> Helper loaded: language_helper
INFO - 2021-07-06 07:24:29 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:24:29 --> Model "Customer_model" initialized
INFO - 2021-07-06 07:24:29 --> Model "Product_model" initialized
INFO - 2021-07-06 07:24:29 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 07:24:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 07:24:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 07:24:29 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-06 07:24:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 07:24:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 07:24:29 --> Final output sent to browser
DEBUG - 2021-07-06 07:24:29 --> Total execution time: 0.0788
INFO - 2021-07-06 07:33:24 --> Config Class Initialized
INFO - 2021-07-06 07:33:24 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:33:24 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:33:24 --> Utf8 Class Initialized
INFO - 2021-07-06 07:33:24 --> URI Class Initialized
DEBUG - 2021-07-06 07:33:24 --> No URI present. Default controller set.
INFO - 2021-07-06 07:33:24 --> Router Class Initialized
INFO - 2021-07-06 07:33:24 --> Output Class Initialized
INFO - 2021-07-06 07:33:24 --> Security Class Initialized
DEBUG - 2021-07-06 07:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:33:24 --> Input Class Initialized
INFO - 2021-07-06 07:33:24 --> Language Class Initialized
INFO - 2021-07-06 07:33:24 --> Loader Class Initialized
INFO - 2021-07-06 07:33:24 --> Helper loaded: html_helper
INFO - 2021-07-06 07:33:24 --> Helper loaded: url_helper
INFO - 2021-07-06 07:33:24 --> Helper loaded: form_helper
INFO - 2021-07-06 07:33:24 --> Database Driver Class Initialized
INFO - 2021-07-06 07:33:24 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:33:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:33:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:33:24 --> Encryption Class Initialized
INFO - 2021-07-06 07:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:33:24 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:33:24 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:33:24 --> Model "user_model" initialized
INFO - 2021-07-06 07:33:24 --> Model "role_model" initialized
INFO - 2021-07-06 07:33:24 --> Controller Class Initialized
INFO - 2021-07-06 07:33:24 --> Helper loaded: language_helper
INFO - 2021-07-06 07:33:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:33:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-06 07:33:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-06 07:33:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-06 07:33:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 07:33:24 --> Final output sent to browser
DEBUG - 2021-07-06 07:33:24 --> Total execution time: 0.1182
INFO - 2021-07-06 07:33:25 --> Config Class Initialized
INFO - 2021-07-06 07:33:25 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:33:25 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:33:25 --> Utf8 Class Initialized
INFO - 2021-07-06 07:33:25 --> URI Class Initialized
DEBUG - 2021-07-06 07:33:25 --> No URI present. Default controller set.
INFO - 2021-07-06 07:33:25 --> Router Class Initialized
INFO - 2021-07-06 07:33:25 --> Output Class Initialized
INFO - 2021-07-06 07:33:25 --> Security Class Initialized
DEBUG - 2021-07-06 07:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:33:25 --> Input Class Initialized
INFO - 2021-07-06 07:33:25 --> Language Class Initialized
INFO - 2021-07-06 07:33:25 --> Loader Class Initialized
INFO - 2021-07-06 07:33:25 --> Helper loaded: html_helper
INFO - 2021-07-06 07:33:25 --> Helper loaded: url_helper
INFO - 2021-07-06 07:33:25 --> Helper loaded: form_helper
INFO - 2021-07-06 07:33:25 --> Database Driver Class Initialized
INFO - 2021-07-06 07:33:25 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:33:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:33:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:33:25 --> Encryption Class Initialized
INFO - 2021-07-06 07:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:33:25 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:33:25 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:33:25 --> Model "user_model" initialized
INFO - 2021-07-06 07:33:25 --> Model "role_model" initialized
INFO - 2021-07-06 07:33:25 --> Controller Class Initialized
INFO - 2021-07-06 07:33:25 --> Helper loaded: language_helper
INFO - 2021-07-06 07:33:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:33:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-06 07:33:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-06 07:33:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-06 07:33:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 07:33:25 --> Final output sent to browser
DEBUG - 2021-07-06 07:33:25 --> Total execution time: 0.0754
INFO - 2021-07-06 07:33:35 --> Config Class Initialized
INFO - 2021-07-06 07:33:35 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:33:35 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:33:35 --> Utf8 Class Initialized
INFO - 2021-07-06 07:33:35 --> URI Class Initialized
INFO - 2021-07-06 07:33:35 --> Router Class Initialized
INFO - 2021-07-06 07:33:35 --> Output Class Initialized
INFO - 2021-07-06 07:33:35 --> Security Class Initialized
DEBUG - 2021-07-06 07:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:33:35 --> Input Class Initialized
INFO - 2021-07-06 07:33:35 --> Language Class Initialized
INFO - 2021-07-06 07:33:35 --> Loader Class Initialized
INFO - 2021-07-06 07:33:35 --> Helper loaded: html_helper
INFO - 2021-07-06 07:33:35 --> Helper loaded: url_helper
INFO - 2021-07-06 07:33:35 --> Helper loaded: form_helper
INFO - 2021-07-06 07:33:35 --> Database Driver Class Initialized
INFO - 2021-07-06 07:33:35 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:33:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:33:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:33:35 --> Encryption Class Initialized
INFO - 2021-07-06 07:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:33:35 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:33:35 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:33:35 --> Model "user_model" initialized
INFO - 2021-07-06 07:33:35 --> Model "role_model" initialized
INFO - 2021-07-06 07:33:35 --> Controller Class Initialized
INFO - 2021-07-06 07:33:35 --> Helper loaded: language_helper
INFO - 2021-07-06 07:33:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:33:35 --> Model "Customer_model" initialized
INFO - 2021-07-06 07:33:35 --> Model "Product_model" initialized
INFO - 2021-07-06 07:33:35 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 07:33:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 07:33:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 07:33:35 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-06 07:33:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 07:33:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 07:33:35 --> Final output sent to browser
DEBUG - 2021-07-06 07:33:35 --> Total execution time: 0.1296
INFO - 2021-07-06 07:33:54 --> Config Class Initialized
INFO - 2021-07-06 07:33:54 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:33:54 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:33:54 --> Utf8 Class Initialized
INFO - 2021-07-06 07:33:54 --> URI Class Initialized
INFO - 2021-07-06 07:33:54 --> Router Class Initialized
INFO - 2021-07-06 07:33:54 --> Output Class Initialized
INFO - 2021-07-06 07:33:54 --> Security Class Initialized
DEBUG - 2021-07-06 07:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:33:54 --> Input Class Initialized
INFO - 2021-07-06 07:33:54 --> Language Class Initialized
INFO - 2021-07-06 07:33:54 --> Loader Class Initialized
INFO - 2021-07-06 07:33:54 --> Helper loaded: html_helper
INFO - 2021-07-06 07:33:54 --> Helper loaded: url_helper
INFO - 2021-07-06 07:33:54 --> Helper loaded: form_helper
INFO - 2021-07-06 07:33:54 --> Database Driver Class Initialized
INFO - 2021-07-06 07:33:54 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:33:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:33:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:33:54 --> Encryption Class Initialized
INFO - 2021-07-06 07:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:33:54 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:33:54 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:33:54 --> Model "user_model" initialized
INFO - 2021-07-06 07:33:54 --> Model "role_model" initialized
INFO - 2021-07-06 07:33:54 --> Controller Class Initialized
INFO - 2021-07-06 07:33:54 --> Helper loaded: language_helper
INFO - 2021-07-06 07:33:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:33:54 --> Model "Customer_model" initialized
INFO - 2021-07-06 07:33:54 --> Final output sent to browser
DEBUG - 2021-07-06 07:33:54 --> Total execution time: 0.1111
INFO - 2021-07-06 07:39:26 --> Config Class Initialized
INFO - 2021-07-06 07:39:26 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:39:26 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:39:26 --> Utf8 Class Initialized
INFO - 2021-07-06 07:39:26 --> URI Class Initialized
DEBUG - 2021-07-06 07:39:26 --> No URI present. Default controller set.
INFO - 2021-07-06 07:39:26 --> Router Class Initialized
INFO - 2021-07-06 07:39:26 --> Output Class Initialized
INFO - 2021-07-06 07:39:26 --> Security Class Initialized
DEBUG - 2021-07-06 07:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:39:26 --> Input Class Initialized
INFO - 2021-07-06 07:39:26 --> Language Class Initialized
INFO - 2021-07-06 07:39:26 --> Loader Class Initialized
INFO - 2021-07-06 07:39:26 --> Helper loaded: html_helper
INFO - 2021-07-06 07:39:26 --> Helper loaded: url_helper
INFO - 2021-07-06 07:39:26 --> Helper loaded: form_helper
INFO - 2021-07-06 07:39:26 --> Database Driver Class Initialized
INFO - 2021-07-06 07:39:26 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:39:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:39:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:39:26 --> Encryption Class Initialized
INFO - 2021-07-06 07:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:39:26 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:39:26 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:39:26 --> Model "user_model" initialized
INFO - 2021-07-06 07:39:26 --> Model "role_model" initialized
INFO - 2021-07-06 07:39:26 --> Controller Class Initialized
INFO - 2021-07-06 07:39:26 --> Helper loaded: language_helper
INFO - 2021-07-06 07:39:26 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:39:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-06 07:39:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-06 07:39:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-06 07:39:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 07:39:26 --> Final output sent to browser
DEBUG - 2021-07-06 07:39:26 --> Total execution time: 0.0786
INFO - 2021-07-06 07:39:27 --> Config Class Initialized
INFO - 2021-07-06 07:39:27 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:39:27 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:39:27 --> Utf8 Class Initialized
INFO - 2021-07-06 07:39:27 --> URI Class Initialized
DEBUG - 2021-07-06 07:39:27 --> No URI present. Default controller set.
INFO - 2021-07-06 07:39:27 --> Router Class Initialized
INFO - 2021-07-06 07:39:27 --> Output Class Initialized
INFO - 2021-07-06 07:39:27 --> Security Class Initialized
DEBUG - 2021-07-06 07:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:39:27 --> Input Class Initialized
INFO - 2021-07-06 07:39:27 --> Language Class Initialized
INFO - 2021-07-06 07:39:27 --> Loader Class Initialized
INFO - 2021-07-06 07:39:27 --> Helper loaded: html_helper
INFO - 2021-07-06 07:39:27 --> Helper loaded: url_helper
INFO - 2021-07-06 07:39:27 --> Helper loaded: form_helper
INFO - 2021-07-06 07:39:27 --> Database Driver Class Initialized
INFO - 2021-07-06 07:39:27 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:39:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:39:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:39:27 --> Encryption Class Initialized
INFO - 2021-07-06 07:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:39:27 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:39:27 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:39:27 --> Model "user_model" initialized
INFO - 2021-07-06 07:39:27 --> Model "role_model" initialized
INFO - 2021-07-06 07:39:27 --> Controller Class Initialized
INFO - 2021-07-06 07:39:27 --> Helper loaded: language_helper
INFO - 2021-07-06 07:39:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:39:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-06 07:39:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-06 07:39:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-06 07:39:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 07:39:27 --> Final output sent to browser
DEBUG - 2021-07-06 07:39:27 --> Total execution time: 0.0733
INFO - 2021-07-06 07:39:36 --> Config Class Initialized
INFO - 2021-07-06 07:39:36 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:39:36 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:39:36 --> Utf8 Class Initialized
INFO - 2021-07-06 07:39:36 --> URI Class Initialized
INFO - 2021-07-06 07:39:36 --> Router Class Initialized
INFO - 2021-07-06 07:39:36 --> Output Class Initialized
INFO - 2021-07-06 07:39:36 --> Security Class Initialized
DEBUG - 2021-07-06 07:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:39:36 --> Input Class Initialized
INFO - 2021-07-06 07:39:36 --> Language Class Initialized
INFO - 2021-07-06 07:39:36 --> Loader Class Initialized
INFO - 2021-07-06 07:39:36 --> Helper loaded: html_helper
INFO - 2021-07-06 07:39:36 --> Helper loaded: url_helper
INFO - 2021-07-06 07:39:36 --> Helper loaded: form_helper
INFO - 2021-07-06 07:39:36 --> Database Driver Class Initialized
INFO - 2021-07-06 07:39:36 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:39:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:39:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:39:36 --> Encryption Class Initialized
INFO - 2021-07-06 07:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:39:36 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:39:36 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:39:36 --> Model "user_model" initialized
INFO - 2021-07-06 07:39:36 --> Model "role_model" initialized
INFO - 2021-07-06 07:39:36 --> Controller Class Initialized
INFO - 2021-07-06 07:39:36 --> Helper loaded: language_helper
INFO - 2021-07-06 07:39:36 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:39:36 --> Model "Customer_model" initialized
INFO - 2021-07-06 07:39:36 --> Model "Product_model" initialized
INFO - 2021-07-06 07:39:36 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 07:39:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 07:39:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 07:39:36 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-06 07:39:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 07:39:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 07:39:36 --> Final output sent to browser
DEBUG - 2021-07-06 07:39:36 --> Total execution time: 0.1481
INFO - 2021-07-06 07:40:02 --> Config Class Initialized
INFO - 2021-07-06 07:40:02 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:40:02 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:40:02 --> Utf8 Class Initialized
INFO - 2021-07-06 07:40:02 --> URI Class Initialized
INFO - 2021-07-06 07:40:02 --> Router Class Initialized
INFO - 2021-07-06 07:40:02 --> Output Class Initialized
INFO - 2021-07-06 07:40:02 --> Security Class Initialized
DEBUG - 2021-07-06 07:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:40:02 --> Input Class Initialized
INFO - 2021-07-06 07:40:02 --> Language Class Initialized
INFO - 2021-07-06 07:40:02 --> Loader Class Initialized
INFO - 2021-07-06 07:40:02 --> Helper loaded: html_helper
INFO - 2021-07-06 07:40:02 --> Helper loaded: url_helper
INFO - 2021-07-06 07:40:02 --> Helper loaded: form_helper
INFO - 2021-07-06 07:40:02 --> Database Driver Class Initialized
INFO - 2021-07-06 07:40:02 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:40:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:40:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:40:02 --> Encryption Class Initialized
INFO - 2021-07-06 07:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:40:02 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:40:02 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:40:02 --> Model "user_model" initialized
INFO - 2021-07-06 07:40:02 --> Model "role_model" initialized
INFO - 2021-07-06 07:40:02 --> Controller Class Initialized
INFO - 2021-07-06 07:40:02 --> Helper loaded: language_helper
INFO - 2021-07-06 07:40:02 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:40:02 --> Model "Customer_model" initialized
INFO - 2021-07-06 07:40:02 --> Final output sent to browser
DEBUG - 2021-07-06 07:40:02 --> Total execution time: 0.1023
INFO - 2021-07-06 07:40:15 --> Config Class Initialized
INFO - 2021-07-06 07:40:15 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:40:15 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:40:15 --> Utf8 Class Initialized
INFO - 2021-07-06 07:40:15 --> URI Class Initialized
INFO - 2021-07-06 07:40:15 --> Router Class Initialized
INFO - 2021-07-06 07:40:15 --> Output Class Initialized
INFO - 2021-07-06 07:40:15 --> Security Class Initialized
DEBUG - 2021-07-06 07:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:40:15 --> Input Class Initialized
INFO - 2021-07-06 07:40:15 --> Language Class Initialized
INFO - 2021-07-06 07:40:15 --> Loader Class Initialized
INFO - 2021-07-06 07:40:15 --> Helper loaded: html_helper
INFO - 2021-07-06 07:40:15 --> Helper loaded: url_helper
INFO - 2021-07-06 07:40:15 --> Helper loaded: form_helper
INFO - 2021-07-06 07:40:15 --> Database Driver Class Initialized
INFO - 2021-07-06 07:40:15 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:40:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:40:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:40:15 --> Encryption Class Initialized
INFO - 2021-07-06 07:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:40:15 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:40:15 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:40:15 --> Model "user_model" initialized
INFO - 2021-07-06 07:40:15 --> Model "role_model" initialized
INFO - 2021-07-06 07:40:15 --> Controller Class Initialized
INFO - 2021-07-06 07:40:15 --> Helper loaded: language_helper
INFO - 2021-07-06 07:40:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:40:15 --> Model "Customer_model" initialized
INFO - 2021-07-06 07:40:15 --> Final output sent to browser
DEBUG - 2021-07-06 07:40:15 --> Total execution time: 0.0793
INFO - 2021-07-06 07:40:57 --> Config Class Initialized
INFO - 2021-07-06 07:40:57 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:40:57 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:40:57 --> Utf8 Class Initialized
INFO - 2021-07-06 07:40:57 --> URI Class Initialized
INFO - 2021-07-06 07:40:57 --> Router Class Initialized
INFO - 2021-07-06 07:40:57 --> Output Class Initialized
INFO - 2021-07-06 07:40:57 --> Security Class Initialized
DEBUG - 2021-07-06 07:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:40:57 --> Input Class Initialized
INFO - 2021-07-06 07:40:57 --> Language Class Initialized
INFO - 2021-07-06 07:40:57 --> Loader Class Initialized
INFO - 2021-07-06 07:40:57 --> Helper loaded: html_helper
INFO - 2021-07-06 07:40:57 --> Helper loaded: url_helper
INFO - 2021-07-06 07:40:57 --> Helper loaded: form_helper
INFO - 2021-07-06 07:40:57 --> Database Driver Class Initialized
INFO - 2021-07-06 07:40:57 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:40:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:40:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:40:57 --> Encryption Class Initialized
INFO - 2021-07-06 07:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:40:57 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:40:57 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:40:57 --> Model "user_model" initialized
INFO - 2021-07-06 07:40:57 --> Model "role_model" initialized
INFO - 2021-07-06 07:40:57 --> Controller Class Initialized
INFO - 2021-07-06 07:40:57 --> Helper loaded: language_helper
INFO - 2021-07-06 07:40:57 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:40:57 --> Model "Product_model" initialized
INFO - 2021-07-06 07:40:57 --> Final output sent to browser
DEBUG - 2021-07-06 07:40:57 --> Total execution time: 0.0931
INFO - 2021-07-06 07:41:07 --> Config Class Initialized
INFO - 2021-07-06 07:41:07 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:41:07 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:41:07 --> Utf8 Class Initialized
INFO - 2021-07-06 07:41:07 --> URI Class Initialized
INFO - 2021-07-06 07:41:07 --> Router Class Initialized
INFO - 2021-07-06 07:41:07 --> Output Class Initialized
INFO - 2021-07-06 07:41:07 --> Security Class Initialized
DEBUG - 2021-07-06 07:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:41:07 --> Input Class Initialized
INFO - 2021-07-06 07:41:07 --> Language Class Initialized
INFO - 2021-07-06 07:41:07 --> Loader Class Initialized
INFO - 2021-07-06 07:41:07 --> Helper loaded: html_helper
INFO - 2021-07-06 07:41:07 --> Helper loaded: url_helper
INFO - 2021-07-06 07:41:07 --> Helper loaded: form_helper
INFO - 2021-07-06 07:41:07 --> Database Driver Class Initialized
INFO - 2021-07-06 07:41:07 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:41:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:41:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:41:07 --> Encryption Class Initialized
INFO - 2021-07-06 07:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:41:07 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:41:07 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:41:07 --> Model "user_model" initialized
INFO - 2021-07-06 07:41:07 --> Model "role_model" initialized
INFO - 2021-07-06 07:41:07 --> Controller Class Initialized
INFO - 2021-07-06 07:41:07 --> Helper loaded: language_helper
INFO - 2021-07-06 07:41:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:41:07 --> Model "Product_model" initialized
INFO - 2021-07-06 07:41:07 --> Final output sent to browser
DEBUG - 2021-07-06 07:41:07 --> Total execution time: 0.0743
INFO - 2021-07-06 07:41:23 --> Config Class Initialized
INFO - 2021-07-06 07:41:23 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:41:23 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:41:23 --> Utf8 Class Initialized
INFO - 2021-07-06 07:41:23 --> URI Class Initialized
INFO - 2021-07-06 07:41:23 --> Router Class Initialized
INFO - 2021-07-06 07:41:23 --> Output Class Initialized
INFO - 2021-07-06 07:41:23 --> Security Class Initialized
DEBUG - 2021-07-06 07:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:41:23 --> Input Class Initialized
INFO - 2021-07-06 07:41:23 --> Language Class Initialized
INFO - 2021-07-06 07:41:23 --> Loader Class Initialized
INFO - 2021-07-06 07:41:23 --> Helper loaded: html_helper
INFO - 2021-07-06 07:41:23 --> Helper loaded: url_helper
INFO - 2021-07-06 07:41:23 --> Helper loaded: form_helper
INFO - 2021-07-06 07:41:23 --> Database Driver Class Initialized
INFO - 2021-07-06 07:41:23 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:41:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:41:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:41:23 --> Encryption Class Initialized
INFO - 2021-07-06 07:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:41:23 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:41:23 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:41:23 --> Model "user_model" initialized
INFO - 2021-07-06 07:41:23 --> Model "role_model" initialized
INFO - 2021-07-06 07:41:23 --> Controller Class Initialized
INFO - 2021-07-06 07:41:23 --> Helper loaded: language_helper
INFO - 2021-07-06 07:41:23 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:41:23 --> Model "Quotation_model" initialized
INFO - 2021-07-06 07:41:23 --> Final output sent to browser
DEBUG - 2021-07-06 07:41:23 --> Total execution time: 0.1119
INFO - 2021-07-06 07:41:23 --> Config Class Initialized
INFO - 2021-07-06 07:41:23 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:41:23 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:41:23 --> Utf8 Class Initialized
INFO - 2021-07-06 07:41:23 --> URI Class Initialized
INFO - 2021-07-06 07:41:23 --> Router Class Initialized
INFO - 2021-07-06 07:41:23 --> Output Class Initialized
INFO - 2021-07-06 07:41:23 --> Security Class Initialized
DEBUG - 2021-07-06 07:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:41:23 --> Input Class Initialized
INFO - 2021-07-06 07:41:23 --> Language Class Initialized
INFO - 2021-07-06 07:41:23 --> Loader Class Initialized
INFO - 2021-07-06 07:41:23 --> Helper loaded: html_helper
INFO - 2021-07-06 07:41:23 --> Helper loaded: url_helper
INFO - 2021-07-06 07:41:23 --> Helper loaded: form_helper
INFO - 2021-07-06 07:41:23 --> Database Driver Class Initialized
INFO - 2021-07-06 07:41:23 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:41:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:41:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:41:23 --> Encryption Class Initialized
INFO - 2021-07-06 07:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:41:23 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:41:23 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:41:23 --> Model "user_model" initialized
INFO - 2021-07-06 07:41:23 --> Model "role_model" initialized
INFO - 2021-07-06 07:41:23 --> Controller Class Initialized
INFO - 2021-07-06 07:41:23 --> Helper loaded: language_helper
INFO - 2021-07-06 07:41:23 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:41:23 --> Model "Quotation_model" initialized
INFO - 2021-07-06 07:41:23 --> Final output sent to browser
DEBUG - 2021-07-06 07:41:23 --> Total execution time: 0.0756
INFO - 2021-07-06 07:41:24 --> Config Class Initialized
INFO - 2021-07-06 07:41:24 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:41:24 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:41:24 --> Utf8 Class Initialized
INFO - 2021-07-06 07:41:24 --> URI Class Initialized
INFO - 2021-07-06 07:41:24 --> Router Class Initialized
INFO - 2021-07-06 07:41:24 --> Output Class Initialized
INFO - 2021-07-06 07:41:24 --> Security Class Initialized
DEBUG - 2021-07-06 07:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:41:24 --> Input Class Initialized
INFO - 2021-07-06 07:41:24 --> Language Class Initialized
INFO - 2021-07-06 07:41:24 --> Loader Class Initialized
INFO - 2021-07-06 07:41:24 --> Helper loaded: html_helper
INFO - 2021-07-06 07:41:24 --> Helper loaded: url_helper
INFO - 2021-07-06 07:41:24 --> Helper loaded: form_helper
INFO - 2021-07-06 07:41:24 --> Database Driver Class Initialized
INFO - 2021-07-06 07:41:24 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:41:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:41:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:41:24 --> Encryption Class Initialized
INFO - 2021-07-06 07:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:41:24 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:41:24 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:41:24 --> Model "user_model" initialized
INFO - 2021-07-06 07:41:24 --> Model "role_model" initialized
INFO - 2021-07-06 07:41:24 --> Controller Class Initialized
INFO - 2021-07-06 07:41:24 --> Helper loaded: language_helper
INFO - 2021-07-06 07:41:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:41:24 --> Model "Quotation_model" initialized
INFO - 2021-07-06 07:41:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 07:41:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 07:41:24 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-06 07:41:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-06 07:41:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 07:41:24 --> Final output sent to browser
DEBUG - 2021-07-06 07:41:24 --> Total execution time: 0.0904
INFO - 2021-07-06 07:41:25 --> Config Class Initialized
INFO - 2021-07-06 07:41:25 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:41:25 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:41:25 --> Utf8 Class Initialized
INFO - 2021-07-06 07:41:25 --> URI Class Initialized
INFO - 2021-07-06 07:41:25 --> Router Class Initialized
INFO - 2021-07-06 07:41:25 --> Config Class Initialized
INFO - 2021-07-06 07:41:25 --> Hooks Class Initialized
INFO - 2021-07-06 07:41:25 --> Output Class Initialized
INFO - 2021-07-06 07:41:25 --> Security Class Initialized
DEBUG - 2021-07-06 07:41:25 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:41:25 --> Utf8 Class Initialized
DEBUG - 2021-07-06 07:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:41:25 --> URI Class Initialized
INFO - 2021-07-06 07:41:25 --> Input Class Initialized
INFO - 2021-07-06 07:41:25 --> Language Class Initialized
INFO - 2021-07-06 07:41:25 --> Router Class Initialized
INFO - 2021-07-06 07:41:25 --> Output Class Initialized
INFO - 2021-07-06 07:41:25 --> Loader Class Initialized
INFO - 2021-07-06 07:41:25 --> Security Class Initialized
INFO - 2021-07-06 07:41:25 --> Helper loaded: html_helper
DEBUG - 2021-07-06 07:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:41:25 --> Helper loaded: url_helper
INFO - 2021-07-06 07:41:25 --> Input Class Initialized
INFO - 2021-07-06 07:41:25 --> Language Class Initialized
INFO - 2021-07-06 07:41:25 --> Helper loaded: form_helper
INFO - 2021-07-06 07:41:25 --> Loader Class Initialized
INFO - 2021-07-06 07:41:25 --> Helper loaded: html_helper
INFO - 2021-07-06 07:41:25 --> Helper loaded: url_helper
INFO - 2021-07-06 07:41:25 --> Helper loaded: form_helper
INFO - 2021-07-06 07:41:25 --> Database Driver Class Initialized
INFO - 2021-07-06 07:41:25 --> Database Driver Class Initialized
INFO - 2021-07-06 07:41:25 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:41:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:41:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:41:25 --> Encryption Class Initialized
INFO - 2021-07-06 07:41:25 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:41:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:41:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:41:25 --> Encryption Class Initialized
INFO - 2021-07-06 07:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:41:25 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:41:25 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:41:25 --> Model "user_model" initialized
INFO - 2021-07-06 07:41:25 --> Model "role_model" initialized
INFO - 2021-07-06 07:41:25 --> Controller Class Initialized
INFO - 2021-07-06 07:41:25 --> Helper loaded: language_helper
INFO - 2021-07-06 07:41:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:41:25 --> Model "Quotation_model" initialized
INFO - 2021-07-06 07:41:25 --> Final output sent to browser
DEBUG - 2021-07-06 07:41:25 --> Total execution time: 0.1113
INFO - 2021-07-06 07:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:41:25 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:41:25 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:41:25 --> Model "user_model" initialized
INFO - 2021-07-06 07:41:25 --> Model "role_model" initialized
INFO - 2021-07-06 07:41:25 --> Controller Class Initialized
INFO - 2021-07-06 07:41:25 --> Helper loaded: language_helper
INFO - 2021-07-06 07:41:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:41:25 --> Model "Quotation_model" initialized
INFO - 2021-07-06 07:41:25 --> Final output sent to browser
DEBUG - 2021-07-06 07:41:25 --> Total execution time: 0.1143
INFO - 2021-07-06 07:44:40 --> Config Class Initialized
INFO - 2021-07-06 07:44:40 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:44:40 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:44:40 --> Utf8 Class Initialized
INFO - 2021-07-06 07:44:40 --> URI Class Initialized
DEBUG - 2021-07-06 07:44:40 --> No URI present. Default controller set.
INFO - 2021-07-06 07:44:40 --> Router Class Initialized
INFO - 2021-07-06 07:44:40 --> Output Class Initialized
INFO - 2021-07-06 07:44:40 --> Security Class Initialized
DEBUG - 2021-07-06 07:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:44:40 --> Input Class Initialized
INFO - 2021-07-06 07:44:40 --> Language Class Initialized
INFO - 2021-07-06 07:44:40 --> Loader Class Initialized
INFO - 2021-07-06 07:44:40 --> Helper loaded: html_helper
INFO - 2021-07-06 07:44:40 --> Helper loaded: url_helper
INFO - 2021-07-06 07:44:40 --> Helper loaded: form_helper
INFO - 2021-07-06 07:44:40 --> Database Driver Class Initialized
INFO - 2021-07-06 07:44:40 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:44:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:44:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:44:40 --> Encryption Class Initialized
INFO - 2021-07-06 07:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:44:40 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:44:40 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:44:40 --> Model "user_model" initialized
INFO - 2021-07-06 07:44:40 --> Model "role_model" initialized
INFO - 2021-07-06 07:44:40 --> Controller Class Initialized
INFO - 2021-07-06 07:44:40 --> Helper loaded: language_helper
INFO - 2021-07-06 07:44:40 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:44:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-06 07:44:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-06 07:44:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-06 07:44:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 07:44:40 --> Final output sent to browser
DEBUG - 2021-07-06 07:44:40 --> Total execution time: 0.0838
INFO - 2021-07-06 07:44:41 --> Config Class Initialized
INFO - 2021-07-06 07:44:41 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:44:41 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:44:41 --> Utf8 Class Initialized
INFO - 2021-07-06 07:44:41 --> URI Class Initialized
DEBUG - 2021-07-06 07:44:41 --> No URI present. Default controller set.
INFO - 2021-07-06 07:44:41 --> Router Class Initialized
INFO - 2021-07-06 07:44:41 --> Output Class Initialized
INFO - 2021-07-06 07:44:41 --> Security Class Initialized
DEBUG - 2021-07-06 07:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:44:41 --> Input Class Initialized
INFO - 2021-07-06 07:44:41 --> Language Class Initialized
INFO - 2021-07-06 07:44:41 --> Loader Class Initialized
INFO - 2021-07-06 07:44:41 --> Helper loaded: html_helper
INFO - 2021-07-06 07:44:41 --> Helper loaded: url_helper
INFO - 2021-07-06 07:44:41 --> Helper loaded: form_helper
INFO - 2021-07-06 07:44:41 --> Database Driver Class Initialized
INFO - 2021-07-06 07:44:41 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:44:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:44:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:44:41 --> Encryption Class Initialized
INFO - 2021-07-06 07:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:44:41 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:44:41 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:44:41 --> Model "user_model" initialized
INFO - 2021-07-06 07:44:41 --> Model "role_model" initialized
INFO - 2021-07-06 07:44:41 --> Controller Class Initialized
INFO - 2021-07-06 07:44:41 --> Helper loaded: language_helper
INFO - 2021-07-06 07:44:41 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:44:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-06 07:44:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-06 07:44:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-06 07:44:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 07:44:41 --> Final output sent to browser
DEBUG - 2021-07-06 07:44:41 --> Total execution time: 0.0749
INFO - 2021-07-06 07:44:47 --> Config Class Initialized
INFO - 2021-07-06 07:44:47 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:44:47 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:44:47 --> Utf8 Class Initialized
INFO - 2021-07-06 07:44:47 --> URI Class Initialized
INFO - 2021-07-06 07:44:47 --> Router Class Initialized
INFO - 2021-07-06 07:44:47 --> Output Class Initialized
INFO - 2021-07-06 07:44:47 --> Security Class Initialized
DEBUG - 2021-07-06 07:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:44:47 --> Input Class Initialized
INFO - 2021-07-06 07:44:47 --> Language Class Initialized
INFO - 2021-07-06 07:44:47 --> Loader Class Initialized
INFO - 2021-07-06 07:44:47 --> Helper loaded: html_helper
INFO - 2021-07-06 07:44:47 --> Helper loaded: url_helper
INFO - 2021-07-06 07:44:47 --> Helper loaded: form_helper
INFO - 2021-07-06 07:44:47 --> Database Driver Class Initialized
INFO - 2021-07-06 07:44:47 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:44:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:44:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:44:47 --> Encryption Class Initialized
INFO - 2021-07-06 07:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:44:47 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:44:47 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:44:47 --> Model "user_model" initialized
INFO - 2021-07-06 07:44:47 --> Model "role_model" initialized
INFO - 2021-07-06 07:44:47 --> Controller Class Initialized
INFO - 2021-07-06 07:44:47 --> Helper loaded: language_helper
INFO - 2021-07-06 07:44:47 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:44:47 --> Model "Customer_model" initialized
INFO - 2021-07-06 07:44:47 --> Model "Product_model" initialized
INFO - 2021-07-06 07:44:47 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 07:44:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 07:44:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 07:44:47 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-06 07:44:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 07:44:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 07:44:47 --> Final output sent to browser
DEBUG - 2021-07-06 07:44:47 --> Total execution time: 0.0723
INFO - 2021-07-06 07:45:05 --> Config Class Initialized
INFO - 2021-07-06 07:45:05 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:45:05 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:45:05 --> Utf8 Class Initialized
INFO - 2021-07-06 07:45:05 --> URI Class Initialized
INFO - 2021-07-06 07:45:05 --> Router Class Initialized
INFO - 2021-07-06 07:45:05 --> Output Class Initialized
INFO - 2021-07-06 07:45:05 --> Security Class Initialized
DEBUG - 2021-07-06 07:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:45:05 --> Input Class Initialized
INFO - 2021-07-06 07:45:05 --> Language Class Initialized
INFO - 2021-07-06 07:45:05 --> Loader Class Initialized
INFO - 2021-07-06 07:45:05 --> Helper loaded: html_helper
INFO - 2021-07-06 07:45:05 --> Helper loaded: url_helper
INFO - 2021-07-06 07:45:05 --> Helper loaded: form_helper
INFO - 2021-07-06 07:45:05 --> Database Driver Class Initialized
INFO - 2021-07-06 07:45:05 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:45:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:45:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:45:05 --> Encryption Class Initialized
INFO - 2021-07-06 07:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:45:05 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:45:05 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:45:05 --> Model "user_model" initialized
INFO - 2021-07-06 07:45:05 --> Model "role_model" initialized
INFO - 2021-07-06 07:45:05 --> Controller Class Initialized
INFO - 2021-07-06 07:45:05 --> Helper loaded: language_helper
INFO - 2021-07-06 07:45:05 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:45:05 --> Model "Customer_model" initialized
INFO - 2021-07-06 07:45:05 --> Final output sent to browser
DEBUG - 2021-07-06 07:45:05 --> Total execution time: 0.0762
INFO - 2021-07-06 07:45:09 --> Config Class Initialized
INFO - 2021-07-06 07:45:09 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:45:09 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:45:09 --> Utf8 Class Initialized
INFO - 2021-07-06 07:45:09 --> URI Class Initialized
INFO - 2021-07-06 07:45:09 --> Router Class Initialized
INFO - 2021-07-06 07:45:09 --> Output Class Initialized
INFO - 2021-07-06 07:45:09 --> Security Class Initialized
DEBUG - 2021-07-06 07:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:45:09 --> Input Class Initialized
INFO - 2021-07-06 07:45:09 --> Language Class Initialized
INFO - 2021-07-06 07:45:09 --> Loader Class Initialized
INFO - 2021-07-06 07:45:09 --> Helper loaded: html_helper
INFO - 2021-07-06 07:45:09 --> Helper loaded: url_helper
INFO - 2021-07-06 07:45:09 --> Helper loaded: form_helper
INFO - 2021-07-06 07:45:09 --> Database Driver Class Initialized
INFO - 2021-07-06 07:45:09 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:45:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:45:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:45:09 --> Encryption Class Initialized
INFO - 2021-07-06 07:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:45:09 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:45:09 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:45:09 --> Model "user_model" initialized
INFO - 2021-07-06 07:45:09 --> Model "role_model" initialized
INFO - 2021-07-06 07:45:09 --> Controller Class Initialized
INFO - 2021-07-06 07:45:09 --> Helper loaded: language_helper
INFO - 2021-07-06 07:45:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:45:09 --> Model "Customer_model" initialized
INFO - 2021-07-06 07:45:09 --> Final output sent to browser
DEBUG - 2021-07-06 07:45:09 --> Total execution time: 0.0643
INFO - 2021-07-06 07:45:48 --> Config Class Initialized
INFO - 2021-07-06 07:45:48 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:45:48 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:45:48 --> Utf8 Class Initialized
INFO - 2021-07-06 07:45:48 --> URI Class Initialized
INFO - 2021-07-06 07:45:48 --> Router Class Initialized
INFO - 2021-07-06 07:45:48 --> Output Class Initialized
INFO - 2021-07-06 07:45:48 --> Security Class Initialized
DEBUG - 2021-07-06 07:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:45:48 --> Input Class Initialized
INFO - 2021-07-06 07:45:48 --> Language Class Initialized
INFO - 2021-07-06 07:45:48 --> Loader Class Initialized
INFO - 2021-07-06 07:45:48 --> Helper loaded: html_helper
INFO - 2021-07-06 07:45:48 --> Helper loaded: url_helper
INFO - 2021-07-06 07:45:48 --> Helper loaded: form_helper
INFO - 2021-07-06 07:45:48 --> Database Driver Class Initialized
INFO - 2021-07-06 07:45:48 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:45:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:45:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:45:48 --> Encryption Class Initialized
INFO - 2021-07-06 07:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:45:48 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:45:48 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:45:48 --> Model "user_model" initialized
INFO - 2021-07-06 07:45:48 --> Model "role_model" initialized
INFO - 2021-07-06 07:45:48 --> Controller Class Initialized
INFO - 2021-07-06 07:45:48 --> Helper loaded: language_helper
INFO - 2021-07-06 07:45:48 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:45:48 --> Model "Product_model" initialized
INFO - 2021-07-06 07:45:48 --> Final output sent to browser
DEBUG - 2021-07-06 07:45:48 --> Total execution time: 0.0714
INFO - 2021-07-06 07:45:54 --> Config Class Initialized
INFO - 2021-07-06 07:45:54 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:45:54 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:45:54 --> Utf8 Class Initialized
INFO - 2021-07-06 07:45:54 --> URI Class Initialized
INFO - 2021-07-06 07:45:54 --> Router Class Initialized
INFO - 2021-07-06 07:45:54 --> Output Class Initialized
INFO - 2021-07-06 07:45:54 --> Security Class Initialized
DEBUG - 2021-07-06 07:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:45:54 --> Input Class Initialized
INFO - 2021-07-06 07:45:54 --> Language Class Initialized
INFO - 2021-07-06 07:45:54 --> Loader Class Initialized
INFO - 2021-07-06 07:45:54 --> Helper loaded: html_helper
INFO - 2021-07-06 07:45:54 --> Helper loaded: url_helper
INFO - 2021-07-06 07:45:54 --> Helper loaded: form_helper
INFO - 2021-07-06 07:45:54 --> Database Driver Class Initialized
INFO - 2021-07-06 07:45:54 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:45:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:45:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:45:54 --> Encryption Class Initialized
INFO - 2021-07-06 07:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:45:54 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:45:54 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:45:54 --> Model "user_model" initialized
INFO - 2021-07-06 07:45:54 --> Model "role_model" initialized
INFO - 2021-07-06 07:45:54 --> Controller Class Initialized
INFO - 2021-07-06 07:45:54 --> Helper loaded: language_helper
INFO - 2021-07-06 07:45:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:45:54 --> Model "Product_model" initialized
INFO - 2021-07-06 07:45:54 --> Final output sent to browser
DEBUG - 2021-07-06 07:45:54 --> Total execution time: 0.0592
INFO - 2021-07-06 07:46:04 --> Config Class Initialized
INFO - 2021-07-06 07:46:04 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:46:04 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:46:04 --> Utf8 Class Initialized
INFO - 2021-07-06 07:46:04 --> URI Class Initialized
INFO - 2021-07-06 07:46:04 --> Router Class Initialized
INFO - 2021-07-06 07:46:04 --> Output Class Initialized
INFO - 2021-07-06 07:46:04 --> Security Class Initialized
DEBUG - 2021-07-06 07:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:46:04 --> Input Class Initialized
INFO - 2021-07-06 07:46:04 --> Language Class Initialized
INFO - 2021-07-06 07:46:04 --> Loader Class Initialized
INFO - 2021-07-06 07:46:04 --> Helper loaded: html_helper
INFO - 2021-07-06 07:46:04 --> Helper loaded: url_helper
INFO - 2021-07-06 07:46:04 --> Helper loaded: form_helper
INFO - 2021-07-06 07:46:04 --> Database Driver Class Initialized
INFO - 2021-07-06 07:46:04 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:46:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:46:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:46:04 --> Encryption Class Initialized
INFO - 2021-07-06 07:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:46:04 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:46:04 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:46:04 --> Model "user_model" initialized
INFO - 2021-07-06 07:46:04 --> Model "role_model" initialized
INFO - 2021-07-06 07:46:04 --> Controller Class Initialized
INFO - 2021-07-06 07:46:04 --> Helper loaded: language_helper
INFO - 2021-07-06 07:46:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:46:04 --> Model "Quotation_model" initialized
INFO - 2021-07-06 07:46:04 --> Final output sent to browser
DEBUG - 2021-07-06 07:46:04 --> Total execution time: 0.0691
INFO - 2021-07-06 07:46:05 --> Config Class Initialized
INFO - 2021-07-06 07:46:05 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:46:05 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:46:05 --> Utf8 Class Initialized
INFO - 2021-07-06 07:46:05 --> URI Class Initialized
INFO - 2021-07-06 07:46:05 --> Router Class Initialized
INFO - 2021-07-06 07:46:05 --> Output Class Initialized
INFO - 2021-07-06 07:46:05 --> Security Class Initialized
DEBUG - 2021-07-06 07:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:46:05 --> Input Class Initialized
INFO - 2021-07-06 07:46:05 --> Language Class Initialized
INFO - 2021-07-06 07:46:05 --> Loader Class Initialized
INFO - 2021-07-06 07:46:05 --> Helper loaded: html_helper
INFO - 2021-07-06 07:46:05 --> Helper loaded: url_helper
INFO - 2021-07-06 07:46:05 --> Helper loaded: form_helper
INFO - 2021-07-06 07:46:05 --> Database Driver Class Initialized
INFO - 2021-07-06 07:46:05 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:46:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:46:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:46:05 --> Encryption Class Initialized
INFO - 2021-07-06 07:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:46:05 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:46:05 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:46:05 --> Model "user_model" initialized
INFO - 2021-07-06 07:46:05 --> Model "role_model" initialized
INFO - 2021-07-06 07:46:05 --> Controller Class Initialized
INFO - 2021-07-06 07:46:05 --> Helper loaded: language_helper
INFO - 2021-07-06 07:46:05 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:46:05 --> Model "Quotation_model" initialized
INFO - 2021-07-06 07:46:05 --> Final output sent to browser
DEBUG - 2021-07-06 07:46:05 --> Total execution time: 0.0755
INFO - 2021-07-06 07:46:06 --> Config Class Initialized
INFO - 2021-07-06 07:46:06 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:46:06 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:46:06 --> Utf8 Class Initialized
INFO - 2021-07-06 07:46:06 --> URI Class Initialized
INFO - 2021-07-06 07:46:06 --> Router Class Initialized
INFO - 2021-07-06 07:46:06 --> Output Class Initialized
INFO - 2021-07-06 07:46:06 --> Security Class Initialized
DEBUG - 2021-07-06 07:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:46:06 --> Input Class Initialized
INFO - 2021-07-06 07:46:06 --> Language Class Initialized
INFO - 2021-07-06 07:46:06 --> Loader Class Initialized
INFO - 2021-07-06 07:46:06 --> Helper loaded: html_helper
INFO - 2021-07-06 07:46:06 --> Helper loaded: url_helper
INFO - 2021-07-06 07:46:06 --> Helper loaded: form_helper
INFO - 2021-07-06 07:46:06 --> Database Driver Class Initialized
INFO - 2021-07-06 07:46:06 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:46:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:46:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:46:06 --> Encryption Class Initialized
INFO - 2021-07-06 07:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:46:06 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:46:06 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:46:06 --> Model "user_model" initialized
INFO - 2021-07-06 07:46:06 --> Model "role_model" initialized
INFO - 2021-07-06 07:46:06 --> Controller Class Initialized
INFO - 2021-07-06 07:46:06 --> Helper loaded: language_helper
INFO - 2021-07-06 07:46:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:46:06 --> Model "Quotation_model" initialized
INFO - 2021-07-06 07:46:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 07:46:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 07:46:06 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-06 07:46:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-06 07:46:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 07:46:06 --> Final output sent to browser
DEBUG - 2021-07-06 07:46:06 --> Total execution time: 0.0728
INFO - 2021-07-06 07:46:06 --> Config Class Initialized
INFO - 2021-07-06 07:46:06 --> Hooks Class Initialized
INFO - 2021-07-06 07:46:06 --> Config Class Initialized
INFO - 2021-07-06 07:46:06 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:46:06 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:46:06 --> Utf8 Class Initialized
DEBUG - 2021-07-06 07:46:06 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:46:06 --> Utf8 Class Initialized
INFO - 2021-07-06 07:46:06 --> URI Class Initialized
INFO - 2021-07-06 07:46:06 --> URI Class Initialized
INFO - 2021-07-06 07:46:06 --> Router Class Initialized
INFO - 2021-07-06 07:46:06 --> Router Class Initialized
INFO - 2021-07-06 07:46:06 --> Output Class Initialized
INFO - 2021-07-06 07:46:06 --> Output Class Initialized
INFO - 2021-07-06 07:46:06 --> Security Class Initialized
INFO - 2021-07-06 07:46:06 --> Security Class Initialized
DEBUG - 2021-07-06 07:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:46:06 --> Input Class Initialized
DEBUG - 2021-07-06 07:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:46:06 --> Input Class Initialized
INFO - 2021-07-06 07:46:06 --> Language Class Initialized
INFO - 2021-07-06 07:46:06 --> Language Class Initialized
INFO - 2021-07-06 07:46:06 --> Loader Class Initialized
INFO - 2021-07-06 07:46:06 --> Loader Class Initialized
INFO - 2021-07-06 07:46:06 --> Helper loaded: html_helper
INFO - 2021-07-06 07:46:06 --> Helper loaded: html_helper
INFO - 2021-07-06 07:46:06 --> Helper loaded: url_helper
INFO - 2021-07-06 07:46:06 --> Helper loaded: url_helper
INFO - 2021-07-06 07:46:06 --> Helper loaded: form_helper
INFO - 2021-07-06 07:46:06 --> Helper loaded: form_helper
INFO - 2021-07-06 07:46:06 --> Database Driver Class Initialized
INFO - 2021-07-06 07:46:06 --> Database Driver Class Initialized
INFO - 2021-07-06 07:46:06 --> Form Validation Class Initialized
INFO - 2021-07-06 07:46:06 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:46:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:46:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:46:06 --> Encryption Class Initialized
DEBUG - 2021-07-06 07:46:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:46:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:46:06 --> Encryption Class Initialized
INFO - 2021-07-06 07:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:46:06 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:46:06 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:46:06 --> Model "user_model" initialized
INFO - 2021-07-06 07:46:06 --> Model "role_model" initialized
INFO - 2021-07-06 07:46:06 --> Controller Class Initialized
INFO - 2021-07-06 07:46:06 --> Helper loaded: language_helper
INFO - 2021-07-06 07:46:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:46:07 --> Model "Quotation_model" initialized
INFO - 2021-07-06 07:46:07 --> Final output sent to browser
DEBUG - 2021-07-06 07:46:07 --> Total execution time: 0.0773
INFO - 2021-07-06 07:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:46:07 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:46:07 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:46:07 --> Model "user_model" initialized
INFO - 2021-07-06 07:46:07 --> Model "role_model" initialized
INFO - 2021-07-06 07:46:07 --> Controller Class Initialized
INFO - 2021-07-06 07:46:07 --> Helper loaded: language_helper
INFO - 2021-07-06 07:46:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:46:07 --> Model "Quotation_model" initialized
INFO - 2021-07-06 07:46:07 --> Final output sent to browser
DEBUG - 2021-07-06 07:46:07 --> Total execution time: 0.0900
INFO - 2021-07-06 07:49:06 --> Config Class Initialized
INFO - 2021-07-06 07:49:06 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:49:06 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:49:06 --> Utf8 Class Initialized
INFO - 2021-07-06 07:49:06 --> URI Class Initialized
INFO - 2021-07-06 07:49:06 --> Router Class Initialized
INFO - 2021-07-06 07:49:06 --> Output Class Initialized
INFO - 2021-07-06 07:49:06 --> Security Class Initialized
DEBUG - 2021-07-06 07:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:49:06 --> Input Class Initialized
INFO - 2021-07-06 07:49:06 --> Language Class Initialized
INFO - 2021-07-06 07:49:06 --> Loader Class Initialized
INFO - 2021-07-06 07:49:06 --> Helper loaded: html_helper
INFO - 2021-07-06 07:49:06 --> Helper loaded: url_helper
INFO - 2021-07-06 07:49:06 --> Helper loaded: form_helper
INFO - 2021-07-06 07:49:06 --> Database Driver Class Initialized
INFO - 2021-07-06 07:49:06 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:49:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:49:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:49:06 --> Encryption Class Initialized
INFO - 2021-07-06 07:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:49:06 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:49:06 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:49:06 --> Model "user_model" initialized
INFO - 2021-07-06 07:49:06 --> Model "role_model" initialized
INFO - 2021-07-06 07:49:06 --> Controller Class Initialized
INFO - 2021-07-06 07:49:06 --> Helper loaded: language_helper
INFO - 2021-07-06 07:49:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:49:06 --> Model "Quotation_model" initialized
INFO - 2021-07-06 07:49:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 07:49:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 07:49:06 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-06 07:49:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-06 07:49:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 07:49:06 --> Final output sent to browser
DEBUG - 2021-07-06 07:49:06 --> Total execution time: 0.1383
INFO - 2021-07-06 07:49:08 --> Config Class Initialized
INFO - 2021-07-06 07:49:08 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:49:08 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:49:08 --> Utf8 Class Initialized
INFO - 2021-07-06 07:49:08 --> URI Class Initialized
INFO - 2021-07-06 07:49:08 --> Router Class Initialized
INFO - 2021-07-06 07:49:08 --> Output Class Initialized
INFO - 2021-07-06 07:49:08 --> Security Class Initialized
DEBUG - 2021-07-06 07:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:49:08 --> Input Class Initialized
INFO - 2021-07-06 07:49:08 --> Language Class Initialized
INFO - 2021-07-06 07:49:08 --> Loader Class Initialized
INFO - 2021-07-06 07:49:08 --> Helper loaded: html_helper
INFO - 2021-07-06 07:49:08 --> Helper loaded: url_helper
INFO - 2021-07-06 07:49:08 --> Helper loaded: form_helper
INFO - 2021-07-06 07:49:08 --> Config Class Initialized
INFO - 2021-07-06 07:49:08 --> Database Driver Class Initialized
INFO - 2021-07-06 07:49:08 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:49:08 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:49:08 --> Utf8 Class Initialized
INFO - 2021-07-06 07:49:08 --> URI Class Initialized
INFO - 2021-07-06 07:49:08 --> Router Class Initialized
INFO - 2021-07-06 07:49:08 --> Output Class Initialized
INFO - 2021-07-06 07:49:08 --> Security Class Initialized
DEBUG - 2021-07-06 07:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:49:08 --> Input Class Initialized
INFO - 2021-07-06 07:49:08 --> Language Class Initialized
INFO - 2021-07-06 07:49:08 --> Loader Class Initialized
INFO - 2021-07-06 07:49:08 --> Helper loaded: html_helper
INFO - 2021-07-06 07:49:08 --> Helper loaded: url_helper
INFO - 2021-07-06 07:49:08 --> Helper loaded: form_helper
INFO - 2021-07-06 07:49:08 --> Form Validation Class Initialized
INFO - 2021-07-06 07:49:08 --> Database Driver Class Initialized
DEBUG - 2021-07-06 07:49:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:49:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:49:08 --> Encryption Class Initialized
INFO - 2021-07-06 07:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:49:08 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:49:08 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:49:08 --> Model "user_model" initialized
INFO - 2021-07-06 07:49:08 --> Model "role_model" initialized
INFO - 2021-07-06 07:49:08 --> Controller Class Initialized
INFO - 2021-07-06 07:49:08 --> Helper loaded: language_helper
INFO - 2021-07-06 07:49:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:49:08 --> Model "Quotation_model" initialized
INFO - 2021-07-06 07:49:08 --> Final output sent to browser
DEBUG - 2021-07-06 07:49:08 --> Total execution time: 0.1145
INFO - 2021-07-06 07:49:08 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:49:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:49:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:49:08 --> Encryption Class Initialized
INFO - 2021-07-06 07:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:49:08 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:49:08 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:49:08 --> Model "user_model" initialized
INFO - 2021-07-06 07:49:08 --> Model "role_model" initialized
INFO - 2021-07-06 07:49:08 --> Controller Class Initialized
INFO - 2021-07-06 07:49:08 --> Helper loaded: language_helper
INFO - 2021-07-06 07:49:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:49:08 --> Model "Quotation_model" initialized
INFO - 2021-07-06 07:49:08 --> Final output sent to browser
DEBUG - 2021-07-06 07:49:08 --> Total execution time: 0.1346
INFO - 2021-07-06 07:50:54 --> Config Class Initialized
INFO - 2021-07-06 07:50:54 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:50:54 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:50:54 --> Utf8 Class Initialized
INFO - 2021-07-06 07:50:54 --> URI Class Initialized
DEBUG - 2021-07-06 07:50:54 --> No URI present. Default controller set.
INFO - 2021-07-06 07:50:54 --> Router Class Initialized
INFO - 2021-07-06 07:50:54 --> Output Class Initialized
INFO - 2021-07-06 07:50:54 --> Security Class Initialized
DEBUG - 2021-07-06 07:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:50:54 --> Input Class Initialized
INFO - 2021-07-06 07:50:54 --> Language Class Initialized
INFO - 2021-07-06 07:50:54 --> Loader Class Initialized
INFO - 2021-07-06 07:50:54 --> Helper loaded: html_helper
INFO - 2021-07-06 07:50:54 --> Helper loaded: url_helper
INFO - 2021-07-06 07:50:54 --> Helper loaded: form_helper
INFO - 2021-07-06 07:50:54 --> Database Driver Class Initialized
INFO - 2021-07-06 07:50:54 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:50:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:50:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:50:54 --> Encryption Class Initialized
INFO - 2021-07-06 07:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:50:54 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:50:54 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:50:54 --> Model "user_model" initialized
INFO - 2021-07-06 07:50:54 --> Model "role_model" initialized
INFO - 2021-07-06 07:50:54 --> Controller Class Initialized
INFO - 2021-07-06 07:50:54 --> Helper loaded: language_helper
INFO - 2021-07-06 07:50:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:50:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-06 07:50:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-06 07:50:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-06 07:50:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 07:50:54 --> Final output sent to browser
DEBUG - 2021-07-06 07:50:54 --> Total execution time: 0.0719
INFO - 2021-07-06 07:57:20 --> Config Class Initialized
INFO - 2021-07-06 07:57:20 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:57:20 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:57:20 --> Utf8 Class Initialized
INFO - 2021-07-06 07:57:20 --> URI Class Initialized
DEBUG - 2021-07-06 07:57:20 --> No URI present. Default controller set.
INFO - 2021-07-06 07:57:20 --> Router Class Initialized
INFO - 2021-07-06 07:57:20 --> Output Class Initialized
INFO - 2021-07-06 07:57:20 --> Security Class Initialized
DEBUG - 2021-07-06 07:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:57:20 --> Input Class Initialized
INFO - 2021-07-06 07:57:20 --> Language Class Initialized
INFO - 2021-07-06 07:57:20 --> Loader Class Initialized
INFO - 2021-07-06 07:57:20 --> Helper loaded: html_helper
INFO - 2021-07-06 07:57:20 --> Helper loaded: url_helper
INFO - 2021-07-06 07:57:20 --> Helper loaded: form_helper
INFO - 2021-07-06 07:57:20 --> Database Driver Class Initialized
INFO - 2021-07-06 07:57:20 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:57:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:57:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:57:20 --> Encryption Class Initialized
INFO - 2021-07-06 07:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:57:20 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:57:20 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:57:20 --> Model "user_model" initialized
INFO - 2021-07-06 07:57:20 --> Model "role_model" initialized
INFO - 2021-07-06 07:57:20 --> Controller Class Initialized
INFO - 2021-07-06 07:57:20 --> Helper loaded: language_helper
INFO - 2021-07-06 07:57:20 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:57:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-06 07:57:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-06 07:57:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-06 07:57:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 07:57:20 --> Final output sent to browser
DEBUG - 2021-07-06 07:57:20 --> Total execution time: 0.0772
INFO - 2021-07-06 07:57:21 --> Config Class Initialized
INFO - 2021-07-06 07:57:21 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:57:21 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:57:21 --> Utf8 Class Initialized
INFO - 2021-07-06 07:57:21 --> URI Class Initialized
DEBUG - 2021-07-06 07:57:21 --> No URI present. Default controller set.
INFO - 2021-07-06 07:57:21 --> Router Class Initialized
INFO - 2021-07-06 07:57:21 --> Output Class Initialized
INFO - 2021-07-06 07:57:21 --> Security Class Initialized
DEBUG - 2021-07-06 07:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:57:21 --> Input Class Initialized
INFO - 2021-07-06 07:57:21 --> Language Class Initialized
INFO - 2021-07-06 07:57:21 --> Loader Class Initialized
INFO - 2021-07-06 07:57:21 --> Helper loaded: html_helper
INFO - 2021-07-06 07:57:21 --> Helper loaded: url_helper
INFO - 2021-07-06 07:57:21 --> Helper loaded: form_helper
INFO - 2021-07-06 07:57:21 --> Database Driver Class Initialized
INFO - 2021-07-06 07:57:21 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:57:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:57:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:57:21 --> Encryption Class Initialized
INFO - 2021-07-06 07:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:57:21 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:57:21 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:57:21 --> Model "user_model" initialized
INFO - 2021-07-06 07:57:21 --> Model "role_model" initialized
INFO - 2021-07-06 07:57:21 --> Controller Class Initialized
INFO - 2021-07-06 07:57:21 --> Helper loaded: language_helper
INFO - 2021-07-06 07:57:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:57:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-06 07:57:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-06 07:57:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-06 07:57:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 07:57:21 --> Final output sent to browser
DEBUG - 2021-07-06 07:57:21 --> Total execution time: 0.0727
INFO - 2021-07-06 07:57:25 --> Config Class Initialized
INFO - 2021-07-06 07:57:25 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:57:25 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:57:25 --> Utf8 Class Initialized
INFO - 2021-07-06 07:57:25 --> URI Class Initialized
INFO - 2021-07-06 07:57:25 --> Router Class Initialized
INFO - 2021-07-06 07:57:25 --> Output Class Initialized
INFO - 2021-07-06 07:57:25 --> Security Class Initialized
DEBUG - 2021-07-06 07:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:57:25 --> Input Class Initialized
INFO - 2021-07-06 07:57:25 --> Language Class Initialized
INFO - 2021-07-06 07:57:25 --> Loader Class Initialized
INFO - 2021-07-06 07:57:25 --> Helper loaded: html_helper
INFO - 2021-07-06 07:57:25 --> Helper loaded: url_helper
INFO - 2021-07-06 07:57:25 --> Helper loaded: form_helper
INFO - 2021-07-06 07:57:25 --> Database Driver Class Initialized
INFO - 2021-07-06 07:57:25 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:57:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:57:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:57:25 --> Encryption Class Initialized
INFO - 2021-07-06 07:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:57:25 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:57:25 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:57:25 --> Model "user_model" initialized
INFO - 2021-07-06 07:57:25 --> Model "role_model" initialized
INFO - 2021-07-06 07:57:25 --> Controller Class Initialized
INFO - 2021-07-06 07:57:25 --> Helper loaded: language_helper
INFO - 2021-07-06 07:57:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:57:25 --> Model "Customer_model" initialized
INFO - 2021-07-06 07:57:25 --> Model "Product_model" initialized
INFO - 2021-07-06 07:57:25 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 07:57:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 07:57:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 07:57:25 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-06 07:57:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 07:57:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 07:57:25 --> Final output sent to browser
DEBUG - 2021-07-06 07:57:25 --> Total execution time: 0.0707
INFO - 2021-07-06 07:57:28 --> Config Class Initialized
INFO - 2021-07-06 07:57:28 --> Hooks Class Initialized
DEBUG - 2021-07-06 07:57:28 --> UTF-8 Support Enabled
INFO - 2021-07-06 07:57:28 --> Utf8 Class Initialized
INFO - 2021-07-06 07:57:28 --> URI Class Initialized
INFO - 2021-07-06 07:57:28 --> Router Class Initialized
INFO - 2021-07-06 07:57:28 --> Output Class Initialized
INFO - 2021-07-06 07:57:28 --> Security Class Initialized
DEBUG - 2021-07-06 07:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 07:57:28 --> Input Class Initialized
INFO - 2021-07-06 07:57:28 --> Language Class Initialized
INFO - 2021-07-06 07:57:28 --> Loader Class Initialized
INFO - 2021-07-06 07:57:28 --> Helper loaded: html_helper
INFO - 2021-07-06 07:57:28 --> Helper loaded: url_helper
INFO - 2021-07-06 07:57:28 --> Helper loaded: form_helper
INFO - 2021-07-06 07:57:28 --> Database Driver Class Initialized
INFO - 2021-07-06 07:57:28 --> Form Validation Class Initialized
DEBUG - 2021-07-06 07:57:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 07:57:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 07:57:28 --> Encryption Class Initialized
INFO - 2021-07-06 07:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 07:57:28 --> Model "vendor_model" initialized
INFO - 2021-07-06 07:57:28 --> Model "coupon_model" initialized
INFO - 2021-07-06 07:57:28 --> Model "user_model" initialized
INFO - 2021-07-06 07:57:28 --> Model "role_model" initialized
INFO - 2021-07-06 07:57:28 --> Controller Class Initialized
INFO - 2021-07-06 07:57:28 --> Helper loaded: language_helper
INFO - 2021-07-06 07:57:28 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 07:57:28 --> Model "Customer_model" initialized
INFO - 2021-07-06 07:57:28 --> Model "Product_model" initialized
INFO - 2021-07-06 07:57:28 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 07:57:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 07:57:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 07:57:28 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-06 07:57:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 07:57:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 07:57:28 --> Final output sent to browser
DEBUG - 2021-07-06 07:57:28 --> Total execution time: 0.0674
INFO - 2021-07-06 08:21:21 --> Config Class Initialized
INFO - 2021-07-06 08:21:21 --> Hooks Class Initialized
DEBUG - 2021-07-06 08:21:21 --> UTF-8 Support Enabled
INFO - 2021-07-06 08:21:21 --> Utf8 Class Initialized
INFO - 2021-07-06 08:21:21 --> URI Class Initialized
DEBUG - 2021-07-06 08:21:21 --> No URI present. Default controller set.
INFO - 2021-07-06 08:21:21 --> Router Class Initialized
INFO - 2021-07-06 08:21:21 --> Output Class Initialized
INFO - 2021-07-06 08:21:21 --> Security Class Initialized
DEBUG - 2021-07-06 08:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 08:21:21 --> Input Class Initialized
INFO - 2021-07-06 08:21:21 --> Language Class Initialized
INFO - 2021-07-06 08:21:21 --> Loader Class Initialized
INFO - 2021-07-06 08:21:21 --> Helper loaded: html_helper
INFO - 2021-07-06 08:21:21 --> Helper loaded: url_helper
INFO - 2021-07-06 08:21:21 --> Helper loaded: form_helper
INFO - 2021-07-06 08:21:21 --> Database Driver Class Initialized
INFO - 2021-07-06 08:21:21 --> Form Validation Class Initialized
DEBUG - 2021-07-06 08:21:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 08:21:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 08:21:21 --> Encryption Class Initialized
INFO - 2021-07-06 08:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 08:21:21 --> Model "vendor_model" initialized
INFO - 2021-07-06 08:21:21 --> Model "coupon_model" initialized
INFO - 2021-07-06 08:21:21 --> Model "user_model" initialized
INFO - 2021-07-06 08:21:21 --> Model "role_model" initialized
INFO - 2021-07-06 08:21:21 --> Controller Class Initialized
INFO - 2021-07-06 08:21:21 --> Helper loaded: language_helper
INFO - 2021-07-06 08:21:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 08:21:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\login.php
INFO - 2021-07-06 08:21:21 --> Final output sent to browser
DEBUG - 2021-07-06 08:21:21 --> Total execution time: 0.4354
INFO - 2021-07-06 08:21:22 --> Config Class Initialized
INFO - 2021-07-06 08:21:22 --> Hooks Class Initialized
DEBUG - 2021-07-06 08:21:22 --> UTF-8 Support Enabled
INFO - 2021-07-06 08:21:22 --> Utf8 Class Initialized
INFO - 2021-07-06 08:21:22 --> URI Class Initialized
DEBUG - 2021-07-06 08:21:22 --> No URI present. Default controller set.
INFO - 2021-07-06 08:21:22 --> Router Class Initialized
INFO - 2021-07-06 08:21:22 --> Output Class Initialized
INFO - 2021-07-06 08:21:22 --> Security Class Initialized
DEBUG - 2021-07-06 08:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 08:21:22 --> Input Class Initialized
INFO - 2021-07-06 08:21:22 --> Language Class Initialized
INFO - 2021-07-06 08:21:22 --> Loader Class Initialized
INFO - 2021-07-06 08:21:22 --> Helper loaded: html_helper
INFO - 2021-07-06 08:21:22 --> Helper loaded: url_helper
INFO - 2021-07-06 08:21:22 --> Helper loaded: form_helper
INFO - 2021-07-06 08:21:22 --> Database Driver Class Initialized
INFO - 2021-07-06 08:21:22 --> Form Validation Class Initialized
DEBUG - 2021-07-06 08:21:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 08:21:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 08:21:22 --> Encryption Class Initialized
INFO - 2021-07-06 08:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 08:21:22 --> Model "vendor_model" initialized
INFO - 2021-07-06 08:21:22 --> Model "coupon_model" initialized
INFO - 2021-07-06 08:21:22 --> Model "user_model" initialized
INFO - 2021-07-06 08:21:22 --> Model "role_model" initialized
INFO - 2021-07-06 08:21:22 --> Controller Class Initialized
INFO - 2021-07-06 08:21:22 --> Helper loaded: language_helper
INFO - 2021-07-06 08:21:22 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 08:21:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\login.php
INFO - 2021-07-06 08:21:22 --> Final output sent to browser
DEBUG - 2021-07-06 08:21:22 --> Total execution time: 0.0743
INFO - 2021-07-06 08:21:30 --> Config Class Initialized
INFO - 2021-07-06 08:21:30 --> Hooks Class Initialized
DEBUG - 2021-07-06 08:21:30 --> UTF-8 Support Enabled
INFO - 2021-07-06 08:21:30 --> Utf8 Class Initialized
INFO - 2021-07-06 08:21:30 --> URI Class Initialized
INFO - 2021-07-06 08:21:30 --> Router Class Initialized
INFO - 2021-07-06 08:21:30 --> Output Class Initialized
INFO - 2021-07-06 08:21:30 --> Security Class Initialized
DEBUG - 2021-07-06 08:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 08:21:30 --> Input Class Initialized
INFO - 2021-07-06 08:21:30 --> Language Class Initialized
INFO - 2021-07-06 08:21:30 --> Loader Class Initialized
INFO - 2021-07-06 08:21:30 --> Helper loaded: html_helper
INFO - 2021-07-06 08:21:30 --> Helper loaded: url_helper
INFO - 2021-07-06 08:21:30 --> Helper loaded: form_helper
INFO - 2021-07-06 08:21:30 --> Database Driver Class Initialized
INFO - 2021-07-06 08:21:30 --> Form Validation Class Initialized
DEBUG - 2021-07-06 08:21:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 08:21:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 08:21:30 --> Encryption Class Initialized
INFO - 2021-07-06 08:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 08:21:30 --> Model "vendor_model" initialized
INFO - 2021-07-06 08:21:30 --> Model "coupon_model" initialized
INFO - 2021-07-06 08:21:30 --> Model "user_model" initialized
INFO - 2021-07-06 08:21:30 --> Model "role_model" initialized
INFO - 2021-07-06 08:21:30 --> Controller Class Initialized
INFO - 2021-07-06 08:21:30 --> Helper loaded: language_helper
INFO - 2021-07-06 08:21:30 --> Language file loaded: language/english/content_lang.php
DEBUG - 2021-07-06 08:21:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-06 08:21:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-07-06 08:21:30 --> Model "User" initialized
INFO - 2021-07-06 08:21:30 --> Config Class Initialized
INFO - 2021-07-06 08:21:30 --> Hooks Class Initialized
DEBUG - 2021-07-06 08:21:30 --> UTF-8 Support Enabled
INFO - 2021-07-06 08:21:30 --> Utf8 Class Initialized
INFO - 2021-07-06 08:21:30 --> URI Class Initialized
INFO - 2021-07-06 08:21:30 --> Router Class Initialized
INFO - 2021-07-06 08:21:30 --> Output Class Initialized
INFO - 2021-07-06 08:21:30 --> Security Class Initialized
DEBUG - 2021-07-06 08:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 08:21:30 --> Input Class Initialized
INFO - 2021-07-06 08:21:30 --> Language Class Initialized
INFO - 2021-07-06 08:21:30 --> Loader Class Initialized
INFO - 2021-07-06 08:21:30 --> Helper loaded: html_helper
INFO - 2021-07-06 08:21:30 --> Helper loaded: url_helper
INFO - 2021-07-06 08:21:30 --> Helper loaded: form_helper
INFO - 2021-07-06 08:21:30 --> Database Driver Class Initialized
INFO - 2021-07-06 08:21:30 --> Form Validation Class Initialized
DEBUG - 2021-07-06 08:21:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 08:21:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 08:21:30 --> Encryption Class Initialized
INFO - 2021-07-06 08:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 08:21:30 --> Model "vendor_model" initialized
INFO - 2021-07-06 08:21:30 --> Model "coupon_model" initialized
INFO - 2021-07-06 08:21:30 --> Model "user_model" initialized
INFO - 2021-07-06 08:21:30 --> Model "role_model" initialized
INFO - 2021-07-06 08:21:30 --> Controller Class Initialized
INFO - 2021-07-06 08:21:30 --> Helper loaded: language_helper
INFO - 2021-07-06 08:21:30 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 08:21:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-06 08:21:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-06 08:21:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-06 08:21:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 08:21:30 --> Final output sent to browser
DEBUG - 2021-07-06 08:21:30 --> Total execution time: 0.0602
INFO - 2021-07-06 08:21:37 --> Config Class Initialized
INFO - 2021-07-06 08:21:37 --> Hooks Class Initialized
DEBUG - 2021-07-06 08:21:37 --> UTF-8 Support Enabled
INFO - 2021-07-06 08:21:37 --> Utf8 Class Initialized
INFO - 2021-07-06 08:21:37 --> URI Class Initialized
INFO - 2021-07-06 08:21:37 --> Router Class Initialized
INFO - 2021-07-06 08:21:37 --> Output Class Initialized
INFO - 2021-07-06 08:21:37 --> Security Class Initialized
DEBUG - 2021-07-06 08:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 08:21:37 --> Input Class Initialized
INFO - 2021-07-06 08:21:37 --> Language Class Initialized
INFO - 2021-07-06 08:21:37 --> Loader Class Initialized
INFO - 2021-07-06 08:21:37 --> Helper loaded: html_helper
INFO - 2021-07-06 08:21:37 --> Helper loaded: url_helper
INFO - 2021-07-06 08:21:37 --> Helper loaded: form_helper
INFO - 2021-07-06 08:21:37 --> Database Driver Class Initialized
INFO - 2021-07-06 08:21:37 --> Form Validation Class Initialized
DEBUG - 2021-07-06 08:21:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 08:21:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 08:21:37 --> Encryption Class Initialized
INFO - 2021-07-06 08:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 08:21:37 --> Model "vendor_model" initialized
INFO - 2021-07-06 08:21:37 --> Model "coupon_model" initialized
INFO - 2021-07-06 08:21:37 --> Model "user_model" initialized
INFO - 2021-07-06 08:21:37 --> Model "role_model" initialized
INFO - 2021-07-06 08:21:37 --> Controller Class Initialized
INFO - 2021-07-06 08:21:37 --> Helper loaded: language_helper
INFO - 2021-07-06 08:21:37 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 08:21:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 08:21:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-06 08:21:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\create_role.php
INFO - 2021-07-06 08:21:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 08:21:37 --> Final output sent to browser
DEBUG - 2021-07-06 08:21:37 --> Total execution time: 0.2638
INFO - 2021-07-06 08:21:50 --> Config Class Initialized
INFO - 2021-07-06 08:21:50 --> Hooks Class Initialized
DEBUG - 2021-07-06 08:21:50 --> UTF-8 Support Enabled
INFO - 2021-07-06 08:21:50 --> Utf8 Class Initialized
INFO - 2021-07-06 08:21:50 --> URI Class Initialized
INFO - 2021-07-06 08:21:50 --> Router Class Initialized
INFO - 2021-07-06 08:21:50 --> Output Class Initialized
INFO - 2021-07-06 08:21:50 --> Security Class Initialized
DEBUG - 2021-07-06 08:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 08:21:50 --> Input Class Initialized
INFO - 2021-07-06 08:21:50 --> Language Class Initialized
INFO - 2021-07-06 08:21:50 --> Loader Class Initialized
INFO - 2021-07-06 08:21:50 --> Helper loaded: html_helper
INFO - 2021-07-06 08:21:50 --> Helper loaded: url_helper
INFO - 2021-07-06 08:21:50 --> Helper loaded: form_helper
INFO - 2021-07-06 08:21:50 --> Database Driver Class Initialized
INFO - 2021-07-06 08:21:50 --> Form Validation Class Initialized
DEBUG - 2021-07-06 08:21:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 08:21:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 08:21:50 --> Encryption Class Initialized
INFO - 2021-07-06 08:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 08:21:50 --> Model "vendor_model" initialized
INFO - 2021-07-06 08:21:50 --> Model "coupon_model" initialized
INFO - 2021-07-06 08:21:50 --> Model "user_model" initialized
INFO - 2021-07-06 08:21:50 --> Model "role_model" initialized
INFO - 2021-07-06 08:21:50 --> Controller Class Initialized
INFO - 2021-07-06 08:21:50 --> Helper loaded: language_helper
INFO - 2021-07-06 08:21:50 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 08:21:50 --> Model "Customer_model" initialized
INFO - 2021-07-06 08:21:50 --> Model "Product_model" initialized
INFO - 2021-07-06 08:21:50 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 08:21:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 08:21:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 08:21:50 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-06 08:21:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 08:21:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 08:21:50 --> Final output sent to browser
DEBUG - 2021-07-06 08:21:50 --> Total execution time: 0.0822
INFO - 2021-07-06 08:44:32 --> Config Class Initialized
INFO - 2021-07-06 08:44:32 --> Hooks Class Initialized
DEBUG - 2021-07-06 08:44:32 --> UTF-8 Support Enabled
INFO - 2021-07-06 08:44:32 --> Utf8 Class Initialized
INFO - 2021-07-06 08:44:32 --> URI Class Initialized
INFO - 2021-07-06 08:44:32 --> Router Class Initialized
INFO - 2021-07-06 08:44:32 --> Output Class Initialized
INFO - 2021-07-06 08:44:32 --> Security Class Initialized
DEBUG - 2021-07-06 08:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 08:44:32 --> Input Class Initialized
INFO - 2021-07-06 08:44:32 --> Language Class Initialized
INFO - 2021-07-06 08:44:32 --> Loader Class Initialized
INFO - 2021-07-06 08:44:32 --> Helper loaded: html_helper
INFO - 2021-07-06 08:44:32 --> Helper loaded: url_helper
INFO - 2021-07-06 08:44:32 --> Helper loaded: form_helper
INFO - 2021-07-06 08:44:32 --> Database Driver Class Initialized
INFO - 2021-07-06 08:44:32 --> Form Validation Class Initialized
DEBUG - 2021-07-06 08:44:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 08:44:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 08:44:32 --> Encryption Class Initialized
INFO - 2021-07-06 08:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 08:44:32 --> Model "vendor_model" initialized
INFO - 2021-07-06 08:44:32 --> Model "coupon_model" initialized
INFO - 2021-07-06 08:44:32 --> Model "user_model" initialized
INFO - 2021-07-06 08:44:32 --> Model "role_model" initialized
INFO - 2021-07-06 08:44:32 --> Controller Class Initialized
INFO - 2021-07-06 08:44:32 --> Helper loaded: language_helper
INFO - 2021-07-06 08:44:32 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 08:44:32 --> Model "Customer_model" initialized
INFO - 2021-07-06 08:44:32 --> Model "Product_model" initialized
INFO - 2021-07-06 08:44:32 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 08:44:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 08:44:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 08:44:32 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-06 08:44:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 08:44:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 08:44:32 --> Final output sent to browser
DEBUG - 2021-07-06 08:44:32 --> Total execution time: 0.0997
INFO - 2021-07-06 08:48:54 --> Config Class Initialized
INFO - 2021-07-06 08:48:54 --> Hooks Class Initialized
DEBUG - 2021-07-06 08:48:54 --> UTF-8 Support Enabled
INFO - 2021-07-06 08:48:54 --> Utf8 Class Initialized
INFO - 2021-07-06 08:48:54 --> URI Class Initialized
DEBUG - 2021-07-06 08:48:54 --> No URI present. Default controller set.
INFO - 2021-07-06 08:48:54 --> Router Class Initialized
INFO - 2021-07-06 08:48:54 --> Output Class Initialized
INFO - 2021-07-06 08:48:54 --> Security Class Initialized
DEBUG - 2021-07-06 08:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 08:48:54 --> Input Class Initialized
INFO - 2021-07-06 08:48:54 --> Language Class Initialized
INFO - 2021-07-06 08:48:54 --> Loader Class Initialized
INFO - 2021-07-06 08:48:54 --> Helper loaded: html_helper
INFO - 2021-07-06 08:48:54 --> Helper loaded: url_helper
INFO - 2021-07-06 08:48:54 --> Helper loaded: form_helper
INFO - 2021-07-06 08:48:54 --> Database Driver Class Initialized
INFO - 2021-07-06 08:48:54 --> Form Validation Class Initialized
DEBUG - 2021-07-06 08:48:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 08:48:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 08:48:54 --> Encryption Class Initialized
INFO - 2021-07-06 08:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 08:48:54 --> Model "vendor_model" initialized
INFO - 2021-07-06 08:48:54 --> Model "coupon_model" initialized
INFO - 2021-07-06 08:48:54 --> Model "user_model" initialized
INFO - 2021-07-06 08:48:54 --> Model "role_model" initialized
INFO - 2021-07-06 08:48:54 --> Controller Class Initialized
INFO - 2021-07-06 08:48:54 --> Helper loaded: language_helper
INFO - 2021-07-06 08:48:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 08:48:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-06 08:48:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-06 08:48:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-06 08:48:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 08:48:54 --> Final output sent to browser
DEBUG - 2021-07-06 08:48:54 --> Total execution time: 0.0806
INFO - 2021-07-06 08:48:55 --> Config Class Initialized
INFO - 2021-07-06 08:48:55 --> Hooks Class Initialized
DEBUG - 2021-07-06 08:48:55 --> UTF-8 Support Enabled
INFO - 2021-07-06 08:48:55 --> Utf8 Class Initialized
INFO - 2021-07-06 08:48:55 --> URI Class Initialized
DEBUG - 2021-07-06 08:48:55 --> No URI present. Default controller set.
INFO - 2021-07-06 08:48:55 --> Router Class Initialized
INFO - 2021-07-06 08:48:55 --> Output Class Initialized
INFO - 2021-07-06 08:48:55 --> Security Class Initialized
DEBUG - 2021-07-06 08:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 08:48:55 --> Input Class Initialized
INFO - 2021-07-06 08:48:55 --> Language Class Initialized
INFO - 2021-07-06 08:48:55 --> Loader Class Initialized
INFO - 2021-07-06 08:48:55 --> Helper loaded: html_helper
INFO - 2021-07-06 08:48:55 --> Helper loaded: url_helper
INFO - 2021-07-06 08:48:55 --> Helper loaded: form_helper
INFO - 2021-07-06 08:48:55 --> Database Driver Class Initialized
INFO - 2021-07-06 08:48:55 --> Form Validation Class Initialized
DEBUG - 2021-07-06 08:48:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 08:48:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 08:48:55 --> Encryption Class Initialized
INFO - 2021-07-06 08:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 08:48:55 --> Model "vendor_model" initialized
INFO - 2021-07-06 08:48:55 --> Model "coupon_model" initialized
INFO - 2021-07-06 08:48:55 --> Model "user_model" initialized
INFO - 2021-07-06 08:48:55 --> Model "role_model" initialized
INFO - 2021-07-06 08:48:55 --> Controller Class Initialized
INFO - 2021-07-06 08:48:55 --> Helper loaded: language_helper
INFO - 2021-07-06 08:48:55 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 08:48:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-06 08:48:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-06 08:48:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-06 08:48:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 08:48:55 --> Final output sent to browser
DEBUG - 2021-07-06 08:48:55 --> Total execution time: 0.0732
INFO - 2021-07-06 08:49:07 --> Config Class Initialized
INFO - 2021-07-06 08:49:07 --> Hooks Class Initialized
DEBUG - 2021-07-06 08:49:07 --> UTF-8 Support Enabled
INFO - 2021-07-06 08:49:07 --> Utf8 Class Initialized
INFO - 2021-07-06 08:49:07 --> URI Class Initialized
INFO - 2021-07-06 08:49:07 --> Router Class Initialized
INFO - 2021-07-06 08:49:07 --> Output Class Initialized
INFO - 2021-07-06 08:49:07 --> Security Class Initialized
DEBUG - 2021-07-06 08:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 08:49:07 --> Input Class Initialized
INFO - 2021-07-06 08:49:07 --> Language Class Initialized
INFO - 2021-07-06 08:49:07 --> Loader Class Initialized
INFO - 2021-07-06 08:49:07 --> Helper loaded: html_helper
INFO - 2021-07-06 08:49:07 --> Helper loaded: url_helper
INFO - 2021-07-06 08:49:07 --> Helper loaded: form_helper
INFO - 2021-07-06 08:49:07 --> Database Driver Class Initialized
INFO - 2021-07-06 08:49:07 --> Form Validation Class Initialized
DEBUG - 2021-07-06 08:49:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 08:49:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 08:49:07 --> Encryption Class Initialized
INFO - 2021-07-06 08:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 08:49:07 --> Model "vendor_model" initialized
INFO - 2021-07-06 08:49:07 --> Model "coupon_model" initialized
INFO - 2021-07-06 08:49:07 --> Model "user_model" initialized
INFO - 2021-07-06 08:49:07 --> Model "role_model" initialized
INFO - 2021-07-06 08:49:07 --> Controller Class Initialized
INFO - 2021-07-06 08:49:07 --> Helper loaded: language_helper
INFO - 2021-07-06 08:49:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 08:49:07 --> Model "Customer_model" initialized
INFO - 2021-07-06 08:49:07 --> Model "Product_model" initialized
INFO - 2021-07-06 08:49:07 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-06 08:49:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-06 08:49:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-06 08:49:07 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-06 08:49:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-06 08:49:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-06 08:49:07 --> Final output sent to browser
DEBUG - 2021-07-06 08:49:07 --> Total execution time: 0.0824
INFO - 2021-07-06 11:41:18 --> Config Class Initialized
INFO - 2021-07-06 11:41:19 --> Hooks Class Initialized
DEBUG - 2021-07-06 11:41:19 --> UTF-8 Support Enabled
INFO - 2021-07-06 11:41:19 --> Utf8 Class Initialized
INFO - 2021-07-06 11:41:19 --> URI Class Initialized
DEBUG - 2021-07-06 11:41:19 --> No URI present. Default controller set.
INFO - 2021-07-06 11:41:19 --> Router Class Initialized
INFO - 2021-07-06 11:41:19 --> Output Class Initialized
INFO - 2021-07-06 11:41:19 --> Security Class Initialized
DEBUG - 2021-07-06 11:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 11:41:19 --> Input Class Initialized
INFO - 2021-07-06 11:41:19 --> Language Class Initialized
INFO - 2021-07-06 11:41:19 --> Loader Class Initialized
INFO - 2021-07-06 11:41:19 --> Helper loaded: html_helper
INFO - 2021-07-06 11:41:19 --> Helper loaded: url_helper
INFO - 2021-07-06 11:41:19 --> Helper loaded: form_helper
INFO - 2021-07-06 11:41:19 --> Database Driver Class Initialized
INFO - 2021-07-06 11:41:19 --> Form Validation Class Initialized
DEBUG - 2021-07-06 11:41:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-06 11:41:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-06 11:41:19 --> Encryption Class Initialized
INFO - 2021-07-06 11:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-06 11:41:19 --> Model "vendor_model" initialized
INFO - 2021-07-06 11:41:19 --> Model "coupon_model" initialized
INFO - 2021-07-06 11:41:19 --> Model "user_model" initialized
INFO - 2021-07-06 11:41:19 --> Model "role_model" initialized
INFO - 2021-07-06 11:41:19 --> Controller Class Initialized
INFO - 2021-07-06 11:41:19 --> Helper loaded: language_helper
INFO - 2021-07-06 11:41:19 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-06 11:41:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\login.php
INFO - 2021-07-06 11:41:19 --> Final output sent to browser
DEBUG - 2021-07-06 11:41:19 --> Total execution time: 0.6629
