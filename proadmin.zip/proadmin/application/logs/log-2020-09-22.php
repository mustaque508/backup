<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-22 04:40:50 --> Config Class Initialized
INFO - 2020-09-22 04:40:50 --> Hooks Class Initialized
DEBUG - 2020-09-22 04:40:50 --> UTF-8 Support Enabled
INFO - 2020-09-22 04:40:50 --> Utf8 Class Initialized
INFO - 2020-09-22 04:40:51 --> URI Class Initialized
INFO - 2020-09-22 04:40:51 --> Router Class Initialized
INFO - 2020-09-22 04:40:51 --> Output Class Initialized
INFO - 2020-09-22 04:40:51 --> Security Class Initialized
DEBUG - 2020-09-22 04:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 04:40:51 --> Input Class Initialized
INFO - 2020-09-22 04:40:51 --> Language Class Initialized
INFO - 2020-09-22 04:40:51 --> Loader Class Initialized
INFO - 2020-09-22 04:40:51 --> Helper loaded: html_helper
INFO - 2020-09-22 04:40:51 --> Helper loaded: url_helper
INFO - 2020-09-22 04:40:51 --> Helper loaded: form_helper
INFO - 2020-09-22 04:40:52 --> Database Driver Class Initialized
INFO - 2020-09-22 04:40:52 --> Form Validation Class Initialized
DEBUG - 2020-09-22 04:40:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 04:40:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 04:40:52 --> Encryption Class Initialized
INFO - 2020-09-22 04:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 04:40:52 --> Controller Class Initialized
INFO - 2020-09-22 04:40:52 --> Helper loaded: language_helper
INFO - 2020-09-22 04:40:52 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 04:40:52 --> Final output sent to browser
DEBUG - 2020-09-22 04:40:53 --> Total execution time: 2.4877
INFO - 2020-09-22 04:40:53 --> Config Class Initialized
INFO - 2020-09-22 04:40:53 --> Hooks Class Initialized
DEBUG - 2020-09-22 04:40:53 --> UTF-8 Support Enabled
INFO - 2020-09-22 04:40:53 --> Utf8 Class Initialized
INFO - 2020-09-22 04:40:53 --> URI Class Initialized
DEBUG - 2020-09-22 04:40:53 --> No URI present. Default controller set.
INFO - 2020-09-22 04:40:53 --> Router Class Initialized
INFO - 2020-09-22 04:40:53 --> Output Class Initialized
INFO - 2020-09-22 04:40:53 --> Security Class Initialized
DEBUG - 2020-09-22 04:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 04:40:53 --> Input Class Initialized
INFO - 2020-09-22 04:40:53 --> Language Class Initialized
INFO - 2020-09-22 04:40:53 --> Loader Class Initialized
INFO - 2020-09-22 04:40:53 --> Helper loaded: html_helper
INFO - 2020-09-22 04:40:53 --> Helper loaded: url_helper
INFO - 2020-09-22 04:40:53 --> Helper loaded: form_helper
INFO - 2020-09-22 04:40:54 --> Database Driver Class Initialized
INFO - 2020-09-22 04:40:54 --> Form Validation Class Initialized
DEBUG - 2020-09-22 04:40:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 04:40:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 04:40:54 --> Encryption Class Initialized
INFO - 2020-09-22 04:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 04:40:54 --> Controller Class Initialized
INFO - 2020-09-22 04:40:54 --> Helper loaded: language_helper
INFO - 2020-09-22 04:40:54 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 04:40:54 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-22 04:40:54 --> Final output sent to browser
DEBUG - 2020-09-22 04:40:54 --> Total execution time: 1.0130
INFO - 2020-09-22 04:41:00 --> Config Class Initialized
INFO - 2020-09-22 04:41:00 --> Hooks Class Initialized
DEBUG - 2020-09-22 04:41:00 --> UTF-8 Support Enabled
INFO - 2020-09-22 04:41:00 --> Utf8 Class Initialized
INFO - 2020-09-22 04:41:00 --> URI Class Initialized
INFO - 2020-09-22 04:41:00 --> Router Class Initialized
INFO - 2020-09-22 04:41:00 --> Output Class Initialized
INFO - 2020-09-22 04:41:00 --> Security Class Initialized
DEBUG - 2020-09-22 04:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 04:41:00 --> Input Class Initialized
INFO - 2020-09-22 04:41:00 --> Language Class Initialized
INFO - 2020-09-22 04:41:00 --> Loader Class Initialized
INFO - 2020-09-22 04:41:00 --> Helper loaded: html_helper
INFO - 2020-09-22 04:41:00 --> Helper loaded: url_helper
INFO - 2020-09-22 04:41:00 --> Helper loaded: form_helper
INFO - 2020-09-22 04:41:01 --> Database Driver Class Initialized
INFO - 2020-09-22 04:41:01 --> Form Validation Class Initialized
DEBUG - 2020-09-22 04:41:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 04:41:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 04:41:01 --> Encryption Class Initialized
INFO - 2020-09-22 04:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 04:41:01 --> Controller Class Initialized
INFO - 2020-09-22 04:41:01 --> Helper loaded: language_helper
INFO - 2020-09-22 04:41:01 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-22 04:41:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-22 04:41:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-22 04:41:01 --> Model "User" initialized
INFO - 2020-09-22 04:41:02 --> Config Class Initialized
INFO - 2020-09-22 04:41:02 --> Hooks Class Initialized
DEBUG - 2020-09-22 04:41:02 --> UTF-8 Support Enabled
INFO - 2020-09-22 04:41:02 --> Utf8 Class Initialized
INFO - 2020-09-22 04:41:02 --> URI Class Initialized
INFO - 2020-09-22 04:41:02 --> Router Class Initialized
INFO - 2020-09-22 04:41:02 --> Output Class Initialized
INFO - 2020-09-22 04:41:02 --> Security Class Initialized
DEBUG - 2020-09-22 04:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 04:41:02 --> Input Class Initialized
INFO - 2020-09-22 04:41:02 --> Language Class Initialized
INFO - 2020-09-22 04:41:02 --> Loader Class Initialized
INFO - 2020-09-22 04:41:02 --> Helper loaded: html_helper
INFO - 2020-09-22 04:41:02 --> Helper loaded: url_helper
INFO - 2020-09-22 04:41:02 --> Helper loaded: form_helper
INFO - 2020-09-22 04:41:02 --> Database Driver Class Initialized
INFO - 2020-09-22 04:41:02 --> Form Validation Class Initialized
DEBUG - 2020-09-22 04:41:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 04:41:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 04:41:03 --> Encryption Class Initialized
INFO - 2020-09-22 04:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 04:41:03 --> Controller Class Initialized
INFO - 2020-09-22 04:41:03 --> Helper loaded: language_helper
INFO - 2020-09-22 04:41:03 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 04:41:03 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-22 04:41:03 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-22 04:41:03 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-22 04:41:03 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-22 04:41:03 --> Final output sent to browser
DEBUG - 2020-09-22 04:41:03 --> Total execution time: 1.1904
INFO - 2020-09-22 04:41:11 --> Config Class Initialized
INFO - 2020-09-22 04:41:11 --> Hooks Class Initialized
DEBUG - 2020-09-22 04:41:11 --> UTF-8 Support Enabled
INFO - 2020-09-22 04:41:11 --> Utf8 Class Initialized
INFO - 2020-09-22 04:41:11 --> URI Class Initialized
INFO - 2020-09-22 04:41:11 --> Router Class Initialized
INFO - 2020-09-22 04:41:11 --> Output Class Initialized
INFO - 2020-09-22 04:41:11 --> Security Class Initialized
DEBUG - 2020-09-22 04:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 04:41:11 --> Input Class Initialized
INFO - 2020-09-22 04:41:11 --> Language Class Initialized
INFO - 2020-09-22 04:41:12 --> Loader Class Initialized
INFO - 2020-09-22 04:41:12 --> Helper loaded: html_helper
INFO - 2020-09-22 04:41:12 --> Helper loaded: url_helper
INFO - 2020-09-22 04:41:12 --> Helper loaded: form_helper
INFO - 2020-09-22 04:41:12 --> Database Driver Class Initialized
INFO - 2020-09-22 04:41:12 --> Form Validation Class Initialized
DEBUG - 2020-09-22 04:41:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 04:41:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 04:41:12 --> Encryption Class Initialized
INFO - 2020-09-22 04:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 04:41:12 --> Controller Class Initialized
INFO - 2020-09-22 04:41:12 --> Helper loaded: language_helper
INFO - 2020-09-22 04:41:12 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 04:41:12 --> Final output sent to browser
DEBUG - 2020-09-22 04:41:12 --> Total execution time: 0.9315
INFO - 2020-09-22 04:41:12 --> Config Class Initialized
INFO - 2020-09-22 04:41:13 --> Hooks Class Initialized
DEBUG - 2020-09-22 04:41:13 --> UTF-8 Support Enabled
INFO - 2020-09-22 04:41:13 --> Utf8 Class Initialized
INFO - 2020-09-22 04:41:13 --> URI Class Initialized
DEBUG - 2020-09-22 04:41:13 --> No URI present. Default controller set.
INFO - 2020-09-22 04:41:13 --> Router Class Initialized
INFO - 2020-09-22 04:41:13 --> Output Class Initialized
INFO - 2020-09-22 04:41:13 --> Security Class Initialized
DEBUG - 2020-09-22 04:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 04:41:13 --> Input Class Initialized
INFO - 2020-09-22 04:41:13 --> Language Class Initialized
INFO - 2020-09-22 04:41:13 --> Loader Class Initialized
INFO - 2020-09-22 04:41:13 --> Helper loaded: html_helper
INFO - 2020-09-22 04:41:13 --> Helper loaded: url_helper
INFO - 2020-09-22 04:41:13 --> Helper loaded: form_helper
INFO - 2020-09-22 04:41:13 --> Database Driver Class Initialized
INFO - 2020-09-22 04:41:13 --> Form Validation Class Initialized
DEBUG - 2020-09-22 04:41:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 04:41:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 04:41:13 --> Encryption Class Initialized
INFO - 2020-09-22 04:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 04:41:13 --> Controller Class Initialized
INFO - 2020-09-22 04:41:13 --> Helper loaded: language_helper
INFO - 2020-09-22 04:41:13 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 04:41:13 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-22 04:41:13 --> Final output sent to browser
DEBUG - 2020-09-22 04:41:13 --> Total execution time: 0.9390
INFO - 2020-09-22 04:43:40 --> Config Class Initialized
INFO - 2020-09-22 04:43:40 --> Hooks Class Initialized
DEBUG - 2020-09-22 04:43:40 --> UTF-8 Support Enabled
INFO - 2020-09-22 04:43:40 --> Utf8 Class Initialized
INFO - 2020-09-22 04:43:40 --> URI Class Initialized
INFO - 2020-09-22 04:43:40 --> Router Class Initialized
INFO - 2020-09-22 04:43:40 --> Output Class Initialized
INFO - 2020-09-22 04:43:41 --> Security Class Initialized
DEBUG - 2020-09-22 04:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 04:43:41 --> Input Class Initialized
INFO - 2020-09-22 04:43:41 --> Language Class Initialized
INFO - 2020-09-22 04:43:41 --> Loader Class Initialized
INFO - 2020-09-22 04:43:41 --> Helper loaded: html_helper
INFO - 2020-09-22 04:43:41 --> Helper loaded: url_helper
INFO - 2020-09-22 04:43:41 --> Helper loaded: form_helper
INFO - 2020-09-22 04:43:41 --> Database Driver Class Initialized
INFO - 2020-09-22 04:43:41 --> Form Validation Class Initialized
DEBUG - 2020-09-22 04:43:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 04:43:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 04:43:41 --> Encryption Class Initialized
INFO - 2020-09-22 04:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 04:43:41 --> Controller Class Initialized
INFO - 2020-09-22 04:43:41 --> Helper loaded: language_helper
INFO - 2020-09-22 04:43:41 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-22 04:43:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-22 04:43:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-22 04:43:41 --> Model "User" initialized
INFO - 2020-09-22 04:43:42 --> Config Class Initialized
INFO - 2020-09-22 04:43:42 --> Hooks Class Initialized
DEBUG - 2020-09-22 04:43:42 --> UTF-8 Support Enabled
INFO - 2020-09-22 04:43:42 --> Utf8 Class Initialized
INFO - 2020-09-22 04:43:42 --> URI Class Initialized
INFO - 2020-09-22 04:43:42 --> Router Class Initialized
INFO - 2020-09-22 04:43:42 --> Output Class Initialized
INFO - 2020-09-22 04:43:42 --> Security Class Initialized
DEBUG - 2020-09-22 04:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 04:43:42 --> Input Class Initialized
INFO - 2020-09-22 04:43:42 --> Language Class Initialized
INFO - 2020-09-22 04:43:42 --> Loader Class Initialized
INFO - 2020-09-22 04:43:42 --> Helper loaded: html_helper
INFO - 2020-09-22 04:43:42 --> Helper loaded: url_helper
INFO - 2020-09-22 04:43:42 --> Helper loaded: form_helper
INFO - 2020-09-22 04:43:42 --> Database Driver Class Initialized
INFO - 2020-09-22 04:43:43 --> Form Validation Class Initialized
DEBUG - 2020-09-22 04:43:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 04:43:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 04:43:43 --> Encryption Class Initialized
INFO - 2020-09-22 04:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 04:43:43 --> Controller Class Initialized
INFO - 2020-09-22 04:43:43 --> Helper loaded: language_helper
INFO - 2020-09-22 04:43:43 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 04:43:43 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-22 04:43:43 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-22 04:43:43 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-22 04:43:43 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-22 04:43:43 --> Final output sent to browser
DEBUG - 2020-09-22 04:43:43 --> Total execution time: 1.0398
INFO - 2020-09-22 04:43:52 --> Config Class Initialized
INFO - 2020-09-22 04:43:52 --> Hooks Class Initialized
DEBUG - 2020-09-22 04:43:52 --> UTF-8 Support Enabled
INFO - 2020-09-22 04:43:52 --> Utf8 Class Initialized
INFO - 2020-09-22 04:43:52 --> URI Class Initialized
INFO - 2020-09-22 04:43:52 --> Router Class Initialized
INFO - 2020-09-22 04:43:52 --> Output Class Initialized
INFO - 2020-09-22 04:43:52 --> Security Class Initialized
DEBUG - 2020-09-22 04:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 04:43:52 --> Input Class Initialized
INFO - 2020-09-22 04:43:52 --> Language Class Initialized
INFO - 2020-09-22 04:43:53 --> Loader Class Initialized
INFO - 2020-09-22 04:43:53 --> Helper loaded: html_helper
INFO - 2020-09-22 04:43:53 --> Helper loaded: url_helper
INFO - 2020-09-22 04:43:53 --> Helper loaded: form_helper
INFO - 2020-09-22 04:43:53 --> Database Driver Class Initialized
INFO - 2020-09-22 04:43:53 --> Form Validation Class Initialized
DEBUG - 2020-09-22 04:43:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 04:43:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 04:43:53 --> Encryption Class Initialized
INFO - 2020-09-22 04:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 04:43:53 --> Controller Class Initialized
INFO - 2020-09-22 04:43:53 --> Helper loaded: language_helper
INFO - 2020-09-22 04:43:53 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 04:43:53 --> Final output sent to browser
DEBUG - 2020-09-22 04:43:53 --> Total execution time: 0.9061
INFO - 2020-09-22 04:43:53 --> Config Class Initialized
INFO - 2020-09-22 04:43:53 --> Hooks Class Initialized
DEBUG - 2020-09-22 04:43:54 --> UTF-8 Support Enabled
INFO - 2020-09-22 04:43:54 --> Utf8 Class Initialized
INFO - 2020-09-22 04:43:54 --> URI Class Initialized
DEBUG - 2020-09-22 04:43:54 --> No URI present. Default controller set.
INFO - 2020-09-22 04:43:54 --> Router Class Initialized
INFO - 2020-09-22 04:43:54 --> Output Class Initialized
INFO - 2020-09-22 04:43:54 --> Security Class Initialized
DEBUG - 2020-09-22 04:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 04:43:54 --> Input Class Initialized
INFO - 2020-09-22 04:43:54 --> Language Class Initialized
INFO - 2020-09-22 04:43:54 --> Loader Class Initialized
INFO - 2020-09-22 04:43:54 --> Helper loaded: html_helper
INFO - 2020-09-22 04:43:54 --> Helper loaded: url_helper
INFO - 2020-09-22 04:43:54 --> Helper loaded: form_helper
INFO - 2020-09-22 04:43:54 --> Database Driver Class Initialized
INFO - 2020-09-22 04:43:54 --> Form Validation Class Initialized
DEBUG - 2020-09-22 04:43:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 04:43:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 04:43:54 --> Encryption Class Initialized
INFO - 2020-09-22 04:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 04:43:54 --> Controller Class Initialized
INFO - 2020-09-22 04:43:54 --> Helper loaded: language_helper
INFO - 2020-09-22 04:43:54 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 04:43:54 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-22 04:43:54 --> Final output sent to browser
DEBUG - 2020-09-22 04:43:54 --> Total execution time: 0.9179
INFO - 2020-09-22 04:44:01 --> Config Class Initialized
INFO - 2020-09-22 04:44:01 --> Hooks Class Initialized
DEBUG - 2020-09-22 04:44:01 --> UTF-8 Support Enabled
INFO - 2020-09-22 04:44:01 --> Utf8 Class Initialized
INFO - 2020-09-22 04:44:01 --> URI Class Initialized
INFO - 2020-09-22 04:44:01 --> Router Class Initialized
INFO - 2020-09-22 04:44:01 --> Output Class Initialized
INFO - 2020-09-22 04:44:01 --> Security Class Initialized
DEBUG - 2020-09-22 04:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 04:44:01 --> Input Class Initialized
INFO - 2020-09-22 04:44:01 --> Language Class Initialized
INFO - 2020-09-22 04:44:01 --> Loader Class Initialized
INFO - 2020-09-22 04:44:01 --> Helper loaded: html_helper
INFO - 2020-09-22 04:44:01 --> Helper loaded: url_helper
INFO - 2020-09-22 04:44:01 --> Helper loaded: form_helper
INFO - 2020-09-22 04:44:01 --> Database Driver Class Initialized
INFO - 2020-09-22 04:44:01 --> Form Validation Class Initialized
DEBUG - 2020-09-22 04:44:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 04:44:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 04:44:01 --> Encryption Class Initialized
INFO - 2020-09-22 04:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 04:44:02 --> Controller Class Initialized
INFO - 2020-09-22 04:44:02 --> Helper loaded: language_helper
INFO - 2020-09-22 04:44:02 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-22 04:44:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-22 04:44:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-22 04:44:02 --> Model "User" initialized
INFO - 2020-09-22 04:44:02 --> Config Class Initialized
INFO - 2020-09-22 04:44:03 --> Hooks Class Initialized
DEBUG - 2020-09-22 04:44:03 --> UTF-8 Support Enabled
INFO - 2020-09-22 04:44:03 --> Utf8 Class Initialized
INFO - 2020-09-22 04:44:03 --> URI Class Initialized
INFO - 2020-09-22 04:44:03 --> Router Class Initialized
INFO - 2020-09-22 04:44:03 --> Output Class Initialized
INFO - 2020-09-22 04:44:03 --> Security Class Initialized
DEBUG - 2020-09-22 04:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 04:44:03 --> Input Class Initialized
INFO - 2020-09-22 04:44:03 --> Language Class Initialized
INFO - 2020-09-22 04:44:03 --> Loader Class Initialized
INFO - 2020-09-22 04:44:03 --> Helper loaded: html_helper
INFO - 2020-09-22 04:44:03 --> Helper loaded: url_helper
INFO - 2020-09-22 04:44:03 --> Helper loaded: form_helper
INFO - 2020-09-22 04:44:03 --> Database Driver Class Initialized
INFO - 2020-09-22 04:44:03 --> Form Validation Class Initialized
DEBUG - 2020-09-22 04:44:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 04:44:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 04:44:03 --> Encryption Class Initialized
INFO - 2020-09-22 04:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 04:44:03 --> Controller Class Initialized
INFO - 2020-09-22 04:44:03 --> Helper loaded: language_helper
INFO - 2020-09-22 04:44:03 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 04:44:03 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-22 04:44:03 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-22 04:44:03 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-22 04:44:03 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-22 04:44:03 --> Final output sent to browser
DEBUG - 2020-09-22 04:44:03 --> Total execution time: 1.0183
INFO - 2020-09-22 04:44:08 --> Config Class Initialized
INFO - 2020-09-22 04:44:08 --> Hooks Class Initialized
DEBUG - 2020-09-22 04:44:08 --> UTF-8 Support Enabled
INFO - 2020-09-22 04:44:08 --> Utf8 Class Initialized
INFO - 2020-09-22 04:44:08 --> URI Class Initialized
INFO - 2020-09-22 04:44:08 --> Router Class Initialized
INFO - 2020-09-22 04:44:08 --> Output Class Initialized
INFO - 2020-09-22 04:44:08 --> Security Class Initialized
DEBUG - 2020-09-22 04:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 04:44:08 --> Input Class Initialized
INFO - 2020-09-22 04:44:08 --> Language Class Initialized
INFO - 2020-09-22 04:44:08 --> Loader Class Initialized
INFO - 2020-09-22 04:44:08 --> Helper loaded: html_helper
INFO - 2020-09-22 04:44:08 --> Helper loaded: url_helper
INFO - 2020-09-22 04:44:08 --> Helper loaded: form_helper
INFO - 2020-09-22 04:44:08 --> Database Driver Class Initialized
INFO - 2020-09-22 04:44:08 --> Form Validation Class Initialized
DEBUG - 2020-09-22 04:44:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 04:44:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 04:44:09 --> Encryption Class Initialized
INFO - 2020-09-22 04:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 04:44:09 --> Controller Class Initialized
INFO - 2020-09-22 04:44:09 --> Helper loaded: language_helper
INFO - 2020-09-22 04:44:09 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 04:44:09 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-22 04:44:09 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-22 04:44:09 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-22 04:44:09 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-22 04:44:09 --> Final output sent to browser
DEBUG - 2020-09-22 04:44:09 --> Total execution time: 1.1028
INFO - 2020-09-22 04:44:12 --> Config Class Initialized
INFO - 2020-09-22 04:44:12 --> Hooks Class Initialized
DEBUG - 2020-09-22 04:44:12 --> UTF-8 Support Enabled
INFO - 2020-09-22 04:44:12 --> Utf8 Class Initialized
INFO - 2020-09-22 04:44:12 --> URI Class Initialized
INFO - 2020-09-22 04:44:12 --> Router Class Initialized
INFO - 2020-09-22 04:44:12 --> Output Class Initialized
INFO - 2020-09-22 04:44:12 --> Security Class Initialized
DEBUG - 2020-09-22 04:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 04:44:12 --> Input Class Initialized
INFO - 2020-09-22 04:44:12 --> Language Class Initialized
INFO - 2020-09-22 04:44:12 --> Loader Class Initialized
INFO - 2020-09-22 04:44:12 --> Helper loaded: html_helper
INFO - 2020-09-22 04:44:12 --> Helper loaded: url_helper
INFO - 2020-09-22 04:44:12 --> Helper loaded: form_helper
INFO - 2020-09-22 04:44:12 --> Database Driver Class Initialized
INFO - 2020-09-22 04:44:12 --> Form Validation Class Initialized
DEBUG - 2020-09-22 04:44:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 04:44:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 04:44:12 --> Encryption Class Initialized
INFO - 2020-09-22 04:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 04:44:12 --> Controller Class Initialized
INFO - 2020-09-22 04:44:12 --> Helper loaded: language_helper
INFO - 2020-09-22 04:44:12 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 04:44:13 --> Final output sent to browser
DEBUG - 2020-09-22 04:44:13 --> Total execution time: 1.0405
INFO - 2020-09-22 04:44:13 --> Config Class Initialized
INFO - 2020-09-22 04:44:13 --> Hooks Class Initialized
DEBUG - 2020-09-22 04:44:13 --> UTF-8 Support Enabled
INFO - 2020-09-22 04:44:13 --> Utf8 Class Initialized
INFO - 2020-09-22 04:44:13 --> URI Class Initialized
DEBUG - 2020-09-22 04:44:13 --> No URI present. Default controller set.
INFO - 2020-09-22 04:44:13 --> Router Class Initialized
INFO - 2020-09-22 04:44:13 --> Output Class Initialized
INFO - 2020-09-22 04:44:13 --> Security Class Initialized
DEBUG - 2020-09-22 04:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 04:44:13 --> Input Class Initialized
INFO - 2020-09-22 04:44:13 --> Language Class Initialized
INFO - 2020-09-22 04:44:13 --> Loader Class Initialized
INFO - 2020-09-22 04:44:13 --> Helper loaded: html_helper
INFO - 2020-09-22 04:44:13 --> Helper loaded: url_helper
INFO - 2020-09-22 04:44:13 --> Helper loaded: form_helper
INFO - 2020-09-22 04:44:14 --> Database Driver Class Initialized
INFO - 2020-09-22 04:44:14 --> Form Validation Class Initialized
DEBUG - 2020-09-22 04:44:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 04:44:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 04:44:14 --> Encryption Class Initialized
INFO - 2020-09-22 04:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 04:44:14 --> Controller Class Initialized
INFO - 2020-09-22 04:44:14 --> Helper loaded: language_helper
INFO - 2020-09-22 04:44:14 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 04:44:14 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-22 04:44:14 --> Final output sent to browser
DEBUG - 2020-09-22 04:44:14 --> Total execution time: 0.9921
INFO - 2020-09-22 04:44:26 --> Config Class Initialized
INFO - 2020-09-22 04:44:26 --> Hooks Class Initialized
DEBUG - 2020-09-22 04:44:26 --> UTF-8 Support Enabled
INFO - 2020-09-22 04:44:26 --> Utf8 Class Initialized
INFO - 2020-09-22 04:44:26 --> URI Class Initialized
INFO - 2020-09-22 04:44:27 --> Router Class Initialized
INFO - 2020-09-22 04:44:27 --> Output Class Initialized
INFO - 2020-09-22 04:44:27 --> Security Class Initialized
DEBUG - 2020-09-22 04:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 04:44:27 --> Input Class Initialized
INFO - 2020-09-22 04:44:27 --> Language Class Initialized
INFO - 2020-09-22 04:44:27 --> Loader Class Initialized
INFO - 2020-09-22 04:44:27 --> Helper loaded: html_helper
INFO - 2020-09-22 04:44:27 --> Helper loaded: url_helper
INFO - 2020-09-22 04:44:27 --> Helper loaded: form_helper
INFO - 2020-09-22 04:44:27 --> Database Driver Class Initialized
INFO - 2020-09-22 04:44:27 --> Form Validation Class Initialized
DEBUG - 2020-09-22 04:44:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 04:44:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 04:44:27 --> Encryption Class Initialized
INFO - 2020-09-22 04:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 04:44:27 --> Controller Class Initialized
INFO - 2020-09-22 04:44:27 --> Helper loaded: language_helper
INFO - 2020-09-22 04:44:27 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-22 04:44:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-22 04:44:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-22 04:44:27 --> Model "User" initialized
INFO - 2020-09-22 04:44:28 --> Config Class Initialized
INFO - 2020-09-22 04:44:28 --> Hooks Class Initialized
DEBUG - 2020-09-22 04:44:28 --> UTF-8 Support Enabled
INFO - 2020-09-22 04:44:28 --> Utf8 Class Initialized
INFO - 2020-09-22 04:44:28 --> URI Class Initialized
INFO - 2020-09-22 04:44:28 --> Router Class Initialized
INFO - 2020-09-22 04:44:28 --> Output Class Initialized
INFO - 2020-09-22 04:44:28 --> Security Class Initialized
DEBUG - 2020-09-22 04:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 04:44:28 --> Input Class Initialized
INFO - 2020-09-22 04:44:28 --> Language Class Initialized
INFO - 2020-09-22 04:44:28 --> Loader Class Initialized
INFO - 2020-09-22 04:44:28 --> Helper loaded: html_helper
INFO - 2020-09-22 04:44:28 --> Helper loaded: url_helper
INFO - 2020-09-22 04:44:29 --> Helper loaded: form_helper
INFO - 2020-09-22 04:44:29 --> Database Driver Class Initialized
INFO - 2020-09-22 04:44:29 --> Form Validation Class Initialized
DEBUG - 2020-09-22 04:44:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 04:44:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 04:44:29 --> Encryption Class Initialized
INFO - 2020-09-22 04:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 04:44:29 --> Controller Class Initialized
INFO - 2020-09-22 04:44:29 --> Helper loaded: language_helper
INFO - 2020-09-22 04:44:29 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 04:44:29 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-22 04:44:29 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-22 04:44:29 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-22 04:44:29 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-22 04:44:29 --> Final output sent to browser
DEBUG - 2020-09-22 04:44:29 --> Total execution time: 1.0816
INFO - 2020-09-22 04:44:48 --> Config Class Initialized
INFO - 2020-09-22 04:44:48 --> Hooks Class Initialized
DEBUG - 2020-09-22 04:44:48 --> UTF-8 Support Enabled
INFO - 2020-09-22 04:44:48 --> Utf8 Class Initialized
INFO - 2020-09-22 04:44:48 --> URI Class Initialized
INFO - 2020-09-22 04:44:48 --> Router Class Initialized
INFO - 2020-09-22 04:44:48 --> Output Class Initialized
INFO - 2020-09-22 04:44:48 --> Security Class Initialized
DEBUG - 2020-09-22 04:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 04:44:48 --> Input Class Initialized
INFO - 2020-09-22 04:44:48 --> Language Class Initialized
INFO - 2020-09-22 04:44:48 --> Loader Class Initialized
INFO - 2020-09-22 04:44:48 --> Helper loaded: html_helper
INFO - 2020-09-22 04:44:48 --> Helper loaded: url_helper
INFO - 2020-09-22 04:44:48 --> Helper loaded: form_helper
INFO - 2020-09-22 04:44:48 --> Database Driver Class Initialized
INFO - 2020-09-22 04:44:48 --> Form Validation Class Initialized
DEBUG - 2020-09-22 04:44:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 04:44:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 04:44:48 --> Encryption Class Initialized
INFO - 2020-09-22 04:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 04:44:49 --> Controller Class Initialized
INFO - 2020-09-22 04:44:49 --> Helper loaded: language_helper
INFO - 2020-09-22 04:44:49 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 04:44:49 --> Final output sent to browser
DEBUG - 2020-09-22 04:44:49 --> Total execution time: 0.9187
INFO - 2020-09-22 04:44:49 --> Config Class Initialized
INFO - 2020-09-22 04:44:49 --> Hooks Class Initialized
DEBUG - 2020-09-22 04:44:49 --> UTF-8 Support Enabled
INFO - 2020-09-22 04:44:49 --> Utf8 Class Initialized
INFO - 2020-09-22 04:44:49 --> URI Class Initialized
DEBUG - 2020-09-22 04:44:49 --> No URI present. Default controller set.
INFO - 2020-09-22 04:44:49 --> Router Class Initialized
INFO - 2020-09-22 04:44:49 --> Output Class Initialized
INFO - 2020-09-22 04:44:49 --> Security Class Initialized
DEBUG - 2020-09-22 04:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 04:44:49 --> Input Class Initialized
INFO - 2020-09-22 04:44:50 --> Language Class Initialized
INFO - 2020-09-22 04:44:50 --> Loader Class Initialized
INFO - 2020-09-22 04:44:50 --> Helper loaded: html_helper
INFO - 2020-09-22 04:44:50 --> Helper loaded: url_helper
INFO - 2020-09-22 04:44:50 --> Helper loaded: form_helper
INFO - 2020-09-22 04:44:50 --> Database Driver Class Initialized
INFO - 2020-09-22 04:44:50 --> Form Validation Class Initialized
DEBUG - 2020-09-22 04:44:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 04:44:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 04:44:50 --> Encryption Class Initialized
INFO - 2020-09-22 04:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 04:44:50 --> Controller Class Initialized
INFO - 2020-09-22 04:44:50 --> Helper loaded: language_helper
INFO - 2020-09-22 04:44:50 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 04:44:50 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-22 04:44:50 --> Final output sent to browser
DEBUG - 2020-09-22 04:44:50 --> Total execution time: 0.9634
INFO - 2020-09-22 04:47:54 --> Config Class Initialized
INFO - 2020-09-22 04:47:54 --> Hooks Class Initialized
DEBUG - 2020-09-22 04:47:54 --> UTF-8 Support Enabled
INFO - 2020-09-22 04:47:54 --> Utf8 Class Initialized
INFO - 2020-09-22 04:47:54 --> URI Class Initialized
DEBUG - 2020-09-22 04:47:54 --> No URI present. Default controller set.
INFO - 2020-09-22 04:47:54 --> Router Class Initialized
INFO - 2020-09-22 04:47:54 --> Output Class Initialized
INFO - 2020-09-22 04:47:54 --> Security Class Initialized
DEBUG - 2020-09-22 04:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 04:47:54 --> Input Class Initialized
INFO - 2020-09-22 04:47:54 --> Language Class Initialized
INFO - 2020-09-22 04:47:54 --> Loader Class Initialized
INFO - 2020-09-22 04:47:55 --> Helper loaded: html_helper
INFO - 2020-09-22 04:47:55 --> Helper loaded: url_helper
INFO - 2020-09-22 04:47:55 --> Helper loaded: form_helper
INFO - 2020-09-22 04:47:55 --> Database Driver Class Initialized
INFO - 2020-09-22 04:47:55 --> Form Validation Class Initialized
DEBUG - 2020-09-22 04:47:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 04:47:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 04:47:55 --> Encryption Class Initialized
INFO - 2020-09-22 04:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 04:47:55 --> Controller Class Initialized
INFO - 2020-09-22 04:47:55 --> Helper loaded: language_helper
INFO - 2020-09-22 04:47:55 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 04:47:55 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-22 04:47:55 --> Final output sent to browser
DEBUG - 2020-09-22 04:47:55 --> Total execution time: 0.9859
INFO - 2020-09-22 05:26:59 --> Config Class Initialized
INFO - 2020-09-22 05:26:59 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:26:59 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:26:59 --> Utf8 Class Initialized
INFO - 2020-09-22 05:26:59 --> URI Class Initialized
DEBUG - 2020-09-22 05:26:59 --> No URI present. Default controller set.
INFO - 2020-09-22 05:26:59 --> Router Class Initialized
INFO - 2020-09-22 05:26:59 --> Output Class Initialized
INFO - 2020-09-22 05:26:59 --> Security Class Initialized
DEBUG - 2020-09-22 05:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:26:59 --> Input Class Initialized
INFO - 2020-09-22 05:26:59 --> Language Class Initialized
INFO - 2020-09-22 05:26:59 --> Loader Class Initialized
INFO - 2020-09-22 05:26:59 --> Helper loaded: html_helper
INFO - 2020-09-22 05:26:59 --> Helper loaded: url_helper
INFO - 2020-09-22 05:26:59 --> Helper loaded: form_helper
INFO - 2020-09-22 05:26:59 --> Database Driver Class Initialized
INFO - 2020-09-22 05:26:59 --> Form Validation Class Initialized
DEBUG - 2020-09-22 05:26:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 05:26:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 05:26:59 --> Encryption Class Initialized
INFO - 2020-09-22 05:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:26:59 --> Controller Class Initialized
INFO - 2020-09-22 05:26:59 --> Helper loaded: language_helper
INFO - 2020-09-22 05:26:59 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 05:27:00 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-22 05:27:00 --> Final output sent to browser
DEBUG - 2020-09-22 05:27:00 --> Total execution time: 1.0083
INFO - 2020-09-22 05:28:52 --> Config Class Initialized
INFO - 2020-09-22 05:28:52 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:28:52 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:28:52 --> Utf8 Class Initialized
INFO - 2020-09-22 05:28:52 --> URI Class Initialized
INFO - 2020-09-22 05:28:52 --> Router Class Initialized
INFO - 2020-09-22 05:28:52 --> Output Class Initialized
INFO - 2020-09-22 05:28:52 --> Security Class Initialized
DEBUG - 2020-09-22 05:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:28:52 --> Input Class Initialized
INFO - 2020-09-22 05:28:52 --> Language Class Initialized
INFO - 2020-09-22 05:28:52 --> Loader Class Initialized
INFO - 2020-09-22 05:28:52 --> Helper loaded: html_helper
INFO - 2020-09-22 05:28:52 --> Helper loaded: url_helper
INFO - 2020-09-22 05:28:52 --> Helper loaded: form_helper
INFO - 2020-09-22 05:28:52 --> Database Driver Class Initialized
INFO - 2020-09-22 05:28:52 --> Form Validation Class Initialized
DEBUG - 2020-09-22 05:28:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 05:28:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 05:28:52 --> Encryption Class Initialized
INFO - 2020-09-22 05:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:28:52 --> Controller Class Initialized
INFO - 2020-09-22 05:28:53 --> Helper loaded: language_helper
INFO - 2020-09-22 05:28:53 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-22 05:28:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-22 05:28:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-22 05:28:53 --> Model "User" initialized
INFO - 2020-09-22 05:28:53 --> Config Class Initialized
INFO - 2020-09-22 05:28:53 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:28:53 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:28:53 --> Utf8 Class Initialized
INFO - 2020-09-22 05:28:53 --> URI Class Initialized
INFO - 2020-09-22 05:28:53 --> Router Class Initialized
INFO - 2020-09-22 05:28:53 --> Output Class Initialized
INFO - 2020-09-22 05:28:53 --> Security Class Initialized
DEBUG - 2020-09-22 05:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:28:54 --> Input Class Initialized
INFO - 2020-09-22 05:28:54 --> Language Class Initialized
INFO - 2020-09-22 05:28:54 --> Loader Class Initialized
INFO - 2020-09-22 05:28:54 --> Helper loaded: html_helper
INFO - 2020-09-22 05:28:54 --> Helper loaded: url_helper
INFO - 2020-09-22 05:28:54 --> Helper loaded: form_helper
INFO - 2020-09-22 05:28:54 --> Database Driver Class Initialized
INFO - 2020-09-22 05:28:54 --> Form Validation Class Initialized
DEBUG - 2020-09-22 05:28:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 05:28:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 05:28:54 --> Encryption Class Initialized
INFO - 2020-09-22 05:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:28:54 --> Controller Class Initialized
INFO - 2020-09-22 05:28:54 --> Helper loaded: language_helper
INFO - 2020-09-22 05:28:54 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 05:28:54 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-22 05:28:54 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-22 05:28:54 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-22 05:28:55 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-22 05:28:55 --> Final output sent to browser
DEBUG - 2020-09-22 05:28:55 --> Total execution time: 1.6550
INFO - 2020-09-22 05:28:59 --> Config Class Initialized
INFO - 2020-09-22 05:28:59 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:28:59 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:28:59 --> Utf8 Class Initialized
INFO - 2020-09-22 05:28:59 --> URI Class Initialized
INFO - 2020-09-22 05:28:59 --> Router Class Initialized
INFO - 2020-09-22 05:28:59 --> Output Class Initialized
INFO - 2020-09-22 05:29:00 --> Security Class Initialized
DEBUG - 2020-09-22 05:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:29:00 --> Input Class Initialized
INFO - 2020-09-22 05:29:00 --> Language Class Initialized
INFO - 2020-09-22 05:29:00 --> Loader Class Initialized
INFO - 2020-09-22 05:29:00 --> Helper loaded: html_helper
INFO - 2020-09-22 05:29:00 --> Helper loaded: url_helper
INFO - 2020-09-22 05:29:00 --> Helper loaded: form_helper
INFO - 2020-09-22 05:29:00 --> Database Driver Class Initialized
INFO - 2020-09-22 05:29:00 --> Form Validation Class Initialized
DEBUG - 2020-09-22 05:29:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 05:29:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 05:29:00 --> Encryption Class Initialized
INFO - 2020-09-22 05:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:29:00 --> Controller Class Initialized
INFO - 2020-09-22 05:29:00 --> Helper loaded: language_helper
INFO - 2020-09-22 05:29:00 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 05:29:00 --> Final output sent to browser
DEBUG - 2020-09-22 05:29:00 --> Total execution time: 1.0929
INFO - 2020-09-22 05:29:01 --> Config Class Initialized
INFO - 2020-09-22 05:29:01 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:29:01 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:29:01 --> Utf8 Class Initialized
INFO - 2020-09-22 05:29:01 --> URI Class Initialized
DEBUG - 2020-09-22 05:29:01 --> No URI present. Default controller set.
INFO - 2020-09-22 05:29:01 --> Router Class Initialized
INFO - 2020-09-22 05:29:01 --> Output Class Initialized
INFO - 2020-09-22 05:29:01 --> Security Class Initialized
DEBUG - 2020-09-22 05:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:29:01 --> Input Class Initialized
INFO - 2020-09-22 05:29:01 --> Language Class Initialized
INFO - 2020-09-22 05:29:01 --> Loader Class Initialized
INFO - 2020-09-22 05:29:01 --> Helper loaded: html_helper
INFO - 2020-09-22 05:29:01 --> Helper loaded: url_helper
INFO - 2020-09-22 05:29:01 --> Helper loaded: form_helper
INFO - 2020-09-22 05:29:01 --> Database Driver Class Initialized
INFO - 2020-09-22 05:29:02 --> Form Validation Class Initialized
DEBUG - 2020-09-22 05:29:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 05:29:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 05:29:02 --> Encryption Class Initialized
INFO - 2020-09-22 05:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:29:02 --> Controller Class Initialized
INFO - 2020-09-22 05:29:02 --> Helper loaded: language_helper
INFO - 2020-09-22 05:29:02 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 05:29:02 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-22 05:29:02 --> Final output sent to browser
DEBUG - 2020-09-22 05:29:02 --> Total execution time: 1.0790
INFO - 2020-09-22 05:29:09 --> Config Class Initialized
INFO - 2020-09-22 05:29:09 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:29:09 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:29:09 --> Utf8 Class Initialized
INFO - 2020-09-22 05:29:09 --> URI Class Initialized
INFO - 2020-09-22 05:29:09 --> Router Class Initialized
INFO - 2020-09-22 05:29:09 --> Output Class Initialized
INFO - 2020-09-22 05:29:09 --> Security Class Initialized
DEBUG - 2020-09-22 05:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:29:09 --> Input Class Initialized
INFO - 2020-09-22 05:29:09 --> Language Class Initialized
INFO - 2020-09-22 05:29:09 --> Loader Class Initialized
INFO - 2020-09-22 05:29:09 --> Helper loaded: html_helper
INFO - 2020-09-22 05:29:09 --> Helper loaded: url_helper
INFO - 2020-09-22 05:29:09 --> Helper loaded: form_helper
INFO - 2020-09-22 05:29:09 --> Database Driver Class Initialized
INFO - 2020-09-22 05:29:10 --> Form Validation Class Initialized
DEBUG - 2020-09-22 05:29:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 05:29:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 05:29:10 --> Encryption Class Initialized
INFO - 2020-09-22 05:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:29:10 --> Controller Class Initialized
INFO - 2020-09-22 05:29:10 --> Helper loaded: language_helper
INFO - 2020-09-22 05:29:10 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-22 05:29:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-22 05:29:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-22 05:29:10 --> Model "User" initialized
INFO - 2020-09-22 05:29:11 --> Config Class Initialized
INFO - 2020-09-22 05:29:11 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:29:11 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:29:11 --> Utf8 Class Initialized
INFO - 2020-09-22 05:29:11 --> URI Class Initialized
INFO - 2020-09-22 05:29:11 --> Router Class Initialized
INFO - 2020-09-22 05:29:11 --> Output Class Initialized
INFO - 2020-09-22 05:29:11 --> Security Class Initialized
DEBUG - 2020-09-22 05:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:29:11 --> Input Class Initialized
INFO - 2020-09-22 05:29:11 --> Language Class Initialized
INFO - 2020-09-22 05:29:11 --> Loader Class Initialized
INFO - 2020-09-22 05:29:11 --> Helper loaded: html_helper
INFO - 2020-09-22 05:29:11 --> Helper loaded: url_helper
INFO - 2020-09-22 05:29:11 --> Helper loaded: form_helper
INFO - 2020-09-22 05:29:11 --> Database Driver Class Initialized
INFO - 2020-09-22 05:29:11 --> Form Validation Class Initialized
DEBUG - 2020-09-22 05:29:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 05:29:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 05:29:11 --> Encryption Class Initialized
INFO - 2020-09-22 05:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:29:12 --> Controller Class Initialized
INFO - 2020-09-22 05:29:12 --> Helper loaded: language_helper
INFO - 2020-09-22 05:29:12 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 05:29:12 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-22 05:29:12 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-22 05:29:12 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-22 05:29:12 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-22 05:29:12 --> Final output sent to browser
DEBUG - 2020-09-22 05:29:12 --> Total execution time: 1.1070
INFO - 2020-09-22 05:29:15 --> Config Class Initialized
INFO - 2020-09-22 05:29:15 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:29:15 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:29:15 --> Utf8 Class Initialized
INFO - 2020-09-22 05:29:15 --> URI Class Initialized
INFO - 2020-09-22 05:29:15 --> Router Class Initialized
INFO - 2020-09-22 05:29:15 --> Output Class Initialized
INFO - 2020-09-22 05:29:15 --> Security Class Initialized
DEBUG - 2020-09-22 05:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:29:15 --> Input Class Initialized
INFO - 2020-09-22 05:29:15 --> Language Class Initialized
INFO - 2020-09-22 05:29:15 --> Loader Class Initialized
INFO - 2020-09-22 05:29:15 --> Helper loaded: html_helper
INFO - 2020-09-22 05:29:15 --> Helper loaded: url_helper
INFO - 2020-09-22 05:29:15 --> Helper loaded: form_helper
INFO - 2020-09-22 05:29:15 --> Database Driver Class Initialized
INFO - 2020-09-22 05:29:15 --> Form Validation Class Initialized
DEBUG - 2020-09-22 05:29:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 05:29:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 05:29:15 --> Encryption Class Initialized
INFO - 2020-09-22 05:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:29:15 --> Controller Class Initialized
INFO - 2020-09-22 05:29:16 --> Helper loaded: language_helper
INFO - 2020-09-22 05:29:16 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 05:29:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-22 05:29:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-22 05:29:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-22 05:29:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-22 05:29:16 --> Final output sent to browser
DEBUG - 2020-09-22 05:29:16 --> Total execution time: 1.4729
INFO - 2020-09-22 05:29:18 --> Config Class Initialized
INFO - 2020-09-22 05:29:18 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:29:18 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:29:18 --> Utf8 Class Initialized
INFO - 2020-09-22 05:29:18 --> URI Class Initialized
INFO - 2020-09-22 05:29:18 --> Router Class Initialized
INFO - 2020-09-22 05:29:18 --> Output Class Initialized
INFO - 2020-09-22 05:29:18 --> Security Class Initialized
DEBUG - 2020-09-22 05:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:29:18 --> Input Class Initialized
INFO - 2020-09-22 05:29:19 --> Language Class Initialized
INFO - 2020-09-22 05:29:19 --> Loader Class Initialized
INFO - 2020-09-22 05:29:19 --> Helper loaded: html_helper
INFO - 2020-09-22 05:29:19 --> Helper loaded: url_helper
INFO - 2020-09-22 05:29:19 --> Helper loaded: form_helper
INFO - 2020-09-22 05:29:19 --> Database Driver Class Initialized
INFO - 2020-09-22 05:29:19 --> Form Validation Class Initialized
DEBUG - 2020-09-22 05:29:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 05:29:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 05:29:19 --> Encryption Class Initialized
INFO - 2020-09-22 05:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:29:19 --> Controller Class Initialized
INFO - 2020-09-22 05:29:19 --> Helper loaded: language_helper
INFO - 2020-09-22 05:29:19 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 05:29:19 --> Model "Sale_model" initialized
INFO - 2020-09-22 05:29:19 --> Final output sent to browser
DEBUG - 2020-09-22 05:29:19 --> Total execution time: 1.1001
INFO - 2020-09-22 05:29:26 --> Config Class Initialized
INFO - 2020-09-22 05:29:26 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:29:26 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:29:26 --> Utf8 Class Initialized
INFO - 2020-09-22 05:29:26 --> URI Class Initialized
INFO - 2020-09-22 05:29:26 --> Router Class Initialized
INFO - 2020-09-22 05:29:26 --> Output Class Initialized
INFO - 2020-09-22 05:29:27 --> Security Class Initialized
DEBUG - 2020-09-22 05:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:29:27 --> Input Class Initialized
INFO - 2020-09-22 05:29:27 --> Language Class Initialized
INFO - 2020-09-22 05:29:27 --> Loader Class Initialized
INFO - 2020-09-22 05:29:27 --> Helper loaded: html_helper
INFO - 2020-09-22 05:29:27 --> Helper loaded: url_helper
INFO - 2020-09-22 05:29:27 --> Helper loaded: form_helper
INFO - 2020-09-22 05:29:27 --> Database Driver Class Initialized
INFO - 2020-09-22 05:29:27 --> Form Validation Class Initialized
DEBUG - 2020-09-22 05:29:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 05:29:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 05:29:27 --> Encryption Class Initialized
INFO - 2020-09-22 05:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:29:27 --> Controller Class Initialized
INFO - 2020-09-22 05:29:27 --> Helper loaded: language_helper
INFO - 2020-09-22 05:29:27 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 05:29:27 --> Model "Sale_model" initialized
INFO - 2020-09-22 05:29:27 --> Final output sent to browser
DEBUG - 2020-09-22 05:29:27 --> Total execution time: 1.0141
INFO - 2020-09-22 05:31:02 --> Config Class Initialized
INFO - 2020-09-22 05:31:02 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:31:02 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:31:02 --> Utf8 Class Initialized
INFO - 2020-09-22 05:31:02 --> URI Class Initialized
INFO - 2020-09-22 05:31:03 --> Router Class Initialized
INFO - 2020-09-22 05:31:03 --> Output Class Initialized
INFO - 2020-09-22 05:31:03 --> Security Class Initialized
DEBUG - 2020-09-22 05:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:31:03 --> Input Class Initialized
INFO - 2020-09-22 05:31:03 --> Language Class Initialized
INFO - 2020-09-22 05:31:03 --> Loader Class Initialized
INFO - 2020-09-22 05:31:03 --> Helper loaded: html_helper
INFO - 2020-09-22 05:31:03 --> Helper loaded: url_helper
INFO - 2020-09-22 05:31:03 --> Helper loaded: form_helper
INFO - 2020-09-22 05:31:03 --> Database Driver Class Initialized
INFO - 2020-09-22 05:31:03 --> Form Validation Class Initialized
DEBUG - 2020-09-22 05:31:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 05:31:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 05:31:03 --> Encryption Class Initialized
INFO - 2020-09-22 05:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:31:03 --> Controller Class Initialized
INFO - 2020-09-22 05:31:03 --> Helper loaded: language_helper
INFO - 2020-09-22 05:31:03 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 05:31:03 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-22 05:31:03 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-22 05:31:03 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment.php
INFO - 2020-09-22 05:31:03 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-22 05:31:03 --> Final output sent to browser
DEBUG - 2020-09-22 05:31:03 --> Total execution time: 1.1367
INFO - 2020-09-22 05:31:04 --> Config Class Initialized
INFO - 2020-09-22 05:31:04 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:31:04 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:31:04 --> Utf8 Class Initialized
INFO - 2020-09-22 05:31:04 --> URI Class Initialized
INFO - 2020-09-22 05:31:04 --> Router Class Initialized
INFO - 2020-09-22 05:31:04 --> Output Class Initialized
INFO - 2020-09-22 05:31:04 --> Security Class Initialized
DEBUG - 2020-09-22 05:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:31:04 --> Input Class Initialized
INFO - 2020-09-22 05:31:04 --> Language Class Initialized
INFO - 2020-09-22 05:31:05 --> Loader Class Initialized
INFO - 2020-09-22 05:31:05 --> Helper loaded: html_helper
INFO - 2020-09-22 05:31:05 --> Helper loaded: url_helper
INFO - 2020-09-22 05:31:05 --> Helper loaded: form_helper
INFO - 2020-09-22 05:31:05 --> Database Driver Class Initialized
INFO - 2020-09-22 05:31:05 --> Form Validation Class Initialized
DEBUG - 2020-09-22 05:31:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 05:31:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 05:31:05 --> Encryption Class Initialized
INFO - 2020-09-22 05:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:31:05 --> Controller Class Initialized
INFO - 2020-09-22 05:31:05 --> Helper loaded: language_helper
INFO - 2020-09-22 05:31:05 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 05:31:05 --> Final output sent to browser
DEBUG - 2020-09-22 05:31:05 --> Total execution time: 0.9878
INFO - 2020-09-22 05:38:01 --> Config Class Initialized
INFO - 2020-09-22 05:38:01 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:38:01 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:38:01 --> Utf8 Class Initialized
INFO - 2020-09-22 05:38:01 --> URI Class Initialized
INFO - 2020-09-22 05:38:01 --> Router Class Initialized
INFO - 2020-09-22 05:38:02 --> Output Class Initialized
INFO - 2020-09-22 05:38:02 --> Security Class Initialized
DEBUG - 2020-09-22 05:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:38:02 --> Input Class Initialized
INFO - 2020-09-22 05:38:02 --> Language Class Initialized
INFO - 2020-09-22 05:38:02 --> Loader Class Initialized
INFO - 2020-09-22 05:38:02 --> Helper loaded: html_helper
INFO - 2020-09-22 05:38:02 --> Helper loaded: url_helper
INFO - 2020-09-22 05:38:02 --> Helper loaded: form_helper
INFO - 2020-09-22 05:38:02 --> Database Driver Class Initialized
INFO - 2020-09-22 05:38:02 --> Form Validation Class Initialized
DEBUG - 2020-09-22 05:38:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 05:38:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 05:38:02 --> Encryption Class Initialized
INFO - 2020-09-22 05:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:38:02 --> Controller Class Initialized
INFO - 2020-09-22 05:38:02 --> Helper loaded: language_helper
INFO - 2020-09-22 05:38:02 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 05:38:02 --> Final output sent to browser
DEBUG - 2020-09-22 05:38:02 --> Total execution time: 1.0178
INFO - 2020-09-22 05:38:03 --> Config Class Initialized
INFO - 2020-09-22 05:38:03 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:38:03 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:38:03 --> Utf8 Class Initialized
INFO - 2020-09-22 05:38:03 --> URI Class Initialized
DEBUG - 2020-09-22 05:38:03 --> No URI present. Default controller set.
INFO - 2020-09-22 05:38:03 --> Router Class Initialized
INFO - 2020-09-22 05:38:03 --> Output Class Initialized
INFO - 2020-09-22 05:38:03 --> Security Class Initialized
DEBUG - 2020-09-22 05:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:38:03 --> Input Class Initialized
INFO - 2020-09-22 05:38:03 --> Language Class Initialized
INFO - 2020-09-22 05:38:03 --> Loader Class Initialized
INFO - 2020-09-22 05:38:03 --> Helper loaded: html_helper
INFO - 2020-09-22 05:38:03 --> Helper loaded: url_helper
INFO - 2020-09-22 05:38:03 --> Helper loaded: form_helper
INFO - 2020-09-22 05:38:03 --> Database Driver Class Initialized
INFO - 2020-09-22 05:38:04 --> Form Validation Class Initialized
DEBUG - 2020-09-22 05:38:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 05:38:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 05:38:04 --> Encryption Class Initialized
INFO - 2020-09-22 05:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:38:04 --> Controller Class Initialized
INFO - 2020-09-22 05:38:04 --> Helper loaded: language_helper
INFO - 2020-09-22 05:38:04 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 05:38:04 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-22 05:38:04 --> Final output sent to browser
DEBUG - 2020-09-22 05:38:04 --> Total execution time: 1.0519
INFO - 2020-09-22 05:38:19 --> Config Class Initialized
INFO - 2020-09-22 05:38:19 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:38:19 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:38:19 --> Utf8 Class Initialized
INFO - 2020-09-22 05:38:19 --> URI Class Initialized
INFO - 2020-09-22 05:38:19 --> Router Class Initialized
INFO - 2020-09-22 05:38:19 --> Output Class Initialized
INFO - 2020-09-22 05:38:19 --> Security Class Initialized
DEBUG - 2020-09-22 05:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:38:19 --> Input Class Initialized
INFO - 2020-09-22 05:38:19 --> Language Class Initialized
INFO - 2020-09-22 05:38:19 --> Loader Class Initialized
INFO - 2020-09-22 05:38:19 --> Helper loaded: html_helper
INFO - 2020-09-22 05:38:19 --> Helper loaded: url_helper
INFO - 2020-09-22 05:38:19 --> Helper loaded: form_helper
INFO - 2020-09-22 05:38:19 --> Database Driver Class Initialized
INFO - 2020-09-22 05:38:19 --> Form Validation Class Initialized
DEBUG - 2020-09-22 05:38:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 05:38:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 05:38:20 --> Encryption Class Initialized
INFO - 2020-09-22 05:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:38:20 --> Controller Class Initialized
INFO - 2020-09-22 05:38:20 --> Helper loaded: language_helper
INFO - 2020-09-22 05:38:20 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-22 05:38:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-22 05:38:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-22 05:38:20 --> Model "User" initialized
INFO - 2020-09-22 05:38:20 --> Config Class Initialized
INFO - 2020-09-22 05:38:20 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:38:20 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:38:20 --> Utf8 Class Initialized
INFO - 2020-09-22 05:38:21 --> URI Class Initialized
INFO - 2020-09-22 05:38:21 --> Router Class Initialized
INFO - 2020-09-22 05:38:21 --> Output Class Initialized
INFO - 2020-09-22 05:38:21 --> Security Class Initialized
DEBUG - 2020-09-22 05:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:38:21 --> Input Class Initialized
INFO - 2020-09-22 05:38:21 --> Language Class Initialized
INFO - 2020-09-22 05:38:21 --> Loader Class Initialized
INFO - 2020-09-22 05:38:21 --> Helper loaded: html_helper
INFO - 2020-09-22 05:38:21 --> Helper loaded: url_helper
INFO - 2020-09-22 05:38:21 --> Helper loaded: form_helper
INFO - 2020-09-22 05:38:21 --> Database Driver Class Initialized
INFO - 2020-09-22 05:38:21 --> Form Validation Class Initialized
DEBUG - 2020-09-22 05:38:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 05:38:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 05:38:21 --> Encryption Class Initialized
INFO - 2020-09-22 05:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:38:21 --> Controller Class Initialized
INFO - 2020-09-22 05:38:21 --> Helper loaded: language_helper
INFO - 2020-09-22 05:38:21 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 05:38:21 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-22 05:38:21 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-22 05:38:21 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-22 05:38:21 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-22 05:38:21 --> Final output sent to browser
DEBUG - 2020-09-22 05:38:21 --> Total execution time: 1.0608
INFO - 2020-09-22 06:46:57 --> Config Class Initialized
INFO - 2020-09-22 06:46:57 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:46:57 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:46:57 --> Utf8 Class Initialized
INFO - 2020-09-22 06:46:57 --> URI Class Initialized
INFO - 2020-09-22 06:46:57 --> Router Class Initialized
INFO - 2020-09-22 06:46:57 --> Output Class Initialized
INFO - 2020-09-22 06:46:57 --> Security Class Initialized
DEBUG - 2020-09-22 06:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:46:57 --> Input Class Initialized
INFO - 2020-09-22 06:46:57 --> Language Class Initialized
INFO - 2020-09-22 06:46:57 --> Loader Class Initialized
INFO - 2020-09-22 06:46:57 --> Helper loaded: html_helper
INFO - 2020-09-22 06:46:57 --> Helper loaded: url_helper
INFO - 2020-09-22 06:46:57 --> Helper loaded: form_helper
INFO - 2020-09-22 06:46:58 --> Database Driver Class Initialized
INFO - 2020-09-22 06:46:58 --> Form Validation Class Initialized
DEBUG - 2020-09-22 06:46:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 06:46:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 06:46:58 --> Encryption Class Initialized
INFO - 2020-09-22 06:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:46:58 --> Controller Class Initialized
INFO - 2020-09-22 06:46:58 --> Helper loaded: language_helper
INFO - 2020-09-22 06:46:58 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 06:46:58 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-22 06:46:58 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-22 06:46:58 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\installation.php
INFO - 2020-09-22 06:46:58 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-22 06:46:58 --> Final output sent to browser
DEBUG - 2020-09-22 06:46:58 --> Total execution time: 1.4596
INFO - 2020-09-22 06:47:22 --> Config Class Initialized
INFO - 2020-09-22 06:47:22 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:47:22 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:47:23 --> Utf8 Class Initialized
INFO - 2020-09-22 06:47:23 --> URI Class Initialized
INFO - 2020-09-22 06:47:23 --> Router Class Initialized
INFO - 2020-09-22 06:47:23 --> Output Class Initialized
INFO - 2020-09-22 06:47:23 --> Security Class Initialized
DEBUG - 2020-09-22 06:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:47:23 --> Input Class Initialized
INFO - 2020-09-22 06:47:23 --> Language Class Initialized
INFO - 2020-09-22 06:47:23 --> Loader Class Initialized
INFO - 2020-09-22 06:47:23 --> Helper loaded: html_helper
INFO - 2020-09-22 06:47:23 --> Helper loaded: url_helper
INFO - 2020-09-22 06:47:23 --> Helper loaded: form_helper
INFO - 2020-09-22 06:47:23 --> Database Driver Class Initialized
INFO - 2020-09-22 06:47:23 --> Form Validation Class Initialized
DEBUG - 2020-09-22 06:47:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 06:47:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 06:47:23 --> Encryption Class Initialized
INFO - 2020-09-22 06:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:47:23 --> Controller Class Initialized
INFO - 2020-09-22 06:47:23 --> Helper loaded: language_helper
INFO - 2020-09-22 06:47:23 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 06:47:24 --> Model "Installation_model" initialized
INFO - 2020-09-22 06:47:24 --> Final output sent to browser
DEBUG - 2020-09-22 06:47:24 --> Total execution time: 1.2610
INFO - 2020-09-22 06:47:26 --> Config Class Initialized
INFO - 2020-09-22 06:47:26 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:47:26 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:47:26 --> Utf8 Class Initialized
INFO - 2020-09-22 06:47:26 --> URI Class Initialized
INFO - 2020-09-22 06:47:26 --> Router Class Initialized
INFO - 2020-09-22 06:47:26 --> Output Class Initialized
INFO - 2020-09-22 06:47:26 --> Security Class Initialized
DEBUG - 2020-09-22 06:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:47:26 --> Input Class Initialized
INFO - 2020-09-22 06:47:27 --> Language Class Initialized
INFO - 2020-09-22 06:47:27 --> Loader Class Initialized
INFO - 2020-09-22 06:47:27 --> Helper loaded: html_helper
INFO - 2020-09-22 06:47:27 --> Helper loaded: url_helper
INFO - 2020-09-22 06:47:27 --> Helper loaded: form_helper
INFO - 2020-09-22 06:47:27 --> Database Driver Class Initialized
INFO - 2020-09-22 06:47:27 --> Form Validation Class Initialized
DEBUG - 2020-09-22 06:47:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 06:47:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 06:47:27 --> Encryption Class Initialized
INFO - 2020-09-22 06:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:47:27 --> Controller Class Initialized
INFO - 2020-09-22 06:47:27 --> Helper loaded: language_helper
INFO - 2020-09-22 06:47:27 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 06:47:27 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-22 06:47:27 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-22 06:47:27 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-22 06:47:27 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-22 06:47:27 --> Final output sent to browser
DEBUG - 2020-09-22 06:47:27 --> Total execution time: 1.1182
INFO - 2020-09-22 06:47:31 --> Config Class Initialized
INFO - 2020-09-22 06:47:31 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:47:31 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:47:31 --> Utf8 Class Initialized
INFO - 2020-09-22 06:47:31 --> URI Class Initialized
INFO - 2020-09-22 06:47:31 --> Router Class Initialized
INFO - 2020-09-22 06:47:31 --> Output Class Initialized
INFO - 2020-09-22 06:47:31 --> Security Class Initialized
DEBUG - 2020-09-22 06:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:47:31 --> Input Class Initialized
INFO - 2020-09-22 06:47:31 --> Language Class Initialized
INFO - 2020-09-22 06:47:31 --> Loader Class Initialized
INFO - 2020-09-22 06:47:31 --> Helper loaded: html_helper
INFO - 2020-09-22 06:47:31 --> Helper loaded: url_helper
INFO - 2020-09-22 06:47:31 --> Helper loaded: form_helper
INFO - 2020-09-22 06:47:31 --> Database Driver Class Initialized
INFO - 2020-09-22 06:47:31 --> Form Validation Class Initialized
DEBUG - 2020-09-22 06:47:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 06:47:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 06:47:31 --> Encryption Class Initialized
INFO - 2020-09-22 06:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:47:31 --> Controller Class Initialized
INFO - 2020-09-22 06:47:31 --> Helper loaded: language_helper
INFO - 2020-09-22 06:47:32 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 06:47:32 --> Model "Sale_model" initialized
INFO - 2020-09-22 06:47:32 --> Final output sent to browser
DEBUG - 2020-09-22 06:47:32 --> Total execution time: 1.0540
INFO - 2020-09-22 06:47:44 --> Config Class Initialized
INFO - 2020-09-22 06:47:44 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:47:44 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:47:44 --> Utf8 Class Initialized
INFO - 2020-09-22 06:47:44 --> URI Class Initialized
INFO - 2020-09-22 06:47:44 --> Router Class Initialized
INFO - 2020-09-22 06:47:44 --> Output Class Initialized
INFO - 2020-09-22 06:47:44 --> Security Class Initialized
DEBUG - 2020-09-22 06:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:47:44 --> Input Class Initialized
INFO - 2020-09-22 06:47:44 --> Language Class Initialized
INFO - 2020-09-22 06:47:44 --> Loader Class Initialized
INFO - 2020-09-22 06:47:44 --> Helper loaded: html_helper
INFO - 2020-09-22 06:47:44 --> Helper loaded: url_helper
INFO - 2020-09-22 06:47:44 --> Helper loaded: form_helper
INFO - 2020-09-22 06:47:44 --> Database Driver Class Initialized
INFO - 2020-09-22 06:47:44 --> Form Validation Class Initialized
DEBUG - 2020-09-22 06:47:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 06:47:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 06:47:44 --> Encryption Class Initialized
INFO - 2020-09-22 06:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:47:44 --> Controller Class Initialized
INFO - 2020-09-22 06:47:44 --> Helper loaded: language_helper
INFO - 2020-09-22 06:47:44 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 06:47:45 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-22 06:47:45 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-22 06:47:45 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment.php
INFO - 2020-09-22 06:47:45 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-22 06:47:45 --> Final output sent to browser
DEBUG - 2020-09-22 06:47:45 --> Total execution time: 1.1060
INFO - 2020-09-22 06:47:45 --> Config Class Initialized
INFO - 2020-09-22 06:47:45 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:47:45 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:47:45 --> Utf8 Class Initialized
INFO - 2020-09-22 06:47:45 --> URI Class Initialized
INFO - 2020-09-22 06:47:45 --> Router Class Initialized
INFO - 2020-09-22 06:47:45 --> Output Class Initialized
INFO - 2020-09-22 06:47:46 --> Security Class Initialized
DEBUG - 2020-09-22 06:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:47:46 --> Input Class Initialized
INFO - 2020-09-22 06:47:46 --> Language Class Initialized
INFO - 2020-09-22 06:47:46 --> Loader Class Initialized
INFO - 2020-09-22 06:47:46 --> Helper loaded: html_helper
INFO - 2020-09-22 06:47:46 --> Helper loaded: url_helper
INFO - 2020-09-22 06:47:46 --> Helper loaded: form_helper
INFO - 2020-09-22 06:47:46 --> Database Driver Class Initialized
INFO - 2020-09-22 06:47:46 --> Form Validation Class Initialized
DEBUG - 2020-09-22 06:47:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 06:47:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 06:47:46 --> Encryption Class Initialized
INFO - 2020-09-22 06:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:47:46 --> Controller Class Initialized
INFO - 2020-09-22 06:47:46 --> Helper loaded: language_helper
INFO - 2020-09-22 06:47:46 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 06:47:46 --> Final output sent to browser
DEBUG - 2020-09-22 06:47:46 --> Total execution time: 0.9897
INFO - 2020-09-22 06:48:15 --> Config Class Initialized
INFO - 2020-09-22 06:48:15 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:48:15 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:48:15 --> Utf8 Class Initialized
INFO - 2020-09-22 06:48:15 --> URI Class Initialized
INFO - 2020-09-22 06:48:15 --> Router Class Initialized
INFO - 2020-09-22 06:48:15 --> Output Class Initialized
INFO - 2020-09-22 06:48:15 --> Security Class Initialized
DEBUG - 2020-09-22 06:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:48:15 --> Input Class Initialized
INFO - 2020-09-22 06:48:15 --> Language Class Initialized
INFO - 2020-09-22 06:48:15 --> Loader Class Initialized
INFO - 2020-09-22 06:48:15 --> Helper loaded: html_helper
INFO - 2020-09-22 06:48:15 --> Helper loaded: url_helper
INFO - 2020-09-22 06:48:15 --> Helper loaded: form_helper
INFO - 2020-09-22 06:48:15 --> Database Driver Class Initialized
INFO - 2020-09-22 06:48:15 --> Form Validation Class Initialized
DEBUG - 2020-09-22 06:48:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 06:48:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 06:48:15 --> Encryption Class Initialized
INFO - 2020-09-22 06:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:48:15 --> Controller Class Initialized
INFO - 2020-09-22 06:48:16 --> Helper loaded: language_helper
INFO - 2020-09-22 06:48:16 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 06:48:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-22 06:48:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-22 06:48:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-22 06:48:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-22 06:48:16 --> Final output sent to browser
DEBUG - 2020-09-22 06:48:16 --> Total execution time: 1.0944
INFO - 2020-09-22 06:48:24 --> Config Class Initialized
INFO - 2020-09-22 06:48:24 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:48:24 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:48:24 --> Utf8 Class Initialized
INFO - 2020-09-22 06:48:24 --> URI Class Initialized
INFO - 2020-09-22 06:48:24 --> Router Class Initialized
INFO - 2020-09-22 06:48:24 --> Output Class Initialized
INFO - 2020-09-22 06:48:24 --> Security Class Initialized
DEBUG - 2020-09-22 06:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:48:24 --> Input Class Initialized
INFO - 2020-09-22 06:48:25 --> Language Class Initialized
INFO - 2020-09-22 06:48:25 --> Loader Class Initialized
INFO - 2020-09-22 06:48:25 --> Helper loaded: html_helper
INFO - 2020-09-22 06:48:25 --> Helper loaded: url_helper
INFO - 2020-09-22 06:48:25 --> Helper loaded: form_helper
INFO - 2020-09-22 06:48:25 --> Database Driver Class Initialized
INFO - 2020-09-22 06:48:25 --> Form Validation Class Initialized
DEBUG - 2020-09-22 06:48:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 06:48:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 06:48:25 --> Encryption Class Initialized
INFO - 2020-09-22 06:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:48:25 --> Controller Class Initialized
INFO - 2020-09-22 06:48:25 --> Helper loaded: language_helper
INFO - 2020-09-22 06:48:25 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 06:48:25 --> Model "Sale_model" initialized
INFO - 2020-09-22 06:48:25 --> Final output sent to browser
DEBUG - 2020-09-22 06:48:25 --> Total execution time: 0.9789
INFO - 2020-09-22 06:48:37 --> Config Class Initialized
INFO - 2020-09-22 06:48:37 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:48:37 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:48:37 --> Utf8 Class Initialized
INFO - 2020-09-22 06:48:37 --> URI Class Initialized
INFO - 2020-09-22 06:48:37 --> Router Class Initialized
INFO - 2020-09-22 06:48:37 --> Output Class Initialized
INFO - 2020-09-22 06:48:37 --> Security Class Initialized
DEBUG - 2020-09-22 06:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:48:37 --> Input Class Initialized
INFO - 2020-09-22 06:48:37 --> Language Class Initialized
INFO - 2020-09-22 06:48:37 --> Loader Class Initialized
INFO - 2020-09-22 06:48:37 --> Helper loaded: html_helper
INFO - 2020-09-22 06:48:37 --> Helper loaded: url_helper
INFO - 2020-09-22 06:48:37 --> Helper loaded: form_helper
INFO - 2020-09-22 06:48:37 --> Database Driver Class Initialized
INFO - 2020-09-22 06:48:37 --> Form Validation Class Initialized
DEBUG - 2020-09-22 06:48:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 06:48:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 06:48:37 --> Encryption Class Initialized
INFO - 2020-09-22 06:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:48:37 --> Controller Class Initialized
INFO - 2020-09-22 06:48:37 --> Helper loaded: language_helper
INFO - 2020-09-22 06:48:37 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 06:48:37 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-22 06:48:38 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-22 06:48:38 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment_custom.php
INFO - 2020-09-22 06:48:38 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-22 06:48:38 --> Final output sent to browser
DEBUG - 2020-09-22 06:48:38 --> Total execution time: 1.1700
INFO - 2020-09-22 06:48:42 --> Config Class Initialized
INFO - 2020-09-22 06:48:42 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:48:42 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:48:42 --> Utf8 Class Initialized
INFO - 2020-09-22 06:48:42 --> URI Class Initialized
INFO - 2020-09-22 06:48:42 --> Router Class Initialized
INFO - 2020-09-22 06:48:42 --> Output Class Initialized
INFO - 2020-09-22 06:48:42 --> Security Class Initialized
DEBUG - 2020-09-22 06:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:48:42 --> Input Class Initialized
INFO - 2020-09-22 06:48:42 --> Language Class Initialized
INFO - 2020-09-22 06:48:42 --> Loader Class Initialized
INFO - 2020-09-22 06:48:42 --> Helper loaded: html_helper
INFO - 2020-09-22 06:48:42 --> Helper loaded: url_helper
INFO - 2020-09-22 06:48:42 --> Config Class Initialized
INFO - 2020-09-22 06:48:42 --> Hooks Class Initialized
INFO - 2020-09-22 06:48:42 --> Helper loaded: form_helper
INFO - 2020-09-22 06:48:42 --> Database Driver Class Initialized
DEBUG - 2020-09-22 06:48:42 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:48:42 --> Utf8 Class Initialized
INFO - 2020-09-22 06:48:42 --> URI Class Initialized
INFO - 2020-09-22 06:48:42 --> Form Validation Class Initialized
INFO - 2020-09-22 06:48:42 --> Router Class Initialized
INFO - 2020-09-22 06:48:42 --> Output Class Initialized
DEBUG - 2020-09-22 06:48:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 06:48:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 06:48:42 --> Encryption Class Initialized
INFO - 2020-09-22 06:48:42 --> Security Class Initialized
DEBUG - 2020-09-22 06:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:48:42 --> Controller Class Initialized
INFO - 2020-09-22 06:48:42 --> Input Class Initialized
INFO - 2020-09-22 06:48:42 --> Helper loaded: language_helper
INFO - 2020-09-22 06:48:42 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 06:48:42 --> Language Class Initialized
INFO - 2020-09-22 06:48:42 --> Loader Class Initialized
INFO - 2020-09-22 06:48:42 --> Helper loaded: html_helper
INFO - 2020-09-22 06:48:42 --> Helper loaded: url_helper
INFO - 2020-09-22 06:48:43 --> Helper loaded: form_helper
INFO - 2020-09-22 06:48:43 --> Database Driver Class Initialized
INFO - 2020-09-22 06:48:43 --> Form Validation Class Initialized
DEBUG - 2020-09-22 06:48:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 06:48:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 06:48:43 --> Encryption Class Initialized
INFO - 2020-09-22 06:48:45 --> Final output sent to browser
DEBUG - 2020-09-22 06:48:45 --> Total execution time: 3.1677
INFO - 2020-09-22 06:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:48:45 --> Controller Class Initialized
INFO - 2020-09-22 06:48:45 --> Helper loaded: language_helper
INFO - 2020-09-22 06:48:45 --> Language file loaded: language/english/content_lang.php
ERROR - 2020-09-22 06:48:45 --> Severity: Notice --> Undefined index: selected_order_id C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\controllers\Payment.php 184
INFO - 2020-09-22 06:48:47 --> Final output sent to browser
DEBUG - 2020-09-22 06:48:47 --> Total execution time: 4.8533
INFO - 2020-09-22 06:49:42 --> Config Class Initialized
INFO - 2020-09-22 06:49:42 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:49:42 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:49:42 --> Utf8 Class Initialized
INFO - 2020-09-22 06:49:42 --> URI Class Initialized
INFO - 2020-09-22 06:49:42 --> Router Class Initialized
INFO - 2020-09-22 06:49:42 --> Output Class Initialized
INFO - 2020-09-22 06:49:42 --> Security Class Initialized
DEBUG - 2020-09-22 06:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:49:42 --> Input Class Initialized
INFO - 2020-09-22 06:49:42 --> Language Class Initialized
INFO - 2020-09-22 06:49:42 --> Loader Class Initialized
INFO - 2020-09-22 06:49:42 --> Helper loaded: html_helper
INFO - 2020-09-22 06:49:42 --> Helper loaded: url_helper
INFO - 2020-09-22 06:49:42 --> Helper loaded: form_helper
INFO - 2020-09-22 06:49:42 --> Database Driver Class Initialized
INFO - 2020-09-22 06:49:43 --> Form Validation Class Initialized
DEBUG - 2020-09-22 06:49:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 06:49:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 06:49:43 --> Encryption Class Initialized
INFO - 2020-09-22 06:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:49:43 --> Controller Class Initialized
INFO - 2020-09-22 06:49:43 --> Helper loaded: language_helper
INFO - 2020-09-22 06:49:43 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 06:49:43 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-22 06:49:43 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-22 06:49:43 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment_custom.php
INFO - 2020-09-22 06:49:43 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-22 06:49:43 --> Final output sent to browser
DEBUG - 2020-09-22 06:49:43 --> Total execution time: 1.1188
INFO - 2020-09-22 06:49:52 --> Config Class Initialized
INFO - 2020-09-22 06:49:52 --> Config Class Initialized
INFO - 2020-09-22 06:49:52 --> Hooks Class Initialized
INFO - 2020-09-22 06:49:52 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:49:52 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:49:52 --> Utf8 Class Initialized
INFO - 2020-09-22 06:49:52 --> URI Class Initialized
DEBUG - 2020-09-22 06:49:52 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:49:52 --> Utf8 Class Initialized
INFO - 2020-09-22 06:49:52 --> URI Class Initialized
INFO - 2020-09-22 06:49:52 --> Router Class Initialized
INFO - 2020-09-22 06:49:52 --> Output Class Initialized
INFO - 2020-09-22 06:49:52 --> Router Class Initialized
INFO - 2020-09-22 06:49:52 --> Output Class Initialized
INFO - 2020-09-22 06:49:52 --> Security Class Initialized
INFO - 2020-09-22 06:49:52 --> Security Class Initialized
DEBUG - 2020-09-22 06:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:49:52 --> Input Class Initialized
DEBUG - 2020-09-22 06:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:49:52 --> Language Class Initialized
INFO - 2020-09-22 06:49:52 --> Loader Class Initialized
INFO - 2020-09-22 06:49:52 --> Input Class Initialized
INFO - 2020-09-22 06:49:52 --> Helper loaded: html_helper
INFO - 2020-09-22 06:49:52 --> Helper loaded: url_helper
INFO - 2020-09-22 06:49:52 --> Language Class Initialized
INFO - 2020-09-22 06:49:52 --> Loader Class Initialized
INFO - 2020-09-22 06:49:52 --> Helper loaded: form_helper
INFO - 2020-09-22 06:49:52 --> Database Driver Class Initialized
INFO - 2020-09-22 06:49:52 --> Helper loaded: html_helper
INFO - 2020-09-22 06:49:53 --> Helper loaded: url_helper
INFO - 2020-09-22 06:49:53 --> Helper loaded: form_helper
INFO - 2020-09-22 06:49:53 --> Form Validation Class Initialized
DEBUG - 2020-09-22 06:49:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 06:49:53 --> Database Driver Class Initialized
INFO - 2020-09-22 06:49:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 06:49:53 --> Form Validation Class Initialized
INFO - 2020-09-22 06:49:53 --> Encryption Class Initialized
DEBUG - 2020-09-22 06:49:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 06:49:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 06:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:49:53 --> Controller Class Initialized
INFO - 2020-09-22 06:49:53 --> Encryption Class Initialized
INFO - 2020-09-22 06:49:53 --> Helper loaded: language_helper
INFO - 2020-09-22 06:49:53 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 06:49:54 --> Final output sent to browser
DEBUG - 2020-09-22 06:49:54 --> Total execution time: 2.1326
INFO - 2020-09-22 06:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:49:54 --> Controller Class Initialized
INFO - 2020-09-22 06:49:54 --> Helper loaded: language_helper
INFO - 2020-09-22 06:49:54 --> Language file loaded: language/english/content_lang.php
ERROR - 2020-09-22 06:49:54 --> Severity: Notice --> Undefined index: selected_order_id C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\controllers\Payment.php 184
INFO - 2020-09-22 06:49:56 --> Final output sent to browser
DEBUG - 2020-09-22 06:49:56 --> Total execution time: 4.1713
INFO - 2020-09-22 06:51:16 --> Config Class Initialized
INFO - 2020-09-22 06:51:16 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:51:16 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:51:16 --> Utf8 Class Initialized
INFO - 2020-09-22 06:51:16 --> URI Class Initialized
INFO - 2020-09-22 06:51:16 --> Router Class Initialized
INFO - 2020-09-22 06:51:16 --> Output Class Initialized
INFO - 2020-09-22 06:51:16 --> Security Class Initialized
DEBUG - 2020-09-22 06:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:51:16 --> Input Class Initialized
INFO - 2020-09-22 06:51:17 --> Language Class Initialized
INFO - 2020-09-22 06:51:17 --> Loader Class Initialized
INFO - 2020-09-22 06:51:17 --> Helper loaded: html_helper
INFO - 2020-09-22 06:51:17 --> Helper loaded: url_helper
INFO - 2020-09-22 06:51:17 --> Helper loaded: form_helper
INFO - 2020-09-22 06:51:17 --> Database Driver Class Initialized
INFO - 2020-09-22 06:51:17 --> Form Validation Class Initialized
DEBUG - 2020-09-22 06:51:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 06:51:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 06:51:17 --> Encryption Class Initialized
INFO - 2020-09-22 06:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:51:17 --> Controller Class Initialized
INFO - 2020-09-22 06:51:17 --> Helper loaded: language_helper
INFO - 2020-09-22 06:51:17 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 06:51:17 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-22 06:51:17 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-22 06:51:17 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\customer_care.php
INFO - 2020-09-22 06:51:17 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-22 06:51:17 --> Final output sent to browser
DEBUG - 2020-09-22 06:51:17 --> Total execution time: 1.1623
INFO - 2020-09-22 06:51:32 --> Config Class Initialized
INFO - 2020-09-22 06:51:32 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:51:32 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:51:32 --> Utf8 Class Initialized
INFO - 2020-09-22 06:51:32 --> URI Class Initialized
INFO - 2020-09-22 06:51:32 --> Router Class Initialized
INFO - 2020-09-22 06:51:32 --> Output Class Initialized
INFO - 2020-09-22 06:51:32 --> Security Class Initialized
DEBUG - 2020-09-22 06:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:51:32 --> Input Class Initialized
INFO - 2020-09-22 06:51:32 --> Language Class Initialized
INFO - 2020-09-22 06:51:32 --> Loader Class Initialized
INFO - 2020-09-22 06:51:32 --> Helper loaded: html_helper
INFO - 2020-09-22 06:51:32 --> Helper loaded: url_helper
INFO - 2020-09-22 06:51:32 --> Helper loaded: form_helper
INFO - 2020-09-22 06:51:32 --> Database Driver Class Initialized
INFO - 2020-09-22 06:51:32 --> Form Validation Class Initialized
DEBUG - 2020-09-22 06:51:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 06:51:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 06:51:32 --> Encryption Class Initialized
INFO - 2020-09-22 06:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:51:33 --> Controller Class Initialized
INFO - 2020-09-22 06:51:33 --> Helper loaded: language_helper
INFO - 2020-09-22 06:51:33 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 06:51:33 --> Model "Customer_care_model" initialized
INFO - 2020-09-22 06:51:33 --> Final output sent to browser
DEBUG - 2020-09-22 06:51:33 --> Total execution time: 1.0408
INFO - 2020-09-22 06:52:04 --> Config Class Initialized
INFO - 2020-09-22 06:52:04 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:52:04 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:52:04 --> Utf8 Class Initialized
INFO - 2020-09-22 06:52:04 --> URI Class Initialized
INFO - 2020-09-22 06:52:04 --> Router Class Initialized
INFO - 2020-09-22 06:52:04 --> Output Class Initialized
INFO - 2020-09-22 06:52:04 --> Security Class Initialized
DEBUG - 2020-09-22 06:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:52:04 --> Input Class Initialized
INFO - 2020-09-22 06:52:04 --> Language Class Initialized
INFO - 2020-09-22 06:52:04 --> Loader Class Initialized
INFO - 2020-09-22 06:52:04 --> Helper loaded: html_helper
INFO - 2020-09-22 06:52:04 --> Helper loaded: url_helper
INFO - 2020-09-22 06:52:04 --> Helper loaded: form_helper
INFO - 2020-09-22 06:52:04 --> Database Driver Class Initialized
INFO - 2020-09-22 06:52:04 --> Form Validation Class Initialized
DEBUG - 2020-09-22 06:52:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 06:52:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 06:52:04 --> Encryption Class Initialized
INFO - 2020-09-22 06:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:52:04 --> Controller Class Initialized
INFO - 2020-09-22 06:52:04 --> Helper loaded: language_helper
INFO - 2020-09-22 06:52:05 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 06:52:05 --> Model "Customer_care_model" initialized
INFO - 2020-09-22 06:52:05 --> Final output sent to browser
DEBUG - 2020-09-22 06:52:05 --> Total execution time: 1.0255
INFO - 2020-09-22 06:54:01 --> Config Class Initialized
INFO - 2020-09-22 06:54:01 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:54:01 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:54:01 --> Utf8 Class Initialized
INFO - 2020-09-22 06:54:01 --> URI Class Initialized
INFO - 2020-09-22 06:54:01 --> Router Class Initialized
INFO - 2020-09-22 06:54:01 --> Output Class Initialized
INFO - 2020-09-22 06:54:01 --> Security Class Initialized
DEBUG - 2020-09-22 06:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:54:01 --> Input Class Initialized
INFO - 2020-09-22 06:54:01 --> Language Class Initialized
INFO - 2020-09-22 06:54:01 --> Loader Class Initialized
INFO - 2020-09-22 06:54:01 --> Helper loaded: html_helper
INFO - 2020-09-22 06:54:02 --> Helper loaded: url_helper
INFO - 2020-09-22 06:54:02 --> Helper loaded: form_helper
INFO - 2020-09-22 06:54:02 --> Database Driver Class Initialized
INFO - 2020-09-22 06:54:02 --> Form Validation Class Initialized
DEBUG - 2020-09-22 06:54:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 06:54:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 06:54:02 --> Encryption Class Initialized
INFO - 2020-09-22 06:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:54:02 --> Controller Class Initialized
INFO - 2020-09-22 06:54:02 --> Helper loaded: language_helper
INFO - 2020-09-22 06:54:02 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 06:54:02 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-22 06:54:02 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-22 06:54:02 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment_custom.php
INFO - 2020-09-22 06:54:02 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-22 06:54:02 --> Final output sent to browser
DEBUG - 2020-09-22 06:54:02 --> Total execution time: 1.1695
INFO - 2020-09-22 06:54:10 --> Config Class Initialized
INFO - 2020-09-22 06:54:10 --> Config Class Initialized
INFO - 2020-09-22 06:54:10 --> Hooks Class Initialized
INFO - 2020-09-22 06:54:10 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:54:10 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:54:10 --> Utf8 Class Initialized
INFO - 2020-09-22 06:54:10 --> URI Class Initialized
DEBUG - 2020-09-22 06:54:10 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:54:10 --> Router Class Initialized
INFO - 2020-09-22 06:54:10 --> Output Class Initialized
INFO - 2020-09-22 06:54:10 --> Utf8 Class Initialized
INFO - 2020-09-22 06:54:10 --> URI Class Initialized
INFO - 2020-09-22 06:54:10 --> Security Class Initialized
INFO - 2020-09-22 06:54:10 --> Router Class Initialized
INFO - 2020-09-22 06:54:10 --> Output Class Initialized
INFO - 2020-09-22 06:54:10 --> Security Class Initialized
DEBUG - 2020-09-22 06:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:54:10 --> Input Class Initialized
INFO - 2020-09-22 06:54:10 --> Language Class Initialized
DEBUG - 2020-09-22 06:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:54:10 --> Input Class Initialized
INFO - 2020-09-22 06:54:10 --> Language Class Initialized
INFO - 2020-09-22 06:54:10 --> Loader Class Initialized
INFO - 2020-09-22 06:54:10 --> Helper loaded: html_helper
INFO - 2020-09-22 06:54:10 --> Loader Class Initialized
INFO - 2020-09-22 06:54:10 --> Helper loaded: html_helper
INFO - 2020-09-22 06:54:10 --> Helper loaded: url_helper
INFO - 2020-09-22 06:54:10 --> Helper loaded: form_helper
INFO - 2020-09-22 06:54:10 --> Helper loaded: url_helper
INFO - 2020-09-22 06:54:10 --> Helper loaded: form_helper
INFO - 2020-09-22 06:54:10 --> Database Driver Class Initialized
INFO - 2020-09-22 06:54:10 --> Database Driver Class Initialized
INFO - 2020-09-22 06:54:10 --> Form Validation Class Initialized
DEBUG - 2020-09-22 06:54:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 06:54:10 --> Form Validation Class Initialized
INFO - 2020-09-22 06:54:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 06:54:10 --> Encryption Class Initialized
DEBUG - 2020-09-22 06:54:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 06:54:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 06:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:54:10 --> Controller Class Initialized
INFO - 2020-09-22 06:54:10 --> Encryption Class Initialized
INFO - 2020-09-22 06:54:10 --> Helper loaded: language_helper
INFO - 2020-09-22 06:54:10 --> Language file loaded: language/english/content_lang.php
ERROR - 2020-09-22 06:54:11 --> Severity: Notice --> Undefined index: selected_order_id C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\controllers\Payment.php 184
INFO - 2020-09-22 06:54:12 --> Final output sent to browser
DEBUG - 2020-09-22 06:54:12 --> Total execution time: 2.6698
INFO - 2020-09-22 06:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:54:13 --> Controller Class Initialized
INFO - 2020-09-22 06:54:13 --> Helper loaded: language_helper
INFO - 2020-09-22 06:54:13 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 06:54:14 --> Final output sent to browser
DEBUG - 2020-09-22 06:54:14 --> Total execution time: 4.2870
INFO - 2020-09-22 06:54:19 --> Config Class Initialized
INFO - 2020-09-22 06:54:19 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:54:19 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:54:19 --> Utf8 Class Initialized
INFO - 2020-09-22 06:54:19 --> URI Class Initialized
INFO - 2020-09-22 06:54:19 --> Router Class Initialized
INFO - 2020-09-22 06:54:19 --> Output Class Initialized
INFO - 2020-09-22 06:54:19 --> Security Class Initialized
DEBUG - 2020-09-22 06:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:54:19 --> Input Class Initialized
INFO - 2020-09-22 06:54:19 --> Language Class Initialized
INFO - 2020-09-22 06:54:19 --> Loader Class Initialized
INFO - 2020-09-22 06:54:19 --> Helper loaded: html_helper
INFO - 2020-09-22 06:54:19 --> Helper loaded: url_helper
INFO - 2020-09-22 06:54:19 --> Helper loaded: form_helper
INFO - 2020-09-22 06:54:19 --> Database Driver Class Initialized
INFO - 2020-09-22 06:54:19 --> Form Validation Class Initialized
DEBUG - 2020-09-22 06:54:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 06:54:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 06:54:19 --> Encryption Class Initialized
INFO - 2020-09-22 06:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:54:20 --> Controller Class Initialized
INFO - 2020-09-22 06:54:20 --> Helper loaded: language_helper
INFO - 2020-09-22 06:54:20 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 06:54:20 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-22 06:54:20 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-22 06:54:20 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-22 06:54:20 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-22 06:54:20 --> Final output sent to browser
DEBUG - 2020-09-22 06:54:20 --> Total execution time: 1.2457
INFO - 2020-09-22 06:54:40 --> Config Class Initialized
INFO - 2020-09-22 06:54:40 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:54:40 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:54:40 --> Utf8 Class Initialized
INFO - 2020-09-22 06:54:40 --> URI Class Initialized
INFO - 2020-09-22 06:54:40 --> Router Class Initialized
INFO - 2020-09-22 06:54:40 --> Output Class Initialized
INFO - 2020-09-22 06:54:40 --> Security Class Initialized
DEBUG - 2020-09-22 06:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:54:40 --> Input Class Initialized
INFO - 2020-09-22 06:54:40 --> Language Class Initialized
INFO - 2020-09-22 06:54:40 --> Loader Class Initialized
INFO - 2020-09-22 06:54:40 --> Helper loaded: html_helper
INFO - 2020-09-22 06:54:40 --> Helper loaded: url_helper
INFO - 2020-09-22 06:54:40 --> Helper loaded: form_helper
INFO - 2020-09-22 06:54:40 --> Database Driver Class Initialized
INFO - 2020-09-22 06:54:40 --> Form Validation Class Initialized
DEBUG - 2020-09-22 06:54:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 06:54:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 06:54:41 --> Encryption Class Initialized
INFO - 2020-09-22 06:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:54:41 --> Controller Class Initialized
INFO - 2020-09-22 06:54:41 --> Helper loaded: language_helper
INFO - 2020-09-22 06:54:41 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 06:54:41 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-22 06:54:41 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-22 06:54:41 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-22 06:54:41 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-22 06:54:41 --> Final output sent to browser
DEBUG - 2020-09-22 06:54:41 --> Total execution time: 1.1351
INFO - 2020-09-22 06:54:43 --> Config Class Initialized
INFO - 2020-09-22 06:54:43 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:54:43 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:54:43 --> Utf8 Class Initialized
INFO - 2020-09-22 06:54:43 --> URI Class Initialized
INFO - 2020-09-22 06:54:43 --> Router Class Initialized
INFO - 2020-09-22 06:54:43 --> Output Class Initialized
INFO - 2020-09-22 06:54:43 --> Security Class Initialized
DEBUG - 2020-09-22 06:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:54:44 --> Input Class Initialized
INFO - 2020-09-22 06:54:44 --> Language Class Initialized
INFO - 2020-09-22 06:54:44 --> Loader Class Initialized
INFO - 2020-09-22 06:54:44 --> Helper loaded: html_helper
INFO - 2020-09-22 06:54:44 --> Helper loaded: url_helper
INFO - 2020-09-22 06:54:44 --> Helper loaded: form_helper
INFO - 2020-09-22 06:54:44 --> Database Driver Class Initialized
INFO - 2020-09-22 06:54:44 --> Form Validation Class Initialized
DEBUG - 2020-09-22 06:54:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 06:54:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 06:54:44 --> Encryption Class Initialized
INFO - 2020-09-22 06:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:54:44 --> Controller Class Initialized
INFO - 2020-09-22 06:54:44 --> Helper loaded: language_helper
INFO - 2020-09-22 06:54:44 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 06:54:44 --> Model "Sale_model" initialized
INFO - 2020-09-22 06:54:44 --> Final output sent to browser
DEBUG - 2020-09-22 06:54:44 --> Total execution time: 1.0363
INFO - 2020-09-22 06:54:53 --> Config Class Initialized
INFO - 2020-09-22 06:54:53 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:54:53 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:54:53 --> Utf8 Class Initialized
INFO - 2020-09-22 06:54:53 --> URI Class Initialized
INFO - 2020-09-22 06:54:53 --> Router Class Initialized
INFO - 2020-09-22 06:54:53 --> Output Class Initialized
INFO - 2020-09-22 06:54:53 --> Security Class Initialized
DEBUG - 2020-09-22 06:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:54:53 --> Input Class Initialized
INFO - 2020-09-22 06:54:54 --> Language Class Initialized
INFO - 2020-09-22 06:54:54 --> Loader Class Initialized
INFO - 2020-09-22 06:54:54 --> Helper loaded: html_helper
INFO - 2020-09-22 06:54:54 --> Helper loaded: url_helper
INFO - 2020-09-22 06:54:54 --> Helper loaded: form_helper
INFO - 2020-09-22 06:54:54 --> Database Driver Class Initialized
INFO - 2020-09-22 06:54:54 --> Form Validation Class Initialized
DEBUG - 2020-09-22 06:54:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 06:54:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 06:54:54 --> Encryption Class Initialized
INFO - 2020-09-22 06:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:54:54 --> Controller Class Initialized
INFO - 2020-09-22 06:54:54 --> Helper loaded: language_helper
INFO - 2020-09-22 06:54:54 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 06:54:54 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-22 06:54:54 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-22 06:54:54 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment.php
INFO - 2020-09-22 06:54:54 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-22 06:54:54 --> Final output sent to browser
DEBUG - 2020-09-22 06:54:54 --> Total execution time: 1.1548
INFO - 2020-09-22 06:54:55 --> Config Class Initialized
INFO - 2020-09-22 06:54:55 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:54:55 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:54:56 --> Utf8 Class Initialized
INFO - 2020-09-22 06:54:56 --> URI Class Initialized
INFO - 2020-09-22 06:54:56 --> Router Class Initialized
INFO - 2020-09-22 06:54:56 --> Output Class Initialized
INFO - 2020-09-22 06:54:56 --> Security Class Initialized
DEBUG - 2020-09-22 06:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:54:56 --> Input Class Initialized
INFO - 2020-09-22 06:54:56 --> Language Class Initialized
INFO - 2020-09-22 06:54:56 --> Loader Class Initialized
INFO - 2020-09-22 06:54:56 --> Helper loaded: html_helper
INFO - 2020-09-22 06:54:56 --> Helper loaded: url_helper
INFO - 2020-09-22 06:54:56 --> Helper loaded: form_helper
INFO - 2020-09-22 06:54:56 --> Database Driver Class Initialized
INFO - 2020-09-22 06:54:56 --> Form Validation Class Initialized
DEBUG - 2020-09-22 06:54:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 06:54:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 06:54:56 --> Encryption Class Initialized
INFO - 2020-09-22 06:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:54:56 --> Controller Class Initialized
INFO - 2020-09-22 06:54:56 --> Helper loaded: language_helper
INFO - 2020-09-22 06:54:56 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 06:54:56 --> Final output sent to browser
DEBUG - 2020-09-22 06:54:56 --> Total execution time: 0.9914
INFO - 2020-09-22 06:55:06 --> Config Class Initialized
INFO - 2020-09-22 06:55:06 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:55:06 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:55:06 --> Utf8 Class Initialized
INFO - 2020-09-22 06:55:06 --> URI Class Initialized
INFO - 2020-09-22 06:55:06 --> Router Class Initialized
INFO - 2020-09-22 06:55:06 --> Output Class Initialized
INFO - 2020-09-22 06:55:06 --> Security Class Initialized
DEBUG - 2020-09-22 06:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:55:06 --> Input Class Initialized
INFO - 2020-09-22 06:55:06 --> Language Class Initialized
INFO - 2020-09-22 06:55:06 --> Loader Class Initialized
INFO - 2020-09-22 06:55:06 --> Helper loaded: html_helper
INFO - 2020-09-22 06:55:06 --> Helper loaded: url_helper
INFO - 2020-09-22 06:55:06 --> Helper loaded: form_helper
INFO - 2020-09-22 06:55:06 --> Database Driver Class Initialized
INFO - 2020-09-22 06:55:06 --> Form Validation Class Initialized
DEBUG - 2020-09-22 06:55:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 06:55:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 06:55:06 --> Encryption Class Initialized
INFO - 2020-09-22 06:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:55:06 --> Controller Class Initialized
INFO - 2020-09-22 06:55:06 --> Helper loaded: language_helper
INFO - 2020-09-22 06:55:07 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 06:55:07 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-22 06:55:07 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-22 06:55:07 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment_custom.php
INFO - 2020-09-22 06:55:07 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-22 06:55:07 --> Final output sent to browser
DEBUG - 2020-09-22 06:55:07 --> Total execution time: 1.1782
INFO - 2020-09-22 06:55:08 --> Config Class Initialized
INFO - 2020-09-22 06:55:08 --> Config Class Initialized
INFO - 2020-09-22 06:55:08 --> Hooks Class Initialized
INFO - 2020-09-22 06:55:08 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:55:08 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:55:08 --> Utf8 Class Initialized
INFO - 2020-09-22 06:55:08 --> URI Class Initialized
DEBUG - 2020-09-22 06:55:08 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:55:08 --> Utf8 Class Initialized
INFO - 2020-09-22 06:55:08 --> URI Class Initialized
INFO - 2020-09-22 06:55:08 --> Router Class Initialized
INFO - 2020-09-22 06:55:08 --> Output Class Initialized
INFO - 2020-09-22 06:55:08 --> Router Class Initialized
INFO - 2020-09-22 06:55:08 --> Output Class Initialized
INFO - 2020-09-22 06:55:08 --> Security Class Initialized
INFO - 2020-09-22 06:55:08 --> Security Class Initialized
DEBUG - 2020-09-22 06:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:55:08 --> Input Class Initialized
INFO - 2020-09-22 06:55:08 --> Language Class Initialized
DEBUG - 2020-09-22 06:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:55:08 --> Input Class Initialized
INFO - 2020-09-22 06:55:09 --> Language Class Initialized
INFO - 2020-09-22 06:55:09 --> Loader Class Initialized
INFO - 2020-09-22 06:55:09 --> Loader Class Initialized
INFO - 2020-09-22 06:55:09 --> Helper loaded: html_helper
INFO - 2020-09-22 06:55:09 --> Helper loaded: html_helper
INFO - 2020-09-22 06:55:09 --> Helper loaded: url_helper
INFO - 2020-09-22 06:55:09 --> Helper loaded: url_helper
INFO - 2020-09-22 06:55:09 --> Helper loaded: form_helper
INFO - 2020-09-22 06:55:09 --> Helper loaded: form_helper
INFO - 2020-09-22 06:55:09 --> Database Driver Class Initialized
INFO - 2020-09-22 06:55:09 --> Database Driver Class Initialized
INFO - 2020-09-22 06:55:09 --> Form Validation Class Initialized
INFO - 2020-09-22 06:55:09 --> Form Validation Class Initialized
DEBUG - 2020-09-22 06:55:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 06:55:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-09-22 06:55:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 06:55:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 06:55:09 --> Encryption Class Initialized
INFO - 2020-09-22 06:55:09 --> Encryption Class Initialized
INFO - 2020-09-22 06:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:55:09 --> Controller Class Initialized
INFO - 2020-09-22 06:55:09 --> Helper loaded: language_helper
INFO - 2020-09-22 06:55:09 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 06:55:10 --> Final output sent to browser
DEBUG - 2020-09-22 06:55:10 --> Total execution time: 2.2409
INFO - 2020-09-22 06:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:55:11 --> Controller Class Initialized
INFO - 2020-09-22 06:55:11 --> Helper loaded: language_helper
INFO - 2020-09-22 06:55:11 --> Language file loaded: language/english/content_lang.php
ERROR - 2020-09-22 06:55:11 --> Severity: Notice --> Undefined index: selected_order_id C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\controllers\Payment.php 184
INFO - 2020-09-22 06:55:13 --> Final output sent to browser
DEBUG - 2020-09-22 06:55:13 --> Total execution time: 4.2778
INFO - 2020-09-22 06:55:42 --> Config Class Initialized
INFO - 2020-09-22 06:55:42 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:55:42 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:55:42 --> Utf8 Class Initialized
INFO - 2020-09-22 06:55:42 --> URI Class Initialized
INFO - 2020-09-22 06:55:43 --> Router Class Initialized
INFO - 2020-09-22 06:55:43 --> Output Class Initialized
INFO - 2020-09-22 06:55:43 --> Security Class Initialized
DEBUG - 2020-09-22 06:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:55:43 --> Input Class Initialized
INFO - 2020-09-22 06:55:43 --> Language Class Initialized
INFO - 2020-09-22 06:55:43 --> Loader Class Initialized
INFO - 2020-09-22 06:55:43 --> Helper loaded: html_helper
INFO - 2020-09-22 06:55:43 --> Helper loaded: url_helper
INFO - 2020-09-22 06:55:43 --> Helper loaded: form_helper
INFO - 2020-09-22 06:55:43 --> Database Driver Class Initialized
INFO - 2020-09-22 06:55:43 --> Form Validation Class Initialized
DEBUG - 2020-09-22 06:55:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 06:55:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 06:55:43 --> Encryption Class Initialized
INFO - 2020-09-22 06:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:55:44 --> Controller Class Initialized
INFO - 2020-09-22 06:55:44 --> Helper loaded: language_helper
INFO - 2020-09-22 06:55:44 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 06:55:44 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-22 06:55:44 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-22 06:55:44 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-22 06:55:44 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-22 06:55:44 --> Final output sent to browser
DEBUG - 2020-09-22 06:55:44 --> Total execution time: 1.5137
INFO - 2020-09-22 07:00:15 --> Config Class Initialized
INFO - 2020-09-22 07:00:15 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:00:16 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:00:16 --> Utf8 Class Initialized
INFO - 2020-09-22 07:00:16 --> URI Class Initialized
INFO - 2020-09-22 07:00:16 --> Router Class Initialized
INFO - 2020-09-22 07:00:16 --> Output Class Initialized
INFO - 2020-09-22 07:00:16 --> Security Class Initialized
DEBUG - 2020-09-22 07:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:00:16 --> Input Class Initialized
INFO - 2020-09-22 07:00:16 --> Language Class Initialized
INFO - 2020-09-22 07:00:16 --> Loader Class Initialized
INFO - 2020-09-22 07:00:16 --> Helper loaded: html_helper
INFO - 2020-09-22 07:00:16 --> Helper loaded: url_helper
INFO - 2020-09-22 07:00:16 --> Helper loaded: form_helper
INFO - 2020-09-22 07:00:16 --> Database Driver Class Initialized
INFO - 2020-09-22 07:00:16 --> Form Validation Class Initialized
DEBUG - 2020-09-22 07:00:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 07:00:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 07:00:16 --> Encryption Class Initialized
INFO - 2020-09-22 07:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:00:16 --> Controller Class Initialized
INFO - 2020-09-22 07:00:16 --> Helper loaded: language_helper
INFO - 2020-09-22 07:00:16 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 07:00:17 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-22 07:00:17 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-22 07:00:17 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-22 07:00:17 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-22 07:00:17 --> Final output sent to browser
DEBUG - 2020-09-22 07:00:17 --> Total execution time: 1.2412
INFO - 2020-09-22 07:02:27 --> Config Class Initialized
INFO - 2020-09-22 07:02:27 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:02:27 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:02:27 --> Utf8 Class Initialized
INFO - 2020-09-22 07:02:27 --> URI Class Initialized
INFO - 2020-09-22 07:02:27 --> Router Class Initialized
INFO - 2020-09-22 07:02:27 --> Output Class Initialized
INFO - 2020-09-22 07:02:27 --> Security Class Initialized
DEBUG - 2020-09-22 07:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:02:27 --> Input Class Initialized
INFO - 2020-09-22 07:02:27 --> Language Class Initialized
INFO - 2020-09-22 07:02:28 --> Loader Class Initialized
INFO - 2020-09-22 07:02:28 --> Helper loaded: html_helper
INFO - 2020-09-22 07:02:28 --> Helper loaded: url_helper
INFO - 2020-09-22 07:02:28 --> Helper loaded: form_helper
INFO - 2020-09-22 07:02:28 --> Database Driver Class Initialized
INFO - 2020-09-22 07:02:28 --> Form Validation Class Initialized
DEBUG - 2020-09-22 07:02:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 07:02:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 07:02:28 --> Encryption Class Initialized
INFO - 2020-09-22 07:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:02:29 --> Controller Class Initialized
INFO - 2020-09-22 07:02:29 --> Helper loaded: language_helper
INFO - 2020-09-22 07:02:29 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 07:02:29 --> Model "Sale_model" initialized
INFO - 2020-09-22 07:02:29 --> Final output sent to browser
DEBUG - 2020-09-22 07:02:29 --> Total execution time: 1.8784
INFO - 2020-09-22 07:02:42 --> Config Class Initialized
INFO - 2020-09-22 07:02:42 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:02:42 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:02:42 --> Utf8 Class Initialized
INFO - 2020-09-22 07:02:42 --> URI Class Initialized
INFO - 2020-09-22 07:02:42 --> Router Class Initialized
INFO - 2020-09-22 07:02:43 --> Output Class Initialized
INFO - 2020-09-22 07:02:43 --> Security Class Initialized
DEBUG - 2020-09-22 07:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:02:43 --> Input Class Initialized
INFO - 2020-09-22 07:02:43 --> Language Class Initialized
INFO - 2020-09-22 07:02:43 --> Loader Class Initialized
INFO - 2020-09-22 07:02:43 --> Helper loaded: html_helper
INFO - 2020-09-22 07:02:43 --> Helper loaded: url_helper
INFO - 2020-09-22 07:02:43 --> Helper loaded: form_helper
INFO - 2020-09-22 07:02:43 --> Database Driver Class Initialized
INFO - 2020-09-22 07:02:43 --> Form Validation Class Initialized
DEBUG - 2020-09-22 07:02:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 07:02:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 07:02:43 --> Encryption Class Initialized
INFO - 2020-09-22 07:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:02:43 --> Controller Class Initialized
INFO - 2020-09-22 07:02:43 --> Helper loaded: language_helper
INFO - 2020-09-22 07:02:43 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 07:02:43 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-22 07:02:43 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-22 07:02:43 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment.php
INFO - 2020-09-22 07:02:43 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-22 07:02:43 --> Final output sent to browser
DEBUG - 2020-09-22 07:02:43 --> Total execution time: 1.1781
INFO - 2020-09-22 07:02:44 --> Config Class Initialized
INFO - 2020-09-22 07:02:44 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:02:44 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:02:45 --> Utf8 Class Initialized
INFO - 2020-09-22 07:02:45 --> URI Class Initialized
INFO - 2020-09-22 07:02:45 --> Router Class Initialized
INFO - 2020-09-22 07:02:45 --> Output Class Initialized
INFO - 2020-09-22 07:02:45 --> Security Class Initialized
DEBUG - 2020-09-22 07:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:02:45 --> Input Class Initialized
INFO - 2020-09-22 07:02:45 --> Language Class Initialized
INFO - 2020-09-22 07:02:45 --> Loader Class Initialized
INFO - 2020-09-22 07:02:45 --> Helper loaded: html_helper
INFO - 2020-09-22 07:02:45 --> Helper loaded: url_helper
INFO - 2020-09-22 07:02:45 --> Helper loaded: form_helper
INFO - 2020-09-22 07:02:45 --> Database Driver Class Initialized
INFO - 2020-09-22 07:02:45 --> Form Validation Class Initialized
DEBUG - 2020-09-22 07:02:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-22 07:02:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-22 07:02:45 --> Encryption Class Initialized
INFO - 2020-09-22 07:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:02:45 --> Controller Class Initialized
INFO - 2020-09-22 07:02:45 --> Helper loaded: language_helper
INFO - 2020-09-22 07:02:45 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-22 07:02:45 --> Final output sent to browser
DEBUG - 2020-09-22 07:02:45 --> Total execution time: 1.0120
