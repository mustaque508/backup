<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-08 08:54:00 --> Config Class Initialized
INFO - 2021-07-08 08:54:00 --> Hooks Class Initialized
DEBUG - 2021-07-08 08:54:00 --> UTF-8 Support Enabled
INFO - 2021-07-08 08:54:00 --> Utf8 Class Initialized
INFO - 2021-07-08 08:54:00 --> URI Class Initialized
DEBUG - 2021-07-08 08:54:00 --> No URI present. Default controller set.
INFO - 2021-07-08 08:54:00 --> Router Class Initialized
INFO - 2021-07-08 08:54:00 --> Output Class Initialized
INFO - 2021-07-08 08:54:00 --> Security Class Initialized
DEBUG - 2021-07-08 08:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 08:54:00 --> Input Class Initialized
INFO - 2021-07-08 08:54:01 --> Language Class Initialized
INFO - 2021-07-08 08:54:01 --> Loader Class Initialized
INFO - 2021-07-08 08:54:01 --> Helper loaded: html_helper
INFO - 2021-07-08 08:54:01 --> Helper loaded: url_helper
INFO - 2021-07-08 08:54:01 --> Helper loaded: form_helper
INFO - 2021-07-08 08:54:01 --> Database Driver Class Initialized
INFO - 2021-07-08 08:54:02 --> Form Validation Class Initialized
DEBUG - 2021-07-08 08:54:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 08:54:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 08:54:02 --> Encryption Class Initialized
INFO - 2021-07-08 08:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 08:54:02 --> Model "vendor_model" initialized
INFO - 2021-07-08 08:54:02 --> Model "coupon_model" initialized
INFO - 2021-07-08 08:54:02 --> Model "user_model" initialized
INFO - 2021-07-08 08:54:02 --> Model "role_model" initialized
INFO - 2021-07-08 08:54:02 --> Controller Class Initialized
INFO - 2021-07-08 08:54:02 --> Helper loaded: language_helper
INFO - 2021-07-08 08:54:02 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 08:54:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\login.php
INFO - 2021-07-08 08:54:02 --> Final output sent to browser
DEBUG - 2021-07-08 08:54:02 --> Total execution time: 2.4723
INFO - 2021-07-08 08:54:05 --> Config Class Initialized
INFO - 2021-07-08 08:54:05 --> Hooks Class Initialized
DEBUG - 2021-07-08 08:54:05 --> UTF-8 Support Enabled
INFO - 2021-07-08 08:54:05 --> Utf8 Class Initialized
INFO - 2021-07-08 08:54:05 --> URI Class Initialized
DEBUG - 2021-07-08 08:54:05 --> No URI present. Default controller set.
INFO - 2021-07-08 08:54:05 --> Router Class Initialized
INFO - 2021-07-08 08:54:05 --> Output Class Initialized
INFO - 2021-07-08 08:54:05 --> Security Class Initialized
DEBUG - 2021-07-08 08:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 08:54:05 --> Input Class Initialized
INFO - 2021-07-08 08:54:05 --> Language Class Initialized
INFO - 2021-07-08 08:54:05 --> Loader Class Initialized
INFO - 2021-07-08 08:54:05 --> Helper loaded: html_helper
INFO - 2021-07-08 08:54:05 --> Helper loaded: url_helper
INFO - 2021-07-08 08:54:05 --> Helper loaded: form_helper
INFO - 2021-07-08 08:54:05 --> Database Driver Class Initialized
INFO - 2021-07-08 08:54:05 --> Form Validation Class Initialized
DEBUG - 2021-07-08 08:54:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 08:54:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 08:54:05 --> Encryption Class Initialized
INFO - 2021-07-08 08:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 08:54:05 --> Model "vendor_model" initialized
INFO - 2021-07-08 08:54:05 --> Model "coupon_model" initialized
INFO - 2021-07-08 08:54:05 --> Model "user_model" initialized
INFO - 2021-07-08 08:54:05 --> Model "role_model" initialized
INFO - 2021-07-08 08:54:05 --> Controller Class Initialized
INFO - 2021-07-08 08:54:05 --> Helper loaded: language_helper
INFO - 2021-07-08 08:54:05 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 08:54:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\login.php
INFO - 2021-07-08 08:54:05 --> Final output sent to browser
DEBUG - 2021-07-08 08:54:05 --> Total execution time: 0.1033
INFO - 2021-07-08 08:54:12 --> Config Class Initialized
INFO - 2021-07-08 08:54:12 --> Hooks Class Initialized
DEBUG - 2021-07-08 08:54:12 --> UTF-8 Support Enabled
INFO - 2021-07-08 08:54:12 --> Utf8 Class Initialized
INFO - 2021-07-08 08:54:12 --> URI Class Initialized
INFO - 2021-07-08 08:54:12 --> Router Class Initialized
INFO - 2021-07-08 08:54:12 --> Output Class Initialized
INFO - 2021-07-08 08:54:12 --> Security Class Initialized
DEBUG - 2021-07-08 08:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 08:54:12 --> Input Class Initialized
INFO - 2021-07-08 08:54:12 --> Language Class Initialized
INFO - 2021-07-08 08:54:12 --> Loader Class Initialized
INFO - 2021-07-08 08:54:12 --> Helper loaded: html_helper
INFO - 2021-07-08 08:54:12 --> Helper loaded: url_helper
INFO - 2021-07-08 08:54:12 --> Helper loaded: form_helper
INFO - 2021-07-08 08:54:12 --> Database Driver Class Initialized
INFO - 2021-07-08 08:54:12 --> Form Validation Class Initialized
DEBUG - 2021-07-08 08:54:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 08:54:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 08:54:12 --> Encryption Class Initialized
INFO - 2021-07-08 08:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 08:54:12 --> Model "vendor_model" initialized
INFO - 2021-07-08 08:54:12 --> Model "coupon_model" initialized
INFO - 2021-07-08 08:54:12 --> Model "user_model" initialized
INFO - 2021-07-08 08:54:12 --> Model "role_model" initialized
INFO - 2021-07-08 08:54:12 --> Controller Class Initialized
INFO - 2021-07-08 08:54:12 --> Helper loaded: language_helper
INFO - 2021-07-08 08:54:12 --> Language file loaded: language/english/content_lang.php
DEBUG - 2021-07-08 08:54:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-08 08:54:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-07-08 08:54:12 --> Model "User" initialized
INFO - 2021-07-08 08:54:12 --> Config Class Initialized
INFO - 2021-07-08 08:54:12 --> Hooks Class Initialized
DEBUG - 2021-07-08 08:54:12 --> UTF-8 Support Enabled
INFO - 2021-07-08 08:54:12 --> Utf8 Class Initialized
INFO - 2021-07-08 08:54:12 --> URI Class Initialized
INFO - 2021-07-08 08:54:12 --> Router Class Initialized
INFO - 2021-07-08 08:54:12 --> Output Class Initialized
INFO - 2021-07-08 08:54:12 --> Security Class Initialized
DEBUG - 2021-07-08 08:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 08:54:12 --> Input Class Initialized
INFO - 2021-07-08 08:54:12 --> Language Class Initialized
INFO - 2021-07-08 08:54:13 --> Loader Class Initialized
INFO - 2021-07-08 08:54:13 --> Helper loaded: html_helper
INFO - 2021-07-08 08:54:13 --> Helper loaded: url_helper
INFO - 2021-07-08 08:54:13 --> Helper loaded: form_helper
INFO - 2021-07-08 08:54:13 --> Database Driver Class Initialized
INFO - 2021-07-08 08:54:13 --> Form Validation Class Initialized
DEBUG - 2021-07-08 08:54:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 08:54:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 08:54:13 --> Encryption Class Initialized
INFO - 2021-07-08 08:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 08:54:13 --> Model "vendor_model" initialized
INFO - 2021-07-08 08:54:13 --> Model "coupon_model" initialized
INFO - 2021-07-08 08:54:13 --> Model "user_model" initialized
INFO - 2021-07-08 08:54:13 --> Model "role_model" initialized
INFO - 2021-07-08 08:54:13 --> Controller Class Initialized
INFO - 2021-07-08 08:54:13 --> Helper loaded: language_helper
INFO - 2021-07-08 08:54:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 08:54:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-08 08:54:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-08 08:54:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-08 08:54:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 08:54:13 --> Final output sent to browser
DEBUG - 2021-07-08 08:54:13 --> Total execution time: 0.1952
INFO - 2021-07-08 08:54:17 --> Config Class Initialized
INFO - 2021-07-08 08:54:17 --> Hooks Class Initialized
DEBUG - 2021-07-08 08:54:17 --> UTF-8 Support Enabled
INFO - 2021-07-08 08:54:17 --> Utf8 Class Initialized
INFO - 2021-07-08 08:54:17 --> URI Class Initialized
INFO - 2021-07-08 08:54:17 --> Router Class Initialized
INFO - 2021-07-08 08:54:17 --> Output Class Initialized
INFO - 2021-07-08 08:54:17 --> Security Class Initialized
DEBUG - 2021-07-08 08:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 08:54:17 --> Input Class Initialized
INFO - 2021-07-08 08:54:17 --> Language Class Initialized
INFO - 2021-07-08 08:54:17 --> Loader Class Initialized
INFO - 2021-07-08 08:54:17 --> Helper loaded: html_helper
INFO - 2021-07-08 08:54:17 --> Helper loaded: url_helper
INFO - 2021-07-08 08:54:17 --> Helper loaded: form_helper
INFO - 2021-07-08 08:54:17 --> Database Driver Class Initialized
INFO - 2021-07-08 08:54:17 --> Form Validation Class Initialized
DEBUG - 2021-07-08 08:54:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 08:54:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 08:54:17 --> Encryption Class Initialized
INFO - 2021-07-08 08:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 08:54:17 --> Model "vendor_model" initialized
INFO - 2021-07-08 08:54:17 --> Model "coupon_model" initialized
INFO - 2021-07-08 08:54:17 --> Model "user_model" initialized
INFO - 2021-07-08 08:54:17 --> Model "role_model" initialized
INFO - 2021-07-08 08:54:17 --> Controller Class Initialized
INFO - 2021-07-08 08:54:17 --> Helper loaded: language_helper
INFO - 2021-07-08 08:54:17 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 08:54:17 --> Final output sent to browser
DEBUG - 2021-07-08 08:54:17 --> Total execution time: 0.0618
INFO - 2021-07-08 08:54:18 --> Config Class Initialized
INFO - 2021-07-08 08:54:18 --> Hooks Class Initialized
DEBUG - 2021-07-08 08:54:18 --> UTF-8 Support Enabled
INFO - 2021-07-08 08:54:18 --> Utf8 Class Initialized
INFO - 2021-07-08 08:54:18 --> URI Class Initialized
DEBUG - 2021-07-08 08:54:18 --> No URI present. Default controller set.
INFO - 2021-07-08 08:54:18 --> Router Class Initialized
INFO - 2021-07-08 08:54:18 --> Output Class Initialized
INFO - 2021-07-08 08:54:18 --> Security Class Initialized
DEBUG - 2021-07-08 08:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 08:54:18 --> Input Class Initialized
INFO - 2021-07-08 08:54:18 --> Language Class Initialized
INFO - 2021-07-08 08:54:18 --> Loader Class Initialized
INFO - 2021-07-08 08:54:18 --> Helper loaded: html_helper
INFO - 2021-07-08 08:54:18 --> Helper loaded: url_helper
INFO - 2021-07-08 08:54:18 --> Helper loaded: form_helper
INFO - 2021-07-08 08:54:18 --> Database Driver Class Initialized
INFO - 2021-07-08 08:54:18 --> Form Validation Class Initialized
DEBUG - 2021-07-08 08:54:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 08:54:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 08:54:18 --> Encryption Class Initialized
INFO - 2021-07-08 08:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 08:54:18 --> Model "vendor_model" initialized
INFO - 2021-07-08 08:54:18 --> Model "coupon_model" initialized
INFO - 2021-07-08 08:54:18 --> Model "user_model" initialized
INFO - 2021-07-08 08:54:18 --> Model "role_model" initialized
INFO - 2021-07-08 08:54:18 --> Controller Class Initialized
INFO - 2021-07-08 08:54:18 --> Helper loaded: language_helper
INFO - 2021-07-08 08:54:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 08:54:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\login.php
INFO - 2021-07-08 08:54:18 --> Final output sent to browser
DEBUG - 2021-07-08 08:54:18 --> Total execution time: 0.1145
INFO - 2021-07-08 08:54:26 --> Config Class Initialized
INFO - 2021-07-08 08:54:26 --> Hooks Class Initialized
DEBUG - 2021-07-08 08:54:26 --> UTF-8 Support Enabled
INFO - 2021-07-08 08:54:26 --> Utf8 Class Initialized
INFO - 2021-07-08 08:54:26 --> URI Class Initialized
INFO - 2021-07-08 08:54:26 --> Router Class Initialized
INFO - 2021-07-08 08:54:26 --> Output Class Initialized
INFO - 2021-07-08 08:54:26 --> Security Class Initialized
DEBUG - 2021-07-08 08:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 08:54:26 --> Input Class Initialized
INFO - 2021-07-08 08:54:26 --> Language Class Initialized
INFO - 2021-07-08 08:54:26 --> Loader Class Initialized
INFO - 2021-07-08 08:54:26 --> Helper loaded: html_helper
INFO - 2021-07-08 08:54:26 --> Helper loaded: url_helper
INFO - 2021-07-08 08:54:26 --> Helper loaded: form_helper
INFO - 2021-07-08 08:54:26 --> Database Driver Class Initialized
INFO - 2021-07-08 08:54:26 --> Form Validation Class Initialized
DEBUG - 2021-07-08 08:54:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 08:54:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 08:54:26 --> Encryption Class Initialized
INFO - 2021-07-08 08:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 08:54:26 --> Model "vendor_model" initialized
INFO - 2021-07-08 08:54:26 --> Model "coupon_model" initialized
INFO - 2021-07-08 08:54:26 --> Model "user_model" initialized
INFO - 2021-07-08 08:54:26 --> Model "role_model" initialized
INFO - 2021-07-08 08:54:26 --> Controller Class Initialized
INFO - 2021-07-08 08:54:26 --> Helper loaded: language_helper
INFO - 2021-07-08 08:54:26 --> Language file loaded: language/english/content_lang.php
DEBUG - 2021-07-08 08:54:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-08 08:54:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-07-08 08:54:26 --> Model "User" initialized
INFO - 2021-07-08 08:54:27 --> Config Class Initialized
INFO - 2021-07-08 08:54:27 --> Hooks Class Initialized
DEBUG - 2021-07-08 08:54:27 --> UTF-8 Support Enabled
INFO - 2021-07-08 08:54:27 --> Utf8 Class Initialized
INFO - 2021-07-08 08:54:27 --> URI Class Initialized
INFO - 2021-07-08 08:54:27 --> Router Class Initialized
INFO - 2021-07-08 08:54:27 --> Output Class Initialized
INFO - 2021-07-08 08:54:27 --> Security Class Initialized
DEBUG - 2021-07-08 08:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 08:54:27 --> Input Class Initialized
INFO - 2021-07-08 08:54:27 --> Language Class Initialized
INFO - 2021-07-08 08:54:27 --> Loader Class Initialized
INFO - 2021-07-08 08:54:27 --> Helper loaded: html_helper
INFO - 2021-07-08 08:54:27 --> Helper loaded: url_helper
INFO - 2021-07-08 08:54:27 --> Helper loaded: form_helper
INFO - 2021-07-08 08:54:27 --> Database Driver Class Initialized
INFO - 2021-07-08 08:54:27 --> Form Validation Class Initialized
DEBUG - 2021-07-08 08:54:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 08:54:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 08:54:27 --> Encryption Class Initialized
INFO - 2021-07-08 08:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 08:54:27 --> Model "vendor_model" initialized
INFO - 2021-07-08 08:54:27 --> Model "coupon_model" initialized
INFO - 2021-07-08 08:54:27 --> Model "user_model" initialized
INFO - 2021-07-08 08:54:27 --> Model "role_model" initialized
INFO - 2021-07-08 08:54:27 --> Controller Class Initialized
INFO - 2021-07-08 08:54:27 --> Helper loaded: language_helper
INFO - 2021-07-08 08:54:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 08:54:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-08 08:54:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-08 08:54:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-08 08:54:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 08:54:27 --> Final output sent to browser
DEBUG - 2021-07-08 08:54:27 --> Total execution time: 0.0740
INFO - 2021-07-08 08:54:39 --> Config Class Initialized
INFO - 2021-07-08 08:54:39 --> Hooks Class Initialized
DEBUG - 2021-07-08 08:54:39 --> UTF-8 Support Enabled
INFO - 2021-07-08 08:54:39 --> Utf8 Class Initialized
INFO - 2021-07-08 08:54:39 --> URI Class Initialized
INFO - 2021-07-08 08:54:39 --> Router Class Initialized
INFO - 2021-07-08 08:54:39 --> Output Class Initialized
INFO - 2021-07-08 08:54:39 --> Security Class Initialized
DEBUG - 2021-07-08 08:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 08:54:39 --> Input Class Initialized
INFO - 2021-07-08 08:54:39 --> Language Class Initialized
INFO - 2021-07-08 08:54:39 --> Loader Class Initialized
INFO - 2021-07-08 08:54:39 --> Helper loaded: html_helper
INFO - 2021-07-08 08:54:39 --> Helper loaded: url_helper
INFO - 2021-07-08 08:54:39 --> Helper loaded: form_helper
INFO - 2021-07-08 08:54:39 --> Database Driver Class Initialized
INFO - 2021-07-08 08:54:39 --> Form Validation Class Initialized
DEBUG - 2021-07-08 08:54:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 08:54:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 08:54:39 --> Encryption Class Initialized
INFO - 2021-07-08 08:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 08:54:39 --> Model "vendor_model" initialized
INFO - 2021-07-08 08:54:39 --> Model "coupon_model" initialized
INFO - 2021-07-08 08:54:39 --> Model "user_model" initialized
INFO - 2021-07-08 08:54:39 --> Model "role_model" initialized
INFO - 2021-07-08 08:54:39 --> Controller Class Initialized
INFO - 2021-07-08 08:54:39 --> Helper loaded: language_helper
INFO - 2021-07-08 08:54:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 08:54:39 --> Model "Customer_model" initialized
INFO - 2021-07-08 08:54:39 --> Model "Product_model" initialized
INFO - 2021-07-08 08:54:40 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 08:54:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 08:54:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 08:54:40 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 08:54:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 08:54:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 08:54:40 --> Final output sent to browser
DEBUG - 2021-07-08 08:54:40 --> Total execution time: 0.4334
INFO - 2021-07-08 08:54:46 --> Config Class Initialized
INFO - 2021-07-08 08:54:46 --> Hooks Class Initialized
DEBUG - 2021-07-08 08:54:46 --> UTF-8 Support Enabled
INFO - 2021-07-08 08:54:46 --> Utf8 Class Initialized
INFO - 2021-07-08 08:54:46 --> URI Class Initialized
INFO - 2021-07-08 08:54:46 --> Router Class Initialized
INFO - 2021-07-08 08:54:46 --> Output Class Initialized
INFO - 2021-07-08 08:54:46 --> Security Class Initialized
DEBUG - 2021-07-08 08:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 08:54:46 --> Input Class Initialized
INFO - 2021-07-08 08:54:46 --> Language Class Initialized
INFO - 2021-07-08 08:54:46 --> Loader Class Initialized
INFO - 2021-07-08 08:54:46 --> Helper loaded: html_helper
INFO - 2021-07-08 08:54:46 --> Helper loaded: url_helper
INFO - 2021-07-08 08:54:46 --> Helper loaded: form_helper
INFO - 2021-07-08 08:54:46 --> Database Driver Class Initialized
INFO - 2021-07-08 08:54:46 --> Form Validation Class Initialized
DEBUG - 2021-07-08 08:54:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 08:54:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 08:54:46 --> Encryption Class Initialized
INFO - 2021-07-08 08:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 08:54:46 --> Model "vendor_model" initialized
INFO - 2021-07-08 08:54:46 --> Model "coupon_model" initialized
INFO - 2021-07-08 08:54:46 --> Model "user_model" initialized
INFO - 2021-07-08 08:54:46 --> Model "role_model" initialized
INFO - 2021-07-08 08:54:46 --> Controller Class Initialized
INFO - 2021-07-08 08:54:46 --> Helper loaded: language_helper
INFO - 2021-07-08 08:54:46 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 08:54:46 --> Model "Customer_model" initialized
INFO - 2021-07-08 08:54:46 --> Final output sent to browser
DEBUG - 2021-07-08 08:54:46 --> Total execution time: 0.1055
INFO - 2021-07-08 08:55:32 --> Config Class Initialized
INFO - 2021-07-08 08:55:32 --> Hooks Class Initialized
DEBUG - 2021-07-08 08:55:32 --> UTF-8 Support Enabled
INFO - 2021-07-08 08:55:32 --> Utf8 Class Initialized
INFO - 2021-07-08 08:55:32 --> URI Class Initialized
INFO - 2021-07-08 08:55:32 --> Router Class Initialized
INFO - 2021-07-08 08:55:32 --> Output Class Initialized
INFO - 2021-07-08 08:55:32 --> Security Class Initialized
DEBUG - 2021-07-08 08:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 08:55:32 --> Input Class Initialized
INFO - 2021-07-08 08:55:32 --> Language Class Initialized
INFO - 2021-07-08 08:55:32 --> Loader Class Initialized
INFO - 2021-07-08 08:55:32 --> Helper loaded: html_helper
INFO - 2021-07-08 08:55:32 --> Helper loaded: url_helper
INFO - 2021-07-08 08:55:32 --> Helper loaded: form_helper
INFO - 2021-07-08 08:55:32 --> Database Driver Class Initialized
INFO - 2021-07-08 08:55:32 --> Form Validation Class Initialized
DEBUG - 2021-07-08 08:55:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 08:55:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 08:55:32 --> Encryption Class Initialized
INFO - 2021-07-08 08:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 08:55:32 --> Model "vendor_model" initialized
INFO - 2021-07-08 08:55:32 --> Model "coupon_model" initialized
INFO - 2021-07-08 08:55:32 --> Model "user_model" initialized
INFO - 2021-07-08 08:55:32 --> Model "role_model" initialized
INFO - 2021-07-08 08:55:32 --> Controller Class Initialized
INFO - 2021-07-08 08:55:32 --> Helper loaded: language_helper
INFO - 2021-07-08 08:55:32 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 08:55:32 --> Model "Product_model" initialized
INFO - 2021-07-08 08:55:32 --> Final output sent to browser
DEBUG - 2021-07-08 08:55:32 --> Total execution time: 0.0984
INFO - 2021-07-08 08:55:49 --> Config Class Initialized
INFO - 2021-07-08 08:55:49 --> Hooks Class Initialized
DEBUG - 2021-07-08 08:55:49 --> UTF-8 Support Enabled
INFO - 2021-07-08 08:55:49 --> Utf8 Class Initialized
INFO - 2021-07-08 08:55:49 --> URI Class Initialized
INFO - 2021-07-08 08:55:49 --> Router Class Initialized
INFO - 2021-07-08 08:55:49 --> Output Class Initialized
INFO - 2021-07-08 08:55:49 --> Security Class Initialized
DEBUG - 2021-07-08 08:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 08:55:49 --> Input Class Initialized
INFO - 2021-07-08 08:55:49 --> Language Class Initialized
INFO - 2021-07-08 08:55:49 --> Loader Class Initialized
INFO - 2021-07-08 08:55:49 --> Helper loaded: html_helper
INFO - 2021-07-08 08:55:49 --> Helper loaded: url_helper
INFO - 2021-07-08 08:55:49 --> Helper loaded: form_helper
INFO - 2021-07-08 08:55:49 --> Database Driver Class Initialized
INFO - 2021-07-08 08:55:49 --> Form Validation Class Initialized
DEBUG - 2021-07-08 08:55:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 08:55:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 08:55:49 --> Encryption Class Initialized
INFO - 2021-07-08 08:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 08:55:49 --> Model "vendor_model" initialized
INFO - 2021-07-08 08:55:49 --> Model "coupon_model" initialized
INFO - 2021-07-08 08:55:49 --> Model "user_model" initialized
INFO - 2021-07-08 08:55:49 --> Model "role_model" initialized
INFO - 2021-07-08 08:55:49 --> Controller Class Initialized
INFO - 2021-07-08 08:55:49 --> Helper loaded: language_helper
INFO - 2021-07-08 08:55:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 08:55:49 --> Model "Customer_model" initialized
INFO - 2021-07-08 08:55:49 --> Model "Product_model" initialized
INFO - 2021-07-08 08:55:49 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 08:55:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 08:55:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 08:55:49 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 08:55:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 08:55:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 08:55:49 --> Final output sent to browser
DEBUG - 2021-07-08 08:55:49 --> Total execution time: 0.0731
INFO - 2021-07-08 08:56:31 --> Config Class Initialized
INFO - 2021-07-08 08:56:31 --> Hooks Class Initialized
DEBUG - 2021-07-08 08:56:31 --> UTF-8 Support Enabled
INFO - 2021-07-08 08:56:31 --> Utf8 Class Initialized
INFO - 2021-07-08 08:56:31 --> URI Class Initialized
INFO - 2021-07-08 08:56:31 --> Router Class Initialized
INFO - 2021-07-08 08:56:31 --> Output Class Initialized
INFO - 2021-07-08 08:56:31 --> Security Class Initialized
DEBUG - 2021-07-08 08:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 08:56:32 --> Input Class Initialized
INFO - 2021-07-08 08:56:32 --> Language Class Initialized
INFO - 2021-07-08 08:56:32 --> Loader Class Initialized
INFO - 2021-07-08 08:56:32 --> Helper loaded: html_helper
INFO - 2021-07-08 08:56:32 --> Helper loaded: url_helper
INFO - 2021-07-08 08:56:32 --> Helper loaded: form_helper
INFO - 2021-07-08 08:56:32 --> Database Driver Class Initialized
INFO - 2021-07-08 08:56:32 --> Form Validation Class Initialized
DEBUG - 2021-07-08 08:56:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 08:56:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 08:56:32 --> Encryption Class Initialized
INFO - 2021-07-08 08:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 08:56:32 --> Model "vendor_model" initialized
INFO - 2021-07-08 08:56:32 --> Model "coupon_model" initialized
INFO - 2021-07-08 08:56:32 --> Model "user_model" initialized
INFO - 2021-07-08 08:56:32 --> Model "role_model" initialized
INFO - 2021-07-08 08:56:32 --> Controller Class Initialized
INFO - 2021-07-08 08:56:32 --> Helper loaded: language_helper
INFO - 2021-07-08 08:56:32 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 08:56:32 --> Model "Product_model" initialized
INFO - 2021-07-08 08:56:32 --> Final output sent to browser
DEBUG - 2021-07-08 08:56:32 --> Total execution time: 0.0639
INFO - 2021-07-08 08:57:33 --> Config Class Initialized
INFO - 2021-07-08 08:57:33 --> Hooks Class Initialized
DEBUG - 2021-07-08 08:57:33 --> UTF-8 Support Enabled
INFO - 2021-07-08 08:57:33 --> Utf8 Class Initialized
INFO - 2021-07-08 08:57:33 --> URI Class Initialized
INFO - 2021-07-08 08:57:33 --> Router Class Initialized
INFO - 2021-07-08 08:57:33 --> Output Class Initialized
INFO - 2021-07-08 08:57:33 --> Security Class Initialized
DEBUG - 2021-07-08 08:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 08:57:33 --> Input Class Initialized
INFO - 2021-07-08 08:57:33 --> Language Class Initialized
INFO - 2021-07-08 08:57:33 --> Loader Class Initialized
INFO - 2021-07-08 08:57:33 --> Helper loaded: html_helper
INFO - 2021-07-08 08:57:33 --> Helper loaded: url_helper
INFO - 2021-07-08 08:57:33 --> Helper loaded: form_helper
INFO - 2021-07-08 08:57:33 --> Database Driver Class Initialized
INFO - 2021-07-08 08:57:33 --> Form Validation Class Initialized
DEBUG - 2021-07-08 08:57:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 08:57:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 08:57:33 --> Encryption Class Initialized
INFO - 2021-07-08 08:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 08:57:33 --> Model "vendor_model" initialized
INFO - 2021-07-08 08:57:33 --> Model "coupon_model" initialized
INFO - 2021-07-08 08:57:33 --> Model "user_model" initialized
INFO - 2021-07-08 08:57:33 --> Model "role_model" initialized
INFO - 2021-07-08 08:57:33 --> Controller Class Initialized
INFO - 2021-07-08 08:57:33 --> Helper loaded: language_helper
INFO - 2021-07-08 08:57:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 08:57:33 --> Model "Customer_model" initialized
INFO - 2021-07-08 08:57:33 --> Model "Product_model" initialized
INFO - 2021-07-08 08:57:33 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 08:57:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 08:57:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 08:57:33 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 08:57:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 08:57:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 08:57:33 --> Final output sent to browser
DEBUG - 2021-07-08 08:57:33 --> Total execution time: 0.0817
INFO - 2021-07-08 08:58:46 --> Config Class Initialized
INFO - 2021-07-08 08:58:46 --> Hooks Class Initialized
DEBUG - 2021-07-08 08:58:46 --> UTF-8 Support Enabled
INFO - 2021-07-08 08:58:46 --> Utf8 Class Initialized
INFO - 2021-07-08 08:58:46 --> URI Class Initialized
INFO - 2021-07-08 08:58:46 --> Router Class Initialized
INFO - 2021-07-08 08:58:46 --> Output Class Initialized
INFO - 2021-07-08 08:58:46 --> Security Class Initialized
DEBUG - 2021-07-08 08:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 08:58:46 --> Input Class Initialized
INFO - 2021-07-08 08:58:46 --> Language Class Initialized
INFO - 2021-07-08 08:58:46 --> Loader Class Initialized
INFO - 2021-07-08 08:58:46 --> Helper loaded: html_helper
INFO - 2021-07-08 08:58:46 --> Helper loaded: url_helper
INFO - 2021-07-08 08:58:46 --> Helper loaded: form_helper
INFO - 2021-07-08 08:58:46 --> Database Driver Class Initialized
INFO - 2021-07-08 08:58:46 --> Form Validation Class Initialized
DEBUG - 2021-07-08 08:58:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 08:58:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 08:58:46 --> Encryption Class Initialized
INFO - 2021-07-08 08:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 08:58:46 --> Model "vendor_model" initialized
INFO - 2021-07-08 08:58:46 --> Model "coupon_model" initialized
INFO - 2021-07-08 08:58:46 --> Model "user_model" initialized
INFO - 2021-07-08 08:58:46 --> Model "role_model" initialized
INFO - 2021-07-08 08:58:46 --> Controller Class Initialized
INFO - 2021-07-08 08:58:46 --> Helper loaded: language_helper
INFO - 2021-07-08 08:58:46 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 08:58:46 --> Model "Customer_model" initialized
INFO - 2021-07-08 08:58:46 --> Final output sent to browser
DEBUG - 2021-07-08 08:58:46 --> Total execution time: 0.0635
INFO - 2021-07-08 08:58:57 --> Config Class Initialized
INFO - 2021-07-08 08:58:57 --> Hooks Class Initialized
DEBUG - 2021-07-08 08:58:57 --> UTF-8 Support Enabled
INFO - 2021-07-08 08:58:57 --> Utf8 Class Initialized
INFO - 2021-07-08 08:58:57 --> URI Class Initialized
INFO - 2021-07-08 08:58:57 --> Router Class Initialized
INFO - 2021-07-08 08:58:57 --> Output Class Initialized
INFO - 2021-07-08 08:58:57 --> Security Class Initialized
DEBUG - 2021-07-08 08:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 08:58:57 --> Input Class Initialized
INFO - 2021-07-08 08:58:57 --> Language Class Initialized
INFO - 2021-07-08 08:58:57 --> Loader Class Initialized
INFO - 2021-07-08 08:58:57 --> Helper loaded: html_helper
INFO - 2021-07-08 08:58:57 --> Helper loaded: url_helper
INFO - 2021-07-08 08:58:57 --> Helper loaded: form_helper
INFO - 2021-07-08 08:58:57 --> Database Driver Class Initialized
INFO - 2021-07-08 08:58:57 --> Form Validation Class Initialized
DEBUG - 2021-07-08 08:58:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 08:58:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 08:58:57 --> Encryption Class Initialized
INFO - 2021-07-08 08:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 08:58:57 --> Model "vendor_model" initialized
INFO - 2021-07-08 08:58:57 --> Model "coupon_model" initialized
INFO - 2021-07-08 08:58:57 --> Model "user_model" initialized
INFO - 2021-07-08 08:58:57 --> Model "role_model" initialized
INFO - 2021-07-08 08:58:57 --> Controller Class Initialized
INFO - 2021-07-08 08:58:57 --> Helper loaded: language_helper
INFO - 2021-07-08 08:58:57 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 08:58:57 --> Model "Customer_model" initialized
INFO - 2021-07-08 08:58:57 --> Model "Product_model" initialized
INFO - 2021-07-08 08:58:57 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 08:58:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 08:58:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 08:58:57 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 08:58:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 08:58:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 08:58:57 --> Final output sent to browser
DEBUG - 2021-07-08 08:58:57 --> Total execution time: 0.0796
INFO - 2021-07-08 08:59:48 --> Config Class Initialized
INFO - 2021-07-08 08:59:48 --> Hooks Class Initialized
DEBUG - 2021-07-08 08:59:48 --> UTF-8 Support Enabled
INFO - 2021-07-08 08:59:48 --> Utf8 Class Initialized
INFO - 2021-07-08 08:59:48 --> URI Class Initialized
INFO - 2021-07-08 08:59:48 --> Router Class Initialized
INFO - 2021-07-08 08:59:48 --> Output Class Initialized
INFO - 2021-07-08 08:59:48 --> Security Class Initialized
DEBUG - 2021-07-08 08:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 08:59:48 --> Input Class Initialized
INFO - 2021-07-08 08:59:48 --> Language Class Initialized
INFO - 2021-07-08 08:59:48 --> Loader Class Initialized
INFO - 2021-07-08 08:59:48 --> Helper loaded: html_helper
INFO - 2021-07-08 08:59:48 --> Helper loaded: url_helper
INFO - 2021-07-08 08:59:48 --> Helper loaded: form_helper
INFO - 2021-07-08 08:59:48 --> Database Driver Class Initialized
INFO - 2021-07-08 08:59:48 --> Form Validation Class Initialized
DEBUG - 2021-07-08 08:59:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 08:59:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 08:59:48 --> Encryption Class Initialized
INFO - 2021-07-08 08:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 08:59:48 --> Model "vendor_model" initialized
INFO - 2021-07-08 08:59:48 --> Model "coupon_model" initialized
INFO - 2021-07-08 08:59:48 --> Model "user_model" initialized
INFO - 2021-07-08 08:59:48 --> Model "role_model" initialized
INFO - 2021-07-08 08:59:48 --> Controller Class Initialized
INFO - 2021-07-08 08:59:48 --> Helper loaded: language_helper
INFO - 2021-07-08 08:59:48 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 08:59:48 --> Model "Customer_model" initialized
INFO - 2021-07-08 08:59:48 --> Final output sent to browser
DEBUG - 2021-07-08 08:59:48 --> Total execution time: 0.0652
INFO - 2021-07-08 08:59:51 --> Config Class Initialized
INFO - 2021-07-08 08:59:51 --> Hooks Class Initialized
DEBUG - 2021-07-08 08:59:51 --> UTF-8 Support Enabled
INFO - 2021-07-08 08:59:51 --> Utf8 Class Initialized
INFO - 2021-07-08 08:59:51 --> URI Class Initialized
INFO - 2021-07-08 08:59:51 --> Router Class Initialized
INFO - 2021-07-08 08:59:51 --> Output Class Initialized
INFO - 2021-07-08 08:59:51 --> Security Class Initialized
DEBUG - 2021-07-08 08:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 08:59:51 --> Input Class Initialized
INFO - 2021-07-08 08:59:51 --> Language Class Initialized
INFO - 2021-07-08 08:59:51 --> Loader Class Initialized
INFO - 2021-07-08 08:59:51 --> Helper loaded: html_helper
INFO - 2021-07-08 08:59:51 --> Helper loaded: url_helper
INFO - 2021-07-08 08:59:51 --> Helper loaded: form_helper
INFO - 2021-07-08 08:59:51 --> Database Driver Class Initialized
INFO - 2021-07-08 08:59:51 --> Form Validation Class Initialized
DEBUG - 2021-07-08 08:59:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 08:59:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 08:59:51 --> Encryption Class Initialized
INFO - 2021-07-08 08:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 08:59:51 --> Model "vendor_model" initialized
INFO - 2021-07-08 08:59:51 --> Model "coupon_model" initialized
INFO - 2021-07-08 08:59:51 --> Model "user_model" initialized
INFO - 2021-07-08 08:59:51 --> Model "role_model" initialized
INFO - 2021-07-08 08:59:51 --> Controller Class Initialized
INFO - 2021-07-08 08:59:51 --> Helper loaded: language_helper
INFO - 2021-07-08 08:59:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 08:59:51 --> Model "Customer_model" initialized
INFO - 2021-07-08 08:59:51 --> Final output sent to browser
DEBUG - 2021-07-08 08:59:51 --> Total execution time: 0.0636
INFO - 2021-07-08 09:00:35 --> Config Class Initialized
INFO - 2021-07-08 09:00:35 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:00:35 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:00:35 --> Utf8 Class Initialized
INFO - 2021-07-08 09:00:35 --> URI Class Initialized
INFO - 2021-07-08 09:00:35 --> Router Class Initialized
INFO - 2021-07-08 09:00:35 --> Output Class Initialized
INFO - 2021-07-08 09:00:35 --> Security Class Initialized
DEBUG - 2021-07-08 09:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:00:35 --> Input Class Initialized
INFO - 2021-07-08 09:00:35 --> Language Class Initialized
INFO - 2021-07-08 09:00:35 --> Loader Class Initialized
INFO - 2021-07-08 09:00:35 --> Helper loaded: html_helper
INFO - 2021-07-08 09:00:35 --> Helper loaded: url_helper
INFO - 2021-07-08 09:00:35 --> Helper loaded: form_helper
INFO - 2021-07-08 09:00:35 --> Database Driver Class Initialized
INFO - 2021-07-08 09:00:35 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:00:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:00:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:00:35 --> Encryption Class Initialized
INFO - 2021-07-08 09:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:00:35 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:00:35 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:00:35 --> Model "user_model" initialized
INFO - 2021-07-08 09:00:35 --> Model "role_model" initialized
INFO - 2021-07-08 09:00:35 --> Controller Class Initialized
INFO - 2021-07-08 09:00:35 --> Helper loaded: language_helper
INFO - 2021-07-08 09:00:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:00:35 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:00:35 --> Model "Product_model" initialized
INFO - 2021-07-08 09:00:35 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:00:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:00:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:00:35 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:00:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:00:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:00:35 --> Final output sent to browser
DEBUG - 2021-07-08 09:00:35 --> Total execution time: 0.1053
INFO - 2021-07-08 09:00:43 --> Config Class Initialized
INFO - 2021-07-08 09:00:43 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:00:43 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:00:43 --> Utf8 Class Initialized
INFO - 2021-07-08 09:00:43 --> URI Class Initialized
INFO - 2021-07-08 09:00:43 --> Router Class Initialized
INFO - 2021-07-08 09:00:43 --> Output Class Initialized
INFO - 2021-07-08 09:00:43 --> Security Class Initialized
DEBUG - 2021-07-08 09:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:00:43 --> Input Class Initialized
INFO - 2021-07-08 09:00:43 --> Language Class Initialized
INFO - 2021-07-08 09:00:43 --> Loader Class Initialized
INFO - 2021-07-08 09:00:43 --> Helper loaded: html_helper
INFO - 2021-07-08 09:00:43 --> Helper loaded: url_helper
INFO - 2021-07-08 09:00:43 --> Helper loaded: form_helper
INFO - 2021-07-08 09:00:43 --> Database Driver Class Initialized
INFO - 2021-07-08 09:00:43 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:00:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:00:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:00:43 --> Encryption Class Initialized
INFO - 2021-07-08 09:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:00:43 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:00:43 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:00:43 --> Model "user_model" initialized
INFO - 2021-07-08 09:00:43 --> Model "role_model" initialized
INFO - 2021-07-08 09:00:43 --> Controller Class Initialized
INFO - 2021-07-08 09:00:43 --> Helper loaded: language_helper
INFO - 2021-07-08 09:00:43 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:00:43 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:00:43 --> Final output sent to browser
DEBUG - 2021-07-08 09:00:43 --> Total execution time: 0.0599
INFO - 2021-07-08 09:04:57 --> Config Class Initialized
INFO - 2021-07-08 09:04:57 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:04:57 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:04:57 --> Utf8 Class Initialized
INFO - 2021-07-08 09:04:57 --> URI Class Initialized
INFO - 2021-07-08 09:04:57 --> Router Class Initialized
INFO - 2021-07-08 09:04:57 --> Output Class Initialized
INFO - 2021-07-08 09:04:57 --> Security Class Initialized
DEBUG - 2021-07-08 09:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:04:57 --> Input Class Initialized
INFO - 2021-07-08 09:04:57 --> Language Class Initialized
INFO - 2021-07-08 09:04:57 --> Loader Class Initialized
INFO - 2021-07-08 09:04:57 --> Helper loaded: html_helper
INFO - 2021-07-08 09:04:57 --> Helper loaded: url_helper
INFO - 2021-07-08 09:04:57 --> Helper loaded: form_helper
INFO - 2021-07-08 09:04:58 --> Database Driver Class Initialized
INFO - 2021-07-08 09:04:58 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:04:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:04:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:04:58 --> Encryption Class Initialized
INFO - 2021-07-08 09:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:04:58 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:04:58 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:04:58 --> Model "user_model" initialized
INFO - 2021-07-08 09:04:58 --> Model "role_model" initialized
INFO - 2021-07-08 09:04:58 --> Controller Class Initialized
INFO - 2021-07-08 09:04:58 --> Helper loaded: language_helper
INFO - 2021-07-08 09:04:58 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:04:58 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:04:58 --> Model "Product_model" initialized
INFO - 2021-07-08 09:04:58 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:04:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:04:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:04:58 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:04:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:04:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:04:58 --> Final output sent to browser
DEBUG - 2021-07-08 09:04:58 --> Total execution time: 0.0821
INFO - 2021-07-08 09:06:21 --> Config Class Initialized
INFO - 2021-07-08 09:06:21 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:06:21 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:06:21 --> Utf8 Class Initialized
INFO - 2021-07-08 09:06:21 --> URI Class Initialized
INFO - 2021-07-08 09:06:21 --> Router Class Initialized
INFO - 2021-07-08 09:06:21 --> Output Class Initialized
INFO - 2021-07-08 09:06:21 --> Security Class Initialized
DEBUG - 2021-07-08 09:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:06:21 --> Input Class Initialized
INFO - 2021-07-08 09:06:21 --> Language Class Initialized
INFO - 2021-07-08 09:06:21 --> Loader Class Initialized
INFO - 2021-07-08 09:06:21 --> Helper loaded: html_helper
INFO - 2021-07-08 09:06:21 --> Helper loaded: url_helper
INFO - 2021-07-08 09:06:21 --> Helper loaded: form_helper
INFO - 2021-07-08 09:06:21 --> Database Driver Class Initialized
INFO - 2021-07-08 09:06:21 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:06:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:06:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:06:21 --> Encryption Class Initialized
INFO - 2021-07-08 09:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:06:21 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:06:21 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:06:21 --> Model "user_model" initialized
INFO - 2021-07-08 09:06:21 --> Model "role_model" initialized
INFO - 2021-07-08 09:06:21 --> Controller Class Initialized
INFO - 2021-07-08 09:06:21 --> Helper loaded: language_helper
INFO - 2021-07-08 09:06:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:06:21 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:06:21 --> Model "Product_model" initialized
INFO - 2021-07-08 09:06:21 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:06:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:06:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:06:21 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:06:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:06:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:06:21 --> Final output sent to browser
DEBUG - 2021-07-08 09:06:21 --> Total execution time: 0.0806
INFO - 2021-07-08 09:06:22 --> Config Class Initialized
INFO - 2021-07-08 09:06:22 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:06:22 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:06:22 --> Utf8 Class Initialized
INFO - 2021-07-08 09:06:22 --> URI Class Initialized
INFO - 2021-07-08 09:06:22 --> Router Class Initialized
INFO - 2021-07-08 09:06:22 --> Output Class Initialized
INFO - 2021-07-08 09:06:22 --> Security Class Initialized
DEBUG - 2021-07-08 09:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:06:22 --> Input Class Initialized
INFO - 2021-07-08 09:06:22 --> Language Class Initialized
INFO - 2021-07-08 09:06:22 --> Loader Class Initialized
INFO - 2021-07-08 09:06:22 --> Helper loaded: html_helper
INFO - 2021-07-08 09:06:22 --> Helper loaded: url_helper
INFO - 2021-07-08 09:06:22 --> Helper loaded: form_helper
INFO - 2021-07-08 09:06:22 --> Database Driver Class Initialized
INFO - 2021-07-08 09:06:22 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:06:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:06:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:06:22 --> Encryption Class Initialized
INFO - 2021-07-08 09:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:06:22 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:06:22 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:06:22 --> Model "user_model" initialized
INFO - 2021-07-08 09:06:22 --> Model "role_model" initialized
INFO - 2021-07-08 09:06:22 --> Controller Class Initialized
INFO - 2021-07-08 09:06:22 --> Helper loaded: language_helper
INFO - 2021-07-08 09:06:22 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:06:22 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:06:22 --> Model "Product_model" initialized
INFO - 2021-07-08 09:06:22 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:06:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:06:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:06:22 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:06:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:06:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:06:22 --> Final output sent to browser
DEBUG - 2021-07-08 09:06:22 --> Total execution time: 0.0772
INFO - 2021-07-08 09:06:24 --> Config Class Initialized
INFO - 2021-07-08 09:06:24 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:06:24 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:06:24 --> Utf8 Class Initialized
INFO - 2021-07-08 09:06:24 --> URI Class Initialized
INFO - 2021-07-08 09:06:24 --> Router Class Initialized
INFO - 2021-07-08 09:06:24 --> Output Class Initialized
INFO - 2021-07-08 09:06:24 --> Security Class Initialized
DEBUG - 2021-07-08 09:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:06:24 --> Input Class Initialized
INFO - 2021-07-08 09:06:24 --> Language Class Initialized
INFO - 2021-07-08 09:06:24 --> Loader Class Initialized
INFO - 2021-07-08 09:06:24 --> Helper loaded: html_helper
INFO - 2021-07-08 09:06:24 --> Helper loaded: url_helper
INFO - 2021-07-08 09:06:24 --> Helper loaded: form_helper
INFO - 2021-07-08 09:06:24 --> Database Driver Class Initialized
INFO - 2021-07-08 09:06:24 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:06:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:06:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:06:24 --> Encryption Class Initialized
INFO - 2021-07-08 09:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:06:24 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:06:24 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:06:24 --> Model "user_model" initialized
INFO - 2021-07-08 09:06:24 --> Model "role_model" initialized
INFO - 2021-07-08 09:06:24 --> Controller Class Initialized
INFO - 2021-07-08 09:06:24 --> Helper loaded: language_helper
INFO - 2021-07-08 09:06:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:06:24 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:06:24 --> Model "Product_model" initialized
INFO - 2021-07-08 09:06:24 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:06:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:06:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:06:24 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:06:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:06:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:06:24 --> Final output sent to browser
DEBUG - 2021-07-08 09:06:24 --> Total execution time: 0.0742
INFO - 2021-07-08 09:06:26 --> Config Class Initialized
INFO - 2021-07-08 09:06:26 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:06:26 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:06:26 --> Utf8 Class Initialized
INFO - 2021-07-08 09:06:26 --> URI Class Initialized
INFO - 2021-07-08 09:06:26 --> Router Class Initialized
INFO - 2021-07-08 09:06:26 --> Output Class Initialized
INFO - 2021-07-08 09:06:26 --> Security Class Initialized
DEBUG - 2021-07-08 09:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:06:26 --> Input Class Initialized
INFO - 2021-07-08 09:06:26 --> Language Class Initialized
INFO - 2021-07-08 09:06:26 --> Loader Class Initialized
INFO - 2021-07-08 09:06:26 --> Helper loaded: html_helper
INFO - 2021-07-08 09:06:26 --> Helper loaded: url_helper
INFO - 2021-07-08 09:06:26 --> Helper loaded: form_helper
INFO - 2021-07-08 09:06:26 --> Database Driver Class Initialized
INFO - 2021-07-08 09:06:26 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:06:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:06:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:06:26 --> Encryption Class Initialized
INFO - 2021-07-08 09:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:06:26 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:06:26 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:06:26 --> Model "user_model" initialized
INFO - 2021-07-08 09:06:26 --> Model "role_model" initialized
INFO - 2021-07-08 09:06:26 --> Controller Class Initialized
INFO - 2021-07-08 09:06:26 --> Helper loaded: language_helper
INFO - 2021-07-08 09:06:26 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:06:26 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:06:26 --> Model "Product_model" initialized
INFO - 2021-07-08 09:06:26 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:06:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:06:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:06:26 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:06:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:06:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:06:26 --> Final output sent to browser
DEBUG - 2021-07-08 09:06:26 --> Total execution time: 0.0673
INFO - 2021-07-08 09:06:48 --> Config Class Initialized
INFO - 2021-07-08 09:06:48 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:06:48 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:06:48 --> Utf8 Class Initialized
INFO - 2021-07-08 09:06:48 --> URI Class Initialized
INFO - 2021-07-08 09:06:48 --> Router Class Initialized
INFO - 2021-07-08 09:06:48 --> Output Class Initialized
INFO - 2021-07-08 09:06:48 --> Security Class Initialized
DEBUG - 2021-07-08 09:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:06:48 --> Input Class Initialized
INFO - 2021-07-08 09:06:48 --> Language Class Initialized
INFO - 2021-07-08 09:06:48 --> Loader Class Initialized
INFO - 2021-07-08 09:06:48 --> Helper loaded: html_helper
INFO - 2021-07-08 09:06:48 --> Helper loaded: url_helper
INFO - 2021-07-08 09:06:48 --> Helper loaded: form_helper
INFO - 2021-07-08 09:06:48 --> Database Driver Class Initialized
INFO - 2021-07-08 09:06:48 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:06:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:06:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:06:48 --> Encryption Class Initialized
INFO - 2021-07-08 09:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:06:48 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:06:48 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:06:48 --> Model "user_model" initialized
INFO - 2021-07-08 09:06:48 --> Model "role_model" initialized
INFO - 2021-07-08 09:06:48 --> Controller Class Initialized
INFO - 2021-07-08 09:06:48 --> Helper loaded: language_helper
INFO - 2021-07-08 09:06:48 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:06:48 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:06:48 --> Final output sent to browser
DEBUG - 2021-07-08 09:06:48 --> Total execution time: 0.0628
INFO - 2021-07-08 09:06:50 --> Config Class Initialized
INFO - 2021-07-08 09:06:50 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:06:50 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:06:50 --> Utf8 Class Initialized
INFO - 2021-07-08 09:06:50 --> URI Class Initialized
INFO - 2021-07-08 09:06:50 --> Router Class Initialized
INFO - 2021-07-08 09:06:50 --> Output Class Initialized
INFO - 2021-07-08 09:06:50 --> Security Class Initialized
DEBUG - 2021-07-08 09:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:06:50 --> Input Class Initialized
INFO - 2021-07-08 09:06:50 --> Language Class Initialized
INFO - 2021-07-08 09:06:50 --> Loader Class Initialized
INFO - 2021-07-08 09:06:50 --> Helper loaded: html_helper
INFO - 2021-07-08 09:06:50 --> Helper loaded: url_helper
INFO - 2021-07-08 09:06:50 --> Helper loaded: form_helper
INFO - 2021-07-08 09:06:50 --> Database Driver Class Initialized
INFO - 2021-07-08 09:06:50 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:06:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:06:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:06:50 --> Encryption Class Initialized
INFO - 2021-07-08 09:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:06:50 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:06:50 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:06:50 --> Model "user_model" initialized
INFO - 2021-07-08 09:06:50 --> Model "role_model" initialized
INFO - 2021-07-08 09:06:50 --> Controller Class Initialized
INFO - 2021-07-08 09:06:50 --> Helper loaded: language_helper
INFO - 2021-07-08 09:06:50 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:06:50 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:06:50 --> Final output sent to browser
DEBUG - 2021-07-08 09:06:50 --> Total execution time: 0.0595
INFO - 2021-07-08 09:08:07 --> Config Class Initialized
INFO - 2021-07-08 09:08:07 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:08:07 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:08:07 --> Utf8 Class Initialized
INFO - 2021-07-08 09:08:07 --> URI Class Initialized
INFO - 2021-07-08 09:08:07 --> Router Class Initialized
INFO - 2021-07-08 09:08:07 --> Output Class Initialized
INFO - 2021-07-08 09:08:07 --> Security Class Initialized
DEBUG - 2021-07-08 09:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:08:07 --> Input Class Initialized
INFO - 2021-07-08 09:08:07 --> Language Class Initialized
INFO - 2021-07-08 09:08:07 --> Loader Class Initialized
INFO - 2021-07-08 09:08:07 --> Helper loaded: html_helper
INFO - 2021-07-08 09:08:07 --> Helper loaded: url_helper
INFO - 2021-07-08 09:08:07 --> Helper loaded: form_helper
INFO - 2021-07-08 09:08:07 --> Database Driver Class Initialized
INFO - 2021-07-08 09:08:07 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:08:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:08:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:08:07 --> Encryption Class Initialized
INFO - 2021-07-08 09:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:08:07 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:08:07 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:08:07 --> Model "user_model" initialized
INFO - 2021-07-08 09:08:07 --> Model "role_model" initialized
INFO - 2021-07-08 09:08:07 --> Controller Class Initialized
INFO - 2021-07-08 09:08:07 --> Helper loaded: language_helper
INFO - 2021-07-08 09:08:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:08:07 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:08:07 --> Model "Product_model" initialized
INFO - 2021-07-08 09:08:07 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:08:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:08:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:08:07 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:08:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:08:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:08:07 --> Final output sent to browser
DEBUG - 2021-07-08 09:08:07 --> Total execution time: 0.0744
INFO - 2021-07-08 09:08:10 --> Config Class Initialized
INFO - 2021-07-08 09:08:10 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:08:10 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:08:10 --> Utf8 Class Initialized
INFO - 2021-07-08 09:08:10 --> URI Class Initialized
INFO - 2021-07-08 09:08:10 --> Router Class Initialized
INFO - 2021-07-08 09:08:10 --> Output Class Initialized
INFO - 2021-07-08 09:08:10 --> Security Class Initialized
DEBUG - 2021-07-08 09:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:08:10 --> Input Class Initialized
INFO - 2021-07-08 09:08:10 --> Language Class Initialized
INFO - 2021-07-08 09:08:10 --> Loader Class Initialized
INFO - 2021-07-08 09:08:10 --> Helper loaded: html_helper
INFO - 2021-07-08 09:08:10 --> Helper loaded: url_helper
INFO - 2021-07-08 09:08:10 --> Helper loaded: form_helper
INFO - 2021-07-08 09:08:10 --> Database Driver Class Initialized
INFO - 2021-07-08 09:08:10 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:08:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:08:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:08:10 --> Encryption Class Initialized
INFO - 2021-07-08 09:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:08:10 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:08:10 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:08:10 --> Model "user_model" initialized
INFO - 2021-07-08 09:08:10 --> Model "role_model" initialized
INFO - 2021-07-08 09:08:10 --> Controller Class Initialized
INFO - 2021-07-08 09:08:10 --> Helper loaded: language_helper
INFO - 2021-07-08 09:08:10 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:08:10 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:08:10 --> Model "Product_model" initialized
INFO - 2021-07-08 09:08:10 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:08:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:08:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:08:10 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:08:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:08:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:08:10 --> Final output sent to browser
DEBUG - 2021-07-08 09:08:10 --> Total execution time: 0.0750
INFO - 2021-07-08 09:08:27 --> Config Class Initialized
INFO - 2021-07-08 09:08:27 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:08:27 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:08:27 --> Utf8 Class Initialized
INFO - 2021-07-08 09:08:27 --> URI Class Initialized
INFO - 2021-07-08 09:08:27 --> Router Class Initialized
INFO - 2021-07-08 09:08:27 --> Output Class Initialized
INFO - 2021-07-08 09:08:27 --> Security Class Initialized
DEBUG - 2021-07-08 09:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:08:27 --> Input Class Initialized
INFO - 2021-07-08 09:08:27 --> Language Class Initialized
INFO - 2021-07-08 09:08:27 --> Loader Class Initialized
INFO - 2021-07-08 09:08:27 --> Helper loaded: html_helper
INFO - 2021-07-08 09:08:27 --> Helper loaded: url_helper
INFO - 2021-07-08 09:08:27 --> Helper loaded: form_helper
INFO - 2021-07-08 09:08:27 --> Database Driver Class Initialized
INFO - 2021-07-08 09:08:27 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:08:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:08:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:08:27 --> Encryption Class Initialized
INFO - 2021-07-08 09:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:08:27 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:08:27 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:08:27 --> Model "user_model" initialized
INFO - 2021-07-08 09:08:27 --> Model "role_model" initialized
INFO - 2021-07-08 09:08:27 --> Controller Class Initialized
INFO - 2021-07-08 09:08:27 --> Helper loaded: language_helper
INFO - 2021-07-08 09:08:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:08:27 --> Model "Quotation_model" initialized
INFO - 2021-07-08 09:08:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:08:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:08:27 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-08 09:08:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-08 09:08:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:08:27 --> Final output sent to browser
DEBUG - 2021-07-08 09:08:27 --> Total execution time: 0.2019
INFO - 2021-07-08 09:08:35 --> Config Class Initialized
INFO - 2021-07-08 09:08:35 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:08:35 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:08:35 --> Utf8 Class Initialized
INFO - 2021-07-08 09:08:35 --> URI Class Initialized
INFO - 2021-07-08 09:08:35 --> Router Class Initialized
INFO - 2021-07-08 09:08:35 --> Output Class Initialized
INFO - 2021-07-08 09:08:35 --> Security Class Initialized
DEBUG - 2021-07-08 09:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:08:35 --> Input Class Initialized
INFO - 2021-07-08 09:08:35 --> Language Class Initialized
INFO - 2021-07-08 09:08:35 --> Loader Class Initialized
INFO - 2021-07-08 09:08:35 --> Helper loaded: html_helper
INFO - 2021-07-08 09:08:35 --> Helper loaded: url_helper
INFO - 2021-07-08 09:08:35 --> Helper loaded: form_helper
INFO - 2021-07-08 09:08:35 --> Database Driver Class Initialized
INFO - 2021-07-08 09:08:35 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:08:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:08:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:08:35 --> Encryption Class Initialized
INFO - 2021-07-08 09:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:08:35 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:08:35 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:08:35 --> Model "user_model" initialized
INFO - 2021-07-08 09:08:35 --> Model "role_model" initialized
INFO - 2021-07-08 09:08:35 --> Controller Class Initialized
INFO - 2021-07-08 09:08:35 --> Helper loaded: language_helper
INFO - 2021-07-08 09:08:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:08:35 --> Model "Quotation_model" initialized
INFO - 2021-07-08 09:08:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:08:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:08:35 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-08 09:08:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-08 09:08:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:08:35 --> Final output sent to browser
DEBUG - 2021-07-08 09:08:35 --> Total execution time: 0.0708
INFO - 2021-07-08 09:08:38 --> Config Class Initialized
INFO - 2021-07-08 09:08:38 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:08:38 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:08:38 --> Utf8 Class Initialized
INFO - 2021-07-08 09:08:38 --> URI Class Initialized
INFO - 2021-07-08 09:08:38 --> Router Class Initialized
INFO - 2021-07-08 09:08:38 --> Output Class Initialized
INFO - 2021-07-08 09:08:38 --> Security Class Initialized
DEBUG - 2021-07-08 09:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:08:38 --> Input Class Initialized
INFO - 2021-07-08 09:08:38 --> Language Class Initialized
INFO - 2021-07-08 09:08:38 --> Loader Class Initialized
INFO - 2021-07-08 09:08:38 --> Helper loaded: html_helper
INFO - 2021-07-08 09:08:38 --> Helper loaded: url_helper
INFO - 2021-07-08 09:08:38 --> Helper loaded: form_helper
INFO - 2021-07-08 09:08:38 --> Database Driver Class Initialized
INFO - 2021-07-08 09:08:38 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:08:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:08:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:08:38 --> Encryption Class Initialized
INFO - 2021-07-08 09:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:08:38 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:08:38 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:08:38 --> Model "user_model" initialized
INFO - 2021-07-08 09:08:38 --> Model "role_model" initialized
INFO - 2021-07-08 09:08:38 --> Controller Class Initialized
INFO - 2021-07-08 09:08:38 --> Helper loaded: language_helper
INFO - 2021-07-08 09:08:38 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:08:38 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:08:38 --> Model "Product_model" initialized
INFO - 2021-07-08 09:08:38 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:08:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:08:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:08:38 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:08:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:08:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:08:38 --> Final output sent to browser
DEBUG - 2021-07-08 09:08:38 --> Total execution time: 0.0646
INFO - 2021-07-08 09:08:43 --> Config Class Initialized
INFO - 2021-07-08 09:08:43 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:08:43 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:08:43 --> Utf8 Class Initialized
INFO - 2021-07-08 09:08:43 --> URI Class Initialized
INFO - 2021-07-08 09:08:43 --> Router Class Initialized
INFO - 2021-07-08 09:08:43 --> Output Class Initialized
INFO - 2021-07-08 09:08:43 --> Security Class Initialized
DEBUG - 2021-07-08 09:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:08:43 --> Input Class Initialized
INFO - 2021-07-08 09:08:43 --> Language Class Initialized
INFO - 2021-07-08 09:08:43 --> Loader Class Initialized
INFO - 2021-07-08 09:08:43 --> Helper loaded: html_helper
INFO - 2021-07-08 09:08:43 --> Helper loaded: url_helper
INFO - 2021-07-08 09:08:43 --> Helper loaded: form_helper
INFO - 2021-07-08 09:08:43 --> Database Driver Class Initialized
INFO - 2021-07-08 09:08:43 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:08:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:08:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:08:43 --> Encryption Class Initialized
INFO - 2021-07-08 09:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:08:43 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:08:43 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:08:43 --> Model "user_model" initialized
INFO - 2021-07-08 09:08:43 --> Model "role_model" initialized
INFO - 2021-07-08 09:08:43 --> Controller Class Initialized
INFO - 2021-07-08 09:08:43 --> Helper loaded: language_helper
INFO - 2021-07-08 09:08:43 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:08:43 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:08:43 --> Model "Product_model" initialized
INFO - 2021-07-08 09:08:43 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:08:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:08:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:08:43 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:08:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:08:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:08:43 --> Final output sent to browser
DEBUG - 2021-07-08 09:08:43 --> Total execution time: 0.0744
INFO - 2021-07-08 09:08:46 --> Config Class Initialized
INFO - 2021-07-08 09:08:46 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:08:46 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:08:46 --> Utf8 Class Initialized
INFO - 2021-07-08 09:08:46 --> URI Class Initialized
INFO - 2021-07-08 09:08:46 --> Router Class Initialized
INFO - 2021-07-08 09:08:46 --> Output Class Initialized
INFO - 2021-07-08 09:08:46 --> Security Class Initialized
DEBUG - 2021-07-08 09:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:08:46 --> Input Class Initialized
INFO - 2021-07-08 09:08:46 --> Language Class Initialized
INFO - 2021-07-08 09:08:46 --> Loader Class Initialized
INFO - 2021-07-08 09:08:46 --> Helper loaded: html_helper
INFO - 2021-07-08 09:08:46 --> Helper loaded: url_helper
INFO - 2021-07-08 09:08:46 --> Helper loaded: form_helper
INFO - 2021-07-08 09:08:46 --> Database Driver Class Initialized
INFO - 2021-07-08 09:08:46 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:08:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:08:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:08:46 --> Encryption Class Initialized
INFO - 2021-07-08 09:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:08:46 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:08:46 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:08:46 --> Model "user_model" initialized
INFO - 2021-07-08 09:08:46 --> Model "role_model" initialized
INFO - 2021-07-08 09:08:46 --> Controller Class Initialized
INFO - 2021-07-08 09:08:46 --> Helper loaded: language_helper
INFO - 2021-07-08 09:08:46 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:08:46 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:08:46 --> Model "Product_model" initialized
INFO - 2021-07-08 09:08:46 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:08:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:08:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:08:46 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:08:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:08:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:08:46 --> Final output sent to browser
DEBUG - 2021-07-08 09:08:46 --> Total execution time: 0.0776
INFO - 2021-07-08 09:09:52 --> Config Class Initialized
INFO - 2021-07-08 09:09:52 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:09:52 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:09:52 --> Utf8 Class Initialized
INFO - 2021-07-08 09:09:52 --> URI Class Initialized
INFO - 2021-07-08 09:09:52 --> Router Class Initialized
INFO - 2021-07-08 09:09:52 --> Output Class Initialized
INFO - 2021-07-08 09:09:52 --> Security Class Initialized
DEBUG - 2021-07-08 09:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:09:52 --> Input Class Initialized
INFO - 2021-07-08 09:09:52 --> Language Class Initialized
INFO - 2021-07-08 09:09:52 --> Loader Class Initialized
INFO - 2021-07-08 09:09:52 --> Helper loaded: html_helper
INFO - 2021-07-08 09:09:52 --> Helper loaded: url_helper
INFO - 2021-07-08 09:09:52 --> Helper loaded: form_helper
INFO - 2021-07-08 09:09:52 --> Database Driver Class Initialized
INFO - 2021-07-08 09:09:52 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:09:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:09:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:09:52 --> Encryption Class Initialized
INFO - 2021-07-08 09:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:09:52 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:09:52 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:09:52 --> Model "user_model" initialized
INFO - 2021-07-08 09:09:52 --> Model "role_model" initialized
INFO - 2021-07-08 09:09:52 --> Controller Class Initialized
INFO - 2021-07-08 09:09:52 --> Helper loaded: language_helper
INFO - 2021-07-08 09:09:52 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:09:52 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:09:52 --> Final output sent to browser
DEBUG - 2021-07-08 09:09:52 --> Total execution time: 0.0684
INFO - 2021-07-08 09:12:44 --> Config Class Initialized
INFO - 2021-07-08 09:12:44 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:12:44 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:12:44 --> Utf8 Class Initialized
INFO - 2021-07-08 09:12:44 --> URI Class Initialized
INFO - 2021-07-08 09:12:44 --> Router Class Initialized
INFO - 2021-07-08 09:12:44 --> Output Class Initialized
INFO - 2021-07-08 09:12:44 --> Security Class Initialized
DEBUG - 2021-07-08 09:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:12:44 --> Input Class Initialized
INFO - 2021-07-08 09:12:44 --> Language Class Initialized
INFO - 2021-07-08 09:12:44 --> Loader Class Initialized
INFO - 2021-07-08 09:12:44 --> Helper loaded: html_helper
INFO - 2021-07-08 09:12:44 --> Helper loaded: url_helper
INFO - 2021-07-08 09:12:44 --> Helper loaded: form_helper
INFO - 2021-07-08 09:12:44 --> Database Driver Class Initialized
INFO - 2021-07-08 09:12:44 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:12:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:12:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:12:44 --> Encryption Class Initialized
INFO - 2021-07-08 09:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:12:44 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:12:44 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:12:44 --> Model "user_model" initialized
INFO - 2021-07-08 09:12:44 --> Model "role_model" initialized
INFO - 2021-07-08 09:12:44 --> Controller Class Initialized
INFO - 2021-07-08 09:12:44 --> Helper loaded: language_helper
INFO - 2021-07-08 09:12:44 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:12:44 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:12:44 --> Model "Product_model" initialized
INFO - 2021-07-08 09:12:44 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:12:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:12:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:12:44 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:12:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:12:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:12:44 --> Final output sent to browser
DEBUG - 2021-07-08 09:12:44 --> Total execution time: 0.1353
INFO - 2021-07-08 09:12:50 --> Config Class Initialized
INFO - 2021-07-08 09:12:50 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:12:50 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:12:50 --> Utf8 Class Initialized
INFO - 2021-07-08 09:12:50 --> URI Class Initialized
INFO - 2021-07-08 09:12:50 --> Router Class Initialized
INFO - 2021-07-08 09:12:50 --> Output Class Initialized
INFO - 2021-07-08 09:12:50 --> Security Class Initialized
DEBUG - 2021-07-08 09:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:12:50 --> Input Class Initialized
INFO - 2021-07-08 09:12:50 --> Language Class Initialized
INFO - 2021-07-08 09:12:50 --> Loader Class Initialized
INFO - 2021-07-08 09:12:50 --> Helper loaded: html_helper
INFO - 2021-07-08 09:12:50 --> Helper loaded: url_helper
INFO - 2021-07-08 09:12:50 --> Helper loaded: form_helper
INFO - 2021-07-08 09:12:50 --> Database Driver Class Initialized
INFO - 2021-07-08 09:12:50 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:12:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:12:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:12:50 --> Encryption Class Initialized
INFO - 2021-07-08 09:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:12:50 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:12:50 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:12:50 --> Model "user_model" initialized
INFO - 2021-07-08 09:12:50 --> Model "role_model" initialized
INFO - 2021-07-08 09:12:50 --> Controller Class Initialized
INFO - 2021-07-08 09:12:50 --> Helper loaded: language_helper
INFO - 2021-07-08 09:12:50 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:12:50 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:12:50 --> Final output sent to browser
DEBUG - 2021-07-08 09:12:50 --> Total execution time: 0.0635
INFO - 2021-07-08 09:14:11 --> Config Class Initialized
INFO - 2021-07-08 09:14:11 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:14:11 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:14:11 --> Utf8 Class Initialized
INFO - 2021-07-08 09:14:11 --> URI Class Initialized
INFO - 2021-07-08 09:14:11 --> Router Class Initialized
INFO - 2021-07-08 09:14:11 --> Output Class Initialized
INFO - 2021-07-08 09:14:11 --> Security Class Initialized
DEBUG - 2021-07-08 09:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:14:11 --> Input Class Initialized
INFO - 2021-07-08 09:14:11 --> Language Class Initialized
INFO - 2021-07-08 09:14:11 --> Loader Class Initialized
INFO - 2021-07-08 09:14:11 --> Helper loaded: html_helper
INFO - 2021-07-08 09:14:11 --> Helper loaded: url_helper
INFO - 2021-07-08 09:14:11 --> Helper loaded: form_helper
INFO - 2021-07-08 09:14:11 --> Database Driver Class Initialized
INFO - 2021-07-08 09:14:11 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:14:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:14:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:14:11 --> Encryption Class Initialized
INFO - 2021-07-08 09:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:14:11 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:14:11 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:14:11 --> Model "user_model" initialized
INFO - 2021-07-08 09:14:11 --> Model "role_model" initialized
INFO - 2021-07-08 09:14:11 --> Controller Class Initialized
INFO - 2021-07-08 09:14:11 --> Helper loaded: language_helper
INFO - 2021-07-08 09:14:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:14:11 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:14:11 --> Model "Product_model" initialized
INFO - 2021-07-08 09:14:11 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:14:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:14:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:14:11 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:14:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:14:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:14:11 --> Final output sent to browser
DEBUG - 2021-07-08 09:14:11 --> Total execution time: 0.1145
INFO - 2021-07-08 09:14:14 --> Config Class Initialized
INFO - 2021-07-08 09:14:14 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:14:14 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:14:14 --> Utf8 Class Initialized
INFO - 2021-07-08 09:14:14 --> URI Class Initialized
INFO - 2021-07-08 09:14:14 --> Router Class Initialized
INFO - 2021-07-08 09:14:14 --> Output Class Initialized
INFO - 2021-07-08 09:14:14 --> Security Class Initialized
DEBUG - 2021-07-08 09:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:14:14 --> Input Class Initialized
INFO - 2021-07-08 09:14:14 --> Language Class Initialized
INFO - 2021-07-08 09:14:14 --> Loader Class Initialized
INFO - 2021-07-08 09:14:14 --> Helper loaded: html_helper
INFO - 2021-07-08 09:14:14 --> Helper loaded: url_helper
INFO - 2021-07-08 09:14:14 --> Helper loaded: form_helper
INFO - 2021-07-08 09:14:14 --> Database Driver Class Initialized
INFO - 2021-07-08 09:14:14 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:14:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:14:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:14:14 --> Encryption Class Initialized
INFO - 2021-07-08 09:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:14:14 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:14:14 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:14:14 --> Model "user_model" initialized
INFO - 2021-07-08 09:14:14 --> Model "role_model" initialized
INFO - 2021-07-08 09:14:14 --> Controller Class Initialized
INFO - 2021-07-08 09:14:14 --> Helper loaded: language_helper
INFO - 2021-07-08 09:14:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:14:14 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:14:14 --> Final output sent to browser
DEBUG - 2021-07-08 09:14:14 --> Total execution time: 0.0646
INFO - 2021-07-08 09:16:07 --> Config Class Initialized
INFO - 2021-07-08 09:16:07 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:16:07 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:16:07 --> Utf8 Class Initialized
INFO - 2021-07-08 09:16:07 --> URI Class Initialized
INFO - 2021-07-08 09:16:07 --> Router Class Initialized
INFO - 2021-07-08 09:16:07 --> Output Class Initialized
INFO - 2021-07-08 09:16:07 --> Security Class Initialized
DEBUG - 2021-07-08 09:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:16:07 --> Input Class Initialized
INFO - 2021-07-08 09:16:07 --> Language Class Initialized
INFO - 2021-07-08 09:16:07 --> Loader Class Initialized
INFO - 2021-07-08 09:16:07 --> Helper loaded: html_helper
INFO - 2021-07-08 09:16:07 --> Helper loaded: url_helper
INFO - 2021-07-08 09:16:07 --> Helper loaded: form_helper
INFO - 2021-07-08 09:16:07 --> Database Driver Class Initialized
INFO - 2021-07-08 09:16:07 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:16:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:16:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:16:07 --> Encryption Class Initialized
INFO - 2021-07-08 09:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:16:07 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:16:07 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:16:07 --> Model "user_model" initialized
INFO - 2021-07-08 09:16:07 --> Model "role_model" initialized
INFO - 2021-07-08 09:16:07 --> Controller Class Initialized
INFO - 2021-07-08 09:16:07 --> Helper loaded: language_helper
INFO - 2021-07-08 09:16:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:16:07 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:16:07 --> Model "Product_model" initialized
INFO - 2021-07-08 09:16:07 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:16:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:16:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:16:07 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:16:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:16:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:16:07 --> Final output sent to browser
DEBUG - 2021-07-08 09:16:07 --> Total execution time: 0.1179
INFO - 2021-07-08 09:16:12 --> Config Class Initialized
INFO - 2021-07-08 09:16:12 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:16:12 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:16:12 --> Utf8 Class Initialized
INFO - 2021-07-08 09:16:12 --> URI Class Initialized
INFO - 2021-07-08 09:16:12 --> Router Class Initialized
INFO - 2021-07-08 09:16:12 --> Output Class Initialized
INFO - 2021-07-08 09:16:12 --> Security Class Initialized
DEBUG - 2021-07-08 09:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:16:12 --> Input Class Initialized
INFO - 2021-07-08 09:16:12 --> Language Class Initialized
INFO - 2021-07-08 09:16:12 --> Loader Class Initialized
INFO - 2021-07-08 09:16:12 --> Helper loaded: html_helper
INFO - 2021-07-08 09:16:12 --> Helper loaded: url_helper
INFO - 2021-07-08 09:16:12 --> Helper loaded: form_helper
INFO - 2021-07-08 09:16:12 --> Database Driver Class Initialized
INFO - 2021-07-08 09:16:12 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:16:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:16:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:16:12 --> Encryption Class Initialized
INFO - 2021-07-08 09:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:16:12 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:16:12 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:16:12 --> Model "user_model" initialized
INFO - 2021-07-08 09:16:12 --> Model "role_model" initialized
INFO - 2021-07-08 09:16:12 --> Controller Class Initialized
INFO - 2021-07-08 09:16:12 --> Helper loaded: language_helper
INFO - 2021-07-08 09:16:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:16:12 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:16:12 --> Final output sent to browser
DEBUG - 2021-07-08 09:16:12 --> Total execution time: 0.0640
INFO - 2021-07-08 09:16:21 --> Config Class Initialized
INFO - 2021-07-08 09:16:21 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:16:21 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:16:21 --> Utf8 Class Initialized
INFO - 2021-07-08 09:16:21 --> URI Class Initialized
INFO - 2021-07-08 09:16:21 --> Router Class Initialized
INFO - 2021-07-08 09:16:21 --> Output Class Initialized
INFO - 2021-07-08 09:16:21 --> Security Class Initialized
DEBUG - 2021-07-08 09:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:16:21 --> Input Class Initialized
INFO - 2021-07-08 09:16:21 --> Language Class Initialized
INFO - 2021-07-08 09:16:21 --> Loader Class Initialized
INFO - 2021-07-08 09:16:21 --> Helper loaded: html_helper
INFO - 2021-07-08 09:16:21 --> Helper loaded: url_helper
INFO - 2021-07-08 09:16:21 --> Helper loaded: form_helper
INFO - 2021-07-08 09:16:21 --> Database Driver Class Initialized
INFO - 2021-07-08 09:16:21 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:16:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:16:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:16:21 --> Encryption Class Initialized
INFO - 2021-07-08 09:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:16:21 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:16:21 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:16:21 --> Model "user_model" initialized
INFO - 2021-07-08 09:16:21 --> Model "role_model" initialized
INFO - 2021-07-08 09:16:21 --> Controller Class Initialized
INFO - 2021-07-08 09:16:21 --> Helper loaded: language_helper
INFO - 2021-07-08 09:16:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:16:21 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:16:21 --> Final output sent to browser
DEBUG - 2021-07-08 09:16:21 --> Total execution time: 0.0643
INFO - 2021-07-08 09:16:45 --> Config Class Initialized
INFO - 2021-07-08 09:16:45 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:16:45 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:16:45 --> Utf8 Class Initialized
INFO - 2021-07-08 09:16:45 --> URI Class Initialized
INFO - 2021-07-08 09:16:45 --> Router Class Initialized
INFO - 2021-07-08 09:16:45 --> Output Class Initialized
INFO - 2021-07-08 09:16:45 --> Security Class Initialized
DEBUG - 2021-07-08 09:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:16:45 --> Input Class Initialized
INFO - 2021-07-08 09:16:45 --> Language Class Initialized
INFO - 2021-07-08 09:16:45 --> Loader Class Initialized
INFO - 2021-07-08 09:16:45 --> Helper loaded: html_helper
INFO - 2021-07-08 09:16:45 --> Helper loaded: url_helper
INFO - 2021-07-08 09:16:45 --> Helper loaded: form_helper
INFO - 2021-07-08 09:16:45 --> Database Driver Class Initialized
INFO - 2021-07-08 09:16:45 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:16:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:16:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:16:45 --> Encryption Class Initialized
INFO - 2021-07-08 09:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:16:45 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:16:45 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:16:45 --> Model "user_model" initialized
INFO - 2021-07-08 09:16:45 --> Model "role_model" initialized
INFO - 2021-07-08 09:16:45 --> Controller Class Initialized
INFO - 2021-07-08 09:16:45 --> Helper loaded: language_helper
INFO - 2021-07-08 09:16:45 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:16:45 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:16:45 --> Model "Product_model" initialized
INFO - 2021-07-08 09:16:45 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:16:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:16:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:16:46 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:16:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:16:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:16:46 --> Final output sent to browser
DEBUG - 2021-07-08 09:16:46 --> Total execution time: 0.1119
INFO - 2021-07-08 09:16:49 --> Config Class Initialized
INFO - 2021-07-08 09:16:49 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:16:49 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:16:49 --> Utf8 Class Initialized
INFO - 2021-07-08 09:16:49 --> URI Class Initialized
INFO - 2021-07-08 09:16:49 --> Router Class Initialized
INFO - 2021-07-08 09:16:49 --> Output Class Initialized
INFO - 2021-07-08 09:16:49 --> Security Class Initialized
DEBUG - 2021-07-08 09:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:16:49 --> Input Class Initialized
INFO - 2021-07-08 09:16:49 --> Language Class Initialized
INFO - 2021-07-08 09:16:49 --> Loader Class Initialized
INFO - 2021-07-08 09:16:49 --> Helper loaded: html_helper
INFO - 2021-07-08 09:16:49 --> Helper loaded: url_helper
INFO - 2021-07-08 09:16:49 --> Helper loaded: form_helper
INFO - 2021-07-08 09:16:49 --> Database Driver Class Initialized
INFO - 2021-07-08 09:16:49 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:16:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:16:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:16:49 --> Encryption Class Initialized
INFO - 2021-07-08 09:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:16:49 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:16:49 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:16:49 --> Model "user_model" initialized
INFO - 2021-07-08 09:16:49 --> Model "role_model" initialized
INFO - 2021-07-08 09:16:49 --> Controller Class Initialized
INFO - 2021-07-08 09:16:49 --> Helper loaded: language_helper
INFO - 2021-07-08 09:16:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:16:49 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:16:49 --> Final output sent to browser
DEBUG - 2021-07-08 09:16:49 --> Total execution time: 0.0627
INFO - 2021-07-08 09:17:01 --> Config Class Initialized
INFO - 2021-07-08 09:17:01 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:17:01 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:17:01 --> Utf8 Class Initialized
INFO - 2021-07-08 09:17:01 --> URI Class Initialized
INFO - 2021-07-08 09:17:01 --> Router Class Initialized
INFO - 2021-07-08 09:17:01 --> Output Class Initialized
INFO - 2021-07-08 09:17:01 --> Security Class Initialized
DEBUG - 2021-07-08 09:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:17:01 --> Input Class Initialized
INFO - 2021-07-08 09:17:01 --> Language Class Initialized
INFO - 2021-07-08 09:17:01 --> Loader Class Initialized
INFO - 2021-07-08 09:17:01 --> Helper loaded: html_helper
INFO - 2021-07-08 09:17:01 --> Helper loaded: url_helper
INFO - 2021-07-08 09:17:01 --> Helper loaded: form_helper
INFO - 2021-07-08 09:17:01 --> Database Driver Class Initialized
INFO - 2021-07-08 09:17:02 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:17:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:17:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:17:02 --> Encryption Class Initialized
INFO - 2021-07-08 09:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:17:02 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:17:02 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:17:02 --> Model "user_model" initialized
INFO - 2021-07-08 09:17:02 --> Model "role_model" initialized
INFO - 2021-07-08 09:17:02 --> Controller Class Initialized
INFO - 2021-07-08 09:17:02 --> Helper loaded: language_helper
INFO - 2021-07-08 09:17:02 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:17:02 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:17:02 --> Model "Product_model" initialized
INFO - 2021-07-08 09:17:02 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:17:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:17:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:17:02 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:17:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:17:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:17:02 --> Final output sent to browser
DEBUG - 2021-07-08 09:17:02 --> Total execution time: 0.0782
INFO - 2021-07-08 09:17:07 --> Config Class Initialized
INFO - 2021-07-08 09:17:07 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:17:07 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:17:07 --> Utf8 Class Initialized
INFO - 2021-07-08 09:17:07 --> URI Class Initialized
INFO - 2021-07-08 09:17:07 --> Router Class Initialized
INFO - 2021-07-08 09:17:07 --> Output Class Initialized
INFO - 2021-07-08 09:17:07 --> Security Class Initialized
DEBUG - 2021-07-08 09:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:17:07 --> Input Class Initialized
INFO - 2021-07-08 09:17:07 --> Language Class Initialized
INFO - 2021-07-08 09:17:07 --> Loader Class Initialized
INFO - 2021-07-08 09:17:07 --> Helper loaded: html_helper
INFO - 2021-07-08 09:17:07 --> Helper loaded: url_helper
INFO - 2021-07-08 09:17:07 --> Helper loaded: form_helper
INFO - 2021-07-08 09:17:07 --> Database Driver Class Initialized
INFO - 2021-07-08 09:17:07 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:17:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:17:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:17:07 --> Encryption Class Initialized
INFO - 2021-07-08 09:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:17:07 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:17:07 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:17:07 --> Model "user_model" initialized
INFO - 2021-07-08 09:17:07 --> Model "role_model" initialized
INFO - 2021-07-08 09:17:07 --> Controller Class Initialized
INFO - 2021-07-08 09:17:07 --> Helper loaded: language_helper
INFO - 2021-07-08 09:17:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:17:07 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:17:07 --> Final output sent to browser
DEBUG - 2021-07-08 09:17:07 --> Total execution time: 0.0630
INFO - 2021-07-08 09:17:26 --> Config Class Initialized
INFO - 2021-07-08 09:17:26 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:17:26 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:17:26 --> Utf8 Class Initialized
INFO - 2021-07-08 09:17:26 --> URI Class Initialized
INFO - 2021-07-08 09:17:26 --> Router Class Initialized
INFO - 2021-07-08 09:17:26 --> Output Class Initialized
INFO - 2021-07-08 09:17:26 --> Security Class Initialized
DEBUG - 2021-07-08 09:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:17:26 --> Input Class Initialized
INFO - 2021-07-08 09:17:26 --> Language Class Initialized
INFO - 2021-07-08 09:17:26 --> Loader Class Initialized
INFO - 2021-07-08 09:17:26 --> Helper loaded: html_helper
INFO - 2021-07-08 09:17:26 --> Helper loaded: url_helper
INFO - 2021-07-08 09:17:26 --> Helper loaded: form_helper
INFO - 2021-07-08 09:17:26 --> Database Driver Class Initialized
INFO - 2021-07-08 09:17:26 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:17:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:17:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:17:26 --> Encryption Class Initialized
INFO - 2021-07-08 09:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:17:26 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:17:26 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:17:26 --> Model "user_model" initialized
INFO - 2021-07-08 09:17:26 --> Model "role_model" initialized
INFO - 2021-07-08 09:17:26 --> Controller Class Initialized
INFO - 2021-07-08 09:17:26 --> Helper loaded: language_helper
INFO - 2021-07-08 09:17:26 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:17:26 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:17:26 --> Model "Product_model" initialized
INFO - 2021-07-08 09:17:26 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:17:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:17:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:17:27 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:17:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:17:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:17:27 --> Final output sent to browser
DEBUG - 2021-07-08 09:17:27 --> Total execution time: 0.1228
INFO - 2021-07-08 09:17:30 --> Config Class Initialized
INFO - 2021-07-08 09:17:30 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:17:30 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:17:30 --> Utf8 Class Initialized
INFO - 2021-07-08 09:17:30 --> URI Class Initialized
INFO - 2021-07-08 09:17:30 --> Router Class Initialized
INFO - 2021-07-08 09:17:30 --> Output Class Initialized
INFO - 2021-07-08 09:17:30 --> Security Class Initialized
DEBUG - 2021-07-08 09:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:17:30 --> Input Class Initialized
INFO - 2021-07-08 09:17:30 --> Language Class Initialized
INFO - 2021-07-08 09:17:30 --> Loader Class Initialized
INFO - 2021-07-08 09:17:30 --> Helper loaded: html_helper
INFO - 2021-07-08 09:17:30 --> Helper loaded: url_helper
INFO - 2021-07-08 09:17:30 --> Helper loaded: form_helper
INFO - 2021-07-08 09:17:31 --> Database Driver Class Initialized
INFO - 2021-07-08 09:17:31 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:17:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:17:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:17:31 --> Encryption Class Initialized
INFO - 2021-07-08 09:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:17:31 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:17:31 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:17:31 --> Model "user_model" initialized
INFO - 2021-07-08 09:17:31 --> Model "role_model" initialized
INFO - 2021-07-08 09:17:31 --> Controller Class Initialized
INFO - 2021-07-08 09:17:31 --> Helper loaded: language_helper
INFO - 2021-07-08 09:17:31 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:17:31 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:17:31 --> Final output sent to browser
DEBUG - 2021-07-08 09:17:31 --> Total execution time: 0.0663
INFO - 2021-07-08 09:17:37 --> Config Class Initialized
INFO - 2021-07-08 09:17:37 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:17:37 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:17:37 --> Utf8 Class Initialized
INFO - 2021-07-08 09:17:37 --> URI Class Initialized
INFO - 2021-07-08 09:17:37 --> Router Class Initialized
INFO - 2021-07-08 09:17:37 --> Output Class Initialized
INFO - 2021-07-08 09:17:37 --> Security Class Initialized
DEBUG - 2021-07-08 09:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:17:37 --> Input Class Initialized
INFO - 2021-07-08 09:17:37 --> Language Class Initialized
INFO - 2021-07-08 09:17:37 --> Loader Class Initialized
INFO - 2021-07-08 09:17:37 --> Helper loaded: html_helper
INFO - 2021-07-08 09:17:37 --> Helper loaded: url_helper
INFO - 2021-07-08 09:17:37 --> Helper loaded: form_helper
INFO - 2021-07-08 09:17:37 --> Database Driver Class Initialized
INFO - 2021-07-08 09:17:37 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:17:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:17:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:17:37 --> Encryption Class Initialized
INFO - 2021-07-08 09:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:17:37 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:17:37 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:17:37 --> Model "user_model" initialized
INFO - 2021-07-08 09:17:37 --> Model "role_model" initialized
INFO - 2021-07-08 09:17:37 --> Controller Class Initialized
INFO - 2021-07-08 09:17:37 --> Helper loaded: language_helper
INFO - 2021-07-08 09:17:37 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:17:37 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:17:37 --> Final output sent to browser
DEBUG - 2021-07-08 09:17:37 --> Total execution time: 0.0604
INFO - 2021-07-08 09:18:08 --> Config Class Initialized
INFO - 2021-07-08 09:18:08 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:18:08 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:18:08 --> Utf8 Class Initialized
INFO - 2021-07-08 09:18:08 --> URI Class Initialized
INFO - 2021-07-08 09:18:08 --> Router Class Initialized
INFO - 2021-07-08 09:18:08 --> Output Class Initialized
INFO - 2021-07-08 09:18:08 --> Security Class Initialized
DEBUG - 2021-07-08 09:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:18:08 --> Input Class Initialized
INFO - 2021-07-08 09:18:08 --> Language Class Initialized
INFO - 2021-07-08 09:18:08 --> Loader Class Initialized
INFO - 2021-07-08 09:18:08 --> Helper loaded: html_helper
INFO - 2021-07-08 09:18:08 --> Helper loaded: url_helper
INFO - 2021-07-08 09:18:08 --> Helper loaded: form_helper
INFO - 2021-07-08 09:18:08 --> Database Driver Class Initialized
INFO - 2021-07-08 09:18:08 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:18:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:18:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:18:08 --> Encryption Class Initialized
INFO - 2021-07-08 09:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:18:08 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:18:08 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:18:08 --> Model "user_model" initialized
INFO - 2021-07-08 09:18:08 --> Model "role_model" initialized
INFO - 2021-07-08 09:18:08 --> Controller Class Initialized
INFO - 2021-07-08 09:18:08 --> Helper loaded: language_helper
INFO - 2021-07-08 09:18:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:18:08 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:18:08 --> Model "Product_model" initialized
INFO - 2021-07-08 09:18:08 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:18:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:18:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:18:08 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:18:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:18:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:18:08 --> Final output sent to browser
DEBUG - 2021-07-08 09:18:08 --> Total execution time: 0.1178
INFO - 2021-07-08 09:18:13 --> Config Class Initialized
INFO - 2021-07-08 09:18:13 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:18:13 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:18:13 --> Utf8 Class Initialized
INFO - 2021-07-08 09:18:13 --> URI Class Initialized
INFO - 2021-07-08 09:18:13 --> Router Class Initialized
INFO - 2021-07-08 09:18:13 --> Output Class Initialized
INFO - 2021-07-08 09:18:13 --> Security Class Initialized
DEBUG - 2021-07-08 09:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:18:13 --> Input Class Initialized
INFO - 2021-07-08 09:18:13 --> Language Class Initialized
INFO - 2021-07-08 09:18:13 --> Loader Class Initialized
INFO - 2021-07-08 09:18:13 --> Helper loaded: html_helper
INFO - 2021-07-08 09:18:13 --> Helper loaded: url_helper
INFO - 2021-07-08 09:18:13 --> Helper loaded: form_helper
INFO - 2021-07-08 09:18:13 --> Database Driver Class Initialized
INFO - 2021-07-08 09:18:13 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:18:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:18:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:18:13 --> Encryption Class Initialized
INFO - 2021-07-08 09:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:18:13 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:18:13 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:18:13 --> Model "user_model" initialized
INFO - 2021-07-08 09:18:13 --> Model "role_model" initialized
INFO - 2021-07-08 09:18:13 --> Controller Class Initialized
INFO - 2021-07-08 09:18:13 --> Helper loaded: language_helper
INFO - 2021-07-08 09:18:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:18:13 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:18:13 --> Final output sent to browser
DEBUG - 2021-07-08 09:18:13 --> Total execution time: 0.0971
INFO - 2021-07-08 09:18:28 --> Config Class Initialized
INFO - 2021-07-08 09:18:28 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:18:28 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:18:28 --> Utf8 Class Initialized
INFO - 2021-07-08 09:18:28 --> URI Class Initialized
INFO - 2021-07-08 09:18:28 --> Router Class Initialized
INFO - 2021-07-08 09:18:28 --> Output Class Initialized
INFO - 2021-07-08 09:18:28 --> Security Class Initialized
DEBUG - 2021-07-08 09:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:18:28 --> Input Class Initialized
INFO - 2021-07-08 09:18:28 --> Language Class Initialized
INFO - 2021-07-08 09:18:28 --> Loader Class Initialized
INFO - 2021-07-08 09:18:28 --> Helper loaded: html_helper
INFO - 2021-07-08 09:18:28 --> Helper loaded: url_helper
INFO - 2021-07-08 09:18:28 --> Helper loaded: form_helper
INFO - 2021-07-08 09:18:28 --> Database Driver Class Initialized
INFO - 2021-07-08 09:18:28 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:18:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:18:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:18:28 --> Encryption Class Initialized
INFO - 2021-07-08 09:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:18:28 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:18:28 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:18:28 --> Model "user_model" initialized
INFO - 2021-07-08 09:18:28 --> Model "role_model" initialized
INFO - 2021-07-08 09:18:28 --> Controller Class Initialized
INFO - 2021-07-08 09:18:28 --> Helper loaded: language_helper
INFO - 2021-07-08 09:18:28 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:18:28 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:18:28 --> Model "Product_model" initialized
INFO - 2021-07-08 09:18:28 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:18:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:18:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:18:28 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:18:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:18:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:18:28 --> Final output sent to browser
DEBUG - 2021-07-08 09:18:28 --> Total execution time: 0.1055
INFO - 2021-07-08 09:18:31 --> Config Class Initialized
INFO - 2021-07-08 09:18:31 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:18:31 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:18:31 --> Utf8 Class Initialized
INFO - 2021-07-08 09:18:31 --> URI Class Initialized
INFO - 2021-07-08 09:18:31 --> Router Class Initialized
INFO - 2021-07-08 09:18:31 --> Output Class Initialized
INFO - 2021-07-08 09:18:31 --> Security Class Initialized
DEBUG - 2021-07-08 09:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:18:31 --> Input Class Initialized
INFO - 2021-07-08 09:18:31 --> Language Class Initialized
INFO - 2021-07-08 09:18:31 --> Loader Class Initialized
INFO - 2021-07-08 09:18:31 --> Helper loaded: html_helper
INFO - 2021-07-08 09:18:31 --> Helper loaded: url_helper
INFO - 2021-07-08 09:18:31 --> Helper loaded: form_helper
INFO - 2021-07-08 09:18:31 --> Database Driver Class Initialized
INFO - 2021-07-08 09:18:31 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:18:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:18:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:18:31 --> Encryption Class Initialized
INFO - 2021-07-08 09:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:18:31 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:18:31 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:18:31 --> Model "user_model" initialized
INFO - 2021-07-08 09:18:31 --> Model "role_model" initialized
INFO - 2021-07-08 09:18:31 --> Controller Class Initialized
INFO - 2021-07-08 09:18:31 --> Helper loaded: language_helper
INFO - 2021-07-08 09:18:31 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:18:31 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:18:31 --> Final output sent to browser
DEBUG - 2021-07-08 09:18:31 --> Total execution time: 0.0631
INFO - 2021-07-08 09:18:55 --> Config Class Initialized
INFO - 2021-07-08 09:18:55 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:18:55 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:18:55 --> Utf8 Class Initialized
INFO - 2021-07-08 09:18:55 --> URI Class Initialized
INFO - 2021-07-08 09:18:55 --> Router Class Initialized
INFO - 2021-07-08 09:18:55 --> Output Class Initialized
INFO - 2021-07-08 09:18:55 --> Security Class Initialized
DEBUG - 2021-07-08 09:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:18:55 --> Input Class Initialized
INFO - 2021-07-08 09:18:55 --> Language Class Initialized
INFO - 2021-07-08 09:18:55 --> Loader Class Initialized
INFO - 2021-07-08 09:18:55 --> Helper loaded: html_helper
INFO - 2021-07-08 09:18:55 --> Helper loaded: url_helper
INFO - 2021-07-08 09:18:55 --> Helper loaded: form_helper
INFO - 2021-07-08 09:18:55 --> Database Driver Class Initialized
INFO - 2021-07-08 09:18:55 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:18:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:18:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:18:55 --> Encryption Class Initialized
INFO - 2021-07-08 09:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:18:55 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:18:55 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:18:55 --> Model "user_model" initialized
INFO - 2021-07-08 09:18:55 --> Model "role_model" initialized
INFO - 2021-07-08 09:18:55 --> Controller Class Initialized
INFO - 2021-07-08 09:18:55 --> Helper loaded: language_helper
INFO - 2021-07-08 09:18:55 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:18:55 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:18:55 --> Model "Product_model" initialized
INFO - 2021-07-08 09:18:55 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:18:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:18:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:18:55 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:18:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:18:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:18:55 --> Final output sent to browser
DEBUG - 2021-07-08 09:18:55 --> Total execution time: 0.1293
INFO - 2021-07-08 09:18:58 --> Config Class Initialized
INFO - 2021-07-08 09:18:58 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:18:58 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:18:58 --> Utf8 Class Initialized
INFO - 2021-07-08 09:18:58 --> URI Class Initialized
INFO - 2021-07-08 09:18:58 --> Router Class Initialized
INFO - 2021-07-08 09:18:58 --> Output Class Initialized
INFO - 2021-07-08 09:18:58 --> Security Class Initialized
DEBUG - 2021-07-08 09:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:18:58 --> Input Class Initialized
INFO - 2021-07-08 09:18:58 --> Language Class Initialized
INFO - 2021-07-08 09:18:58 --> Loader Class Initialized
INFO - 2021-07-08 09:18:58 --> Helper loaded: html_helper
INFO - 2021-07-08 09:18:58 --> Helper loaded: url_helper
INFO - 2021-07-08 09:18:58 --> Helper loaded: form_helper
INFO - 2021-07-08 09:18:58 --> Database Driver Class Initialized
INFO - 2021-07-08 09:18:58 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:18:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:18:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:18:58 --> Encryption Class Initialized
INFO - 2021-07-08 09:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:18:58 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:18:58 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:18:58 --> Model "user_model" initialized
INFO - 2021-07-08 09:18:58 --> Model "role_model" initialized
INFO - 2021-07-08 09:18:58 --> Controller Class Initialized
INFO - 2021-07-08 09:18:58 --> Helper loaded: language_helper
INFO - 2021-07-08 09:18:58 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:18:58 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:18:58 --> Final output sent to browser
DEBUG - 2021-07-08 09:18:58 --> Total execution time: 0.0609
INFO - 2021-07-08 09:19:11 --> Config Class Initialized
INFO - 2021-07-08 09:19:11 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:19:11 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:19:11 --> Utf8 Class Initialized
INFO - 2021-07-08 09:19:11 --> URI Class Initialized
INFO - 2021-07-08 09:19:11 --> Router Class Initialized
INFO - 2021-07-08 09:19:11 --> Output Class Initialized
INFO - 2021-07-08 09:19:11 --> Security Class Initialized
DEBUG - 2021-07-08 09:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:19:11 --> Input Class Initialized
INFO - 2021-07-08 09:19:11 --> Language Class Initialized
INFO - 2021-07-08 09:19:11 --> Loader Class Initialized
INFO - 2021-07-08 09:19:11 --> Helper loaded: html_helper
INFO - 2021-07-08 09:19:11 --> Helper loaded: url_helper
INFO - 2021-07-08 09:19:11 --> Helper loaded: form_helper
INFO - 2021-07-08 09:19:11 --> Database Driver Class Initialized
INFO - 2021-07-08 09:19:11 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:19:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:19:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:19:11 --> Encryption Class Initialized
INFO - 2021-07-08 09:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:19:11 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:19:11 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:19:11 --> Model "user_model" initialized
INFO - 2021-07-08 09:19:11 --> Model "role_model" initialized
INFO - 2021-07-08 09:19:11 --> Controller Class Initialized
INFO - 2021-07-08 09:19:11 --> Helper loaded: language_helper
INFO - 2021-07-08 09:19:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:19:11 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:19:11 --> Model "Product_model" initialized
INFO - 2021-07-08 09:19:11 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:19:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:19:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:19:11 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:19:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:19:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:19:11 --> Final output sent to browser
DEBUG - 2021-07-08 09:19:11 --> Total execution time: 0.0804
INFO - 2021-07-08 09:21:16 --> Config Class Initialized
INFO - 2021-07-08 09:21:16 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:21:16 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:21:16 --> Utf8 Class Initialized
INFO - 2021-07-08 09:21:16 --> URI Class Initialized
INFO - 2021-07-08 09:21:16 --> Router Class Initialized
INFO - 2021-07-08 09:21:16 --> Output Class Initialized
INFO - 2021-07-08 09:21:16 --> Security Class Initialized
DEBUG - 2021-07-08 09:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:21:16 --> Input Class Initialized
INFO - 2021-07-08 09:21:16 --> Language Class Initialized
INFO - 2021-07-08 09:21:16 --> Loader Class Initialized
INFO - 2021-07-08 09:21:16 --> Helper loaded: html_helper
INFO - 2021-07-08 09:21:16 --> Helper loaded: url_helper
INFO - 2021-07-08 09:21:16 --> Helper loaded: form_helper
INFO - 2021-07-08 09:21:16 --> Database Driver Class Initialized
INFO - 2021-07-08 09:21:16 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:21:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:21:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:21:16 --> Encryption Class Initialized
INFO - 2021-07-08 09:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:21:16 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:21:16 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:21:16 --> Model "user_model" initialized
INFO - 2021-07-08 09:21:16 --> Model "role_model" initialized
INFO - 2021-07-08 09:21:16 --> Controller Class Initialized
INFO - 2021-07-08 09:21:16 --> Helper loaded: language_helper
INFO - 2021-07-08 09:21:16 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:21:16 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:21:16 --> Model "Product_model" initialized
INFO - 2021-07-08 09:21:16 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:21:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:21:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:21:16 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:21:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:21:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:21:16 --> Final output sent to browser
DEBUG - 2021-07-08 09:21:16 --> Total execution time: 0.1256
INFO - 2021-07-08 09:21:20 --> Config Class Initialized
INFO - 2021-07-08 09:21:20 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:21:20 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:21:20 --> Utf8 Class Initialized
INFO - 2021-07-08 09:21:20 --> URI Class Initialized
INFO - 2021-07-08 09:21:20 --> Router Class Initialized
INFO - 2021-07-08 09:21:20 --> Output Class Initialized
INFO - 2021-07-08 09:21:20 --> Security Class Initialized
DEBUG - 2021-07-08 09:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:21:20 --> Input Class Initialized
INFO - 2021-07-08 09:21:20 --> Language Class Initialized
INFO - 2021-07-08 09:21:20 --> Loader Class Initialized
INFO - 2021-07-08 09:21:20 --> Helper loaded: html_helper
INFO - 2021-07-08 09:21:20 --> Helper loaded: url_helper
INFO - 2021-07-08 09:21:20 --> Helper loaded: form_helper
INFO - 2021-07-08 09:21:20 --> Database Driver Class Initialized
INFO - 2021-07-08 09:21:20 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:21:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:21:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:21:20 --> Encryption Class Initialized
INFO - 2021-07-08 09:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:21:20 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:21:20 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:21:20 --> Model "user_model" initialized
INFO - 2021-07-08 09:21:20 --> Model "role_model" initialized
INFO - 2021-07-08 09:21:20 --> Controller Class Initialized
INFO - 2021-07-08 09:21:20 --> Helper loaded: language_helper
INFO - 2021-07-08 09:21:20 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:21:20 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:21:20 --> Final output sent to browser
DEBUG - 2021-07-08 09:21:20 --> Total execution time: 0.0625
INFO - 2021-07-08 09:21:47 --> Config Class Initialized
INFO - 2021-07-08 09:21:47 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:21:47 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:21:47 --> Utf8 Class Initialized
INFO - 2021-07-08 09:21:47 --> URI Class Initialized
INFO - 2021-07-08 09:21:47 --> Router Class Initialized
INFO - 2021-07-08 09:21:47 --> Output Class Initialized
INFO - 2021-07-08 09:21:47 --> Security Class Initialized
DEBUG - 2021-07-08 09:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:21:47 --> Input Class Initialized
INFO - 2021-07-08 09:21:47 --> Language Class Initialized
INFO - 2021-07-08 09:21:47 --> Loader Class Initialized
INFO - 2021-07-08 09:21:47 --> Helper loaded: html_helper
INFO - 2021-07-08 09:21:47 --> Helper loaded: url_helper
INFO - 2021-07-08 09:21:47 --> Helper loaded: form_helper
INFO - 2021-07-08 09:21:47 --> Database Driver Class Initialized
INFO - 2021-07-08 09:21:47 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:21:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:21:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:21:47 --> Encryption Class Initialized
INFO - 2021-07-08 09:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:21:47 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:21:47 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:21:47 --> Model "user_model" initialized
INFO - 2021-07-08 09:21:47 --> Model "role_model" initialized
INFO - 2021-07-08 09:21:47 --> Controller Class Initialized
INFO - 2021-07-08 09:21:47 --> Helper loaded: language_helper
INFO - 2021-07-08 09:21:47 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:21:47 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:21:47 --> Model "Product_model" initialized
INFO - 2021-07-08 09:21:47 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:21:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:21:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:21:47 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:21:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:21:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:21:47 --> Final output sent to browser
DEBUG - 2021-07-08 09:21:47 --> Total execution time: 0.1084
INFO - 2021-07-08 09:21:54 --> Config Class Initialized
INFO - 2021-07-08 09:21:54 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:21:54 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:21:54 --> Utf8 Class Initialized
INFO - 2021-07-08 09:21:54 --> URI Class Initialized
INFO - 2021-07-08 09:21:54 --> Router Class Initialized
INFO - 2021-07-08 09:21:54 --> Output Class Initialized
INFO - 2021-07-08 09:21:54 --> Security Class Initialized
DEBUG - 2021-07-08 09:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:21:54 --> Input Class Initialized
INFO - 2021-07-08 09:21:54 --> Language Class Initialized
INFO - 2021-07-08 09:21:54 --> Loader Class Initialized
INFO - 2021-07-08 09:21:54 --> Helper loaded: html_helper
INFO - 2021-07-08 09:21:54 --> Helper loaded: url_helper
INFO - 2021-07-08 09:21:54 --> Helper loaded: form_helper
INFO - 2021-07-08 09:21:54 --> Database Driver Class Initialized
INFO - 2021-07-08 09:21:54 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:21:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:21:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:21:54 --> Encryption Class Initialized
INFO - 2021-07-08 09:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:21:54 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:21:54 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:21:54 --> Model "user_model" initialized
INFO - 2021-07-08 09:21:54 --> Model "role_model" initialized
INFO - 2021-07-08 09:21:54 --> Controller Class Initialized
INFO - 2021-07-08 09:21:54 --> Helper loaded: language_helper
INFO - 2021-07-08 09:21:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:21:54 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:21:54 --> Final output sent to browser
DEBUG - 2021-07-08 09:21:54 --> Total execution time: 0.0582
INFO - 2021-07-08 09:21:58 --> Config Class Initialized
INFO - 2021-07-08 09:21:58 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:21:58 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:21:58 --> Utf8 Class Initialized
INFO - 2021-07-08 09:21:58 --> URI Class Initialized
INFO - 2021-07-08 09:21:58 --> Router Class Initialized
INFO - 2021-07-08 09:21:58 --> Output Class Initialized
INFO - 2021-07-08 09:21:58 --> Security Class Initialized
DEBUG - 2021-07-08 09:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:21:58 --> Input Class Initialized
INFO - 2021-07-08 09:21:58 --> Language Class Initialized
INFO - 2021-07-08 09:21:58 --> Loader Class Initialized
INFO - 2021-07-08 09:21:58 --> Helper loaded: html_helper
INFO - 2021-07-08 09:21:58 --> Helper loaded: url_helper
INFO - 2021-07-08 09:21:58 --> Helper loaded: form_helper
INFO - 2021-07-08 09:21:58 --> Database Driver Class Initialized
INFO - 2021-07-08 09:21:58 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:21:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:21:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:21:58 --> Encryption Class Initialized
INFO - 2021-07-08 09:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:21:58 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:21:58 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:21:58 --> Model "user_model" initialized
INFO - 2021-07-08 09:21:58 --> Model "role_model" initialized
INFO - 2021-07-08 09:21:58 --> Controller Class Initialized
INFO - 2021-07-08 09:21:58 --> Helper loaded: language_helper
INFO - 2021-07-08 09:21:58 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:21:58 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:21:58 --> Model "Product_model" initialized
INFO - 2021-07-08 09:21:58 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:21:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:21:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:21:58 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:21:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:21:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:21:58 --> Final output sent to browser
DEBUG - 2021-07-08 09:21:58 --> Total execution time: 0.0741
INFO - 2021-07-08 09:26:57 --> Config Class Initialized
INFO - 2021-07-08 09:26:57 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:26:57 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:26:57 --> Utf8 Class Initialized
INFO - 2021-07-08 09:26:57 --> URI Class Initialized
INFO - 2021-07-08 09:26:57 --> Router Class Initialized
INFO - 2021-07-08 09:26:57 --> Output Class Initialized
INFO - 2021-07-08 09:26:57 --> Security Class Initialized
DEBUG - 2021-07-08 09:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:26:57 --> Input Class Initialized
INFO - 2021-07-08 09:26:57 --> Language Class Initialized
INFO - 2021-07-08 09:26:57 --> Loader Class Initialized
INFO - 2021-07-08 09:26:57 --> Helper loaded: html_helper
INFO - 2021-07-08 09:26:57 --> Helper loaded: url_helper
INFO - 2021-07-08 09:26:57 --> Helper loaded: form_helper
INFO - 2021-07-08 09:26:57 --> Database Driver Class Initialized
INFO - 2021-07-08 09:26:57 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:26:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:26:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:26:57 --> Encryption Class Initialized
INFO - 2021-07-08 09:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:26:57 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:26:57 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:26:57 --> Model "user_model" initialized
INFO - 2021-07-08 09:26:57 --> Model "role_model" initialized
INFO - 2021-07-08 09:26:57 --> Controller Class Initialized
INFO - 2021-07-08 09:26:57 --> Helper loaded: language_helper
INFO - 2021-07-08 09:26:57 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:26:57 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:26:57 --> Model "Product_model" initialized
INFO - 2021-07-08 09:26:57 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:26:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:26:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:26:57 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:26:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:26:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:26:57 --> Final output sent to browser
DEBUG - 2021-07-08 09:26:57 --> Total execution time: 0.1187
INFO - 2021-07-08 09:27:01 --> Config Class Initialized
INFO - 2021-07-08 09:27:01 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:27:01 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:27:01 --> Utf8 Class Initialized
INFO - 2021-07-08 09:27:01 --> URI Class Initialized
INFO - 2021-07-08 09:27:01 --> Router Class Initialized
INFO - 2021-07-08 09:27:01 --> Output Class Initialized
INFO - 2021-07-08 09:27:01 --> Security Class Initialized
DEBUG - 2021-07-08 09:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:27:01 --> Input Class Initialized
INFO - 2021-07-08 09:27:01 --> Language Class Initialized
INFO - 2021-07-08 09:27:01 --> Loader Class Initialized
INFO - 2021-07-08 09:27:01 --> Helper loaded: html_helper
INFO - 2021-07-08 09:27:01 --> Helper loaded: url_helper
INFO - 2021-07-08 09:27:01 --> Helper loaded: form_helper
INFO - 2021-07-08 09:27:01 --> Database Driver Class Initialized
INFO - 2021-07-08 09:27:01 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:27:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:27:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:27:01 --> Encryption Class Initialized
INFO - 2021-07-08 09:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:27:01 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:27:01 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:27:01 --> Model "user_model" initialized
INFO - 2021-07-08 09:27:01 --> Model "role_model" initialized
INFO - 2021-07-08 09:27:01 --> Controller Class Initialized
INFO - 2021-07-08 09:27:01 --> Helper loaded: language_helper
INFO - 2021-07-08 09:27:01 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:27:01 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:27:01 --> Final output sent to browser
DEBUG - 2021-07-08 09:27:01 --> Total execution time: 0.0657
INFO - 2021-07-08 09:27:17 --> Config Class Initialized
INFO - 2021-07-08 09:27:17 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:27:17 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:27:17 --> Utf8 Class Initialized
INFO - 2021-07-08 09:27:17 --> URI Class Initialized
INFO - 2021-07-08 09:27:17 --> Router Class Initialized
INFO - 2021-07-08 09:27:17 --> Output Class Initialized
INFO - 2021-07-08 09:27:17 --> Security Class Initialized
DEBUG - 2021-07-08 09:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:27:17 --> Input Class Initialized
INFO - 2021-07-08 09:27:17 --> Language Class Initialized
INFO - 2021-07-08 09:27:17 --> Loader Class Initialized
INFO - 2021-07-08 09:27:17 --> Helper loaded: html_helper
INFO - 2021-07-08 09:27:17 --> Helper loaded: url_helper
INFO - 2021-07-08 09:27:17 --> Helper loaded: form_helper
INFO - 2021-07-08 09:27:17 --> Database Driver Class Initialized
INFO - 2021-07-08 09:27:17 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:27:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:27:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:27:17 --> Encryption Class Initialized
INFO - 2021-07-08 09:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:27:17 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:27:17 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:27:17 --> Model "user_model" initialized
INFO - 2021-07-08 09:27:17 --> Model "role_model" initialized
INFO - 2021-07-08 09:27:17 --> Controller Class Initialized
INFO - 2021-07-08 09:27:17 --> Helper loaded: language_helper
INFO - 2021-07-08 09:27:17 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:27:17 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:27:17 --> Model "Product_model" initialized
INFO - 2021-07-08 09:27:17 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:27:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:27:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:27:17 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:27:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:27:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:27:17 --> Final output sent to browser
DEBUG - 2021-07-08 09:27:17 --> Total execution time: 0.1173
INFO - 2021-07-08 09:27:20 --> Config Class Initialized
INFO - 2021-07-08 09:27:20 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:27:20 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:27:20 --> Utf8 Class Initialized
INFO - 2021-07-08 09:27:20 --> URI Class Initialized
INFO - 2021-07-08 09:27:20 --> Router Class Initialized
INFO - 2021-07-08 09:27:20 --> Output Class Initialized
INFO - 2021-07-08 09:27:20 --> Security Class Initialized
DEBUG - 2021-07-08 09:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:27:20 --> Input Class Initialized
INFO - 2021-07-08 09:27:20 --> Language Class Initialized
INFO - 2021-07-08 09:27:20 --> Loader Class Initialized
INFO - 2021-07-08 09:27:20 --> Helper loaded: html_helper
INFO - 2021-07-08 09:27:20 --> Helper loaded: url_helper
INFO - 2021-07-08 09:27:20 --> Helper loaded: form_helper
INFO - 2021-07-08 09:27:20 --> Database Driver Class Initialized
INFO - 2021-07-08 09:27:20 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:27:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:27:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:27:20 --> Encryption Class Initialized
INFO - 2021-07-08 09:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:27:20 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:27:20 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:27:20 --> Model "user_model" initialized
INFO - 2021-07-08 09:27:20 --> Model "role_model" initialized
INFO - 2021-07-08 09:27:20 --> Controller Class Initialized
INFO - 2021-07-08 09:27:20 --> Helper loaded: language_helper
INFO - 2021-07-08 09:27:20 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:27:20 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:27:20 --> Final output sent to browser
DEBUG - 2021-07-08 09:27:20 --> Total execution time: 0.0632
INFO - 2021-07-08 09:27:46 --> Config Class Initialized
INFO - 2021-07-08 09:27:46 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:27:46 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:27:46 --> Utf8 Class Initialized
INFO - 2021-07-08 09:27:46 --> URI Class Initialized
INFO - 2021-07-08 09:27:46 --> Router Class Initialized
INFO - 2021-07-08 09:27:46 --> Output Class Initialized
INFO - 2021-07-08 09:27:46 --> Security Class Initialized
DEBUG - 2021-07-08 09:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:27:46 --> Input Class Initialized
INFO - 2021-07-08 09:27:46 --> Language Class Initialized
INFO - 2021-07-08 09:27:46 --> Loader Class Initialized
INFO - 2021-07-08 09:27:46 --> Helper loaded: html_helper
INFO - 2021-07-08 09:27:46 --> Helper loaded: url_helper
INFO - 2021-07-08 09:27:46 --> Helper loaded: form_helper
INFO - 2021-07-08 09:27:46 --> Database Driver Class Initialized
INFO - 2021-07-08 09:27:46 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:27:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:27:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:27:46 --> Encryption Class Initialized
INFO - 2021-07-08 09:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:27:46 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:27:46 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:27:46 --> Model "user_model" initialized
INFO - 2021-07-08 09:27:46 --> Model "role_model" initialized
INFO - 2021-07-08 09:27:46 --> Controller Class Initialized
INFO - 2021-07-08 09:27:46 --> Helper loaded: language_helper
INFO - 2021-07-08 09:27:46 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:27:46 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:27:46 --> Model "Product_model" initialized
INFO - 2021-07-08 09:27:46 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:27:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:27:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:27:46 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:27:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:27:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:27:46 --> Final output sent to browser
DEBUG - 2021-07-08 09:27:46 --> Total execution time: 0.1194
INFO - 2021-07-08 09:27:51 --> Config Class Initialized
INFO - 2021-07-08 09:27:51 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:27:51 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:27:51 --> Utf8 Class Initialized
INFO - 2021-07-08 09:27:51 --> URI Class Initialized
INFO - 2021-07-08 09:27:51 --> Router Class Initialized
INFO - 2021-07-08 09:27:51 --> Output Class Initialized
INFO - 2021-07-08 09:27:51 --> Security Class Initialized
DEBUG - 2021-07-08 09:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:27:51 --> Input Class Initialized
INFO - 2021-07-08 09:27:51 --> Language Class Initialized
INFO - 2021-07-08 09:27:51 --> Loader Class Initialized
INFO - 2021-07-08 09:27:51 --> Helper loaded: html_helper
INFO - 2021-07-08 09:27:51 --> Helper loaded: url_helper
INFO - 2021-07-08 09:27:51 --> Helper loaded: form_helper
INFO - 2021-07-08 09:27:51 --> Database Driver Class Initialized
INFO - 2021-07-08 09:27:51 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:27:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:27:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:27:51 --> Encryption Class Initialized
INFO - 2021-07-08 09:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:27:51 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:27:51 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:27:51 --> Model "user_model" initialized
INFO - 2021-07-08 09:27:51 --> Model "role_model" initialized
INFO - 2021-07-08 09:27:51 --> Controller Class Initialized
INFO - 2021-07-08 09:27:51 --> Helper loaded: language_helper
INFO - 2021-07-08 09:27:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:27:51 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:27:51 --> Final output sent to browser
DEBUG - 2021-07-08 09:27:51 --> Total execution time: 0.0592
INFO - 2021-07-08 09:31:56 --> Config Class Initialized
INFO - 2021-07-08 09:31:56 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:31:56 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:31:56 --> Utf8 Class Initialized
INFO - 2021-07-08 09:31:56 --> URI Class Initialized
INFO - 2021-07-08 09:31:56 --> Router Class Initialized
INFO - 2021-07-08 09:31:56 --> Output Class Initialized
INFO - 2021-07-08 09:31:56 --> Security Class Initialized
DEBUG - 2021-07-08 09:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:31:56 --> Input Class Initialized
INFO - 2021-07-08 09:31:56 --> Language Class Initialized
INFO - 2021-07-08 09:31:56 --> Loader Class Initialized
INFO - 2021-07-08 09:31:56 --> Helper loaded: html_helper
INFO - 2021-07-08 09:31:56 --> Helper loaded: url_helper
INFO - 2021-07-08 09:31:56 --> Helper loaded: form_helper
INFO - 2021-07-08 09:31:56 --> Database Driver Class Initialized
INFO - 2021-07-08 09:31:56 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:31:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:31:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:31:56 --> Encryption Class Initialized
INFO - 2021-07-08 09:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:31:56 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:31:56 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:31:56 --> Model "user_model" initialized
INFO - 2021-07-08 09:31:56 --> Model "role_model" initialized
INFO - 2021-07-08 09:31:56 --> Controller Class Initialized
INFO - 2021-07-08 09:31:56 --> Helper loaded: language_helper
INFO - 2021-07-08 09:31:56 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:31:56 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:31:56 --> Model "Product_model" initialized
INFO - 2021-07-08 09:31:56 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:31:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:31:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:31:56 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:31:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:31:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:31:56 --> Final output sent to browser
DEBUG - 2021-07-08 09:31:56 --> Total execution time: 0.1181
INFO - 2021-07-08 09:32:00 --> Config Class Initialized
INFO - 2021-07-08 09:32:00 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:32:00 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:32:00 --> Utf8 Class Initialized
INFO - 2021-07-08 09:32:00 --> URI Class Initialized
INFO - 2021-07-08 09:32:00 --> Router Class Initialized
INFO - 2021-07-08 09:32:00 --> Output Class Initialized
INFO - 2021-07-08 09:32:00 --> Security Class Initialized
DEBUG - 2021-07-08 09:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:32:00 --> Input Class Initialized
INFO - 2021-07-08 09:32:00 --> Language Class Initialized
INFO - 2021-07-08 09:32:00 --> Loader Class Initialized
INFO - 2021-07-08 09:32:00 --> Helper loaded: html_helper
INFO - 2021-07-08 09:32:00 --> Helper loaded: url_helper
INFO - 2021-07-08 09:32:00 --> Helper loaded: form_helper
INFO - 2021-07-08 09:32:00 --> Database Driver Class Initialized
INFO - 2021-07-08 09:32:00 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:32:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:32:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:32:00 --> Encryption Class Initialized
INFO - 2021-07-08 09:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:32:00 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:32:00 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:32:00 --> Model "user_model" initialized
INFO - 2021-07-08 09:32:00 --> Model "role_model" initialized
INFO - 2021-07-08 09:32:00 --> Controller Class Initialized
INFO - 2021-07-08 09:32:00 --> Helper loaded: language_helper
INFO - 2021-07-08 09:32:00 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:32:00 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:32:00 --> Final output sent to browser
DEBUG - 2021-07-08 09:32:00 --> Total execution time: 0.0592
INFO - 2021-07-08 09:33:21 --> Config Class Initialized
INFO - 2021-07-08 09:33:21 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:33:21 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:33:21 --> Utf8 Class Initialized
INFO - 2021-07-08 09:33:21 --> URI Class Initialized
INFO - 2021-07-08 09:33:21 --> Router Class Initialized
INFO - 2021-07-08 09:33:21 --> Output Class Initialized
INFO - 2021-07-08 09:33:21 --> Security Class Initialized
DEBUG - 2021-07-08 09:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:33:21 --> Input Class Initialized
INFO - 2021-07-08 09:33:21 --> Language Class Initialized
INFO - 2021-07-08 09:33:21 --> Loader Class Initialized
INFO - 2021-07-08 09:33:21 --> Helper loaded: html_helper
INFO - 2021-07-08 09:33:21 --> Helper loaded: url_helper
INFO - 2021-07-08 09:33:21 --> Helper loaded: form_helper
INFO - 2021-07-08 09:33:21 --> Database Driver Class Initialized
INFO - 2021-07-08 09:33:21 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:33:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:33:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:33:21 --> Encryption Class Initialized
INFO - 2021-07-08 09:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:33:21 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:33:21 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:33:21 --> Model "user_model" initialized
INFO - 2021-07-08 09:33:21 --> Model "role_model" initialized
INFO - 2021-07-08 09:33:21 --> Controller Class Initialized
INFO - 2021-07-08 09:33:21 --> Helper loaded: language_helper
INFO - 2021-07-08 09:33:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:33:21 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:33:21 --> Model "Product_model" initialized
INFO - 2021-07-08 09:33:21 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:33:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:33:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:33:21 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:33:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:33:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:33:21 --> Final output sent to browser
DEBUG - 2021-07-08 09:33:21 --> Total execution time: 0.1384
INFO - 2021-07-08 09:33:25 --> Config Class Initialized
INFO - 2021-07-08 09:33:25 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:33:25 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:33:25 --> Utf8 Class Initialized
INFO - 2021-07-08 09:33:25 --> URI Class Initialized
INFO - 2021-07-08 09:33:25 --> Router Class Initialized
INFO - 2021-07-08 09:33:25 --> Output Class Initialized
INFO - 2021-07-08 09:33:25 --> Security Class Initialized
DEBUG - 2021-07-08 09:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:33:25 --> Input Class Initialized
INFO - 2021-07-08 09:33:25 --> Language Class Initialized
INFO - 2021-07-08 09:33:25 --> Loader Class Initialized
INFO - 2021-07-08 09:33:25 --> Helper loaded: html_helper
INFO - 2021-07-08 09:33:25 --> Helper loaded: url_helper
INFO - 2021-07-08 09:33:25 --> Helper loaded: form_helper
INFO - 2021-07-08 09:33:25 --> Database Driver Class Initialized
INFO - 2021-07-08 09:33:25 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:33:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:33:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:33:25 --> Encryption Class Initialized
INFO - 2021-07-08 09:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:33:25 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:33:25 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:33:25 --> Model "user_model" initialized
INFO - 2021-07-08 09:33:25 --> Model "role_model" initialized
INFO - 2021-07-08 09:33:25 --> Controller Class Initialized
INFO - 2021-07-08 09:33:25 --> Helper loaded: language_helper
INFO - 2021-07-08 09:33:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:33:25 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:33:25 --> Final output sent to browser
DEBUG - 2021-07-08 09:33:25 --> Total execution time: 0.0652
INFO - 2021-07-08 09:33:39 --> Config Class Initialized
INFO - 2021-07-08 09:33:39 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:33:39 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:33:39 --> Utf8 Class Initialized
INFO - 2021-07-08 09:33:39 --> URI Class Initialized
INFO - 2021-07-08 09:33:39 --> Router Class Initialized
INFO - 2021-07-08 09:33:39 --> Output Class Initialized
INFO - 2021-07-08 09:33:39 --> Security Class Initialized
DEBUG - 2021-07-08 09:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:33:39 --> Input Class Initialized
INFO - 2021-07-08 09:33:39 --> Language Class Initialized
INFO - 2021-07-08 09:33:39 --> Loader Class Initialized
INFO - 2021-07-08 09:33:39 --> Helper loaded: html_helper
INFO - 2021-07-08 09:33:39 --> Helper loaded: url_helper
INFO - 2021-07-08 09:33:39 --> Helper loaded: form_helper
INFO - 2021-07-08 09:33:39 --> Database Driver Class Initialized
INFO - 2021-07-08 09:33:39 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:33:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:33:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:33:39 --> Encryption Class Initialized
INFO - 2021-07-08 09:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:33:39 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:33:39 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:33:39 --> Model "user_model" initialized
INFO - 2021-07-08 09:33:39 --> Model "role_model" initialized
INFO - 2021-07-08 09:33:39 --> Controller Class Initialized
INFO - 2021-07-08 09:33:39 --> Helper loaded: language_helper
INFO - 2021-07-08 09:33:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:33:39 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:33:39 --> Final output sent to browser
DEBUG - 2021-07-08 09:33:39 --> Total execution time: 0.0582
INFO - 2021-07-08 09:33:44 --> Config Class Initialized
INFO - 2021-07-08 09:33:44 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:33:44 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:33:44 --> Utf8 Class Initialized
INFO - 2021-07-08 09:33:44 --> URI Class Initialized
INFO - 2021-07-08 09:33:44 --> Router Class Initialized
INFO - 2021-07-08 09:33:44 --> Output Class Initialized
INFO - 2021-07-08 09:33:44 --> Security Class Initialized
DEBUG - 2021-07-08 09:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:33:44 --> Input Class Initialized
INFO - 2021-07-08 09:33:44 --> Language Class Initialized
INFO - 2021-07-08 09:33:44 --> Loader Class Initialized
INFO - 2021-07-08 09:33:44 --> Helper loaded: html_helper
INFO - 2021-07-08 09:33:44 --> Helper loaded: url_helper
INFO - 2021-07-08 09:33:44 --> Helper loaded: form_helper
INFO - 2021-07-08 09:33:44 --> Database Driver Class Initialized
INFO - 2021-07-08 09:33:44 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:33:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:33:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:33:44 --> Encryption Class Initialized
INFO - 2021-07-08 09:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:33:44 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:33:44 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:33:44 --> Model "user_model" initialized
INFO - 2021-07-08 09:33:44 --> Model "role_model" initialized
INFO - 2021-07-08 09:33:44 --> Controller Class Initialized
INFO - 2021-07-08 09:33:44 --> Helper loaded: language_helper
INFO - 2021-07-08 09:33:44 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:33:44 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:33:44 --> Final output sent to browser
DEBUG - 2021-07-08 09:33:44 --> Total execution time: 0.0547
INFO - 2021-07-08 09:35:42 --> Config Class Initialized
INFO - 2021-07-08 09:35:42 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:35:42 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:35:42 --> Utf8 Class Initialized
INFO - 2021-07-08 09:35:42 --> URI Class Initialized
INFO - 2021-07-08 09:35:42 --> Router Class Initialized
INFO - 2021-07-08 09:35:42 --> Output Class Initialized
INFO - 2021-07-08 09:35:42 --> Security Class Initialized
DEBUG - 2021-07-08 09:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:35:42 --> Input Class Initialized
INFO - 2021-07-08 09:35:42 --> Language Class Initialized
INFO - 2021-07-08 09:35:42 --> Loader Class Initialized
INFO - 2021-07-08 09:35:42 --> Helper loaded: html_helper
INFO - 2021-07-08 09:35:42 --> Helper loaded: url_helper
INFO - 2021-07-08 09:35:42 --> Helper loaded: form_helper
INFO - 2021-07-08 09:35:42 --> Database Driver Class Initialized
INFO - 2021-07-08 09:35:42 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:35:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:35:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:35:42 --> Encryption Class Initialized
INFO - 2021-07-08 09:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:35:42 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:35:42 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:35:42 --> Model "user_model" initialized
INFO - 2021-07-08 09:35:42 --> Model "role_model" initialized
INFO - 2021-07-08 09:35:42 --> Controller Class Initialized
INFO - 2021-07-08 09:35:42 --> Helper loaded: language_helper
INFO - 2021-07-08 09:35:42 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:35:42 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:35:42 --> Model "Product_model" initialized
INFO - 2021-07-08 09:35:42 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:35:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:35:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:35:42 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:35:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:35:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:35:42 --> Final output sent to browser
DEBUG - 2021-07-08 09:35:42 --> Total execution time: 0.1135
INFO - 2021-07-08 09:35:46 --> Config Class Initialized
INFO - 2021-07-08 09:35:46 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:35:46 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:35:46 --> Utf8 Class Initialized
INFO - 2021-07-08 09:35:46 --> URI Class Initialized
INFO - 2021-07-08 09:35:46 --> Router Class Initialized
INFO - 2021-07-08 09:35:46 --> Output Class Initialized
INFO - 2021-07-08 09:35:46 --> Security Class Initialized
DEBUG - 2021-07-08 09:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:35:46 --> Input Class Initialized
INFO - 2021-07-08 09:35:46 --> Language Class Initialized
INFO - 2021-07-08 09:35:46 --> Loader Class Initialized
INFO - 2021-07-08 09:35:46 --> Helper loaded: html_helper
INFO - 2021-07-08 09:35:46 --> Helper loaded: url_helper
INFO - 2021-07-08 09:35:46 --> Helper loaded: form_helper
INFO - 2021-07-08 09:35:46 --> Database Driver Class Initialized
INFO - 2021-07-08 09:35:46 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:35:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:35:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:35:46 --> Encryption Class Initialized
INFO - 2021-07-08 09:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:35:46 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:35:46 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:35:46 --> Model "user_model" initialized
INFO - 2021-07-08 09:35:46 --> Model "role_model" initialized
INFO - 2021-07-08 09:35:46 --> Controller Class Initialized
INFO - 2021-07-08 09:35:46 --> Helper loaded: language_helper
INFO - 2021-07-08 09:35:46 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:35:46 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:35:46 --> Final output sent to browser
DEBUG - 2021-07-08 09:35:46 --> Total execution time: 0.0602
INFO - 2021-07-08 09:36:02 --> Config Class Initialized
INFO - 2021-07-08 09:36:02 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:36:02 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:36:02 --> Utf8 Class Initialized
INFO - 2021-07-08 09:36:02 --> URI Class Initialized
INFO - 2021-07-08 09:36:02 --> Router Class Initialized
INFO - 2021-07-08 09:36:02 --> Output Class Initialized
INFO - 2021-07-08 09:36:02 --> Security Class Initialized
DEBUG - 2021-07-08 09:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:36:02 --> Input Class Initialized
INFO - 2021-07-08 09:36:02 --> Language Class Initialized
INFO - 2021-07-08 09:36:02 --> Loader Class Initialized
INFO - 2021-07-08 09:36:02 --> Helper loaded: html_helper
INFO - 2021-07-08 09:36:02 --> Helper loaded: url_helper
INFO - 2021-07-08 09:36:02 --> Helper loaded: form_helper
INFO - 2021-07-08 09:36:02 --> Database Driver Class Initialized
INFO - 2021-07-08 09:36:03 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:36:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:36:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:36:03 --> Encryption Class Initialized
INFO - 2021-07-08 09:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:36:03 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:36:03 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:36:03 --> Model "user_model" initialized
INFO - 2021-07-08 09:36:03 --> Model "role_model" initialized
INFO - 2021-07-08 09:36:03 --> Controller Class Initialized
INFO - 2021-07-08 09:36:03 --> Helper loaded: language_helper
INFO - 2021-07-08 09:36:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:36:03 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:36:03 --> Model "Product_model" initialized
INFO - 2021-07-08 09:36:03 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:36:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:36:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:36:03 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:36:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:36:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:36:03 --> Final output sent to browser
DEBUG - 2021-07-08 09:36:03 --> Total execution time: 0.1215
INFO - 2021-07-08 09:36:05 --> Config Class Initialized
INFO - 2021-07-08 09:36:05 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:36:05 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:36:05 --> Utf8 Class Initialized
INFO - 2021-07-08 09:36:05 --> URI Class Initialized
INFO - 2021-07-08 09:36:05 --> Router Class Initialized
INFO - 2021-07-08 09:36:05 --> Output Class Initialized
INFO - 2021-07-08 09:36:05 --> Security Class Initialized
DEBUG - 2021-07-08 09:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:36:05 --> Input Class Initialized
INFO - 2021-07-08 09:36:05 --> Language Class Initialized
INFO - 2021-07-08 09:36:05 --> Loader Class Initialized
INFO - 2021-07-08 09:36:05 --> Helper loaded: html_helper
INFO - 2021-07-08 09:36:05 --> Helper loaded: url_helper
INFO - 2021-07-08 09:36:05 --> Helper loaded: form_helper
INFO - 2021-07-08 09:36:05 --> Database Driver Class Initialized
INFO - 2021-07-08 09:36:05 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:36:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:36:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:36:05 --> Encryption Class Initialized
INFO - 2021-07-08 09:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:36:05 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:36:05 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:36:05 --> Model "user_model" initialized
INFO - 2021-07-08 09:36:05 --> Model "role_model" initialized
INFO - 2021-07-08 09:36:05 --> Controller Class Initialized
INFO - 2021-07-08 09:36:05 --> Helper loaded: language_helper
INFO - 2021-07-08 09:36:05 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:36:05 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:36:05 --> Final output sent to browser
DEBUG - 2021-07-08 09:36:05 --> Total execution time: 0.0618
INFO - 2021-07-08 09:36:07 --> Config Class Initialized
INFO - 2021-07-08 09:36:07 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:36:07 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:36:07 --> Utf8 Class Initialized
INFO - 2021-07-08 09:36:07 --> URI Class Initialized
INFO - 2021-07-08 09:36:07 --> Router Class Initialized
INFO - 2021-07-08 09:36:07 --> Output Class Initialized
INFO - 2021-07-08 09:36:07 --> Security Class Initialized
DEBUG - 2021-07-08 09:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:36:07 --> Input Class Initialized
INFO - 2021-07-08 09:36:07 --> Language Class Initialized
INFO - 2021-07-08 09:36:07 --> Loader Class Initialized
INFO - 2021-07-08 09:36:07 --> Helper loaded: html_helper
INFO - 2021-07-08 09:36:07 --> Helper loaded: url_helper
INFO - 2021-07-08 09:36:07 --> Helper loaded: form_helper
INFO - 2021-07-08 09:36:07 --> Database Driver Class Initialized
INFO - 2021-07-08 09:36:07 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:36:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:36:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:36:07 --> Encryption Class Initialized
INFO - 2021-07-08 09:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:36:07 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:36:07 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:36:07 --> Model "user_model" initialized
INFO - 2021-07-08 09:36:07 --> Model "role_model" initialized
INFO - 2021-07-08 09:36:07 --> Controller Class Initialized
INFO - 2021-07-08 09:36:07 --> Helper loaded: language_helper
INFO - 2021-07-08 09:36:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:36:07 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:36:07 --> Final output sent to browser
DEBUG - 2021-07-08 09:36:07 --> Total execution time: 0.0625
INFO - 2021-07-08 09:36:09 --> Config Class Initialized
INFO - 2021-07-08 09:36:09 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:36:09 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:36:09 --> Utf8 Class Initialized
INFO - 2021-07-08 09:36:09 --> URI Class Initialized
INFO - 2021-07-08 09:36:09 --> Router Class Initialized
INFO - 2021-07-08 09:36:09 --> Output Class Initialized
INFO - 2021-07-08 09:36:09 --> Security Class Initialized
DEBUG - 2021-07-08 09:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:36:09 --> Input Class Initialized
INFO - 2021-07-08 09:36:09 --> Language Class Initialized
INFO - 2021-07-08 09:36:09 --> Loader Class Initialized
INFO - 2021-07-08 09:36:09 --> Helper loaded: html_helper
INFO - 2021-07-08 09:36:09 --> Helper loaded: url_helper
INFO - 2021-07-08 09:36:09 --> Helper loaded: form_helper
INFO - 2021-07-08 09:36:09 --> Database Driver Class Initialized
INFO - 2021-07-08 09:36:09 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:36:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:36:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:36:09 --> Encryption Class Initialized
INFO - 2021-07-08 09:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:36:09 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:36:09 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:36:09 --> Model "user_model" initialized
INFO - 2021-07-08 09:36:09 --> Model "role_model" initialized
INFO - 2021-07-08 09:36:09 --> Controller Class Initialized
INFO - 2021-07-08 09:36:09 --> Helper loaded: language_helper
INFO - 2021-07-08 09:36:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:36:09 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:36:09 --> Model "Product_model" initialized
INFO - 2021-07-08 09:36:09 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:36:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:36:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:36:09 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:36:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:36:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:36:09 --> Final output sent to browser
DEBUG - 2021-07-08 09:36:09 --> Total execution time: 0.0738
INFO - 2021-07-08 09:37:01 --> Config Class Initialized
INFO - 2021-07-08 09:37:01 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:37:01 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:37:01 --> Utf8 Class Initialized
INFO - 2021-07-08 09:37:01 --> URI Class Initialized
INFO - 2021-07-08 09:37:01 --> Router Class Initialized
INFO - 2021-07-08 09:37:01 --> Output Class Initialized
INFO - 2021-07-08 09:37:01 --> Security Class Initialized
DEBUG - 2021-07-08 09:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:37:01 --> Input Class Initialized
INFO - 2021-07-08 09:37:01 --> Language Class Initialized
INFO - 2021-07-08 09:37:01 --> Loader Class Initialized
INFO - 2021-07-08 09:37:01 --> Helper loaded: html_helper
INFO - 2021-07-08 09:37:01 --> Helper loaded: url_helper
INFO - 2021-07-08 09:37:01 --> Helper loaded: form_helper
INFO - 2021-07-08 09:37:01 --> Database Driver Class Initialized
INFO - 2021-07-08 09:37:01 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:37:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:37:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:37:01 --> Encryption Class Initialized
INFO - 2021-07-08 09:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:37:01 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:37:01 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:37:01 --> Model "user_model" initialized
INFO - 2021-07-08 09:37:01 --> Model "role_model" initialized
INFO - 2021-07-08 09:37:01 --> Controller Class Initialized
INFO - 2021-07-08 09:37:01 --> Helper loaded: language_helper
INFO - 2021-07-08 09:37:01 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:37:01 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:37:01 --> Model "Product_model" initialized
INFO - 2021-07-08 09:37:01 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:37:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:37:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:37:01 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:37:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:37:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:37:01 --> Final output sent to browser
DEBUG - 2021-07-08 09:37:01 --> Total execution time: 0.1069
INFO - 2021-07-08 09:37:04 --> Config Class Initialized
INFO - 2021-07-08 09:37:04 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:37:04 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:37:04 --> Utf8 Class Initialized
INFO - 2021-07-08 09:37:04 --> URI Class Initialized
INFO - 2021-07-08 09:37:04 --> Router Class Initialized
INFO - 2021-07-08 09:37:04 --> Output Class Initialized
INFO - 2021-07-08 09:37:04 --> Security Class Initialized
DEBUG - 2021-07-08 09:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:37:04 --> Input Class Initialized
INFO - 2021-07-08 09:37:04 --> Language Class Initialized
INFO - 2021-07-08 09:37:04 --> Loader Class Initialized
INFO - 2021-07-08 09:37:04 --> Helper loaded: html_helper
INFO - 2021-07-08 09:37:04 --> Helper loaded: url_helper
INFO - 2021-07-08 09:37:04 --> Helper loaded: form_helper
INFO - 2021-07-08 09:37:04 --> Database Driver Class Initialized
INFO - 2021-07-08 09:37:04 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:37:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:37:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:37:04 --> Encryption Class Initialized
INFO - 2021-07-08 09:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:37:04 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:37:04 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:37:04 --> Model "user_model" initialized
INFO - 2021-07-08 09:37:04 --> Model "role_model" initialized
INFO - 2021-07-08 09:37:04 --> Controller Class Initialized
INFO - 2021-07-08 09:37:04 --> Helper loaded: language_helper
INFO - 2021-07-08 09:37:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:37:04 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:37:04 --> Final output sent to browser
DEBUG - 2021-07-08 09:37:04 --> Total execution time: 0.0584
INFO - 2021-07-08 09:37:09 --> Config Class Initialized
INFO - 2021-07-08 09:37:09 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:37:09 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:37:09 --> Utf8 Class Initialized
INFO - 2021-07-08 09:37:09 --> URI Class Initialized
INFO - 2021-07-08 09:37:09 --> Router Class Initialized
INFO - 2021-07-08 09:37:09 --> Output Class Initialized
INFO - 2021-07-08 09:37:09 --> Security Class Initialized
DEBUG - 2021-07-08 09:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:37:09 --> Input Class Initialized
INFO - 2021-07-08 09:37:09 --> Language Class Initialized
INFO - 2021-07-08 09:37:09 --> Loader Class Initialized
INFO - 2021-07-08 09:37:09 --> Helper loaded: html_helper
INFO - 2021-07-08 09:37:09 --> Helper loaded: url_helper
INFO - 2021-07-08 09:37:09 --> Helper loaded: form_helper
INFO - 2021-07-08 09:37:09 --> Database Driver Class Initialized
INFO - 2021-07-08 09:37:09 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:37:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:37:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:37:09 --> Encryption Class Initialized
INFO - 2021-07-08 09:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:37:09 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:37:09 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:37:09 --> Model "user_model" initialized
INFO - 2021-07-08 09:37:09 --> Model "role_model" initialized
INFO - 2021-07-08 09:37:09 --> Controller Class Initialized
INFO - 2021-07-08 09:37:09 --> Helper loaded: language_helper
INFO - 2021-07-08 09:37:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:37:09 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:37:09 --> Final output sent to browser
DEBUG - 2021-07-08 09:37:09 --> Total execution time: 0.0679
INFO - 2021-07-08 09:37:11 --> Config Class Initialized
INFO - 2021-07-08 09:37:11 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:37:11 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:37:11 --> Utf8 Class Initialized
INFO - 2021-07-08 09:37:11 --> URI Class Initialized
INFO - 2021-07-08 09:37:11 --> Router Class Initialized
INFO - 2021-07-08 09:37:11 --> Output Class Initialized
INFO - 2021-07-08 09:37:11 --> Security Class Initialized
DEBUG - 2021-07-08 09:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:37:11 --> Input Class Initialized
INFO - 2021-07-08 09:37:11 --> Language Class Initialized
INFO - 2021-07-08 09:37:11 --> Loader Class Initialized
INFO - 2021-07-08 09:37:11 --> Helper loaded: html_helper
INFO - 2021-07-08 09:37:11 --> Helper loaded: url_helper
INFO - 2021-07-08 09:37:11 --> Helper loaded: form_helper
INFO - 2021-07-08 09:37:11 --> Database Driver Class Initialized
INFO - 2021-07-08 09:37:11 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:37:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:37:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:37:11 --> Encryption Class Initialized
INFO - 2021-07-08 09:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:37:11 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:37:11 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:37:11 --> Model "user_model" initialized
INFO - 2021-07-08 09:37:11 --> Model "role_model" initialized
INFO - 2021-07-08 09:37:11 --> Controller Class Initialized
INFO - 2021-07-08 09:37:11 --> Helper loaded: language_helper
INFO - 2021-07-08 09:37:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:37:11 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:37:11 --> Model "Product_model" initialized
INFO - 2021-07-08 09:37:11 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:37:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:37:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:37:11 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:37:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:37:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:37:11 --> Final output sent to browser
DEBUG - 2021-07-08 09:37:11 --> Total execution time: 0.0769
INFO - 2021-07-08 09:39:12 --> Config Class Initialized
INFO - 2021-07-08 09:39:12 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:39:12 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:39:12 --> Utf8 Class Initialized
INFO - 2021-07-08 09:39:12 --> URI Class Initialized
INFO - 2021-07-08 09:39:12 --> Router Class Initialized
INFO - 2021-07-08 09:39:12 --> Output Class Initialized
INFO - 2021-07-08 09:39:12 --> Security Class Initialized
DEBUG - 2021-07-08 09:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:39:12 --> Input Class Initialized
INFO - 2021-07-08 09:39:12 --> Language Class Initialized
INFO - 2021-07-08 09:39:12 --> Loader Class Initialized
INFO - 2021-07-08 09:39:12 --> Helper loaded: html_helper
INFO - 2021-07-08 09:39:12 --> Helper loaded: url_helper
INFO - 2021-07-08 09:39:12 --> Helper loaded: form_helper
INFO - 2021-07-08 09:39:12 --> Database Driver Class Initialized
INFO - 2021-07-08 09:39:12 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:39:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:39:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:39:12 --> Encryption Class Initialized
INFO - 2021-07-08 09:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:39:12 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:39:12 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:39:12 --> Model "user_model" initialized
INFO - 2021-07-08 09:39:12 --> Model "role_model" initialized
INFO - 2021-07-08 09:39:12 --> Controller Class Initialized
INFO - 2021-07-08 09:39:12 --> Helper loaded: language_helper
INFO - 2021-07-08 09:39:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:39:12 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:39:12 --> Model "Product_model" initialized
INFO - 2021-07-08 09:39:12 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:39:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:39:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:39:12 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:39:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:39:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:39:12 --> Final output sent to browser
DEBUG - 2021-07-08 09:39:12 --> Total execution time: 0.1158
INFO - 2021-07-08 09:39:16 --> Config Class Initialized
INFO - 2021-07-08 09:39:16 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:39:16 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:39:16 --> Utf8 Class Initialized
INFO - 2021-07-08 09:39:16 --> URI Class Initialized
INFO - 2021-07-08 09:39:16 --> Router Class Initialized
INFO - 2021-07-08 09:39:16 --> Output Class Initialized
INFO - 2021-07-08 09:39:16 --> Security Class Initialized
DEBUG - 2021-07-08 09:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:39:16 --> Input Class Initialized
INFO - 2021-07-08 09:39:16 --> Language Class Initialized
INFO - 2021-07-08 09:39:16 --> Loader Class Initialized
INFO - 2021-07-08 09:39:16 --> Helper loaded: html_helper
INFO - 2021-07-08 09:39:16 --> Helper loaded: url_helper
INFO - 2021-07-08 09:39:16 --> Helper loaded: form_helper
INFO - 2021-07-08 09:39:16 --> Database Driver Class Initialized
INFO - 2021-07-08 09:39:16 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:39:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:39:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:39:16 --> Encryption Class Initialized
INFO - 2021-07-08 09:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:39:16 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:39:16 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:39:16 --> Model "user_model" initialized
INFO - 2021-07-08 09:39:16 --> Model "role_model" initialized
INFO - 2021-07-08 09:39:16 --> Controller Class Initialized
INFO - 2021-07-08 09:39:16 --> Helper loaded: language_helper
INFO - 2021-07-08 09:39:16 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:39:16 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:39:16 --> Final output sent to browser
DEBUG - 2021-07-08 09:39:16 --> Total execution time: 0.0632
INFO - 2021-07-08 09:40:27 --> Config Class Initialized
INFO - 2021-07-08 09:40:27 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:40:27 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:40:27 --> Utf8 Class Initialized
INFO - 2021-07-08 09:40:27 --> URI Class Initialized
INFO - 2021-07-08 09:40:27 --> Router Class Initialized
INFO - 2021-07-08 09:40:27 --> Output Class Initialized
INFO - 2021-07-08 09:40:27 --> Security Class Initialized
DEBUG - 2021-07-08 09:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:40:27 --> Input Class Initialized
INFO - 2021-07-08 09:40:27 --> Language Class Initialized
INFO - 2021-07-08 09:40:27 --> Loader Class Initialized
INFO - 2021-07-08 09:40:27 --> Helper loaded: html_helper
INFO - 2021-07-08 09:40:27 --> Helper loaded: url_helper
INFO - 2021-07-08 09:40:27 --> Helper loaded: form_helper
INFO - 2021-07-08 09:40:27 --> Database Driver Class Initialized
INFO - 2021-07-08 09:40:27 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:40:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:40:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:40:27 --> Encryption Class Initialized
INFO - 2021-07-08 09:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:40:27 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:40:27 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:40:27 --> Model "user_model" initialized
INFO - 2021-07-08 09:40:27 --> Model "role_model" initialized
INFO - 2021-07-08 09:40:27 --> Controller Class Initialized
INFO - 2021-07-08 09:40:27 --> Helper loaded: language_helper
INFO - 2021-07-08 09:40:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:40:27 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:40:27 --> Model "Product_model" initialized
INFO - 2021-07-08 09:40:27 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:40:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:40:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:40:27 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:40:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:40:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:40:27 --> Final output sent to browser
DEBUG - 2021-07-08 09:40:27 --> Total execution time: 0.1116
INFO - 2021-07-08 09:40:31 --> Config Class Initialized
INFO - 2021-07-08 09:40:31 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:40:31 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:40:31 --> Utf8 Class Initialized
INFO - 2021-07-08 09:40:31 --> URI Class Initialized
INFO - 2021-07-08 09:40:31 --> Router Class Initialized
INFO - 2021-07-08 09:40:31 --> Output Class Initialized
INFO - 2021-07-08 09:40:31 --> Security Class Initialized
DEBUG - 2021-07-08 09:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:40:31 --> Input Class Initialized
INFO - 2021-07-08 09:40:31 --> Language Class Initialized
INFO - 2021-07-08 09:40:31 --> Loader Class Initialized
INFO - 2021-07-08 09:40:31 --> Helper loaded: html_helper
INFO - 2021-07-08 09:40:31 --> Helper loaded: url_helper
INFO - 2021-07-08 09:40:31 --> Helper loaded: form_helper
INFO - 2021-07-08 09:40:31 --> Database Driver Class Initialized
INFO - 2021-07-08 09:40:31 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:40:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:40:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:40:31 --> Encryption Class Initialized
INFO - 2021-07-08 09:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:40:31 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:40:31 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:40:31 --> Model "user_model" initialized
INFO - 2021-07-08 09:40:31 --> Model "role_model" initialized
INFO - 2021-07-08 09:40:31 --> Controller Class Initialized
INFO - 2021-07-08 09:40:31 --> Helper loaded: language_helper
INFO - 2021-07-08 09:40:31 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:40:31 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:40:31 --> Final output sent to browser
DEBUG - 2021-07-08 09:40:31 --> Total execution time: 0.0576
INFO - 2021-07-08 09:40:40 --> Config Class Initialized
INFO - 2021-07-08 09:40:40 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:40:40 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:40:40 --> Utf8 Class Initialized
INFO - 2021-07-08 09:40:40 --> URI Class Initialized
INFO - 2021-07-08 09:40:40 --> Router Class Initialized
INFO - 2021-07-08 09:40:40 --> Output Class Initialized
INFO - 2021-07-08 09:40:40 --> Security Class Initialized
DEBUG - 2021-07-08 09:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:40:40 --> Input Class Initialized
INFO - 2021-07-08 09:40:40 --> Language Class Initialized
INFO - 2021-07-08 09:40:40 --> Loader Class Initialized
INFO - 2021-07-08 09:40:40 --> Helper loaded: html_helper
INFO - 2021-07-08 09:40:40 --> Helper loaded: url_helper
INFO - 2021-07-08 09:40:40 --> Helper loaded: form_helper
INFO - 2021-07-08 09:40:40 --> Database Driver Class Initialized
INFO - 2021-07-08 09:40:40 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:40:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:40:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:40:40 --> Encryption Class Initialized
INFO - 2021-07-08 09:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:40:40 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:40:40 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:40:40 --> Model "user_model" initialized
INFO - 2021-07-08 09:40:40 --> Model "role_model" initialized
INFO - 2021-07-08 09:40:40 --> Controller Class Initialized
INFO - 2021-07-08 09:40:40 --> Helper loaded: language_helper
INFO - 2021-07-08 09:40:40 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:40:40 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:40:40 --> Final output sent to browser
DEBUG - 2021-07-08 09:40:40 --> Total execution time: 0.0641
INFO - 2021-07-08 09:40:42 --> Config Class Initialized
INFO - 2021-07-08 09:40:42 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:40:42 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:40:42 --> Utf8 Class Initialized
INFO - 2021-07-08 09:40:42 --> URI Class Initialized
INFO - 2021-07-08 09:40:42 --> Router Class Initialized
INFO - 2021-07-08 09:40:42 --> Output Class Initialized
INFO - 2021-07-08 09:40:42 --> Security Class Initialized
DEBUG - 2021-07-08 09:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:40:42 --> Input Class Initialized
INFO - 2021-07-08 09:40:42 --> Language Class Initialized
INFO - 2021-07-08 09:40:42 --> Loader Class Initialized
INFO - 2021-07-08 09:40:42 --> Helper loaded: html_helper
INFO - 2021-07-08 09:40:42 --> Helper loaded: url_helper
INFO - 2021-07-08 09:40:42 --> Helper loaded: form_helper
INFO - 2021-07-08 09:40:42 --> Database Driver Class Initialized
INFO - 2021-07-08 09:40:42 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:40:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:40:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:40:42 --> Encryption Class Initialized
INFO - 2021-07-08 09:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:40:42 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:40:42 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:40:42 --> Model "user_model" initialized
INFO - 2021-07-08 09:40:42 --> Model "role_model" initialized
INFO - 2021-07-08 09:40:42 --> Controller Class Initialized
INFO - 2021-07-08 09:40:42 --> Helper loaded: language_helper
INFO - 2021-07-08 09:40:42 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:40:42 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:40:42 --> Model "Product_model" initialized
INFO - 2021-07-08 09:40:42 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:40:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:40:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:40:42 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:40:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:40:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:40:42 --> Final output sent to browser
DEBUG - 2021-07-08 09:40:42 --> Total execution time: 0.0700
INFO - 2021-07-08 09:40:47 --> Config Class Initialized
INFO - 2021-07-08 09:40:47 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:40:47 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:40:47 --> Utf8 Class Initialized
INFO - 2021-07-08 09:40:47 --> URI Class Initialized
INFO - 2021-07-08 09:40:47 --> Router Class Initialized
INFO - 2021-07-08 09:40:47 --> Output Class Initialized
INFO - 2021-07-08 09:40:47 --> Security Class Initialized
DEBUG - 2021-07-08 09:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:40:47 --> Input Class Initialized
INFO - 2021-07-08 09:40:47 --> Language Class Initialized
INFO - 2021-07-08 09:40:47 --> Loader Class Initialized
INFO - 2021-07-08 09:40:47 --> Helper loaded: html_helper
INFO - 2021-07-08 09:40:47 --> Helper loaded: url_helper
INFO - 2021-07-08 09:40:47 --> Helper loaded: form_helper
INFO - 2021-07-08 09:40:47 --> Database Driver Class Initialized
INFO - 2021-07-08 09:40:47 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:40:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:40:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:40:47 --> Encryption Class Initialized
INFO - 2021-07-08 09:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:40:47 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:40:47 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:40:47 --> Model "user_model" initialized
INFO - 2021-07-08 09:40:47 --> Model "role_model" initialized
INFO - 2021-07-08 09:40:47 --> Controller Class Initialized
INFO - 2021-07-08 09:40:47 --> Helper loaded: language_helper
INFO - 2021-07-08 09:40:47 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:40:47 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:40:47 --> Final output sent to browser
DEBUG - 2021-07-08 09:40:47 --> Total execution time: 0.0598
INFO - 2021-07-08 09:40:49 --> Config Class Initialized
INFO - 2021-07-08 09:40:49 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:40:49 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:40:49 --> Utf8 Class Initialized
INFO - 2021-07-08 09:40:49 --> URI Class Initialized
INFO - 2021-07-08 09:40:49 --> Router Class Initialized
INFO - 2021-07-08 09:40:49 --> Output Class Initialized
INFO - 2021-07-08 09:40:49 --> Security Class Initialized
DEBUG - 2021-07-08 09:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:40:49 --> Input Class Initialized
INFO - 2021-07-08 09:40:49 --> Language Class Initialized
INFO - 2021-07-08 09:40:49 --> Loader Class Initialized
INFO - 2021-07-08 09:40:49 --> Helper loaded: html_helper
INFO - 2021-07-08 09:40:49 --> Helper loaded: url_helper
INFO - 2021-07-08 09:40:49 --> Helper loaded: form_helper
INFO - 2021-07-08 09:40:49 --> Database Driver Class Initialized
INFO - 2021-07-08 09:40:49 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:40:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:40:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:40:49 --> Encryption Class Initialized
INFO - 2021-07-08 09:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:40:49 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:40:49 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:40:49 --> Model "user_model" initialized
INFO - 2021-07-08 09:40:49 --> Model "role_model" initialized
INFO - 2021-07-08 09:40:49 --> Controller Class Initialized
INFO - 2021-07-08 09:40:49 --> Helper loaded: language_helper
INFO - 2021-07-08 09:40:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:40:49 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:40:49 --> Model "Product_model" initialized
INFO - 2021-07-08 09:40:49 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:40:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:40:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:40:49 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:40:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:40:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:40:49 --> Final output sent to browser
DEBUG - 2021-07-08 09:40:49 --> Total execution time: 0.0783
INFO - 2021-07-08 09:48:09 --> Config Class Initialized
INFO - 2021-07-08 09:48:09 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:48:09 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:48:09 --> Utf8 Class Initialized
INFO - 2021-07-08 09:48:09 --> URI Class Initialized
INFO - 2021-07-08 09:48:09 --> Router Class Initialized
INFO - 2021-07-08 09:48:09 --> Output Class Initialized
INFO - 2021-07-08 09:48:09 --> Security Class Initialized
DEBUG - 2021-07-08 09:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:48:09 --> Input Class Initialized
INFO - 2021-07-08 09:48:09 --> Language Class Initialized
INFO - 2021-07-08 09:48:09 --> Loader Class Initialized
INFO - 2021-07-08 09:48:09 --> Helper loaded: html_helper
INFO - 2021-07-08 09:48:09 --> Helper loaded: url_helper
INFO - 2021-07-08 09:48:09 --> Helper loaded: form_helper
INFO - 2021-07-08 09:48:09 --> Database Driver Class Initialized
INFO - 2021-07-08 09:48:09 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:48:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:48:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:48:09 --> Encryption Class Initialized
INFO - 2021-07-08 09:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:48:09 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:48:09 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:48:09 --> Model "user_model" initialized
INFO - 2021-07-08 09:48:09 --> Model "role_model" initialized
INFO - 2021-07-08 09:48:09 --> Controller Class Initialized
INFO - 2021-07-08 09:48:09 --> Helper loaded: language_helper
INFO - 2021-07-08 09:48:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:48:09 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:48:09 --> Model "Product_model" initialized
INFO - 2021-07-08 09:48:09 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:48:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:48:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:48:09 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:48:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:48:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:48:09 --> Final output sent to browser
DEBUG - 2021-07-08 09:48:09 --> Total execution time: 0.1282
INFO - 2021-07-08 09:48:13 --> Config Class Initialized
INFO - 2021-07-08 09:48:13 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:48:13 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:48:13 --> Utf8 Class Initialized
INFO - 2021-07-08 09:48:13 --> URI Class Initialized
INFO - 2021-07-08 09:48:13 --> Router Class Initialized
INFO - 2021-07-08 09:48:13 --> Output Class Initialized
INFO - 2021-07-08 09:48:13 --> Security Class Initialized
DEBUG - 2021-07-08 09:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:48:13 --> Input Class Initialized
INFO - 2021-07-08 09:48:13 --> Language Class Initialized
INFO - 2021-07-08 09:48:13 --> Loader Class Initialized
INFO - 2021-07-08 09:48:13 --> Helper loaded: html_helper
INFO - 2021-07-08 09:48:13 --> Helper loaded: url_helper
INFO - 2021-07-08 09:48:13 --> Helper loaded: form_helper
INFO - 2021-07-08 09:48:13 --> Database Driver Class Initialized
INFO - 2021-07-08 09:48:13 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:48:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:48:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:48:13 --> Encryption Class Initialized
INFO - 2021-07-08 09:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:48:13 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:48:13 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:48:13 --> Model "user_model" initialized
INFO - 2021-07-08 09:48:13 --> Model "role_model" initialized
INFO - 2021-07-08 09:48:13 --> Controller Class Initialized
INFO - 2021-07-08 09:48:13 --> Helper loaded: language_helper
INFO - 2021-07-08 09:48:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:48:13 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:48:13 --> Final output sent to browser
DEBUG - 2021-07-08 09:48:13 --> Total execution time: 0.0852
INFO - 2021-07-08 09:48:29 --> Config Class Initialized
INFO - 2021-07-08 09:48:29 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:48:29 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:48:29 --> Utf8 Class Initialized
INFO - 2021-07-08 09:48:29 --> URI Class Initialized
INFO - 2021-07-08 09:48:29 --> Router Class Initialized
INFO - 2021-07-08 09:48:29 --> Output Class Initialized
INFO - 2021-07-08 09:48:29 --> Security Class Initialized
DEBUG - 2021-07-08 09:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:48:29 --> Input Class Initialized
INFO - 2021-07-08 09:48:29 --> Language Class Initialized
INFO - 2021-07-08 09:48:29 --> Loader Class Initialized
INFO - 2021-07-08 09:48:29 --> Helper loaded: html_helper
INFO - 2021-07-08 09:48:29 --> Helper loaded: url_helper
INFO - 2021-07-08 09:48:29 --> Helper loaded: form_helper
INFO - 2021-07-08 09:48:29 --> Database Driver Class Initialized
INFO - 2021-07-08 09:48:29 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:48:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:48:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:48:29 --> Encryption Class Initialized
INFO - 2021-07-08 09:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:48:29 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:48:29 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:48:29 --> Model "user_model" initialized
INFO - 2021-07-08 09:48:29 --> Model "role_model" initialized
INFO - 2021-07-08 09:48:29 --> Controller Class Initialized
INFO - 2021-07-08 09:48:29 --> Helper loaded: language_helper
INFO - 2021-07-08 09:48:29 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:48:29 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:48:29 --> Model "Product_model" initialized
INFO - 2021-07-08 09:48:29 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:48:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:48:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:48:30 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:48:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:48:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:48:30 --> Final output sent to browser
DEBUG - 2021-07-08 09:48:30 --> Total execution time: 0.1100
INFO - 2021-07-08 09:48:33 --> Config Class Initialized
INFO - 2021-07-08 09:48:33 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:48:33 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:48:33 --> Utf8 Class Initialized
INFO - 2021-07-08 09:48:33 --> URI Class Initialized
INFO - 2021-07-08 09:48:33 --> Router Class Initialized
INFO - 2021-07-08 09:48:33 --> Output Class Initialized
INFO - 2021-07-08 09:48:33 --> Security Class Initialized
DEBUG - 2021-07-08 09:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:48:33 --> Input Class Initialized
INFO - 2021-07-08 09:48:33 --> Language Class Initialized
INFO - 2021-07-08 09:48:33 --> Loader Class Initialized
INFO - 2021-07-08 09:48:33 --> Helper loaded: html_helper
INFO - 2021-07-08 09:48:33 --> Helper loaded: url_helper
INFO - 2021-07-08 09:48:33 --> Helper loaded: form_helper
INFO - 2021-07-08 09:48:33 --> Database Driver Class Initialized
INFO - 2021-07-08 09:48:33 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:48:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:48:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:48:33 --> Encryption Class Initialized
INFO - 2021-07-08 09:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:48:33 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:48:33 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:48:33 --> Model "user_model" initialized
INFO - 2021-07-08 09:48:33 --> Model "role_model" initialized
INFO - 2021-07-08 09:48:33 --> Controller Class Initialized
INFO - 2021-07-08 09:48:33 --> Helper loaded: language_helper
INFO - 2021-07-08 09:48:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:48:33 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:48:33 --> Final output sent to browser
DEBUG - 2021-07-08 09:48:33 --> Total execution time: 0.0630
INFO - 2021-07-08 09:48:57 --> Config Class Initialized
INFO - 2021-07-08 09:48:57 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:48:57 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:48:57 --> Utf8 Class Initialized
INFO - 2021-07-08 09:48:57 --> URI Class Initialized
INFO - 2021-07-08 09:48:57 --> Router Class Initialized
INFO - 2021-07-08 09:48:57 --> Output Class Initialized
INFO - 2021-07-08 09:48:57 --> Security Class Initialized
DEBUG - 2021-07-08 09:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:48:57 --> Input Class Initialized
INFO - 2021-07-08 09:48:57 --> Language Class Initialized
INFO - 2021-07-08 09:48:57 --> Loader Class Initialized
INFO - 2021-07-08 09:48:57 --> Helper loaded: html_helper
INFO - 2021-07-08 09:48:57 --> Helper loaded: url_helper
INFO - 2021-07-08 09:48:57 --> Helper loaded: form_helper
INFO - 2021-07-08 09:48:57 --> Database Driver Class Initialized
INFO - 2021-07-08 09:48:58 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:48:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:48:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:48:58 --> Encryption Class Initialized
INFO - 2021-07-08 09:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:48:58 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:48:58 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:48:58 --> Model "user_model" initialized
INFO - 2021-07-08 09:48:58 --> Model "role_model" initialized
INFO - 2021-07-08 09:48:58 --> Controller Class Initialized
INFO - 2021-07-08 09:48:58 --> Helper loaded: language_helper
INFO - 2021-07-08 09:48:58 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:48:58 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:48:58 --> Model "Product_model" initialized
INFO - 2021-07-08 09:48:58 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:48:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:48:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:48:58 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:48:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:48:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:48:58 --> Final output sent to browser
DEBUG - 2021-07-08 09:48:58 --> Total execution time: 0.1220
INFO - 2021-07-08 09:49:01 --> Config Class Initialized
INFO - 2021-07-08 09:49:01 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:49:01 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:49:01 --> Utf8 Class Initialized
INFO - 2021-07-08 09:49:01 --> URI Class Initialized
INFO - 2021-07-08 09:49:01 --> Router Class Initialized
INFO - 2021-07-08 09:49:01 --> Output Class Initialized
INFO - 2021-07-08 09:49:01 --> Security Class Initialized
DEBUG - 2021-07-08 09:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:49:01 --> Input Class Initialized
INFO - 2021-07-08 09:49:01 --> Language Class Initialized
INFO - 2021-07-08 09:49:01 --> Loader Class Initialized
INFO - 2021-07-08 09:49:01 --> Helper loaded: html_helper
INFO - 2021-07-08 09:49:01 --> Helper loaded: url_helper
INFO - 2021-07-08 09:49:01 --> Helper loaded: form_helper
INFO - 2021-07-08 09:49:01 --> Database Driver Class Initialized
INFO - 2021-07-08 09:49:01 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:49:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:49:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:49:01 --> Encryption Class Initialized
INFO - 2021-07-08 09:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:49:01 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:49:01 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:49:01 --> Model "user_model" initialized
INFO - 2021-07-08 09:49:01 --> Model "role_model" initialized
INFO - 2021-07-08 09:49:01 --> Controller Class Initialized
INFO - 2021-07-08 09:49:01 --> Helper loaded: language_helper
INFO - 2021-07-08 09:49:01 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:49:01 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:49:01 --> Final output sent to browser
DEBUG - 2021-07-08 09:49:01 --> Total execution time: 0.0566
INFO - 2021-07-08 09:49:16 --> Config Class Initialized
INFO - 2021-07-08 09:49:16 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:49:16 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:49:16 --> Utf8 Class Initialized
INFO - 2021-07-08 09:49:16 --> URI Class Initialized
INFO - 2021-07-08 09:49:16 --> Router Class Initialized
INFO - 2021-07-08 09:49:16 --> Output Class Initialized
INFO - 2021-07-08 09:49:16 --> Security Class Initialized
DEBUG - 2021-07-08 09:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:49:16 --> Input Class Initialized
INFO - 2021-07-08 09:49:16 --> Language Class Initialized
INFO - 2021-07-08 09:49:16 --> Loader Class Initialized
INFO - 2021-07-08 09:49:16 --> Helper loaded: html_helper
INFO - 2021-07-08 09:49:16 --> Helper loaded: url_helper
INFO - 2021-07-08 09:49:16 --> Helper loaded: form_helper
INFO - 2021-07-08 09:49:16 --> Database Driver Class Initialized
INFO - 2021-07-08 09:49:16 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:49:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:49:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:49:16 --> Encryption Class Initialized
INFO - 2021-07-08 09:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:49:16 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:49:16 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:49:16 --> Model "user_model" initialized
INFO - 2021-07-08 09:49:16 --> Model "role_model" initialized
INFO - 2021-07-08 09:49:16 --> Controller Class Initialized
INFO - 2021-07-08 09:49:16 --> Helper loaded: language_helper
INFO - 2021-07-08 09:49:16 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:49:16 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:49:16 --> Model "Product_model" initialized
INFO - 2021-07-08 09:49:16 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:49:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:49:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:49:16 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:49:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:49:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:49:16 --> Final output sent to browser
DEBUG - 2021-07-08 09:49:16 --> Total execution time: 0.1261
INFO - 2021-07-08 09:49:18 --> Config Class Initialized
INFO - 2021-07-08 09:49:18 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:49:18 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:49:18 --> Utf8 Class Initialized
INFO - 2021-07-08 09:49:18 --> URI Class Initialized
INFO - 2021-07-08 09:49:18 --> Router Class Initialized
INFO - 2021-07-08 09:49:18 --> Output Class Initialized
INFO - 2021-07-08 09:49:18 --> Security Class Initialized
DEBUG - 2021-07-08 09:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:49:18 --> Input Class Initialized
INFO - 2021-07-08 09:49:18 --> Language Class Initialized
INFO - 2021-07-08 09:49:18 --> Loader Class Initialized
INFO - 2021-07-08 09:49:18 --> Helper loaded: html_helper
INFO - 2021-07-08 09:49:18 --> Helper loaded: url_helper
INFO - 2021-07-08 09:49:18 --> Helper loaded: form_helper
INFO - 2021-07-08 09:49:18 --> Database Driver Class Initialized
INFO - 2021-07-08 09:49:18 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:49:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:49:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:49:18 --> Encryption Class Initialized
INFO - 2021-07-08 09:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:49:18 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:49:18 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:49:18 --> Model "user_model" initialized
INFO - 2021-07-08 09:49:18 --> Model "role_model" initialized
INFO - 2021-07-08 09:49:18 --> Controller Class Initialized
INFO - 2021-07-08 09:49:18 --> Helper loaded: language_helper
INFO - 2021-07-08 09:49:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:49:18 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:49:18 --> Final output sent to browser
DEBUG - 2021-07-08 09:49:18 --> Total execution time: 0.0600
INFO - 2021-07-08 09:50:44 --> Config Class Initialized
INFO - 2021-07-08 09:50:44 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:50:44 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:50:44 --> Utf8 Class Initialized
INFO - 2021-07-08 09:50:44 --> URI Class Initialized
INFO - 2021-07-08 09:50:44 --> Router Class Initialized
INFO - 2021-07-08 09:50:44 --> Output Class Initialized
INFO - 2021-07-08 09:50:44 --> Security Class Initialized
DEBUG - 2021-07-08 09:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:50:44 --> Input Class Initialized
INFO - 2021-07-08 09:50:44 --> Language Class Initialized
INFO - 2021-07-08 09:50:44 --> Loader Class Initialized
INFO - 2021-07-08 09:50:44 --> Helper loaded: html_helper
INFO - 2021-07-08 09:50:44 --> Helper loaded: url_helper
INFO - 2021-07-08 09:50:44 --> Helper loaded: form_helper
INFO - 2021-07-08 09:50:44 --> Database Driver Class Initialized
INFO - 2021-07-08 09:50:44 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:50:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:50:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:50:44 --> Encryption Class Initialized
INFO - 2021-07-08 09:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:50:44 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:50:44 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:50:44 --> Model "user_model" initialized
INFO - 2021-07-08 09:50:44 --> Model "role_model" initialized
INFO - 2021-07-08 09:50:44 --> Controller Class Initialized
INFO - 2021-07-08 09:50:44 --> Helper loaded: language_helper
INFO - 2021-07-08 09:50:44 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:50:44 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:50:44 --> Model "Product_model" initialized
INFO - 2021-07-08 09:50:44 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:50:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:50:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:50:44 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:50:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:50:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:50:44 --> Final output sent to browser
DEBUG - 2021-07-08 09:50:44 --> Total execution time: 0.0799
INFO - 2021-07-08 09:51:00 --> Config Class Initialized
INFO - 2021-07-08 09:51:00 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:51:00 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:51:00 --> Utf8 Class Initialized
INFO - 2021-07-08 09:51:00 --> URI Class Initialized
INFO - 2021-07-08 09:51:00 --> Router Class Initialized
INFO - 2021-07-08 09:51:00 --> Output Class Initialized
INFO - 2021-07-08 09:51:00 --> Security Class Initialized
DEBUG - 2021-07-08 09:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:51:00 --> Input Class Initialized
INFO - 2021-07-08 09:51:00 --> Language Class Initialized
INFO - 2021-07-08 09:51:00 --> Loader Class Initialized
INFO - 2021-07-08 09:51:00 --> Helper loaded: html_helper
INFO - 2021-07-08 09:51:00 --> Helper loaded: url_helper
INFO - 2021-07-08 09:51:00 --> Helper loaded: form_helper
INFO - 2021-07-08 09:51:00 --> Database Driver Class Initialized
INFO - 2021-07-08 09:51:00 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:51:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:51:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:51:00 --> Encryption Class Initialized
INFO - 2021-07-08 09:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:51:00 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:51:00 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:51:00 --> Model "user_model" initialized
INFO - 2021-07-08 09:51:00 --> Model "role_model" initialized
INFO - 2021-07-08 09:51:00 --> Controller Class Initialized
INFO - 2021-07-08 09:51:00 --> Helper loaded: language_helper
INFO - 2021-07-08 09:51:00 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:51:00 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:51:00 --> Model "Product_model" initialized
INFO - 2021-07-08 09:51:00 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 09:51:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 09:51:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 09:51:00 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 09:51:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 09:51:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 09:51:00 --> Final output sent to browser
DEBUG - 2021-07-08 09:51:00 --> Total execution time: 0.1317
INFO - 2021-07-08 09:51:04 --> Config Class Initialized
INFO - 2021-07-08 09:51:04 --> Hooks Class Initialized
DEBUG - 2021-07-08 09:51:04 --> UTF-8 Support Enabled
INFO - 2021-07-08 09:51:04 --> Utf8 Class Initialized
INFO - 2021-07-08 09:51:04 --> URI Class Initialized
INFO - 2021-07-08 09:51:04 --> Router Class Initialized
INFO - 2021-07-08 09:51:04 --> Output Class Initialized
INFO - 2021-07-08 09:51:04 --> Security Class Initialized
DEBUG - 2021-07-08 09:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 09:51:04 --> Input Class Initialized
INFO - 2021-07-08 09:51:04 --> Language Class Initialized
INFO - 2021-07-08 09:51:04 --> Loader Class Initialized
INFO - 2021-07-08 09:51:04 --> Helper loaded: html_helper
INFO - 2021-07-08 09:51:04 --> Helper loaded: url_helper
INFO - 2021-07-08 09:51:04 --> Helper loaded: form_helper
INFO - 2021-07-08 09:51:04 --> Database Driver Class Initialized
INFO - 2021-07-08 09:51:04 --> Form Validation Class Initialized
DEBUG - 2021-07-08 09:51:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 09:51:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 09:51:04 --> Encryption Class Initialized
INFO - 2021-07-08 09:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 09:51:04 --> Model "vendor_model" initialized
INFO - 2021-07-08 09:51:04 --> Model "coupon_model" initialized
INFO - 2021-07-08 09:51:04 --> Model "user_model" initialized
INFO - 2021-07-08 09:51:04 --> Model "role_model" initialized
INFO - 2021-07-08 09:51:04 --> Controller Class Initialized
INFO - 2021-07-08 09:51:04 --> Helper loaded: language_helper
INFO - 2021-07-08 09:51:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 09:51:04 --> Model "Customer_model" initialized
INFO - 2021-07-08 09:51:04 --> Final output sent to browser
DEBUG - 2021-07-08 09:51:04 --> Total execution time: 0.0628
INFO - 2021-07-08 10:45:31 --> Config Class Initialized
INFO - 2021-07-08 10:45:31 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:45:31 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:45:31 --> Utf8 Class Initialized
INFO - 2021-07-08 10:45:31 --> URI Class Initialized
INFO - 2021-07-08 10:45:31 --> Router Class Initialized
INFO - 2021-07-08 10:45:31 --> Output Class Initialized
INFO - 2021-07-08 10:45:31 --> Security Class Initialized
DEBUG - 2021-07-08 10:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:45:31 --> Input Class Initialized
INFO - 2021-07-08 10:45:31 --> Language Class Initialized
INFO - 2021-07-08 10:45:31 --> Loader Class Initialized
INFO - 2021-07-08 10:45:31 --> Helper loaded: html_helper
INFO - 2021-07-08 10:45:31 --> Helper loaded: url_helper
INFO - 2021-07-08 10:45:31 --> Helper loaded: form_helper
INFO - 2021-07-08 10:45:31 --> Database Driver Class Initialized
INFO - 2021-07-08 10:45:31 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:45:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:45:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:45:31 --> Encryption Class Initialized
INFO - 2021-07-08 10:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:45:31 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:45:31 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:45:31 --> Model "user_model" initialized
INFO - 2021-07-08 10:45:31 --> Model "role_model" initialized
INFO - 2021-07-08 10:45:31 --> Controller Class Initialized
INFO - 2021-07-08 10:45:31 --> Helper loaded: language_helper
INFO - 2021-07-08 10:45:31 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:45:31 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:45:31 --> Model "Product_model" initialized
INFO - 2021-07-08 10:45:31 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 10:45:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 10:45:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 10:45:31 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 10:45:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 10:45:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 10:45:31 --> Final output sent to browser
DEBUG - 2021-07-08 10:45:31 --> Total execution time: 0.0822
INFO - 2021-07-08 10:46:44 --> Config Class Initialized
INFO - 2021-07-08 10:46:44 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:46:44 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:46:44 --> Utf8 Class Initialized
INFO - 2021-07-08 10:46:44 --> URI Class Initialized
INFO - 2021-07-08 10:46:44 --> Router Class Initialized
INFO - 2021-07-08 10:46:44 --> Output Class Initialized
INFO - 2021-07-08 10:46:44 --> Security Class Initialized
DEBUG - 2021-07-08 10:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:46:44 --> Input Class Initialized
INFO - 2021-07-08 10:46:44 --> Language Class Initialized
INFO - 2021-07-08 10:46:44 --> Loader Class Initialized
INFO - 2021-07-08 10:46:44 --> Helper loaded: html_helper
INFO - 2021-07-08 10:46:44 --> Helper loaded: url_helper
INFO - 2021-07-08 10:46:44 --> Helper loaded: form_helper
INFO - 2021-07-08 10:46:44 --> Database Driver Class Initialized
INFO - 2021-07-08 10:46:44 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:46:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:46:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:46:44 --> Encryption Class Initialized
INFO - 2021-07-08 10:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:46:44 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:46:44 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:46:44 --> Model "user_model" initialized
INFO - 2021-07-08 10:46:44 --> Model "role_model" initialized
INFO - 2021-07-08 10:46:44 --> Controller Class Initialized
INFO - 2021-07-08 10:46:44 --> Helper loaded: language_helper
INFO - 2021-07-08 10:46:44 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:46:44 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:46:44 --> Model "Product_model" initialized
INFO - 2021-07-08 10:46:44 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 10:46:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 10:46:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 10:46:44 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 10:46:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 10:46:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 10:46:44 --> Final output sent to browser
DEBUG - 2021-07-08 10:46:44 --> Total execution time: 0.0818
INFO - 2021-07-08 10:47:37 --> Config Class Initialized
INFO - 2021-07-08 10:47:37 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:47:37 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:47:37 --> Utf8 Class Initialized
INFO - 2021-07-08 10:47:37 --> URI Class Initialized
INFO - 2021-07-08 10:47:37 --> Router Class Initialized
INFO - 2021-07-08 10:47:37 --> Output Class Initialized
INFO - 2021-07-08 10:47:37 --> Security Class Initialized
DEBUG - 2021-07-08 10:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:47:37 --> Input Class Initialized
INFO - 2021-07-08 10:47:37 --> Language Class Initialized
INFO - 2021-07-08 10:47:37 --> Loader Class Initialized
INFO - 2021-07-08 10:47:37 --> Helper loaded: html_helper
INFO - 2021-07-08 10:47:37 --> Helper loaded: url_helper
INFO - 2021-07-08 10:47:37 --> Helper loaded: form_helper
INFO - 2021-07-08 10:47:37 --> Database Driver Class Initialized
INFO - 2021-07-08 10:47:37 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:47:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:47:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:47:37 --> Encryption Class Initialized
INFO - 2021-07-08 10:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:47:37 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:47:37 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:47:37 --> Model "user_model" initialized
INFO - 2021-07-08 10:47:37 --> Model "role_model" initialized
INFO - 2021-07-08 10:47:37 --> Controller Class Initialized
INFO - 2021-07-08 10:47:37 --> Helper loaded: language_helper
INFO - 2021-07-08 10:47:37 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:47:37 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:47:37 --> Model "Product_model" initialized
INFO - 2021-07-08 10:47:37 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 10:47:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 10:47:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 10:47:37 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 10:47:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 10:47:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 10:47:37 --> Final output sent to browser
DEBUG - 2021-07-08 10:47:37 --> Total execution time: 0.1135
INFO - 2021-07-08 10:47:40 --> Config Class Initialized
INFO - 2021-07-08 10:47:40 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:47:40 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:47:40 --> Utf8 Class Initialized
INFO - 2021-07-08 10:47:40 --> URI Class Initialized
INFO - 2021-07-08 10:47:40 --> Router Class Initialized
INFO - 2021-07-08 10:47:40 --> Output Class Initialized
INFO - 2021-07-08 10:47:40 --> Security Class Initialized
DEBUG - 2021-07-08 10:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:47:40 --> Input Class Initialized
INFO - 2021-07-08 10:47:40 --> Language Class Initialized
INFO - 2021-07-08 10:47:40 --> Loader Class Initialized
INFO - 2021-07-08 10:47:40 --> Helper loaded: html_helper
INFO - 2021-07-08 10:47:40 --> Helper loaded: url_helper
INFO - 2021-07-08 10:47:40 --> Helper loaded: form_helper
INFO - 2021-07-08 10:47:40 --> Database Driver Class Initialized
INFO - 2021-07-08 10:47:40 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:47:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:47:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:47:40 --> Encryption Class Initialized
INFO - 2021-07-08 10:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:47:40 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:47:40 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:47:40 --> Model "user_model" initialized
INFO - 2021-07-08 10:47:40 --> Model "role_model" initialized
INFO - 2021-07-08 10:47:40 --> Controller Class Initialized
INFO - 2021-07-08 10:47:40 --> Helper loaded: language_helper
INFO - 2021-07-08 10:47:40 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:47:40 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:47:40 --> Final output sent to browser
DEBUG - 2021-07-08 10:47:40 --> Total execution time: 0.0598
INFO - 2021-07-08 10:48:00 --> Config Class Initialized
INFO - 2021-07-08 10:48:00 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:48:00 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:48:00 --> Utf8 Class Initialized
INFO - 2021-07-08 10:48:00 --> URI Class Initialized
INFO - 2021-07-08 10:48:00 --> Router Class Initialized
INFO - 2021-07-08 10:48:00 --> Output Class Initialized
INFO - 2021-07-08 10:48:00 --> Security Class Initialized
DEBUG - 2021-07-08 10:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:48:00 --> Input Class Initialized
INFO - 2021-07-08 10:48:00 --> Language Class Initialized
INFO - 2021-07-08 10:48:00 --> Loader Class Initialized
INFO - 2021-07-08 10:48:00 --> Helper loaded: html_helper
INFO - 2021-07-08 10:48:00 --> Helper loaded: url_helper
INFO - 2021-07-08 10:48:00 --> Helper loaded: form_helper
INFO - 2021-07-08 10:48:00 --> Database Driver Class Initialized
INFO - 2021-07-08 10:48:00 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:48:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:48:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:48:00 --> Encryption Class Initialized
INFO - 2021-07-08 10:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:48:00 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:48:00 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:48:00 --> Model "user_model" initialized
INFO - 2021-07-08 10:48:00 --> Model "role_model" initialized
INFO - 2021-07-08 10:48:00 --> Controller Class Initialized
INFO - 2021-07-08 10:48:00 --> Helper loaded: language_helper
INFO - 2021-07-08 10:48:00 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:48:00 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:48:00 --> Model "Product_model" initialized
INFO - 2021-07-08 10:48:00 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 10:48:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 10:48:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 10:48:00 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 10:48:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 10:48:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 10:48:00 --> Final output sent to browser
DEBUG - 2021-07-08 10:48:00 --> Total execution time: 0.0999
INFO - 2021-07-08 10:48:03 --> Config Class Initialized
INFO - 2021-07-08 10:48:03 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:48:03 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:48:03 --> Utf8 Class Initialized
INFO - 2021-07-08 10:48:03 --> URI Class Initialized
INFO - 2021-07-08 10:48:03 --> Router Class Initialized
INFO - 2021-07-08 10:48:03 --> Output Class Initialized
INFO - 2021-07-08 10:48:03 --> Security Class Initialized
DEBUG - 2021-07-08 10:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:48:03 --> Input Class Initialized
INFO - 2021-07-08 10:48:03 --> Language Class Initialized
INFO - 2021-07-08 10:48:03 --> Loader Class Initialized
INFO - 2021-07-08 10:48:03 --> Helper loaded: html_helper
INFO - 2021-07-08 10:48:03 --> Helper loaded: url_helper
INFO - 2021-07-08 10:48:03 --> Helper loaded: form_helper
INFO - 2021-07-08 10:48:03 --> Database Driver Class Initialized
INFO - 2021-07-08 10:48:03 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:48:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:48:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:48:03 --> Encryption Class Initialized
INFO - 2021-07-08 10:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:48:03 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:48:03 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:48:03 --> Model "user_model" initialized
INFO - 2021-07-08 10:48:03 --> Model "role_model" initialized
INFO - 2021-07-08 10:48:03 --> Controller Class Initialized
INFO - 2021-07-08 10:48:03 --> Helper loaded: language_helper
INFO - 2021-07-08 10:48:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:48:03 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:48:03 --> Final output sent to browser
DEBUG - 2021-07-08 10:48:03 --> Total execution time: 0.0613
INFO - 2021-07-08 10:48:09 --> Config Class Initialized
INFO - 2021-07-08 10:48:09 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:48:09 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:48:09 --> Utf8 Class Initialized
INFO - 2021-07-08 10:48:09 --> URI Class Initialized
INFO - 2021-07-08 10:48:09 --> Router Class Initialized
INFO - 2021-07-08 10:48:09 --> Output Class Initialized
INFO - 2021-07-08 10:48:09 --> Security Class Initialized
DEBUG - 2021-07-08 10:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:48:09 --> Input Class Initialized
INFO - 2021-07-08 10:48:09 --> Language Class Initialized
INFO - 2021-07-08 10:48:09 --> Loader Class Initialized
INFO - 2021-07-08 10:48:09 --> Helper loaded: html_helper
INFO - 2021-07-08 10:48:09 --> Helper loaded: url_helper
INFO - 2021-07-08 10:48:09 --> Helper loaded: form_helper
INFO - 2021-07-08 10:48:09 --> Database Driver Class Initialized
INFO - 2021-07-08 10:48:09 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:48:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:48:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:48:09 --> Encryption Class Initialized
INFO - 2021-07-08 10:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:48:09 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:48:09 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:48:09 --> Model "user_model" initialized
INFO - 2021-07-08 10:48:09 --> Model "role_model" initialized
INFO - 2021-07-08 10:48:09 --> Controller Class Initialized
INFO - 2021-07-08 10:48:09 --> Helper loaded: language_helper
INFO - 2021-07-08 10:48:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:48:09 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:48:09 --> Final output sent to browser
DEBUG - 2021-07-08 10:48:09 --> Total execution time: 0.0628
INFO - 2021-07-08 10:48:59 --> Config Class Initialized
INFO - 2021-07-08 10:48:59 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:48:59 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:48:59 --> Utf8 Class Initialized
INFO - 2021-07-08 10:48:59 --> URI Class Initialized
INFO - 2021-07-08 10:48:59 --> Router Class Initialized
INFO - 2021-07-08 10:48:59 --> Output Class Initialized
INFO - 2021-07-08 10:48:59 --> Security Class Initialized
DEBUG - 2021-07-08 10:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:48:59 --> Input Class Initialized
INFO - 2021-07-08 10:48:59 --> Language Class Initialized
INFO - 2021-07-08 10:48:59 --> Loader Class Initialized
INFO - 2021-07-08 10:48:59 --> Helper loaded: html_helper
INFO - 2021-07-08 10:48:59 --> Helper loaded: url_helper
INFO - 2021-07-08 10:48:59 --> Helper loaded: form_helper
INFO - 2021-07-08 10:48:59 --> Database Driver Class Initialized
INFO - 2021-07-08 10:48:59 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:48:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:48:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:48:59 --> Encryption Class Initialized
INFO - 2021-07-08 10:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:48:59 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:48:59 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:48:59 --> Model "user_model" initialized
INFO - 2021-07-08 10:48:59 --> Model "role_model" initialized
INFO - 2021-07-08 10:48:59 --> Controller Class Initialized
INFO - 2021-07-08 10:48:59 --> Helper loaded: language_helper
INFO - 2021-07-08 10:48:59 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:48:59 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:48:59 --> Model "Product_model" initialized
INFO - 2021-07-08 10:48:59 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 10:48:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 10:48:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 10:48:59 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 10:48:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 10:48:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 10:48:59 --> Final output sent to browser
DEBUG - 2021-07-08 10:48:59 --> Total execution time: 0.1135
INFO - 2021-07-08 10:49:02 --> Config Class Initialized
INFO - 2021-07-08 10:49:02 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:49:02 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:49:02 --> Utf8 Class Initialized
INFO - 2021-07-08 10:49:02 --> URI Class Initialized
INFO - 2021-07-08 10:49:02 --> Router Class Initialized
INFO - 2021-07-08 10:49:02 --> Output Class Initialized
INFO - 2021-07-08 10:49:02 --> Security Class Initialized
DEBUG - 2021-07-08 10:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:49:02 --> Input Class Initialized
INFO - 2021-07-08 10:49:02 --> Language Class Initialized
INFO - 2021-07-08 10:49:02 --> Loader Class Initialized
INFO - 2021-07-08 10:49:02 --> Helper loaded: html_helper
INFO - 2021-07-08 10:49:02 --> Helper loaded: url_helper
INFO - 2021-07-08 10:49:02 --> Helper loaded: form_helper
INFO - 2021-07-08 10:49:02 --> Database Driver Class Initialized
INFO - 2021-07-08 10:49:02 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:49:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:49:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:49:02 --> Encryption Class Initialized
INFO - 2021-07-08 10:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:49:02 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:49:02 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:49:02 --> Model "user_model" initialized
INFO - 2021-07-08 10:49:02 --> Model "role_model" initialized
INFO - 2021-07-08 10:49:02 --> Controller Class Initialized
INFO - 2021-07-08 10:49:02 --> Helper loaded: language_helper
INFO - 2021-07-08 10:49:02 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:49:02 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:49:02 --> Final output sent to browser
DEBUG - 2021-07-08 10:49:02 --> Total execution time: 0.0654
INFO - 2021-07-08 10:49:07 --> Config Class Initialized
INFO - 2021-07-08 10:49:07 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:49:07 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:49:07 --> Utf8 Class Initialized
INFO - 2021-07-08 10:49:07 --> URI Class Initialized
INFO - 2021-07-08 10:49:07 --> Router Class Initialized
INFO - 2021-07-08 10:49:07 --> Output Class Initialized
INFO - 2021-07-08 10:49:07 --> Security Class Initialized
DEBUG - 2021-07-08 10:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:49:07 --> Input Class Initialized
INFO - 2021-07-08 10:49:07 --> Language Class Initialized
INFO - 2021-07-08 10:49:07 --> Loader Class Initialized
INFO - 2021-07-08 10:49:07 --> Helper loaded: html_helper
INFO - 2021-07-08 10:49:07 --> Helper loaded: url_helper
INFO - 2021-07-08 10:49:07 --> Helper loaded: form_helper
INFO - 2021-07-08 10:49:07 --> Database Driver Class Initialized
INFO - 2021-07-08 10:49:07 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:49:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:49:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:49:07 --> Encryption Class Initialized
INFO - 2021-07-08 10:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:49:07 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:49:07 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:49:07 --> Model "user_model" initialized
INFO - 2021-07-08 10:49:07 --> Model "role_model" initialized
INFO - 2021-07-08 10:49:07 --> Controller Class Initialized
INFO - 2021-07-08 10:49:07 --> Helper loaded: language_helper
INFO - 2021-07-08 10:49:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:49:07 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:49:07 --> Final output sent to browser
DEBUG - 2021-07-08 10:49:07 --> Total execution time: 0.0579
INFO - 2021-07-08 10:49:22 --> Config Class Initialized
INFO - 2021-07-08 10:49:22 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:49:22 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:49:22 --> Utf8 Class Initialized
INFO - 2021-07-08 10:49:22 --> URI Class Initialized
INFO - 2021-07-08 10:49:22 --> Router Class Initialized
INFO - 2021-07-08 10:49:22 --> Output Class Initialized
INFO - 2021-07-08 10:49:22 --> Security Class Initialized
DEBUG - 2021-07-08 10:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:49:22 --> Input Class Initialized
INFO - 2021-07-08 10:49:22 --> Language Class Initialized
INFO - 2021-07-08 10:49:22 --> Loader Class Initialized
INFO - 2021-07-08 10:49:22 --> Helper loaded: html_helper
INFO - 2021-07-08 10:49:22 --> Helper loaded: url_helper
INFO - 2021-07-08 10:49:22 --> Helper loaded: form_helper
INFO - 2021-07-08 10:49:22 --> Database Driver Class Initialized
INFO - 2021-07-08 10:49:22 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:49:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:49:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:49:22 --> Encryption Class Initialized
INFO - 2021-07-08 10:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:49:22 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:49:22 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:49:22 --> Model "user_model" initialized
INFO - 2021-07-08 10:49:22 --> Model "role_model" initialized
INFO - 2021-07-08 10:49:22 --> Controller Class Initialized
INFO - 2021-07-08 10:49:22 --> Helper loaded: language_helper
INFO - 2021-07-08 10:49:22 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:49:22 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:49:22 --> Model "Product_model" initialized
INFO - 2021-07-08 10:49:22 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 10:49:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 10:49:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 10:49:22 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 10:49:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 10:49:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 10:49:22 --> Final output sent to browser
DEBUG - 2021-07-08 10:49:22 --> Total execution time: 0.1206
INFO - 2021-07-08 10:49:24 --> Config Class Initialized
INFO - 2021-07-08 10:49:24 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:49:24 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:49:24 --> Utf8 Class Initialized
INFO - 2021-07-08 10:49:24 --> URI Class Initialized
INFO - 2021-07-08 10:49:24 --> Router Class Initialized
INFO - 2021-07-08 10:49:24 --> Output Class Initialized
INFO - 2021-07-08 10:49:24 --> Security Class Initialized
DEBUG - 2021-07-08 10:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:49:24 --> Input Class Initialized
INFO - 2021-07-08 10:49:24 --> Language Class Initialized
INFO - 2021-07-08 10:49:24 --> Loader Class Initialized
INFO - 2021-07-08 10:49:24 --> Helper loaded: html_helper
INFO - 2021-07-08 10:49:24 --> Helper loaded: url_helper
INFO - 2021-07-08 10:49:24 --> Helper loaded: form_helper
INFO - 2021-07-08 10:49:24 --> Database Driver Class Initialized
INFO - 2021-07-08 10:49:24 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:49:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:49:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:49:24 --> Encryption Class Initialized
INFO - 2021-07-08 10:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:49:24 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:49:24 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:49:24 --> Model "user_model" initialized
INFO - 2021-07-08 10:49:24 --> Model "role_model" initialized
INFO - 2021-07-08 10:49:24 --> Controller Class Initialized
INFO - 2021-07-08 10:49:24 --> Helper loaded: language_helper
INFO - 2021-07-08 10:49:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:49:24 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:49:24 --> Final output sent to browser
DEBUG - 2021-07-08 10:49:24 --> Total execution time: 0.0662
INFO - 2021-07-08 10:49:32 --> Config Class Initialized
INFO - 2021-07-08 10:49:32 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:49:32 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:49:32 --> Utf8 Class Initialized
INFO - 2021-07-08 10:49:32 --> URI Class Initialized
INFO - 2021-07-08 10:49:32 --> Router Class Initialized
INFO - 2021-07-08 10:49:32 --> Output Class Initialized
INFO - 2021-07-08 10:49:32 --> Security Class Initialized
DEBUG - 2021-07-08 10:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:49:32 --> Input Class Initialized
INFO - 2021-07-08 10:49:32 --> Language Class Initialized
INFO - 2021-07-08 10:49:32 --> Loader Class Initialized
INFO - 2021-07-08 10:49:32 --> Helper loaded: html_helper
INFO - 2021-07-08 10:49:32 --> Helper loaded: url_helper
INFO - 2021-07-08 10:49:32 --> Helper loaded: form_helper
INFO - 2021-07-08 10:49:32 --> Database Driver Class Initialized
INFO - 2021-07-08 10:49:32 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:49:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:49:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:49:32 --> Encryption Class Initialized
INFO - 2021-07-08 10:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:49:32 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:49:32 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:49:32 --> Model "user_model" initialized
INFO - 2021-07-08 10:49:32 --> Model "role_model" initialized
INFO - 2021-07-08 10:49:32 --> Controller Class Initialized
INFO - 2021-07-08 10:49:32 --> Helper loaded: language_helper
INFO - 2021-07-08 10:49:32 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:49:32 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:49:32 --> Final output sent to browser
DEBUG - 2021-07-08 10:49:32 --> Total execution time: 0.0659
INFO - 2021-07-08 10:53:08 --> Config Class Initialized
INFO - 2021-07-08 10:53:08 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:53:08 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:53:08 --> Utf8 Class Initialized
INFO - 2021-07-08 10:53:08 --> URI Class Initialized
INFO - 2021-07-08 10:53:08 --> Router Class Initialized
INFO - 2021-07-08 10:53:08 --> Output Class Initialized
INFO - 2021-07-08 10:53:08 --> Security Class Initialized
DEBUG - 2021-07-08 10:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:53:08 --> Input Class Initialized
INFO - 2021-07-08 10:53:08 --> Language Class Initialized
INFO - 2021-07-08 10:53:08 --> Loader Class Initialized
INFO - 2021-07-08 10:53:08 --> Helper loaded: html_helper
INFO - 2021-07-08 10:53:09 --> Helper loaded: url_helper
INFO - 2021-07-08 10:53:09 --> Helper loaded: form_helper
INFO - 2021-07-08 10:53:09 --> Database Driver Class Initialized
INFO - 2021-07-08 10:53:09 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:53:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:53:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:53:09 --> Encryption Class Initialized
INFO - 2021-07-08 10:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:53:09 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:53:09 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:53:09 --> Model "user_model" initialized
INFO - 2021-07-08 10:53:09 --> Model "role_model" initialized
INFO - 2021-07-08 10:53:09 --> Controller Class Initialized
INFO - 2021-07-08 10:53:09 --> Helper loaded: language_helper
INFO - 2021-07-08 10:53:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:53:09 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:53:09 --> Model "Product_model" initialized
INFO - 2021-07-08 10:53:09 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 10:53:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 10:53:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 10:53:09 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 10:53:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 10:53:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 10:53:09 --> Final output sent to browser
DEBUG - 2021-07-08 10:53:09 --> Total execution time: 0.1823
INFO - 2021-07-08 10:53:12 --> Config Class Initialized
INFO - 2021-07-08 10:53:12 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:53:12 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:53:12 --> Utf8 Class Initialized
INFO - 2021-07-08 10:53:12 --> URI Class Initialized
INFO - 2021-07-08 10:53:12 --> Router Class Initialized
INFO - 2021-07-08 10:53:12 --> Output Class Initialized
INFO - 2021-07-08 10:53:12 --> Security Class Initialized
DEBUG - 2021-07-08 10:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:53:12 --> Input Class Initialized
INFO - 2021-07-08 10:53:12 --> Language Class Initialized
INFO - 2021-07-08 10:53:12 --> Loader Class Initialized
INFO - 2021-07-08 10:53:12 --> Helper loaded: html_helper
INFO - 2021-07-08 10:53:12 --> Helper loaded: url_helper
INFO - 2021-07-08 10:53:12 --> Helper loaded: form_helper
INFO - 2021-07-08 10:53:12 --> Database Driver Class Initialized
INFO - 2021-07-08 10:53:12 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:53:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:53:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:53:12 --> Encryption Class Initialized
INFO - 2021-07-08 10:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:53:12 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:53:12 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:53:12 --> Model "user_model" initialized
INFO - 2021-07-08 10:53:12 --> Model "role_model" initialized
INFO - 2021-07-08 10:53:12 --> Controller Class Initialized
INFO - 2021-07-08 10:53:12 --> Helper loaded: language_helper
INFO - 2021-07-08 10:53:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:53:12 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:53:12 --> Final output sent to browser
DEBUG - 2021-07-08 10:53:12 --> Total execution time: 0.0632
INFO - 2021-07-08 10:53:40 --> Config Class Initialized
INFO - 2021-07-08 10:53:40 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:53:40 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:53:40 --> Utf8 Class Initialized
INFO - 2021-07-08 10:53:40 --> URI Class Initialized
INFO - 2021-07-08 10:53:40 --> Router Class Initialized
INFO - 2021-07-08 10:53:40 --> Output Class Initialized
INFO - 2021-07-08 10:53:40 --> Security Class Initialized
DEBUG - 2021-07-08 10:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:53:40 --> Input Class Initialized
INFO - 2021-07-08 10:53:40 --> Language Class Initialized
INFO - 2021-07-08 10:53:40 --> Loader Class Initialized
INFO - 2021-07-08 10:53:40 --> Helper loaded: html_helper
INFO - 2021-07-08 10:53:40 --> Helper loaded: url_helper
INFO - 2021-07-08 10:53:40 --> Helper loaded: form_helper
INFO - 2021-07-08 10:53:40 --> Database Driver Class Initialized
INFO - 2021-07-08 10:53:40 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:53:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:53:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:53:40 --> Encryption Class Initialized
INFO - 2021-07-08 10:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:53:40 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:53:40 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:53:40 --> Model "user_model" initialized
INFO - 2021-07-08 10:53:40 --> Model "role_model" initialized
INFO - 2021-07-08 10:53:40 --> Controller Class Initialized
INFO - 2021-07-08 10:53:40 --> Helper loaded: language_helper
INFO - 2021-07-08 10:53:40 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:53:40 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:53:40 --> Model "Product_model" initialized
INFO - 2021-07-08 10:53:40 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 10:53:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 10:53:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 10:53:40 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 10:53:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 10:53:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 10:53:40 --> Final output sent to browser
DEBUG - 2021-07-08 10:53:40 --> Total execution time: 0.1175
INFO - 2021-07-08 10:53:44 --> Config Class Initialized
INFO - 2021-07-08 10:53:44 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:53:44 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:53:44 --> Utf8 Class Initialized
INFO - 2021-07-08 10:53:44 --> URI Class Initialized
INFO - 2021-07-08 10:53:44 --> Router Class Initialized
INFO - 2021-07-08 10:53:44 --> Output Class Initialized
INFO - 2021-07-08 10:53:44 --> Security Class Initialized
DEBUG - 2021-07-08 10:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:53:44 --> Input Class Initialized
INFO - 2021-07-08 10:53:44 --> Language Class Initialized
INFO - 2021-07-08 10:53:44 --> Loader Class Initialized
INFO - 2021-07-08 10:53:44 --> Helper loaded: html_helper
INFO - 2021-07-08 10:53:44 --> Helper loaded: url_helper
INFO - 2021-07-08 10:53:44 --> Helper loaded: form_helper
INFO - 2021-07-08 10:53:44 --> Database Driver Class Initialized
INFO - 2021-07-08 10:53:44 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:53:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:53:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:53:44 --> Encryption Class Initialized
INFO - 2021-07-08 10:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:53:44 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:53:44 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:53:44 --> Model "user_model" initialized
INFO - 2021-07-08 10:53:44 --> Model "role_model" initialized
INFO - 2021-07-08 10:53:44 --> Controller Class Initialized
INFO - 2021-07-08 10:53:44 --> Helper loaded: language_helper
INFO - 2021-07-08 10:53:44 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:53:44 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:53:44 --> Final output sent to browser
DEBUG - 2021-07-08 10:53:44 --> Total execution time: 0.0625
INFO - 2021-07-08 10:53:53 --> Config Class Initialized
INFO - 2021-07-08 10:53:53 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:53:53 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:53:53 --> Utf8 Class Initialized
INFO - 2021-07-08 10:53:53 --> URI Class Initialized
INFO - 2021-07-08 10:53:53 --> Router Class Initialized
INFO - 2021-07-08 10:53:53 --> Output Class Initialized
INFO - 2021-07-08 10:53:53 --> Security Class Initialized
DEBUG - 2021-07-08 10:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:53:53 --> Input Class Initialized
INFO - 2021-07-08 10:53:53 --> Language Class Initialized
INFO - 2021-07-08 10:53:53 --> Loader Class Initialized
INFO - 2021-07-08 10:53:53 --> Helper loaded: html_helper
INFO - 2021-07-08 10:53:54 --> Helper loaded: url_helper
INFO - 2021-07-08 10:53:54 --> Helper loaded: form_helper
INFO - 2021-07-08 10:53:54 --> Database Driver Class Initialized
INFO - 2021-07-08 10:53:54 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:53:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:53:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:53:54 --> Encryption Class Initialized
INFO - 2021-07-08 10:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:53:54 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:53:54 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:53:54 --> Model "user_model" initialized
INFO - 2021-07-08 10:53:54 --> Model "role_model" initialized
INFO - 2021-07-08 10:53:54 --> Controller Class Initialized
INFO - 2021-07-08 10:53:54 --> Helper loaded: language_helper
INFO - 2021-07-08 10:53:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:53:54 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:53:54 --> Final output sent to browser
DEBUG - 2021-07-08 10:53:54 --> Total execution time: 0.0643
INFO - 2021-07-08 10:55:03 --> Config Class Initialized
INFO - 2021-07-08 10:55:03 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:55:03 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:55:03 --> Utf8 Class Initialized
INFO - 2021-07-08 10:55:03 --> URI Class Initialized
INFO - 2021-07-08 10:55:03 --> Router Class Initialized
INFO - 2021-07-08 10:55:03 --> Output Class Initialized
INFO - 2021-07-08 10:55:03 --> Security Class Initialized
DEBUG - 2021-07-08 10:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:55:03 --> Input Class Initialized
INFO - 2021-07-08 10:55:03 --> Language Class Initialized
INFO - 2021-07-08 10:55:03 --> Loader Class Initialized
INFO - 2021-07-08 10:55:03 --> Helper loaded: html_helper
INFO - 2021-07-08 10:55:03 --> Helper loaded: url_helper
INFO - 2021-07-08 10:55:03 --> Helper loaded: form_helper
INFO - 2021-07-08 10:55:03 --> Database Driver Class Initialized
INFO - 2021-07-08 10:55:03 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:55:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:55:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:55:03 --> Encryption Class Initialized
INFO - 2021-07-08 10:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:55:03 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:55:03 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:55:03 --> Model "user_model" initialized
INFO - 2021-07-08 10:55:03 --> Model "role_model" initialized
INFO - 2021-07-08 10:55:03 --> Controller Class Initialized
INFO - 2021-07-08 10:55:03 --> Helper loaded: language_helper
INFO - 2021-07-08 10:55:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:55:03 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:55:03 --> Model "Product_model" initialized
INFO - 2021-07-08 10:55:03 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 10:55:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 10:55:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 10:55:03 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 10:55:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 10:55:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 10:55:03 --> Final output sent to browser
DEBUG - 2021-07-08 10:55:03 --> Total execution time: 0.1240
INFO - 2021-07-08 10:55:07 --> Config Class Initialized
INFO - 2021-07-08 10:55:07 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:55:07 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:55:07 --> Utf8 Class Initialized
INFO - 2021-07-08 10:55:07 --> URI Class Initialized
INFO - 2021-07-08 10:55:07 --> Router Class Initialized
INFO - 2021-07-08 10:55:07 --> Output Class Initialized
INFO - 2021-07-08 10:55:07 --> Security Class Initialized
DEBUG - 2021-07-08 10:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:55:07 --> Input Class Initialized
INFO - 2021-07-08 10:55:07 --> Language Class Initialized
INFO - 2021-07-08 10:55:07 --> Loader Class Initialized
INFO - 2021-07-08 10:55:07 --> Helper loaded: html_helper
INFO - 2021-07-08 10:55:07 --> Helper loaded: url_helper
INFO - 2021-07-08 10:55:07 --> Helper loaded: form_helper
INFO - 2021-07-08 10:55:07 --> Database Driver Class Initialized
INFO - 2021-07-08 10:55:07 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:55:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:55:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:55:07 --> Encryption Class Initialized
INFO - 2021-07-08 10:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:55:07 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:55:07 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:55:07 --> Model "user_model" initialized
INFO - 2021-07-08 10:55:07 --> Model "role_model" initialized
INFO - 2021-07-08 10:55:07 --> Controller Class Initialized
INFO - 2021-07-08 10:55:07 --> Helper loaded: language_helper
INFO - 2021-07-08 10:55:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:55:07 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:55:07 --> Final output sent to browser
DEBUG - 2021-07-08 10:55:07 --> Total execution time: 0.0669
INFO - 2021-07-08 10:55:54 --> Config Class Initialized
INFO - 2021-07-08 10:55:54 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:55:54 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:55:54 --> Utf8 Class Initialized
INFO - 2021-07-08 10:55:54 --> URI Class Initialized
INFO - 2021-07-08 10:55:54 --> Router Class Initialized
INFO - 2021-07-08 10:55:54 --> Output Class Initialized
INFO - 2021-07-08 10:55:54 --> Security Class Initialized
DEBUG - 2021-07-08 10:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:55:54 --> Input Class Initialized
INFO - 2021-07-08 10:55:54 --> Language Class Initialized
INFO - 2021-07-08 10:55:54 --> Loader Class Initialized
INFO - 2021-07-08 10:55:54 --> Helper loaded: html_helper
INFO - 2021-07-08 10:55:54 --> Helper loaded: url_helper
INFO - 2021-07-08 10:55:54 --> Helper loaded: form_helper
INFO - 2021-07-08 10:55:54 --> Database Driver Class Initialized
INFO - 2021-07-08 10:55:54 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:55:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:55:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:55:54 --> Encryption Class Initialized
INFO - 2021-07-08 10:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:55:54 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:55:54 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:55:54 --> Model "user_model" initialized
INFO - 2021-07-08 10:55:54 --> Model "role_model" initialized
INFO - 2021-07-08 10:55:54 --> Controller Class Initialized
INFO - 2021-07-08 10:55:54 --> Helper loaded: language_helper
INFO - 2021-07-08 10:55:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:55:54 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:55:54 --> Model "Product_model" initialized
INFO - 2021-07-08 10:55:54 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 10:55:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 10:55:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 10:55:54 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 10:55:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 10:55:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 10:55:54 --> Final output sent to browser
DEBUG - 2021-07-08 10:55:54 --> Total execution time: 0.1225
INFO - 2021-07-08 10:55:57 --> Config Class Initialized
INFO - 2021-07-08 10:55:57 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:55:57 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:55:57 --> Utf8 Class Initialized
INFO - 2021-07-08 10:55:57 --> URI Class Initialized
INFO - 2021-07-08 10:55:57 --> Router Class Initialized
INFO - 2021-07-08 10:55:57 --> Output Class Initialized
INFO - 2021-07-08 10:55:57 --> Security Class Initialized
DEBUG - 2021-07-08 10:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:55:57 --> Input Class Initialized
INFO - 2021-07-08 10:55:57 --> Language Class Initialized
INFO - 2021-07-08 10:55:57 --> Loader Class Initialized
INFO - 2021-07-08 10:55:57 --> Helper loaded: html_helper
INFO - 2021-07-08 10:55:57 --> Helper loaded: url_helper
INFO - 2021-07-08 10:55:57 --> Helper loaded: form_helper
INFO - 2021-07-08 10:55:57 --> Database Driver Class Initialized
INFO - 2021-07-08 10:55:57 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:55:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:55:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:55:57 --> Encryption Class Initialized
INFO - 2021-07-08 10:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:55:57 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:55:57 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:55:57 --> Model "user_model" initialized
INFO - 2021-07-08 10:55:57 --> Model "role_model" initialized
INFO - 2021-07-08 10:55:57 --> Controller Class Initialized
INFO - 2021-07-08 10:55:57 --> Helper loaded: language_helper
INFO - 2021-07-08 10:55:57 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:55:57 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:55:57 --> Final output sent to browser
DEBUG - 2021-07-08 10:55:57 --> Total execution time: 0.0628
INFO - 2021-07-08 10:56:03 --> Config Class Initialized
INFO - 2021-07-08 10:56:03 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:56:03 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:56:03 --> Utf8 Class Initialized
INFO - 2021-07-08 10:56:03 --> URI Class Initialized
INFO - 2021-07-08 10:56:03 --> Router Class Initialized
INFO - 2021-07-08 10:56:03 --> Output Class Initialized
INFO - 2021-07-08 10:56:03 --> Security Class Initialized
DEBUG - 2021-07-08 10:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:56:03 --> Input Class Initialized
INFO - 2021-07-08 10:56:03 --> Language Class Initialized
INFO - 2021-07-08 10:56:03 --> Loader Class Initialized
INFO - 2021-07-08 10:56:03 --> Helper loaded: html_helper
INFO - 2021-07-08 10:56:03 --> Helper loaded: url_helper
INFO - 2021-07-08 10:56:03 --> Helper loaded: form_helper
INFO - 2021-07-08 10:56:03 --> Database Driver Class Initialized
INFO - 2021-07-08 10:56:03 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:56:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:56:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:56:03 --> Encryption Class Initialized
INFO - 2021-07-08 10:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:56:03 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:56:03 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:56:03 --> Model "user_model" initialized
INFO - 2021-07-08 10:56:03 --> Model "role_model" initialized
INFO - 2021-07-08 10:56:03 --> Controller Class Initialized
INFO - 2021-07-08 10:56:03 --> Helper loaded: language_helper
INFO - 2021-07-08 10:56:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:56:03 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:56:03 --> Final output sent to browser
DEBUG - 2021-07-08 10:56:03 --> Total execution time: 0.0624
INFO - 2021-07-08 10:56:06 --> Config Class Initialized
INFO - 2021-07-08 10:56:06 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:56:06 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:56:06 --> Utf8 Class Initialized
INFO - 2021-07-08 10:56:06 --> URI Class Initialized
INFO - 2021-07-08 10:56:06 --> Router Class Initialized
INFO - 2021-07-08 10:56:06 --> Output Class Initialized
INFO - 2021-07-08 10:56:06 --> Security Class Initialized
DEBUG - 2021-07-08 10:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:56:06 --> Input Class Initialized
INFO - 2021-07-08 10:56:06 --> Language Class Initialized
INFO - 2021-07-08 10:56:06 --> Loader Class Initialized
INFO - 2021-07-08 10:56:06 --> Helper loaded: html_helper
INFO - 2021-07-08 10:56:06 --> Helper loaded: url_helper
INFO - 2021-07-08 10:56:06 --> Helper loaded: form_helper
INFO - 2021-07-08 10:56:06 --> Database Driver Class Initialized
INFO - 2021-07-08 10:56:06 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:56:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:56:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:56:06 --> Encryption Class Initialized
INFO - 2021-07-08 10:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:56:06 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:56:06 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:56:06 --> Model "user_model" initialized
INFO - 2021-07-08 10:56:06 --> Model "role_model" initialized
INFO - 2021-07-08 10:56:06 --> Controller Class Initialized
INFO - 2021-07-08 10:56:06 --> Helper loaded: language_helper
INFO - 2021-07-08 10:56:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:56:06 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:56:06 --> Model "Product_model" initialized
INFO - 2021-07-08 10:56:06 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 10:56:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 10:56:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 10:56:06 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 10:56:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 10:56:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 10:56:06 --> Final output sent to browser
DEBUG - 2021-07-08 10:56:06 --> Total execution time: 0.0747
INFO - 2021-07-08 10:56:10 --> Config Class Initialized
INFO - 2021-07-08 10:56:10 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:56:10 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:56:10 --> Utf8 Class Initialized
INFO - 2021-07-08 10:56:10 --> URI Class Initialized
INFO - 2021-07-08 10:56:10 --> Router Class Initialized
INFO - 2021-07-08 10:56:10 --> Output Class Initialized
INFO - 2021-07-08 10:56:10 --> Security Class Initialized
DEBUG - 2021-07-08 10:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:56:10 --> Input Class Initialized
INFO - 2021-07-08 10:56:10 --> Language Class Initialized
INFO - 2021-07-08 10:56:10 --> Loader Class Initialized
INFO - 2021-07-08 10:56:10 --> Helper loaded: html_helper
INFO - 2021-07-08 10:56:10 --> Helper loaded: url_helper
INFO - 2021-07-08 10:56:10 --> Helper loaded: form_helper
INFO - 2021-07-08 10:56:10 --> Database Driver Class Initialized
INFO - 2021-07-08 10:56:10 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:56:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:56:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:56:10 --> Encryption Class Initialized
INFO - 2021-07-08 10:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:56:10 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:56:10 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:56:10 --> Model "user_model" initialized
INFO - 2021-07-08 10:56:10 --> Model "role_model" initialized
INFO - 2021-07-08 10:56:10 --> Controller Class Initialized
INFO - 2021-07-08 10:56:10 --> Helper loaded: language_helper
INFO - 2021-07-08 10:56:10 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:56:10 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:56:10 --> Final output sent to browser
DEBUG - 2021-07-08 10:56:10 --> Total execution time: 0.0635
INFO - 2021-07-08 10:56:52 --> Config Class Initialized
INFO - 2021-07-08 10:56:52 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:56:52 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:56:52 --> Utf8 Class Initialized
INFO - 2021-07-08 10:56:52 --> URI Class Initialized
INFO - 2021-07-08 10:56:52 --> Router Class Initialized
INFO - 2021-07-08 10:56:52 --> Output Class Initialized
INFO - 2021-07-08 10:56:52 --> Security Class Initialized
DEBUG - 2021-07-08 10:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:56:52 --> Input Class Initialized
INFO - 2021-07-08 10:56:52 --> Language Class Initialized
INFO - 2021-07-08 10:56:52 --> Loader Class Initialized
INFO - 2021-07-08 10:56:52 --> Helper loaded: html_helper
INFO - 2021-07-08 10:56:52 --> Helper loaded: url_helper
INFO - 2021-07-08 10:56:52 --> Helper loaded: form_helper
INFO - 2021-07-08 10:56:52 --> Database Driver Class Initialized
INFO - 2021-07-08 10:56:52 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:56:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:56:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:56:52 --> Encryption Class Initialized
INFO - 2021-07-08 10:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:56:52 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:56:52 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:56:52 --> Model "user_model" initialized
INFO - 2021-07-08 10:56:52 --> Model "role_model" initialized
INFO - 2021-07-08 10:56:52 --> Controller Class Initialized
INFO - 2021-07-08 10:56:52 --> Helper loaded: language_helper
INFO - 2021-07-08 10:56:52 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:56:52 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:56:52 --> Model "Product_model" initialized
INFO - 2021-07-08 10:56:52 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 10:56:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 10:56:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 10:56:53 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 10:56:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 10:56:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 10:56:53 --> Final output sent to browser
DEBUG - 2021-07-08 10:56:53 --> Total execution time: 0.1184
INFO - 2021-07-08 10:56:56 --> Config Class Initialized
INFO - 2021-07-08 10:56:56 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:56:56 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:56:56 --> Utf8 Class Initialized
INFO - 2021-07-08 10:56:56 --> URI Class Initialized
INFO - 2021-07-08 10:56:56 --> Router Class Initialized
INFO - 2021-07-08 10:56:56 --> Output Class Initialized
INFO - 2021-07-08 10:56:56 --> Security Class Initialized
DEBUG - 2021-07-08 10:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:56:56 --> Input Class Initialized
INFO - 2021-07-08 10:56:56 --> Language Class Initialized
INFO - 2021-07-08 10:56:56 --> Loader Class Initialized
INFO - 2021-07-08 10:56:56 --> Helper loaded: html_helper
INFO - 2021-07-08 10:56:56 --> Helper loaded: url_helper
INFO - 2021-07-08 10:56:56 --> Helper loaded: form_helper
INFO - 2021-07-08 10:56:56 --> Database Driver Class Initialized
INFO - 2021-07-08 10:56:56 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:56:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:56:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:56:56 --> Encryption Class Initialized
INFO - 2021-07-08 10:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:56:56 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:56:56 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:56:56 --> Model "user_model" initialized
INFO - 2021-07-08 10:56:56 --> Model "role_model" initialized
INFO - 2021-07-08 10:56:56 --> Controller Class Initialized
INFO - 2021-07-08 10:56:56 --> Helper loaded: language_helper
INFO - 2021-07-08 10:56:56 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:56:56 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:56:56 --> Final output sent to browser
DEBUG - 2021-07-08 10:56:56 --> Total execution time: 0.0615
INFO - 2021-07-08 10:57:39 --> Config Class Initialized
INFO - 2021-07-08 10:57:39 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:57:39 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:57:39 --> Utf8 Class Initialized
INFO - 2021-07-08 10:57:39 --> URI Class Initialized
INFO - 2021-07-08 10:57:39 --> Router Class Initialized
INFO - 2021-07-08 10:57:39 --> Output Class Initialized
INFO - 2021-07-08 10:57:39 --> Security Class Initialized
DEBUG - 2021-07-08 10:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:57:39 --> Input Class Initialized
INFO - 2021-07-08 10:57:39 --> Language Class Initialized
INFO - 2021-07-08 10:57:39 --> Loader Class Initialized
INFO - 2021-07-08 10:57:39 --> Helper loaded: html_helper
INFO - 2021-07-08 10:57:39 --> Helper loaded: url_helper
INFO - 2021-07-08 10:57:39 --> Helper loaded: form_helper
INFO - 2021-07-08 10:57:39 --> Database Driver Class Initialized
INFO - 2021-07-08 10:57:39 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:57:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:57:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:57:39 --> Encryption Class Initialized
INFO - 2021-07-08 10:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:57:39 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:57:39 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:57:39 --> Model "user_model" initialized
INFO - 2021-07-08 10:57:39 --> Model "role_model" initialized
INFO - 2021-07-08 10:57:39 --> Controller Class Initialized
INFO - 2021-07-08 10:57:39 --> Helper loaded: language_helper
INFO - 2021-07-08 10:57:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:57:39 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:57:39 --> Model "Product_model" initialized
INFO - 2021-07-08 10:57:39 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 10:57:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 10:57:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 10:57:39 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 10:57:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 10:57:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 10:57:39 --> Final output sent to browser
DEBUG - 2021-07-08 10:57:39 --> Total execution time: 0.1172
INFO - 2021-07-08 10:57:42 --> Config Class Initialized
INFO - 2021-07-08 10:57:42 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:57:42 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:57:42 --> Utf8 Class Initialized
INFO - 2021-07-08 10:57:42 --> URI Class Initialized
INFO - 2021-07-08 10:57:42 --> Router Class Initialized
INFO - 2021-07-08 10:57:42 --> Output Class Initialized
INFO - 2021-07-08 10:57:42 --> Security Class Initialized
DEBUG - 2021-07-08 10:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:57:42 --> Input Class Initialized
INFO - 2021-07-08 10:57:42 --> Language Class Initialized
INFO - 2021-07-08 10:57:42 --> Loader Class Initialized
INFO - 2021-07-08 10:57:42 --> Helper loaded: html_helper
INFO - 2021-07-08 10:57:42 --> Helper loaded: url_helper
INFO - 2021-07-08 10:57:42 --> Helper loaded: form_helper
INFO - 2021-07-08 10:57:42 --> Database Driver Class Initialized
INFO - 2021-07-08 10:57:42 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:57:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:57:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:57:42 --> Encryption Class Initialized
INFO - 2021-07-08 10:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:57:42 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:57:42 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:57:42 --> Model "user_model" initialized
INFO - 2021-07-08 10:57:42 --> Model "role_model" initialized
INFO - 2021-07-08 10:57:42 --> Controller Class Initialized
INFO - 2021-07-08 10:57:42 --> Helper loaded: language_helper
INFO - 2021-07-08 10:57:42 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:57:42 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:57:42 --> Final output sent to browser
DEBUG - 2021-07-08 10:57:42 --> Total execution time: 0.0649
INFO - 2021-07-08 10:58:38 --> Config Class Initialized
INFO - 2021-07-08 10:58:38 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:58:38 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:58:38 --> Utf8 Class Initialized
INFO - 2021-07-08 10:58:38 --> URI Class Initialized
INFO - 2021-07-08 10:58:38 --> Router Class Initialized
INFO - 2021-07-08 10:58:38 --> Output Class Initialized
INFO - 2021-07-08 10:58:38 --> Security Class Initialized
DEBUG - 2021-07-08 10:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:58:38 --> Input Class Initialized
INFO - 2021-07-08 10:58:38 --> Language Class Initialized
INFO - 2021-07-08 10:58:38 --> Loader Class Initialized
INFO - 2021-07-08 10:58:38 --> Helper loaded: html_helper
INFO - 2021-07-08 10:58:38 --> Helper loaded: url_helper
INFO - 2021-07-08 10:58:38 --> Helper loaded: form_helper
INFO - 2021-07-08 10:58:38 --> Database Driver Class Initialized
INFO - 2021-07-08 10:58:38 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:58:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:58:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:58:38 --> Encryption Class Initialized
INFO - 2021-07-08 10:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:58:38 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:58:38 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:58:38 --> Model "user_model" initialized
INFO - 2021-07-08 10:58:38 --> Model "role_model" initialized
INFO - 2021-07-08 10:58:38 --> Controller Class Initialized
INFO - 2021-07-08 10:58:38 --> Helper loaded: language_helper
INFO - 2021-07-08 10:58:38 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:58:38 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:58:38 --> Model "Product_model" initialized
INFO - 2021-07-08 10:58:38 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 10:58:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 10:58:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 10:58:38 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 10:58:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 10:58:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 10:58:38 --> Final output sent to browser
DEBUG - 2021-07-08 10:58:38 --> Total execution time: 0.1260
INFO - 2021-07-08 10:59:44 --> Config Class Initialized
INFO - 2021-07-08 10:59:44 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:59:44 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:59:44 --> Utf8 Class Initialized
INFO - 2021-07-08 10:59:44 --> URI Class Initialized
INFO - 2021-07-08 10:59:44 --> Router Class Initialized
INFO - 2021-07-08 10:59:44 --> Output Class Initialized
INFO - 2021-07-08 10:59:44 --> Security Class Initialized
DEBUG - 2021-07-08 10:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:59:44 --> Input Class Initialized
INFO - 2021-07-08 10:59:44 --> Language Class Initialized
INFO - 2021-07-08 10:59:44 --> Loader Class Initialized
INFO - 2021-07-08 10:59:44 --> Helper loaded: html_helper
INFO - 2021-07-08 10:59:44 --> Helper loaded: url_helper
INFO - 2021-07-08 10:59:44 --> Helper loaded: form_helper
INFO - 2021-07-08 10:59:44 --> Database Driver Class Initialized
INFO - 2021-07-08 10:59:44 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:59:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:59:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:59:44 --> Encryption Class Initialized
INFO - 2021-07-08 10:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:59:44 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:59:44 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:59:44 --> Model "user_model" initialized
INFO - 2021-07-08 10:59:44 --> Model "role_model" initialized
INFO - 2021-07-08 10:59:44 --> Controller Class Initialized
INFO - 2021-07-08 10:59:44 --> Helper loaded: language_helper
INFO - 2021-07-08 10:59:44 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:59:44 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:59:44 --> Model "Product_model" initialized
INFO - 2021-07-08 10:59:44 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 10:59:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 10:59:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 10:59:44 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 10:59:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 10:59:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 10:59:44 --> Final output sent to browser
DEBUG - 2021-07-08 10:59:44 --> Total execution time: 0.1136
INFO - 2021-07-08 10:59:47 --> Config Class Initialized
INFO - 2021-07-08 10:59:47 --> Hooks Class Initialized
DEBUG - 2021-07-08 10:59:47 --> UTF-8 Support Enabled
INFO - 2021-07-08 10:59:47 --> Utf8 Class Initialized
INFO - 2021-07-08 10:59:47 --> URI Class Initialized
INFO - 2021-07-08 10:59:47 --> Router Class Initialized
INFO - 2021-07-08 10:59:47 --> Output Class Initialized
INFO - 2021-07-08 10:59:47 --> Security Class Initialized
DEBUG - 2021-07-08 10:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 10:59:47 --> Input Class Initialized
INFO - 2021-07-08 10:59:47 --> Language Class Initialized
INFO - 2021-07-08 10:59:47 --> Loader Class Initialized
INFO - 2021-07-08 10:59:47 --> Helper loaded: html_helper
INFO - 2021-07-08 10:59:47 --> Helper loaded: url_helper
INFO - 2021-07-08 10:59:47 --> Helper loaded: form_helper
INFO - 2021-07-08 10:59:47 --> Database Driver Class Initialized
INFO - 2021-07-08 10:59:47 --> Form Validation Class Initialized
DEBUG - 2021-07-08 10:59:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 10:59:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 10:59:47 --> Encryption Class Initialized
INFO - 2021-07-08 10:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 10:59:47 --> Model "vendor_model" initialized
INFO - 2021-07-08 10:59:47 --> Model "coupon_model" initialized
INFO - 2021-07-08 10:59:47 --> Model "user_model" initialized
INFO - 2021-07-08 10:59:47 --> Model "role_model" initialized
INFO - 2021-07-08 10:59:47 --> Controller Class Initialized
INFO - 2021-07-08 10:59:47 --> Helper loaded: language_helper
INFO - 2021-07-08 10:59:47 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 10:59:47 --> Model "Customer_model" initialized
INFO - 2021-07-08 10:59:47 --> Final output sent to browser
DEBUG - 2021-07-08 10:59:47 --> Total execution time: 0.0629
INFO - 2021-07-08 11:00:00 --> Config Class Initialized
INFO - 2021-07-08 11:00:00 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:00:00 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:00:00 --> Utf8 Class Initialized
INFO - 2021-07-08 11:00:00 --> URI Class Initialized
INFO - 2021-07-08 11:00:00 --> Router Class Initialized
INFO - 2021-07-08 11:00:00 --> Output Class Initialized
INFO - 2021-07-08 11:00:00 --> Security Class Initialized
DEBUG - 2021-07-08 11:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:00:00 --> Input Class Initialized
INFO - 2021-07-08 11:00:00 --> Language Class Initialized
INFO - 2021-07-08 11:00:00 --> Loader Class Initialized
INFO - 2021-07-08 11:00:00 --> Helper loaded: html_helper
INFO - 2021-07-08 11:00:00 --> Helper loaded: url_helper
INFO - 2021-07-08 11:00:00 --> Helper loaded: form_helper
INFO - 2021-07-08 11:00:00 --> Database Driver Class Initialized
INFO - 2021-07-08 11:00:00 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:00:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:00:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:00:00 --> Encryption Class Initialized
INFO - 2021-07-08 11:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:00:00 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:00:00 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:00:00 --> Model "user_model" initialized
INFO - 2021-07-08 11:00:00 --> Model "role_model" initialized
INFO - 2021-07-08 11:00:00 --> Controller Class Initialized
INFO - 2021-07-08 11:00:00 --> Helper loaded: language_helper
INFO - 2021-07-08 11:00:00 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:00:00 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:00:00 --> Final output sent to browser
DEBUG - 2021-07-08 11:00:00 --> Total execution time: 0.0534
INFO - 2021-07-08 11:07:15 --> Config Class Initialized
INFO - 2021-07-08 11:07:15 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:07:15 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:07:15 --> Utf8 Class Initialized
INFO - 2021-07-08 11:07:15 --> URI Class Initialized
INFO - 2021-07-08 11:07:15 --> Router Class Initialized
INFO - 2021-07-08 11:07:15 --> Output Class Initialized
INFO - 2021-07-08 11:07:15 --> Security Class Initialized
DEBUG - 2021-07-08 11:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:07:15 --> Input Class Initialized
INFO - 2021-07-08 11:07:15 --> Language Class Initialized
INFO - 2021-07-08 11:07:15 --> Loader Class Initialized
INFO - 2021-07-08 11:07:15 --> Helper loaded: html_helper
INFO - 2021-07-08 11:07:15 --> Helper loaded: url_helper
INFO - 2021-07-08 11:07:15 --> Helper loaded: form_helper
INFO - 2021-07-08 11:07:15 --> Database Driver Class Initialized
INFO - 2021-07-08 11:07:15 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:07:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:07:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:07:15 --> Encryption Class Initialized
INFO - 2021-07-08 11:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:07:15 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:07:15 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:07:15 --> Model "user_model" initialized
INFO - 2021-07-08 11:07:15 --> Model "role_model" initialized
INFO - 2021-07-08 11:07:15 --> Controller Class Initialized
INFO - 2021-07-08 11:07:15 --> Helper loaded: language_helper
INFO - 2021-07-08 11:07:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:07:15 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:07:15 --> Model "Product_model" initialized
INFO - 2021-07-08 11:07:15 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:07:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:07:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:07:15 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:07:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:07:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:07:15 --> Final output sent to browser
DEBUG - 2021-07-08 11:07:15 --> Total execution time: 0.1232
INFO - 2021-07-08 11:07:18 --> Config Class Initialized
INFO - 2021-07-08 11:07:18 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:07:18 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:07:18 --> Utf8 Class Initialized
INFO - 2021-07-08 11:07:18 --> URI Class Initialized
INFO - 2021-07-08 11:07:18 --> Router Class Initialized
INFO - 2021-07-08 11:07:18 --> Output Class Initialized
INFO - 2021-07-08 11:07:18 --> Security Class Initialized
DEBUG - 2021-07-08 11:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:07:18 --> Input Class Initialized
INFO - 2021-07-08 11:07:18 --> Language Class Initialized
INFO - 2021-07-08 11:07:18 --> Loader Class Initialized
INFO - 2021-07-08 11:07:18 --> Helper loaded: html_helper
INFO - 2021-07-08 11:07:18 --> Helper loaded: url_helper
INFO - 2021-07-08 11:07:18 --> Helper loaded: form_helper
INFO - 2021-07-08 11:07:18 --> Database Driver Class Initialized
INFO - 2021-07-08 11:07:18 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:07:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:07:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:07:18 --> Encryption Class Initialized
INFO - 2021-07-08 11:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:07:18 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:07:18 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:07:18 --> Model "user_model" initialized
INFO - 2021-07-08 11:07:18 --> Model "role_model" initialized
INFO - 2021-07-08 11:07:18 --> Controller Class Initialized
INFO - 2021-07-08 11:07:18 --> Helper loaded: language_helper
INFO - 2021-07-08 11:07:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:07:18 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:07:18 --> Final output sent to browser
DEBUG - 2021-07-08 11:07:18 --> Total execution time: 0.0862
INFO - 2021-07-08 11:07:36 --> Config Class Initialized
INFO - 2021-07-08 11:07:36 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:07:36 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:07:36 --> Utf8 Class Initialized
INFO - 2021-07-08 11:07:36 --> URI Class Initialized
INFO - 2021-07-08 11:07:36 --> Router Class Initialized
INFO - 2021-07-08 11:07:36 --> Output Class Initialized
INFO - 2021-07-08 11:07:36 --> Security Class Initialized
DEBUG - 2021-07-08 11:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:07:36 --> Input Class Initialized
INFO - 2021-07-08 11:07:36 --> Language Class Initialized
INFO - 2021-07-08 11:07:36 --> Loader Class Initialized
INFO - 2021-07-08 11:07:36 --> Helper loaded: html_helper
INFO - 2021-07-08 11:07:36 --> Helper loaded: url_helper
INFO - 2021-07-08 11:07:36 --> Helper loaded: form_helper
INFO - 2021-07-08 11:07:36 --> Database Driver Class Initialized
INFO - 2021-07-08 11:07:36 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:07:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:07:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:07:36 --> Encryption Class Initialized
INFO - 2021-07-08 11:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:07:36 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:07:36 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:07:36 --> Model "user_model" initialized
INFO - 2021-07-08 11:07:36 --> Model "role_model" initialized
INFO - 2021-07-08 11:07:36 --> Controller Class Initialized
INFO - 2021-07-08 11:07:36 --> Helper loaded: language_helper
INFO - 2021-07-08 11:07:36 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:07:36 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:07:36 --> Model "Product_model" initialized
INFO - 2021-07-08 11:07:36 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:07:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:07:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:07:36 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:07:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:07:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:07:36 --> Final output sent to browser
DEBUG - 2021-07-08 11:07:36 --> Total execution time: 0.1065
INFO - 2021-07-08 11:07:38 --> Config Class Initialized
INFO - 2021-07-08 11:07:38 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:07:38 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:07:38 --> Utf8 Class Initialized
INFO - 2021-07-08 11:07:38 --> URI Class Initialized
INFO - 2021-07-08 11:07:38 --> Router Class Initialized
INFO - 2021-07-08 11:07:38 --> Output Class Initialized
INFO - 2021-07-08 11:07:38 --> Security Class Initialized
DEBUG - 2021-07-08 11:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:07:38 --> Input Class Initialized
INFO - 2021-07-08 11:07:38 --> Language Class Initialized
INFO - 2021-07-08 11:07:38 --> Loader Class Initialized
INFO - 2021-07-08 11:07:38 --> Helper loaded: html_helper
INFO - 2021-07-08 11:07:38 --> Helper loaded: url_helper
INFO - 2021-07-08 11:07:38 --> Helper loaded: form_helper
INFO - 2021-07-08 11:07:38 --> Database Driver Class Initialized
INFO - 2021-07-08 11:07:38 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:07:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:07:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:07:38 --> Encryption Class Initialized
INFO - 2021-07-08 11:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:07:38 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:07:38 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:07:38 --> Model "user_model" initialized
INFO - 2021-07-08 11:07:38 --> Model "role_model" initialized
INFO - 2021-07-08 11:07:38 --> Controller Class Initialized
INFO - 2021-07-08 11:07:38 --> Helper loaded: language_helper
INFO - 2021-07-08 11:07:38 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:07:38 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:07:38 --> Final output sent to browser
DEBUG - 2021-07-08 11:07:38 --> Total execution time: 0.0600
INFO - 2021-07-08 11:08:05 --> Config Class Initialized
INFO - 2021-07-08 11:08:05 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:08:05 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:08:05 --> Utf8 Class Initialized
INFO - 2021-07-08 11:08:05 --> URI Class Initialized
INFO - 2021-07-08 11:08:05 --> Router Class Initialized
INFO - 2021-07-08 11:08:05 --> Output Class Initialized
INFO - 2021-07-08 11:08:05 --> Security Class Initialized
DEBUG - 2021-07-08 11:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:08:05 --> Input Class Initialized
INFO - 2021-07-08 11:08:05 --> Language Class Initialized
INFO - 2021-07-08 11:08:05 --> Loader Class Initialized
INFO - 2021-07-08 11:08:05 --> Helper loaded: html_helper
INFO - 2021-07-08 11:08:05 --> Helper loaded: url_helper
INFO - 2021-07-08 11:08:05 --> Helper loaded: form_helper
INFO - 2021-07-08 11:08:05 --> Database Driver Class Initialized
INFO - 2021-07-08 11:08:05 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:08:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:08:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:08:05 --> Encryption Class Initialized
INFO - 2021-07-08 11:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:08:05 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:08:05 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:08:05 --> Model "user_model" initialized
INFO - 2021-07-08 11:08:05 --> Model "role_model" initialized
INFO - 2021-07-08 11:08:05 --> Controller Class Initialized
INFO - 2021-07-08 11:08:05 --> Helper loaded: language_helper
INFO - 2021-07-08 11:08:05 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:08:05 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:08:05 --> Model "Product_model" initialized
INFO - 2021-07-08 11:08:05 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:08:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:08:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:08:05 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:08:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:08:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:08:05 --> Final output sent to browser
DEBUG - 2021-07-08 11:08:05 --> Total execution time: 0.1273
INFO - 2021-07-08 11:08:07 --> Config Class Initialized
INFO - 2021-07-08 11:08:07 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:08:07 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:08:07 --> Utf8 Class Initialized
INFO - 2021-07-08 11:08:07 --> URI Class Initialized
INFO - 2021-07-08 11:08:07 --> Router Class Initialized
INFO - 2021-07-08 11:08:07 --> Output Class Initialized
INFO - 2021-07-08 11:08:07 --> Security Class Initialized
DEBUG - 2021-07-08 11:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:08:07 --> Input Class Initialized
INFO - 2021-07-08 11:08:07 --> Language Class Initialized
INFO - 2021-07-08 11:08:07 --> Loader Class Initialized
INFO - 2021-07-08 11:08:07 --> Helper loaded: html_helper
INFO - 2021-07-08 11:08:07 --> Helper loaded: url_helper
INFO - 2021-07-08 11:08:07 --> Helper loaded: form_helper
INFO - 2021-07-08 11:08:07 --> Database Driver Class Initialized
INFO - 2021-07-08 11:08:07 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:08:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:08:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:08:07 --> Encryption Class Initialized
INFO - 2021-07-08 11:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:08:07 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:08:07 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:08:07 --> Model "user_model" initialized
INFO - 2021-07-08 11:08:07 --> Model "role_model" initialized
INFO - 2021-07-08 11:08:07 --> Controller Class Initialized
INFO - 2021-07-08 11:08:07 --> Helper loaded: language_helper
INFO - 2021-07-08 11:08:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:08:07 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:08:07 --> Final output sent to browser
DEBUG - 2021-07-08 11:08:07 --> Total execution time: 0.0626
INFO - 2021-07-08 11:08:28 --> Config Class Initialized
INFO - 2021-07-08 11:08:28 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:08:28 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:08:28 --> Utf8 Class Initialized
INFO - 2021-07-08 11:08:28 --> URI Class Initialized
INFO - 2021-07-08 11:08:28 --> Router Class Initialized
INFO - 2021-07-08 11:08:28 --> Output Class Initialized
INFO - 2021-07-08 11:08:28 --> Security Class Initialized
DEBUG - 2021-07-08 11:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:08:28 --> Input Class Initialized
INFO - 2021-07-08 11:08:28 --> Language Class Initialized
INFO - 2021-07-08 11:08:28 --> Loader Class Initialized
INFO - 2021-07-08 11:08:28 --> Helper loaded: html_helper
INFO - 2021-07-08 11:08:28 --> Helper loaded: url_helper
INFO - 2021-07-08 11:08:28 --> Helper loaded: form_helper
INFO - 2021-07-08 11:08:28 --> Database Driver Class Initialized
INFO - 2021-07-08 11:08:28 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:08:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:08:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:08:28 --> Encryption Class Initialized
INFO - 2021-07-08 11:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:08:28 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:08:28 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:08:28 --> Model "user_model" initialized
INFO - 2021-07-08 11:08:28 --> Model "role_model" initialized
INFO - 2021-07-08 11:08:28 --> Controller Class Initialized
INFO - 2021-07-08 11:08:28 --> Helper loaded: language_helper
INFO - 2021-07-08 11:08:28 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:08:28 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:08:28 --> Model "Product_model" initialized
INFO - 2021-07-08 11:08:28 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:08:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:08:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:08:28 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
ERROR - 2021-07-08 11:08:28 --> Severity: error --> Exception: Object of class CI_DB_sqlsrv_result could not be converted to string D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 581
INFO - 2021-07-08 11:08:34 --> Config Class Initialized
INFO - 2021-07-08 11:08:34 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:08:34 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:08:34 --> Utf8 Class Initialized
INFO - 2021-07-08 11:08:34 --> URI Class Initialized
INFO - 2021-07-08 11:08:34 --> Router Class Initialized
INFO - 2021-07-08 11:08:34 --> Output Class Initialized
INFO - 2021-07-08 11:08:34 --> Security Class Initialized
DEBUG - 2021-07-08 11:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:08:34 --> Input Class Initialized
INFO - 2021-07-08 11:08:34 --> Language Class Initialized
INFO - 2021-07-08 11:08:34 --> Loader Class Initialized
INFO - 2021-07-08 11:08:34 --> Helper loaded: html_helper
INFO - 2021-07-08 11:08:34 --> Helper loaded: url_helper
INFO - 2021-07-08 11:08:34 --> Helper loaded: form_helper
INFO - 2021-07-08 11:08:34 --> Database Driver Class Initialized
INFO - 2021-07-08 11:08:34 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:08:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:08:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:08:34 --> Encryption Class Initialized
INFO - 2021-07-08 11:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:08:34 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:08:34 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:08:34 --> Model "user_model" initialized
INFO - 2021-07-08 11:08:34 --> Model "role_model" initialized
INFO - 2021-07-08 11:08:34 --> Controller Class Initialized
INFO - 2021-07-08 11:08:34 --> Helper loaded: language_helper
INFO - 2021-07-08 11:08:34 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:08:34 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:08:34 --> Model "Product_model" initialized
INFO - 2021-07-08 11:08:34 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:08:34 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:08:34 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:08:34 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
ERROR - 2021-07-08 11:08:34 --> Severity: error --> Exception: Object of class CI_DB_sqlsrv_result could not be converted to string D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 581
INFO - 2021-07-08 11:08:57 --> Config Class Initialized
INFO - 2021-07-08 11:08:57 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:08:57 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:08:57 --> Utf8 Class Initialized
INFO - 2021-07-08 11:08:57 --> URI Class Initialized
INFO - 2021-07-08 11:08:57 --> Router Class Initialized
INFO - 2021-07-08 11:08:57 --> Output Class Initialized
INFO - 2021-07-08 11:08:57 --> Security Class Initialized
DEBUG - 2021-07-08 11:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:08:57 --> Input Class Initialized
INFO - 2021-07-08 11:08:57 --> Language Class Initialized
INFO - 2021-07-08 11:08:57 --> Loader Class Initialized
INFO - 2021-07-08 11:08:57 --> Helper loaded: html_helper
INFO - 2021-07-08 11:08:57 --> Helper loaded: url_helper
INFO - 2021-07-08 11:08:57 --> Helper loaded: form_helper
INFO - 2021-07-08 11:08:57 --> Database Driver Class Initialized
INFO - 2021-07-08 11:08:57 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:08:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:08:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:08:57 --> Encryption Class Initialized
INFO - 2021-07-08 11:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:08:57 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:08:57 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:08:57 --> Model "user_model" initialized
INFO - 2021-07-08 11:08:57 --> Model "role_model" initialized
INFO - 2021-07-08 11:08:57 --> Controller Class Initialized
INFO - 2021-07-08 11:08:57 --> Helper loaded: language_helper
INFO - 2021-07-08 11:08:57 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:08:57 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:08:57 --> Model "Product_model" initialized
INFO - 2021-07-08 11:08:57 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:08:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:08:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:08:57 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
ERROR - 2021-07-08 11:08:57 --> Severity: error --> Exception: Object of class CI_DB_sqlsrv_result could not be converted to string D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 581
INFO - 2021-07-08 11:09:12 --> Config Class Initialized
INFO - 2021-07-08 11:09:12 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:09:12 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:09:12 --> Utf8 Class Initialized
INFO - 2021-07-08 11:09:12 --> URI Class Initialized
INFO - 2021-07-08 11:09:12 --> Router Class Initialized
INFO - 2021-07-08 11:09:12 --> Output Class Initialized
INFO - 2021-07-08 11:09:12 --> Security Class Initialized
DEBUG - 2021-07-08 11:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:09:12 --> Input Class Initialized
INFO - 2021-07-08 11:09:12 --> Language Class Initialized
INFO - 2021-07-08 11:09:12 --> Loader Class Initialized
INFO - 2021-07-08 11:09:12 --> Helper loaded: html_helper
INFO - 2021-07-08 11:09:12 --> Helper loaded: url_helper
INFO - 2021-07-08 11:09:12 --> Helper loaded: form_helper
INFO - 2021-07-08 11:09:12 --> Database Driver Class Initialized
INFO - 2021-07-08 11:09:12 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:09:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:09:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:09:12 --> Encryption Class Initialized
INFO - 2021-07-08 11:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:09:12 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:09:12 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:09:12 --> Model "user_model" initialized
INFO - 2021-07-08 11:09:12 --> Model "role_model" initialized
INFO - 2021-07-08 11:09:12 --> Controller Class Initialized
INFO - 2021-07-08 11:09:12 --> Helper loaded: language_helper
INFO - 2021-07-08 11:09:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:09:12 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:09:12 --> Model "Product_model" initialized
INFO - 2021-07-08 11:09:12 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:09:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:09:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:09:12 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
ERROR - 2021-07-08 11:09:12 --> Severity: error --> Exception: Object of class CI_DB_sqlsrv_result could not be converted to string D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 581
INFO - 2021-07-08 11:09:15 --> Config Class Initialized
INFO - 2021-07-08 11:09:15 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:09:15 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:09:15 --> Utf8 Class Initialized
INFO - 2021-07-08 11:09:15 --> URI Class Initialized
INFO - 2021-07-08 11:09:15 --> Router Class Initialized
INFO - 2021-07-08 11:09:15 --> Output Class Initialized
INFO - 2021-07-08 11:09:15 --> Security Class Initialized
DEBUG - 2021-07-08 11:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:09:15 --> Input Class Initialized
INFO - 2021-07-08 11:09:15 --> Language Class Initialized
INFO - 2021-07-08 11:09:15 --> Loader Class Initialized
INFO - 2021-07-08 11:09:15 --> Helper loaded: html_helper
INFO - 2021-07-08 11:09:15 --> Helper loaded: url_helper
INFO - 2021-07-08 11:09:15 --> Helper loaded: form_helper
INFO - 2021-07-08 11:09:15 --> Database Driver Class Initialized
INFO - 2021-07-08 11:09:15 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:09:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:09:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:09:15 --> Encryption Class Initialized
INFO - 2021-07-08 11:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:09:15 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:09:15 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:09:15 --> Model "user_model" initialized
INFO - 2021-07-08 11:09:15 --> Model "role_model" initialized
INFO - 2021-07-08 11:09:15 --> Controller Class Initialized
INFO - 2021-07-08 11:09:15 --> Helper loaded: language_helper
INFO - 2021-07-08 11:09:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:09:15 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:09:15 --> Model "Product_model" initialized
INFO - 2021-07-08 11:09:15 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:09:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:09:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:09:15 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
ERROR - 2021-07-08 11:09:15 --> Severity: error --> Exception: Object of class CI_DB_sqlsrv_result could not be converted to string D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 581
INFO - 2021-07-08 11:09:41 --> Config Class Initialized
INFO - 2021-07-08 11:09:41 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:09:41 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:09:41 --> Utf8 Class Initialized
INFO - 2021-07-08 11:09:41 --> URI Class Initialized
INFO - 2021-07-08 11:09:41 --> Router Class Initialized
INFO - 2021-07-08 11:09:41 --> Output Class Initialized
INFO - 2021-07-08 11:09:41 --> Security Class Initialized
DEBUG - 2021-07-08 11:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:09:41 --> Input Class Initialized
INFO - 2021-07-08 11:09:41 --> Language Class Initialized
INFO - 2021-07-08 11:09:41 --> Loader Class Initialized
INFO - 2021-07-08 11:09:41 --> Helper loaded: html_helper
INFO - 2021-07-08 11:09:41 --> Helper loaded: url_helper
INFO - 2021-07-08 11:09:41 --> Helper loaded: form_helper
INFO - 2021-07-08 11:09:41 --> Database Driver Class Initialized
INFO - 2021-07-08 11:09:41 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:09:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:09:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:09:41 --> Encryption Class Initialized
INFO - 2021-07-08 11:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:09:41 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:09:41 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:09:41 --> Model "user_model" initialized
INFO - 2021-07-08 11:09:41 --> Model "role_model" initialized
INFO - 2021-07-08 11:09:41 --> Controller Class Initialized
INFO - 2021-07-08 11:09:41 --> Helper loaded: language_helper
INFO - 2021-07-08 11:09:41 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:09:41 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:09:41 --> Model "Product_model" initialized
INFO - 2021-07-08 11:09:41 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:09:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:09:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:09:41 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:09:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:09:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:09:41 --> Final output sent to browser
DEBUG - 2021-07-08 11:09:41 --> Total execution time: 0.1140
INFO - 2021-07-08 11:10:24 --> Config Class Initialized
INFO - 2021-07-08 11:10:24 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:10:24 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:10:24 --> Utf8 Class Initialized
INFO - 2021-07-08 11:10:24 --> URI Class Initialized
INFO - 2021-07-08 11:10:24 --> Router Class Initialized
INFO - 2021-07-08 11:10:24 --> Output Class Initialized
INFO - 2021-07-08 11:10:24 --> Security Class Initialized
DEBUG - 2021-07-08 11:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:10:24 --> Input Class Initialized
INFO - 2021-07-08 11:10:24 --> Language Class Initialized
INFO - 2021-07-08 11:10:24 --> Loader Class Initialized
INFO - 2021-07-08 11:10:24 --> Helper loaded: html_helper
INFO - 2021-07-08 11:10:24 --> Helper loaded: url_helper
INFO - 2021-07-08 11:10:24 --> Helper loaded: form_helper
INFO - 2021-07-08 11:10:24 --> Database Driver Class Initialized
INFO - 2021-07-08 11:10:24 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:10:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:10:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:10:24 --> Encryption Class Initialized
INFO - 2021-07-08 11:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:10:24 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:10:24 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:10:24 --> Model "user_model" initialized
INFO - 2021-07-08 11:10:24 --> Model "role_model" initialized
INFO - 2021-07-08 11:10:24 --> Controller Class Initialized
INFO - 2021-07-08 11:10:24 --> Helper loaded: language_helper
INFO - 2021-07-08 11:10:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:10:24 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:10:24 --> Model "Product_model" initialized
INFO - 2021-07-08 11:10:24 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:10:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:10:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:10:24 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
ERROR - 2021-07-08 11:10:24 --> Severity: error --> Exception: Object of class CI_DB_sqlsrv_result could not be converted to string D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 581
INFO - 2021-07-08 11:10:51 --> Config Class Initialized
INFO - 2021-07-08 11:10:51 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:10:51 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:10:51 --> Utf8 Class Initialized
INFO - 2021-07-08 11:10:51 --> URI Class Initialized
INFO - 2021-07-08 11:10:51 --> Router Class Initialized
INFO - 2021-07-08 11:10:51 --> Output Class Initialized
INFO - 2021-07-08 11:10:51 --> Security Class Initialized
DEBUG - 2021-07-08 11:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:10:51 --> Input Class Initialized
INFO - 2021-07-08 11:10:51 --> Language Class Initialized
INFO - 2021-07-08 11:10:51 --> Loader Class Initialized
INFO - 2021-07-08 11:10:51 --> Helper loaded: html_helper
INFO - 2021-07-08 11:10:51 --> Helper loaded: url_helper
INFO - 2021-07-08 11:10:51 --> Helper loaded: form_helper
INFO - 2021-07-08 11:10:51 --> Database Driver Class Initialized
INFO - 2021-07-08 11:10:51 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:10:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:10:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:10:51 --> Encryption Class Initialized
INFO - 2021-07-08 11:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:10:51 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:10:51 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:10:51 --> Model "user_model" initialized
INFO - 2021-07-08 11:10:51 --> Model "role_model" initialized
INFO - 2021-07-08 11:10:51 --> Controller Class Initialized
INFO - 2021-07-08 11:10:51 --> Helper loaded: language_helper
INFO - 2021-07-08 11:10:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:10:51 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:10:51 --> Model "Product_model" initialized
INFO - 2021-07-08 11:10:51 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:10:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:10:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:10:51 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
ERROR - 2021-07-08 11:10:51 --> Severity: error --> Exception: Object of class CI_DB_sqlsrv_result could not be converted to string D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 581
INFO - 2021-07-08 11:10:54 --> Config Class Initialized
INFO - 2021-07-08 11:10:54 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:10:54 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:10:54 --> Utf8 Class Initialized
INFO - 2021-07-08 11:10:54 --> URI Class Initialized
INFO - 2021-07-08 11:10:54 --> Router Class Initialized
INFO - 2021-07-08 11:10:54 --> Output Class Initialized
INFO - 2021-07-08 11:10:54 --> Security Class Initialized
DEBUG - 2021-07-08 11:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:10:54 --> Input Class Initialized
INFO - 2021-07-08 11:10:54 --> Language Class Initialized
INFO - 2021-07-08 11:10:54 --> Loader Class Initialized
INFO - 2021-07-08 11:10:54 --> Helper loaded: html_helper
INFO - 2021-07-08 11:10:54 --> Helper loaded: url_helper
INFO - 2021-07-08 11:10:54 --> Helper loaded: form_helper
INFO - 2021-07-08 11:10:54 --> Database Driver Class Initialized
INFO - 2021-07-08 11:10:54 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:10:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:10:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:10:54 --> Encryption Class Initialized
INFO - 2021-07-08 11:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:10:54 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:10:54 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:10:54 --> Model "user_model" initialized
INFO - 2021-07-08 11:10:54 --> Model "role_model" initialized
INFO - 2021-07-08 11:10:54 --> Controller Class Initialized
INFO - 2021-07-08 11:10:54 --> Helper loaded: language_helper
INFO - 2021-07-08 11:10:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:10:54 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:10:54 --> Model "Product_model" initialized
INFO - 2021-07-08 11:10:54 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:10:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:10:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:10:54 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
ERROR - 2021-07-08 11:10:54 --> Severity: error --> Exception: Object of class CI_DB_sqlsrv_result could not be converted to string D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 581
INFO - 2021-07-08 11:10:59 --> Config Class Initialized
INFO - 2021-07-08 11:10:59 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:10:59 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:10:59 --> Utf8 Class Initialized
INFO - 2021-07-08 11:10:59 --> URI Class Initialized
INFO - 2021-07-08 11:10:59 --> Router Class Initialized
INFO - 2021-07-08 11:10:59 --> Output Class Initialized
INFO - 2021-07-08 11:10:59 --> Security Class Initialized
DEBUG - 2021-07-08 11:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:10:59 --> Input Class Initialized
INFO - 2021-07-08 11:10:59 --> Language Class Initialized
INFO - 2021-07-08 11:10:59 --> Loader Class Initialized
INFO - 2021-07-08 11:10:59 --> Helper loaded: html_helper
INFO - 2021-07-08 11:10:59 --> Helper loaded: url_helper
INFO - 2021-07-08 11:11:00 --> Helper loaded: form_helper
INFO - 2021-07-08 11:11:00 --> Database Driver Class Initialized
INFO - 2021-07-08 11:11:00 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:11:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:11:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:11:00 --> Encryption Class Initialized
INFO - 2021-07-08 11:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:11:00 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:11:00 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:11:00 --> Model "user_model" initialized
INFO - 2021-07-08 11:11:00 --> Model "role_model" initialized
INFO - 2021-07-08 11:11:00 --> Controller Class Initialized
INFO - 2021-07-08 11:11:00 --> Helper loaded: language_helper
INFO - 2021-07-08 11:11:00 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:11:00 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:11:00 --> Model "Product_model" initialized
INFO - 2021-07-08 11:11:00 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:11:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:11:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:11:00 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:11:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:11:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:11:00 --> Final output sent to browser
DEBUG - 2021-07-08 11:11:00 --> Total execution time: 0.1161
INFO - 2021-07-08 11:12:54 --> Config Class Initialized
INFO - 2021-07-08 11:12:54 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:12:54 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:12:54 --> Utf8 Class Initialized
INFO - 2021-07-08 11:12:54 --> URI Class Initialized
INFO - 2021-07-08 11:12:54 --> Router Class Initialized
INFO - 2021-07-08 11:12:54 --> Output Class Initialized
INFO - 2021-07-08 11:12:54 --> Security Class Initialized
DEBUG - 2021-07-08 11:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:12:54 --> Input Class Initialized
INFO - 2021-07-08 11:12:54 --> Language Class Initialized
INFO - 2021-07-08 11:12:54 --> Loader Class Initialized
INFO - 2021-07-08 11:12:54 --> Helper loaded: html_helper
INFO - 2021-07-08 11:12:54 --> Helper loaded: url_helper
INFO - 2021-07-08 11:12:54 --> Helper loaded: form_helper
INFO - 2021-07-08 11:12:54 --> Database Driver Class Initialized
INFO - 2021-07-08 11:12:54 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:12:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:12:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:12:54 --> Encryption Class Initialized
INFO - 2021-07-08 11:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:12:54 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:12:54 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:12:54 --> Model "user_model" initialized
INFO - 2021-07-08 11:12:54 --> Model "role_model" initialized
INFO - 2021-07-08 11:12:54 --> Controller Class Initialized
INFO - 2021-07-08 11:12:54 --> Helper loaded: language_helper
INFO - 2021-07-08 11:12:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:12:54 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:12:54 --> Model "Product_model" initialized
INFO - 2021-07-08 11:12:54 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:12:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:12:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:12:54 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:12:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:12:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:12:54 --> Final output sent to browser
DEBUG - 2021-07-08 11:12:54 --> Total execution time: 0.1182
INFO - 2021-07-08 11:13:08 --> Config Class Initialized
INFO - 2021-07-08 11:13:08 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:13:08 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:13:08 --> Utf8 Class Initialized
INFO - 2021-07-08 11:13:08 --> URI Class Initialized
INFO - 2021-07-08 11:13:08 --> Router Class Initialized
INFO - 2021-07-08 11:13:08 --> Output Class Initialized
INFO - 2021-07-08 11:13:08 --> Security Class Initialized
DEBUG - 2021-07-08 11:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:13:08 --> Input Class Initialized
INFO - 2021-07-08 11:13:08 --> Language Class Initialized
INFO - 2021-07-08 11:13:08 --> Loader Class Initialized
INFO - 2021-07-08 11:13:08 --> Helper loaded: html_helper
INFO - 2021-07-08 11:13:08 --> Helper loaded: url_helper
INFO - 2021-07-08 11:13:08 --> Helper loaded: form_helper
INFO - 2021-07-08 11:13:08 --> Database Driver Class Initialized
INFO - 2021-07-08 11:13:08 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:13:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:13:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:13:08 --> Encryption Class Initialized
INFO - 2021-07-08 11:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:13:08 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:13:08 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:13:08 --> Model "user_model" initialized
INFO - 2021-07-08 11:13:08 --> Model "role_model" initialized
INFO - 2021-07-08 11:13:08 --> Controller Class Initialized
INFO - 2021-07-08 11:13:08 --> Helper loaded: language_helper
INFO - 2021-07-08 11:13:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:13:08 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:13:08 --> Model "Product_model" initialized
INFO - 2021-07-08 11:13:08 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:13:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:13:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:13:08 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:13:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:13:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:13:08 --> Final output sent to browser
DEBUG - 2021-07-08 11:13:08 --> Total execution time: 0.1066
INFO - 2021-07-08 11:13:11 --> Config Class Initialized
INFO - 2021-07-08 11:13:11 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:13:11 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:13:11 --> Utf8 Class Initialized
INFO - 2021-07-08 11:13:11 --> URI Class Initialized
INFO - 2021-07-08 11:13:11 --> Router Class Initialized
INFO - 2021-07-08 11:13:11 --> Output Class Initialized
INFO - 2021-07-08 11:13:11 --> Security Class Initialized
DEBUG - 2021-07-08 11:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:13:11 --> Input Class Initialized
INFO - 2021-07-08 11:13:11 --> Language Class Initialized
INFO - 2021-07-08 11:13:11 --> Loader Class Initialized
INFO - 2021-07-08 11:13:11 --> Helper loaded: html_helper
INFO - 2021-07-08 11:13:11 --> Helper loaded: url_helper
INFO - 2021-07-08 11:13:11 --> Helper loaded: form_helper
INFO - 2021-07-08 11:13:11 --> Database Driver Class Initialized
INFO - 2021-07-08 11:13:11 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:13:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:13:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:13:11 --> Encryption Class Initialized
INFO - 2021-07-08 11:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:13:11 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:13:11 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:13:11 --> Model "user_model" initialized
INFO - 2021-07-08 11:13:11 --> Model "role_model" initialized
INFO - 2021-07-08 11:13:11 --> Controller Class Initialized
INFO - 2021-07-08 11:13:11 --> Helper loaded: language_helper
INFO - 2021-07-08 11:13:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:13:11 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:13:11 --> Final output sent to browser
DEBUG - 2021-07-08 11:13:11 --> Total execution time: 0.0584
INFO - 2021-07-08 11:13:24 --> Config Class Initialized
INFO - 2021-07-08 11:13:24 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:13:24 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:13:24 --> Utf8 Class Initialized
INFO - 2021-07-08 11:13:24 --> URI Class Initialized
INFO - 2021-07-08 11:13:24 --> Router Class Initialized
INFO - 2021-07-08 11:13:24 --> Output Class Initialized
INFO - 2021-07-08 11:13:24 --> Security Class Initialized
DEBUG - 2021-07-08 11:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:13:24 --> Input Class Initialized
INFO - 2021-07-08 11:13:24 --> Language Class Initialized
INFO - 2021-07-08 11:13:24 --> Loader Class Initialized
INFO - 2021-07-08 11:13:24 --> Helper loaded: html_helper
INFO - 2021-07-08 11:13:24 --> Helper loaded: url_helper
INFO - 2021-07-08 11:13:24 --> Helper loaded: form_helper
INFO - 2021-07-08 11:13:24 --> Database Driver Class Initialized
INFO - 2021-07-08 11:13:24 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:13:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:13:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:13:24 --> Encryption Class Initialized
INFO - 2021-07-08 11:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:13:24 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:13:24 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:13:24 --> Model "user_model" initialized
INFO - 2021-07-08 11:13:24 --> Model "role_model" initialized
INFO - 2021-07-08 11:13:24 --> Controller Class Initialized
INFO - 2021-07-08 11:13:24 --> Helper loaded: language_helper
INFO - 2021-07-08 11:13:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:13:24 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:13:24 --> Model "Product_model" initialized
INFO - 2021-07-08 11:13:24 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:13:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:13:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:13:24 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
ERROR - 2021-07-08 11:13:24 --> Severity: Notice --> Array to string conversion D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 581
INFO - 2021-07-08 11:13:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:13:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:13:24 --> Final output sent to browser
DEBUG - 2021-07-08 11:13:24 --> Total execution time: 0.1259
INFO - 2021-07-08 11:13:58 --> Config Class Initialized
INFO - 2021-07-08 11:13:58 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:13:58 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:13:58 --> Utf8 Class Initialized
INFO - 2021-07-08 11:13:58 --> URI Class Initialized
INFO - 2021-07-08 11:13:58 --> Router Class Initialized
INFO - 2021-07-08 11:13:58 --> Output Class Initialized
INFO - 2021-07-08 11:13:58 --> Security Class Initialized
DEBUG - 2021-07-08 11:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:13:58 --> Input Class Initialized
INFO - 2021-07-08 11:13:58 --> Language Class Initialized
INFO - 2021-07-08 11:13:58 --> Loader Class Initialized
INFO - 2021-07-08 11:13:58 --> Helper loaded: html_helper
INFO - 2021-07-08 11:13:58 --> Helper loaded: url_helper
INFO - 2021-07-08 11:13:58 --> Helper loaded: form_helper
INFO - 2021-07-08 11:13:58 --> Database Driver Class Initialized
INFO - 2021-07-08 11:13:58 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:13:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:13:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:13:58 --> Encryption Class Initialized
INFO - 2021-07-08 11:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:13:58 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:13:58 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:13:58 --> Model "user_model" initialized
INFO - 2021-07-08 11:13:58 --> Model "role_model" initialized
INFO - 2021-07-08 11:13:58 --> Controller Class Initialized
INFO - 2021-07-08 11:13:58 --> Helper loaded: language_helper
INFO - 2021-07-08 11:13:58 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:13:58 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:13:58 --> Model "Product_model" initialized
INFO - 2021-07-08 11:13:58 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:13:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:13:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:13:58 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
ERROR - 2021-07-08 11:13:58 --> Severity: Notice --> Array to string conversion D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 581
INFO - 2021-07-08 11:13:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:13:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:13:58 --> Final output sent to browser
DEBUG - 2021-07-08 11:13:58 --> Total execution time: 0.1165
INFO - 2021-07-08 11:14:30 --> Config Class Initialized
INFO - 2021-07-08 11:14:30 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:14:30 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:14:30 --> Utf8 Class Initialized
INFO - 2021-07-08 11:14:30 --> URI Class Initialized
INFO - 2021-07-08 11:14:30 --> Router Class Initialized
INFO - 2021-07-08 11:14:30 --> Output Class Initialized
INFO - 2021-07-08 11:14:30 --> Security Class Initialized
DEBUG - 2021-07-08 11:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:14:30 --> Input Class Initialized
INFO - 2021-07-08 11:14:30 --> Language Class Initialized
INFO - 2021-07-08 11:14:30 --> Loader Class Initialized
INFO - 2021-07-08 11:14:30 --> Helper loaded: html_helper
INFO - 2021-07-08 11:14:30 --> Helper loaded: url_helper
INFO - 2021-07-08 11:14:30 --> Helper loaded: form_helper
INFO - 2021-07-08 11:14:30 --> Database Driver Class Initialized
INFO - 2021-07-08 11:14:30 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:14:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:14:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:14:30 --> Encryption Class Initialized
INFO - 2021-07-08 11:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:14:30 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:14:30 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:14:30 --> Model "user_model" initialized
INFO - 2021-07-08 11:14:30 --> Model "role_model" initialized
INFO - 2021-07-08 11:14:30 --> Controller Class Initialized
INFO - 2021-07-08 11:14:30 --> Helper loaded: language_helper
INFO - 2021-07-08 11:14:30 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:14:30 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:14:30 --> Model "Product_model" initialized
INFO - 2021-07-08 11:14:30 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:14:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:14:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:14:30 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
ERROR - 2021-07-08 11:14:30 --> Severity: Notice --> Array to string conversion D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 581
INFO - 2021-07-08 11:14:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:14:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:14:30 --> Final output sent to browser
DEBUG - 2021-07-08 11:14:30 --> Total execution time: 0.1054
INFO - 2021-07-08 11:14:43 --> Config Class Initialized
INFO - 2021-07-08 11:14:43 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:14:43 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:14:43 --> Utf8 Class Initialized
INFO - 2021-07-08 11:14:43 --> URI Class Initialized
INFO - 2021-07-08 11:14:43 --> Router Class Initialized
INFO - 2021-07-08 11:14:43 --> Output Class Initialized
INFO - 2021-07-08 11:14:43 --> Security Class Initialized
DEBUG - 2021-07-08 11:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:14:43 --> Input Class Initialized
INFO - 2021-07-08 11:14:43 --> Language Class Initialized
INFO - 2021-07-08 11:14:43 --> Loader Class Initialized
INFO - 2021-07-08 11:14:43 --> Helper loaded: html_helper
INFO - 2021-07-08 11:14:43 --> Helper loaded: url_helper
INFO - 2021-07-08 11:14:43 --> Helper loaded: form_helper
INFO - 2021-07-08 11:14:43 --> Database Driver Class Initialized
INFO - 2021-07-08 11:14:43 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:14:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:14:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:14:43 --> Encryption Class Initialized
INFO - 2021-07-08 11:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:14:43 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:14:43 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:14:43 --> Model "user_model" initialized
INFO - 2021-07-08 11:14:43 --> Model "role_model" initialized
INFO - 2021-07-08 11:14:43 --> Controller Class Initialized
INFO - 2021-07-08 11:14:43 --> Helper loaded: language_helper
INFO - 2021-07-08 11:14:43 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:14:43 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:14:43 --> Model "Product_model" initialized
INFO - 2021-07-08 11:14:43 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:14:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:14:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:14:43 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:14:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:14:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:14:43 --> Final output sent to browser
DEBUG - 2021-07-08 11:14:43 --> Total execution time: 0.1065
INFO - 2021-07-08 11:14:47 --> Config Class Initialized
INFO - 2021-07-08 11:14:47 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:14:47 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:14:47 --> Utf8 Class Initialized
INFO - 2021-07-08 11:14:47 --> URI Class Initialized
INFO - 2021-07-08 11:14:47 --> Router Class Initialized
INFO - 2021-07-08 11:14:47 --> Output Class Initialized
INFO - 2021-07-08 11:14:47 --> Security Class Initialized
DEBUG - 2021-07-08 11:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:14:47 --> Input Class Initialized
INFO - 2021-07-08 11:14:47 --> Language Class Initialized
INFO - 2021-07-08 11:14:47 --> Loader Class Initialized
INFO - 2021-07-08 11:14:47 --> Helper loaded: html_helper
INFO - 2021-07-08 11:14:47 --> Helper loaded: url_helper
INFO - 2021-07-08 11:14:47 --> Helper loaded: form_helper
INFO - 2021-07-08 11:14:47 --> Database Driver Class Initialized
INFO - 2021-07-08 11:14:47 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:14:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:14:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:14:47 --> Encryption Class Initialized
INFO - 2021-07-08 11:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:14:47 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:14:47 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:14:47 --> Model "user_model" initialized
INFO - 2021-07-08 11:14:47 --> Model "role_model" initialized
INFO - 2021-07-08 11:14:47 --> Controller Class Initialized
INFO - 2021-07-08 11:14:47 --> Helper loaded: language_helper
INFO - 2021-07-08 11:14:47 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:14:47 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:14:47 --> Final output sent to browser
DEBUG - 2021-07-08 11:14:47 --> Total execution time: 0.0610
INFO - 2021-07-08 11:15:09 --> Config Class Initialized
INFO - 2021-07-08 11:15:09 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:15:09 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:15:09 --> Utf8 Class Initialized
INFO - 2021-07-08 11:15:09 --> URI Class Initialized
INFO - 2021-07-08 11:15:09 --> Router Class Initialized
INFO - 2021-07-08 11:15:09 --> Output Class Initialized
INFO - 2021-07-08 11:15:09 --> Security Class Initialized
DEBUG - 2021-07-08 11:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:15:09 --> Input Class Initialized
INFO - 2021-07-08 11:15:09 --> Language Class Initialized
INFO - 2021-07-08 11:15:09 --> Loader Class Initialized
INFO - 2021-07-08 11:15:09 --> Helper loaded: html_helper
INFO - 2021-07-08 11:15:09 --> Helper loaded: url_helper
INFO - 2021-07-08 11:15:09 --> Helper loaded: form_helper
INFO - 2021-07-08 11:15:09 --> Database Driver Class Initialized
INFO - 2021-07-08 11:15:09 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:15:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:15:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:15:09 --> Encryption Class Initialized
INFO - 2021-07-08 11:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:15:09 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:15:09 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:15:09 --> Model "user_model" initialized
INFO - 2021-07-08 11:15:09 --> Model "role_model" initialized
INFO - 2021-07-08 11:15:09 --> Controller Class Initialized
INFO - 2021-07-08 11:15:09 --> Helper loaded: language_helper
INFO - 2021-07-08 11:15:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:15:09 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:15:09 --> Model "Product_model" initialized
INFO - 2021-07-08 11:15:09 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:15:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:15:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:15:09 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:15:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:15:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:15:09 --> Final output sent to browser
DEBUG - 2021-07-08 11:15:09 --> Total execution time: 0.1244
INFO - 2021-07-08 11:15:17 --> Config Class Initialized
INFO - 2021-07-08 11:15:17 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:15:17 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:15:17 --> Utf8 Class Initialized
INFO - 2021-07-08 11:15:17 --> URI Class Initialized
INFO - 2021-07-08 11:15:17 --> Router Class Initialized
INFO - 2021-07-08 11:15:17 --> Output Class Initialized
INFO - 2021-07-08 11:15:17 --> Security Class Initialized
DEBUG - 2021-07-08 11:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:15:17 --> Input Class Initialized
INFO - 2021-07-08 11:15:17 --> Language Class Initialized
INFO - 2021-07-08 11:15:17 --> Loader Class Initialized
INFO - 2021-07-08 11:15:17 --> Helper loaded: html_helper
INFO - 2021-07-08 11:15:17 --> Helper loaded: url_helper
INFO - 2021-07-08 11:15:17 --> Helper loaded: form_helper
INFO - 2021-07-08 11:15:17 --> Database Driver Class Initialized
INFO - 2021-07-08 11:15:17 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:15:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:15:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:15:17 --> Encryption Class Initialized
INFO - 2021-07-08 11:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:15:17 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:15:17 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:15:17 --> Model "user_model" initialized
INFO - 2021-07-08 11:15:17 --> Model "role_model" initialized
INFO - 2021-07-08 11:15:17 --> Controller Class Initialized
INFO - 2021-07-08 11:15:17 --> Helper loaded: language_helper
INFO - 2021-07-08 11:15:17 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:15:17 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:15:17 --> Model "Product_model" initialized
INFO - 2021-07-08 11:15:17 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:15:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:15:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:15:17 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
ERROR - 2021-07-08 11:15:17 --> Severity: Notice --> Array to string conversion D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 581
INFO - 2021-07-08 11:15:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:15:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:15:17 --> Final output sent to browser
DEBUG - 2021-07-08 11:15:17 --> Total execution time: 0.1060
INFO - 2021-07-08 11:16:14 --> Config Class Initialized
INFO - 2021-07-08 11:16:14 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:16:14 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:16:14 --> Utf8 Class Initialized
INFO - 2021-07-08 11:16:14 --> URI Class Initialized
INFO - 2021-07-08 11:16:14 --> Router Class Initialized
INFO - 2021-07-08 11:16:14 --> Output Class Initialized
INFO - 2021-07-08 11:16:14 --> Security Class Initialized
DEBUG - 2021-07-08 11:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:16:14 --> Input Class Initialized
INFO - 2021-07-08 11:16:14 --> Language Class Initialized
INFO - 2021-07-08 11:16:14 --> Loader Class Initialized
INFO - 2021-07-08 11:16:14 --> Helper loaded: html_helper
INFO - 2021-07-08 11:16:14 --> Helper loaded: url_helper
INFO - 2021-07-08 11:16:14 --> Helper loaded: form_helper
INFO - 2021-07-08 11:16:14 --> Database Driver Class Initialized
INFO - 2021-07-08 11:16:14 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:16:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:16:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:16:14 --> Encryption Class Initialized
INFO - 2021-07-08 11:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:16:14 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:16:14 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:16:14 --> Model "user_model" initialized
INFO - 2021-07-08 11:16:14 --> Model "role_model" initialized
INFO - 2021-07-08 11:16:14 --> Controller Class Initialized
INFO - 2021-07-08 11:16:14 --> Helper loaded: language_helper
INFO - 2021-07-08 11:16:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:16:14 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:16:14 --> Model "Product_model" initialized
INFO - 2021-07-08 11:16:14 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:16:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:16:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:16:14 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
ERROR - 2021-07-08 11:16:14 --> Severity: error --> Exception: Object of class CI_DB_sqlsrv_result could not be converted to string D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 581
INFO - 2021-07-08 11:16:31 --> Config Class Initialized
INFO - 2021-07-08 11:16:31 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:16:31 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:16:31 --> Utf8 Class Initialized
INFO - 2021-07-08 11:16:31 --> URI Class Initialized
INFO - 2021-07-08 11:16:31 --> Router Class Initialized
INFO - 2021-07-08 11:16:31 --> Output Class Initialized
INFO - 2021-07-08 11:16:31 --> Security Class Initialized
DEBUG - 2021-07-08 11:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:16:31 --> Input Class Initialized
INFO - 2021-07-08 11:16:31 --> Language Class Initialized
INFO - 2021-07-08 11:16:31 --> Loader Class Initialized
INFO - 2021-07-08 11:16:31 --> Helper loaded: html_helper
INFO - 2021-07-08 11:16:31 --> Helper loaded: url_helper
INFO - 2021-07-08 11:16:31 --> Helper loaded: form_helper
INFO - 2021-07-08 11:16:31 --> Database Driver Class Initialized
INFO - 2021-07-08 11:16:31 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:16:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:16:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:16:31 --> Encryption Class Initialized
INFO - 2021-07-08 11:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:16:31 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:16:31 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:16:31 --> Model "user_model" initialized
INFO - 2021-07-08 11:16:31 --> Model "role_model" initialized
INFO - 2021-07-08 11:16:31 --> Controller Class Initialized
INFO - 2021-07-08 11:16:31 --> Helper loaded: language_helper
INFO - 2021-07-08 11:16:31 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:16:31 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:16:31 --> Model "Product_model" initialized
INFO - 2021-07-08 11:16:31 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:16:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:16:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:16:31 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
ERROR - 2021-07-08 11:16:31 --> Severity: Notice --> Array to string conversion D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 581
INFO - 2021-07-08 11:16:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:16:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:16:31 --> Final output sent to browser
DEBUG - 2021-07-08 11:16:31 --> Total execution time: 0.1160
INFO - 2021-07-08 11:17:15 --> Config Class Initialized
INFO - 2021-07-08 11:17:15 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:17:15 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:17:15 --> Utf8 Class Initialized
INFO - 2021-07-08 11:17:15 --> URI Class Initialized
INFO - 2021-07-08 11:17:15 --> Router Class Initialized
INFO - 2021-07-08 11:17:15 --> Output Class Initialized
INFO - 2021-07-08 11:17:15 --> Security Class Initialized
DEBUG - 2021-07-08 11:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:17:15 --> Input Class Initialized
INFO - 2021-07-08 11:17:15 --> Language Class Initialized
INFO - 2021-07-08 11:17:15 --> Loader Class Initialized
INFO - 2021-07-08 11:17:15 --> Helper loaded: html_helper
INFO - 2021-07-08 11:17:15 --> Helper loaded: url_helper
INFO - 2021-07-08 11:17:15 --> Helper loaded: form_helper
INFO - 2021-07-08 11:17:15 --> Database Driver Class Initialized
INFO - 2021-07-08 11:17:15 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:17:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:17:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:17:15 --> Encryption Class Initialized
INFO - 2021-07-08 11:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:17:15 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:17:15 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:17:15 --> Model "user_model" initialized
INFO - 2021-07-08 11:17:15 --> Model "role_model" initialized
INFO - 2021-07-08 11:17:15 --> Controller Class Initialized
INFO - 2021-07-08 11:17:15 --> Helper loaded: language_helper
INFO - 2021-07-08 11:17:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:17:15 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:17:15 --> Model "Product_model" initialized
INFO - 2021-07-08 11:17:15 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:17:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:17:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:17:15 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:17:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:17:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:17:15 --> Final output sent to browser
DEBUG - 2021-07-08 11:17:15 --> Total execution time: 0.1146
INFO - 2021-07-08 11:17:19 --> Config Class Initialized
INFO - 2021-07-08 11:17:19 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:17:19 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:17:19 --> Utf8 Class Initialized
INFO - 2021-07-08 11:17:19 --> URI Class Initialized
INFO - 2021-07-08 11:17:19 --> Router Class Initialized
INFO - 2021-07-08 11:17:19 --> Output Class Initialized
INFO - 2021-07-08 11:17:19 --> Security Class Initialized
DEBUG - 2021-07-08 11:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:17:19 --> Input Class Initialized
INFO - 2021-07-08 11:17:19 --> Language Class Initialized
INFO - 2021-07-08 11:17:19 --> Loader Class Initialized
INFO - 2021-07-08 11:17:19 --> Helper loaded: html_helper
INFO - 2021-07-08 11:17:19 --> Helper loaded: url_helper
INFO - 2021-07-08 11:17:19 --> Helper loaded: form_helper
INFO - 2021-07-08 11:17:19 --> Database Driver Class Initialized
INFO - 2021-07-08 11:17:19 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:17:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:17:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:17:19 --> Encryption Class Initialized
INFO - 2021-07-08 11:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:17:19 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:17:19 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:17:19 --> Model "user_model" initialized
INFO - 2021-07-08 11:17:19 --> Model "role_model" initialized
INFO - 2021-07-08 11:17:19 --> Controller Class Initialized
INFO - 2021-07-08 11:17:19 --> Helper loaded: language_helper
INFO - 2021-07-08 11:17:19 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:17:19 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:17:19 --> Final output sent to browser
DEBUG - 2021-07-08 11:17:19 --> Total execution time: 0.0606
INFO - 2021-07-08 11:20:42 --> Config Class Initialized
INFO - 2021-07-08 11:20:42 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:20:42 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:20:42 --> Utf8 Class Initialized
INFO - 2021-07-08 11:20:42 --> URI Class Initialized
INFO - 2021-07-08 11:20:42 --> Router Class Initialized
INFO - 2021-07-08 11:20:42 --> Output Class Initialized
INFO - 2021-07-08 11:20:42 --> Security Class Initialized
DEBUG - 2021-07-08 11:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:20:42 --> Input Class Initialized
INFO - 2021-07-08 11:20:42 --> Language Class Initialized
INFO - 2021-07-08 11:20:42 --> Loader Class Initialized
INFO - 2021-07-08 11:20:42 --> Helper loaded: html_helper
INFO - 2021-07-08 11:20:42 --> Helper loaded: url_helper
INFO - 2021-07-08 11:20:42 --> Helper loaded: form_helper
INFO - 2021-07-08 11:20:42 --> Database Driver Class Initialized
INFO - 2021-07-08 11:20:42 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:20:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:20:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:20:42 --> Encryption Class Initialized
INFO - 2021-07-08 11:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:20:42 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:20:42 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:20:42 --> Model "user_model" initialized
INFO - 2021-07-08 11:20:42 --> Model "role_model" initialized
INFO - 2021-07-08 11:20:42 --> Controller Class Initialized
INFO - 2021-07-08 11:20:42 --> Helper loaded: language_helper
INFO - 2021-07-08 11:20:42 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:20:42 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:20:42 --> Model "Product_model" initialized
INFO - 2021-07-08 11:20:42 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:20:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:20:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:20:42 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:20:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:20:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:20:42 --> Final output sent to browser
DEBUG - 2021-07-08 11:20:42 --> Total execution time: 0.1154
INFO - 2021-07-08 11:20:47 --> Config Class Initialized
INFO - 2021-07-08 11:20:47 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:20:47 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:20:47 --> Utf8 Class Initialized
INFO - 2021-07-08 11:20:47 --> URI Class Initialized
INFO - 2021-07-08 11:20:47 --> Router Class Initialized
INFO - 2021-07-08 11:20:47 --> Output Class Initialized
INFO - 2021-07-08 11:20:47 --> Security Class Initialized
DEBUG - 2021-07-08 11:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:20:47 --> Input Class Initialized
INFO - 2021-07-08 11:20:47 --> Language Class Initialized
INFO - 2021-07-08 11:20:47 --> Loader Class Initialized
INFO - 2021-07-08 11:20:47 --> Helper loaded: html_helper
INFO - 2021-07-08 11:20:47 --> Helper loaded: url_helper
INFO - 2021-07-08 11:20:47 --> Helper loaded: form_helper
INFO - 2021-07-08 11:20:47 --> Database Driver Class Initialized
INFO - 2021-07-08 11:20:47 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:20:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:20:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:20:47 --> Encryption Class Initialized
INFO - 2021-07-08 11:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:20:47 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:20:47 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:20:47 --> Model "user_model" initialized
INFO - 2021-07-08 11:20:47 --> Model "role_model" initialized
INFO - 2021-07-08 11:20:47 --> Controller Class Initialized
INFO - 2021-07-08 11:20:47 --> Helper loaded: language_helper
INFO - 2021-07-08 11:20:47 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:20:47 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:20:47 --> Final output sent to browser
DEBUG - 2021-07-08 11:20:47 --> Total execution time: 0.0526
INFO - 2021-07-08 11:21:04 --> Config Class Initialized
INFO - 2021-07-08 11:21:04 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:21:04 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:21:04 --> Utf8 Class Initialized
INFO - 2021-07-08 11:21:04 --> URI Class Initialized
INFO - 2021-07-08 11:21:04 --> Router Class Initialized
INFO - 2021-07-08 11:21:04 --> Output Class Initialized
INFO - 2021-07-08 11:21:04 --> Security Class Initialized
DEBUG - 2021-07-08 11:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:21:04 --> Input Class Initialized
INFO - 2021-07-08 11:21:04 --> Language Class Initialized
INFO - 2021-07-08 11:21:04 --> Loader Class Initialized
INFO - 2021-07-08 11:21:04 --> Helper loaded: html_helper
INFO - 2021-07-08 11:21:04 --> Helper loaded: url_helper
INFO - 2021-07-08 11:21:04 --> Helper loaded: form_helper
INFO - 2021-07-08 11:21:04 --> Database Driver Class Initialized
INFO - 2021-07-08 11:21:04 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:21:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:21:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:21:04 --> Encryption Class Initialized
INFO - 2021-07-08 11:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:21:04 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:21:04 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:21:04 --> Model "user_model" initialized
INFO - 2021-07-08 11:21:04 --> Model "role_model" initialized
INFO - 2021-07-08 11:21:04 --> Controller Class Initialized
INFO - 2021-07-08 11:21:04 --> Helper loaded: language_helper
INFO - 2021-07-08 11:21:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:21:04 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:21:04 --> Model "Product_model" initialized
INFO - 2021-07-08 11:21:04 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:21:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:21:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:21:04 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:21:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:21:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:21:04 --> Final output sent to browser
DEBUG - 2021-07-08 11:21:04 --> Total execution time: 0.1076
INFO - 2021-07-08 11:21:07 --> Config Class Initialized
INFO - 2021-07-08 11:21:07 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:21:07 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:21:07 --> Utf8 Class Initialized
INFO - 2021-07-08 11:21:07 --> URI Class Initialized
INFO - 2021-07-08 11:21:07 --> Router Class Initialized
INFO - 2021-07-08 11:21:07 --> Output Class Initialized
INFO - 2021-07-08 11:21:07 --> Security Class Initialized
DEBUG - 2021-07-08 11:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:21:07 --> Input Class Initialized
INFO - 2021-07-08 11:21:07 --> Language Class Initialized
INFO - 2021-07-08 11:21:07 --> Loader Class Initialized
INFO - 2021-07-08 11:21:07 --> Helper loaded: html_helper
INFO - 2021-07-08 11:21:07 --> Helper loaded: url_helper
INFO - 2021-07-08 11:21:07 --> Helper loaded: form_helper
INFO - 2021-07-08 11:21:07 --> Database Driver Class Initialized
INFO - 2021-07-08 11:21:07 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:21:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:21:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:21:07 --> Encryption Class Initialized
INFO - 2021-07-08 11:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:21:07 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:21:07 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:21:07 --> Model "user_model" initialized
INFO - 2021-07-08 11:21:07 --> Model "role_model" initialized
INFO - 2021-07-08 11:21:07 --> Controller Class Initialized
INFO - 2021-07-08 11:21:07 --> Helper loaded: language_helper
INFO - 2021-07-08 11:21:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:21:07 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:21:07 --> Final output sent to browser
DEBUG - 2021-07-08 11:21:07 --> Total execution time: 0.0582
INFO - 2021-07-08 11:21:32 --> Config Class Initialized
INFO - 2021-07-08 11:21:32 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:21:32 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:21:32 --> Utf8 Class Initialized
INFO - 2021-07-08 11:21:32 --> URI Class Initialized
INFO - 2021-07-08 11:21:32 --> Router Class Initialized
INFO - 2021-07-08 11:21:32 --> Output Class Initialized
INFO - 2021-07-08 11:21:32 --> Security Class Initialized
DEBUG - 2021-07-08 11:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:21:32 --> Input Class Initialized
INFO - 2021-07-08 11:21:32 --> Language Class Initialized
INFO - 2021-07-08 11:21:32 --> Loader Class Initialized
INFO - 2021-07-08 11:21:32 --> Helper loaded: html_helper
INFO - 2021-07-08 11:21:32 --> Helper loaded: url_helper
INFO - 2021-07-08 11:21:32 --> Helper loaded: form_helper
INFO - 2021-07-08 11:21:32 --> Database Driver Class Initialized
INFO - 2021-07-08 11:21:32 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:21:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:21:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:21:32 --> Encryption Class Initialized
INFO - 2021-07-08 11:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:21:32 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:21:32 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:21:32 --> Model "user_model" initialized
INFO - 2021-07-08 11:21:32 --> Model "role_model" initialized
INFO - 2021-07-08 11:21:32 --> Controller Class Initialized
INFO - 2021-07-08 11:21:32 --> Helper loaded: language_helper
INFO - 2021-07-08 11:21:32 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:21:32 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:21:32 --> Model "Product_model" initialized
INFO - 2021-07-08 11:21:32 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:21:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:21:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:21:32 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:21:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:21:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:21:32 --> Final output sent to browser
DEBUG - 2021-07-08 11:21:32 --> Total execution time: 0.1175
INFO - 2021-07-08 11:21:35 --> Config Class Initialized
INFO - 2021-07-08 11:21:35 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:21:35 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:21:35 --> Utf8 Class Initialized
INFO - 2021-07-08 11:21:35 --> URI Class Initialized
INFO - 2021-07-08 11:21:35 --> Router Class Initialized
INFO - 2021-07-08 11:21:35 --> Output Class Initialized
INFO - 2021-07-08 11:21:35 --> Security Class Initialized
DEBUG - 2021-07-08 11:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:21:35 --> Input Class Initialized
INFO - 2021-07-08 11:21:35 --> Language Class Initialized
INFO - 2021-07-08 11:21:35 --> Loader Class Initialized
INFO - 2021-07-08 11:21:35 --> Helper loaded: html_helper
INFO - 2021-07-08 11:21:35 --> Helper loaded: url_helper
INFO - 2021-07-08 11:21:35 --> Helper loaded: form_helper
INFO - 2021-07-08 11:21:35 --> Database Driver Class Initialized
INFO - 2021-07-08 11:21:35 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:21:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:21:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:21:35 --> Encryption Class Initialized
INFO - 2021-07-08 11:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:21:35 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:21:35 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:21:35 --> Model "user_model" initialized
INFO - 2021-07-08 11:21:35 --> Model "role_model" initialized
INFO - 2021-07-08 11:21:35 --> Controller Class Initialized
INFO - 2021-07-08 11:21:35 --> Helper loaded: language_helper
INFO - 2021-07-08 11:21:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:21:35 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:21:35 --> Final output sent to browser
DEBUG - 2021-07-08 11:21:35 --> Total execution time: 0.0596
INFO - 2021-07-08 11:21:39 --> Config Class Initialized
INFO - 2021-07-08 11:21:39 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:21:39 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:21:39 --> Utf8 Class Initialized
INFO - 2021-07-08 11:21:39 --> URI Class Initialized
INFO - 2021-07-08 11:21:39 --> Router Class Initialized
INFO - 2021-07-08 11:21:39 --> Output Class Initialized
INFO - 2021-07-08 11:21:39 --> Security Class Initialized
DEBUG - 2021-07-08 11:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:21:39 --> Input Class Initialized
INFO - 2021-07-08 11:21:39 --> Language Class Initialized
INFO - 2021-07-08 11:21:39 --> Loader Class Initialized
INFO - 2021-07-08 11:21:39 --> Helper loaded: html_helper
INFO - 2021-07-08 11:21:39 --> Helper loaded: url_helper
INFO - 2021-07-08 11:21:39 --> Helper loaded: form_helper
INFO - 2021-07-08 11:21:39 --> Database Driver Class Initialized
INFO - 2021-07-08 11:21:39 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:21:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:21:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:21:39 --> Encryption Class Initialized
INFO - 2021-07-08 11:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:21:39 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:21:39 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:21:39 --> Model "user_model" initialized
INFO - 2021-07-08 11:21:39 --> Model "role_model" initialized
INFO - 2021-07-08 11:21:39 --> Controller Class Initialized
INFO - 2021-07-08 11:21:39 --> Helper loaded: language_helper
INFO - 2021-07-08 11:21:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:21:39 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:21:39 --> Final output sent to browser
DEBUG - 2021-07-08 11:21:39 --> Total execution time: 0.0617
INFO - 2021-07-08 11:21:41 --> Config Class Initialized
INFO - 2021-07-08 11:21:41 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:21:41 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:21:41 --> Utf8 Class Initialized
INFO - 2021-07-08 11:21:41 --> URI Class Initialized
INFO - 2021-07-08 11:21:41 --> Router Class Initialized
INFO - 2021-07-08 11:21:41 --> Output Class Initialized
INFO - 2021-07-08 11:21:41 --> Security Class Initialized
DEBUG - 2021-07-08 11:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:21:41 --> Input Class Initialized
INFO - 2021-07-08 11:21:41 --> Language Class Initialized
INFO - 2021-07-08 11:21:41 --> Loader Class Initialized
INFO - 2021-07-08 11:21:41 --> Helper loaded: html_helper
INFO - 2021-07-08 11:21:41 --> Helper loaded: url_helper
INFO - 2021-07-08 11:21:41 --> Helper loaded: form_helper
INFO - 2021-07-08 11:21:41 --> Database Driver Class Initialized
INFO - 2021-07-08 11:21:41 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:21:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:21:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:21:41 --> Encryption Class Initialized
INFO - 2021-07-08 11:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:21:41 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:21:41 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:21:41 --> Model "user_model" initialized
INFO - 2021-07-08 11:21:41 --> Model "role_model" initialized
INFO - 2021-07-08 11:21:41 --> Controller Class Initialized
INFO - 2021-07-08 11:21:41 --> Helper loaded: language_helper
INFO - 2021-07-08 11:21:41 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:21:41 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:21:41 --> Model "Product_model" initialized
INFO - 2021-07-08 11:21:41 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:21:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:21:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:21:41 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:21:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:21:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:21:41 --> Final output sent to browser
DEBUG - 2021-07-08 11:21:41 --> Total execution time: 0.0742
INFO - 2021-07-08 11:33:04 --> Config Class Initialized
INFO - 2021-07-08 11:33:04 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:33:04 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:33:04 --> Utf8 Class Initialized
INFO - 2021-07-08 11:33:04 --> URI Class Initialized
INFO - 2021-07-08 11:33:04 --> Router Class Initialized
INFO - 2021-07-08 11:33:04 --> Output Class Initialized
INFO - 2021-07-08 11:33:04 --> Security Class Initialized
DEBUG - 2021-07-08 11:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:33:04 --> Input Class Initialized
INFO - 2021-07-08 11:33:04 --> Language Class Initialized
INFO - 2021-07-08 11:33:04 --> Loader Class Initialized
INFO - 2021-07-08 11:33:04 --> Helper loaded: html_helper
INFO - 2021-07-08 11:33:04 --> Helper loaded: url_helper
INFO - 2021-07-08 11:33:04 --> Helper loaded: form_helper
INFO - 2021-07-08 11:33:04 --> Database Driver Class Initialized
INFO - 2021-07-08 11:33:04 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:33:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:33:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:33:04 --> Encryption Class Initialized
INFO - 2021-07-08 11:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:33:04 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:33:04 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:33:04 --> Model "user_model" initialized
INFO - 2021-07-08 11:33:04 --> Model "role_model" initialized
INFO - 2021-07-08 11:33:04 --> Controller Class Initialized
INFO - 2021-07-08 11:33:04 --> Helper loaded: language_helper
INFO - 2021-07-08 11:33:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:33:04 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:33:04 --> Model "Product_model" initialized
INFO - 2021-07-08 11:33:04 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:33:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:33:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:33:04 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:33:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:33:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:33:04 --> Final output sent to browser
DEBUG - 2021-07-08 11:33:04 --> Total execution time: 0.1499
INFO - 2021-07-08 11:33:08 --> Config Class Initialized
INFO - 2021-07-08 11:33:08 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:33:08 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:33:08 --> Utf8 Class Initialized
INFO - 2021-07-08 11:33:08 --> URI Class Initialized
INFO - 2021-07-08 11:33:08 --> Router Class Initialized
INFO - 2021-07-08 11:33:08 --> Output Class Initialized
INFO - 2021-07-08 11:33:08 --> Security Class Initialized
DEBUG - 2021-07-08 11:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:33:08 --> Input Class Initialized
INFO - 2021-07-08 11:33:08 --> Language Class Initialized
INFO - 2021-07-08 11:33:08 --> Loader Class Initialized
INFO - 2021-07-08 11:33:08 --> Helper loaded: html_helper
INFO - 2021-07-08 11:33:08 --> Helper loaded: url_helper
INFO - 2021-07-08 11:33:08 --> Helper loaded: form_helper
INFO - 2021-07-08 11:33:08 --> Database Driver Class Initialized
INFO - 2021-07-08 11:33:08 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:33:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:33:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:33:08 --> Encryption Class Initialized
INFO - 2021-07-08 11:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:33:08 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:33:08 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:33:08 --> Model "user_model" initialized
INFO - 2021-07-08 11:33:08 --> Model "role_model" initialized
INFO - 2021-07-08 11:33:08 --> Controller Class Initialized
INFO - 2021-07-08 11:33:08 --> Helper loaded: language_helper
INFO - 2021-07-08 11:33:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:33:08 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:33:08 --> Final output sent to browser
DEBUG - 2021-07-08 11:33:08 --> Total execution time: 0.0571
INFO - 2021-07-08 11:33:09 --> Config Class Initialized
INFO - 2021-07-08 11:33:09 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:33:09 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:33:09 --> Utf8 Class Initialized
INFO - 2021-07-08 11:33:09 --> URI Class Initialized
INFO - 2021-07-08 11:33:09 --> Router Class Initialized
INFO - 2021-07-08 11:33:09 --> Output Class Initialized
INFO - 2021-07-08 11:33:09 --> Security Class Initialized
DEBUG - 2021-07-08 11:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:33:09 --> Input Class Initialized
INFO - 2021-07-08 11:33:09 --> Language Class Initialized
INFO - 2021-07-08 11:33:09 --> Loader Class Initialized
INFO - 2021-07-08 11:33:09 --> Helper loaded: html_helper
INFO - 2021-07-08 11:33:09 --> Helper loaded: url_helper
INFO - 2021-07-08 11:33:09 --> Helper loaded: form_helper
INFO - 2021-07-08 11:33:09 --> Database Driver Class Initialized
INFO - 2021-07-08 11:33:09 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:33:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:33:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:33:09 --> Encryption Class Initialized
INFO - 2021-07-08 11:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:33:09 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:33:09 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:33:09 --> Model "user_model" initialized
INFO - 2021-07-08 11:33:09 --> Model "role_model" initialized
INFO - 2021-07-08 11:33:09 --> Controller Class Initialized
INFO - 2021-07-08 11:33:09 --> Helper loaded: language_helper
INFO - 2021-07-08 11:33:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:33:09 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:33:09 --> Final output sent to browser
DEBUG - 2021-07-08 11:33:09 --> Total execution time: 0.0686
INFO - 2021-07-08 11:33:29 --> Config Class Initialized
INFO - 2021-07-08 11:33:29 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:33:29 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:33:29 --> Utf8 Class Initialized
INFO - 2021-07-08 11:33:29 --> URI Class Initialized
INFO - 2021-07-08 11:33:29 --> Router Class Initialized
INFO - 2021-07-08 11:33:29 --> Output Class Initialized
INFO - 2021-07-08 11:33:29 --> Security Class Initialized
DEBUG - 2021-07-08 11:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:33:29 --> Input Class Initialized
INFO - 2021-07-08 11:33:29 --> Language Class Initialized
INFO - 2021-07-08 11:33:29 --> Loader Class Initialized
INFO - 2021-07-08 11:33:29 --> Helper loaded: html_helper
INFO - 2021-07-08 11:33:29 --> Helper loaded: url_helper
INFO - 2021-07-08 11:33:29 --> Helper loaded: form_helper
INFO - 2021-07-08 11:33:29 --> Database Driver Class Initialized
INFO - 2021-07-08 11:33:29 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:33:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:33:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:33:29 --> Encryption Class Initialized
INFO - 2021-07-08 11:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:33:29 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:33:29 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:33:29 --> Model "user_model" initialized
INFO - 2021-07-08 11:33:29 --> Model "role_model" initialized
INFO - 2021-07-08 11:33:29 --> Controller Class Initialized
INFO - 2021-07-08 11:33:29 --> Helper loaded: language_helper
INFO - 2021-07-08 11:33:29 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:33:29 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:33:29 --> Model "Product_model" initialized
INFO - 2021-07-08 11:33:29 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:33:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:33:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:33:29 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:33:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:33:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:33:29 --> Final output sent to browser
DEBUG - 2021-07-08 11:33:29 --> Total execution time: 0.1082
INFO - 2021-07-08 11:33:32 --> Config Class Initialized
INFO - 2021-07-08 11:33:32 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:33:32 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:33:32 --> Utf8 Class Initialized
INFO - 2021-07-08 11:33:32 --> URI Class Initialized
INFO - 2021-07-08 11:33:32 --> Router Class Initialized
INFO - 2021-07-08 11:33:32 --> Output Class Initialized
INFO - 2021-07-08 11:33:32 --> Security Class Initialized
DEBUG - 2021-07-08 11:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:33:32 --> Input Class Initialized
INFO - 2021-07-08 11:33:32 --> Language Class Initialized
INFO - 2021-07-08 11:33:32 --> Loader Class Initialized
INFO - 2021-07-08 11:33:32 --> Helper loaded: html_helper
INFO - 2021-07-08 11:33:32 --> Helper loaded: url_helper
INFO - 2021-07-08 11:33:32 --> Helper loaded: form_helper
INFO - 2021-07-08 11:33:32 --> Database Driver Class Initialized
INFO - 2021-07-08 11:33:32 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:33:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:33:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:33:32 --> Encryption Class Initialized
INFO - 2021-07-08 11:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:33:32 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:33:32 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:33:32 --> Model "user_model" initialized
INFO - 2021-07-08 11:33:32 --> Model "role_model" initialized
INFO - 2021-07-08 11:33:32 --> Controller Class Initialized
INFO - 2021-07-08 11:33:32 --> Helper loaded: language_helper
INFO - 2021-07-08 11:33:32 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:33:32 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:33:32 --> Final output sent to browser
DEBUG - 2021-07-08 11:33:32 --> Total execution time: 0.0586
INFO - 2021-07-08 11:33:33 --> Config Class Initialized
INFO - 2021-07-08 11:33:33 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:33:33 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:33:33 --> Utf8 Class Initialized
INFO - 2021-07-08 11:33:33 --> URI Class Initialized
INFO - 2021-07-08 11:33:33 --> Router Class Initialized
INFO - 2021-07-08 11:33:33 --> Output Class Initialized
INFO - 2021-07-08 11:33:33 --> Security Class Initialized
DEBUG - 2021-07-08 11:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:33:33 --> Input Class Initialized
INFO - 2021-07-08 11:33:33 --> Language Class Initialized
INFO - 2021-07-08 11:33:33 --> Loader Class Initialized
INFO - 2021-07-08 11:33:33 --> Helper loaded: html_helper
INFO - 2021-07-08 11:33:33 --> Helper loaded: url_helper
INFO - 2021-07-08 11:33:33 --> Helper loaded: form_helper
INFO - 2021-07-08 11:33:33 --> Database Driver Class Initialized
INFO - 2021-07-08 11:33:33 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:33:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:33:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:33:33 --> Encryption Class Initialized
INFO - 2021-07-08 11:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:33:33 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:33:33 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:33:33 --> Model "user_model" initialized
INFO - 2021-07-08 11:33:33 --> Model "role_model" initialized
INFO - 2021-07-08 11:33:33 --> Controller Class Initialized
INFO - 2021-07-08 11:33:33 --> Helper loaded: language_helper
INFO - 2021-07-08 11:33:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:33:33 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:33:33 --> Final output sent to browser
DEBUG - 2021-07-08 11:33:33 --> Total execution time: 0.0683
INFO - 2021-07-08 11:34:19 --> Config Class Initialized
INFO - 2021-07-08 11:34:19 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:34:19 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:34:19 --> Utf8 Class Initialized
INFO - 2021-07-08 11:34:19 --> URI Class Initialized
INFO - 2021-07-08 11:34:19 --> Router Class Initialized
INFO - 2021-07-08 11:34:19 --> Output Class Initialized
INFO - 2021-07-08 11:34:19 --> Security Class Initialized
DEBUG - 2021-07-08 11:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:34:19 --> Input Class Initialized
INFO - 2021-07-08 11:34:19 --> Language Class Initialized
INFO - 2021-07-08 11:34:19 --> Loader Class Initialized
INFO - 2021-07-08 11:34:19 --> Helper loaded: html_helper
INFO - 2021-07-08 11:34:19 --> Helper loaded: url_helper
INFO - 2021-07-08 11:34:19 --> Helper loaded: form_helper
INFO - 2021-07-08 11:34:19 --> Database Driver Class Initialized
INFO - 2021-07-08 11:34:19 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:34:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:34:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:34:19 --> Encryption Class Initialized
INFO - 2021-07-08 11:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:34:19 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:34:19 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:34:19 --> Model "user_model" initialized
INFO - 2021-07-08 11:34:19 --> Model "role_model" initialized
INFO - 2021-07-08 11:34:19 --> Controller Class Initialized
INFO - 2021-07-08 11:34:19 --> Helper loaded: language_helper
INFO - 2021-07-08 11:34:19 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:34:19 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:34:19 --> Model "Product_model" initialized
INFO - 2021-07-08 11:34:19 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:34:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:34:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:34:19 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:34:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:34:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:34:19 --> Final output sent to browser
DEBUG - 2021-07-08 11:34:19 --> Total execution time: 0.1153
INFO - 2021-07-08 11:34:22 --> Config Class Initialized
INFO - 2021-07-08 11:34:22 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:34:22 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:34:22 --> Utf8 Class Initialized
INFO - 2021-07-08 11:34:22 --> URI Class Initialized
INFO - 2021-07-08 11:34:22 --> Router Class Initialized
INFO - 2021-07-08 11:34:22 --> Output Class Initialized
INFO - 2021-07-08 11:34:22 --> Security Class Initialized
DEBUG - 2021-07-08 11:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:34:22 --> Input Class Initialized
INFO - 2021-07-08 11:34:22 --> Language Class Initialized
INFO - 2021-07-08 11:34:22 --> Loader Class Initialized
INFO - 2021-07-08 11:34:22 --> Helper loaded: html_helper
INFO - 2021-07-08 11:34:22 --> Helper loaded: url_helper
INFO - 2021-07-08 11:34:22 --> Helper loaded: form_helper
INFO - 2021-07-08 11:34:22 --> Database Driver Class Initialized
INFO - 2021-07-08 11:34:23 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:34:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:34:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:34:23 --> Encryption Class Initialized
INFO - 2021-07-08 11:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:34:23 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:34:23 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:34:23 --> Model "user_model" initialized
INFO - 2021-07-08 11:34:23 --> Model "role_model" initialized
INFO - 2021-07-08 11:34:23 --> Controller Class Initialized
INFO - 2021-07-08 11:34:23 --> Helper loaded: language_helper
INFO - 2021-07-08 11:34:23 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:34:23 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:34:23 --> Final output sent to browser
DEBUG - 2021-07-08 11:34:23 --> Total execution time: 0.0644
INFO - 2021-07-08 11:34:23 --> Config Class Initialized
INFO - 2021-07-08 11:34:23 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:34:23 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:34:23 --> Utf8 Class Initialized
INFO - 2021-07-08 11:34:23 --> URI Class Initialized
INFO - 2021-07-08 11:34:23 --> Router Class Initialized
INFO - 2021-07-08 11:34:23 --> Output Class Initialized
INFO - 2021-07-08 11:34:23 --> Security Class Initialized
DEBUG - 2021-07-08 11:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:34:23 --> Input Class Initialized
INFO - 2021-07-08 11:34:23 --> Language Class Initialized
INFO - 2021-07-08 11:34:23 --> Loader Class Initialized
INFO - 2021-07-08 11:34:23 --> Helper loaded: html_helper
INFO - 2021-07-08 11:34:23 --> Helper loaded: url_helper
INFO - 2021-07-08 11:34:23 --> Helper loaded: form_helper
INFO - 2021-07-08 11:34:23 --> Database Driver Class Initialized
INFO - 2021-07-08 11:34:23 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:34:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:34:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:34:23 --> Encryption Class Initialized
INFO - 2021-07-08 11:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:34:23 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:34:23 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:34:23 --> Model "user_model" initialized
INFO - 2021-07-08 11:34:23 --> Model "role_model" initialized
INFO - 2021-07-08 11:34:23 --> Controller Class Initialized
INFO - 2021-07-08 11:34:23 --> Helper loaded: language_helper
INFO - 2021-07-08 11:34:23 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:34:23 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:34:23 --> Final output sent to browser
DEBUG - 2021-07-08 11:34:23 --> Total execution time: 0.0713
INFO - 2021-07-08 11:38:24 --> Config Class Initialized
INFO - 2021-07-08 11:38:24 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:38:24 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:38:24 --> Utf8 Class Initialized
INFO - 2021-07-08 11:38:24 --> URI Class Initialized
INFO - 2021-07-08 11:38:24 --> Router Class Initialized
INFO - 2021-07-08 11:38:24 --> Output Class Initialized
INFO - 2021-07-08 11:38:24 --> Security Class Initialized
DEBUG - 2021-07-08 11:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:38:24 --> Input Class Initialized
INFO - 2021-07-08 11:38:24 --> Language Class Initialized
INFO - 2021-07-08 11:38:24 --> Loader Class Initialized
INFO - 2021-07-08 11:38:24 --> Helper loaded: html_helper
INFO - 2021-07-08 11:38:24 --> Helper loaded: url_helper
INFO - 2021-07-08 11:38:24 --> Helper loaded: form_helper
INFO - 2021-07-08 11:38:24 --> Database Driver Class Initialized
INFO - 2021-07-08 11:38:24 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:38:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:38:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:38:24 --> Encryption Class Initialized
INFO - 2021-07-08 11:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:38:24 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:38:24 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:38:24 --> Model "user_model" initialized
INFO - 2021-07-08 11:38:24 --> Model "role_model" initialized
INFO - 2021-07-08 11:38:24 --> Controller Class Initialized
INFO - 2021-07-08 11:38:24 --> Helper loaded: language_helper
INFO - 2021-07-08 11:38:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:38:24 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:38:24 --> Model "Product_model" initialized
INFO - 2021-07-08 11:38:24 --> Model "StateGSTCode_modal" initialized
ERROR - 2021-07-08 11:38:24 --> Severity: Notice --> Undefined variable: query D:\development\web\xampp\htdocs\proadmin\proadmin\application\models\StateGSTCode_modal.php 24
ERROR - 2021-07-08 11:38:24 --> Severity: error --> Exception: Call to a member function num_rows() on null D:\development\web\xampp\htdocs\proadmin\proadmin\application\models\StateGSTCode_modal.php 24
INFO - 2021-07-08 11:38:56 --> Config Class Initialized
INFO - 2021-07-08 11:38:56 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:38:56 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:38:56 --> Utf8 Class Initialized
INFO - 2021-07-08 11:38:56 --> URI Class Initialized
INFO - 2021-07-08 11:38:56 --> Router Class Initialized
INFO - 2021-07-08 11:38:56 --> Output Class Initialized
INFO - 2021-07-08 11:38:56 --> Security Class Initialized
DEBUG - 2021-07-08 11:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:38:56 --> Input Class Initialized
INFO - 2021-07-08 11:38:56 --> Language Class Initialized
INFO - 2021-07-08 11:38:56 --> Loader Class Initialized
INFO - 2021-07-08 11:38:56 --> Helper loaded: html_helper
INFO - 2021-07-08 11:38:56 --> Helper loaded: url_helper
INFO - 2021-07-08 11:38:56 --> Helper loaded: form_helper
INFO - 2021-07-08 11:38:56 --> Database Driver Class Initialized
INFO - 2021-07-08 11:38:56 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:38:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:38:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:38:56 --> Encryption Class Initialized
INFO - 2021-07-08 11:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:38:56 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:38:56 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:38:56 --> Model "user_model" initialized
INFO - 2021-07-08 11:38:56 --> Model "role_model" initialized
INFO - 2021-07-08 11:38:56 --> Controller Class Initialized
INFO - 2021-07-08 11:38:56 --> Helper loaded: language_helper
INFO - 2021-07-08 11:38:56 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:38:56 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:38:56 --> Model "Product_model" initialized
INFO - 2021-07-08 11:38:56 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:38:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:38:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:38:56 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
ERROR - 2021-07-08 11:38:56 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 74
INFO - 2021-07-08 11:39:35 --> Config Class Initialized
INFO - 2021-07-08 11:39:35 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:39:35 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:39:35 --> Utf8 Class Initialized
INFO - 2021-07-08 11:39:35 --> URI Class Initialized
INFO - 2021-07-08 11:39:35 --> Router Class Initialized
INFO - 2021-07-08 11:39:35 --> Output Class Initialized
INFO - 2021-07-08 11:39:35 --> Security Class Initialized
DEBUG - 2021-07-08 11:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:39:35 --> Input Class Initialized
INFO - 2021-07-08 11:39:35 --> Language Class Initialized
INFO - 2021-07-08 11:39:35 --> Loader Class Initialized
INFO - 2021-07-08 11:39:35 --> Helper loaded: html_helper
INFO - 2021-07-08 11:39:35 --> Helper loaded: url_helper
INFO - 2021-07-08 11:39:35 --> Helper loaded: form_helper
INFO - 2021-07-08 11:39:35 --> Database Driver Class Initialized
INFO - 2021-07-08 11:39:35 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:39:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:39:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:39:35 --> Encryption Class Initialized
INFO - 2021-07-08 11:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:39:35 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:39:35 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:39:35 --> Model "user_model" initialized
INFO - 2021-07-08 11:39:35 --> Model "role_model" initialized
INFO - 2021-07-08 11:39:35 --> Controller Class Initialized
INFO - 2021-07-08 11:39:35 --> Helper loaded: language_helper
INFO - 2021-07-08 11:39:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:39:35 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:39:35 --> Model "Product_model" initialized
INFO - 2021-07-08 11:39:35 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:39:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:39:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:39:35 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:39:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:39:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:39:35 --> Final output sent to browser
DEBUG - 2021-07-08 11:39:35 --> Total execution time: 0.1120
INFO - 2021-07-08 11:40:17 --> Config Class Initialized
INFO - 2021-07-08 11:40:17 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:40:17 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:40:17 --> Utf8 Class Initialized
INFO - 2021-07-08 11:40:17 --> URI Class Initialized
INFO - 2021-07-08 11:40:17 --> Router Class Initialized
INFO - 2021-07-08 11:40:17 --> Output Class Initialized
INFO - 2021-07-08 11:40:17 --> Security Class Initialized
DEBUG - 2021-07-08 11:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:40:17 --> Input Class Initialized
INFO - 2021-07-08 11:40:17 --> Language Class Initialized
INFO - 2021-07-08 11:40:17 --> Loader Class Initialized
INFO - 2021-07-08 11:40:17 --> Helper loaded: html_helper
INFO - 2021-07-08 11:40:17 --> Helper loaded: url_helper
INFO - 2021-07-08 11:40:17 --> Helper loaded: form_helper
INFO - 2021-07-08 11:40:17 --> Database Driver Class Initialized
INFO - 2021-07-08 11:40:17 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:40:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:40:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:40:17 --> Encryption Class Initialized
INFO - 2021-07-08 11:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:40:17 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:40:17 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:40:17 --> Model "user_model" initialized
INFO - 2021-07-08 11:40:17 --> Model "role_model" initialized
INFO - 2021-07-08 11:40:17 --> Controller Class Initialized
INFO - 2021-07-08 11:40:17 --> Helper loaded: language_helper
INFO - 2021-07-08 11:40:17 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:40:17 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:40:17 --> Model "Product_model" initialized
INFO - 2021-07-08 11:40:17 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:40:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:40:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:40:17 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:40:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:40:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:40:17 --> Final output sent to browser
DEBUG - 2021-07-08 11:40:17 --> Total execution time: 0.1016
INFO - 2021-07-08 11:40:21 --> Config Class Initialized
INFO - 2021-07-08 11:40:21 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:40:21 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:40:21 --> Utf8 Class Initialized
INFO - 2021-07-08 11:40:21 --> URI Class Initialized
INFO - 2021-07-08 11:40:21 --> Router Class Initialized
INFO - 2021-07-08 11:40:21 --> Output Class Initialized
INFO - 2021-07-08 11:40:21 --> Security Class Initialized
DEBUG - 2021-07-08 11:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:40:21 --> Input Class Initialized
INFO - 2021-07-08 11:40:21 --> Language Class Initialized
INFO - 2021-07-08 11:40:21 --> Loader Class Initialized
INFO - 2021-07-08 11:40:21 --> Helper loaded: html_helper
INFO - 2021-07-08 11:40:21 --> Helper loaded: url_helper
INFO - 2021-07-08 11:40:21 --> Helper loaded: form_helper
INFO - 2021-07-08 11:40:21 --> Database Driver Class Initialized
INFO - 2021-07-08 11:40:21 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:40:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:40:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:40:21 --> Encryption Class Initialized
INFO - 2021-07-08 11:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:40:21 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:40:21 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:40:21 --> Model "user_model" initialized
INFO - 2021-07-08 11:40:21 --> Model "role_model" initialized
INFO - 2021-07-08 11:40:21 --> Controller Class Initialized
INFO - 2021-07-08 11:40:21 --> Helper loaded: language_helper
INFO - 2021-07-08 11:40:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:40:21 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:40:21 --> Final output sent to browser
DEBUG - 2021-07-08 11:40:21 --> Total execution time: 0.0648
INFO - 2021-07-08 11:40:22 --> Config Class Initialized
INFO - 2021-07-08 11:40:22 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:40:22 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:40:22 --> Utf8 Class Initialized
INFO - 2021-07-08 11:40:22 --> URI Class Initialized
INFO - 2021-07-08 11:40:22 --> Router Class Initialized
INFO - 2021-07-08 11:40:22 --> Output Class Initialized
INFO - 2021-07-08 11:40:22 --> Security Class Initialized
DEBUG - 2021-07-08 11:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:40:22 --> Input Class Initialized
INFO - 2021-07-08 11:40:22 --> Language Class Initialized
INFO - 2021-07-08 11:40:22 --> Loader Class Initialized
INFO - 2021-07-08 11:40:22 --> Helper loaded: html_helper
INFO - 2021-07-08 11:40:22 --> Helper loaded: url_helper
INFO - 2021-07-08 11:40:22 --> Helper loaded: form_helper
INFO - 2021-07-08 11:40:22 --> Database Driver Class Initialized
INFO - 2021-07-08 11:40:22 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:40:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:40:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:40:22 --> Encryption Class Initialized
INFO - 2021-07-08 11:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:40:22 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:40:22 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:40:22 --> Model "user_model" initialized
INFO - 2021-07-08 11:40:22 --> Model "role_model" initialized
INFO - 2021-07-08 11:40:22 --> Controller Class Initialized
INFO - 2021-07-08 11:40:22 --> Helper loaded: language_helper
INFO - 2021-07-08 11:40:22 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:40:22 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:40:22 --> Final output sent to browser
DEBUG - 2021-07-08 11:40:22 --> Total execution time: 0.0665
INFO - 2021-07-08 11:40:36 --> Config Class Initialized
INFO - 2021-07-08 11:40:36 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:40:36 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:40:36 --> Utf8 Class Initialized
INFO - 2021-07-08 11:40:36 --> URI Class Initialized
INFO - 2021-07-08 11:40:36 --> Router Class Initialized
INFO - 2021-07-08 11:40:36 --> Output Class Initialized
INFO - 2021-07-08 11:40:36 --> Security Class Initialized
DEBUG - 2021-07-08 11:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:40:36 --> Input Class Initialized
INFO - 2021-07-08 11:40:36 --> Language Class Initialized
INFO - 2021-07-08 11:40:36 --> Loader Class Initialized
INFO - 2021-07-08 11:40:36 --> Helper loaded: html_helper
INFO - 2021-07-08 11:40:36 --> Helper loaded: url_helper
INFO - 2021-07-08 11:40:36 --> Helper loaded: form_helper
INFO - 2021-07-08 11:40:36 --> Database Driver Class Initialized
INFO - 2021-07-08 11:40:36 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:40:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:40:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:40:36 --> Encryption Class Initialized
INFO - 2021-07-08 11:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:40:36 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:40:36 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:40:36 --> Model "user_model" initialized
INFO - 2021-07-08 11:40:36 --> Model "role_model" initialized
INFO - 2021-07-08 11:40:36 --> Controller Class Initialized
INFO - 2021-07-08 11:40:36 --> Helper loaded: language_helper
INFO - 2021-07-08 11:40:36 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:40:36 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:40:36 --> Model "Product_model" initialized
INFO - 2021-07-08 11:40:36 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:40:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:40:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:40:36 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:40:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:40:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:40:36 --> Final output sent to browser
DEBUG - 2021-07-08 11:40:36 --> Total execution time: 0.0993
INFO - 2021-07-08 11:40:39 --> Config Class Initialized
INFO - 2021-07-08 11:40:39 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:40:39 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:40:39 --> Utf8 Class Initialized
INFO - 2021-07-08 11:40:39 --> URI Class Initialized
INFO - 2021-07-08 11:40:39 --> Router Class Initialized
INFO - 2021-07-08 11:40:39 --> Output Class Initialized
INFO - 2021-07-08 11:40:39 --> Security Class Initialized
DEBUG - 2021-07-08 11:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:40:39 --> Input Class Initialized
INFO - 2021-07-08 11:40:39 --> Language Class Initialized
INFO - 2021-07-08 11:40:39 --> Loader Class Initialized
INFO - 2021-07-08 11:40:39 --> Helper loaded: html_helper
INFO - 2021-07-08 11:40:39 --> Helper loaded: url_helper
INFO - 2021-07-08 11:40:39 --> Helper loaded: form_helper
INFO - 2021-07-08 11:40:39 --> Database Driver Class Initialized
INFO - 2021-07-08 11:40:39 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:40:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:40:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:40:39 --> Encryption Class Initialized
INFO - 2021-07-08 11:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:40:39 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:40:39 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:40:39 --> Model "user_model" initialized
INFO - 2021-07-08 11:40:39 --> Model "role_model" initialized
INFO - 2021-07-08 11:40:39 --> Controller Class Initialized
INFO - 2021-07-08 11:40:39 --> Helper loaded: language_helper
INFO - 2021-07-08 11:40:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:40:39 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:40:39 --> Final output sent to browser
DEBUG - 2021-07-08 11:40:39 --> Total execution time: 0.0593
INFO - 2021-07-08 11:40:40 --> Config Class Initialized
INFO - 2021-07-08 11:40:40 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:40:40 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:40:40 --> Utf8 Class Initialized
INFO - 2021-07-08 11:40:40 --> URI Class Initialized
INFO - 2021-07-08 11:40:40 --> Router Class Initialized
INFO - 2021-07-08 11:40:40 --> Output Class Initialized
INFO - 2021-07-08 11:40:40 --> Security Class Initialized
DEBUG - 2021-07-08 11:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:40:40 --> Input Class Initialized
INFO - 2021-07-08 11:40:40 --> Language Class Initialized
INFO - 2021-07-08 11:40:40 --> Loader Class Initialized
INFO - 2021-07-08 11:40:40 --> Helper loaded: html_helper
INFO - 2021-07-08 11:40:40 --> Helper loaded: url_helper
INFO - 2021-07-08 11:40:40 --> Helper loaded: form_helper
INFO - 2021-07-08 11:40:40 --> Database Driver Class Initialized
INFO - 2021-07-08 11:40:40 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:40:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:40:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:40:40 --> Encryption Class Initialized
INFO - 2021-07-08 11:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:40:40 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:40:40 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:40:40 --> Model "user_model" initialized
INFO - 2021-07-08 11:40:40 --> Model "role_model" initialized
INFO - 2021-07-08 11:40:40 --> Controller Class Initialized
INFO - 2021-07-08 11:40:40 --> Helper loaded: language_helper
INFO - 2021-07-08 11:40:40 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:40:40 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:40:40 --> Final output sent to browser
DEBUG - 2021-07-08 11:40:40 --> Total execution time: 0.0638
INFO - 2021-07-08 11:41:43 --> Config Class Initialized
INFO - 2021-07-08 11:41:43 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:41:43 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:41:43 --> Utf8 Class Initialized
INFO - 2021-07-08 11:41:43 --> URI Class Initialized
INFO - 2021-07-08 11:41:43 --> Router Class Initialized
INFO - 2021-07-08 11:41:43 --> Output Class Initialized
INFO - 2021-07-08 11:41:43 --> Security Class Initialized
DEBUG - 2021-07-08 11:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:41:43 --> Input Class Initialized
INFO - 2021-07-08 11:41:43 --> Language Class Initialized
INFO - 2021-07-08 11:41:43 --> Loader Class Initialized
INFO - 2021-07-08 11:41:43 --> Helper loaded: html_helper
INFO - 2021-07-08 11:41:43 --> Helper loaded: url_helper
INFO - 2021-07-08 11:41:43 --> Helper loaded: form_helper
INFO - 2021-07-08 11:41:43 --> Database Driver Class Initialized
INFO - 2021-07-08 11:41:43 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:41:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:41:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:41:43 --> Encryption Class Initialized
INFO - 2021-07-08 11:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:41:43 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:41:43 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:41:43 --> Model "user_model" initialized
INFO - 2021-07-08 11:41:43 --> Model "role_model" initialized
INFO - 2021-07-08 11:41:43 --> Controller Class Initialized
INFO - 2021-07-08 11:41:43 --> Helper loaded: language_helper
INFO - 2021-07-08 11:41:43 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:41:43 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:41:43 --> Model "Product_model" initialized
INFO - 2021-07-08 11:41:43 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:41:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:41:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:41:43 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:41:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:41:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:41:43 --> Final output sent to browser
DEBUG - 2021-07-08 11:41:43 --> Total execution time: 0.1380
INFO - 2021-07-08 11:41:56 --> Config Class Initialized
INFO - 2021-07-08 11:41:56 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:41:56 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:41:56 --> Utf8 Class Initialized
INFO - 2021-07-08 11:41:56 --> URI Class Initialized
INFO - 2021-07-08 11:41:56 --> Router Class Initialized
INFO - 2021-07-08 11:41:56 --> Output Class Initialized
INFO - 2021-07-08 11:41:56 --> Security Class Initialized
DEBUG - 2021-07-08 11:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:41:56 --> Input Class Initialized
INFO - 2021-07-08 11:41:57 --> Language Class Initialized
INFO - 2021-07-08 11:41:57 --> Loader Class Initialized
INFO - 2021-07-08 11:41:57 --> Helper loaded: html_helper
INFO - 2021-07-08 11:41:57 --> Helper loaded: url_helper
INFO - 2021-07-08 11:41:57 --> Helper loaded: form_helper
INFO - 2021-07-08 11:41:57 --> Database Driver Class Initialized
INFO - 2021-07-08 11:41:57 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:41:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:41:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:41:57 --> Encryption Class Initialized
INFO - 2021-07-08 11:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:41:57 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:41:57 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:41:57 --> Model "user_model" initialized
INFO - 2021-07-08 11:41:57 --> Model "role_model" initialized
INFO - 2021-07-08 11:41:57 --> Controller Class Initialized
INFO - 2021-07-08 11:41:57 --> Helper loaded: language_helper
INFO - 2021-07-08 11:41:57 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:41:57 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:41:57 --> Model "Product_model" initialized
INFO - 2021-07-08 11:41:57 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:41:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:41:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:41:57 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:41:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:41:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:41:57 --> Final output sent to browser
DEBUG - 2021-07-08 11:41:57 --> Total execution time: 0.1072
INFO - 2021-07-08 11:42:03 --> Config Class Initialized
INFO - 2021-07-08 11:42:03 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:42:03 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:42:03 --> Utf8 Class Initialized
INFO - 2021-07-08 11:42:03 --> URI Class Initialized
INFO - 2021-07-08 11:42:03 --> Router Class Initialized
INFO - 2021-07-08 11:42:03 --> Output Class Initialized
INFO - 2021-07-08 11:42:03 --> Security Class Initialized
DEBUG - 2021-07-08 11:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:42:03 --> Input Class Initialized
INFO - 2021-07-08 11:42:03 --> Language Class Initialized
INFO - 2021-07-08 11:42:03 --> Loader Class Initialized
INFO - 2021-07-08 11:42:03 --> Helper loaded: html_helper
INFO - 2021-07-08 11:42:03 --> Helper loaded: url_helper
INFO - 2021-07-08 11:42:03 --> Helper loaded: form_helper
INFO - 2021-07-08 11:42:03 --> Database Driver Class Initialized
INFO - 2021-07-08 11:42:03 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:42:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:42:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:42:03 --> Encryption Class Initialized
INFO - 2021-07-08 11:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:42:03 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:42:03 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:42:03 --> Model "user_model" initialized
INFO - 2021-07-08 11:42:03 --> Model "role_model" initialized
INFO - 2021-07-08 11:42:03 --> Controller Class Initialized
INFO - 2021-07-08 11:42:03 --> Helper loaded: language_helper
INFO - 2021-07-08 11:42:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:42:03 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:42:03 --> Final output sent to browser
DEBUG - 2021-07-08 11:42:03 --> Total execution time: 0.0644
INFO - 2021-07-08 11:42:03 --> Config Class Initialized
INFO - 2021-07-08 11:42:03 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:42:03 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:42:03 --> Utf8 Class Initialized
INFO - 2021-07-08 11:42:03 --> URI Class Initialized
INFO - 2021-07-08 11:42:03 --> Router Class Initialized
INFO - 2021-07-08 11:42:03 --> Output Class Initialized
INFO - 2021-07-08 11:42:03 --> Security Class Initialized
DEBUG - 2021-07-08 11:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:42:03 --> Input Class Initialized
INFO - 2021-07-08 11:42:03 --> Language Class Initialized
INFO - 2021-07-08 11:42:03 --> Loader Class Initialized
INFO - 2021-07-08 11:42:03 --> Helper loaded: html_helper
INFO - 2021-07-08 11:42:03 --> Helper loaded: url_helper
INFO - 2021-07-08 11:42:03 --> Helper loaded: form_helper
INFO - 2021-07-08 11:42:03 --> Database Driver Class Initialized
INFO - 2021-07-08 11:42:03 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:42:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:42:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:42:03 --> Encryption Class Initialized
INFO - 2021-07-08 11:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:42:03 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:42:03 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:42:03 --> Model "user_model" initialized
INFO - 2021-07-08 11:42:03 --> Model "role_model" initialized
INFO - 2021-07-08 11:42:03 --> Controller Class Initialized
INFO - 2021-07-08 11:42:03 --> Helper loaded: language_helper
INFO - 2021-07-08 11:42:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:42:03 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:42:03 --> Final output sent to browser
DEBUG - 2021-07-08 11:42:03 --> Total execution time: 0.0649
INFO - 2021-07-08 11:44:33 --> Config Class Initialized
INFO - 2021-07-08 11:44:33 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:44:33 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:44:33 --> Utf8 Class Initialized
INFO - 2021-07-08 11:44:33 --> URI Class Initialized
INFO - 2021-07-08 11:44:33 --> Router Class Initialized
INFO - 2021-07-08 11:44:33 --> Output Class Initialized
INFO - 2021-07-08 11:44:33 --> Security Class Initialized
DEBUG - 2021-07-08 11:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:44:33 --> Input Class Initialized
INFO - 2021-07-08 11:44:33 --> Language Class Initialized
INFO - 2021-07-08 11:44:33 --> Loader Class Initialized
INFO - 2021-07-08 11:44:33 --> Helper loaded: html_helper
INFO - 2021-07-08 11:44:33 --> Helper loaded: url_helper
INFO - 2021-07-08 11:44:33 --> Helper loaded: form_helper
INFO - 2021-07-08 11:44:33 --> Database Driver Class Initialized
INFO - 2021-07-08 11:44:33 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:44:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:44:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:44:33 --> Encryption Class Initialized
INFO - 2021-07-08 11:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:44:33 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:44:33 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:44:33 --> Model "user_model" initialized
INFO - 2021-07-08 11:44:33 --> Model "role_model" initialized
INFO - 2021-07-08 11:44:33 --> Controller Class Initialized
INFO - 2021-07-08 11:44:33 --> Helper loaded: language_helper
INFO - 2021-07-08 11:44:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:44:33 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:44:33 --> Model "Product_model" initialized
INFO - 2021-07-08 11:44:33 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:44:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:44:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:44:33 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:44:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:44:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:44:33 --> Final output sent to browser
DEBUG - 2021-07-08 11:44:33 --> Total execution time: 0.1017
INFO - 2021-07-08 11:44:37 --> Config Class Initialized
INFO - 2021-07-08 11:44:37 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:44:37 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:44:37 --> Utf8 Class Initialized
INFO - 2021-07-08 11:44:37 --> URI Class Initialized
INFO - 2021-07-08 11:44:37 --> Router Class Initialized
INFO - 2021-07-08 11:44:37 --> Output Class Initialized
INFO - 2021-07-08 11:44:37 --> Security Class Initialized
DEBUG - 2021-07-08 11:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:44:37 --> Input Class Initialized
INFO - 2021-07-08 11:44:37 --> Language Class Initialized
INFO - 2021-07-08 11:44:37 --> Loader Class Initialized
INFO - 2021-07-08 11:44:37 --> Helper loaded: html_helper
INFO - 2021-07-08 11:44:37 --> Helper loaded: url_helper
INFO - 2021-07-08 11:44:37 --> Helper loaded: form_helper
INFO - 2021-07-08 11:44:37 --> Database Driver Class Initialized
INFO - 2021-07-08 11:44:37 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:44:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:44:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:44:37 --> Encryption Class Initialized
INFO - 2021-07-08 11:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:44:37 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:44:37 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:44:37 --> Model "user_model" initialized
INFO - 2021-07-08 11:44:37 --> Model "role_model" initialized
INFO - 2021-07-08 11:44:37 --> Controller Class Initialized
INFO - 2021-07-08 11:44:37 --> Helper loaded: language_helper
INFO - 2021-07-08 11:44:37 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:44:37 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:44:37 --> Final output sent to browser
DEBUG - 2021-07-08 11:44:37 --> Total execution time: 0.0589
INFO - 2021-07-08 11:44:38 --> Config Class Initialized
INFO - 2021-07-08 11:44:38 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:44:38 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:44:38 --> Utf8 Class Initialized
INFO - 2021-07-08 11:44:38 --> URI Class Initialized
INFO - 2021-07-08 11:44:38 --> Router Class Initialized
INFO - 2021-07-08 11:44:38 --> Output Class Initialized
INFO - 2021-07-08 11:44:38 --> Security Class Initialized
DEBUG - 2021-07-08 11:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:44:38 --> Input Class Initialized
INFO - 2021-07-08 11:44:38 --> Language Class Initialized
INFO - 2021-07-08 11:44:38 --> Loader Class Initialized
INFO - 2021-07-08 11:44:38 --> Helper loaded: html_helper
INFO - 2021-07-08 11:44:38 --> Helper loaded: url_helper
INFO - 2021-07-08 11:44:38 --> Helper loaded: form_helper
INFO - 2021-07-08 11:44:38 --> Database Driver Class Initialized
INFO - 2021-07-08 11:44:38 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:44:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:44:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:44:38 --> Encryption Class Initialized
INFO - 2021-07-08 11:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:44:38 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:44:38 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:44:38 --> Model "user_model" initialized
INFO - 2021-07-08 11:44:38 --> Model "role_model" initialized
INFO - 2021-07-08 11:44:38 --> Controller Class Initialized
INFO - 2021-07-08 11:44:38 --> Helper loaded: language_helper
INFO - 2021-07-08 11:44:38 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:44:38 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:44:38 --> Final output sent to browser
DEBUG - 2021-07-08 11:44:38 --> Total execution time: 0.0679
INFO - 2021-07-08 11:46:14 --> Config Class Initialized
INFO - 2021-07-08 11:46:14 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:46:14 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:46:14 --> Utf8 Class Initialized
INFO - 2021-07-08 11:46:14 --> URI Class Initialized
INFO - 2021-07-08 11:46:14 --> Router Class Initialized
INFO - 2021-07-08 11:46:14 --> Output Class Initialized
INFO - 2021-07-08 11:46:14 --> Security Class Initialized
DEBUG - 2021-07-08 11:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:46:14 --> Input Class Initialized
INFO - 2021-07-08 11:46:14 --> Language Class Initialized
INFO - 2021-07-08 11:46:14 --> Loader Class Initialized
INFO - 2021-07-08 11:46:14 --> Helper loaded: html_helper
INFO - 2021-07-08 11:46:14 --> Helper loaded: url_helper
INFO - 2021-07-08 11:46:14 --> Helper loaded: form_helper
INFO - 2021-07-08 11:46:14 --> Database Driver Class Initialized
INFO - 2021-07-08 11:46:14 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:46:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:46:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:46:14 --> Encryption Class Initialized
INFO - 2021-07-08 11:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:46:14 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:46:14 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:46:14 --> Model "user_model" initialized
INFO - 2021-07-08 11:46:14 --> Model "role_model" initialized
INFO - 2021-07-08 11:46:14 --> Controller Class Initialized
INFO - 2021-07-08 11:46:14 --> Helper loaded: language_helper
INFO - 2021-07-08 11:46:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:46:14 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:46:14 --> Model "Product_model" initialized
INFO - 2021-07-08 11:46:14 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:46:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:46:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:46:14 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:46:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:46:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:46:14 --> Final output sent to browser
DEBUG - 2021-07-08 11:46:14 --> Total execution time: 0.1274
INFO - 2021-07-08 11:46:17 --> Config Class Initialized
INFO - 2021-07-08 11:46:17 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:46:17 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:46:17 --> Utf8 Class Initialized
INFO - 2021-07-08 11:46:17 --> URI Class Initialized
INFO - 2021-07-08 11:46:17 --> Router Class Initialized
INFO - 2021-07-08 11:46:17 --> Output Class Initialized
INFO - 2021-07-08 11:46:17 --> Security Class Initialized
DEBUG - 2021-07-08 11:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:46:17 --> Input Class Initialized
INFO - 2021-07-08 11:46:17 --> Language Class Initialized
INFO - 2021-07-08 11:46:17 --> Loader Class Initialized
INFO - 2021-07-08 11:46:17 --> Helper loaded: html_helper
INFO - 2021-07-08 11:46:17 --> Helper loaded: url_helper
INFO - 2021-07-08 11:46:17 --> Helper loaded: form_helper
INFO - 2021-07-08 11:46:17 --> Database Driver Class Initialized
INFO - 2021-07-08 11:46:17 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:46:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:46:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:46:17 --> Encryption Class Initialized
INFO - 2021-07-08 11:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:46:17 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:46:17 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:46:17 --> Model "user_model" initialized
INFO - 2021-07-08 11:46:17 --> Model "role_model" initialized
INFO - 2021-07-08 11:46:17 --> Controller Class Initialized
INFO - 2021-07-08 11:46:17 --> Helper loaded: language_helper
INFO - 2021-07-08 11:46:17 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:46:17 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:46:17 --> Final output sent to browser
DEBUG - 2021-07-08 11:46:17 --> Total execution time: 0.0610
INFO - 2021-07-08 11:46:18 --> Config Class Initialized
INFO - 2021-07-08 11:46:18 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:46:18 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:46:18 --> Utf8 Class Initialized
INFO - 2021-07-08 11:46:18 --> URI Class Initialized
INFO - 2021-07-08 11:46:18 --> Router Class Initialized
INFO - 2021-07-08 11:46:18 --> Output Class Initialized
INFO - 2021-07-08 11:46:18 --> Security Class Initialized
DEBUG - 2021-07-08 11:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:46:18 --> Input Class Initialized
INFO - 2021-07-08 11:46:18 --> Language Class Initialized
INFO - 2021-07-08 11:46:18 --> Loader Class Initialized
INFO - 2021-07-08 11:46:18 --> Helper loaded: html_helper
INFO - 2021-07-08 11:46:18 --> Helper loaded: url_helper
INFO - 2021-07-08 11:46:18 --> Helper loaded: form_helper
INFO - 2021-07-08 11:46:18 --> Database Driver Class Initialized
INFO - 2021-07-08 11:46:18 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:46:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:46:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:46:18 --> Encryption Class Initialized
INFO - 2021-07-08 11:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:46:18 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:46:18 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:46:18 --> Model "user_model" initialized
INFO - 2021-07-08 11:46:18 --> Model "role_model" initialized
INFO - 2021-07-08 11:46:18 --> Controller Class Initialized
INFO - 2021-07-08 11:46:18 --> Helper loaded: language_helper
INFO - 2021-07-08 11:46:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:46:18 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:46:18 --> Final output sent to browser
DEBUG - 2021-07-08 11:46:18 --> Total execution time: 0.0649
INFO - 2021-07-08 11:46:55 --> Config Class Initialized
INFO - 2021-07-08 11:46:55 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:46:55 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:46:55 --> Utf8 Class Initialized
INFO - 2021-07-08 11:46:55 --> URI Class Initialized
INFO - 2021-07-08 11:46:55 --> Router Class Initialized
INFO - 2021-07-08 11:46:55 --> Output Class Initialized
INFO - 2021-07-08 11:46:55 --> Security Class Initialized
DEBUG - 2021-07-08 11:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:46:55 --> Input Class Initialized
INFO - 2021-07-08 11:46:55 --> Language Class Initialized
INFO - 2021-07-08 11:46:55 --> Loader Class Initialized
INFO - 2021-07-08 11:46:55 --> Helper loaded: html_helper
INFO - 2021-07-08 11:46:55 --> Helper loaded: url_helper
INFO - 2021-07-08 11:46:55 --> Helper loaded: form_helper
INFO - 2021-07-08 11:46:55 --> Database Driver Class Initialized
INFO - 2021-07-08 11:46:55 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:46:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:46:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:46:55 --> Encryption Class Initialized
INFO - 2021-07-08 11:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:46:55 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:46:55 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:46:55 --> Model "user_model" initialized
INFO - 2021-07-08 11:46:55 --> Model "role_model" initialized
INFO - 2021-07-08 11:46:55 --> Controller Class Initialized
INFO - 2021-07-08 11:46:55 --> Helper loaded: language_helper
INFO - 2021-07-08 11:46:55 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:46:55 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:46:55 --> Model "Product_model" initialized
INFO - 2021-07-08 11:46:55 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:46:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:46:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:46:55 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:46:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:46:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:46:55 --> Final output sent to browser
DEBUG - 2021-07-08 11:46:55 --> Total execution time: 0.1074
INFO - 2021-07-08 11:46:58 --> Config Class Initialized
INFO - 2021-07-08 11:46:58 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:46:58 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:46:58 --> Utf8 Class Initialized
INFO - 2021-07-08 11:46:58 --> URI Class Initialized
INFO - 2021-07-08 11:46:58 --> Router Class Initialized
INFO - 2021-07-08 11:46:58 --> Output Class Initialized
INFO - 2021-07-08 11:46:58 --> Security Class Initialized
DEBUG - 2021-07-08 11:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:46:58 --> Input Class Initialized
INFO - 2021-07-08 11:46:58 --> Language Class Initialized
INFO - 2021-07-08 11:46:58 --> Loader Class Initialized
INFO - 2021-07-08 11:46:58 --> Helper loaded: html_helper
INFO - 2021-07-08 11:46:58 --> Helper loaded: url_helper
INFO - 2021-07-08 11:46:58 --> Helper loaded: form_helper
INFO - 2021-07-08 11:46:58 --> Database Driver Class Initialized
INFO - 2021-07-08 11:46:58 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:46:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:46:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:46:58 --> Encryption Class Initialized
INFO - 2021-07-08 11:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:46:58 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:46:58 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:46:58 --> Model "user_model" initialized
INFO - 2021-07-08 11:46:58 --> Model "role_model" initialized
INFO - 2021-07-08 11:46:58 --> Controller Class Initialized
INFO - 2021-07-08 11:46:58 --> Helper loaded: language_helper
INFO - 2021-07-08 11:46:58 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:46:58 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:46:58 --> Final output sent to browser
DEBUG - 2021-07-08 11:46:58 --> Total execution time: 0.0526
INFO - 2021-07-08 11:46:59 --> Config Class Initialized
INFO - 2021-07-08 11:46:59 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:46:59 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:46:59 --> Utf8 Class Initialized
INFO - 2021-07-08 11:46:59 --> URI Class Initialized
INFO - 2021-07-08 11:46:59 --> Router Class Initialized
INFO - 2021-07-08 11:46:59 --> Output Class Initialized
INFO - 2021-07-08 11:46:59 --> Security Class Initialized
DEBUG - 2021-07-08 11:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:46:59 --> Input Class Initialized
INFO - 2021-07-08 11:46:59 --> Language Class Initialized
INFO - 2021-07-08 11:46:59 --> Loader Class Initialized
INFO - 2021-07-08 11:46:59 --> Helper loaded: html_helper
INFO - 2021-07-08 11:46:59 --> Helper loaded: url_helper
INFO - 2021-07-08 11:46:59 --> Helper loaded: form_helper
INFO - 2021-07-08 11:46:59 --> Database Driver Class Initialized
INFO - 2021-07-08 11:46:59 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:46:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:46:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:46:59 --> Encryption Class Initialized
INFO - 2021-07-08 11:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:46:59 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:46:59 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:46:59 --> Model "user_model" initialized
INFO - 2021-07-08 11:46:59 --> Model "role_model" initialized
INFO - 2021-07-08 11:46:59 --> Controller Class Initialized
INFO - 2021-07-08 11:46:59 --> Helper loaded: language_helper
INFO - 2021-07-08 11:46:59 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:46:59 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:46:59 --> Final output sent to browser
DEBUG - 2021-07-08 11:46:59 --> Total execution time: 0.0594
INFO - 2021-07-08 11:50:23 --> Config Class Initialized
INFO - 2021-07-08 11:50:23 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:50:23 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:50:23 --> Utf8 Class Initialized
INFO - 2021-07-08 11:50:23 --> URI Class Initialized
INFO - 2021-07-08 11:50:23 --> Router Class Initialized
INFO - 2021-07-08 11:50:23 --> Output Class Initialized
INFO - 2021-07-08 11:50:23 --> Security Class Initialized
DEBUG - 2021-07-08 11:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:50:23 --> Input Class Initialized
INFO - 2021-07-08 11:50:23 --> Language Class Initialized
INFO - 2021-07-08 11:50:23 --> Loader Class Initialized
INFO - 2021-07-08 11:50:23 --> Helper loaded: html_helper
INFO - 2021-07-08 11:50:23 --> Helper loaded: url_helper
INFO - 2021-07-08 11:50:23 --> Helper loaded: form_helper
INFO - 2021-07-08 11:50:23 --> Database Driver Class Initialized
INFO - 2021-07-08 11:50:23 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:50:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:50:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:50:23 --> Encryption Class Initialized
INFO - 2021-07-08 11:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:50:23 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:50:23 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:50:23 --> Model "user_model" initialized
INFO - 2021-07-08 11:50:23 --> Model "role_model" initialized
INFO - 2021-07-08 11:50:23 --> Controller Class Initialized
INFO - 2021-07-08 11:50:23 --> Helper loaded: language_helper
INFO - 2021-07-08 11:50:23 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:50:23 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:50:23 --> Model "Product_model" initialized
INFO - 2021-07-08 11:50:23 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:50:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:50:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:50:23 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:50:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:50:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:50:23 --> Final output sent to browser
DEBUG - 2021-07-08 11:50:23 --> Total execution time: 0.1203
INFO - 2021-07-08 11:50:46 --> Config Class Initialized
INFO - 2021-07-08 11:50:46 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:50:46 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:50:46 --> Utf8 Class Initialized
INFO - 2021-07-08 11:50:46 --> URI Class Initialized
INFO - 2021-07-08 11:50:46 --> Router Class Initialized
INFO - 2021-07-08 11:50:46 --> Output Class Initialized
INFO - 2021-07-08 11:50:46 --> Security Class Initialized
DEBUG - 2021-07-08 11:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:50:46 --> Input Class Initialized
INFO - 2021-07-08 11:50:46 --> Language Class Initialized
INFO - 2021-07-08 11:50:46 --> Loader Class Initialized
INFO - 2021-07-08 11:50:46 --> Helper loaded: html_helper
INFO - 2021-07-08 11:50:46 --> Helper loaded: url_helper
INFO - 2021-07-08 11:50:46 --> Helper loaded: form_helper
INFO - 2021-07-08 11:50:46 --> Database Driver Class Initialized
INFO - 2021-07-08 11:50:46 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:50:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:50:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:50:46 --> Encryption Class Initialized
INFO - 2021-07-08 11:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:50:46 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:50:46 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:50:46 --> Model "user_model" initialized
INFO - 2021-07-08 11:50:46 --> Model "role_model" initialized
INFO - 2021-07-08 11:50:46 --> Controller Class Initialized
INFO - 2021-07-08 11:50:46 --> Helper loaded: language_helper
INFO - 2021-07-08 11:50:46 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:50:46 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:50:46 --> Model "Product_model" initialized
INFO - 2021-07-08 11:50:46 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:50:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:50:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:50:46 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:50:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:50:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:50:46 --> Final output sent to browser
DEBUG - 2021-07-08 11:50:46 --> Total execution time: 0.1078
INFO - 2021-07-08 11:50:50 --> Config Class Initialized
INFO - 2021-07-08 11:50:50 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:50:50 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:50:50 --> Utf8 Class Initialized
INFO - 2021-07-08 11:50:50 --> URI Class Initialized
INFO - 2021-07-08 11:50:50 --> Router Class Initialized
INFO - 2021-07-08 11:50:50 --> Output Class Initialized
INFO - 2021-07-08 11:50:50 --> Security Class Initialized
DEBUG - 2021-07-08 11:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:50:50 --> Input Class Initialized
INFO - 2021-07-08 11:50:50 --> Language Class Initialized
INFO - 2021-07-08 11:50:50 --> Loader Class Initialized
INFO - 2021-07-08 11:50:50 --> Helper loaded: html_helper
INFO - 2021-07-08 11:50:50 --> Helper loaded: url_helper
INFO - 2021-07-08 11:50:50 --> Helper loaded: form_helper
INFO - 2021-07-08 11:50:50 --> Database Driver Class Initialized
INFO - 2021-07-08 11:50:51 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:50:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:50:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:50:51 --> Encryption Class Initialized
INFO - 2021-07-08 11:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:50:51 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:50:51 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:50:51 --> Model "user_model" initialized
INFO - 2021-07-08 11:50:51 --> Model "role_model" initialized
INFO - 2021-07-08 11:50:51 --> Controller Class Initialized
INFO - 2021-07-08 11:50:51 --> Helper loaded: language_helper
INFO - 2021-07-08 11:50:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:50:51 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:50:51 --> Final output sent to browser
DEBUG - 2021-07-08 11:50:51 --> Total execution time: 0.0613
INFO - 2021-07-08 11:50:51 --> Config Class Initialized
INFO - 2021-07-08 11:50:51 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:50:51 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:50:51 --> Utf8 Class Initialized
INFO - 2021-07-08 11:50:51 --> URI Class Initialized
INFO - 2021-07-08 11:50:51 --> Router Class Initialized
INFO - 2021-07-08 11:50:51 --> Output Class Initialized
INFO - 2021-07-08 11:50:51 --> Security Class Initialized
DEBUG - 2021-07-08 11:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:50:51 --> Input Class Initialized
INFO - 2021-07-08 11:50:51 --> Language Class Initialized
INFO - 2021-07-08 11:50:51 --> Loader Class Initialized
INFO - 2021-07-08 11:50:51 --> Helper loaded: html_helper
INFO - 2021-07-08 11:50:51 --> Helper loaded: url_helper
INFO - 2021-07-08 11:50:51 --> Helper loaded: form_helper
INFO - 2021-07-08 11:50:51 --> Database Driver Class Initialized
INFO - 2021-07-08 11:50:51 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:50:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:50:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:50:51 --> Encryption Class Initialized
INFO - 2021-07-08 11:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:50:51 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:50:51 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:50:51 --> Model "user_model" initialized
INFO - 2021-07-08 11:50:51 --> Model "role_model" initialized
INFO - 2021-07-08 11:50:51 --> Controller Class Initialized
INFO - 2021-07-08 11:50:51 --> Helper loaded: language_helper
INFO - 2021-07-08 11:50:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:50:51 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:50:51 --> Final output sent to browser
DEBUG - 2021-07-08 11:50:51 --> Total execution time: 0.0625
INFO - 2021-07-08 11:51:37 --> Config Class Initialized
INFO - 2021-07-08 11:51:37 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:51:37 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:51:37 --> Utf8 Class Initialized
INFO - 2021-07-08 11:51:37 --> URI Class Initialized
INFO - 2021-07-08 11:51:37 --> Router Class Initialized
INFO - 2021-07-08 11:51:37 --> Output Class Initialized
INFO - 2021-07-08 11:51:37 --> Security Class Initialized
DEBUG - 2021-07-08 11:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:51:37 --> Input Class Initialized
INFO - 2021-07-08 11:51:37 --> Language Class Initialized
INFO - 2021-07-08 11:51:37 --> Loader Class Initialized
INFO - 2021-07-08 11:51:37 --> Helper loaded: html_helper
INFO - 2021-07-08 11:51:37 --> Helper loaded: url_helper
INFO - 2021-07-08 11:51:37 --> Helper loaded: form_helper
INFO - 2021-07-08 11:51:37 --> Database Driver Class Initialized
INFO - 2021-07-08 11:51:37 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:51:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:51:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:51:37 --> Encryption Class Initialized
INFO - 2021-07-08 11:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:51:37 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:51:37 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:51:37 --> Model "user_model" initialized
INFO - 2021-07-08 11:51:37 --> Model "role_model" initialized
INFO - 2021-07-08 11:51:37 --> Controller Class Initialized
INFO - 2021-07-08 11:51:37 --> Helper loaded: language_helper
INFO - 2021-07-08 11:51:37 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:51:37 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:51:37 --> Model "Product_model" initialized
INFO - 2021-07-08 11:51:37 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:51:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:51:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:51:37 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:51:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:51:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:51:37 --> Final output sent to browser
DEBUG - 2021-07-08 11:51:37 --> Total execution time: 0.1208
INFO - 2021-07-08 11:51:40 --> Config Class Initialized
INFO - 2021-07-08 11:51:40 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:51:40 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:51:40 --> Utf8 Class Initialized
INFO - 2021-07-08 11:51:40 --> URI Class Initialized
INFO - 2021-07-08 11:51:40 --> Router Class Initialized
INFO - 2021-07-08 11:51:40 --> Output Class Initialized
INFO - 2021-07-08 11:51:40 --> Security Class Initialized
DEBUG - 2021-07-08 11:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:51:40 --> Input Class Initialized
INFO - 2021-07-08 11:51:40 --> Language Class Initialized
INFO - 2021-07-08 11:51:40 --> Loader Class Initialized
INFO - 2021-07-08 11:51:40 --> Helper loaded: html_helper
INFO - 2021-07-08 11:51:40 --> Helper loaded: url_helper
INFO - 2021-07-08 11:51:40 --> Helper loaded: form_helper
INFO - 2021-07-08 11:51:40 --> Database Driver Class Initialized
INFO - 2021-07-08 11:51:40 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:51:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:51:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:51:40 --> Encryption Class Initialized
INFO - 2021-07-08 11:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:51:40 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:51:40 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:51:40 --> Model "user_model" initialized
INFO - 2021-07-08 11:51:40 --> Model "role_model" initialized
INFO - 2021-07-08 11:51:40 --> Controller Class Initialized
INFO - 2021-07-08 11:51:40 --> Helper loaded: language_helper
INFO - 2021-07-08 11:51:40 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:51:40 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:51:40 --> Final output sent to browser
DEBUG - 2021-07-08 11:51:40 --> Total execution time: 0.0605
INFO - 2021-07-08 11:51:40 --> Config Class Initialized
INFO - 2021-07-08 11:51:40 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:51:40 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:51:40 --> Utf8 Class Initialized
INFO - 2021-07-08 11:51:40 --> URI Class Initialized
INFO - 2021-07-08 11:51:40 --> Router Class Initialized
INFO - 2021-07-08 11:51:40 --> Output Class Initialized
INFO - 2021-07-08 11:51:40 --> Security Class Initialized
DEBUG - 2021-07-08 11:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:51:40 --> Input Class Initialized
INFO - 2021-07-08 11:51:40 --> Language Class Initialized
INFO - 2021-07-08 11:51:40 --> Loader Class Initialized
INFO - 2021-07-08 11:51:40 --> Helper loaded: html_helper
INFO - 2021-07-08 11:51:40 --> Helper loaded: url_helper
INFO - 2021-07-08 11:51:40 --> Helper loaded: form_helper
INFO - 2021-07-08 11:51:40 --> Database Driver Class Initialized
INFO - 2021-07-08 11:51:40 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:51:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:51:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:51:40 --> Encryption Class Initialized
INFO - 2021-07-08 11:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:51:40 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:51:40 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:51:40 --> Model "user_model" initialized
INFO - 2021-07-08 11:51:40 --> Model "role_model" initialized
INFO - 2021-07-08 11:51:40 --> Controller Class Initialized
INFO - 2021-07-08 11:51:40 --> Helper loaded: language_helper
INFO - 2021-07-08 11:51:40 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:51:40 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:51:40 --> Final output sent to browser
DEBUG - 2021-07-08 11:51:40 --> Total execution time: 0.0624
INFO - 2021-07-08 11:52:10 --> Config Class Initialized
INFO - 2021-07-08 11:52:10 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:52:10 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:52:10 --> Utf8 Class Initialized
INFO - 2021-07-08 11:52:10 --> URI Class Initialized
INFO - 2021-07-08 11:52:10 --> Router Class Initialized
INFO - 2021-07-08 11:52:10 --> Output Class Initialized
INFO - 2021-07-08 11:52:10 --> Security Class Initialized
DEBUG - 2021-07-08 11:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:52:10 --> Input Class Initialized
INFO - 2021-07-08 11:52:10 --> Language Class Initialized
INFO - 2021-07-08 11:52:10 --> Loader Class Initialized
INFO - 2021-07-08 11:52:10 --> Helper loaded: html_helper
INFO - 2021-07-08 11:52:10 --> Helper loaded: url_helper
INFO - 2021-07-08 11:52:10 --> Helper loaded: form_helper
INFO - 2021-07-08 11:52:10 --> Database Driver Class Initialized
INFO - 2021-07-08 11:52:10 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:52:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:52:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:52:10 --> Encryption Class Initialized
INFO - 2021-07-08 11:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:52:10 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:52:10 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:52:10 --> Model "user_model" initialized
INFO - 2021-07-08 11:52:10 --> Model "role_model" initialized
INFO - 2021-07-08 11:52:10 --> Controller Class Initialized
INFO - 2021-07-08 11:52:10 --> Helper loaded: language_helper
INFO - 2021-07-08 11:52:10 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:52:10 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:52:10 --> Model "Product_model" initialized
INFO - 2021-07-08 11:52:10 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:52:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:52:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:52:10 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:52:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:52:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:52:10 --> Final output sent to browser
DEBUG - 2021-07-08 11:52:10 --> Total execution time: 0.1196
INFO - 2021-07-08 11:52:13 --> Config Class Initialized
INFO - 2021-07-08 11:52:13 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:52:13 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:52:13 --> Utf8 Class Initialized
INFO - 2021-07-08 11:52:13 --> URI Class Initialized
INFO - 2021-07-08 11:52:13 --> Router Class Initialized
INFO - 2021-07-08 11:52:13 --> Output Class Initialized
INFO - 2021-07-08 11:52:13 --> Security Class Initialized
DEBUG - 2021-07-08 11:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:52:13 --> Input Class Initialized
INFO - 2021-07-08 11:52:13 --> Language Class Initialized
INFO - 2021-07-08 11:52:13 --> Loader Class Initialized
INFO - 2021-07-08 11:52:13 --> Helper loaded: html_helper
INFO - 2021-07-08 11:52:13 --> Helper loaded: url_helper
INFO - 2021-07-08 11:52:13 --> Helper loaded: form_helper
INFO - 2021-07-08 11:52:13 --> Database Driver Class Initialized
INFO - 2021-07-08 11:52:13 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:52:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:52:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:52:13 --> Encryption Class Initialized
INFO - 2021-07-08 11:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:52:13 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:52:13 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:52:13 --> Model "user_model" initialized
INFO - 2021-07-08 11:52:13 --> Model "role_model" initialized
INFO - 2021-07-08 11:52:13 --> Controller Class Initialized
INFO - 2021-07-08 11:52:13 --> Helper loaded: language_helper
INFO - 2021-07-08 11:52:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:52:13 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:52:13 --> Final output sent to browser
DEBUG - 2021-07-08 11:52:13 --> Total execution time: 0.0654
INFO - 2021-07-08 11:52:13 --> Config Class Initialized
INFO - 2021-07-08 11:52:13 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:52:13 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:52:13 --> Utf8 Class Initialized
INFO - 2021-07-08 11:52:13 --> URI Class Initialized
INFO - 2021-07-08 11:52:13 --> Router Class Initialized
INFO - 2021-07-08 11:52:13 --> Output Class Initialized
INFO - 2021-07-08 11:52:13 --> Security Class Initialized
DEBUG - 2021-07-08 11:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:52:13 --> Input Class Initialized
INFO - 2021-07-08 11:52:13 --> Language Class Initialized
INFO - 2021-07-08 11:52:13 --> Loader Class Initialized
INFO - 2021-07-08 11:52:13 --> Helper loaded: html_helper
INFO - 2021-07-08 11:52:13 --> Helper loaded: url_helper
INFO - 2021-07-08 11:52:13 --> Helper loaded: form_helper
INFO - 2021-07-08 11:52:13 --> Database Driver Class Initialized
INFO - 2021-07-08 11:52:14 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:52:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:52:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:52:14 --> Encryption Class Initialized
INFO - 2021-07-08 11:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:52:14 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:52:14 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:52:14 --> Model "user_model" initialized
INFO - 2021-07-08 11:52:14 --> Model "role_model" initialized
INFO - 2021-07-08 11:52:14 --> Controller Class Initialized
INFO - 2021-07-08 11:52:14 --> Helper loaded: language_helper
INFO - 2021-07-08 11:52:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:52:14 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:52:14 --> Final output sent to browser
DEBUG - 2021-07-08 11:52:14 --> Total execution time: 0.0653
INFO - 2021-07-08 11:52:32 --> Config Class Initialized
INFO - 2021-07-08 11:52:32 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:52:32 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:52:32 --> Utf8 Class Initialized
INFO - 2021-07-08 11:52:32 --> URI Class Initialized
INFO - 2021-07-08 11:52:32 --> Router Class Initialized
INFO - 2021-07-08 11:52:32 --> Output Class Initialized
INFO - 2021-07-08 11:52:32 --> Security Class Initialized
DEBUG - 2021-07-08 11:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:52:32 --> Input Class Initialized
INFO - 2021-07-08 11:52:32 --> Language Class Initialized
INFO - 2021-07-08 11:52:32 --> Loader Class Initialized
INFO - 2021-07-08 11:52:33 --> Helper loaded: html_helper
INFO - 2021-07-08 11:52:33 --> Helper loaded: url_helper
INFO - 2021-07-08 11:52:33 --> Helper loaded: form_helper
INFO - 2021-07-08 11:52:33 --> Database Driver Class Initialized
INFO - 2021-07-08 11:52:33 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:52:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:52:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:52:33 --> Encryption Class Initialized
INFO - 2021-07-08 11:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:52:33 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:52:33 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:52:33 --> Model "user_model" initialized
INFO - 2021-07-08 11:52:33 --> Model "role_model" initialized
INFO - 2021-07-08 11:52:33 --> Controller Class Initialized
INFO - 2021-07-08 11:52:33 --> Helper loaded: language_helper
INFO - 2021-07-08 11:52:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:52:33 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:52:33 --> Model "Product_model" initialized
INFO - 2021-07-08 11:52:33 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:52:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:52:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:52:33 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:52:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:52:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:52:33 --> Final output sent to browser
DEBUG - 2021-07-08 11:52:33 --> Total execution time: 0.1329
INFO - 2021-07-08 11:52:36 --> Config Class Initialized
INFO - 2021-07-08 11:52:36 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:52:36 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:52:36 --> Utf8 Class Initialized
INFO - 2021-07-08 11:52:36 --> URI Class Initialized
INFO - 2021-07-08 11:52:36 --> Router Class Initialized
INFO - 2021-07-08 11:52:36 --> Output Class Initialized
INFO - 2021-07-08 11:52:36 --> Security Class Initialized
DEBUG - 2021-07-08 11:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:52:36 --> Input Class Initialized
INFO - 2021-07-08 11:52:36 --> Language Class Initialized
INFO - 2021-07-08 11:52:36 --> Loader Class Initialized
INFO - 2021-07-08 11:52:36 --> Helper loaded: html_helper
INFO - 2021-07-08 11:52:36 --> Helper loaded: url_helper
INFO - 2021-07-08 11:52:36 --> Helper loaded: form_helper
INFO - 2021-07-08 11:52:36 --> Database Driver Class Initialized
INFO - 2021-07-08 11:52:36 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:52:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:52:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:52:36 --> Encryption Class Initialized
INFO - 2021-07-08 11:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:52:36 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:52:36 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:52:36 --> Model "user_model" initialized
INFO - 2021-07-08 11:52:36 --> Model "role_model" initialized
INFO - 2021-07-08 11:52:36 --> Controller Class Initialized
INFO - 2021-07-08 11:52:36 --> Helper loaded: language_helper
INFO - 2021-07-08 11:52:36 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:52:36 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:52:36 --> Final output sent to browser
DEBUG - 2021-07-08 11:52:36 --> Total execution time: 0.0628
INFO - 2021-07-08 11:52:36 --> Config Class Initialized
INFO - 2021-07-08 11:52:36 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:52:36 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:52:36 --> Utf8 Class Initialized
INFO - 2021-07-08 11:52:36 --> URI Class Initialized
INFO - 2021-07-08 11:52:36 --> Router Class Initialized
INFO - 2021-07-08 11:52:36 --> Output Class Initialized
INFO - 2021-07-08 11:52:36 --> Security Class Initialized
DEBUG - 2021-07-08 11:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:52:36 --> Input Class Initialized
INFO - 2021-07-08 11:52:36 --> Language Class Initialized
INFO - 2021-07-08 11:52:36 --> Loader Class Initialized
INFO - 2021-07-08 11:52:36 --> Helper loaded: html_helper
INFO - 2021-07-08 11:52:36 --> Helper loaded: url_helper
INFO - 2021-07-08 11:52:36 --> Helper loaded: form_helper
INFO - 2021-07-08 11:52:36 --> Database Driver Class Initialized
INFO - 2021-07-08 11:52:36 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:52:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:52:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:52:36 --> Encryption Class Initialized
INFO - 2021-07-08 11:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:52:36 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:52:36 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:52:36 --> Model "user_model" initialized
INFO - 2021-07-08 11:52:36 --> Model "role_model" initialized
INFO - 2021-07-08 11:52:36 --> Controller Class Initialized
INFO - 2021-07-08 11:52:36 --> Helper loaded: language_helper
INFO - 2021-07-08 11:52:36 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:52:36 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:52:36 --> Final output sent to browser
DEBUG - 2021-07-08 11:52:36 --> Total execution time: 0.0636
INFO - 2021-07-08 11:52:57 --> Config Class Initialized
INFO - 2021-07-08 11:52:57 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:52:57 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:52:57 --> Utf8 Class Initialized
INFO - 2021-07-08 11:52:57 --> URI Class Initialized
INFO - 2021-07-08 11:52:57 --> Router Class Initialized
INFO - 2021-07-08 11:52:57 --> Output Class Initialized
INFO - 2021-07-08 11:52:57 --> Security Class Initialized
DEBUG - 2021-07-08 11:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:52:57 --> Input Class Initialized
INFO - 2021-07-08 11:52:57 --> Language Class Initialized
INFO - 2021-07-08 11:52:57 --> Loader Class Initialized
INFO - 2021-07-08 11:52:57 --> Helper loaded: html_helper
INFO - 2021-07-08 11:52:57 --> Helper loaded: url_helper
INFO - 2021-07-08 11:52:57 --> Helper loaded: form_helper
INFO - 2021-07-08 11:52:57 --> Database Driver Class Initialized
INFO - 2021-07-08 11:52:57 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:52:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:52:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:52:57 --> Encryption Class Initialized
INFO - 2021-07-08 11:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:52:57 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:52:57 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:52:57 --> Model "user_model" initialized
INFO - 2021-07-08 11:52:57 --> Model "role_model" initialized
INFO - 2021-07-08 11:52:57 --> Controller Class Initialized
INFO - 2021-07-08 11:52:57 --> Helper loaded: language_helper
INFO - 2021-07-08 11:52:57 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:52:57 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:52:57 --> Model "Product_model" initialized
INFO - 2021-07-08 11:52:57 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:52:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:52:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:52:57 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:52:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:52:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:52:57 --> Final output sent to browser
DEBUG - 2021-07-08 11:52:57 --> Total execution time: 0.1105
INFO - 2021-07-08 11:52:59 --> Config Class Initialized
INFO - 2021-07-08 11:52:59 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:52:59 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:52:59 --> Utf8 Class Initialized
INFO - 2021-07-08 11:52:59 --> URI Class Initialized
INFO - 2021-07-08 11:52:59 --> Router Class Initialized
INFO - 2021-07-08 11:52:59 --> Output Class Initialized
INFO - 2021-07-08 11:52:59 --> Security Class Initialized
DEBUG - 2021-07-08 11:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:52:59 --> Input Class Initialized
INFO - 2021-07-08 11:52:59 --> Language Class Initialized
INFO - 2021-07-08 11:52:59 --> Loader Class Initialized
INFO - 2021-07-08 11:52:59 --> Helper loaded: html_helper
INFO - 2021-07-08 11:52:59 --> Helper loaded: url_helper
INFO - 2021-07-08 11:52:59 --> Helper loaded: form_helper
INFO - 2021-07-08 11:52:59 --> Database Driver Class Initialized
INFO - 2021-07-08 11:52:59 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:52:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:52:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:52:59 --> Encryption Class Initialized
INFO - 2021-07-08 11:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:52:59 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:52:59 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:52:59 --> Model "user_model" initialized
INFO - 2021-07-08 11:52:59 --> Model "role_model" initialized
INFO - 2021-07-08 11:52:59 --> Controller Class Initialized
INFO - 2021-07-08 11:52:59 --> Helper loaded: language_helper
INFO - 2021-07-08 11:52:59 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:52:59 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:52:59 --> Final output sent to browser
DEBUG - 2021-07-08 11:52:59 --> Total execution time: 0.0523
INFO - 2021-07-08 11:52:59 --> Config Class Initialized
INFO - 2021-07-08 11:52:59 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:52:59 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:52:59 --> Utf8 Class Initialized
INFO - 2021-07-08 11:52:59 --> URI Class Initialized
INFO - 2021-07-08 11:52:59 --> Router Class Initialized
INFO - 2021-07-08 11:52:59 --> Output Class Initialized
INFO - 2021-07-08 11:52:59 --> Security Class Initialized
DEBUG - 2021-07-08 11:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:52:59 --> Input Class Initialized
INFO - 2021-07-08 11:52:59 --> Language Class Initialized
INFO - 2021-07-08 11:52:59 --> Loader Class Initialized
INFO - 2021-07-08 11:52:59 --> Helper loaded: html_helper
INFO - 2021-07-08 11:52:59 --> Helper loaded: url_helper
INFO - 2021-07-08 11:52:59 --> Helper loaded: form_helper
INFO - 2021-07-08 11:52:59 --> Database Driver Class Initialized
INFO - 2021-07-08 11:52:59 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:52:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:52:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:52:59 --> Encryption Class Initialized
INFO - 2021-07-08 11:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:52:59 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:52:59 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:52:59 --> Model "user_model" initialized
INFO - 2021-07-08 11:52:59 --> Model "role_model" initialized
INFO - 2021-07-08 11:52:59 --> Controller Class Initialized
INFO - 2021-07-08 11:52:59 --> Helper loaded: language_helper
INFO - 2021-07-08 11:52:59 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:52:59 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:52:59 --> Final output sent to browser
DEBUG - 2021-07-08 11:52:59 --> Total execution time: 0.0539
INFO - 2021-07-08 11:53:42 --> Config Class Initialized
INFO - 2021-07-08 11:53:42 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:53:42 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:53:42 --> Utf8 Class Initialized
INFO - 2021-07-08 11:53:42 --> URI Class Initialized
INFO - 2021-07-08 11:53:42 --> Router Class Initialized
INFO - 2021-07-08 11:53:42 --> Output Class Initialized
INFO - 2021-07-08 11:53:42 --> Security Class Initialized
DEBUG - 2021-07-08 11:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:53:42 --> Input Class Initialized
INFO - 2021-07-08 11:53:42 --> Language Class Initialized
INFO - 2021-07-08 11:53:42 --> Loader Class Initialized
INFO - 2021-07-08 11:53:42 --> Helper loaded: html_helper
INFO - 2021-07-08 11:53:42 --> Helper loaded: url_helper
INFO - 2021-07-08 11:53:42 --> Helper loaded: form_helper
INFO - 2021-07-08 11:53:42 --> Database Driver Class Initialized
INFO - 2021-07-08 11:53:42 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:53:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:53:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:53:42 --> Encryption Class Initialized
INFO - 2021-07-08 11:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:53:42 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:53:42 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:53:42 --> Model "user_model" initialized
INFO - 2021-07-08 11:53:42 --> Model "role_model" initialized
INFO - 2021-07-08 11:53:42 --> Controller Class Initialized
INFO - 2021-07-08 11:53:42 --> Helper loaded: language_helper
INFO - 2021-07-08 11:53:42 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:53:42 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:53:42 --> Model "Product_model" initialized
INFO - 2021-07-08 11:53:42 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:53:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:53:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:53:42 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:53:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:53:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:53:42 --> Final output sent to browser
DEBUG - 2021-07-08 11:53:42 --> Total execution time: 0.1203
INFO - 2021-07-08 11:53:45 --> Config Class Initialized
INFO - 2021-07-08 11:53:45 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:53:45 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:53:45 --> Utf8 Class Initialized
INFO - 2021-07-08 11:53:45 --> URI Class Initialized
INFO - 2021-07-08 11:53:45 --> Router Class Initialized
INFO - 2021-07-08 11:53:45 --> Output Class Initialized
INFO - 2021-07-08 11:53:45 --> Security Class Initialized
DEBUG - 2021-07-08 11:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:53:45 --> Input Class Initialized
INFO - 2021-07-08 11:53:45 --> Language Class Initialized
INFO - 2021-07-08 11:53:45 --> Loader Class Initialized
INFO - 2021-07-08 11:53:45 --> Helper loaded: html_helper
INFO - 2021-07-08 11:53:45 --> Helper loaded: url_helper
INFO - 2021-07-08 11:53:45 --> Helper loaded: form_helper
INFO - 2021-07-08 11:53:45 --> Database Driver Class Initialized
INFO - 2021-07-08 11:53:45 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:53:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:53:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:53:45 --> Encryption Class Initialized
INFO - 2021-07-08 11:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:53:45 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:53:45 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:53:45 --> Model "user_model" initialized
INFO - 2021-07-08 11:53:45 --> Model "role_model" initialized
INFO - 2021-07-08 11:53:45 --> Controller Class Initialized
INFO - 2021-07-08 11:53:45 --> Helper loaded: language_helper
INFO - 2021-07-08 11:53:45 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:53:45 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:53:45 --> Final output sent to browser
DEBUG - 2021-07-08 11:53:45 --> Total execution time: 0.0612
INFO - 2021-07-08 11:53:45 --> Config Class Initialized
INFO - 2021-07-08 11:53:45 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:53:45 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:53:45 --> Utf8 Class Initialized
INFO - 2021-07-08 11:53:45 --> URI Class Initialized
INFO - 2021-07-08 11:53:45 --> Router Class Initialized
INFO - 2021-07-08 11:53:45 --> Output Class Initialized
INFO - 2021-07-08 11:53:45 --> Security Class Initialized
DEBUG - 2021-07-08 11:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:53:45 --> Input Class Initialized
INFO - 2021-07-08 11:53:45 --> Language Class Initialized
INFO - 2021-07-08 11:53:45 --> Loader Class Initialized
INFO - 2021-07-08 11:53:45 --> Helper loaded: html_helper
INFO - 2021-07-08 11:53:45 --> Helper loaded: url_helper
INFO - 2021-07-08 11:53:45 --> Helper loaded: form_helper
INFO - 2021-07-08 11:53:45 --> Database Driver Class Initialized
INFO - 2021-07-08 11:53:45 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:53:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:53:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:53:45 --> Encryption Class Initialized
INFO - 2021-07-08 11:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:53:45 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:53:45 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:53:45 --> Model "user_model" initialized
INFO - 2021-07-08 11:53:45 --> Model "role_model" initialized
INFO - 2021-07-08 11:53:45 --> Controller Class Initialized
INFO - 2021-07-08 11:53:45 --> Helper loaded: language_helper
INFO - 2021-07-08 11:53:45 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:53:45 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:53:45 --> Final output sent to browser
DEBUG - 2021-07-08 11:53:45 --> Total execution time: 0.0630
INFO - 2021-07-08 11:54:10 --> Config Class Initialized
INFO - 2021-07-08 11:54:10 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:54:10 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:54:10 --> Utf8 Class Initialized
INFO - 2021-07-08 11:54:10 --> URI Class Initialized
INFO - 2021-07-08 11:54:10 --> Router Class Initialized
INFO - 2021-07-08 11:54:10 --> Output Class Initialized
INFO - 2021-07-08 11:54:10 --> Security Class Initialized
DEBUG - 2021-07-08 11:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:54:10 --> Input Class Initialized
INFO - 2021-07-08 11:54:10 --> Language Class Initialized
INFO - 2021-07-08 11:54:10 --> Loader Class Initialized
INFO - 2021-07-08 11:54:10 --> Helper loaded: html_helper
INFO - 2021-07-08 11:54:10 --> Helper loaded: url_helper
INFO - 2021-07-08 11:54:10 --> Helper loaded: form_helper
INFO - 2021-07-08 11:54:10 --> Database Driver Class Initialized
INFO - 2021-07-08 11:54:10 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:54:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:54:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:54:10 --> Encryption Class Initialized
INFO - 2021-07-08 11:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:54:10 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:54:10 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:54:10 --> Model "user_model" initialized
INFO - 2021-07-08 11:54:10 --> Model "role_model" initialized
INFO - 2021-07-08 11:54:10 --> Controller Class Initialized
INFO - 2021-07-08 11:54:10 --> Helper loaded: language_helper
INFO - 2021-07-08 11:54:10 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:54:10 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:54:10 --> Model "Product_model" initialized
INFO - 2021-07-08 11:54:10 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:54:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:54:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:54:10 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:54:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:54:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:54:10 --> Final output sent to browser
DEBUG - 2021-07-08 11:54:10 --> Total execution time: 0.1128
INFO - 2021-07-08 11:54:14 --> Config Class Initialized
INFO - 2021-07-08 11:54:14 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:54:14 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:54:14 --> Utf8 Class Initialized
INFO - 2021-07-08 11:54:14 --> URI Class Initialized
INFO - 2021-07-08 11:54:14 --> Router Class Initialized
INFO - 2021-07-08 11:54:14 --> Output Class Initialized
INFO - 2021-07-08 11:54:14 --> Security Class Initialized
DEBUG - 2021-07-08 11:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:54:14 --> Input Class Initialized
INFO - 2021-07-08 11:54:14 --> Language Class Initialized
INFO - 2021-07-08 11:54:14 --> Loader Class Initialized
INFO - 2021-07-08 11:54:14 --> Helper loaded: html_helper
INFO - 2021-07-08 11:54:14 --> Helper loaded: url_helper
INFO - 2021-07-08 11:54:14 --> Helper loaded: form_helper
INFO - 2021-07-08 11:54:14 --> Database Driver Class Initialized
INFO - 2021-07-08 11:54:14 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:54:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:54:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:54:14 --> Encryption Class Initialized
INFO - 2021-07-08 11:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:54:14 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:54:14 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:54:14 --> Model "user_model" initialized
INFO - 2021-07-08 11:54:14 --> Model "role_model" initialized
INFO - 2021-07-08 11:54:14 --> Controller Class Initialized
INFO - 2021-07-08 11:54:14 --> Helper loaded: language_helper
INFO - 2021-07-08 11:54:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:54:14 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:54:14 --> Final output sent to browser
DEBUG - 2021-07-08 11:54:14 --> Total execution time: 0.0694
INFO - 2021-07-08 11:54:14 --> Config Class Initialized
INFO - 2021-07-08 11:54:14 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:54:14 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:54:14 --> Utf8 Class Initialized
INFO - 2021-07-08 11:54:14 --> URI Class Initialized
INFO - 2021-07-08 11:54:14 --> Router Class Initialized
INFO - 2021-07-08 11:54:14 --> Output Class Initialized
INFO - 2021-07-08 11:54:14 --> Security Class Initialized
DEBUG - 2021-07-08 11:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:54:14 --> Input Class Initialized
INFO - 2021-07-08 11:54:14 --> Language Class Initialized
INFO - 2021-07-08 11:54:14 --> Loader Class Initialized
INFO - 2021-07-08 11:54:14 --> Helper loaded: html_helper
INFO - 2021-07-08 11:54:14 --> Helper loaded: url_helper
INFO - 2021-07-08 11:54:14 --> Helper loaded: form_helper
INFO - 2021-07-08 11:54:14 --> Database Driver Class Initialized
INFO - 2021-07-08 11:54:14 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:54:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:54:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:54:14 --> Encryption Class Initialized
INFO - 2021-07-08 11:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:54:14 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:54:14 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:54:14 --> Model "user_model" initialized
INFO - 2021-07-08 11:54:14 --> Model "role_model" initialized
INFO - 2021-07-08 11:54:14 --> Controller Class Initialized
INFO - 2021-07-08 11:54:14 --> Helper loaded: language_helper
INFO - 2021-07-08 11:54:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:54:14 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:54:14 --> Final output sent to browser
DEBUG - 2021-07-08 11:54:14 --> Total execution time: 0.0680
INFO - 2021-07-08 11:55:23 --> Config Class Initialized
INFO - 2021-07-08 11:55:23 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:55:23 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:55:23 --> Utf8 Class Initialized
INFO - 2021-07-08 11:55:23 --> URI Class Initialized
INFO - 2021-07-08 11:55:23 --> Router Class Initialized
INFO - 2021-07-08 11:55:23 --> Output Class Initialized
INFO - 2021-07-08 11:55:23 --> Security Class Initialized
DEBUG - 2021-07-08 11:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:55:23 --> Input Class Initialized
INFO - 2021-07-08 11:55:23 --> Language Class Initialized
INFO - 2021-07-08 11:55:23 --> Loader Class Initialized
INFO - 2021-07-08 11:55:23 --> Helper loaded: html_helper
INFO - 2021-07-08 11:55:23 --> Helper loaded: url_helper
INFO - 2021-07-08 11:55:23 --> Helper loaded: form_helper
INFO - 2021-07-08 11:55:23 --> Database Driver Class Initialized
INFO - 2021-07-08 11:55:23 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:55:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:55:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:55:23 --> Encryption Class Initialized
INFO - 2021-07-08 11:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:55:23 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:55:23 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:55:23 --> Model "user_model" initialized
INFO - 2021-07-08 11:55:23 --> Model "role_model" initialized
INFO - 2021-07-08 11:55:23 --> Controller Class Initialized
INFO - 2021-07-08 11:55:23 --> Helper loaded: language_helper
INFO - 2021-07-08 11:55:23 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:55:23 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:55:23 --> Model "Product_model" initialized
INFO - 2021-07-08 11:55:23 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:55:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:55:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:55:23 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:55:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:55:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:55:23 --> Final output sent to browser
DEBUG - 2021-07-08 11:55:23 --> Total execution time: 0.1133
INFO - 2021-07-08 11:55:26 --> Config Class Initialized
INFO - 2021-07-08 11:55:26 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:55:26 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:55:26 --> Utf8 Class Initialized
INFO - 2021-07-08 11:55:26 --> URI Class Initialized
INFO - 2021-07-08 11:55:26 --> Router Class Initialized
INFO - 2021-07-08 11:55:26 --> Output Class Initialized
INFO - 2021-07-08 11:55:26 --> Security Class Initialized
DEBUG - 2021-07-08 11:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:55:26 --> Input Class Initialized
INFO - 2021-07-08 11:55:26 --> Language Class Initialized
INFO - 2021-07-08 11:55:26 --> Loader Class Initialized
INFO - 2021-07-08 11:55:26 --> Helper loaded: html_helper
INFO - 2021-07-08 11:55:26 --> Helper loaded: url_helper
INFO - 2021-07-08 11:55:26 --> Helper loaded: form_helper
INFO - 2021-07-08 11:55:26 --> Database Driver Class Initialized
INFO - 2021-07-08 11:55:26 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:55:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:55:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:55:26 --> Encryption Class Initialized
INFO - 2021-07-08 11:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:55:26 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:55:26 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:55:26 --> Model "user_model" initialized
INFO - 2021-07-08 11:55:26 --> Model "role_model" initialized
INFO - 2021-07-08 11:55:26 --> Controller Class Initialized
INFO - 2021-07-08 11:55:26 --> Helper loaded: language_helper
INFO - 2021-07-08 11:55:26 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:55:26 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:55:26 --> Final output sent to browser
DEBUG - 2021-07-08 11:55:26 --> Total execution time: 0.0583
INFO - 2021-07-08 11:55:39 --> Config Class Initialized
INFO - 2021-07-08 11:55:39 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:55:39 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:55:39 --> Utf8 Class Initialized
INFO - 2021-07-08 11:55:39 --> URI Class Initialized
INFO - 2021-07-08 11:55:39 --> Router Class Initialized
INFO - 2021-07-08 11:55:39 --> Output Class Initialized
INFO - 2021-07-08 11:55:39 --> Security Class Initialized
DEBUG - 2021-07-08 11:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:55:39 --> Input Class Initialized
INFO - 2021-07-08 11:55:39 --> Language Class Initialized
INFO - 2021-07-08 11:55:39 --> Loader Class Initialized
INFO - 2021-07-08 11:55:39 --> Helper loaded: html_helper
INFO - 2021-07-08 11:55:39 --> Helper loaded: url_helper
INFO - 2021-07-08 11:55:39 --> Helper loaded: form_helper
INFO - 2021-07-08 11:55:39 --> Database Driver Class Initialized
INFO - 2021-07-08 11:55:39 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:55:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:55:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:55:39 --> Encryption Class Initialized
INFO - 2021-07-08 11:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:55:39 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:55:39 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:55:39 --> Model "user_model" initialized
INFO - 2021-07-08 11:55:39 --> Model "role_model" initialized
INFO - 2021-07-08 11:55:39 --> Controller Class Initialized
INFO - 2021-07-08 11:55:39 --> Helper loaded: language_helper
INFO - 2021-07-08 11:55:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:55:39 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:55:39 --> Model "Product_model" initialized
INFO - 2021-07-08 11:55:39 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:55:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:55:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:55:39 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:55:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:55:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:55:39 --> Final output sent to browser
DEBUG - 2021-07-08 11:55:39 --> Total execution time: 0.1079
INFO - 2021-07-08 11:55:42 --> Config Class Initialized
INFO - 2021-07-08 11:55:42 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:55:42 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:55:42 --> Utf8 Class Initialized
INFO - 2021-07-08 11:55:42 --> URI Class Initialized
INFO - 2021-07-08 11:55:42 --> Router Class Initialized
INFO - 2021-07-08 11:55:42 --> Output Class Initialized
INFO - 2021-07-08 11:55:42 --> Security Class Initialized
DEBUG - 2021-07-08 11:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:55:42 --> Input Class Initialized
INFO - 2021-07-08 11:55:42 --> Language Class Initialized
INFO - 2021-07-08 11:55:42 --> Loader Class Initialized
INFO - 2021-07-08 11:55:42 --> Helper loaded: html_helper
INFO - 2021-07-08 11:55:42 --> Helper loaded: url_helper
INFO - 2021-07-08 11:55:42 --> Helper loaded: form_helper
INFO - 2021-07-08 11:55:42 --> Database Driver Class Initialized
INFO - 2021-07-08 11:55:42 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:55:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:55:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:55:42 --> Encryption Class Initialized
INFO - 2021-07-08 11:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:55:42 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:55:42 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:55:42 --> Model "user_model" initialized
INFO - 2021-07-08 11:55:42 --> Model "role_model" initialized
INFO - 2021-07-08 11:55:42 --> Controller Class Initialized
INFO - 2021-07-08 11:55:42 --> Helper loaded: language_helper
INFO - 2021-07-08 11:55:42 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:55:42 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:55:42 --> Final output sent to browser
DEBUG - 2021-07-08 11:55:42 --> Total execution time: 0.0566
INFO - 2021-07-08 11:55:42 --> Config Class Initialized
INFO - 2021-07-08 11:55:42 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:55:42 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:55:42 --> Utf8 Class Initialized
INFO - 2021-07-08 11:55:42 --> URI Class Initialized
INFO - 2021-07-08 11:55:42 --> Router Class Initialized
INFO - 2021-07-08 11:55:42 --> Output Class Initialized
INFO - 2021-07-08 11:55:42 --> Security Class Initialized
DEBUG - 2021-07-08 11:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:55:42 --> Input Class Initialized
INFO - 2021-07-08 11:55:42 --> Language Class Initialized
INFO - 2021-07-08 11:55:42 --> Loader Class Initialized
INFO - 2021-07-08 11:55:42 --> Helper loaded: html_helper
INFO - 2021-07-08 11:55:42 --> Helper loaded: url_helper
INFO - 2021-07-08 11:55:42 --> Helper loaded: form_helper
INFO - 2021-07-08 11:55:42 --> Database Driver Class Initialized
INFO - 2021-07-08 11:55:42 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:55:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:55:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:55:42 --> Encryption Class Initialized
INFO - 2021-07-08 11:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:55:42 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:55:42 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:55:42 --> Model "user_model" initialized
INFO - 2021-07-08 11:55:42 --> Model "role_model" initialized
INFO - 2021-07-08 11:55:42 --> Controller Class Initialized
INFO - 2021-07-08 11:55:42 --> Helper loaded: language_helper
INFO - 2021-07-08 11:55:42 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:55:42 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:55:42 --> Final output sent to browser
DEBUG - 2021-07-08 11:55:42 --> Total execution time: 0.0560
INFO - 2021-07-08 11:56:09 --> Config Class Initialized
INFO - 2021-07-08 11:56:09 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:56:09 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:56:09 --> Utf8 Class Initialized
INFO - 2021-07-08 11:56:09 --> URI Class Initialized
INFO - 2021-07-08 11:56:09 --> Router Class Initialized
INFO - 2021-07-08 11:56:09 --> Output Class Initialized
INFO - 2021-07-08 11:56:09 --> Security Class Initialized
DEBUG - 2021-07-08 11:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:56:09 --> Input Class Initialized
INFO - 2021-07-08 11:56:09 --> Language Class Initialized
INFO - 2021-07-08 11:56:09 --> Loader Class Initialized
INFO - 2021-07-08 11:56:09 --> Helper loaded: html_helper
INFO - 2021-07-08 11:56:09 --> Helper loaded: url_helper
INFO - 2021-07-08 11:56:09 --> Helper loaded: form_helper
INFO - 2021-07-08 11:56:09 --> Database Driver Class Initialized
INFO - 2021-07-08 11:56:09 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:56:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:56:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:56:09 --> Encryption Class Initialized
INFO - 2021-07-08 11:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:56:09 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:56:09 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:56:09 --> Model "user_model" initialized
INFO - 2021-07-08 11:56:09 --> Model "role_model" initialized
INFO - 2021-07-08 11:56:09 --> Controller Class Initialized
INFO - 2021-07-08 11:56:09 --> Helper loaded: language_helper
INFO - 2021-07-08 11:56:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:56:09 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:56:09 --> Model "Product_model" initialized
INFO - 2021-07-08 11:56:09 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:56:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:56:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:56:09 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:56:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:56:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:56:09 --> Final output sent to browser
DEBUG - 2021-07-08 11:56:09 --> Total execution time: 0.1231
INFO - 2021-07-08 11:56:12 --> Config Class Initialized
INFO - 2021-07-08 11:56:12 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:56:12 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:56:12 --> Utf8 Class Initialized
INFO - 2021-07-08 11:56:12 --> URI Class Initialized
INFO - 2021-07-08 11:56:12 --> Router Class Initialized
INFO - 2021-07-08 11:56:12 --> Output Class Initialized
INFO - 2021-07-08 11:56:12 --> Security Class Initialized
DEBUG - 2021-07-08 11:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:56:12 --> Input Class Initialized
INFO - 2021-07-08 11:56:12 --> Language Class Initialized
INFO - 2021-07-08 11:56:12 --> Loader Class Initialized
INFO - 2021-07-08 11:56:12 --> Helper loaded: html_helper
INFO - 2021-07-08 11:56:12 --> Helper loaded: url_helper
INFO - 2021-07-08 11:56:12 --> Helper loaded: form_helper
INFO - 2021-07-08 11:56:12 --> Database Driver Class Initialized
INFO - 2021-07-08 11:56:12 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:56:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:56:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:56:12 --> Encryption Class Initialized
INFO - 2021-07-08 11:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:56:12 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:56:12 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:56:12 --> Model "user_model" initialized
INFO - 2021-07-08 11:56:12 --> Model "role_model" initialized
INFO - 2021-07-08 11:56:12 --> Controller Class Initialized
INFO - 2021-07-08 11:56:12 --> Helper loaded: language_helper
INFO - 2021-07-08 11:56:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:56:12 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:56:12 --> Final output sent to browser
DEBUG - 2021-07-08 11:56:12 --> Total execution time: 0.0645
INFO - 2021-07-08 11:56:12 --> Config Class Initialized
INFO - 2021-07-08 11:56:12 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:56:12 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:56:12 --> Utf8 Class Initialized
INFO - 2021-07-08 11:56:12 --> URI Class Initialized
INFO - 2021-07-08 11:56:12 --> Router Class Initialized
INFO - 2021-07-08 11:56:12 --> Output Class Initialized
INFO - 2021-07-08 11:56:12 --> Security Class Initialized
DEBUG - 2021-07-08 11:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:56:12 --> Input Class Initialized
INFO - 2021-07-08 11:56:12 --> Language Class Initialized
INFO - 2021-07-08 11:56:12 --> Loader Class Initialized
INFO - 2021-07-08 11:56:12 --> Helper loaded: html_helper
INFO - 2021-07-08 11:56:12 --> Helper loaded: url_helper
INFO - 2021-07-08 11:56:12 --> Helper loaded: form_helper
INFO - 2021-07-08 11:56:12 --> Database Driver Class Initialized
INFO - 2021-07-08 11:56:12 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:56:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:56:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:56:12 --> Encryption Class Initialized
INFO - 2021-07-08 11:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:56:12 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:56:12 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:56:12 --> Model "user_model" initialized
INFO - 2021-07-08 11:56:12 --> Model "role_model" initialized
INFO - 2021-07-08 11:56:12 --> Controller Class Initialized
INFO - 2021-07-08 11:56:12 --> Helper loaded: language_helper
INFO - 2021-07-08 11:56:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:56:12 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:56:12 --> Final output sent to browser
DEBUG - 2021-07-08 11:56:12 --> Total execution time: 0.0635
INFO - 2021-07-08 11:56:30 --> Config Class Initialized
INFO - 2021-07-08 11:56:30 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:56:30 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:56:30 --> Utf8 Class Initialized
INFO - 2021-07-08 11:56:30 --> URI Class Initialized
INFO - 2021-07-08 11:56:30 --> Router Class Initialized
INFO - 2021-07-08 11:56:30 --> Output Class Initialized
INFO - 2021-07-08 11:56:30 --> Security Class Initialized
DEBUG - 2021-07-08 11:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:56:30 --> Input Class Initialized
INFO - 2021-07-08 11:56:30 --> Language Class Initialized
INFO - 2021-07-08 11:56:30 --> Loader Class Initialized
INFO - 2021-07-08 11:56:30 --> Helper loaded: html_helper
INFO - 2021-07-08 11:56:30 --> Helper loaded: url_helper
INFO - 2021-07-08 11:56:30 --> Helper loaded: form_helper
INFO - 2021-07-08 11:56:30 --> Database Driver Class Initialized
INFO - 2021-07-08 11:56:30 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:56:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:56:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:56:30 --> Encryption Class Initialized
INFO - 2021-07-08 11:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:56:30 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:56:30 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:56:30 --> Model "user_model" initialized
INFO - 2021-07-08 11:56:30 --> Model "role_model" initialized
INFO - 2021-07-08 11:56:30 --> Controller Class Initialized
INFO - 2021-07-08 11:56:30 --> Helper loaded: language_helper
INFO - 2021-07-08 11:56:30 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:56:30 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:56:30 --> Model "Product_model" initialized
INFO - 2021-07-08 11:56:30 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:56:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:56:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:56:30 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:56:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:56:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:56:30 --> Final output sent to browser
DEBUG - 2021-07-08 11:56:30 --> Total execution time: 0.1140
INFO - 2021-07-08 11:56:33 --> Config Class Initialized
INFO - 2021-07-08 11:56:33 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:56:33 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:56:33 --> Utf8 Class Initialized
INFO - 2021-07-08 11:56:33 --> URI Class Initialized
INFO - 2021-07-08 11:56:33 --> Router Class Initialized
INFO - 2021-07-08 11:56:33 --> Output Class Initialized
INFO - 2021-07-08 11:56:33 --> Security Class Initialized
DEBUG - 2021-07-08 11:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:56:33 --> Input Class Initialized
INFO - 2021-07-08 11:56:33 --> Language Class Initialized
INFO - 2021-07-08 11:56:33 --> Loader Class Initialized
INFO - 2021-07-08 11:56:33 --> Helper loaded: html_helper
INFO - 2021-07-08 11:56:33 --> Helper loaded: url_helper
INFO - 2021-07-08 11:56:33 --> Helper loaded: form_helper
INFO - 2021-07-08 11:56:33 --> Database Driver Class Initialized
INFO - 2021-07-08 11:56:33 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:56:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:56:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:56:33 --> Encryption Class Initialized
INFO - 2021-07-08 11:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:56:33 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:56:33 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:56:33 --> Model "user_model" initialized
INFO - 2021-07-08 11:56:33 --> Model "role_model" initialized
INFO - 2021-07-08 11:56:33 --> Controller Class Initialized
INFO - 2021-07-08 11:56:33 --> Helper loaded: language_helper
INFO - 2021-07-08 11:56:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:56:33 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:56:33 --> Final output sent to browser
DEBUG - 2021-07-08 11:56:33 --> Total execution time: 0.0640
INFO - 2021-07-08 11:56:33 --> Config Class Initialized
INFO - 2021-07-08 11:56:33 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:56:33 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:56:33 --> Utf8 Class Initialized
INFO - 2021-07-08 11:56:33 --> URI Class Initialized
INFO - 2021-07-08 11:56:33 --> Router Class Initialized
INFO - 2021-07-08 11:56:33 --> Output Class Initialized
INFO - 2021-07-08 11:56:33 --> Security Class Initialized
DEBUG - 2021-07-08 11:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:56:33 --> Input Class Initialized
INFO - 2021-07-08 11:56:33 --> Language Class Initialized
INFO - 2021-07-08 11:56:33 --> Loader Class Initialized
INFO - 2021-07-08 11:56:33 --> Helper loaded: html_helper
INFO - 2021-07-08 11:56:33 --> Helper loaded: url_helper
INFO - 2021-07-08 11:56:33 --> Helper loaded: form_helper
INFO - 2021-07-08 11:56:33 --> Database Driver Class Initialized
INFO - 2021-07-08 11:56:33 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:56:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:56:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:56:33 --> Encryption Class Initialized
INFO - 2021-07-08 11:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:56:33 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:56:33 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:56:33 --> Model "user_model" initialized
INFO - 2021-07-08 11:56:33 --> Model "role_model" initialized
INFO - 2021-07-08 11:56:33 --> Controller Class Initialized
INFO - 2021-07-08 11:56:33 --> Helper loaded: language_helper
INFO - 2021-07-08 11:56:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:56:33 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:56:33 --> Final output sent to browser
DEBUG - 2021-07-08 11:56:33 --> Total execution time: 0.0662
INFO - 2021-07-08 11:57:03 --> Config Class Initialized
INFO - 2021-07-08 11:57:03 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:57:03 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:57:03 --> Utf8 Class Initialized
INFO - 2021-07-08 11:57:03 --> URI Class Initialized
INFO - 2021-07-08 11:57:03 --> Router Class Initialized
INFO - 2021-07-08 11:57:03 --> Output Class Initialized
INFO - 2021-07-08 11:57:03 --> Security Class Initialized
DEBUG - 2021-07-08 11:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:57:03 --> Input Class Initialized
INFO - 2021-07-08 11:57:03 --> Language Class Initialized
INFO - 2021-07-08 11:57:03 --> Loader Class Initialized
INFO - 2021-07-08 11:57:03 --> Helper loaded: html_helper
INFO - 2021-07-08 11:57:03 --> Helper loaded: url_helper
INFO - 2021-07-08 11:57:03 --> Helper loaded: form_helper
INFO - 2021-07-08 11:57:03 --> Database Driver Class Initialized
INFO - 2021-07-08 11:57:03 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:57:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:57:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:57:03 --> Encryption Class Initialized
INFO - 2021-07-08 11:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:57:03 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:57:03 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:57:03 --> Model "user_model" initialized
INFO - 2021-07-08 11:57:03 --> Model "role_model" initialized
INFO - 2021-07-08 11:57:03 --> Controller Class Initialized
INFO - 2021-07-08 11:57:03 --> Helper loaded: language_helper
INFO - 2021-07-08 11:57:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:57:03 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:57:03 --> Model "Product_model" initialized
INFO - 2021-07-08 11:57:03 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:57:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:57:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:57:03 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:57:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:57:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:57:03 --> Final output sent to browser
DEBUG - 2021-07-08 11:57:03 --> Total execution time: 0.1196
INFO - 2021-07-08 11:57:06 --> Config Class Initialized
INFO - 2021-07-08 11:57:06 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:57:06 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:57:06 --> Utf8 Class Initialized
INFO - 2021-07-08 11:57:06 --> URI Class Initialized
INFO - 2021-07-08 11:57:06 --> Router Class Initialized
INFO - 2021-07-08 11:57:06 --> Output Class Initialized
INFO - 2021-07-08 11:57:06 --> Security Class Initialized
DEBUG - 2021-07-08 11:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:57:06 --> Input Class Initialized
INFO - 2021-07-08 11:57:06 --> Language Class Initialized
INFO - 2021-07-08 11:57:06 --> Loader Class Initialized
INFO - 2021-07-08 11:57:06 --> Helper loaded: html_helper
INFO - 2021-07-08 11:57:06 --> Helper loaded: url_helper
INFO - 2021-07-08 11:57:06 --> Helper loaded: form_helper
INFO - 2021-07-08 11:57:06 --> Database Driver Class Initialized
INFO - 2021-07-08 11:57:06 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:57:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:57:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:57:06 --> Encryption Class Initialized
INFO - 2021-07-08 11:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:57:06 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:57:06 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:57:06 --> Model "user_model" initialized
INFO - 2021-07-08 11:57:06 --> Model "role_model" initialized
INFO - 2021-07-08 11:57:06 --> Controller Class Initialized
INFO - 2021-07-08 11:57:06 --> Helper loaded: language_helper
INFO - 2021-07-08 11:57:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:57:06 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:57:06 --> Final output sent to browser
DEBUG - 2021-07-08 11:57:06 --> Total execution time: 0.0592
INFO - 2021-07-08 11:57:06 --> Config Class Initialized
INFO - 2021-07-08 11:57:06 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:57:06 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:57:06 --> Utf8 Class Initialized
INFO - 2021-07-08 11:57:06 --> URI Class Initialized
INFO - 2021-07-08 11:57:06 --> Router Class Initialized
INFO - 2021-07-08 11:57:06 --> Output Class Initialized
INFO - 2021-07-08 11:57:06 --> Security Class Initialized
DEBUG - 2021-07-08 11:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:57:06 --> Input Class Initialized
INFO - 2021-07-08 11:57:06 --> Language Class Initialized
INFO - 2021-07-08 11:57:06 --> Loader Class Initialized
INFO - 2021-07-08 11:57:06 --> Helper loaded: html_helper
INFO - 2021-07-08 11:57:06 --> Helper loaded: url_helper
INFO - 2021-07-08 11:57:06 --> Helper loaded: form_helper
INFO - 2021-07-08 11:57:06 --> Database Driver Class Initialized
INFO - 2021-07-08 11:57:06 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:57:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:57:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:57:06 --> Encryption Class Initialized
INFO - 2021-07-08 11:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:57:06 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:57:06 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:57:06 --> Model "user_model" initialized
INFO - 2021-07-08 11:57:06 --> Model "role_model" initialized
INFO - 2021-07-08 11:57:06 --> Controller Class Initialized
INFO - 2021-07-08 11:57:06 --> Helper loaded: language_helper
INFO - 2021-07-08 11:57:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:57:06 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:57:06 --> Final output sent to browser
DEBUG - 2021-07-08 11:57:06 --> Total execution time: 0.0643
INFO - 2021-07-08 11:57:25 --> Config Class Initialized
INFO - 2021-07-08 11:57:25 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:57:26 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:57:26 --> Utf8 Class Initialized
INFO - 2021-07-08 11:57:26 --> URI Class Initialized
INFO - 2021-07-08 11:57:26 --> Router Class Initialized
INFO - 2021-07-08 11:57:26 --> Output Class Initialized
INFO - 2021-07-08 11:57:26 --> Security Class Initialized
DEBUG - 2021-07-08 11:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:57:26 --> Input Class Initialized
INFO - 2021-07-08 11:57:26 --> Language Class Initialized
INFO - 2021-07-08 11:57:26 --> Loader Class Initialized
INFO - 2021-07-08 11:57:26 --> Helper loaded: html_helper
INFO - 2021-07-08 11:57:26 --> Helper loaded: url_helper
INFO - 2021-07-08 11:57:26 --> Helper loaded: form_helper
INFO - 2021-07-08 11:57:26 --> Database Driver Class Initialized
INFO - 2021-07-08 11:57:26 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:57:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:57:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:57:26 --> Encryption Class Initialized
INFO - 2021-07-08 11:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:57:26 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:57:26 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:57:26 --> Model "user_model" initialized
INFO - 2021-07-08 11:57:26 --> Model "role_model" initialized
INFO - 2021-07-08 11:57:26 --> Controller Class Initialized
INFO - 2021-07-08 11:57:26 --> Helper loaded: language_helper
INFO - 2021-07-08 11:57:26 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:57:26 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:57:26 --> Model "Product_model" initialized
INFO - 2021-07-08 11:57:26 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:57:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:57:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:57:26 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:57:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:57:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:57:26 --> Final output sent to browser
DEBUG - 2021-07-08 11:57:26 --> Total execution time: 0.1141
INFO - 2021-07-08 11:57:28 --> Config Class Initialized
INFO - 2021-07-08 11:57:28 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:57:28 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:57:28 --> Utf8 Class Initialized
INFO - 2021-07-08 11:57:28 --> URI Class Initialized
INFO - 2021-07-08 11:57:28 --> Router Class Initialized
INFO - 2021-07-08 11:57:28 --> Output Class Initialized
INFO - 2021-07-08 11:57:28 --> Security Class Initialized
DEBUG - 2021-07-08 11:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:57:28 --> Input Class Initialized
INFO - 2021-07-08 11:57:28 --> Language Class Initialized
INFO - 2021-07-08 11:57:28 --> Loader Class Initialized
INFO - 2021-07-08 11:57:28 --> Helper loaded: html_helper
INFO - 2021-07-08 11:57:28 --> Helper loaded: url_helper
INFO - 2021-07-08 11:57:28 --> Helper loaded: form_helper
INFO - 2021-07-08 11:57:28 --> Database Driver Class Initialized
INFO - 2021-07-08 11:57:28 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:57:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:57:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:57:28 --> Encryption Class Initialized
INFO - 2021-07-08 11:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:57:28 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:57:28 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:57:28 --> Model "user_model" initialized
INFO - 2021-07-08 11:57:28 --> Model "role_model" initialized
INFO - 2021-07-08 11:57:28 --> Controller Class Initialized
INFO - 2021-07-08 11:57:28 --> Helper loaded: language_helper
INFO - 2021-07-08 11:57:28 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:57:28 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:57:28 --> Final output sent to browser
DEBUG - 2021-07-08 11:57:28 --> Total execution time: 0.0609
INFO - 2021-07-08 11:57:28 --> Config Class Initialized
INFO - 2021-07-08 11:57:28 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:57:28 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:57:28 --> Utf8 Class Initialized
INFO - 2021-07-08 11:57:28 --> URI Class Initialized
INFO - 2021-07-08 11:57:28 --> Router Class Initialized
INFO - 2021-07-08 11:57:28 --> Output Class Initialized
INFO - 2021-07-08 11:57:28 --> Security Class Initialized
DEBUG - 2021-07-08 11:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:57:28 --> Input Class Initialized
INFO - 2021-07-08 11:57:28 --> Language Class Initialized
INFO - 2021-07-08 11:57:28 --> Loader Class Initialized
INFO - 2021-07-08 11:57:28 --> Helper loaded: html_helper
INFO - 2021-07-08 11:57:28 --> Helper loaded: url_helper
INFO - 2021-07-08 11:57:28 --> Helper loaded: form_helper
INFO - 2021-07-08 11:57:28 --> Database Driver Class Initialized
INFO - 2021-07-08 11:57:28 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:57:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:57:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:57:28 --> Encryption Class Initialized
INFO - 2021-07-08 11:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:57:28 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:57:28 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:57:28 --> Model "user_model" initialized
INFO - 2021-07-08 11:57:28 --> Model "role_model" initialized
INFO - 2021-07-08 11:57:28 --> Controller Class Initialized
INFO - 2021-07-08 11:57:28 --> Helper loaded: language_helper
INFO - 2021-07-08 11:57:28 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:57:28 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:57:28 --> Final output sent to browser
DEBUG - 2021-07-08 11:57:28 --> Total execution time: 0.0619
INFO - 2021-07-08 11:58:02 --> Config Class Initialized
INFO - 2021-07-08 11:58:02 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:58:02 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:58:02 --> Utf8 Class Initialized
INFO - 2021-07-08 11:58:02 --> URI Class Initialized
INFO - 2021-07-08 11:58:02 --> Router Class Initialized
INFO - 2021-07-08 11:58:02 --> Output Class Initialized
INFO - 2021-07-08 11:58:02 --> Security Class Initialized
DEBUG - 2021-07-08 11:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:58:02 --> Input Class Initialized
INFO - 2021-07-08 11:58:02 --> Language Class Initialized
INFO - 2021-07-08 11:58:02 --> Loader Class Initialized
INFO - 2021-07-08 11:58:02 --> Helper loaded: html_helper
INFO - 2021-07-08 11:58:02 --> Helper loaded: url_helper
INFO - 2021-07-08 11:58:02 --> Helper loaded: form_helper
INFO - 2021-07-08 11:58:02 --> Database Driver Class Initialized
INFO - 2021-07-08 11:58:02 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:58:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:58:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:58:02 --> Encryption Class Initialized
INFO - 2021-07-08 11:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:58:02 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:58:02 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:58:02 --> Model "user_model" initialized
INFO - 2021-07-08 11:58:02 --> Model "role_model" initialized
INFO - 2021-07-08 11:58:02 --> Controller Class Initialized
INFO - 2021-07-08 11:58:02 --> Helper loaded: language_helper
INFO - 2021-07-08 11:58:02 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:58:02 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:58:02 --> Model "Product_model" initialized
INFO - 2021-07-08 11:58:02 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:58:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:58:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:58:02 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:58:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:58:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:58:02 --> Final output sent to browser
DEBUG - 2021-07-08 11:58:02 --> Total execution time: 0.1174
INFO - 2021-07-08 11:58:05 --> Config Class Initialized
INFO - 2021-07-08 11:58:05 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:58:05 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:58:05 --> Utf8 Class Initialized
INFO - 2021-07-08 11:58:05 --> URI Class Initialized
INFO - 2021-07-08 11:58:05 --> Router Class Initialized
INFO - 2021-07-08 11:58:05 --> Output Class Initialized
INFO - 2021-07-08 11:58:05 --> Security Class Initialized
DEBUG - 2021-07-08 11:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:58:05 --> Input Class Initialized
INFO - 2021-07-08 11:58:05 --> Language Class Initialized
INFO - 2021-07-08 11:58:05 --> Loader Class Initialized
INFO - 2021-07-08 11:58:05 --> Helper loaded: html_helper
INFO - 2021-07-08 11:58:05 --> Helper loaded: url_helper
INFO - 2021-07-08 11:58:05 --> Helper loaded: form_helper
INFO - 2021-07-08 11:58:05 --> Database Driver Class Initialized
INFO - 2021-07-08 11:58:05 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:58:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:58:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:58:05 --> Encryption Class Initialized
INFO - 2021-07-08 11:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:58:05 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:58:05 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:58:05 --> Model "user_model" initialized
INFO - 2021-07-08 11:58:05 --> Model "role_model" initialized
INFO - 2021-07-08 11:58:05 --> Controller Class Initialized
INFO - 2021-07-08 11:58:05 --> Helper loaded: language_helper
INFO - 2021-07-08 11:58:05 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:58:05 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:58:05 --> Final output sent to browser
DEBUG - 2021-07-08 11:58:05 --> Total execution time: 0.0617
INFO - 2021-07-08 11:58:05 --> Config Class Initialized
INFO - 2021-07-08 11:58:05 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:58:05 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:58:05 --> Utf8 Class Initialized
INFO - 2021-07-08 11:58:05 --> URI Class Initialized
INFO - 2021-07-08 11:58:05 --> Router Class Initialized
INFO - 2021-07-08 11:58:05 --> Output Class Initialized
INFO - 2021-07-08 11:58:05 --> Security Class Initialized
DEBUG - 2021-07-08 11:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:58:05 --> Input Class Initialized
INFO - 2021-07-08 11:58:05 --> Language Class Initialized
INFO - 2021-07-08 11:58:05 --> Loader Class Initialized
INFO - 2021-07-08 11:58:05 --> Helper loaded: html_helper
INFO - 2021-07-08 11:58:05 --> Helper loaded: url_helper
INFO - 2021-07-08 11:58:05 --> Helper loaded: form_helper
INFO - 2021-07-08 11:58:05 --> Database Driver Class Initialized
INFO - 2021-07-08 11:58:05 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:58:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:58:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:58:05 --> Encryption Class Initialized
INFO - 2021-07-08 11:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:58:05 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:58:05 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:58:05 --> Model "user_model" initialized
INFO - 2021-07-08 11:58:05 --> Model "role_model" initialized
INFO - 2021-07-08 11:58:05 --> Controller Class Initialized
INFO - 2021-07-08 11:58:05 --> Helper loaded: language_helper
INFO - 2021-07-08 11:58:05 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:58:05 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:58:05 --> Final output sent to browser
DEBUG - 2021-07-08 11:58:05 --> Total execution time: 0.0661
INFO - 2021-07-08 11:58:39 --> Config Class Initialized
INFO - 2021-07-08 11:58:39 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:58:39 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:58:39 --> Utf8 Class Initialized
INFO - 2021-07-08 11:58:39 --> URI Class Initialized
INFO - 2021-07-08 11:58:39 --> Router Class Initialized
INFO - 2021-07-08 11:58:39 --> Output Class Initialized
INFO - 2021-07-08 11:58:39 --> Security Class Initialized
DEBUG - 2021-07-08 11:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:58:39 --> Input Class Initialized
INFO - 2021-07-08 11:58:39 --> Language Class Initialized
INFO - 2021-07-08 11:58:39 --> Loader Class Initialized
INFO - 2021-07-08 11:58:39 --> Helper loaded: html_helper
INFO - 2021-07-08 11:58:39 --> Helper loaded: url_helper
INFO - 2021-07-08 11:58:39 --> Helper loaded: form_helper
INFO - 2021-07-08 11:58:39 --> Database Driver Class Initialized
INFO - 2021-07-08 11:58:39 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:58:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:58:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:58:39 --> Encryption Class Initialized
INFO - 2021-07-08 11:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:58:39 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:58:39 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:58:39 --> Model "user_model" initialized
INFO - 2021-07-08 11:58:39 --> Model "role_model" initialized
INFO - 2021-07-08 11:58:39 --> Controller Class Initialized
INFO - 2021-07-08 11:58:39 --> Helper loaded: language_helper
INFO - 2021-07-08 11:58:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:58:39 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:58:39 --> Model "Product_model" initialized
INFO - 2021-07-08 11:58:39 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:58:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:58:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:58:39 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:58:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:58:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:58:39 --> Final output sent to browser
DEBUG - 2021-07-08 11:58:39 --> Total execution time: 0.1171
INFO - 2021-07-08 11:58:42 --> Config Class Initialized
INFO - 2021-07-08 11:58:42 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:58:42 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:58:42 --> Utf8 Class Initialized
INFO - 2021-07-08 11:58:42 --> URI Class Initialized
INFO - 2021-07-08 11:58:42 --> Router Class Initialized
INFO - 2021-07-08 11:58:42 --> Output Class Initialized
INFO - 2021-07-08 11:58:42 --> Security Class Initialized
DEBUG - 2021-07-08 11:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:58:42 --> Input Class Initialized
INFO - 2021-07-08 11:58:42 --> Language Class Initialized
INFO - 2021-07-08 11:58:42 --> Loader Class Initialized
INFO - 2021-07-08 11:58:42 --> Helper loaded: html_helper
INFO - 2021-07-08 11:58:42 --> Helper loaded: url_helper
INFO - 2021-07-08 11:58:42 --> Helper loaded: form_helper
INFO - 2021-07-08 11:58:42 --> Database Driver Class Initialized
INFO - 2021-07-08 11:58:42 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:58:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:58:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:58:42 --> Encryption Class Initialized
INFO - 2021-07-08 11:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:58:42 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:58:42 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:58:42 --> Model "user_model" initialized
INFO - 2021-07-08 11:58:42 --> Model "role_model" initialized
INFO - 2021-07-08 11:58:42 --> Controller Class Initialized
INFO - 2021-07-08 11:58:42 --> Helper loaded: language_helper
INFO - 2021-07-08 11:58:42 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:58:42 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:58:42 --> Final output sent to browser
DEBUG - 2021-07-08 11:58:42 --> Total execution time: 0.0589
INFO - 2021-07-08 11:58:42 --> Config Class Initialized
INFO - 2021-07-08 11:58:42 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:58:42 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:58:42 --> Utf8 Class Initialized
INFO - 2021-07-08 11:58:42 --> URI Class Initialized
INFO - 2021-07-08 11:58:42 --> Router Class Initialized
INFO - 2021-07-08 11:58:42 --> Output Class Initialized
INFO - 2021-07-08 11:58:42 --> Security Class Initialized
DEBUG - 2021-07-08 11:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:58:42 --> Input Class Initialized
INFO - 2021-07-08 11:58:42 --> Language Class Initialized
INFO - 2021-07-08 11:58:42 --> Loader Class Initialized
INFO - 2021-07-08 11:58:42 --> Helper loaded: html_helper
INFO - 2021-07-08 11:58:42 --> Helper loaded: url_helper
INFO - 2021-07-08 11:58:42 --> Helper loaded: form_helper
INFO - 2021-07-08 11:58:42 --> Database Driver Class Initialized
INFO - 2021-07-08 11:58:42 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:58:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:58:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:58:42 --> Encryption Class Initialized
INFO - 2021-07-08 11:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:58:42 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:58:42 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:58:42 --> Model "user_model" initialized
INFO - 2021-07-08 11:58:42 --> Model "role_model" initialized
INFO - 2021-07-08 11:58:42 --> Controller Class Initialized
INFO - 2021-07-08 11:58:42 --> Helper loaded: language_helper
INFO - 2021-07-08 11:58:42 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:58:42 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:58:42 --> Final output sent to browser
DEBUG - 2021-07-08 11:58:42 --> Total execution time: 0.0569
INFO - 2021-07-08 11:59:08 --> Config Class Initialized
INFO - 2021-07-08 11:59:08 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:59:08 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:59:08 --> Utf8 Class Initialized
INFO - 2021-07-08 11:59:08 --> URI Class Initialized
INFO - 2021-07-08 11:59:08 --> Router Class Initialized
INFO - 2021-07-08 11:59:08 --> Output Class Initialized
INFO - 2021-07-08 11:59:08 --> Security Class Initialized
DEBUG - 2021-07-08 11:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:59:08 --> Input Class Initialized
INFO - 2021-07-08 11:59:08 --> Language Class Initialized
INFO - 2021-07-08 11:59:08 --> Loader Class Initialized
INFO - 2021-07-08 11:59:08 --> Helper loaded: html_helper
INFO - 2021-07-08 11:59:08 --> Helper loaded: url_helper
INFO - 2021-07-08 11:59:08 --> Helper loaded: form_helper
INFO - 2021-07-08 11:59:08 --> Database Driver Class Initialized
INFO - 2021-07-08 11:59:08 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:59:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:59:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:59:08 --> Encryption Class Initialized
INFO - 2021-07-08 11:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:59:08 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:59:08 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:59:08 --> Model "user_model" initialized
INFO - 2021-07-08 11:59:08 --> Model "role_model" initialized
INFO - 2021-07-08 11:59:08 --> Controller Class Initialized
INFO - 2021-07-08 11:59:08 --> Helper loaded: language_helper
INFO - 2021-07-08 11:59:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:59:08 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:59:08 --> Model "Product_model" initialized
INFO - 2021-07-08 11:59:08 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:59:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:59:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:59:08 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:59:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:59:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:59:08 --> Final output sent to browser
DEBUG - 2021-07-08 11:59:08 --> Total execution time: 0.1115
INFO - 2021-07-08 11:59:12 --> Config Class Initialized
INFO - 2021-07-08 11:59:12 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:59:12 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:59:12 --> Utf8 Class Initialized
INFO - 2021-07-08 11:59:12 --> URI Class Initialized
INFO - 2021-07-08 11:59:12 --> Router Class Initialized
INFO - 2021-07-08 11:59:12 --> Output Class Initialized
INFO - 2021-07-08 11:59:12 --> Security Class Initialized
DEBUG - 2021-07-08 11:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:59:12 --> Input Class Initialized
INFO - 2021-07-08 11:59:12 --> Language Class Initialized
INFO - 2021-07-08 11:59:12 --> Loader Class Initialized
INFO - 2021-07-08 11:59:12 --> Helper loaded: html_helper
INFO - 2021-07-08 11:59:12 --> Helper loaded: url_helper
INFO - 2021-07-08 11:59:12 --> Helper loaded: form_helper
INFO - 2021-07-08 11:59:12 --> Database Driver Class Initialized
INFO - 2021-07-08 11:59:12 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:59:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:59:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:59:12 --> Encryption Class Initialized
INFO - 2021-07-08 11:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:59:12 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:59:12 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:59:12 --> Model "user_model" initialized
INFO - 2021-07-08 11:59:12 --> Model "role_model" initialized
INFO - 2021-07-08 11:59:12 --> Controller Class Initialized
INFO - 2021-07-08 11:59:12 --> Helper loaded: language_helper
INFO - 2021-07-08 11:59:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:59:12 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:59:12 --> Final output sent to browser
DEBUG - 2021-07-08 11:59:12 --> Total execution time: 0.0639
INFO - 2021-07-08 11:59:12 --> Config Class Initialized
INFO - 2021-07-08 11:59:12 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:59:12 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:59:12 --> Utf8 Class Initialized
INFO - 2021-07-08 11:59:12 --> URI Class Initialized
INFO - 2021-07-08 11:59:12 --> Router Class Initialized
INFO - 2021-07-08 11:59:12 --> Output Class Initialized
INFO - 2021-07-08 11:59:12 --> Security Class Initialized
DEBUG - 2021-07-08 11:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:59:12 --> Input Class Initialized
INFO - 2021-07-08 11:59:12 --> Language Class Initialized
INFO - 2021-07-08 11:59:12 --> Loader Class Initialized
INFO - 2021-07-08 11:59:12 --> Helper loaded: html_helper
INFO - 2021-07-08 11:59:12 --> Helper loaded: url_helper
INFO - 2021-07-08 11:59:12 --> Helper loaded: form_helper
INFO - 2021-07-08 11:59:12 --> Database Driver Class Initialized
INFO - 2021-07-08 11:59:12 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:59:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:59:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:59:12 --> Encryption Class Initialized
INFO - 2021-07-08 11:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:59:12 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:59:12 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:59:12 --> Model "user_model" initialized
INFO - 2021-07-08 11:59:12 --> Model "role_model" initialized
INFO - 2021-07-08 11:59:12 --> Controller Class Initialized
INFO - 2021-07-08 11:59:12 --> Helper loaded: language_helper
INFO - 2021-07-08 11:59:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:59:12 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:59:12 --> Final output sent to browser
DEBUG - 2021-07-08 11:59:12 --> Total execution time: 0.0609
INFO - 2021-07-08 11:59:29 --> Config Class Initialized
INFO - 2021-07-08 11:59:29 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:59:29 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:59:29 --> Utf8 Class Initialized
INFO - 2021-07-08 11:59:29 --> URI Class Initialized
INFO - 2021-07-08 11:59:29 --> Router Class Initialized
INFO - 2021-07-08 11:59:29 --> Output Class Initialized
INFO - 2021-07-08 11:59:29 --> Security Class Initialized
DEBUG - 2021-07-08 11:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:59:29 --> Input Class Initialized
INFO - 2021-07-08 11:59:29 --> Language Class Initialized
INFO - 2021-07-08 11:59:29 --> Loader Class Initialized
INFO - 2021-07-08 11:59:29 --> Helper loaded: html_helper
INFO - 2021-07-08 11:59:29 --> Helper loaded: url_helper
INFO - 2021-07-08 11:59:29 --> Helper loaded: form_helper
INFO - 2021-07-08 11:59:29 --> Database Driver Class Initialized
INFO - 2021-07-08 11:59:29 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:59:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:59:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:59:29 --> Encryption Class Initialized
INFO - 2021-07-08 11:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:59:29 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:59:29 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:59:29 --> Model "user_model" initialized
INFO - 2021-07-08 11:59:29 --> Model "role_model" initialized
INFO - 2021-07-08 11:59:29 --> Controller Class Initialized
INFO - 2021-07-08 11:59:29 --> Helper loaded: language_helper
INFO - 2021-07-08 11:59:29 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:59:29 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:59:29 --> Model "Product_model" initialized
INFO - 2021-07-08 11:59:29 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:59:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:59:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:59:29 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:59:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:59:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:59:29 --> Final output sent to browser
DEBUG - 2021-07-08 11:59:29 --> Total execution time: 0.1081
INFO - 2021-07-08 11:59:32 --> Config Class Initialized
INFO - 2021-07-08 11:59:32 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:59:32 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:59:32 --> Utf8 Class Initialized
INFO - 2021-07-08 11:59:32 --> URI Class Initialized
INFO - 2021-07-08 11:59:32 --> Router Class Initialized
INFO - 2021-07-08 11:59:32 --> Output Class Initialized
INFO - 2021-07-08 11:59:32 --> Security Class Initialized
DEBUG - 2021-07-08 11:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:59:32 --> Input Class Initialized
INFO - 2021-07-08 11:59:32 --> Language Class Initialized
INFO - 2021-07-08 11:59:32 --> Loader Class Initialized
INFO - 2021-07-08 11:59:32 --> Helper loaded: html_helper
INFO - 2021-07-08 11:59:32 --> Helper loaded: url_helper
INFO - 2021-07-08 11:59:32 --> Helper loaded: form_helper
INFO - 2021-07-08 11:59:32 --> Database Driver Class Initialized
INFO - 2021-07-08 11:59:32 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:59:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:59:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:59:32 --> Encryption Class Initialized
INFO - 2021-07-08 11:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:59:32 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:59:32 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:59:32 --> Model "user_model" initialized
INFO - 2021-07-08 11:59:32 --> Model "role_model" initialized
INFO - 2021-07-08 11:59:32 --> Controller Class Initialized
INFO - 2021-07-08 11:59:32 --> Helper loaded: language_helper
INFO - 2021-07-08 11:59:32 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:59:32 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:59:32 --> Final output sent to browser
DEBUG - 2021-07-08 11:59:32 --> Total execution time: 0.0574
INFO - 2021-07-08 11:59:32 --> Config Class Initialized
INFO - 2021-07-08 11:59:32 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:59:32 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:59:32 --> Utf8 Class Initialized
INFO - 2021-07-08 11:59:32 --> URI Class Initialized
INFO - 2021-07-08 11:59:32 --> Router Class Initialized
INFO - 2021-07-08 11:59:32 --> Output Class Initialized
INFO - 2021-07-08 11:59:32 --> Security Class Initialized
DEBUG - 2021-07-08 11:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:59:32 --> Input Class Initialized
INFO - 2021-07-08 11:59:32 --> Language Class Initialized
INFO - 2021-07-08 11:59:32 --> Loader Class Initialized
INFO - 2021-07-08 11:59:32 --> Helper loaded: html_helper
INFO - 2021-07-08 11:59:32 --> Helper loaded: url_helper
INFO - 2021-07-08 11:59:32 --> Helper loaded: form_helper
INFO - 2021-07-08 11:59:32 --> Database Driver Class Initialized
INFO - 2021-07-08 11:59:32 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:59:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:59:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:59:32 --> Encryption Class Initialized
INFO - 2021-07-08 11:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:59:32 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:59:32 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:59:32 --> Model "user_model" initialized
INFO - 2021-07-08 11:59:32 --> Model "role_model" initialized
INFO - 2021-07-08 11:59:32 --> Controller Class Initialized
INFO - 2021-07-08 11:59:32 --> Helper loaded: language_helper
INFO - 2021-07-08 11:59:32 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:59:32 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:59:32 --> Final output sent to browser
DEBUG - 2021-07-08 11:59:32 --> Total execution time: 0.0591
INFO - 2021-07-08 11:59:52 --> Config Class Initialized
INFO - 2021-07-08 11:59:52 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:59:52 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:59:52 --> Utf8 Class Initialized
INFO - 2021-07-08 11:59:52 --> URI Class Initialized
INFO - 2021-07-08 11:59:52 --> Router Class Initialized
INFO - 2021-07-08 11:59:52 --> Output Class Initialized
INFO - 2021-07-08 11:59:52 --> Security Class Initialized
DEBUG - 2021-07-08 11:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:59:52 --> Input Class Initialized
INFO - 2021-07-08 11:59:52 --> Language Class Initialized
INFO - 2021-07-08 11:59:52 --> Loader Class Initialized
INFO - 2021-07-08 11:59:52 --> Helper loaded: html_helper
INFO - 2021-07-08 11:59:52 --> Helper loaded: url_helper
INFO - 2021-07-08 11:59:52 --> Helper loaded: form_helper
INFO - 2021-07-08 11:59:52 --> Database Driver Class Initialized
INFO - 2021-07-08 11:59:52 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:59:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:59:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:59:52 --> Encryption Class Initialized
INFO - 2021-07-08 11:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:59:52 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:59:52 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:59:52 --> Model "user_model" initialized
INFO - 2021-07-08 11:59:52 --> Model "role_model" initialized
INFO - 2021-07-08 11:59:52 --> Controller Class Initialized
INFO - 2021-07-08 11:59:52 --> Helper loaded: language_helper
INFO - 2021-07-08 11:59:52 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:59:52 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:59:52 --> Model "Product_model" initialized
INFO - 2021-07-08 11:59:52 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:59:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 11:59:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 11:59:52 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 11:59:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 11:59:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 11:59:52 --> Final output sent to browser
DEBUG - 2021-07-08 11:59:52 --> Total execution time: 0.1130
INFO - 2021-07-08 11:59:55 --> Config Class Initialized
INFO - 2021-07-08 11:59:55 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:59:55 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:59:55 --> Utf8 Class Initialized
INFO - 2021-07-08 11:59:55 --> URI Class Initialized
INFO - 2021-07-08 11:59:55 --> Router Class Initialized
INFO - 2021-07-08 11:59:55 --> Output Class Initialized
INFO - 2021-07-08 11:59:55 --> Security Class Initialized
DEBUG - 2021-07-08 11:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:59:55 --> Input Class Initialized
INFO - 2021-07-08 11:59:55 --> Language Class Initialized
INFO - 2021-07-08 11:59:55 --> Loader Class Initialized
INFO - 2021-07-08 11:59:55 --> Helper loaded: html_helper
INFO - 2021-07-08 11:59:55 --> Helper loaded: url_helper
INFO - 2021-07-08 11:59:55 --> Helper loaded: form_helper
INFO - 2021-07-08 11:59:55 --> Database Driver Class Initialized
INFO - 2021-07-08 11:59:55 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:59:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:59:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:59:55 --> Encryption Class Initialized
INFO - 2021-07-08 11:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:59:55 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:59:55 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:59:55 --> Model "user_model" initialized
INFO - 2021-07-08 11:59:55 --> Model "role_model" initialized
INFO - 2021-07-08 11:59:55 --> Controller Class Initialized
INFO - 2021-07-08 11:59:55 --> Helper loaded: language_helper
INFO - 2021-07-08 11:59:55 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:59:55 --> Model "Customer_model" initialized
INFO - 2021-07-08 11:59:55 --> Final output sent to browser
DEBUG - 2021-07-08 11:59:55 --> Total execution time: 0.0620
INFO - 2021-07-08 11:59:55 --> Config Class Initialized
INFO - 2021-07-08 11:59:55 --> Hooks Class Initialized
DEBUG - 2021-07-08 11:59:55 --> UTF-8 Support Enabled
INFO - 2021-07-08 11:59:55 --> Utf8 Class Initialized
INFO - 2021-07-08 11:59:55 --> URI Class Initialized
INFO - 2021-07-08 11:59:55 --> Router Class Initialized
INFO - 2021-07-08 11:59:55 --> Output Class Initialized
INFO - 2021-07-08 11:59:55 --> Security Class Initialized
DEBUG - 2021-07-08 11:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 11:59:55 --> Input Class Initialized
INFO - 2021-07-08 11:59:55 --> Language Class Initialized
INFO - 2021-07-08 11:59:55 --> Loader Class Initialized
INFO - 2021-07-08 11:59:55 --> Helper loaded: html_helper
INFO - 2021-07-08 11:59:55 --> Helper loaded: url_helper
INFO - 2021-07-08 11:59:55 --> Helper loaded: form_helper
INFO - 2021-07-08 11:59:55 --> Database Driver Class Initialized
INFO - 2021-07-08 11:59:55 --> Form Validation Class Initialized
DEBUG - 2021-07-08 11:59:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 11:59:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 11:59:55 --> Encryption Class Initialized
INFO - 2021-07-08 11:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 11:59:55 --> Model "vendor_model" initialized
INFO - 2021-07-08 11:59:55 --> Model "coupon_model" initialized
INFO - 2021-07-08 11:59:55 --> Model "user_model" initialized
INFO - 2021-07-08 11:59:55 --> Model "role_model" initialized
INFO - 2021-07-08 11:59:55 --> Controller Class Initialized
INFO - 2021-07-08 11:59:55 --> Helper loaded: language_helper
INFO - 2021-07-08 11:59:55 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 11:59:55 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 11:59:55 --> Final output sent to browser
DEBUG - 2021-07-08 11:59:55 --> Total execution time: 0.0596
INFO - 2021-07-08 12:00:06 --> Config Class Initialized
INFO - 2021-07-08 12:00:06 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:00:06 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:00:06 --> Utf8 Class Initialized
INFO - 2021-07-08 12:00:06 --> URI Class Initialized
INFO - 2021-07-08 12:00:06 --> Router Class Initialized
INFO - 2021-07-08 12:00:06 --> Output Class Initialized
INFO - 2021-07-08 12:00:06 --> Security Class Initialized
DEBUG - 2021-07-08 12:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:00:06 --> Input Class Initialized
INFO - 2021-07-08 12:00:06 --> Language Class Initialized
INFO - 2021-07-08 12:00:06 --> Loader Class Initialized
INFO - 2021-07-08 12:00:06 --> Helper loaded: html_helper
INFO - 2021-07-08 12:00:06 --> Helper loaded: url_helper
INFO - 2021-07-08 12:00:06 --> Helper loaded: form_helper
INFO - 2021-07-08 12:00:06 --> Database Driver Class Initialized
INFO - 2021-07-08 12:00:06 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:00:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:00:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:00:06 --> Encryption Class Initialized
INFO - 2021-07-08 12:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:00:06 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:00:06 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:00:06 --> Model "user_model" initialized
INFO - 2021-07-08 12:00:06 --> Model "role_model" initialized
INFO - 2021-07-08 12:00:06 --> Controller Class Initialized
INFO - 2021-07-08 12:00:06 --> Helper loaded: language_helper
INFO - 2021-07-08 12:00:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:00:06 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:00:06 --> Model "Product_model" initialized
INFO - 2021-07-08 12:00:06 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:00:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:00:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:00:06 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 12:00:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 12:00:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:00:06 --> Final output sent to browser
DEBUG - 2021-07-08 12:00:06 --> Total execution time: 0.1176
INFO - 2021-07-08 12:00:09 --> Config Class Initialized
INFO - 2021-07-08 12:00:09 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:00:09 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:00:09 --> Utf8 Class Initialized
INFO - 2021-07-08 12:00:09 --> URI Class Initialized
INFO - 2021-07-08 12:00:09 --> Router Class Initialized
INFO - 2021-07-08 12:00:09 --> Output Class Initialized
INFO - 2021-07-08 12:00:09 --> Security Class Initialized
DEBUG - 2021-07-08 12:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:00:09 --> Input Class Initialized
INFO - 2021-07-08 12:00:09 --> Language Class Initialized
INFO - 2021-07-08 12:00:09 --> Loader Class Initialized
INFO - 2021-07-08 12:00:09 --> Helper loaded: html_helper
INFO - 2021-07-08 12:00:09 --> Helper loaded: url_helper
INFO - 2021-07-08 12:00:09 --> Helper loaded: form_helper
INFO - 2021-07-08 12:00:09 --> Database Driver Class Initialized
INFO - 2021-07-08 12:00:09 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:00:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:00:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:00:09 --> Encryption Class Initialized
INFO - 2021-07-08 12:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:00:09 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:00:09 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:00:09 --> Model "user_model" initialized
INFO - 2021-07-08 12:00:09 --> Model "role_model" initialized
INFO - 2021-07-08 12:00:09 --> Controller Class Initialized
INFO - 2021-07-08 12:00:09 --> Helper loaded: language_helper
INFO - 2021-07-08 12:00:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:00:09 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:00:09 --> Final output sent to browser
DEBUG - 2021-07-08 12:00:09 --> Total execution time: 0.0641
INFO - 2021-07-08 12:00:09 --> Config Class Initialized
INFO - 2021-07-08 12:00:09 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:00:09 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:00:09 --> Utf8 Class Initialized
INFO - 2021-07-08 12:00:09 --> URI Class Initialized
INFO - 2021-07-08 12:00:09 --> Router Class Initialized
INFO - 2021-07-08 12:00:09 --> Output Class Initialized
INFO - 2021-07-08 12:00:09 --> Security Class Initialized
DEBUG - 2021-07-08 12:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:00:09 --> Input Class Initialized
INFO - 2021-07-08 12:00:09 --> Language Class Initialized
INFO - 2021-07-08 12:00:09 --> Loader Class Initialized
INFO - 2021-07-08 12:00:09 --> Helper loaded: html_helper
INFO - 2021-07-08 12:00:09 --> Helper loaded: url_helper
INFO - 2021-07-08 12:00:09 --> Helper loaded: form_helper
INFO - 2021-07-08 12:00:09 --> Database Driver Class Initialized
INFO - 2021-07-08 12:00:09 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:00:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:00:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:00:09 --> Encryption Class Initialized
INFO - 2021-07-08 12:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:00:09 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:00:09 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:00:09 --> Model "user_model" initialized
INFO - 2021-07-08 12:00:09 --> Model "role_model" initialized
INFO - 2021-07-08 12:00:09 --> Controller Class Initialized
INFO - 2021-07-08 12:00:09 --> Helper loaded: language_helper
INFO - 2021-07-08 12:00:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:00:09 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:00:09 --> Final output sent to browser
DEBUG - 2021-07-08 12:00:09 --> Total execution time: 0.0616
INFO - 2021-07-08 12:01:22 --> Config Class Initialized
INFO - 2021-07-08 12:01:22 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:01:22 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:01:22 --> Utf8 Class Initialized
INFO - 2021-07-08 12:01:22 --> URI Class Initialized
INFO - 2021-07-08 12:01:22 --> Router Class Initialized
INFO - 2021-07-08 12:01:22 --> Output Class Initialized
INFO - 2021-07-08 12:01:22 --> Security Class Initialized
DEBUG - 2021-07-08 12:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:01:22 --> Input Class Initialized
INFO - 2021-07-08 12:01:22 --> Language Class Initialized
INFO - 2021-07-08 12:01:22 --> Loader Class Initialized
INFO - 2021-07-08 12:01:22 --> Helper loaded: html_helper
INFO - 2021-07-08 12:01:22 --> Helper loaded: url_helper
INFO - 2021-07-08 12:01:22 --> Helper loaded: form_helper
INFO - 2021-07-08 12:01:22 --> Database Driver Class Initialized
INFO - 2021-07-08 12:01:22 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:01:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:01:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:01:22 --> Encryption Class Initialized
INFO - 2021-07-08 12:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:01:22 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:01:22 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:01:22 --> Model "user_model" initialized
INFO - 2021-07-08 12:01:22 --> Model "role_model" initialized
INFO - 2021-07-08 12:01:22 --> Controller Class Initialized
INFO - 2021-07-08 12:01:22 --> Helper loaded: language_helper
INFO - 2021-07-08 12:01:22 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:01:22 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:01:22 --> Model "Product_model" initialized
INFO - 2021-07-08 12:01:22 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:01:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:01:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:01:22 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 12:01:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 12:01:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:01:22 --> Final output sent to browser
DEBUG - 2021-07-08 12:01:22 --> Total execution time: 0.1237
INFO - 2021-07-08 12:01:24 --> Config Class Initialized
INFO - 2021-07-08 12:01:24 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:01:24 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:01:24 --> Utf8 Class Initialized
INFO - 2021-07-08 12:01:24 --> URI Class Initialized
INFO - 2021-07-08 12:01:24 --> Router Class Initialized
INFO - 2021-07-08 12:01:24 --> Output Class Initialized
INFO - 2021-07-08 12:01:24 --> Security Class Initialized
DEBUG - 2021-07-08 12:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:01:24 --> Input Class Initialized
INFO - 2021-07-08 12:01:24 --> Language Class Initialized
INFO - 2021-07-08 12:01:24 --> Loader Class Initialized
INFO - 2021-07-08 12:01:24 --> Helper loaded: html_helper
INFO - 2021-07-08 12:01:24 --> Helper loaded: url_helper
INFO - 2021-07-08 12:01:24 --> Helper loaded: form_helper
INFO - 2021-07-08 12:01:24 --> Database Driver Class Initialized
INFO - 2021-07-08 12:01:24 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:01:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:01:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:01:24 --> Encryption Class Initialized
INFO - 2021-07-08 12:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:01:24 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:01:24 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:01:24 --> Model "user_model" initialized
INFO - 2021-07-08 12:01:24 --> Model "role_model" initialized
INFO - 2021-07-08 12:01:24 --> Controller Class Initialized
INFO - 2021-07-08 12:01:24 --> Helper loaded: language_helper
INFO - 2021-07-08 12:01:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:01:24 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:01:24 --> Final output sent to browser
DEBUG - 2021-07-08 12:01:24 --> Total execution time: 0.0870
INFO - 2021-07-08 12:01:24 --> Config Class Initialized
INFO - 2021-07-08 12:01:24 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:01:24 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:01:24 --> Utf8 Class Initialized
INFO - 2021-07-08 12:01:24 --> URI Class Initialized
INFO - 2021-07-08 12:01:25 --> Router Class Initialized
INFO - 2021-07-08 12:01:25 --> Output Class Initialized
INFO - 2021-07-08 12:01:25 --> Security Class Initialized
DEBUG - 2021-07-08 12:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:01:25 --> Input Class Initialized
INFO - 2021-07-08 12:01:25 --> Language Class Initialized
INFO - 2021-07-08 12:01:25 --> Loader Class Initialized
INFO - 2021-07-08 12:01:25 --> Helper loaded: html_helper
INFO - 2021-07-08 12:01:25 --> Helper loaded: url_helper
INFO - 2021-07-08 12:01:25 --> Helper loaded: form_helper
INFO - 2021-07-08 12:01:25 --> Database Driver Class Initialized
INFO - 2021-07-08 12:01:25 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:01:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:01:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:01:25 --> Encryption Class Initialized
INFO - 2021-07-08 12:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:01:25 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:01:25 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:01:25 --> Model "user_model" initialized
INFO - 2021-07-08 12:01:25 --> Model "role_model" initialized
INFO - 2021-07-08 12:01:25 --> Controller Class Initialized
INFO - 2021-07-08 12:01:25 --> Helper loaded: language_helper
INFO - 2021-07-08 12:01:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:01:25 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:01:25 --> Final output sent to browser
DEBUG - 2021-07-08 12:01:25 --> Total execution time: 0.0626
INFO - 2021-07-08 12:01:51 --> Config Class Initialized
INFO - 2021-07-08 12:01:51 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:01:51 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:01:51 --> Utf8 Class Initialized
INFO - 2021-07-08 12:01:51 --> URI Class Initialized
INFO - 2021-07-08 12:01:51 --> Router Class Initialized
INFO - 2021-07-08 12:01:51 --> Output Class Initialized
INFO - 2021-07-08 12:01:51 --> Security Class Initialized
DEBUG - 2021-07-08 12:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:01:51 --> Input Class Initialized
INFO - 2021-07-08 12:01:51 --> Language Class Initialized
INFO - 2021-07-08 12:01:51 --> Loader Class Initialized
INFO - 2021-07-08 12:01:51 --> Helper loaded: html_helper
INFO - 2021-07-08 12:01:51 --> Helper loaded: url_helper
INFO - 2021-07-08 12:01:51 --> Helper loaded: form_helper
INFO - 2021-07-08 12:01:51 --> Database Driver Class Initialized
INFO - 2021-07-08 12:01:51 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:01:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:01:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:01:51 --> Encryption Class Initialized
INFO - 2021-07-08 12:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:01:51 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:01:51 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:01:51 --> Model "user_model" initialized
INFO - 2021-07-08 12:01:51 --> Model "role_model" initialized
INFO - 2021-07-08 12:01:51 --> Controller Class Initialized
INFO - 2021-07-08 12:01:51 --> Helper loaded: language_helper
INFO - 2021-07-08 12:01:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:01:51 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:01:51 --> Model "Product_model" initialized
INFO - 2021-07-08 12:01:51 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:01:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:01:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:01:51 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 12:01:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 12:01:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:01:51 --> Final output sent to browser
DEBUG - 2021-07-08 12:01:51 --> Total execution time: 0.1013
INFO - 2021-07-08 12:01:54 --> Config Class Initialized
INFO - 2021-07-08 12:01:54 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:01:54 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:01:54 --> Utf8 Class Initialized
INFO - 2021-07-08 12:01:54 --> URI Class Initialized
INFO - 2021-07-08 12:01:54 --> Router Class Initialized
INFO - 2021-07-08 12:01:54 --> Output Class Initialized
INFO - 2021-07-08 12:01:54 --> Security Class Initialized
DEBUG - 2021-07-08 12:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:01:54 --> Input Class Initialized
INFO - 2021-07-08 12:01:54 --> Language Class Initialized
INFO - 2021-07-08 12:01:54 --> Loader Class Initialized
INFO - 2021-07-08 12:01:54 --> Helper loaded: html_helper
INFO - 2021-07-08 12:01:54 --> Helper loaded: url_helper
INFO - 2021-07-08 12:01:54 --> Helper loaded: form_helper
INFO - 2021-07-08 12:01:54 --> Database Driver Class Initialized
INFO - 2021-07-08 12:01:54 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:01:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:01:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:01:54 --> Encryption Class Initialized
INFO - 2021-07-08 12:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:01:54 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:01:54 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:01:54 --> Model "user_model" initialized
INFO - 2021-07-08 12:01:54 --> Model "role_model" initialized
INFO - 2021-07-08 12:01:54 --> Controller Class Initialized
INFO - 2021-07-08 12:01:54 --> Helper loaded: language_helper
INFO - 2021-07-08 12:01:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:01:54 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:01:54 --> Final output sent to browser
DEBUG - 2021-07-08 12:01:54 --> Total execution time: 0.0645
INFO - 2021-07-08 12:01:54 --> Config Class Initialized
INFO - 2021-07-08 12:01:54 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:01:54 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:01:54 --> Utf8 Class Initialized
INFO - 2021-07-08 12:01:54 --> URI Class Initialized
INFO - 2021-07-08 12:01:54 --> Router Class Initialized
INFO - 2021-07-08 12:01:54 --> Output Class Initialized
INFO - 2021-07-08 12:01:54 --> Security Class Initialized
DEBUG - 2021-07-08 12:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:01:54 --> Input Class Initialized
INFO - 2021-07-08 12:01:54 --> Language Class Initialized
INFO - 2021-07-08 12:01:54 --> Loader Class Initialized
INFO - 2021-07-08 12:01:54 --> Helper loaded: html_helper
INFO - 2021-07-08 12:01:54 --> Helper loaded: url_helper
INFO - 2021-07-08 12:01:54 --> Helper loaded: form_helper
INFO - 2021-07-08 12:01:54 --> Database Driver Class Initialized
INFO - 2021-07-08 12:01:54 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:01:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:01:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:01:54 --> Encryption Class Initialized
INFO - 2021-07-08 12:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:01:54 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:01:54 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:01:54 --> Model "user_model" initialized
INFO - 2021-07-08 12:01:54 --> Model "role_model" initialized
INFO - 2021-07-08 12:01:54 --> Controller Class Initialized
INFO - 2021-07-08 12:01:54 --> Helper loaded: language_helper
INFO - 2021-07-08 12:01:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:01:54 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:01:54 --> Final output sent to browser
DEBUG - 2021-07-08 12:01:54 --> Total execution time: 0.0587
INFO - 2021-07-08 12:02:20 --> Config Class Initialized
INFO - 2021-07-08 12:02:20 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:02:20 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:02:20 --> Utf8 Class Initialized
INFO - 2021-07-08 12:02:20 --> URI Class Initialized
INFO - 2021-07-08 12:02:20 --> Router Class Initialized
INFO - 2021-07-08 12:02:20 --> Output Class Initialized
INFO - 2021-07-08 12:02:20 --> Security Class Initialized
DEBUG - 2021-07-08 12:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:02:20 --> Input Class Initialized
INFO - 2021-07-08 12:02:20 --> Language Class Initialized
INFO - 2021-07-08 12:02:20 --> Loader Class Initialized
INFO - 2021-07-08 12:02:20 --> Helper loaded: html_helper
INFO - 2021-07-08 12:02:20 --> Helper loaded: url_helper
INFO - 2021-07-08 12:02:20 --> Helper loaded: form_helper
INFO - 2021-07-08 12:02:20 --> Database Driver Class Initialized
INFO - 2021-07-08 12:02:20 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:02:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:02:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:02:20 --> Encryption Class Initialized
INFO - 2021-07-08 12:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:02:20 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:02:20 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:02:20 --> Model "user_model" initialized
INFO - 2021-07-08 12:02:20 --> Model "role_model" initialized
INFO - 2021-07-08 12:02:20 --> Controller Class Initialized
INFO - 2021-07-08 12:02:20 --> Helper loaded: language_helper
INFO - 2021-07-08 12:02:20 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:02:20 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:02:20 --> Model "Product_model" initialized
INFO - 2021-07-08 12:02:20 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:02:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:02:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:02:20 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 12:02:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 12:02:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:02:20 --> Final output sent to browser
DEBUG - 2021-07-08 12:02:20 --> Total execution time: 0.1188
INFO - 2021-07-08 12:02:22 --> Config Class Initialized
INFO - 2021-07-08 12:02:22 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:02:22 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:02:22 --> Utf8 Class Initialized
INFO - 2021-07-08 12:02:22 --> URI Class Initialized
INFO - 2021-07-08 12:02:22 --> Router Class Initialized
INFO - 2021-07-08 12:02:22 --> Output Class Initialized
INFO - 2021-07-08 12:02:22 --> Security Class Initialized
DEBUG - 2021-07-08 12:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:02:22 --> Input Class Initialized
INFO - 2021-07-08 12:02:22 --> Language Class Initialized
INFO - 2021-07-08 12:02:22 --> Loader Class Initialized
INFO - 2021-07-08 12:02:22 --> Helper loaded: html_helper
INFO - 2021-07-08 12:02:22 --> Helper loaded: url_helper
INFO - 2021-07-08 12:02:22 --> Helper loaded: form_helper
INFO - 2021-07-08 12:02:22 --> Database Driver Class Initialized
INFO - 2021-07-08 12:02:22 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:02:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:02:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:02:22 --> Encryption Class Initialized
INFO - 2021-07-08 12:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:02:22 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:02:22 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:02:22 --> Model "user_model" initialized
INFO - 2021-07-08 12:02:22 --> Model "role_model" initialized
INFO - 2021-07-08 12:02:22 --> Controller Class Initialized
INFO - 2021-07-08 12:02:22 --> Helper loaded: language_helper
INFO - 2021-07-08 12:02:23 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:02:23 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:02:23 --> Final output sent to browser
DEBUG - 2021-07-08 12:02:23 --> Total execution time: 0.0659
INFO - 2021-07-08 12:02:23 --> Config Class Initialized
INFO - 2021-07-08 12:02:23 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:02:23 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:02:23 --> Utf8 Class Initialized
INFO - 2021-07-08 12:02:23 --> URI Class Initialized
INFO - 2021-07-08 12:02:23 --> Router Class Initialized
INFO - 2021-07-08 12:02:23 --> Output Class Initialized
INFO - 2021-07-08 12:02:23 --> Security Class Initialized
DEBUG - 2021-07-08 12:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:02:23 --> Input Class Initialized
INFO - 2021-07-08 12:02:23 --> Language Class Initialized
INFO - 2021-07-08 12:02:23 --> Loader Class Initialized
INFO - 2021-07-08 12:02:23 --> Helper loaded: html_helper
INFO - 2021-07-08 12:02:23 --> Helper loaded: url_helper
INFO - 2021-07-08 12:02:23 --> Helper loaded: form_helper
INFO - 2021-07-08 12:02:23 --> Database Driver Class Initialized
INFO - 2021-07-08 12:02:23 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:02:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:02:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:02:23 --> Encryption Class Initialized
INFO - 2021-07-08 12:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:02:23 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:02:23 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:02:23 --> Model "user_model" initialized
INFO - 2021-07-08 12:02:23 --> Model "role_model" initialized
INFO - 2021-07-08 12:02:23 --> Controller Class Initialized
INFO - 2021-07-08 12:02:23 --> Helper loaded: language_helper
INFO - 2021-07-08 12:02:23 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:02:23 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:02:23 --> Final output sent to browser
DEBUG - 2021-07-08 12:02:23 --> Total execution time: 0.0665
INFO - 2021-07-08 12:02:32 --> Config Class Initialized
INFO - 2021-07-08 12:02:32 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:02:32 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:02:32 --> Utf8 Class Initialized
INFO - 2021-07-08 12:02:32 --> URI Class Initialized
INFO - 2021-07-08 12:02:32 --> Router Class Initialized
INFO - 2021-07-08 12:02:32 --> Output Class Initialized
INFO - 2021-07-08 12:02:32 --> Security Class Initialized
DEBUG - 2021-07-08 12:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:02:33 --> Input Class Initialized
INFO - 2021-07-08 12:02:33 --> Language Class Initialized
INFO - 2021-07-08 12:02:33 --> Loader Class Initialized
INFO - 2021-07-08 12:02:33 --> Helper loaded: html_helper
INFO - 2021-07-08 12:02:33 --> Helper loaded: url_helper
INFO - 2021-07-08 12:02:33 --> Helper loaded: form_helper
INFO - 2021-07-08 12:02:33 --> Database Driver Class Initialized
INFO - 2021-07-08 12:02:33 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:02:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:02:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:02:33 --> Encryption Class Initialized
INFO - 2021-07-08 12:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:02:33 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:02:33 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:02:33 --> Model "user_model" initialized
INFO - 2021-07-08 12:02:33 --> Model "role_model" initialized
INFO - 2021-07-08 12:02:33 --> Controller Class Initialized
INFO - 2021-07-08 12:02:33 --> Helper loaded: language_helper
INFO - 2021-07-08 12:02:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:02:33 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:02:33 --> Model "Product_model" initialized
INFO - 2021-07-08 12:02:33 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:02:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:02:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:02:33 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 12:02:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 12:02:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:02:33 --> Final output sent to browser
DEBUG - 2021-07-08 12:02:33 --> Total execution time: 0.0774
INFO - 2021-07-08 12:03:08 --> Config Class Initialized
INFO - 2021-07-08 12:03:08 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:03:08 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:03:08 --> Utf8 Class Initialized
INFO - 2021-07-08 12:03:08 --> URI Class Initialized
INFO - 2021-07-08 12:03:08 --> Router Class Initialized
INFO - 2021-07-08 12:03:08 --> Output Class Initialized
INFO - 2021-07-08 12:03:08 --> Security Class Initialized
DEBUG - 2021-07-08 12:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:03:08 --> Input Class Initialized
INFO - 2021-07-08 12:03:08 --> Language Class Initialized
INFO - 2021-07-08 12:03:08 --> Loader Class Initialized
INFO - 2021-07-08 12:03:08 --> Helper loaded: html_helper
INFO - 2021-07-08 12:03:08 --> Helper loaded: url_helper
INFO - 2021-07-08 12:03:08 --> Helper loaded: form_helper
INFO - 2021-07-08 12:03:08 --> Database Driver Class Initialized
INFO - 2021-07-08 12:03:08 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:03:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:03:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:03:08 --> Encryption Class Initialized
INFO - 2021-07-08 12:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:03:08 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:03:08 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:03:08 --> Model "user_model" initialized
INFO - 2021-07-08 12:03:08 --> Model "role_model" initialized
INFO - 2021-07-08 12:03:08 --> Controller Class Initialized
INFO - 2021-07-08 12:03:08 --> Helper loaded: language_helper
INFO - 2021-07-08 12:03:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:03:08 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:03:08 --> Model "Product_model" initialized
INFO - 2021-07-08 12:03:08 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:03:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:03:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:03:08 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 12:03:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 12:03:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:03:08 --> Final output sent to browser
DEBUG - 2021-07-08 12:03:08 --> Total execution time: 0.1150
INFO - 2021-07-08 12:03:11 --> Config Class Initialized
INFO - 2021-07-08 12:03:11 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:03:11 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:03:11 --> Utf8 Class Initialized
INFO - 2021-07-08 12:03:11 --> URI Class Initialized
INFO - 2021-07-08 12:03:11 --> Router Class Initialized
INFO - 2021-07-08 12:03:11 --> Output Class Initialized
INFO - 2021-07-08 12:03:11 --> Security Class Initialized
DEBUG - 2021-07-08 12:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:03:11 --> Input Class Initialized
INFO - 2021-07-08 12:03:11 --> Language Class Initialized
INFO - 2021-07-08 12:03:11 --> Loader Class Initialized
INFO - 2021-07-08 12:03:11 --> Helper loaded: html_helper
INFO - 2021-07-08 12:03:11 --> Helper loaded: url_helper
INFO - 2021-07-08 12:03:11 --> Helper loaded: form_helper
INFO - 2021-07-08 12:03:11 --> Database Driver Class Initialized
INFO - 2021-07-08 12:03:11 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:03:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:03:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:03:11 --> Encryption Class Initialized
INFO - 2021-07-08 12:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:03:11 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:03:11 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:03:11 --> Model "user_model" initialized
INFO - 2021-07-08 12:03:11 --> Model "role_model" initialized
INFO - 2021-07-08 12:03:11 --> Controller Class Initialized
INFO - 2021-07-08 12:03:11 --> Helper loaded: language_helper
INFO - 2021-07-08 12:03:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:03:11 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:03:11 --> Final output sent to browser
DEBUG - 2021-07-08 12:03:11 --> Total execution time: 0.0607
INFO - 2021-07-08 12:03:11 --> Config Class Initialized
INFO - 2021-07-08 12:03:11 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:03:11 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:03:11 --> Utf8 Class Initialized
INFO - 2021-07-08 12:03:11 --> URI Class Initialized
INFO - 2021-07-08 12:03:11 --> Router Class Initialized
INFO - 2021-07-08 12:03:11 --> Output Class Initialized
INFO - 2021-07-08 12:03:11 --> Security Class Initialized
DEBUG - 2021-07-08 12:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:03:11 --> Input Class Initialized
INFO - 2021-07-08 12:03:11 --> Language Class Initialized
INFO - 2021-07-08 12:03:11 --> Loader Class Initialized
INFO - 2021-07-08 12:03:11 --> Helper loaded: html_helper
INFO - 2021-07-08 12:03:11 --> Helper loaded: url_helper
INFO - 2021-07-08 12:03:11 --> Helper loaded: form_helper
INFO - 2021-07-08 12:03:11 --> Database Driver Class Initialized
INFO - 2021-07-08 12:03:11 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:03:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:03:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:03:11 --> Encryption Class Initialized
INFO - 2021-07-08 12:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:03:11 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:03:11 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:03:11 --> Model "user_model" initialized
INFO - 2021-07-08 12:03:11 --> Model "role_model" initialized
INFO - 2021-07-08 12:03:11 --> Controller Class Initialized
INFO - 2021-07-08 12:03:11 --> Helper loaded: language_helper
INFO - 2021-07-08 12:03:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:03:11 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:03:11 --> Final output sent to browser
DEBUG - 2021-07-08 12:03:11 --> Total execution time: 0.0630
INFO - 2021-07-08 12:03:36 --> Config Class Initialized
INFO - 2021-07-08 12:03:36 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:03:36 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:03:36 --> Utf8 Class Initialized
INFO - 2021-07-08 12:03:36 --> URI Class Initialized
INFO - 2021-07-08 12:03:36 --> Router Class Initialized
INFO - 2021-07-08 12:03:36 --> Output Class Initialized
INFO - 2021-07-08 12:03:36 --> Security Class Initialized
DEBUG - 2021-07-08 12:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:03:36 --> Input Class Initialized
INFO - 2021-07-08 12:03:36 --> Language Class Initialized
INFO - 2021-07-08 12:03:36 --> Loader Class Initialized
INFO - 2021-07-08 12:03:36 --> Helper loaded: html_helper
INFO - 2021-07-08 12:03:36 --> Helper loaded: url_helper
INFO - 2021-07-08 12:03:36 --> Helper loaded: form_helper
INFO - 2021-07-08 12:03:36 --> Database Driver Class Initialized
INFO - 2021-07-08 12:03:36 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:03:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:03:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:03:36 --> Encryption Class Initialized
INFO - 2021-07-08 12:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:03:36 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:03:36 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:03:36 --> Model "user_model" initialized
INFO - 2021-07-08 12:03:36 --> Model "role_model" initialized
INFO - 2021-07-08 12:03:36 --> Controller Class Initialized
INFO - 2021-07-08 12:03:36 --> Helper loaded: language_helper
INFO - 2021-07-08 12:03:36 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:03:36 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:03:36 --> Model "Product_model" initialized
INFO - 2021-07-08 12:03:36 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:03:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:03:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:03:36 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 12:03:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 12:03:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:03:36 --> Final output sent to browser
DEBUG - 2021-07-08 12:03:36 --> Total execution time: 0.1069
INFO - 2021-07-08 12:03:39 --> Config Class Initialized
INFO - 2021-07-08 12:03:39 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:03:39 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:03:39 --> Utf8 Class Initialized
INFO - 2021-07-08 12:03:39 --> URI Class Initialized
INFO - 2021-07-08 12:03:39 --> Router Class Initialized
INFO - 2021-07-08 12:03:39 --> Output Class Initialized
INFO - 2021-07-08 12:03:39 --> Security Class Initialized
DEBUG - 2021-07-08 12:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:03:39 --> Input Class Initialized
INFO - 2021-07-08 12:03:39 --> Language Class Initialized
INFO - 2021-07-08 12:03:39 --> Loader Class Initialized
INFO - 2021-07-08 12:03:39 --> Helper loaded: html_helper
INFO - 2021-07-08 12:03:39 --> Helper loaded: url_helper
INFO - 2021-07-08 12:03:39 --> Helper loaded: form_helper
INFO - 2021-07-08 12:03:39 --> Database Driver Class Initialized
INFO - 2021-07-08 12:03:39 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:03:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:03:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:03:39 --> Encryption Class Initialized
INFO - 2021-07-08 12:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:03:39 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:03:39 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:03:39 --> Model "user_model" initialized
INFO - 2021-07-08 12:03:39 --> Model "role_model" initialized
INFO - 2021-07-08 12:03:39 --> Controller Class Initialized
INFO - 2021-07-08 12:03:39 --> Helper loaded: language_helper
INFO - 2021-07-08 12:03:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:03:39 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:03:39 --> Final output sent to browser
DEBUG - 2021-07-08 12:03:39 --> Total execution time: 0.0619
INFO - 2021-07-08 12:03:39 --> Config Class Initialized
INFO - 2021-07-08 12:03:39 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:03:39 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:03:39 --> Utf8 Class Initialized
INFO - 2021-07-08 12:03:39 --> URI Class Initialized
INFO - 2021-07-08 12:03:39 --> Router Class Initialized
INFO - 2021-07-08 12:03:39 --> Output Class Initialized
INFO - 2021-07-08 12:03:39 --> Security Class Initialized
DEBUG - 2021-07-08 12:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:03:39 --> Input Class Initialized
INFO - 2021-07-08 12:03:39 --> Language Class Initialized
INFO - 2021-07-08 12:03:39 --> Loader Class Initialized
INFO - 2021-07-08 12:03:39 --> Helper loaded: html_helper
INFO - 2021-07-08 12:03:39 --> Helper loaded: url_helper
INFO - 2021-07-08 12:03:39 --> Helper loaded: form_helper
INFO - 2021-07-08 12:03:39 --> Database Driver Class Initialized
INFO - 2021-07-08 12:03:39 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:03:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:03:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:03:39 --> Encryption Class Initialized
INFO - 2021-07-08 12:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:03:39 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:03:39 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:03:39 --> Model "user_model" initialized
INFO - 2021-07-08 12:03:39 --> Model "role_model" initialized
INFO - 2021-07-08 12:03:39 --> Controller Class Initialized
INFO - 2021-07-08 12:03:39 --> Helper loaded: language_helper
INFO - 2021-07-08 12:03:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:03:39 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:03:39 --> Final output sent to browser
DEBUG - 2021-07-08 12:03:39 --> Total execution time: 0.0662
INFO - 2021-07-08 12:03:49 --> Config Class Initialized
INFO - 2021-07-08 12:03:49 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:03:49 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:03:49 --> Utf8 Class Initialized
INFO - 2021-07-08 12:03:49 --> URI Class Initialized
INFO - 2021-07-08 12:03:49 --> Router Class Initialized
INFO - 2021-07-08 12:03:49 --> Output Class Initialized
INFO - 2021-07-08 12:03:49 --> Security Class Initialized
DEBUG - 2021-07-08 12:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:03:49 --> Input Class Initialized
INFO - 2021-07-08 12:03:49 --> Language Class Initialized
INFO - 2021-07-08 12:03:49 --> Loader Class Initialized
INFO - 2021-07-08 12:03:49 --> Helper loaded: html_helper
INFO - 2021-07-08 12:03:49 --> Helper loaded: url_helper
INFO - 2021-07-08 12:03:49 --> Helper loaded: form_helper
INFO - 2021-07-08 12:03:49 --> Database Driver Class Initialized
INFO - 2021-07-08 12:03:49 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:03:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:03:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:03:49 --> Encryption Class Initialized
INFO - 2021-07-08 12:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:03:49 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:03:49 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:03:49 --> Model "user_model" initialized
INFO - 2021-07-08 12:03:49 --> Model "role_model" initialized
INFO - 2021-07-08 12:03:49 --> Controller Class Initialized
INFO - 2021-07-08 12:03:49 --> Helper loaded: language_helper
INFO - 2021-07-08 12:03:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:03:49 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:03:49 --> Model "Product_model" initialized
INFO - 2021-07-08 12:03:49 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:03:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:03:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:03:49 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 12:03:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 12:03:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:03:49 --> Final output sent to browser
DEBUG - 2021-07-08 12:03:49 --> Total execution time: 0.1104
INFO - 2021-07-08 12:03:54 --> Config Class Initialized
INFO - 2021-07-08 12:03:54 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:03:54 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:03:54 --> Utf8 Class Initialized
INFO - 2021-07-08 12:03:54 --> URI Class Initialized
INFO - 2021-07-08 12:03:54 --> Router Class Initialized
INFO - 2021-07-08 12:03:54 --> Output Class Initialized
INFO - 2021-07-08 12:03:54 --> Security Class Initialized
DEBUG - 2021-07-08 12:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:03:54 --> Input Class Initialized
INFO - 2021-07-08 12:03:54 --> Language Class Initialized
INFO - 2021-07-08 12:03:54 --> Loader Class Initialized
INFO - 2021-07-08 12:03:54 --> Helper loaded: html_helper
INFO - 2021-07-08 12:03:54 --> Helper loaded: url_helper
INFO - 2021-07-08 12:03:54 --> Helper loaded: form_helper
INFO - 2021-07-08 12:03:54 --> Database Driver Class Initialized
INFO - 2021-07-08 12:03:54 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:03:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:03:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:03:54 --> Encryption Class Initialized
INFO - 2021-07-08 12:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:03:54 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:03:54 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:03:54 --> Model "user_model" initialized
INFO - 2021-07-08 12:03:54 --> Model "role_model" initialized
INFO - 2021-07-08 12:03:54 --> Controller Class Initialized
INFO - 2021-07-08 12:03:54 --> Helper loaded: language_helper
INFO - 2021-07-08 12:03:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:03:54 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:03:54 --> Final output sent to browser
DEBUG - 2021-07-08 12:03:54 --> Total execution time: 0.0650
INFO - 2021-07-08 12:03:54 --> Config Class Initialized
INFO - 2021-07-08 12:03:54 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:03:54 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:03:54 --> Utf8 Class Initialized
INFO - 2021-07-08 12:03:54 --> URI Class Initialized
INFO - 2021-07-08 12:03:54 --> Router Class Initialized
INFO - 2021-07-08 12:03:54 --> Output Class Initialized
INFO - 2021-07-08 12:03:54 --> Security Class Initialized
DEBUG - 2021-07-08 12:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:03:54 --> Input Class Initialized
INFO - 2021-07-08 12:03:54 --> Language Class Initialized
INFO - 2021-07-08 12:03:54 --> Loader Class Initialized
INFO - 2021-07-08 12:03:54 --> Helper loaded: html_helper
INFO - 2021-07-08 12:03:54 --> Helper loaded: url_helper
INFO - 2021-07-08 12:03:54 --> Helper loaded: form_helper
INFO - 2021-07-08 12:03:54 --> Database Driver Class Initialized
INFO - 2021-07-08 12:03:54 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:03:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:03:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:03:54 --> Encryption Class Initialized
INFO - 2021-07-08 12:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:03:54 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:03:54 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:03:54 --> Model "user_model" initialized
INFO - 2021-07-08 12:03:54 --> Model "role_model" initialized
INFO - 2021-07-08 12:03:54 --> Controller Class Initialized
INFO - 2021-07-08 12:03:54 --> Helper loaded: language_helper
INFO - 2021-07-08 12:03:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:03:54 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:03:54 --> Final output sent to browser
DEBUG - 2021-07-08 12:03:54 --> Total execution time: 0.0622
INFO - 2021-07-08 12:04:59 --> Config Class Initialized
INFO - 2021-07-08 12:04:59 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:04:59 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:04:59 --> Utf8 Class Initialized
INFO - 2021-07-08 12:04:59 --> URI Class Initialized
INFO - 2021-07-08 12:04:59 --> Router Class Initialized
INFO - 2021-07-08 12:04:59 --> Output Class Initialized
INFO - 2021-07-08 12:04:59 --> Security Class Initialized
DEBUG - 2021-07-08 12:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:04:59 --> Input Class Initialized
INFO - 2021-07-08 12:04:59 --> Language Class Initialized
INFO - 2021-07-08 12:04:59 --> Loader Class Initialized
INFO - 2021-07-08 12:04:59 --> Helper loaded: html_helper
INFO - 2021-07-08 12:04:59 --> Helper loaded: url_helper
INFO - 2021-07-08 12:04:59 --> Helper loaded: form_helper
INFO - 2021-07-08 12:04:59 --> Database Driver Class Initialized
INFO - 2021-07-08 12:04:59 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:04:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:04:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:04:59 --> Encryption Class Initialized
INFO - 2021-07-08 12:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:04:59 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:04:59 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:04:59 --> Model "user_model" initialized
INFO - 2021-07-08 12:04:59 --> Model "role_model" initialized
INFO - 2021-07-08 12:04:59 --> Controller Class Initialized
INFO - 2021-07-08 12:04:59 --> Helper loaded: language_helper
INFO - 2021-07-08 12:04:59 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:04:59 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:04:59 --> Model "Product_model" initialized
INFO - 2021-07-08 12:04:59 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:04:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:04:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:04:59 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 12:04:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 12:04:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:04:59 --> Final output sent to browser
DEBUG - 2021-07-08 12:04:59 --> Total execution time: 0.1200
INFO - 2021-07-08 12:05:03 --> Config Class Initialized
INFO - 2021-07-08 12:05:03 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:05:03 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:05:03 --> Utf8 Class Initialized
INFO - 2021-07-08 12:05:03 --> URI Class Initialized
INFO - 2021-07-08 12:05:03 --> Router Class Initialized
INFO - 2021-07-08 12:05:03 --> Output Class Initialized
INFO - 2021-07-08 12:05:03 --> Security Class Initialized
DEBUG - 2021-07-08 12:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:05:03 --> Input Class Initialized
INFO - 2021-07-08 12:05:03 --> Language Class Initialized
INFO - 2021-07-08 12:05:03 --> Loader Class Initialized
INFO - 2021-07-08 12:05:03 --> Helper loaded: html_helper
INFO - 2021-07-08 12:05:03 --> Helper loaded: url_helper
INFO - 2021-07-08 12:05:03 --> Helper loaded: form_helper
INFO - 2021-07-08 12:05:03 --> Database Driver Class Initialized
INFO - 2021-07-08 12:05:03 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:05:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:05:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:05:03 --> Encryption Class Initialized
INFO - 2021-07-08 12:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:05:03 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:05:03 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:05:03 --> Model "user_model" initialized
INFO - 2021-07-08 12:05:03 --> Model "role_model" initialized
INFO - 2021-07-08 12:05:03 --> Controller Class Initialized
INFO - 2021-07-08 12:05:03 --> Helper loaded: language_helper
INFO - 2021-07-08 12:05:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:05:03 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:05:03 --> Final output sent to browser
DEBUG - 2021-07-08 12:05:03 --> Total execution time: 0.0627
INFO - 2021-07-08 12:05:03 --> Config Class Initialized
INFO - 2021-07-08 12:05:03 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:05:03 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:05:03 --> Utf8 Class Initialized
INFO - 2021-07-08 12:05:03 --> URI Class Initialized
INFO - 2021-07-08 12:05:03 --> Router Class Initialized
INFO - 2021-07-08 12:05:03 --> Output Class Initialized
INFO - 2021-07-08 12:05:03 --> Security Class Initialized
DEBUG - 2021-07-08 12:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:05:03 --> Input Class Initialized
INFO - 2021-07-08 12:05:03 --> Language Class Initialized
INFO - 2021-07-08 12:05:03 --> Loader Class Initialized
INFO - 2021-07-08 12:05:03 --> Helper loaded: html_helper
INFO - 2021-07-08 12:05:03 --> Helper loaded: url_helper
INFO - 2021-07-08 12:05:03 --> Helper loaded: form_helper
INFO - 2021-07-08 12:05:03 --> Database Driver Class Initialized
INFO - 2021-07-08 12:05:03 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:05:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:05:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:05:03 --> Encryption Class Initialized
INFO - 2021-07-08 12:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:05:03 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:05:03 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:05:03 --> Model "user_model" initialized
INFO - 2021-07-08 12:05:03 --> Model "role_model" initialized
INFO - 2021-07-08 12:05:03 --> Controller Class Initialized
INFO - 2021-07-08 12:05:03 --> Helper loaded: language_helper
INFO - 2021-07-08 12:05:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:05:03 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:05:03 --> Final output sent to browser
DEBUG - 2021-07-08 12:05:03 --> Total execution time: 0.0678
INFO - 2021-07-08 12:05:20 --> Config Class Initialized
INFO - 2021-07-08 12:05:20 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:05:20 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:05:20 --> Utf8 Class Initialized
INFO - 2021-07-08 12:05:20 --> URI Class Initialized
INFO - 2021-07-08 12:05:20 --> Router Class Initialized
INFO - 2021-07-08 12:05:20 --> Output Class Initialized
INFO - 2021-07-08 12:05:20 --> Security Class Initialized
DEBUG - 2021-07-08 12:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:05:20 --> Input Class Initialized
INFO - 2021-07-08 12:05:20 --> Language Class Initialized
INFO - 2021-07-08 12:05:20 --> Loader Class Initialized
INFO - 2021-07-08 12:05:20 --> Helper loaded: html_helper
INFO - 2021-07-08 12:05:20 --> Helper loaded: url_helper
INFO - 2021-07-08 12:05:20 --> Helper loaded: form_helper
INFO - 2021-07-08 12:05:20 --> Database Driver Class Initialized
INFO - 2021-07-08 12:05:20 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:05:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:05:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:05:20 --> Encryption Class Initialized
INFO - 2021-07-08 12:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:05:20 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:05:20 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:05:20 --> Model "user_model" initialized
INFO - 2021-07-08 12:05:20 --> Model "role_model" initialized
INFO - 2021-07-08 12:05:20 --> Controller Class Initialized
INFO - 2021-07-08 12:05:20 --> Helper loaded: language_helper
INFO - 2021-07-08 12:05:20 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:05:20 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:05:20 --> Model "Product_model" initialized
INFO - 2021-07-08 12:05:20 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:05:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:05:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:05:20 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 12:05:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 12:05:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:05:20 --> Final output sent to browser
DEBUG - 2021-07-08 12:05:20 --> Total execution time: 0.1074
INFO - 2021-07-08 12:05:23 --> Config Class Initialized
INFO - 2021-07-08 12:05:23 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:05:23 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:05:23 --> Utf8 Class Initialized
INFO - 2021-07-08 12:05:23 --> URI Class Initialized
INFO - 2021-07-08 12:05:23 --> Router Class Initialized
INFO - 2021-07-08 12:05:23 --> Output Class Initialized
INFO - 2021-07-08 12:05:23 --> Security Class Initialized
DEBUG - 2021-07-08 12:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:05:23 --> Input Class Initialized
INFO - 2021-07-08 12:05:23 --> Language Class Initialized
INFO - 2021-07-08 12:05:23 --> Loader Class Initialized
INFO - 2021-07-08 12:05:23 --> Helper loaded: html_helper
INFO - 2021-07-08 12:05:23 --> Helper loaded: url_helper
INFO - 2021-07-08 12:05:23 --> Helper loaded: form_helper
INFO - 2021-07-08 12:05:23 --> Database Driver Class Initialized
INFO - 2021-07-08 12:05:23 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:05:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:05:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:05:23 --> Encryption Class Initialized
INFO - 2021-07-08 12:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:05:23 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:05:23 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:05:23 --> Model "user_model" initialized
INFO - 2021-07-08 12:05:23 --> Model "role_model" initialized
INFO - 2021-07-08 12:05:23 --> Controller Class Initialized
INFO - 2021-07-08 12:05:23 --> Helper loaded: language_helper
INFO - 2021-07-08 12:05:23 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:05:23 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:05:23 --> Final output sent to browser
DEBUG - 2021-07-08 12:05:23 --> Total execution time: 0.0642
INFO - 2021-07-08 12:05:23 --> Config Class Initialized
INFO - 2021-07-08 12:05:23 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:05:23 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:05:23 --> Utf8 Class Initialized
INFO - 2021-07-08 12:05:23 --> URI Class Initialized
INFO - 2021-07-08 12:05:23 --> Router Class Initialized
INFO - 2021-07-08 12:05:23 --> Output Class Initialized
INFO - 2021-07-08 12:05:23 --> Security Class Initialized
DEBUG - 2021-07-08 12:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:05:23 --> Input Class Initialized
INFO - 2021-07-08 12:05:23 --> Language Class Initialized
INFO - 2021-07-08 12:05:23 --> Loader Class Initialized
INFO - 2021-07-08 12:05:23 --> Helper loaded: html_helper
INFO - 2021-07-08 12:05:23 --> Helper loaded: url_helper
INFO - 2021-07-08 12:05:23 --> Helper loaded: form_helper
INFO - 2021-07-08 12:05:23 --> Database Driver Class Initialized
INFO - 2021-07-08 12:05:23 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:05:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:05:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:05:23 --> Encryption Class Initialized
INFO - 2021-07-08 12:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:05:23 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:05:23 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:05:23 --> Model "user_model" initialized
INFO - 2021-07-08 12:05:23 --> Model "role_model" initialized
INFO - 2021-07-08 12:05:23 --> Controller Class Initialized
INFO - 2021-07-08 12:05:23 --> Helper loaded: language_helper
INFO - 2021-07-08 12:05:23 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:05:23 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:05:23 --> Final output sent to browser
DEBUG - 2021-07-08 12:05:23 --> Total execution time: 0.0717
INFO - 2021-07-08 12:05:53 --> Config Class Initialized
INFO - 2021-07-08 12:05:53 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:05:53 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:05:53 --> Utf8 Class Initialized
INFO - 2021-07-08 12:05:53 --> URI Class Initialized
INFO - 2021-07-08 12:05:53 --> Router Class Initialized
INFO - 2021-07-08 12:05:53 --> Output Class Initialized
INFO - 2021-07-08 12:05:53 --> Security Class Initialized
DEBUG - 2021-07-08 12:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:05:53 --> Input Class Initialized
INFO - 2021-07-08 12:05:53 --> Language Class Initialized
INFO - 2021-07-08 12:05:53 --> Loader Class Initialized
INFO - 2021-07-08 12:05:53 --> Helper loaded: html_helper
INFO - 2021-07-08 12:05:53 --> Helper loaded: url_helper
INFO - 2021-07-08 12:05:53 --> Helper loaded: form_helper
INFO - 2021-07-08 12:05:53 --> Database Driver Class Initialized
INFO - 2021-07-08 12:05:53 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:05:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:05:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:05:53 --> Encryption Class Initialized
INFO - 2021-07-08 12:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:05:53 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:05:53 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:05:53 --> Model "user_model" initialized
INFO - 2021-07-08 12:05:53 --> Model "role_model" initialized
INFO - 2021-07-08 12:05:53 --> Controller Class Initialized
INFO - 2021-07-08 12:05:53 --> Helper loaded: language_helper
INFO - 2021-07-08 12:05:53 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:05:53 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:05:53 --> Model "Product_model" initialized
INFO - 2021-07-08 12:05:53 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:05:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:05:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:05:53 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 12:05:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 12:05:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:05:53 --> Final output sent to browser
DEBUG - 2021-07-08 12:05:53 --> Total execution time: 0.1139
INFO - 2021-07-08 12:05:56 --> Config Class Initialized
INFO - 2021-07-08 12:05:56 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:05:56 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:05:56 --> Utf8 Class Initialized
INFO - 2021-07-08 12:05:56 --> URI Class Initialized
INFO - 2021-07-08 12:05:56 --> Router Class Initialized
INFO - 2021-07-08 12:05:56 --> Output Class Initialized
INFO - 2021-07-08 12:05:56 --> Security Class Initialized
DEBUG - 2021-07-08 12:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:05:56 --> Input Class Initialized
INFO - 2021-07-08 12:05:56 --> Language Class Initialized
INFO - 2021-07-08 12:05:56 --> Loader Class Initialized
INFO - 2021-07-08 12:05:56 --> Helper loaded: html_helper
INFO - 2021-07-08 12:05:56 --> Helper loaded: url_helper
INFO - 2021-07-08 12:05:56 --> Helper loaded: form_helper
INFO - 2021-07-08 12:05:56 --> Database Driver Class Initialized
INFO - 2021-07-08 12:05:56 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:05:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:05:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:05:56 --> Encryption Class Initialized
INFO - 2021-07-08 12:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:05:56 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:05:56 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:05:56 --> Model "user_model" initialized
INFO - 2021-07-08 12:05:56 --> Model "role_model" initialized
INFO - 2021-07-08 12:05:56 --> Controller Class Initialized
INFO - 2021-07-08 12:05:56 --> Helper loaded: language_helper
INFO - 2021-07-08 12:05:56 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:05:56 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:05:56 --> Final output sent to browser
DEBUG - 2021-07-08 12:05:56 --> Total execution time: 0.0603
INFO - 2021-07-08 12:05:56 --> Config Class Initialized
INFO - 2021-07-08 12:05:56 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:05:56 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:05:56 --> Utf8 Class Initialized
INFO - 2021-07-08 12:05:56 --> URI Class Initialized
INFO - 2021-07-08 12:05:56 --> Router Class Initialized
INFO - 2021-07-08 12:05:56 --> Output Class Initialized
INFO - 2021-07-08 12:05:56 --> Security Class Initialized
DEBUG - 2021-07-08 12:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:05:56 --> Input Class Initialized
INFO - 2021-07-08 12:05:56 --> Language Class Initialized
INFO - 2021-07-08 12:05:56 --> Loader Class Initialized
INFO - 2021-07-08 12:05:56 --> Helper loaded: html_helper
INFO - 2021-07-08 12:05:56 --> Helper loaded: url_helper
INFO - 2021-07-08 12:05:56 --> Helper loaded: form_helper
INFO - 2021-07-08 12:05:56 --> Database Driver Class Initialized
INFO - 2021-07-08 12:05:56 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:05:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:05:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:05:56 --> Encryption Class Initialized
INFO - 2021-07-08 12:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:05:56 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:05:56 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:05:56 --> Model "user_model" initialized
INFO - 2021-07-08 12:05:56 --> Model "role_model" initialized
INFO - 2021-07-08 12:05:56 --> Controller Class Initialized
INFO - 2021-07-08 12:05:56 --> Helper loaded: language_helper
INFO - 2021-07-08 12:05:56 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:05:56 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:05:56 --> Final output sent to browser
DEBUG - 2021-07-08 12:05:56 --> Total execution time: 0.0617
INFO - 2021-07-08 12:06:01 --> Config Class Initialized
INFO - 2021-07-08 12:06:01 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:01 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:01 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:01 --> URI Class Initialized
INFO - 2021-07-08 12:06:01 --> Router Class Initialized
INFO - 2021-07-08 12:06:01 --> Output Class Initialized
INFO - 2021-07-08 12:06:01 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:01 --> Input Class Initialized
INFO - 2021-07-08 12:06:01 --> Language Class Initialized
INFO - 2021-07-08 12:06:01 --> Loader Class Initialized
INFO - 2021-07-08 12:06:01 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:01 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:01 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:01 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:01 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:01 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:01 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:01 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:01 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:01 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:01 --> Controller Class Initialized
INFO - 2021-07-08 12:06:01 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:01 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:01 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:06:01 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:01 --> Total execution time: 0.0661
INFO - 2021-07-08 12:06:01 --> Config Class Initialized
INFO - 2021-07-08 12:06:01 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:01 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:01 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:01 --> URI Class Initialized
INFO - 2021-07-08 12:06:01 --> Router Class Initialized
INFO - 2021-07-08 12:06:01 --> Output Class Initialized
INFO - 2021-07-08 12:06:01 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:01 --> Input Class Initialized
INFO - 2021-07-08 12:06:01 --> Language Class Initialized
INFO - 2021-07-08 12:06:01 --> Loader Class Initialized
INFO - 2021-07-08 12:06:01 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:01 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:01 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:01 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:01 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:01 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:01 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:01 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:01 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:01 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:01 --> Controller Class Initialized
INFO - 2021-07-08 12:06:01 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:01 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:01 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:06:01 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:01 --> Total execution time: 0.0707
INFO - 2021-07-08 12:06:05 --> Config Class Initialized
INFO - 2021-07-08 12:06:05 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:05 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:05 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:05 --> URI Class Initialized
INFO - 2021-07-08 12:06:05 --> Router Class Initialized
INFO - 2021-07-08 12:06:05 --> Output Class Initialized
INFO - 2021-07-08 12:06:05 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:05 --> Input Class Initialized
INFO - 2021-07-08 12:06:05 --> Language Class Initialized
INFO - 2021-07-08 12:06:05 --> Loader Class Initialized
INFO - 2021-07-08 12:06:05 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:05 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:05 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:05 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:06 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:06 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:06 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:06 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:06 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:06 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:06 --> Controller Class Initialized
INFO - 2021-07-08 12:06:06 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:06 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:06:06 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:06 --> Total execution time: 0.0636
INFO - 2021-07-08 12:06:06 --> Config Class Initialized
INFO - 2021-07-08 12:06:06 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:06 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:06 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:06 --> URI Class Initialized
INFO - 2021-07-08 12:06:06 --> Router Class Initialized
INFO - 2021-07-08 12:06:06 --> Output Class Initialized
INFO - 2021-07-08 12:06:06 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:06 --> Input Class Initialized
INFO - 2021-07-08 12:06:06 --> Language Class Initialized
INFO - 2021-07-08 12:06:06 --> Loader Class Initialized
INFO - 2021-07-08 12:06:06 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:06 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:06 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:06 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:06 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:06 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:06 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:06 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:06 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:06 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:06 --> Controller Class Initialized
INFO - 2021-07-08 12:06:06 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:06 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:06:06 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:06 --> Total execution time: 0.0661
INFO - 2021-07-08 12:06:08 --> Config Class Initialized
INFO - 2021-07-08 12:06:08 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:08 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:08 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:08 --> URI Class Initialized
INFO - 2021-07-08 12:06:08 --> Router Class Initialized
INFO - 2021-07-08 12:06:08 --> Output Class Initialized
INFO - 2021-07-08 12:06:08 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:08 --> Input Class Initialized
INFO - 2021-07-08 12:06:08 --> Language Class Initialized
INFO - 2021-07-08 12:06:08 --> Loader Class Initialized
INFO - 2021-07-08 12:06:08 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:08 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:08 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:08 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:08 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:08 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:08 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:08 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:08 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:08 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:08 --> Controller Class Initialized
INFO - 2021-07-08 12:06:08 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:08 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:06:08 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:08 --> Total execution time: 0.0671
INFO - 2021-07-08 12:06:09 --> Config Class Initialized
INFO - 2021-07-08 12:06:09 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:09 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:09 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:09 --> URI Class Initialized
INFO - 2021-07-08 12:06:09 --> Router Class Initialized
INFO - 2021-07-08 12:06:09 --> Output Class Initialized
INFO - 2021-07-08 12:06:09 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:09 --> Input Class Initialized
INFO - 2021-07-08 12:06:09 --> Language Class Initialized
INFO - 2021-07-08 12:06:09 --> Loader Class Initialized
INFO - 2021-07-08 12:06:09 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:09 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:09 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:09 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:09 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:09 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:09 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:09 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:09 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:09 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:09 --> Controller Class Initialized
INFO - 2021-07-08 12:06:09 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:09 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:06:09 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:09 --> Total execution time: 0.0685
INFO - 2021-07-08 12:06:12 --> Config Class Initialized
INFO - 2021-07-08 12:06:12 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:12 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:12 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:12 --> URI Class Initialized
INFO - 2021-07-08 12:06:12 --> Router Class Initialized
INFO - 2021-07-08 12:06:12 --> Output Class Initialized
INFO - 2021-07-08 12:06:12 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:12 --> Input Class Initialized
INFO - 2021-07-08 12:06:12 --> Language Class Initialized
INFO - 2021-07-08 12:06:12 --> Loader Class Initialized
INFO - 2021-07-08 12:06:12 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:12 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:12 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:12 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:12 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:12 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:12 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:12 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:12 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:12 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:12 --> Controller Class Initialized
INFO - 2021-07-08 12:06:12 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:12 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:06:12 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:12 --> Total execution time: 0.0637
INFO - 2021-07-08 12:06:12 --> Config Class Initialized
INFO - 2021-07-08 12:06:12 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:12 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:12 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:12 --> URI Class Initialized
INFO - 2021-07-08 12:06:12 --> Router Class Initialized
INFO - 2021-07-08 12:06:12 --> Output Class Initialized
INFO - 2021-07-08 12:06:12 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:12 --> Input Class Initialized
INFO - 2021-07-08 12:06:12 --> Language Class Initialized
INFO - 2021-07-08 12:06:12 --> Loader Class Initialized
INFO - 2021-07-08 12:06:12 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:12 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:12 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:12 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:13 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:13 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:13 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:13 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:13 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:13 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:13 --> Controller Class Initialized
INFO - 2021-07-08 12:06:13 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:13 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:06:13 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:13 --> Total execution time: 0.0668
INFO - 2021-07-08 12:06:16 --> Config Class Initialized
INFO - 2021-07-08 12:06:16 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:16 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:16 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:16 --> URI Class Initialized
INFO - 2021-07-08 12:06:16 --> Router Class Initialized
INFO - 2021-07-08 12:06:16 --> Output Class Initialized
INFO - 2021-07-08 12:06:16 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:16 --> Input Class Initialized
INFO - 2021-07-08 12:06:16 --> Language Class Initialized
INFO - 2021-07-08 12:06:16 --> Loader Class Initialized
INFO - 2021-07-08 12:06:16 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:16 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:16 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:16 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:16 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:16 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:16 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:16 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:16 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:16 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:16 --> Controller Class Initialized
INFO - 2021-07-08 12:06:16 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:16 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:16 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:06:16 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:16 --> Total execution time: 0.0643
INFO - 2021-07-08 12:06:16 --> Config Class Initialized
INFO - 2021-07-08 12:06:16 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:16 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:16 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:16 --> URI Class Initialized
INFO - 2021-07-08 12:06:16 --> Router Class Initialized
INFO - 2021-07-08 12:06:16 --> Output Class Initialized
INFO - 2021-07-08 12:06:16 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:16 --> Input Class Initialized
INFO - 2021-07-08 12:06:16 --> Language Class Initialized
INFO - 2021-07-08 12:06:16 --> Loader Class Initialized
INFO - 2021-07-08 12:06:16 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:16 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:16 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:16 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:16 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:16 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:16 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:16 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:16 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:16 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:16 --> Controller Class Initialized
INFO - 2021-07-08 12:06:16 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:16 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:16 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:06:16 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:16 --> Total execution time: 0.0667
INFO - 2021-07-08 12:06:19 --> Config Class Initialized
INFO - 2021-07-08 12:06:19 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:19 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:19 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:19 --> URI Class Initialized
INFO - 2021-07-08 12:06:19 --> Router Class Initialized
INFO - 2021-07-08 12:06:19 --> Output Class Initialized
INFO - 2021-07-08 12:06:19 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:19 --> Input Class Initialized
INFO - 2021-07-08 12:06:19 --> Language Class Initialized
INFO - 2021-07-08 12:06:19 --> Loader Class Initialized
INFO - 2021-07-08 12:06:19 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:19 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:19 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:19 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:19 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:19 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:19 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:19 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:19 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:19 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:19 --> Controller Class Initialized
INFO - 2021-07-08 12:06:19 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:19 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:19 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:06:19 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:19 --> Total execution time: 0.0614
INFO - 2021-07-08 12:06:19 --> Config Class Initialized
INFO - 2021-07-08 12:06:19 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:19 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:19 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:19 --> URI Class Initialized
INFO - 2021-07-08 12:06:19 --> Router Class Initialized
INFO - 2021-07-08 12:06:19 --> Output Class Initialized
INFO - 2021-07-08 12:06:19 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:19 --> Input Class Initialized
INFO - 2021-07-08 12:06:19 --> Language Class Initialized
INFO - 2021-07-08 12:06:19 --> Loader Class Initialized
INFO - 2021-07-08 12:06:19 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:19 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:19 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:19 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:19 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:19 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:19 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:19 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:19 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:19 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:19 --> Controller Class Initialized
INFO - 2021-07-08 12:06:19 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:19 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:19 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:06:19 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:19 --> Total execution time: 0.0675
INFO - 2021-07-08 12:06:21 --> Config Class Initialized
INFO - 2021-07-08 12:06:21 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:21 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:21 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:21 --> URI Class Initialized
INFO - 2021-07-08 12:06:21 --> Router Class Initialized
INFO - 2021-07-08 12:06:21 --> Output Class Initialized
INFO - 2021-07-08 12:06:21 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:21 --> Input Class Initialized
INFO - 2021-07-08 12:06:21 --> Language Class Initialized
INFO - 2021-07-08 12:06:21 --> Loader Class Initialized
INFO - 2021-07-08 12:06:21 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:21 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:21 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:21 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:21 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:21 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:21 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:21 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:21 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:21 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:21 --> Controller Class Initialized
INFO - 2021-07-08 12:06:21 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:21 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:06:21 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:21 --> Total execution time: 0.0660
INFO - 2021-07-08 12:06:21 --> Config Class Initialized
INFO - 2021-07-08 12:06:21 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:21 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:21 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:21 --> URI Class Initialized
INFO - 2021-07-08 12:06:21 --> Router Class Initialized
INFO - 2021-07-08 12:06:21 --> Output Class Initialized
INFO - 2021-07-08 12:06:21 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:21 --> Input Class Initialized
INFO - 2021-07-08 12:06:21 --> Language Class Initialized
INFO - 2021-07-08 12:06:21 --> Loader Class Initialized
INFO - 2021-07-08 12:06:21 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:21 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:21 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:21 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:21 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:21 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:21 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:21 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:21 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:21 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:21 --> Controller Class Initialized
INFO - 2021-07-08 12:06:21 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:21 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:06:21 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:21 --> Total execution time: 0.0658
INFO - 2021-07-08 12:06:24 --> Config Class Initialized
INFO - 2021-07-08 12:06:24 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:24 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:24 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:24 --> URI Class Initialized
INFO - 2021-07-08 12:06:24 --> Router Class Initialized
INFO - 2021-07-08 12:06:24 --> Output Class Initialized
INFO - 2021-07-08 12:06:24 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:24 --> Input Class Initialized
INFO - 2021-07-08 12:06:24 --> Language Class Initialized
INFO - 2021-07-08 12:06:24 --> Loader Class Initialized
INFO - 2021-07-08 12:06:24 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:24 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:24 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:24 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:24 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:24 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:24 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:24 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:24 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:24 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:24 --> Controller Class Initialized
INFO - 2021-07-08 12:06:24 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:24 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:06:24 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:24 --> Total execution time: 0.0695
INFO - 2021-07-08 12:06:24 --> Config Class Initialized
INFO - 2021-07-08 12:06:24 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:24 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:24 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:24 --> URI Class Initialized
INFO - 2021-07-08 12:06:24 --> Router Class Initialized
INFO - 2021-07-08 12:06:24 --> Output Class Initialized
INFO - 2021-07-08 12:06:24 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:24 --> Input Class Initialized
INFO - 2021-07-08 12:06:24 --> Language Class Initialized
INFO - 2021-07-08 12:06:24 --> Loader Class Initialized
INFO - 2021-07-08 12:06:24 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:24 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:24 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:24 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:24 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:24 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:24 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:24 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:24 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:24 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:24 --> Controller Class Initialized
INFO - 2021-07-08 12:06:24 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:24 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:06:24 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:24 --> Total execution time: 0.0649
INFO - 2021-07-08 12:06:28 --> Config Class Initialized
INFO - 2021-07-08 12:06:28 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:28 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:28 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:28 --> URI Class Initialized
INFO - 2021-07-08 12:06:28 --> Router Class Initialized
INFO - 2021-07-08 12:06:28 --> Output Class Initialized
INFO - 2021-07-08 12:06:28 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:28 --> Input Class Initialized
INFO - 2021-07-08 12:06:28 --> Language Class Initialized
INFO - 2021-07-08 12:06:28 --> Loader Class Initialized
INFO - 2021-07-08 12:06:28 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:28 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:28 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:28 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:28 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:28 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:28 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:28 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:28 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:28 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:28 --> Controller Class Initialized
INFO - 2021-07-08 12:06:28 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:28 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:28 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:06:28 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:28 --> Total execution time: 0.0591
INFO - 2021-07-08 12:06:28 --> Config Class Initialized
INFO - 2021-07-08 12:06:28 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:28 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:28 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:28 --> URI Class Initialized
INFO - 2021-07-08 12:06:28 --> Router Class Initialized
INFO - 2021-07-08 12:06:29 --> Output Class Initialized
INFO - 2021-07-08 12:06:29 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:29 --> Input Class Initialized
INFO - 2021-07-08 12:06:29 --> Language Class Initialized
INFO - 2021-07-08 12:06:29 --> Loader Class Initialized
INFO - 2021-07-08 12:06:29 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:29 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:29 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:29 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:29 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:29 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:29 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:29 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:29 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:29 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:29 --> Controller Class Initialized
INFO - 2021-07-08 12:06:29 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:29 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:29 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:06:29 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:29 --> Total execution time: 0.0608
INFO - 2021-07-08 12:06:31 --> Config Class Initialized
INFO - 2021-07-08 12:06:31 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:31 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:31 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:31 --> URI Class Initialized
INFO - 2021-07-08 12:06:31 --> Router Class Initialized
INFO - 2021-07-08 12:06:31 --> Output Class Initialized
INFO - 2021-07-08 12:06:31 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:31 --> Input Class Initialized
INFO - 2021-07-08 12:06:31 --> Language Class Initialized
INFO - 2021-07-08 12:06:31 --> Loader Class Initialized
INFO - 2021-07-08 12:06:31 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:31 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:31 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:31 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:31 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:31 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:31 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:31 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:31 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:31 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:31 --> Controller Class Initialized
INFO - 2021-07-08 12:06:31 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:31 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:31 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:06:31 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:31 --> Total execution time: 0.0623
INFO - 2021-07-08 12:06:31 --> Config Class Initialized
INFO - 2021-07-08 12:06:31 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:31 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:31 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:31 --> URI Class Initialized
INFO - 2021-07-08 12:06:31 --> Router Class Initialized
INFO - 2021-07-08 12:06:31 --> Output Class Initialized
INFO - 2021-07-08 12:06:31 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:31 --> Input Class Initialized
INFO - 2021-07-08 12:06:31 --> Language Class Initialized
INFO - 2021-07-08 12:06:31 --> Loader Class Initialized
INFO - 2021-07-08 12:06:31 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:31 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:31 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:31 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:31 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:31 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:31 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:31 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:31 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:31 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:31 --> Controller Class Initialized
INFO - 2021-07-08 12:06:31 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:31 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:31 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:06:31 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:31 --> Total execution time: 0.0628
INFO - 2021-07-08 12:06:33 --> Config Class Initialized
INFO - 2021-07-08 12:06:33 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:33 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:33 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:33 --> URI Class Initialized
INFO - 2021-07-08 12:06:33 --> Router Class Initialized
INFO - 2021-07-08 12:06:33 --> Output Class Initialized
INFO - 2021-07-08 12:06:33 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:33 --> Input Class Initialized
INFO - 2021-07-08 12:06:33 --> Language Class Initialized
INFO - 2021-07-08 12:06:33 --> Loader Class Initialized
INFO - 2021-07-08 12:06:33 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:33 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:33 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:33 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:33 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:33 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:34 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:34 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:34 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:34 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:34 --> Controller Class Initialized
INFO - 2021-07-08 12:06:34 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:34 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:34 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:06:34 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:34 --> Total execution time: 0.0604
INFO - 2021-07-08 12:06:34 --> Config Class Initialized
INFO - 2021-07-08 12:06:34 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:34 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:34 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:34 --> URI Class Initialized
INFO - 2021-07-08 12:06:34 --> Router Class Initialized
INFO - 2021-07-08 12:06:34 --> Output Class Initialized
INFO - 2021-07-08 12:06:34 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:34 --> Input Class Initialized
INFO - 2021-07-08 12:06:34 --> Language Class Initialized
INFO - 2021-07-08 12:06:34 --> Loader Class Initialized
INFO - 2021-07-08 12:06:34 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:34 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:34 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:34 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:34 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:34 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:34 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:34 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:34 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:34 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:34 --> Controller Class Initialized
INFO - 2021-07-08 12:06:34 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:34 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:34 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:06:34 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:34 --> Total execution time: 0.0596
INFO - 2021-07-08 12:06:36 --> Config Class Initialized
INFO - 2021-07-08 12:06:36 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:36 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:36 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:36 --> URI Class Initialized
INFO - 2021-07-08 12:06:36 --> Router Class Initialized
INFO - 2021-07-08 12:06:36 --> Output Class Initialized
INFO - 2021-07-08 12:06:36 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:36 --> Input Class Initialized
INFO - 2021-07-08 12:06:36 --> Language Class Initialized
INFO - 2021-07-08 12:06:36 --> Loader Class Initialized
INFO - 2021-07-08 12:06:36 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:36 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:36 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:36 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:36 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:36 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:36 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:36 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:36 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:36 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:36 --> Controller Class Initialized
INFO - 2021-07-08 12:06:36 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:36 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:36 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:06:36 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:36 --> Total execution time: 0.0564
INFO - 2021-07-08 12:06:36 --> Config Class Initialized
INFO - 2021-07-08 12:06:36 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:36 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:36 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:36 --> URI Class Initialized
INFO - 2021-07-08 12:06:36 --> Router Class Initialized
INFO - 2021-07-08 12:06:36 --> Output Class Initialized
INFO - 2021-07-08 12:06:36 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:36 --> Input Class Initialized
INFO - 2021-07-08 12:06:36 --> Language Class Initialized
INFO - 2021-07-08 12:06:36 --> Loader Class Initialized
INFO - 2021-07-08 12:06:36 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:36 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:36 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:36 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:36 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:36 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:36 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:36 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:36 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:36 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:36 --> Controller Class Initialized
INFO - 2021-07-08 12:06:36 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:36 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:36 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:06:36 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:36 --> Total execution time: 0.0596
INFO - 2021-07-08 12:06:39 --> Config Class Initialized
INFO - 2021-07-08 12:06:39 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:39 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:39 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:39 --> URI Class Initialized
INFO - 2021-07-08 12:06:39 --> Router Class Initialized
INFO - 2021-07-08 12:06:39 --> Output Class Initialized
INFO - 2021-07-08 12:06:39 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:39 --> Input Class Initialized
INFO - 2021-07-08 12:06:39 --> Language Class Initialized
INFO - 2021-07-08 12:06:39 --> Loader Class Initialized
INFO - 2021-07-08 12:06:39 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:39 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:39 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:39 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:39 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:39 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:39 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:39 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:39 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:39 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:39 --> Controller Class Initialized
INFO - 2021-07-08 12:06:39 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:39 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:06:39 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:39 --> Total execution time: 0.0541
INFO - 2021-07-08 12:06:40 --> Config Class Initialized
INFO - 2021-07-08 12:06:40 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:40 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:40 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:40 --> URI Class Initialized
INFO - 2021-07-08 12:06:40 --> Router Class Initialized
INFO - 2021-07-08 12:06:40 --> Output Class Initialized
INFO - 2021-07-08 12:06:40 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:40 --> Input Class Initialized
INFO - 2021-07-08 12:06:40 --> Language Class Initialized
INFO - 2021-07-08 12:06:40 --> Loader Class Initialized
INFO - 2021-07-08 12:06:40 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:40 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:40 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:40 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:40 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:40 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:40 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:40 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:40 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:40 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:40 --> Controller Class Initialized
INFO - 2021-07-08 12:06:40 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:40 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:40 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:06:40 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:40 --> Total execution time: 0.0659
INFO - 2021-07-08 12:06:43 --> Config Class Initialized
INFO - 2021-07-08 12:06:43 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:43 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:43 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:43 --> URI Class Initialized
INFO - 2021-07-08 12:06:43 --> Router Class Initialized
INFO - 2021-07-08 12:06:43 --> Output Class Initialized
INFO - 2021-07-08 12:06:43 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:43 --> Input Class Initialized
INFO - 2021-07-08 12:06:43 --> Language Class Initialized
INFO - 2021-07-08 12:06:43 --> Loader Class Initialized
INFO - 2021-07-08 12:06:43 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:43 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:43 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:43 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:43 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:43 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:43 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:43 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:43 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:43 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:43 --> Controller Class Initialized
INFO - 2021-07-08 12:06:43 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:43 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:43 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:06:43 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:43 --> Total execution time: 0.0633
INFO - 2021-07-08 12:06:43 --> Config Class Initialized
INFO - 2021-07-08 12:06:43 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:43 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:43 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:43 --> URI Class Initialized
INFO - 2021-07-08 12:06:43 --> Router Class Initialized
INFO - 2021-07-08 12:06:43 --> Output Class Initialized
INFO - 2021-07-08 12:06:43 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:43 --> Input Class Initialized
INFO - 2021-07-08 12:06:43 --> Language Class Initialized
INFO - 2021-07-08 12:06:43 --> Loader Class Initialized
INFO - 2021-07-08 12:06:43 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:43 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:43 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:43 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:43 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:43 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:43 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:43 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:43 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:43 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:43 --> Controller Class Initialized
INFO - 2021-07-08 12:06:43 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:43 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:43 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:06:43 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:43 --> Total execution time: 0.0640
INFO - 2021-07-08 12:06:45 --> Config Class Initialized
INFO - 2021-07-08 12:06:45 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:45 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:45 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:45 --> URI Class Initialized
INFO - 2021-07-08 12:06:45 --> Router Class Initialized
INFO - 2021-07-08 12:06:45 --> Output Class Initialized
INFO - 2021-07-08 12:06:45 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:45 --> Input Class Initialized
INFO - 2021-07-08 12:06:45 --> Language Class Initialized
INFO - 2021-07-08 12:06:45 --> Loader Class Initialized
INFO - 2021-07-08 12:06:45 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:45 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:45 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:45 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:45 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:45 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:45 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:45 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:45 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:45 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:45 --> Controller Class Initialized
INFO - 2021-07-08 12:06:45 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:45 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:45 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:06:45 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:45 --> Total execution time: 0.0578
INFO - 2021-07-08 12:06:45 --> Config Class Initialized
INFO - 2021-07-08 12:06:45 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:45 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:45 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:45 --> URI Class Initialized
INFO - 2021-07-08 12:06:45 --> Router Class Initialized
INFO - 2021-07-08 12:06:45 --> Output Class Initialized
INFO - 2021-07-08 12:06:45 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:45 --> Input Class Initialized
INFO - 2021-07-08 12:06:45 --> Language Class Initialized
INFO - 2021-07-08 12:06:45 --> Loader Class Initialized
INFO - 2021-07-08 12:06:45 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:45 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:45 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:45 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:45 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:45 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:45 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:45 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:45 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:45 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:45 --> Controller Class Initialized
INFO - 2021-07-08 12:06:45 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:45 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:45 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:06:45 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:45 --> Total execution time: 0.0583
INFO - 2021-07-08 12:06:47 --> Config Class Initialized
INFO - 2021-07-08 12:06:47 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:47 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:47 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:47 --> URI Class Initialized
INFO - 2021-07-08 12:06:47 --> Router Class Initialized
INFO - 2021-07-08 12:06:47 --> Output Class Initialized
INFO - 2021-07-08 12:06:47 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:47 --> Input Class Initialized
INFO - 2021-07-08 12:06:47 --> Language Class Initialized
INFO - 2021-07-08 12:06:47 --> Loader Class Initialized
INFO - 2021-07-08 12:06:47 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:47 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:47 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:47 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:47 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:47 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:47 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:47 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:47 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:47 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:47 --> Controller Class Initialized
INFO - 2021-07-08 12:06:47 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:47 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:47 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:06:47 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:47 --> Total execution time: 0.0626
INFO - 2021-07-08 12:06:47 --> Config Class Initialized
INFO - 2021-07-08 12:06:47 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:06:47 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:06:47 --> Utf8 Class Initialized
INFO - 2021-07-08 12:06:47 --> URI Class Initialized
INFO - 2021-07-08 12:06:47 --> Router Class Initialized
INFO - 2021-07-08 12:06:47 --> Output Class Initialized
INFO - 2021-07-08 12:06:47 --> Security Class Initialized
DEBUG - 2021-07-08 12:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:06:47 --> Input Class Initialized
INFO - 2021-07-08 12:06:47 --> Language Class Initialized
INFO - 2021-07-08 12:06:47 --> Loader Class Initialized
INFO - 2021-07-08 12:06:47 --> Helper loaded: html_helper
INFO - 2021-07-08 12:06:47 --> Helper loaded: url_helper
INFO - 2021-07-08 12:06:47 --> Helper loaded: form_helper
INFO - 2021-07-08 12:06:47 --> Database Driver Class Initialized
INFO - 2021-07-08 12:06:47 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:06:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:06:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:06:47 --> Encryption Class Initialized
INFO - 2021-07-08 12:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:06:47 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:06:47 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:06:47 --> Model "user_model" initialized
INFO - 2021-07-08 12:06:47 --> Model "role_model" initialized
INFO - 2021-07-08 12:06:47 --> Controller Class Initialized
INFO - 2021-07-08 12:06:47 --> Helper loaded: language_helper
INFO - 2021-07-08 12:06:47 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:06:47 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:06:47 --> Final output sent to browser
DEBUG - 2021-07-08 12:06:47 --> Total execution time: 0.0646
INFO - 2021-07-08 12:07:53 --> Config Class Initialized
INFO - 2021-07-08 12:07:53 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:07:53 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:07:53 --> Utf8 Class Initialized
INFO - 2021-07-08 12:07:53 --> URI Class Initialized
INFO - 2021-07-08 12:07:53 --> Router Class Initialized
INFO - 2021-07-08 12:07:53 --> Output Class Initialized
INFO - 2021-07-08 12:07:53 --> Security Class Initialized
DEBUG - 2021-07-08 12:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:07:53 --> Input Class Initialized
INFO - 2021-07-08 12:07:53 --> Language Class Initialized
INFO - 2021-07-08 12:07:53 --> Loader Class Initialized
INFO - 2021-07-08 12:07:53 --> Helper loaded: html_helper
INFO - 2021-07-08 12:07:53 --> Helper loaded: url_helper
INFO - 2021-07-08 12:07:53 --> Helper loaded: form_helper
INFO - 2021-07-08 12:07:53 --> Database Driver Class Initialized
INFO - 2021-07-08 12:07:53 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:07:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:07:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:07:53 --> Encryption Class Initialized
INFO - 2021-07-08 12:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:07:53 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:07:53 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:07:53 --> Model "user_model" initialized
INFO - 2021-07-08 12:07:53 --> Model "role_model" initialized
INFO - 2021-07-08 12:07:53 --> Controller Class Initialized
INFO - 2021-07-08 12:07:53 --> Helper loaded: language_helper
INFO - 2021-07-08 12:07:53 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:07:53 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:07:53 --> Model "Product_model" initialized
INFO - 2021-07-08 12:07:53 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:07:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:07:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:07:53 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 12:07:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 12:07:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:07:53 --> Final output sent to browser
DEBUG - 2021-07-08 12:07:53 --> Total execution time: 0.0761
INFO - 2021-07-08 12:07:58 --> Config Class Initialized
INFO - 2021-07-08 12:07:58 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:07:58 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:07:58 --> Utf8 Class Initialized
INFO - 2021-07-08 12:07:58 --> URI Class Initialized
INFO - 2021-07-08 12:07:58 --> Router Class Initialized
INFO - 2021-07-08 12:07:58 --> Output Class Initialized
INFO - 2021-07-08 12:07:58 --> Security Class Initialized
DEBUG - 2021-07-08 12:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:07:58 --> Input Class Initialized
INFO - 2021-07-08 12:07:58 --> Language Class Initialized
INFO - 2021-07-08 12:07:58 --> Loader Class Initialized
INFO - 2021-07-08 12:07:58 --> Helper loaded: html_helper
INFO - 2021-07-08 12:07:58 --> Helper loaded: url_helper
INFO - 2021-07-08 12:07:58 --> Helper loaded: form_helper
INFO - 2021-07-08 12:07:58 --> Database Driver Class Initialized
INFO - 2021-07-08 12:07:58 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:07:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:07:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:07:58 --> Encryption Class Initialized
INFO - 2021-07-08 12:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:07:58 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:07:58 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:07:58 --> Model "user_model" initialized
INFO - 2021-07-08 12:07:58 --> Model "role_model" initialized
INFO - 2021-07-08 12:07:58 --> Controller Class Initialized
INFO - 2021-07-08 12:07:58 --> Helper loaded: language_helper
INFO - 2021-07-08 12:07:58 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:07:58 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:07:58 --> Final output sent to browser
DEBUG - 2021-07-08 12:07:58 --> Total execution time: 0.0655
INFO - 2021-07-08 12:07:58 --> Config Class Initialized
INFO - 2021-07-08 12:07:58 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:07:58 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:07:58 --> Utf8 Class Initialized
INFO - 2021-07-08 12:07:58 --> URI Class Initialized
INFO - 2021-07-08 12:07:58 --> Router Class Initialized
INFO - 2021-07-08 12:07:58 --> Output Class Initialized
INFO - 2021-07-08 12:07:58 --> Security Class Initialized
DEBUG - 2021-07-08 12:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:07:58 --> Input Class Initialized
INFO - 2021-07-08 12:07:58 --> Language Class Initialized
INFO - 2021-07-08 12:07:58 --> Loader Class Initialized
INFO - 2021-07-08 12:07:58 --> Helper loaded: html_helper
INFO - 2021-07-08 12:07:58 --> Helper loaded: url_helper
INFO - 2021-07-08 12:07:58 --> Helper loaded: form_helper
INFO - 2021-07-08 12:07:58 --> Database Driver Class Initialized
INFO - 2021-07-08 12:07:58 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:07:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:07:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:07:58 --> Encryption Class Initialized
INFO - 2021-07-08 12:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:07:58 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:07:58 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:07:58 --> Model "user_model" initialized
INFO - 2021-07-08 12:07:58 --> Model "role_model" initialized
INFO - 2021-07-08 12:07:58 --> Controller Class Initialized
INFO - 2021-07-08 12:07:58 --> Helper loaded: language_helper
INFO - 2021-07-08 12:07:58 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:07:58 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:07:58 --> Final output sent to browser
DEBUG - 2021-07-08 12:07:58 --> Total execution time: 0.0611
INFO - 2021-07-08 12:08:02 --> Config Class Initialized
INFO - 2021-07-08 12:08:02 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:08:02 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:08:02 --> Utf8 Class Initialized
INFO - 2021-07-08 12:08:02 --> URI Class Initialized
INFO - 2021-07-08 12:08:02 --> Router Class Initialized
INFO - 2021-07-08 12:08:02 --> Output Class Initialized
INFO - 2021-07-08 12:08:02 --> Security Class Initialized
DEBUG - 2021-07-08 12:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:08:02 --> Input Class Initialized
INFO - 2021-07-08 12:08:02 --> Language Class Initialized
INFO - 2021-07-08 12:08:02 --> Loader Class Initialized
INFO - 2021-07-08 12:08:02 --> Helper loaded: html_helper
INFO - 2021-07-08 12:08:02 --> Helper loaded: url_helper
INFO - 2021-07-08 12:08:02 --> Helper loaded: form_helper
INFO - 2021-07-08 12:08:02 --> Database Driver Class Initialized
INFO - 2021-07-08 12:08:02 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:08:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:08:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:08:02 --> Encryption Class Initialized
INFO - 2021-07-08 12:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:08:02 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:08:02 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:08:02 --> Model "user_model" initialized
INFO - 2021-07-08 12:08:02 --> Model "role_model" initialized
INFO - 2021-07-08 12:08:02 --> Controller Class Initialized
INFO - 2021-07-08 12:08:02 --> Helper loaded: language_helper
INFO - 2021-07-08 12:08:02 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:08:02 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:08:02 --> Final output sent to browser
DEBUG - 2021-07-08 12:08:02 --> Total execution time: 0.0651
INFO - 2021-07-08 12:08:03 --> Config Class Initialized
INFO - 2021-07-08 12:08:03 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:08:03 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:08:03 --> Utf8 Class Initialized
INFO - 2021-07-08 12:08:03 --> URI Class Initialized
INFO - 2021-07-08 12:08:03 --> Router Class Initialized
INFO - 2021-07-08 12:08:03 --> Output Class Initialized
INFO - 2021-07-08 12:08:03 --> Security Class Initialized
DEBUG - 2021-07-08 12:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:08:03 --> Input Class Initialized
INFO - 2021-07-08 12:08:03 --> Language Class Initialized
INFO - 2021-07-08 12:08:03 --> Loader Class Initialized
INFO - 2021-07-08 12:08:03 --> Helper loaded: html_helper
INFO - 2021-07-08 12:08:03 --> Helper loaded: url_helper
INFO - 2021-07-08 12:08:03 --> Helper loaded: form_helper
INFO - 2021-07-08 12:08:03 --> Database Driver Class Initialized
INFO - 2021-07-08 12:08:03 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:08:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:08:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:08:03 --> Encryption Class Initialized
INFO - 2021-07-08 12:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:08:03 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:08:03 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:08:03 --> Model "user_model" initialized
INFO - 2021-07-08 12:08:03 --> Model "role_model" initialized
INFO - 2021-07-08 12:08:03 --> Controller Class Initialized
INFO - 2021-07-08 12:08:03 --> Helper loaded: language_helper
INFO - 2021-07-08 12:08:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:08:03 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:08:03 --> Final output sent to browser
DEBUG - 2021-07-08 12:08:03 --> Total execution time: 0.0635
INFO - 2021-07-08 12:08:07 --> Config Class Initialized
INFO - 2021-07-08 12:08:07 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:08:07 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:08:07 --> Utf8 Class Initialized
INFO - 2021-07-08 12:08:07 --> URI Class Initialized
INFO - 2021-07-08 12:08:07 --> Router Class Initialized
INFO - 2021-07-08 12:08:07 --> Output Class Initialized
INFO - 2021-07-08 12:08:07 --> Security Class Initialized
DEBUG - 2021-07-08 12:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:08:07 --> Input Class Initialized
INFO - 2021-07-08 12:08:07 --> Language Class Initialized
INFO - 2021-07-08 12:08:07 --> Loader Class Initialized
INFO - 2021-07-08 12:08:07 --> Helper loaded: html_helper
INFO - 2021-07-08 12:08:07 --> Helper loaded: url_helper
INFO - 2021-07-08 12:08:07 --> Helper loaded: form_helper
INFO - 2021-07-08 12:08:07 --> Database Driver Class Initialized
INFO - 2021-07-08 12:08:07 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:08:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:08:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:08:07 --> Encryption Class Initialized
INFO - 2021-07-08 12:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:08:07 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:08:07 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:08:07 --> Model "user_model" initialized
INFO - 2021-07-08 12:08:07 --> Model "role_model" initialized
INFO - 2021-07-08 12:08:07 --> Controller Class Initialized
INFO - 2021-07-08 12:08:07 --> Helper loaded: language_helper
INFO - 2021-07-08 12:08:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:08:07 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:08:07 --> Final output sent to browser
DEBUG - 2021-07-08 12:08:07 --> Total execution time: 0.0668
INFO - 2021-07-08 12:08:08 --> Config Class Initialized
INFO - 2021-07-08 12:08:08 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:08:08 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:08:08 --> Utf8 Class Initialized
INFO - 2021-07-08 12:08:08 --> URI Class Initialized
INFO - 2021-07-08 12:08:08 --> Router Class Initialized
INFO - 2021-07-08 12:08:08 --> Output Class Initialized
INFO - 2021-07-08 12:08:08 --> Security Class Initialized
DEBUG - 2021-07-08 12:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:08:08 --> Input Class Initialized
INFO - 2021-07-08 12:08:08 --> Language Class Initialized
INFO - 2021-07-08 12:08:08 --> Loader Class Initialized
INFO - 2021-07-08 12:08:08 --> Helper loaded: html_helper
INFO - 2021-07-08 12:08:08 --> Helper loaded: url_helper
INFO - 2021-07-08 12:08:08 --> Helper loaded: form_helper
INFO - 2021-07-08 12:08:08 --> Database Driver Class Initialized
INFO - 2021-07-08 12:08:08 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:08:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:08:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:08:08 --> Encryption Class Initialized
INFO - 2021-07-08 12:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:08:08 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:08:08 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:08:08 --> Model "user_model" initialized
INFO - 2021-07-08 12:08:08 --> Model "role_model" initialized
INFO - 2021-07-08 12:08:08 --> Controller Class Initialized
INFO - 2021-07-08 12:08:08 --> Helper loaded: language_helper
INFO - 2021-07-08 12:08:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:08:08 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:08:08 --> Final output sent to browser
DEBUG - 2021-07-08 12:08:08 --> Total execution time: 0.0585
INFO - 2021-07-08 12:08:13 --> Config Class Initialized
INFO - 2021-07-08 12:08:13 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:08:13 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:08:13 --> Utf8 Class Initialized
INFO - 2021-07-08 12:08:13 --> URI Class Initialized
INFO - 2021-07-08 12:08:13 --> Router Class Initialized
INFO - 2021-07-08 12:08:13 --> Output Class Initialized
INFO - 2021-07-08 12:08:13 --> Security Class Initialized
DEBUG - 2021-07-08 12:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:08:13 --> Input Class Initialized
INFO - 2021-07-08 12:08:13 --> Language Class Initialized
INFO - 2021-07-08 12:08:13 --> Loader Class Initialized
INFO - 2021-07-08 12:08:13 --> Helper loaded: html_helper
INFO - 2021-07-08 12:08:13 --> Helper loaded: url_helper
INFO - 2021-07-08 12:08:13 --> Helper loaded: form_helper
INFO - 2021-07-08 12:08:13 --> Database Driver Class Initialized
INFO - 2021-07-08 12:08:13 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:08:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:08:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:08:13 --> Encryption Class Initialized
INFO - 2021-07-08 12:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:08:13 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:08:13 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:08:13 --> Model "user_model" initialized
INFO - 2021-07-08 12:08:13 --> Model "role_model" initialized
INFO - 2021-07-08 12:08:13 --> Controller Class Initialized
INFO - 2021-07-08 12:08:13 --> Helper loaded: language_helper
INFO - 2021-07-08 12:08:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:08:13 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:08:13 --> Final output sent to browser
DEBUG - 2021-07-08 12:08:13 --> Total execution time: 0.0668
INFO - 2021-07-08 12:08:13 --> Config Class Initialized
INFO - 2021-07-08 12:08:13 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:08:13 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:08:13 --> Utf8 Class Initialized
INFO - 2021-07-08 12:08:13 --> URI Class Initialized
INFO - 2021-07-08 12:08:13 --> Router Class Initialized
INFO - 2021-07-08 12:08:13 --> Output Class Initialized
INFO - 2021-07-08 12:08:13 --> Security Class Initialized
DEBUG - 2021-07-08 12:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:08:13 --> Input Class Initialized
INFO - 2021-07-08 12:08:13 --> Language Class Initialized
INFO - 2021-07-08 12:08:13 --> Loader Class Initialized
INFO - 2021-07-08 12:08:13 --> Helper loaded: html_helper
INFO - 2021-07-08 12:08:13 --> Helper loaded: url_helper
INFO - 2021-07-08 12:08:13 --> Helper loaded: form_helper
INFO - 2021-07-08 12:08:13 --> Database Driver Class Initialized
INFO - 2021-07-08 12:08:13 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:08:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:08:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:08:13 --> Encryption Class Initialized
INFO - 2021-07-08 12:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:08:13 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:08:13 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:08:13 --> Model "user_model" initialized
INFO - 2021-07-08 12:08:13 --> Model "role_model" initialized
INFO - 2021-07-08 12:08:13 --> Controller Class Initialized
INFO - 2021-07-08 12:08:13 --> Helper loaded: language_helper
INFO - 2021-07-08 12:08:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:08:13 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:08:13 --> Final output sent to browser
DEBUG - 2021-07-08 12:08:13 --> Total execution time: 0.0645
INFO - 2021-07-08 12:09:39 --> Config Class Initialized
INFO - 2021-07-08 12:09:39 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:09:39 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:09:39 --> Utf8 Class Initialized
INFO - 2021-07-08 12:09:39 --> URI Class Initialized
INFO - 2021-07-08 12:09:39 --> Router Class Initialized
INFO - 2021-07-08 12:09:39 --> Output Class Initialized
INFO - 2021-07-08 12:09:39 --> Security Class Initialized
DEBUG - 2021-07-08 12:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:09:39 --> Input Class Initialized
INFO - 2021-07-08 12:09:39 --> Language Class Initialized
INFO - 2021-07-08 12:09:39 --> Loader Class Initialized
INFO - 2021-07-08 12:09:39 --> Helper loaded: html_helper
INFO - 2021-07-08 12:09:39 --> Helper loaded: url_helper
INFO - 2021-07-08 12:09:39 --> Helper loaded: form_helper
INFO - 2021-07-08 12:09:39 --> Database Driver Class Initialized
INFO - 2021-07-08 12:09:39 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:09:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:09:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:09:39 --> Encryption Class Initialized
INFO - 2021-07-08 12:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:09:39 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:09:39 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:09:39 --> Model "user_model" initialized
INFO - 2021-07-08 12:09:39 --> Model "role_model" initialized
INFO - 2021-07-08 12:09:39 --> Controller Class Initialized
INFO - 2021-07-08 12:09:39 --> Helper loaded: language_helper
INFO - 2021-07-08 12:09:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:09:39 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:09:39 --> Model "Product_model" initialized
INFO - 2021-07-08 12:09:39 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:09:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:09:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:09:39 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 12:09:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 12:09:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:09:39 --> Final output sent to browser
DEBUG - 2021-07-08 12:09:39 --> Total execution time: 0.0752
INFO - 2021-07-08 12:09:54 --> Config Class Initialized
INFO - 2021-07-08 12:09:54 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:09:54 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:09:54 --> Utf8 Class Initialized
INFO - 2021-07-08 12:09:54 --> URI Class Initialized
INFO - 2021-07-08 12:09:54 --> Router Class Initialized
INFO - 2021-07-08 12:09:54 --> Output Class Initialized
INFO - 2021-07-08 12:09:54 --> Security Class Initialized
DEBUG - 2021-07-08 12:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:09:54 --> Input Class Initialized
INFO - 2021-07-08 12:09:54 --> Language Class Initialized
INFO - 2021-07-08 12:09:54 --> Loader Class Initialized
INFO - 2021-07-08 12:09:54 --> Helper loaded: html_helper
INFO - 2021-07-08 12:09:54 --> Helper loaded: url_helper
INFO - 2021-07-08 12:09:54 --> Helper loaded: form_helper
INFO - 2021-07-08 12:09:54 --> Database Driver Class Initialized
INFO - 2021-07-08 12:09:54 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:09:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:09:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:09:54 --> Encryption Class Initialized
INFO - 2021-07-08 12:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:09:54 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:09:54 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:09:54 --> Model "user_model" initialized
INFO - 2021-07-08 12:09:54 --> Model "role_model" initialized
INFO - 2021-07-08 12:09:54 --> Controller Class Initialized
INFO - 2021-07-08 12:09:54 --> Helper loaded: language_helper
INFO - 2021-07-08 12:09:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:09:54 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:09:54 --> Final output sent to browser
DEBUG - 2021-07-08 12:09:54 --> Total execution time: 0.0538
INFO - 2021-07-08 12:09:54 --> Config Class Initialized
INFO - 2021-07-08 12:09:54 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:09:54 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:09:54 --> Utf8 Class Initialized
INFO - 2021-07-08 12:09:54 --> URI Class Initialized
INFO - 2021-07-08 12:09:54 --> Router Class Initialized
INFO - 2021-07-08 12:09:54 --> Output Class Initialized
INFO - 2021-07-08 12:09:54 --> Security Class Initialized
DEBUG - 2021-07-08 12:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:09:54 --> Input Class Initialized
INFO - 2021-07-08 12:09:54 --> Language Class Initialized
INFO - 2021-07-08 12:09:54 --> Loader Class Initialized
INFO - 2021-07-08 12:09:54 --> Helper loaded: html_helper
INFO - 2021-07-08 12:09:54 --> Helper loaded: url_helper
INFO - 2021-07-08 12:09:54 --> Helper loaded: form_helper
INFO - 2021-07-08 12:09:54 --> Database Driver Class Initialized
INFO - 2021-07-08 12:09:54 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:09:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:09:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:09:54 --> Encryption Class Initialized
INFO - 2021-07-08 12:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:09:54 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:09:54 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:09:54 --> Model "user_model" initialized
INFO - 2021-07-08 12:09:54 --> Model "role_model" initialized
INFO - 2021-07-08 12:09:54 --> Controller Class Initialized
INFO - 2021-07-08 12:09:54 --> Helper loaded: language_helper
INFO - 2021-07-08 12:09:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:09:54 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:09:54 --> Final output sent to browser
DEBUG - 2021-07-08 12:09:54 --> Total execution time: 0.0543
INFO - 2021-07-08 12:10:39 --> Config Class Initialized
INFO - 2021-07-08 12:10:39 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:10:39 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:10:39 --> Utf8 Class Initialized
INFO - 2021-07-08 12:10:39 --> URI Class Initialized
INFO - 2021-07-08 12:10:39 --> Router Class Initialized
INFO - 2021-07-08 12:10:39 --> Output Class Initialized
INFO - 2021-07-08 12:10:39 --> Security Class Initialized
DEBUG - 2021-07-08 12:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:10:39 --> Input Class Initialized
INFO - 2021-07-08 12:10:39 --> Language Class Initialized
INFO - 2021-07-08 12:10:39 --> Loader Class Initialized
INFO - 2021-07-08 12:10:39 --> Helper loaded: html_helper
INFO - 2021-07-08 12:10:39 --> Helper loaded: url_helper
INFO - 2021-07-08 12:10:39 --> Helper loaded: form_helper
INFO - 2021-07-08 12:10:39 --> Database Driver Class Initialized
INFO - 2021-07-08 12:10:39 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:10:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:10:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:10:39 --> Encryption Class Initialized
INFO - 2021-07-08 12:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:10:39 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:10:39 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:10:39 --> Model "user_model" initialized
INFO - 2021-07-08 12:10:39 --> Model "role_model" initialized
INFO - 2021-07-08 12:10:39 --> Controller Class Initialized
INFO - 2021-07-08 12:10:39 --> Helper loaded: language_helper
INFO - 2021-07-08 12:10:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:10:39 --> Model "Product_model" initialized
INFO - 2021-07-08 12:10:39 --> Final output sent to browser
DEBUG - 2021-07-08 12:10:39 --> Total execution time: 0.1214
INFO - 2021-07-08 12:15:30 --> Config Class Initialized
INFO - 2021-07-08 12:15:30 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:15:30 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:15:30 --> Utf8 Class Initialized
INFO - 2021-07-08 12:15:30 --> URI Class Initialized
INFO - 2021-07-08 12:15:30 --> Router Class Initialized
INFO - 2021-07-08 12:15:30 --> Output Class Initialized
INFO - 2021-07-08 12:15:30 --> Security Class Initialized
DEBUG - 2021-07-08 12:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:15:30 --> Input Class Initialized
INFO - 2021-07-08 12:15:30 --> Language Class Initialized
INFO - 2021-07-08 12:15:30 --> Loader Class Initialized
INFO - 2021-07-08 12:15:30 --> Helper loaded: html_helper
INFO - 2021-07-08 12:15:30 --> Helper loaded: url_helper
INFO - 2021-07-08 12:15:30 --> Helper loaded: form_helper
INFO - 2021-07-08 12:15:30 --> Database Driver Class Initialized
INFO - 2021-07-08 12:15:30 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:15:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:15:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:15:30 --> Encryption Class Initialized
INFO - 2021-07-08 12:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:15:30 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:15:30 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:15:30 --> Model "user_model" initialized
INFO - 2021-07-08 12:15:30 --> Model "role_model" initialized
INFO - 2021-07-08 12:15:30 --> Controller Class Initialized
INFO - 2021-07-08 12:15:30 --> Helper loaded: language_helper
INFO - 2021-07-08 12:15:30 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:15:30 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:15:30 --> Model "Product_model" initialized
INFO - 2021-07-08 12:15:30 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:15:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:15:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:15:30 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 12:15:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 12:15:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:15:30 --> Final output sent to browser
DEBUG - 2021-07-08 12:15:30 --> Total execution time: 0.1093
INFO - 2021-07-08 12:15:34 --> Config Class Initialized
INFO - 2021-07-08 12:15:34 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:15:34 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:15:34 --> Utf8 Class Initialized
INFO - 2021-07-08 12:15:34 --> URI Class Initialized
INFO - 2021-07-08 12:15:34 --> Router Class Initialized
INFO - 2021-07-08 12:15:34 --> Output Class Initialized
INFO - 2021-07-08 12:15:34 --> Security Class Initialized
DEBUG - 2021-07-08 12:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:15:34 --> Input Class Initialized
INFO - 2021-07-08 12:15:34 --> Language Class Initialized
INFO - 2021-07-08 12:15:34 --> Loader Class Initialized
INFO - 2021-07-08 12:15:34 --> Helper loaded: html_helper
INFO - 2021-07-08 12:15:34 --> Helper loaded: url_helper
INFO - 2021-07-08 12:15:34 --> Helper loaded: form_helper
INFO - 2021-07-08 12:15:34 --> Database Driver Class Initialized
INFO - 2021-07-08 12:15:34 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:15:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:15:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:15:34 --> Encryption Class Initialized
INFO - 2021-07-08 12:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:15:34 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:15:34 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:15:34 --> Model "user_model" initialized
INFO - 2021-07-08 12:15:34 --> Model "role_model" initialized
INFO - 2021-07-08 12:15:34 --> Controller Class Initialized
INFO - 2021-07-08 12:15:34 --> Helper loaded: language_helper
INFO - 2021-07-08 12:15:34 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:15:34 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:15:34 --> Final output sent to browser
DEBUG - 2021-07-08 12:15:34 --> Total execution time: 0.0609
INFO - 2021-07-08 12:15:34 --> Config Class Initialized
INFO - 2021-07-08 12:15:34 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:15:34 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:15:34 --> Utf8 Class Initialized
INFO - 2021-07-08 12:15:34 --> URI Class Initialized
INFO - 2021-07-08 12:15:34 --> Router Class Initialized
INFO - 2021-07-08 12:15:34 --> Output Class Initialized
INFO - 2021-07-08 12:15:34 --> Security Class Initialized
DEBUG - 2021-07-08 12:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:15:34 --> Input Class Initialized
INFO - 2021-07-08 12:15:34 --> Language Class Initialized
INFO - 2021-07-08 12:15:34 --> Loader Class Initialized
INFO - 2021-07-08 12:15:34 --> Helper loaded: html_helper
INFO - 2021-07-08 12:15:34 --> Helper loaded: url_helper
INFO - 2021-07-08 12:15:34 --> Helper loaded: form_helper
INFO - 2021-07-08 12:15:34 --> Database Driver Class Initialized
INFO - 2021-07-08 12:15:34 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:15:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:15:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:15:34 --> Encryption Class Initialized
INFO - 2021-07-08 12:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:15:34 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:15:34 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:15:34 --> Model "user_model" initialized
INFO - 2021-07-08 12:15:34 --> Model "role_model" initialized
INFO - 2021-07-08 12:15:34 --> Controller Class Initialized
INFO - 2021-07-08 12:15:34 --> Helper loaded: language_helper
INFO - 2021-07-08 12:15:34 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:15:34 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:15:34 --> Final output sent to browser
DEBUG - 2021-07-08 12:15:34 --> Total execution time: 0.0577
INFO - 2021-07-08 12:16:47 --> Config Class Initialized
INFO - 2021-07-08 12:16:47 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:16:47 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:16:47 --> Utf8 Class Initialized
INFO - 2021-07-08 12:16:47 --> URI Class Initialized
INFO - 2021-07-08 12:16:47 --> Router Class Initialized
INFO - 2021-07-08 12:16:47 --> Output Class Initialized
INFO - 2021-07-08 12:16:47 --> Security Class Initialized
DEBUG - 2021-07-08 12:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:16:47 --> Input Class Initialized
INFO - 2021-07-08 12:16:47 --> Language Class Initialized
INFO - 2021-07-08 12:16:47 --> Loader Class Initialized
INFO - 2021-07-08 12:16:47 --> Helper loaded: html_helper
INFO - 2021-07-08 12:16:47 --> Helper loaded: url_helper
INFO - 2021-07-08 12:16:47 --> Helper loaded: form_helper
INFO - 2021-07-08 12:16:47 --> Database Driver Class Initialized
INFO - 2021-07-08 12:16:47 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:16:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:16:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:16:47 --> Encryption Class Initialized
INFO - 2021-07-08 12:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:16:47 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:16:47 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:16:47 --> Model "user_model" initialized
INFO - 2021-07-08 12:16:47 --> Model "role_model" initialized
INFO - 2021-07-08 12:16:47 --> Controller Class Initialized
INFO - 2021-07-08 12:16:47 --> Helper loaded: language_helper
INFO - 2021-07-08 12:16:47 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:16:47 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:16:47 --> Model "Product_model" initialized
INFO - 2021-07-08 12:16:47 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:16:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:16:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:16:47 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 12:16:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 12:16:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:16:47 --> Final output sent to browser
DEBUG - 2021-07-08 12:16:47 --> Total execution time: 0.1086
INFO - 2021-07-08 12:17:01 --> Config Class Initialized
INFO - 2021-07-08 12:17:01 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:17:01 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:17:01 --> Utf8 Class Initialized
INFO - 2021-07-08 12:17:01 --> URI Class Initialized
INFO - 2021-07-08 12:17:01 --> Router Class Initialized
INFO - 2021-07-08 12:17:01 --> Output Class Initialized
INFO - 2021-07-08 12:17:01 --> Security Class Initialized
DEBUG - 2021-07-08 12:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:17:01 --> Input Class Initialized
INFO - 2021-07-08 12:17:01 --> Language Class Initialized
INFO - 2021-07-08 12:17:01 --> Loader Class Initialized
INFO - 2021-07-08 12:17:01 --> Helper loaded: html_helper
INFO - 2021-07-08 12:17:01 --> Helper loaded: url_helper
INFO - 2021-07-08 12:17:01 --> Helper loaded: form_helper
INFO - 2021-07-08 12:17:01 --> Database Driver Class Initialized
INFO - 2021-07-08 12:17:01 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:17:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:17:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:17:01 --> Encryption Class Initialized
INFO - 2021-07-08 12:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:17:01 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:17:01 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:17:01 --> Model "user_model" initialized
INFO - 2021-07-08 12:17:01 --> Model "role_model" initialized
INFO - 2021-07-08 12:17:01 --> Controller Class Initialized
INFO - 2021-07-08 12:17:01 --> Helper loaded: language_helper
INFO - 2021-07-08 12:17:01 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:17:01 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:17:01 --> Final output sent to browser
DEBUG - 2021-07-08 12:17:01 --> Total execution time: 0.0607
INFO - 2021-07-08 12:17:01 --> Config Class Initialized
INFO - 2021-07-08 12:17:01 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:17:01 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:17:01 --> Utf8 Class Initialized
INFO - 2021-07-08 12:17:01 --> URI Class Initialized
INFO - 2021-07-08 12:17:01 --> Router Class Initialized
INFO - 2021-07-08 12:17:01 --> Output Class Initialized
INFO - 2021-07-08 12:17:01 --> Security Class Initialized
DEBUG - 2021-07-08 12:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:17:01 --> Input Class Initialized
INFO - 2021-07-08 12:17:01 --> Language Class Initialized
INFO - 2021-07-08 12:17:01 --> Loader Class Initialized
INFO - 2021-07-08 12:17:01 --> Helper loaded: html_helper
INFO - 2021-07-08 12:17:01 --> Helper loaded: url_helper
INFO - 2021-07-08 12:17:01 --> Helper loaded: form_helper
INFO - 2021-07-08 12:17:01 --> Database Driver Class Initialized
INFO - 2021-07-08 12:17:01 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:17:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:17:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:17:01 --> Encryption Class Initialized
INFO - 2021-07-08 12:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:17:01 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:17:01 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:17:01 --> Model "user_model" initialized
INFO - 2021-07-08 12:17:01 --> Model "role_model" initialized
INFO - 2021-07-08 12:17:01 --> Controller Class Initialized
INFO - 2021-07-08 12:17:01 --> Helper loaded: language_helper
INFO - 2021-07-08 12:17:01 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:17:01 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:17:01 --> Final output sent to browser
DEBUG - 2021-07-08 12:17:01 --> Total execution time: 0.0590
INFO - 2021-07-08 12:17:39 --> Config Class Initialized
INFO - 2021-07-08 12:17:39 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:17:39 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:17:39 --> Utf8 Class Initialized
INFO - 2021-07-08 12:17:39 --> URI Class Initialized
INFO - 2021-07-08 12:17:39 --> Router Class Initialized
INFO - 2021-07-08 12:17:39 --> Output Class Initialized
INFO - 2021-07-08 12:17:39 --> Security Class Initialized
DEBUG - 2021-07-08 12:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:17:39 --> Input Class Initialized
INFO - 2021-07-08 12:17:39 --> Language Class Initialized
INFO - 2021-07-08 12:17:39 --> Loader Class Initialized
INFO - 2021-07-08 12:17:39 --> Helper loaded: html_helper
INFO - 2021-07-08 12:17:39 --> Helper loaded: url_helper
INFO - 2021-07-08 12:17:39 --> Helper loaded: form_helper
INFO - 2021-07-08 12:17:39 --> Database Driver Class Initialized
INFO - 2021-07-08 12:17:39 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:17:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:17:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:17:39 --> Encryption Class Initialized
INFO - 2021-07-08 12:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:17:39 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:17:39 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:17:39 --> Model "user_model" initialized
INFO - 2021-07-08 12:17:39 --> Model "role_model" initialized
INFO - 2021-07-08 12:17:39 --> Controller Class Initialized
INFO - 2021-07-08 12:17:39 --> Helper loaded: language_helper
INFO - 2021-07-08 12:17:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:17:39 --> Model "Product_model" initialized
INFO - 2021-07-08 12:17:39 --> Final output sent to browser
DEBUG - 2021-07-08 12:17:39 --> Total execution time: 0.0651
INFO - 2021-07-08 12:17:50 --> Config Class Initialized
INFO - 2021-07-08 12:17:50 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:17:50 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:17:50 --> Utf8 Class Initialized
INFO - 2021-07-08 12:17:50 --> URI Class Initialized
INFO - 2021-07-08 12:17:50 --> Router Class Initialized
INFO - 2021-07-08 12:17:50 --> Output Class Initialized
INFO - 2021-07-08 12:17:50 --> Security Class Initialized
DEBUG - 2021-07-08 12:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:17:50 --> Input Class Initialized
INFO - 2021-07-08 12:17:50 --> Language Class Initialized
INFO - 2021-07-08 12:17:50 --> Loader Class Initialized
INFO - 2021-07-08 12:17:50 --> Helper loaded: html_helper
INFO - 2021-07-08 12:17:50 --> Helper loaded: url_helper
INFO - 2021-07-08 12:17:50 --> Helper loaded: form_helper
INFO - 2021-07-08 12:17:50 --> Database Driver Class Initialized
INFO - 2021-07-08 12:17:50 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:17:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:17:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:17:50 --> Encryption Class Initialized
INFO - 2021-07-08 12:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:17:50 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:17:50 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:17:50 --> Model "user_model" initialized
INFO - 2021-07-08 12:17:50 --> Model "role_model" initialized
INFO - 2021-07-08 12:17:50 --> Controller Class Initialized
INFO - 2021-07-08 12:17:50 --> Helper loaded: language_helper
INFO - 2021-07-08 12:17:50 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:17:50 --> Model "Quotation_model" initialized
INFO - 2021-07-08 12:17:50 --> Final output sent to browser
DEBUG - 2021-07-08 12:17:50 --> Total execution time: 0.1053
INFO - 2021-07-08 12:17:51 --> Config Class Initialized
INFO - 2021-07-08 12:17:51 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:17:51 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:17:51 --> Utf8 Class Initialized
INFO - 2021-07-08 12:17:51 --> URI Class Initialized
INFO - 2021-07-08 12:17:51 --> Router Class Initialized
INFO - 2021-07-08 12:17:51 --> Output Class Initialized
INFO - 2021-07-08 12:17:51 --> Security Class Initialized
DEBUG - 2021-07-08 12:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:17:51 --> Input Class Initialized
INFO - 2021-07-08 12:17:51 --> Language Class Initialized
INFO - 2021-07-08 12:17:51 --> Loader Class Initialized
INFO - 2021-07-08 12:17:51 --> Helper loaded: html_helper
INFO - 2021-07-08 12:17:51 --> Helper loaded: url_helper
INFO - 2021-07-08 12:17:51 --> Helper loaded: form_helper
INFO - 2021-07-08 12:17:51 --> Database Driver Class Initialized
INFO - 2021-07-08 12:17:51 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:17:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:17:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:17:51 --> Encryption Class Initialized
INFO - 2021-07-08 12:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:17:51 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:17:51 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:17:51 --> Model "user_model" initialized
INFO - 2021-07-08 12:17:51 --> Model "role_model" initialized
INFO - 2021-07-08 12:17:51 --> Controller Class Initialized
INFO - 2021-07-08 12:17:51 --> Helper loaded: language_helper
INFO - 2021-07-08 12:17:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:17:51 --> Model "Quotation_model" initialized
INFO - 2021-07-08 12:17:51 --> Final output sent to browser
DEBUG - 2021-07-08 12:17:51 --> Total execution time: 0.0692
INFO - 2021-07-08 12:17:52 --> Config Class Initialized
INFO - 2021-07-08 12:17:52 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:17:52 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:17:52 --> Utf8 Class Initialized
INFO - 2021-07-08 12:17:52 --> URI Class Initialized
INFO - 2021-07-08 12:17:52 --> Router Class Initialized
INFO - 2021-07-08 12:17:52 --> Output Class Initialized
INFO - 2021-07-08 12:17:52 --> Security Class Initialized
DEBUG - 2021-07-08 12:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:17:52 --> Input Class Initialized
INFO - 2021-07-08 12:17:52 --> Language Class Initialized
INFO - 2021-07-08 12:17:52 --> Loader Class Initialized
INFO - 2021-07-08 12:17:52 --> Helper loaded: html_helper
INFO - 2021-07-08 12:17:52 --> Helper loaded: url_helper
INFO - 2021-07-08 12:17:52 --> Helper loaded: form_helper
INFO - 2021-07-08 12:17:52 --> Database Driver Class Initialized
INFO - 2021-07-08 12:17:52 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:17:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:17:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:17:52 --> Encryption Class Initialized
INFO - 2021-07-08 12:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:17:52 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:17:52 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:17:52 --> Model "user_model" initialized
INFO - 2021-07-08 12:17:52 --> Model "role_model" initialized
INFO - 2021-07-08 12:17:52 --> Controller Class Initialized
INFO - 2021-07-08 12:17:52 --> Helper loaded: language_helper
INFO - 2021-07-08 12:17:52 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:17:52 --> Model "Quotation_model" initialized
INFO - 2021-07-08 12:17:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:17:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:17:52 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-08 12:17:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-08 12:17:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:17:52 --> Final output sent to browser
DEBUG - 2021-07-08 12:17:52 --> Total execution time: 0.0761
INFO - 2021-07-08 12:17:53 --> Config Class Initialized
INFO - 2021-07-08 12:17:53 --> Hooks Class Initialized
INFO - 2021-07-08 12:17:53 --> Config Class Initialized
INFO - 2021-07-08 12:17:53 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:17:53 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:17:53 --> Utf8 Class Initialized
DEBUG - 2021-07-08 12:17:53 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:17:53 --> Utf8 Class Initialized
INFO - 2021-07-08 12:17:53 --> URI Class Initialized
INFO - 2021-07-08 12:17:53 --> URI Class Initialized
INFO - 2021-07-08 12:17:53 --> Router Class Initialized
INFO - 2021-07-08 12:17:53 --> Router Class Initialized
INFO - 2021-07-08 12:17:53 --> Output Class Initialized
INFO - 2021-07-08 12:17:53 --> Output Class Initialized
INFO - 2021-07-08 12:17:53 --> Security Class Initialized
INFO - 2021-07-08 12:17:53 --> Security Class Initialized
DEBUG - 2021-07-08 12:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-08 12:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:17:53 --> Input Class Initialized
INFO - 2021-07-08 12:17:53 --> Input Class Initialized
INFO - 2021-07-08 12:17:53 --> Language Class Initialized
INFO - 2021-07-08 12:17:53 --> Language Class Initialized
INFO - 2021-07-08 12:17:53 --> Loader Class Initialized
INFO - 2021-07-08 12:17:53 --> Loader Class Initialized
INFO - 2021-07-08 12:17:53 --> Helper loaded: html_helper
INFO - 2021-07-08 12:17:53 --> Helper loaded: html_helper
INFO - 2021-07-08 12:17:53 --> Helper loaded: url_helper
INFO - 2021-07-08 12:17:53 --> Helper loaded: url_helper
INFO - 2021-07-08 12:17:53 --> Helper loaded: form_helper
INFO - 2021-07-08 12:17:53 --> Helper loaded: form_helper
INFO - 2021-07-08 12:17:53 --> Database Driver Class Initialized
INFO - 2021-07-08 12:17:53 --> Database Driver Class Initialized
INFO - 2021-07-08 12:17:53 --> Form Validation Class Initialized
INFO - 2021-07-08 12:17:53 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-08 12:17:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:17:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:17:53 --> Encryption Class Initialized
INFO - 2021-07-08 12:17:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:17:53 --> Encryption Class Initialized
INFO - 2021-07-08 12:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:17:53 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:17:53 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:17:53 --> Model "user_model" initialized
INFO - 2021-07-08 12:17:53 --> Model "role_model" initialized
INFO - 2021-07-08 12:17:53 --> Controller Class Initialized
INFO - 2021-07-08 12:17:53 --> Helper loaded: language_helper
INFO - 2021-07-08 12:17:53 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:17:53 --> Model "Quotation_model" initialized
INFO - 2021-07-08 12:17:53 --> Final output sent to browser
DEBUG - 2021-07-08 12:17:53 --> Total execution time: 0.0808
INFO - 2021-07-08 12:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:17:53 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:17:53 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:17:53 --> Model "user_model" initialized
INFO - 2021-07-08 12:17:53 --> Model "role_model" initialized
INFO - 2021-07-08 12:17:53 --> Controller Class Initialized
INFO - 2021-07-08 12:17:53 --> Helper loaded: language_helper
INFO - 2021-07-08 12:17:53 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:17:53 --> Model "Quotation_model" initialized
INFO - 2021-07-08 12:17:53 --> Final output sent to browser
DEBUG - 2021-07-08 12:17:53 --> Total execution time: 0.0926
INFO - 2021-07-08 12:22:59 --> Config Class Initialized
INFO - 2021-07-08 12:22:59 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:22:59 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:22:59 --> Utf8 Class Initialized
INFO - 2021-07-08 12:22:59 --> URI Class Initialized
INFO - 2021-07-08 12:22:59 --> Router Class Initialized
INFO - 2021-07-08 12:22:59 --> Output Class Initialized
INFO - 2021-07-08 12:22:59 --> Security Class Initialized
DEBUG - 2021-07-08 12:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:22:59 --> Input Class Initialized
INFO - 2021-07-08 12:22:59 --> Language Class Initialized
INFO - 2021-07-08 12:22:59 --> Loader Class Initialized
INFO - 2021-07-08 12:22:59 --> Helper loaded: html_helper
INFO - 2021-07-08 12:22:59 --> Helper loaded: url_helper
INFO - 2021-07-08 12:22:59 --> Helper loaded: form_helper
INFO - 2021-07-08 12:22:59 --> Database Driver Class Initialized
INFO - 2021-07-08 12:22:59 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:22:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:22:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:22:59 --> Encryption Class Initialized
INFO - 2021-07-08 12:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:22:59 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:22:59 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:22:59 --> Model "user_model" initialized
INFO - 2021-07-08 12:22:59 --> Model "role_model" initialized
INFO - 2021-07-08 12:22:59 --> Controller Class Initialized
INFO - 2021-07-08 12:22:59 --> Helper loaded: language_helper
INFO - 2021-07-08 12:22:59 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:22:59 --> Model "Quotation_model" initialized
INFO - 2021-07-08 12:22:59 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:22:59 --> Model "Product_model" initialized
INFO - 2021-07-08 12:22:59 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:22:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:22:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:22:59 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 12:22:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 12:22:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:22:59 --> Final output sent to browser
DEBUG - 2021-07-08 12:22:59 --> Total execution time: 0.0704
INFO - 2021-07-08 12:23:11 --> Config Class Initialized
INFO - 2021-07-08 12:23:11 --> Hooks Class Initialized
INFO - 2021-07-08 12:23:11 --> Config Class Initialized
INFO - 2021-07-08 12:23:11 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:23:11 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:23:11 --> Utf8 Class Initialized
DEBUG - 2021-07-08 12:23:11 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:23:11 --> Utf8 Class Initialized
INFO - 2021-07-08 12:23:11 --> URI Class Initialized
INFO - 2021-07-08 12:23:11 --> URI Class Initialized
INFO - 2021-07-08 12:23:11 --> Router Class Initialized
INFO - 2021-07-08 12:23:11 --> Router Class Initialized
INFO - 2021-07-08 12:23:11 --> Output Class Initialized
INFO - 2021-07-08 12:23:11 --> Output Class Initialized
INFO - 2021-07-08 12:23:11 --> Security Class Initialized
INFO - 2021-07-08 12:23:11 --> Security Class Initialized
DEBUG - 2021-07-08 12:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:23:11 --> Input Class Initialized
INFO - 2021-07-08 12:23:11 --> Language Class Initialized
DEBUG - 2021-07-08 12:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:23:11 --> Input Class Initialized
INFO - 2021-07-08 12:23:11 --> Language Class Initialized
INFO - 2021-07-08 12:23:11 --> Loader Class Initialized
INFO - 2021-07-08 12:23:11 --> Helper loaded: html_helper
INFO - 2021-07-08 12:23:11 --> Helper loaded: url_helper
INFO - 2021-07-08 12:23:11 --> Loader Class Initialized
INFO - 2021-07-08 12:23:11 --> Helper loaded: html_helper
INFO - 2021-07-08 12:23:11 --> Helper loaded: form_helper
INFO - 2021-07-08 12:23:11 --> Helper loaded: url_helper
INFO - 2021-07-08 12:23:11 --> Helper loaded: form_helper
INFO - 2021-07-08 12:23:11 --> Database Driver Class Initialized
INFO - 2021-07-08 12:23:11 --> Database Driver Class Initialized
INFO - 2021-07-08 12:23:11 --> Form Validation Class Initialized
INFO - 2021-07-08 12:23:11 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-08 12:23:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:23:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:23:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:23:11 --> Encryption Class Initialized
INFO - 2021-07-08 12:23:11 --> Encryption Class Initialized
INFO - 2021-07-08 12:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:23:11 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:23:11 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:23:11 --> Model "user_model" initialized
INFO - 2021-07-08 12:23:11 --> Model "role_model" initialized
INFO - 2021-07-08 12:23:11 --> Controller Class Initialized
INFO - 2021-07-08 12:23:11 --> Helper loaded: language_helper
INFO - 2021-07-08 12:23:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:23:11 --> Model "Quotation_model" initialized
INFO - 2021-07-08 12:23:11 --> Final output sent to browser
DEBUG - 2021-07-08 12:23:11 --> Total execution time: 0.0747
INFO - 2021-07-08 12:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:23:11 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:23:11 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:23:11 --> Model "user_model" initialized
INFO - 2021-07-08 12:23:11 --> Model "role_model" initialized
INFO - 2021-07-08 12:23:11 --> Controller Class Initialized
INFO - 2021-07-08 12:23:11 --> Helper loaded: language_helper
INFO - 2021-07-08 12:23:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:23:11 --> Model "Quotation_model" initialized
INFO - 2021-07-08 12:23:11 --> Final output sent to browser
DEBUG - 2021-07-08 12:23:11 --> Total execution time: 0.0865
INFO - 2021-07-08 12:23:24 --> Config Class Initialized
INFO - 2021-07-08 12:23:24 --> Config Class Initialized
INFO - 2021-07-08 12:23:24 --> Hooks Class Initialized
INFO - 2021-07-08 12:23:24 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:23:24 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:23:24 --> Utf8 Class Initialized
DEBUG - 2021-07-08 12:23:24 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:23:24 --> Utf8 Class Initialized
INFO - 2021-07-08 12:23:24 --> URI Class Initialized
INFO - 2021-07-08 12:23:24 --> URI Class Initialized
INFO - 2021-07-08 12:23:24 --> Router Class Initialized
INFO - 2021-07-08 12:23:24 --> Router Class Initialized
INFO - 2021-07-08 12:23:24 --> Output Class Initialized
INFO - 2021-07-08 12:23:24 --> Output Class Initialized
INFO - 2021-07-08 12:23:24 --> Security Class Initialized
INFO - 2021-07-08 12:23:24 --> Security Class Initialized
DEBUG - 2021-07-08 12:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:23:24 --> Input Class Initialized
DEBUG - 2021-07-08 12:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:23:24 --> Input Class Initialized
INFO - 2021-07-08 12:23:24 --> Language Class Initialized
INFO - 2021-07-08 12:23:24 --> Language Class Initialized
INFO - 2021-07-08 12:23:24 --> Loader Class Initialized
INFO - 2021-07-08 12:23:24 --> Loader Class Initialized
INFO - 2021-07-08 12:23:24 --> Helper loaded: html_helper
INFO - 2021-07-08 12:23:24 --> Helper loaded: html_helper
INFO - 2021-07-08 12:23:24 --> Helper loaded: url_helper
INFO - 2021-07-08 12:23:24 --> Helper loaded: url_helper
INFO - 2021-07-08 12:23:24 --> Helper loaded: form_helper
INFO - 2021-07-08 12:23:24 --> Helper loaded: form_helper
INFO - 2021-07-08 12:23:24 --> Database Driver Class Initialized
INFO - 2021-07-08 12:23:24 --> Database Driver Class Initialized
INFO - 2021-07-08 12:23:24 --> Form Validation Class Initialized
INFO - 2021-07-08 12:23:24 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:23:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:23:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:23:24 --> Encryption Class Initialized
DEBUG - 2021-07-08 12:23:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:23:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:23:24 --> Encryption Class Initialized
INFO - 2021-07-08 12:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:23:24 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:23:24 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:23:24 --> Model "user_model" initialized
INFO - 2021-07-08 12:23:24 --> Model "role_model" initialized
INFO - 2021-07-08 12:23:24 --> Controller Class Initialized
INFO - 2021-07-08 12:23:24 --> Helper loaded: language_helper
INFO - 2021-07-08 12:23:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:23:24 --> Model "Quotation_model" initialized
INFO - 2021-07-08 12:23:24 --> Final output sent to browser
DEBUG - 2021-07-08 12:23:24 --> Total execution time: 0.0690
INFO - 2021-07-08 12:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:23:24 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:23:24 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:23:24 --> Model "user_model" initialized
INFO - 2021-07-08 12:23:24 --> Model "role_model" initialized
INFO - 2021-07-08 12:23:24 --> Controller Class Initialized
INFO - 2021-07-08 12:23:24 --> Helper loaded: language_helper
INFO - 2021-07-08 12:23:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:23:24 --> Model "Quotation_model" initialized
INFO - 2021-07-08 12:23:24 --> Final output sent to browser
DEBUG - 2021-07-08 12:23:24 --> Total execution time: 0.0794
INFO - 2021-07-08 12:23:32 --> Config Class Initialized
INFO - 2021-07-08 12:23:32 --> Config Class Initialized
INFO - 2021-07-08 12:23:32 --> Hooks Class Initialized
INFO - 2021-07-08 12:23:32 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:23:32 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:23:32 --> Utf8 Class Initialized
INFO - 2021-07-08 12:23:32 --> URI Class Initialized
INFO - 2021-07-08 12:23:32 --> Router Class Initialized
INFO - 2021-07-08 12:23:32 --> Output Class Initialized
DEBUG - 2021-07-08 12:23:32 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:23:32 --> Security Class Initialized
INFO - 2021-07-08 12:23:32 --> Utf8 Class Initialized
DEBUG - 2021-07-08 12:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:23:32 --> Input Class Initialized
INFO - 2021-07-08 12:23:32 --> Language Class Initialized
INFO - 2021-07-08 12:23:32 --> URI Class Initialized
INFO - 2021-07-08 12:23:32 --> Router Class Initialized
INFO - 2021-07-08 12:23:32 --> Loader Class Initialized
INFO - 2021-07-08 12:23:32 --> Output Class Initialized
INFO - 2021-07-08 12:23:32 --> Helper loaded: html_helper
INFO - 2021-07-08 12:23:32 --> Security Class Initialized
INFO - 2021-07-08 12:23:32 --> Helper loaded: url_helper
DEBUG - 2021-07-08 12:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:23:32 --> Input Class Initialized
INFO - 2021-07-08 12:23:32 --> Helper loaded: form_helper
INFO - 2021-07-08 12:23:32 --> Language Class Initialized
INFO - 2021-07-08 12:23:32 --> Loader Class Initialized
INFO - 2021-07-08 12:23:32 --> Helper loaded: html_helper
INFO - 2021-07-08 12:23:32 --> Helper loaded: url_helper
INFO - 2021-07-08 12:23:32 --> Database Driver Class Initialized
INFO - 2021-07-08 12:23:32 --> Helper loaded: form_helper
INFO - 2021-07-08 12:23:32 --> Database Driver Class Initialized
INFO - 2021-07-08 12:23:32 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:23:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:23:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:23:32 --> Encryption Class Initialized
INFO - 2021-07-08 12:23:32 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:23:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:23:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:23:32 --> Encryption Class Initialized
INFO - 2021-07-08 12:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:23:32 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:23:32 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:23:32 --> Model "user_model" initialized
INFO - 2021-07-08 12:23:32 --> Model "role_model" initialized
INFO - 2021-07-08 12:23:32 --> Controller Class Initialized
INFO - 2021-07-08 12:23:32 --> Helper loaded: language_helper
INFO - 2021-07-08 12:23:32 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:23:32 --> Model "Quotation_model" initialized
INFO - 2021-07-08 12:23:32 --> Final output sent to browser
DEBUG - 2021-07-08 12:23:32 --> Total execution time: 0.0729
INFO - 2021-07-08 12:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:23:32 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:23:32 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:23:32 --> Model "user_model" initialized
INFO - 2021-07-08 12:23:32 --> Model "role_model" initialized
INFO - 2021-07-08 12:23:32 --> Controller Class Initialized
INFO - 2021-07-08 12:23:32 --> Helper loaded: language_helper
INFO - 2021-07-08 12:23:32 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:23:32 --> Model "Quotation_model" initialized
INFO - 2021-07-08 12:23:32 --> Final output sent to browser
DEBUG - 2021-07-08 12:23:32 --> Total execution time: 0.0816
INFO - 2021-07-08 12:23:36 --> Config Class Initialized
INFO - 2021-07-08 12:23:36 --> Hooks Class Initialized
INFO - 2021-07-08 12:23:36 --> Config Class Initialized
INFO - 2021-07-08 12:23:36 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:23:36 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:23:36 --> Utf8 Class Initialized
DEBUG - 2021-07-08 12:23:36 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:23:36 --> Utf8 Class Initialized
INFO - 2021-07-08 12:23:36 --> URI Class Initialized
INFO - 2021-07-08 12:23:36 --> URI Class Initialized
INFO - 2021-07-08 12:23:36 --> Router Class Initialized
INFO - 2021-07-08 12:23:36 --> Router Class Initialized
INFO - 2021-07-08 12:23:36 --> Output Class Initialized
INFO - 2021-07-08 12:23:36 --> Output Class Initialized
INFO - 2021-07-08 12:23:36 --> Security Class Initialized
INFO - 2021-07-08 12:23:36 --> Security Class Initialized
DEBUG - 2021-07-08 12:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-08 12:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:23:36 --> Input Class Initialized
INFO - 2021-07-08 12:23:36 --> Input Class Initialized
INFO - 2021-07-08 12:23:36 --> Language Class Initialized
INFO - 2021-07-08 12:23:36 --> Language Class Initialized
INFO - 2021-07-08 12:23:36 --> Loader Class Initialized
INFO - 2021-07-08 12:23:36 --> Loader Class Initialized
INFO - 2021-07-08 12:23:36 --> Helper loaded: html_helper
INFO - 2021-07-08 12:23:36 --> Helper loaded: html_helper
INFO - 2021-07-08 12:23:36 --> Helper loaded: url_helper
INFO - 2021-07-08 12:23:36 --> Helper loaded: url_helper
INFO - 2021-07-08 12:23:36 --> Helper loaded: form_helper
INFO - 2021-07-08 12:23:36 --> Helper loaded: form_helper
INFO - 2021-07-08 12:23:36 --> Database Driver Class Initialized
INFO - 2021-07-08 12:23:36 --> Database Driver Class Initialized
INFO - 2021-07-08 12:23:36 --> Form Validation Class Initialized
INFO - 2021-07-08 12:23:36 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-08 12:23:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:23:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:23:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:23:36 --> Encryption Class Initialized
INFO - 2021-07-08 12:23:36 --> Encryption Class Initialized
INFO - 2021-07-08 12:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:23:36 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:23:36 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:23:36 --> Model "user_model" initialized
INFO - 2021-07-08 12:23:36 --> Model "role_model" initialized
INFO - 2021-07-08 12:23:36 --> Controller Class Initialized
INFO - 2021-07-08 12:23:36 --> Helper loaded: language_helper
INFO - 2021-07-08 12:23:36 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:23:36 --> Model "Quotation_model" initialized
INFO - 2021-07-08 12:23:36 --> Final output sent to browser
DEBUG - 2021-07-08 12:23:36 --> Total execution time: 0.0722
INFO - 2021-07-08 12:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:23:36 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:23:36 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:23:36 --> Model "user_model" initialized
INFO - 2021-07-08 12:23:36 --> Model "role_model" initialized
INFO - 2021-07-08 12:23:36 --> Controller Class Initialized
INFO - 2021-07-08 12:23:36 --> Helper loaded: language_helper
INFO - 2021-07-08 12:23:36 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:23:36 --> Model "Quotation_model" initialized
INFO - 2021-07-08 12:23:36 --> Final output sent to browser
DEBUG - 2021-07-08 12:23:36 --> Total execution time: 0.0835
INFO - 2021-07-08 12:24:02 --> Config Class Initialized
INFO - 2021-07-08 12:24:02 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:24:02 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:24:02 --> Utf8 Class Initialized
INFO - 2021-07-08 12:24:02 --> URI Class Initialized
INFO - 2021-07-08 12:24:02 --> Router Class Initialized
INFO - 2021-07-08 12:24:02 --> Output Class Initialized
INFO - 2021-07-08 12:24:02 --> Security Class Initialized
DEBUG - 2021-07-08 12:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:24:02 --> Input Class Initialized
INFO - 2021-07-08 12:24:02 --> Language Class Initialized
INFO - 2021-07-08 12:24:02 --> Loader Class Initialized
INFO - 2021-07-08 12:24:02 --> Helper loaded: html_helper
INFO - 2021-07-08 12:24:02 --> Helper loaded: url_helper
INFO - 2021-07-08 12:24:02 --> Helper loaded: form_helper
INFO - 2021-07-08 12:24:02 --> Database Driver Class Initialized
INFO - 2021-07-08 12:24:02 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:24:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:24:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:24:02 --> Encryption Class Initialized
INFO - 2021-07-08 12:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:24:02 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:24:02 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:24:02 --> Model "user_model" initialized
INFO - 2021-07-08 12:24:02 --> Model "role_model" initialized
INFO - 2021-07-08 12:24:02 --> Controller Class Initialized
INFO - 2021-07-08 12:24:02 --> Helper loaded: language_helper
INFO - 2021-07-08 12:24:02 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:24:02 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:24:02 --> Model "Product_model" initialized
INFO - 2021-07-08 12:24:02 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:24:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:24:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:24:02 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 12:24:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 12:24:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:24:02 --> Final output sent to browser
DEBUG - 2021-07-08 12:24:02 --> Total execution time: 0.0639
INFO - 2021-07-08 12:24:08 --> Config Class Initialized
INFO - 2021-07-08 12:24:08 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:24:08 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:24:08 --> Utf8 Class Initialized
INFO - 2021-07-08 12:24:08 --> URI Class Initialized
INFO - 2021-07-08 12:24:08 --> Router Class Initialized
INFO - 2021-07-08 12:24:08 --> Output Class Initialized
INFO - 2021-07-08 12:24:08 --> Security Class Initialized
DEBUG - 2021-07-08 12:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:24:08 --> Input Class Initialized
INFO - 2021-07-08 12:24:08 --> Language Class Initialized
INFO - 2021-07-08 12:24:08 --> Loader Class Initialized
INFO - 2021-07-08 12:24:08 --> Helper loaded: html_helper
INFO - 2021-07-08 12:24:08 --> Helper loaded: url_helper
INFO - 2021-07-08 12:24:08 --> Helper loaded: form_helper
INFO - 2021-07-08 12:24:08 --> Database Driver Class Initialized
INFO - 2021-07-08 12:24:08 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:24:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:24:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:24:08 --> Encryption Class Initialized
INFO - 2021-07-08 12:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:24:08 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:24:08 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:24:08 --> Model "user_model" initialized
INFO - 2021-07-08 12:24:08 --> Model "role_model" initialized
INFO - 2021-07-08 12:24:08 --> Controller Class Initialized
INFO - 2021-07-08 12:24:08 --> Helper loaded: language_helper
INFO - 2021-07-08 12:24:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:24:08 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:24:08 --> Final output sent to browser
DEBUG - 2021-07-08 12:24:08 --> Total execution time: 0.0646
INFO - 2021-07-08 12:24:08 --> Config Class Initialized
INFO - 2021-07-08 12:24:08 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:24:08 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:24:08 --> Utf8 Class Initialized
INFO - 2021-07-08 12:24:08 --> URI Class Initialized
INFO - 2021-07-08 12:24:08 --> Router Class Initialized
INFO - 2021-07-08 12:24:08 --> Output Class Initialized
INFO - 2021-07-08 12:24:08 --> Security Class Initialized
DEBUG - 2021-07-08 12:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:24:08 --> Input Class Initialized
INFO - 2021-07-08 12:24:08 --> Language Class Initialized
INFO - 2021-07-08 12:24:08 --> Loader Class Initialized
INFO - 2021-07-08 12:24:08 --> Helper loaded: html_helper
INFO - 2021-07-08 12:24:08 --> Helper loaded: url_helper
INFO - 2021-07-08 12:24:08 --> Helper loaded: form_helper
INFO - 2021-07-08 12:24:08 --> Database Driver Class Initialized
INFO - 2021-07-08 12:24:08 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:24:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:24:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:24:08 --> Encryption Class Initialized
INFO - 2021-07-08 12:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:24:08 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:24:08 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:24:08 --> Model "user_model" initialized
INFO - 2021-07-08 12:24:08 --> Model "role_model" initialized
INFO - 2021-07-08 12:24:08 --> Controller Class Initialized
INFO - 2021-07-08 12:24:08 --> Helper loaded: language_helper
INFO - 2021-07-08 12:24:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:24:08 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:24:08 --> Final output sent to browser
DEBUG - 2021-07-08 12:24:08 --> Total execution time: 0.0579
INFO - 2021-07-08 12:24:10 --> Config Class Initialized
INFO - 2021-07-08 12:24:10 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:24:10 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:24:10 --> Utf8 Class Initialized
INFO - 2021-07-08 12:24:10 --> URI Class Initialized
INFO - 2021-07-08 12:24:10 --> Router Class Initialized
INFO - 2021-07-08 12:24:10 --> Output Class Initialized
INFO - 2021-07-08 12:24:10 --> Security Class Initialized
DEBUG - 2021-07-08 12:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:24:11 --> Input Class Initialized
INFO - 2021-07-08 12:24:11 --> Language Class Initialized
INFO - 2021-07-08 12:24:11 --> Loader Class Initialized
INFO - 2021-07-08 12:24:11 --> Helper loaded: html_helper
INFO - 2021-07-08 12:24:11 --> Helper loaded: url_helper
INFO - 2021-07-08 12:24:11 --> Helper loaded: form_helper
INFO - 2021-07-08 12:24:11 --> Database Driver Class Initialized
INFO - 2021-07-08 12:24:11 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:24:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:24:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:24:11 --> Encryption Class Initialized
INFO - 2021-07-08 12:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:24:11 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:24:11 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:24:11 --> Model "user_model" initialized
INFO - 2021-07-08 12:24:11 --> Model "role_model" initialized
INFO - 2021-07-08 12:24:11 --> Controller Class Initialized
INFO - 2021-07-08 12:24:11 --> Helper loaded: language_helper
INFO - 2021-07-08 12:24:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:24:11 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:24:11 --> Final output sent to browser
DEBUG - 2021-07-08 12:24:11 --> Total execution time: 0.0653
INFO - 2021-07-08 12:24:11 --> Config Class Initialized
INFO - 2021-07-08 12:24:11 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:24:11 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:24:11 --> Utf8 Class Initialized
INFO - 2021-07-08 12:24:11 --> URI Class Initialized
INFO - 2021-07-08 12:24:11 --> Router Class Initialized
INFO - 2021-07-08 12:24:11 --> Output Class Initialized
INFO - 2021-07-08 12:24:11 --> Security Class Initialized
DEBUG - 2021-07-08 12:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:24:11 --> Input Class Initialized
INFO - 2021-07-08 12:24:11 --> Language Class Initialized
INFO - 2021-07-08 12:24:11 --> Loader Class Initialized
INFO - 2021-07-08 12:24:11 --> Helper loaded: html_helper
INFO - 2021-07-08 12:24:11 --> Helper loaded: url_helper
INFO - 2021-07-08 12:24:11 --> Helper loaded: form_helper
INFO - 2021-07-08 12:24:11 --> Database Driver Class Initialized
INFO - 2021-07-08 12:24:11 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:24:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:24:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:24:11 --> Encryption Class Initialized
INFO - 2021-07-08 12:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:24:11 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:24:11 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:24:11 --> Model "user_model" initialized
INFO - 2021-07-08 12:24:11 --> Model "role_model" initialized
INFO - 2021-07-08 12:24:11 --> Controller Class Initialized
INFO - 2021-07-08 12:24:11 --> Helper loaded: language_helper
INFO - 2021-07-08 12:24:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:24:11 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:24:11 --> Final output sent to browser
DEBUG - 2021-07-08 12:24:11 --> Total execution time: 0.0585
INFO - 2021-07-08 12:24:13 --> Config Class Initialized
INFO - 2021-07-08 12:24:13 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:24:13 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:24:13 --> Utf8 Class Initialized
INFO - 2021-07-08 12:24:13 --> URI Class Initialized
INFO - 2021-07-08 12:24:13 --> Router Class Initialized
INFO - 2021-07-08 12:24:13 --> Output Class Initialized
INFO - 2021-07-08 12:24:13 --> Security Class Initialized
DEBUG - 2021-07-08 12:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:24:13 --> Input Class Initialized
INFO - 2021-07-08 12:24:13 --> Language Class Initialized
INFO - 2021-07-08 12:24:13 --> Loader Class Initialized
INFO - 2021-07-08 12:24:13 --> Helper loaded: html_helper
INFO - 2021-07-08 12:24:13 --> Helper loaded: url_helper
INFO - 2021-07-08 12:24:13 --> Helper loaded: form_helper
INFO - 2021-07-08 12:24:13 --> Database Driver Class Initialized
INFO - 2021-07-08 12:24:13 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:24:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:24:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:24:13 --> Encryption Class Initialized
INFO - 2021-07-08 12:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:24:13 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:24:13 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:24:13 --> Model "user_model" initialized
INFO - 2021-07-08 12:24:13 --> Model "role_model" initialized
INFO - 2021-07-08 12:24:13 --> Controller Class Initialized
INFO - 2021-07-08 12:24:13 --> Helper loaded: language_helper
INFO - 2021-07-08 12:24:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:24:13 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:24:13 --> Final output sent to browser
DEBUG - 2021-07-08 12:24:13 --> Total execution time: 0.0579
INFO - 2021-07-08 12:24:13 --> Config Class Initialized
INFO - 2021-07-08 12:24:13 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:24:13 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:24:13 --> Utf8 Class Initialized
INFO - 2021-07-08 12:24:13 --> URI Class Initialized
INFO - 2021-07-08 12:24:13 --> Router Class Initialized
INFO - 2021-07-08 12:24:13 --> Output Class Initialized
INFO - 2021-07-08 12:24:13 --> Security Class Initialized
DEBUG - 2021-07-08 12:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:24:13 --> Input Class Initialized
INFO - 2021-07-08 12:24:13 --> Language Class Initialized
INFO - 2021-07-08 12:24:13 --> Loader Class Initialized
INFO - 2021-07-08 12:24:13 --> Helper loaded: html_helper
INFO - 2021-07-08 12:24:13 --> Helper loaded: url_helper
INFO - 2021-07-08 12:24:13 --> Helper loaded: form_helper
INFO - 2021-07-08 12:24:13 --> Database Driver Class Initialized
INFO - 2021-07-08 12:24:13 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:24:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:24:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:24:13 --> Encryption Class Initialized
INFO - 2021-07-08 12:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:24:13 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:24:13 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:24:13 --> Model "user_model" initialized
INFO - 2021-07-08 12:24:13 --> Model "role_model" initialized
INFO - 2021-07-08 12:24:13 --> Controller Class Initialized
INFO - 2021-07-08 12:24:13 --> Helper loaded: language_helper
INFO - 2021-07-08 12:24:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:24:13 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:24:13 --> Final output sent to browser
DEBUG - 2021-07-08 12:24:13 --> Total execution time: 0.0636
INFO - 2021-07-08 12:24:15 --> Config Class Initialized
INFO - 2021-07-08 12:24:15 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:24:15 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:24:15 --> Utf8 Class Initialized
INFO - 2021-07-08 12:24:15 --> URI Class Initialized
INFO - 2021-07-08 12:24:15 --> Router Class Initialized
INFO - 2021-07-08 12:24:15 --> Output Class Initialized
INFO - 2021-07-08 12:24:15 --> Security Class Initialized
DEBUG - 2021-07-08 12:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:24:15 --> Input Class Initialized
INFO - 2021-07-08 12:24:15 --> Language Class Initialized
INFO - 2021-07-08 12:24:15 --> Loader Class Initialized
INFO - 2021-07-08 12:24:15 --> Helper loaded: html_helper
INFO - 2021-07-08 12:24:15 --> Helper loaded: url_helper
INFO - 2021-07-08 12:24:15 --> Helper loaded: form_helper
INFO - 2021-07-08 12:24:15 --> Database Driver Class Initialized
INFO - 2021-07-08 12:24:15 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:24:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:24:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:24:15 --> Encryption Class Initialized
INFO - 2021-07-08 12:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:24:15 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:24:15 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:24:15 --> Model "user_model" initialized
INFO - 2021-07-08 12:24:15 --> Model "role_model" initialized
INFO - 2021-07-08 12:24:15 --> Controller Class Initialized
INFO - 2021-07-08 12:24:15 --> Helper loaded: language_helper
INFO - 2021-07-08 12:24:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:24:15 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:24:15 --> Final output sent to browser
DEBUG - 2021-07-08 12:24:15 --> Total execution time: 0.0632
INFO - 2021-07-08 12:24:15 --> Config Class Initialized
INFO - 2021-07-08 12:24:15 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:24:15 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:24:15 --> Utf8 Class Initialized
INFO - 2021-07-08 12:24:15 --> URI Class Initialized
INFO - 2021-07-08 12:24:15 --> Router Class Initialized
INFO - 2021-07-08 12:24:15 --> Output Class Initialized
INFO - 2021-07-08 12:24:15 --> Security Class Initialized
DEBUG - 2021-07-08 12:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:24:15 --> Input Class Initialized
INFO - 2021-07-08 12:24:15 --> Language Class Initialized
INFO - 2021-07-08 12:24:15 --> Loader Class Initialized
INFO - 2021-07-08 12:24:15 --> Helper loaded: html_helper
INFO - 2021-07-08 12:24:15 --> Helper loaded: url_helper
INFO - 2021-07-08 12:24:15 --> Helper loaded: form_helper
INFO - 2021-07-08 12:24:15 --> Database Driver Class Initialized
INFO - 2021-07-08 12:24:15 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:24:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:24:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:24:15 --> Encryption Class Initialized
INFO - 2021-07-08 12:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:24:15 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:24:15 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:24:15 --> Model "user_model" initialized
INFO - 2021-07-08 12:24:15 --> Model "role_model" initialized
INFO - 2021-07-08 12:24:15 --> Controller Class Initialized
INFO - 2021-07-08 12:24:15 --> Helper loaded: language_helper
INFO - 2021-07-08 12:24:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:24:15 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:24:15 --> Final output sent to browser
DEBUG - 2021-07-08 12:24:15 --> Total execution time: 0.0579
INFO - 2021-07-08 12:24:21 --> Config Class Initialized
INFO - 2021-07-08 12:24:21 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:24:21 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:24:21 --> Utf8 Class Initialized
INFO - 2021-07-08 12:24:21 --> URI Class Initialized
INFO - 2021-07-08 12:24:21 --> Router Class Initialized
INFO - 2021-07-08 12:24:21 --> Output Class Initialized
INFO - 2021-07-08 12:24:21 --> Security Class Initialized
DEBUG - 2021-07-08 12:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:24:21 --> Input Class Initialized
INFO - 2021-07-08 12:24:21 --> Language Class Initialized
INFO - 2021-07-08 12:24:21 --> Loader Class Initialized
INFO - 2021-07-08 12:24:21 --> Helper loaded: html_helper
INFO - 2021-07-08 12:24:21 --> Helper loaded: url_helper
INFO - 2021-07-08 12:24:21 --> Helper loaded: form_helper
INFO - 2021-07-08 12:24:21 --> Database Driver Class Initialized
INFO - 2021-07-08 12:24:21 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:24:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:24:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:24:21 --> Encryption Class Initialized
INFO - 2021-07-08 12:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:24:21 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:24:21 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:24:21 --> Model "user_model" initialized
INFO - 2021-07-08 12:24:21 --> Model "role_model" initialized
INFO - 2021-07-08 12:24:21 --> Controller Class Initialized
INFO - 2021-07-08 12:24:21 --> Helper loaded: language_helper
INFO - 2021-07-08 12:24:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:24:21 --> Model "Product_model" initialized
INFO - 2021-07-08 12:24:21 --> Final output sent to browser
DEBUG - 2021-07-08 12:24:21 --> Total execution time: 0.0662
INFO - 2021-07-08 12:24:33 --> Config Class Initialized
INFO - 2021-07-08 12:24:33 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:24:33 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:24:33 --> Utf8 Class Initialized
INFO - 2021-07-08 12:24:33 --> URI Class Initialized
INFO - 2021-07-08 12:24:33 --> Router Class Initialized
INFO - 2021-07-08 12:24:33 --> Output Class Initialized
INFO - 2021-07-08 12:24:33 --> Security Class Initialized
DEBUG - 2021-07-08 12:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:24:33 --> Input Class Initialized
INFO - 2021-07-08 12:24:33 --> Language Class Initialized
INFO - 2021-07-08 12:24:33 --> Loader Class Initialized
INFO - 2021-07-08 12:24:33 --> Helper loaded: html_helper
INFO - 2021-07-08 12:24:33 --> Helper loaded: url_helper
INFO - 2021-07-08 12:24:33 --> Helper loaded: form_helper
INFO - 2021-07-08 12:24:33 --> Database Driver Class Initialized
INFO - 2021-07-08 12:24:33 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:24:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:24:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:24:33 --> Encryption Class Initialized
INFO - 2021-07-08 12:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:24:33 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:24:33 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:24:33 --> Model "user_model" initialized
INFO - 2021-07-08 12:24:33 --> Model "role_model" initialized
INFO - 2021-07-08 12:24:33 --> Controller Class Initialized
INFO - 2021-07-08 12:24:33 --> Helper loaded: language_helper
INFO - 2021-07-08 12:24:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:24:33 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:24:33 --> Final output sent to browser
DEBUG - 2021-07-08 12:24:33 --> Total execution time: 0.0587
INFO - 2021-07-08 12:24:33 --> Config Class Initialized
INFO - 2021-07-08 12:24:33 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:24:33 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:24:33 --> Utf8 Class Initialized
INFO - 2021-07-08 12:24:33 --> URI Class Initialized
INFO - 2021-07-08 12:24:33 --> Router Class Initialized
INFO - 2021-07-08 12:24:33 --> Output Class Initialized
INFO - 2021-07-08 12:24:33 --> Security Class Initialized
DEBUG - 2021-07-08 12:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:24:33 --> Input Class Initialized
INFO - 2021-07-08 12:24:33 --> Language Class Initialized
INFO - 2021-07-08 12:24:33 --> Loader Class Initialized
INFO - 2021-07-08 12:24:33 --> Helper loaded: html_helper
INFO - 2021-07-08 12:24:33 --> Helper loaded: url_helper
INFO - 2021-07-08 12:24:33 --> Helper loaded: form_helper
INFO - 2021-07-08 12:24:33 --> Database Driver Class Initialized
INFO - 2021-07-08 12:24:33 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:24:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:24:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:24:33 --> Encryption Class Initialized
INFO - 2021-07-08 12:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:24:33 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:24:33 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:24:33 --> Model "user_model" initialized
INFO - 2021-07-08 12:24:33 --> Model "role_model" initialized
INFO - 2021-07-08 12:24:33 --> Controller Class Initialized
INFO - 2021-07-08 12:24:33 --> Helper loaded: language_helper
INFO - 2021-07-08 12:24:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:24:33 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:24:33 --> Final output sent to browser
DEBUG - 2021-07-08 12:24:33 --> Total execution time: 0.0575
INFO - 2021-07-08 12:24:42 --> Config Class Initialized
INFO - 2021-07-08 12:24:42 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:24:42 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:24:42 --> Utf8 Class Initialized
INFO - 2021-07-08 12:24:42 --> URI Class Initialized
INFO - 2021-07-08 12:24:42 --> Router Class Initialized
INFO - 2021-07-08 12:24:42 --> Output Class Initialized
INFO - 2021-07-08 12:24:42 --> Security Class Initialized
DEBUG - 2021-07-08 12:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:24:42 --> Input Class Initialized
INFO - 2021-07-08 12:24:42 --> Language Class Initialized
INFO - 2021-07-08 12:24:42 --> Loader Class Initialized
INFO - 2021-07-08 12:24:42 --> Helper loaded: html_helper
INFO - 2021-07-08 12:24:42 --> Helper loaded: url_helper
INFO - 2021-07-08 12:24:42 --> Helper loaded: form_helper
INFO - 2021-07-08 12:24:42 --> Database Driver Class Initialized
INFO - 2021-07-08 12:24:43 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:24:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:24:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:24:43 --> Encryption Class Initialized
INFO - 2021-07-08 12:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:24:43 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:24:43 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:24:43 --> Model "user_model" initialized
INFO - 2021-07-08 12:24:43 --> Model "role_model" initialized
INFO - 2021-07-08 12:24:43 --> Controller Class Initialized
INFO - 2021-07-08 12:24:43 --> Helper loaded: language_helper
INFO - 2021-07-08 12:24:43 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:24:43 --> Model "Quotation_model" initialized
INFO - 2021-07-08 12:24:43 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:24:43 --> Model "Product_model" initialized
INFO - 2021-07-08 12:24:43 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:24:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:24:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:24:43 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 12:24:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 12:24:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:24:43 --> Final output sent to browser
DEBUG - 2021-07-08 12:24:43 --> Total execution time: 0.0784
INFO - 2021-07-08 12:29:49 --> Config Class Initialized
INFO - 2021-07-08 12:29:49 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:29:49 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:29:49 --> Utf8 Class Initialized
INFO - 2021-07-08 12:29:49 --> URI Class Initialized
INFO - 2021-07-08 12:29:49 --> Router Class Initialized
INFO - 2021-07-08 12:29:49 --> Output Class Initialized
INFO - 2021-07-08 12:29:49 --> Security Class Initialized
DEBUG - 2021-07-08 12:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:29:49 --> Input Class Initialized
INFO - 2021-07-08 12:29:49 --> Language Class Initialized
INFO - 2021-07-08 12:29:49 --> Loader Class Initialized
INFO - 2021-07-08 12:29:49 --> Helper loaded: html_helper
INFO - 2021-07-08 12:29:49 --> Helper loaded: url_helper
INFO - 2021-07-08 12:29:49 --> Helper loaded: form_helper
INFO - 2021-07-08 12:29:49 --> Database Driver Class Initialized
INFO - 2021-07-08 12:29:49 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:29:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:29:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:29:49 --> Encryption Class Initialized
INFO - 2021-07-08 12:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:29:49 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:29:49 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:29:49 --> Model "user_model" initialized
INFO - 2021-07-08 12:29:49 --> Model "role_model" initialized
INFO - 2021-07-08 12:29:49 --> Controller Class Initialized
INFO - 2021-07-08 12:29:49 --> Helper loaded: language_helper
INFO - 2021-07-08 12:29:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:29:49 --> Model "Quotation_model" initialized
INFO - 2021-07-08 12:29:49 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:29:49 --> Model "Product_model" initialized
INFO - 2021-07-08 12:29:49 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:29:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:29:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:29:49 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 12:29:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 12:29:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:29:49 --> Final output sent to browser
DEBUG - 2021-07-08 12:29:49 --> Total execution time: 0.1245
INFO - 2021-07-08 12:29:54 --> Config Class Initialized
INFO - 2021-07-08 12:29:54 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:29:54 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:29:54 --> Utf8 Class Initialized
INFO - 2021-07-08 12:29:54 --> URI Class Initialized
INFO - 2021-07-08 12:29:54 --> Router Class Initialized
INFO - 2021-07-08 12:29:54 --> Output Class Initialized
INFO - 2021-07-08 12:29:54 --> Security Class Initialized
DEBUG - 2021-07-08 12:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:29:54 --> Input Class Initialized
INFO - 2021-07-08 12:29:54 --> Language Class Initialized
INFO - 2021-07-08 12:29:54 --> Loader Class Initialized
INFO - 2021-07-08 12:29:54 --> Helper loaded: html_helper
INFO - 2021-07-08 12:29:54 --> Helper loaded: url_helper
INFO - 2021-07-08 12:29:54 --> Helper loaded: form_helper
INFO - 2021-07-08 12:29:54 --> Database Driver Class Initialized
INFO - 2021-07-08 12:29:54 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:29:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:29:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:29:54 --> Encryption Class Initialized
INFO - 2021-07-08 12:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:29:54 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:29:54 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:29:54 --> Model "user_model" initialized
INFO - 2021-07-08 12:29:54 --> Model "role_model" initialized
INFO - 2021-07-08 12:29:54 --> Controller Class Initialized
INFO - 2021-07-08 12:29:54 --> Helper loaded: language_helper
INFO - 2021-07-08 12:29:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:29:54 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:29:54 --> Final output sent to browser
DEBUG - 2021-07-08 12:29:54 --> Total execution time: 0.0589
INFO - 2021-07-08 12:29:54 --> Config Class Initialized
INFO - 2021-07-08 12:29:54 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:29:54 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:29:54 --> Utf8 Class Initialized
INFO - 2021-07-08 12:29:54 --> URI Class Initialized
INFO - 2021-07-08 12:29:54 --> Router Class Initialized
INFO - 2021-07-08 12:29:54 --> Output Class Initialized
INFO - 2021-07-08 12:29:54 --> Security Class Initialized
DEBUG - 2021-07-08 12:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:29:54 --> Input Class Initialized
INFO - 2021-07-08 12:29:54 --> Language Class Initialized
INFO - 2021-07-08 12:29:54 --> Loader Class Initialized
INFO - 2021-07-08 12:29:54 --> Helper loaded: html_helper
INFO - 2021-07-08 12:29:54 --> Helper loaded: url_helper
INFO - 2021-07-08 12:29:54 --> Helper loaded: form_helper
INFO - 2021-07-08 12:29:54 --> Database Driver Class Initialized
INFO - 2021-07-08 12:29:54 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:29:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:29:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:29:54 --> Encryption Class Initialized
INFO - 2021-07-08 12:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:29:54 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:29:54 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:29:54 --> Model "user_model" initialized
INFO - 2021-07-08 12:29:54 --> Model "role_model" initialized
INFO - 2021-07-08 12:29:54 --> Controller Class Initialized
INFO - 2021-07-08 12:29:54 --> Helper loaded: language_helper
INFO - 2021-07-08 12:29:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:29:54 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:29:54 --> Final output sent to browser
DEBUG - 2021-07-08 12:29:54 --> Total execution time: 0.0578
INFO - 2021-07-08 12:29:58 --> Config Class Initialized
INFO - 2021-07-08 12:29:58 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:29:58 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:29:58 --> Utf8 Class Initialized
INFO - 2021-07-08 12:29:58 --> URI Class Initialized
INFO - 2021-07-08 12:29:58 --> Router Class Initialized
INFO - 2021-07-08 12:29:58 --> Output Class Initialized
INFO - 2021-07-08 12:29:58 --> Security Class Initialized
DEBUG - 2021-07-08 12:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:29:58 --> Input Class Initialized
INFO - 2021-07-08 12:29:58 --> Language Class Initialized
INFO - 2021-07-08 12:29:58 --> Loader Class Initialized
INFO - 2021-07-08 12:29:58 --> Helper loaded: html_helper
INFO - 2021-07-08 12:29:58 --> Helper loaded: url_helper
INFO - 2021-07-08 12:29:58 --> Helper loaded: form_helper
INFO - 2021-07-08 12:29:58 --> Database Driver Class Initialized
INFO - 2021-07-08 12:29:58 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:29:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:29:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:29:58 --> Encryption Class Initialized
INFO - 2021-07-08 12:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:29:58 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:29:58 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:29:58 --> Model "user_model" initialized
INFO - 2021-07-08 12:29:58 --> Model "role_model" initialized
INFO - 2021-07-08 12:29:58 --> Controller Class Initialized
INFO - 2021-07-08 12:29:58 --> Helper loaded: language_helper
INFO - 2021-07-08 12:29:58 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:29:58 --> Model "Quotation_model" initialized
INFO - 2021-07-08 12:29:58 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:29:58 --> Model "Product_model" initialized
INFO - 2021-07-08 12:29:58 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:29:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:29:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:29:58 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 12:29:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 12:29:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:29:58 --> Final output sent to browser
DEBUG - 2021-07-08 12:29:58 --> Total execution time: 0.0781
INFO - 2021-07-08 12:30:02 --> Config Class Initialized
INFO - 2021-07-08 12:30:02 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:30:02 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:30:02 --> Utf8 Class Initialized
INFO - 2021-07-08 12:30:02 --> URI Class Initialized
INFO - 2021-07-08 12:30:02 --> Router Class Initialized
INFO - 2021-07-08 12:30:02 --> Output Class Initialized
INFO - 2021-07-08 12:30:02 --> Security Class Initialized
DEBUG - 2021-07-08 12:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:30:02 --> Input Class Initialized
INFO - 2021-07-08 12:30:02 --> Language Class Initialized
INFO - 2021-07-08 12:30:02 --> Loader Class Initialized
INFO - 2021-07-08 12:30:02 --> Helper loaded: html_helper
INFO - 2021-07-08 12:30:02 --> Helper loaded: url_helper
INFO - 2021-07-08 12:30:02 --> Helper loaded: form_helper
INFO - 2021-07-08 12:30:02 --> Database Driver Class Initialized
INFO - 2021-07-08 12:30:02 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:30:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:30:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:30:02 --> Encryption Class Initialized
INFO - 2021-07-08 12:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:30:02 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:30:02 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:30:02 --> Model "user_model" initialized
INFO - 2021-07-08 12:30:02 --> Model "role_model" initialized
INFO - 2021-07-08 12:30:02 --> Controller Class Initialized
INFO - 2021-07-08 12:30:02 --> Helper loaded: language_helper
INFO - 2021-07-08 12:30:02 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:30:02 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:30:02 --> Model "Product_model" initialized
INFO - 2021-07-08 12:30:02 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:30:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:30:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:30:02 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 12:30:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 12:30:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:30:02 --> Final output sent to browser
DEBUG - 2021-07-08 12:30:02 --> Total execution time: 0.0702
INFO - 2021-07-08 12:30:06 --> Config Class Initialized
INFO - 2021-07-08 12:30:06 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:30:06 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:30:06 --> Utf8 Class Initialized
INFO - 2021-07-08 12:30:06 --> URI Class Initialized
INFO - 2021-07-08 12:30:06 --> Router Class Initialized
INFO - 2021-07-08 12:30:06 --> Output Class Initialized
INFO - 2021-07-08 12:30:06 --> Security Class Initialized
DEBUG - 2021-07-08 12:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:30:06 --> Input Class Initialized
INFO - 2021-07-08 12:30:06 --> Language Class Initialized
INFO - 2021-07-08 12:30:06 --> Loader Class Initialized
INFO - 2021-07-08 12:30:06 --> Helper loaded: html_helper
INFO - 2021-07-08 12:30:06 --> Helper loaded: url_helper
INFO - 2021-07-08 12:30:06 --> Helper loaded: form_helper
INFO - 2021-07-08 12:30:06 --> Database Driver Class Initialized
INFO - 2021-07-08 12:30:07 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:30:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:30:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:30:07 --> Encryption Class Initialized
INFO - 2021-07-08 12:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:30:07 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:30:07 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:30:07 --> Model "user_model" initialized
INFO - 2021-07-08 12:30:07 --> Model "role_model" initialized
INFO - 2021-07-08 12:30:07 --> Controller Class Initialized
INFO - 2021-07-08 12:30:07 --> Helper loaded: language_helper
INFO - 2021-07-08 12:30:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:30:07 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:30:07 --> Final output sent to browser
DEBUG - 2021-07-08 12:30:07 --> Total execution time: 0.0589
INFO - 2021-07-08 12:30:07 --> Config Class Initialized
INFO - 2021-07-08 12:30:07 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:30:07 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:30:07 --> Utf8 Class Initialized
INFO - 2021-07-08 12:30:07 --> URI Class Initialized
INFO - 2021-07-08 12:30:07 --> Router Class Initialized
INFO - 2021-07-08 12:30:07 --> Output Class Initialized
INFO - 2021-07-08 12:30:07 --> Security Class Initialized
DEBUG - 2021-07-08 12:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:30:07 --> Input Class Initialized
INFO - 2021-07-08 12:30:07 --> Language Class Initialized
INFO - 2021-07-08 12:30:07 --> Loader Class Initialized
INFO - 2021-07-08 12:30:07 --> Helper loaded: html_helper
INFO - 2021-07-08 12:30:07 --> Helper loaded: url_helper
INFO - 2021-07-08 12:30:07 --> Helper loaded: form_helper
INFO - 2021-07-08 12:30:07 --> Database Driver Class Initialized
INFO - 2021-07-08 12:30:07 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:30:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:30:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:30:07 --> Encryption Class Initialized
INFO - 2021-07-08 12:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:30:07 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:30:07 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:30:07 --> Model "user_model" initialized
INFO - 2021-07-08 12:30:07 --> Model "role_model" initialized
INFO - 2021-07-08 12:30:07 --> Controller Class Initialized
INFO - 2021-07-08 12:30:07 --> Helper loaded: language_helper
INFO - 2021-07-08 12:30:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:30:07 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:30:07 --> Final output sent to browser
DEBUG - 2021-07-08 12:30:07 --> Total execution time: 0.0591
INFO - 2021-07-08 12:30:27 --> Config Class Initialized
INFO - 2021-07-08 12:30:27 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:30:27 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:30:27 --> Utf8 Class Initialized
INFO - 2021-07-08 12:30:27 --> URI Class Initialized
INFO - 2021-07-08 12:30:27 --> Router Class Initialized
INFO - 2021-07-08 12:30:27 --> Output Class Initialized
INFO - 2021-07-08 12:30:27 --> Security Class Initialized
DEBUG - 2021-07-08 12:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:30:27 --> Input Class Initialized
INFO - 2021-07-08 12:30:27 --> Language Class Initialized
INFO - 2021-07-08 12:30:27 --> Loader Class Initialized
INFO - 2021-07-08 12:30:27 --> Helper loaded: html_helper
INFO - 2021-07-08 12:30:27 --> Helper loaded: url_helper
INFO - 2021-07-08 12:30:27 --> Helper loaded: form_helper
INFO - 2021-07-08 12:30:27 --> Database Driver Class Initialized
INFO - 2021-07-08 12:30:27 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:30:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:30:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:30:27 --> Encryption Class Initialized
INFO - 2021-07-08 12:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:30:27 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:30:27 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:30:27 --> Model "user_model" initialized
INFO - 2021-07-08 12:30:27 --> Model "role_model" initialized
INFO - 2021-07-08 12:30:27 --> Controller Class Initialized
INFO - 2021-07-08 12:30:27 --> Helper loaded: language_helper
INFO - 2021-07-08 12:30:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:30:27 --> Model "Product_model" initialized
INFO - 2021-07-08 12:30:27 --> Final output sent to browser
DEBUG - 2021-07-08 12:30:27 --> Total execution time: 0.0622
INFO - 2021-07-08 12:30:37 --> Config Class Initialized
INFO - 2021-07-08 12:30:37 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:30:37 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:30:37 --> Utf8 Class Initialized
INFO - 2021-07-08 12:30:37 --> URI Class Initialized
INFO - 2021-07-08 12:30:37 --> Router Class Initialized
INFO - 2021-07-08 12:30:37 --> Output Class Initialized
INFO - 2021-07-08 12:30:37 --> Security Class Initialized
DEBUG - 2021-07-08 12:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:30:37 --> Input Class Initialized
INFO - 2021-07-08 12:30:37 --> Language Class Initialized
INFO - 2021-07-08 12:30:37 --> Loader Class Initialized
INFO - 2021-07-08 12:30:37 --> Helper loaded: html_helper
INFO - 2021-07-08 12:30:37 --> Helper loaded: url_helper
INFO - 2021-07-08 12:30:37 --> Helper loaded: form_helper
INFO - 2021-07-08 12:30:37 --> Database Driver Class Initialized
INFO - 2021-07-08 12:30:37 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:30:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:30:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:30:37 --> Encryption Class Initialized
INFO - 2021-07-08 12:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:30:37 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:30:37 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:30:37 --> Model "user_model" initialized
INFO - 2021-07-08 12:30:37 --> Model "role_model" initialized
INFO - 2021-07-08 12:30:37 --> Controller Class Initialized
INFO - 2021-07-08 12:30:37 --> Helper loaded: language_helper
INFO - 2021-07-08 12:30:37 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:30:37 --> Model "Quotation_model" initialized
INFO - 2021-07-08 12:30:37 --> Final output sent to browser
DEBUG - 2021-07-08 12:30:37 --> Total execution time: 0.0611
INFO - 2021-07-08 12:30:37 --> Config Class Initialized
INFO - 2021-07-08 12:30:37 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:30:37 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:30:37 --> Utf8 Class Initialized
INFO - 2021-07-08 12:30:37 --> URI Class Initialized
INFO - 2021-07-08 12:30:37 --> Router Class Initialized
INFO - 2021-07-08 12:30:37 --> Output Class Initialized
INFO - 2021-07-08 12:30:37 --> Security Class Initialized
DEBUG - 2021-07-08 12:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:30:37 --> Input Class Initialized
INFO - 2021-07-08 12:30:37 --> Language Class Initialized
INFO - 2021-07-08 12:30:37 --> Loader Class Initialized
INFO - 2021-07-08 12:30:37 --> Helper loaded: html_helper
INFO - 2021-07-08 12:30:37 --> Helper loaded: url_helper
INFO - 2021-07-08 12:30:37 --> Helper loaded: form_helper
INFO - 2021-07-08 12:30:37 --> Database Driver Class Initialized
INFO - 2021-07-08 12:30:37 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:30:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:30:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:30:37 --> Encryption Class Initialized
INFO - 2021-07-08 12:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:30:37 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:30:37 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:30:37 --> Model "user_model" initialized
INFO - 2021-07-08 12:30:37 --> Model "role_model" initialized
INFO - 2021-07-08 12:30:37 --> Controller Class Initialized
INFO - 2021-07-08 12:30:37 --> Helper loaded: language_helper
INFO - 2021-07-08 12:30:37 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:30:37 --> Model "Quotation_model" initialized
INFO - 2021-07-08 12:30:37 --> Final output sent to browser
DEBUG - 2021-07-08 12:30:37 --> Total execution time: 0.0576
INFO - 2021-07-08 12:30:39 --> Config Class Initialized
INFO - 2021-07-08 12:30:39 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:30:39 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:30:39 --> Utf8 Class Initialized
INFO - 2021-07-08 12:30:39 --> URI Class Initialized
INFO - 2021-07-08 12:30:39 --> Router Class Initialized
INFO - 2021-07-08 12:30:39 --> Output Class Initialized
INFO - 2021-07-08 12:30:39 --> Security Class Initialized
DEBUG - 2021-07-08 12:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:30:39 --> Input Class Initialized
INFO - 2021-07-08 12:30:39 --> Language Class Initialized
INFO - 2021-07-08 12:30:39 --> Loader Class Initialized
INFO - 2021-07-08 12:30:39 --> Helper loaded: html_helper
INFO - 2021-07-08 12:30:39 --> Helper loaded: url_helper
INFO - 2021-07-08 12:30:39 --> Helper loaded: form_helper
INFO - 2021-07-08 12:30:39 --> Database Driver Class Initialized
INFO - 2021-07-08 12:30:39 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:30:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:30:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:30:39 --> Encryption Class Initialized
INFO - 2021-07-08 12:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:30:39 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:30:39 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:30:39 --> Model "user_model" initialized
INFO - 2021-07-08 12:30:39 --> Model "role_model" initialized
INFO - 2021-07-08 12:30:39 --> Controller Class Initialized
INFO - 2021-07-08 12:30:39 --> Helper loaded: language_helper
INFO - 2021-07-08 12:30:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:30:39 --> Model "Quotation_model" initialized
INFO - 2021-07-08 12:30:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:30:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:30:39 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-08 12:30:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-08 12:30:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:30:39 --> Final output sent to browser
DEBUG - 2021-07-08 12:30:39 --> Total execution time: 0.0608
INFO - 2021-07-08 12:30:39 --> Config Class Initialized
INFO - 2021-07-08 12:30:39 --> Hooks Class Initialized
INFO - 2021-07-08 12:30:39 --> Config Class Initialized
INFO - 2021-07-08 12:30:39 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:30:39 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:30:39 --> Utf8 Class Initialized
DEBUG - 2021-07-08 12:30:39 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:30:39 --> Utf8 Class Initialized
INFO - 2021-07-08 12:30:39 --> URI Class Initialized
INFO - 2021-07-08 12:30:39 --> URI Class Initialized
INFO - 2021-07-08 12:30:39 --> Router Class Initialized
INFO - 2021-07-08 12:30:39 --> Router Class Initialized
INFO - 2021-07-08 12:30:39 --> Output Class Initialized
INFO - 2021-07-08 12:30:39 --> Security Class Initialized
DEBUG - 2021-07-08 12:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:30:39 --> Input Class Initialized
INFO - 2021-07-08 12:30:39 --> Language Class Initialized
INFO - 2021-07-08 12:30:39 --> Loader Class Initialized
INFO - 2021-07-08 12:30:39 --> Helper loaded: html_helper
INFO - 2021-07-08 12:30:39 --> Helper loaded: url_helper
INFO - 2021-07-08 12:30:39 --> Helper loaded: form_helper
INFO - 2021-07-08 12:30:39 --> Database Driver Class Initialized
INFO - 2021-07-08 12:30:39 --> Output Class Initialized
INFO - 2021-07-08 12:30:39 --> Security Class Initialized
DEBUG - 2021-07-08 12:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:30:39 --> Input Class Initialized
INFO - 2021-07-08 12:30:39 --> Language Class Initialized
INFO - 2021-07-08 12:30:39 --> Loader Class Initialized
INFO - 2021-07-08 12:30:39 --> Helper loaded: html_helper
INFO - 2021-07-08 12:30:39 --> Helper loaded: url_helper
INFO - 2021-07-08 12:30:39 --> Helper loaded: form_helper
INFO - 2021-07-08 12:30:39 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:30:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:30:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:30:39 --> Encryption Class Initialized
INFO - 2021-07-08 12:30:39 --> Database Driver Class Initialized
INFO - 2021-07-08 12:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:30:39 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:30:39 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:30:39 --> Model "user_model" initialized
INFO - 2021-07-08 12:30:39 --> Model "role_model" initialized
INFO - 2021-07-08 12:30:39 --> Controller Class Initialized
INFO - 2021-07-08 12:30:39 --> Helper loaded: language_helper
INFO - 2021-07-08 12:30:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:30:39 --> Model "Quotation_model" initialized
INFO - 2021-07-08 12:30:39 --> Form Validation Class Initialized
INFO - 2021-07-08 12:30:39 --> Final output sent to browser
DEBUG - 2021-07-08 12:30:39 --> Total execution time: 0.0841
DEBUG - 2021-07-08 12:30:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:30:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:30:39 --> Encryption Class Initialized
INFO - 2021-07-08 12:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:30:39 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:30:39 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:30:39 --> Model "user_model" initialized
INFO - 2021-07-08 12:30:39 --> Model "role_model" initialized
INFO - 2021-07-08 12:30:39 --> Controller Class Initialized
INFO - 2021-07-08 12:30:39 --> Helper loaded: language_helper
INFO - 2021-07-08 12:30:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:30:39 --> Model "Quotation_model" initialized
INFO - 2021-07-08 12:30:39 --> Final output sent to browser
DEBUG - 2021-07-08 12:30:39 --> Total execution time: 0.0990
INFO - 2021-07-08 12:31:25 --> Config Class Initialized
INFO - 2021-07-08 12:31:25 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:31:25 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:31:25 --> Utf8 Class Initialized
INFO - 2021-07-08 12:31:25 --> URI Class Initialized
INFO - 2021-07-08 12:31:25 --> Router Class Initialized
INFO - 2021-07-08 12:31:25 --> Output Class Initialized
INFO - 2021-07-08 12:31:25 --> Security Class Initialized
DEBUG - 2021-07-08 12:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:31:25 --> Input Class Initialized
INFO - 2021-07-08 12:31:25 --> Language Class Initialized
INFO - 2021-07-08 12:31:25 --> Loader Class Initialized
INFO - 2021-07-08 12:31:25 --> Helper loaded: html_helper
INFO - 2021-07-08 12:31:25 --> Helper loaded: url_helper
INFO - 2021-07-08 12:31:25 --> Helper loaded: form_helper
INFO - 2021-07-08 12:31:25 --> Database Driver Class Initialized
INFO - 2021-07-08 12:31:25 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:31:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:31:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:31:25 --> Encryption Class Initialized
INFO - 2021-07-08 12:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:31:25 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:31:25 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:31:25 --> Model "user_model" initialized
INFO - 2021-07-08 12:31:25 --> Model "role_model" initialized
INFO - 2021-07-08 12:31:25 --> Controller Class Initialized
INFO - 2021-07-08 12:31:25 --> Helper loaded: language_helper
INFO - 2021-07-08 12:31:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:31:25 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:31:25 --> Model "Product_model" initialized
INFO - 2021-07-08 12:31:25 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:31:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:31:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:31:25 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 12:31:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 12:31:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:31:25 --> Final output sent to browser
DEBUG - 2021-07-08 12:31:25 --> Total execution time: 0.1110
INFO - 2021-07-08 12:41:15 --> Config Class Initialized
INFO - 2021-07-08 12:41:15 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:41:15 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:41:15 --> Utf8 Class Initialized
INFO - 2021-07-08 12:41:15 --> URI Class Initialized
INFO - 2021-07-08 12:41:15 --> Router Class Initialized
INFO - 2021-07-08 12:41:15 --> Output Class Initialized
INFO - 2021-07-08 12:41:15 --> Security Class Initialized
DEBUG - 2021-07-08 12:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:41:15 --> Input Class Initialized
INFO - 2021-07-08 12:41:15 --> Language Class Initialized
INFO - 2021-07-08 12:41:15 --> Loader Class Initialized
INFO - 2021-07-08 12:41:15 --> Helper loaded: html_helper
INFO - 2021-07-08 12:41:15 --> Helper loaded: url_helper
INFO - 2021-07-08 12:41:15 --> Helper loaded: form_helper
INFO - 2021-07-08 12:41:15 --> Database Driver Class Initialized
INFO - 2021-07-08 12:41:15 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:41:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:41:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:41:15 --> Encryption Class Initialized
INFO - 2021-07-08 12:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:41:15 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:41:15 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:41:15 --> Model "user_model" initialized
INFO - 2021-07-08 12:41:15 --> Model "role_model" initialized
INFO - 2021-07-08 12:41:15 --> Controller Class Initialized
INFO - 2021-07-08 12:41:15 --> Helper loaded: language_helper
INFO - 2021-07-08 12:41:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:41:15 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:41:15 --> Model "Product_model" initialized
INFO - 2021-07-08 12:41:15 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:41:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:41:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:41:15 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 12:41:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 12:41:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:41:15 --> Final output sent to browser
DEBUG - 2021-07-08 12:41:15 --> Total execution time: 0.0824
INFO - 2021-07-08 12:41:21 --> Config Class Initialized
INFO - 2021-07-08 12:41:21 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:41:21 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:41:21 --> Utf8 Class Initialized
INFO - 2021-07-08 12:41:21 --> URI Class Initialized
INFO - 2021-07-08 12:41:21 --> Router Class Initialized
INFO - 2021-07-08 12:41:21 --> Output Class Initialized
INFO - 2021-07-08 12:41:21 --> Security Class Initialized
DEBUG - 2021-07-08 12:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:41:21 --> Input Class Initialized
INFO - 2021-07-08 12:41:21 --> Language Class Initialized
INFO - 2021-07-08 12:41:21 --> Loader Class Initialized
INFO - 2021-07-08 12:41:21 --> Helper loaded: html_helper
INFO - 2021-07-08 12:41:21 --> Helper loaded: url_helper
INFO - 2021-07-08 12:41:21 --> Helper loaded: form_helper
INFO - 2021-07-08 12:41:21 --> Database Driver Class Initialized
INFO - 2021-07-08 12:41:21 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:41:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:41:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:41:21 --> Encryption Class Initialized
INFO - 2021-07-08 12:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:41:21 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:41:21 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:41:21 --> Model "user_model" initialized
INFO - 2021-07-08 12:41:21 --> Model "role_model" initialized
INFO - 2021-07-08 12:41:21 --> Controller Class Initialized
INFO - 2021-07-08 12:41:21 --> Helper loaded: language_helper
INFO - 2021-07-08 12:41:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:41:21 --> Model "Product_model" initialized
INFO - 2021-07-08 12:41:21 --> Final output sent to browser
DEBUG - 2021-07-08 12:41:21 --> Total execution time: 0.0644
INFO - 2021-07-08 12:41:56 --> Config Class Initialized
INFO - 2021-07-08 12:41:56 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:41:56 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:41:56 --> Utf8 Class Initialized
INFO - 2021-07-08 12:41:56 --> URI Class Initialized
INFO - 2021-07-08 12:41:56 --> Router Class Initialized
INFO - 2021-07-08 12:41:56 --> Output Class Initialized
INFO - 2021-07-08 12:41:56 --> Security Class Initialized
DEBUG - 2021-07-08 12:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:41:56 --> Input Class Initialized
INFO - 2021-07-08 12:41:56 --> Language Class Initialized
INFO - 2021-07-08 12:41:56 --> Loader Class Initialized
INFO - 2021-07-08 12:41:56 --> Helper loaded: html_helper
INFO - 2021-07-08 12:41:56 --> Helper loaded: url_helper
INFO - 2021-07-08 12:41:56 --> Helper loaded: form_helper
INFO - 2021-07-08 12:41:56 --> Database Driver Class Initialized
INFO - 2021-07-08 12:41:56 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:41:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:41:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:41:56 --> Encryption Class Initialized
INFO - 2021-07-08 12:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:41:56 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:41:56 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:41:56 --> Model "user_model" initialized
INFO - 2021-07-08 12:41:56 --> Model "role_model" initialized
INFO - 2021-07-08 12:41:56 --> Controller Class Initialized
INFO - 2021-07-08 12:41:56 --> Helper loaded: language_helper
INFO - 2021-07-08 12:41:56 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:41:56 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:41:56 --> Model "Product_model" initialized
INFO - 2021-07-08 12:41:56 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:41:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:41:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:41:56 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 12:41:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 12:41:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:41:56 --> Final output sent to browser
DEBUG - 2021-07-08 12:41:56 --> Total execution time: 0.0726
INFO - 2021-07-08 12:42:00 --> Config Class Initialized
INFO - 2021-07-08 12:42:00 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:42:00 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:42:00 --> Utf8 Class Initialized
INFO - 2021-07-08 12:42:00 --> URI Class Initialized
INFO - 2021-07-08 12:42:00 --> Router Class Initialized
INFO - 2021-07-08 12:42:00 --> Output Class Initialized
INFO - 2021-07-08 12:42:00 --> Security Class Initialized
DEBUG - 2021-07-08 12:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:42:00 --> Input Class Initialized
INFO - 2021-07-08 12:42:00 --> Language Class Initialized
INFO - 2021-07-08 12:42:00 --> Loader Class Initialized
INFO - 2021-07-08 12:42:00 --> Helper loaded: html_helper
INFO - 2021-07-08 12:42:00 --> Helper loaded: url_helper
INFO - 2021-07-08 12:42:00 --> Helper loaded: form_helper
INFO - 2021-07-08 12:42:00 --> Database Driver Class Initialized
INFO - 2021-07-08 12:42:00 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:42:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:42:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:42:00 --> Encryption Class Initialized
INFO - 2021-07-08 12:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:42:00 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:42:00 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:42:00 --> Model "user_model" initialized
INFO - 2021-07-08 12:42:00 --> Model "role_model" initialized
INFO - 2021-07-08 12:42:00 --> Controller Class Initialized
INFO - 2021-07-08 12:42:00 --> Helper loaded: language_helper
INFO - 2021-07-08 12:42:00 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:42:00 --> Model "Product_model" initialized
INFO - 2021-07-08 12:42:00 --> Final output sent to browser
DEBUG - 2021-07-08 12:42:00 --> Total execution time: 0.0636
INFO - 2021-07-08 12:42:03 --> Config Class Initialized
INFO - 2021-07-08 12:42:03 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:42:03 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:42:03 --> Utf8 Class Initialized
INFO - 2021-07-08 12:42:03 --> URI Class Initialized
INFO - 2021-07-08 12:42:03 --> Router Class Initialized
INFO - 2021-07-08 12:42:03 --> Output Class Initialized
INFO - 2021-07-08 12:42:03 --> Security Class Initialized
DEBUG - 2021-07-08 12:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:42:03 --> Input Class Initialized
INFO - 2021-07-08 12:42:03 --> Language Class Initialized
INFO - 2021-07-08 12:42:03 --> Loader Class Initialized
INFO - 2021-07-08 12:42:03 --> Helper loaded: html_helper
INFO - 2021-07-08 12:42:03 --> Helper loaded: url_helper
INFO - 2021-07-08 12:42:03 --> Helper loaded: form_helper
INFO - 2021-07-08 12:42:03 --> Database Driver Class Initialized
INFO - 2021-07-08 12:42:03 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:42:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:42:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:42:03 --> Encryption Class Initialized
INFO - 2021-07-08 12:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:42:03 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:42:03 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:42:03 --> Model "user_model" initialized
INFO - 2021-07-08 12:42:03 --> Model "role_model" initialized
INFO - 2021-07-08 12:42:03 --> Controller Class Initialized
INFO - 2021-07-08 12:42:03 --> Helper loaded: language_helper
INFO - 2021-07-08 12:42:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:42:03 --> Model "Product_model" initialized
INFO - 2021-07-08 12:42:03 --> Final output sent to browser
DEBUG - 2021-07-08 12:42:03 --> Total execution time: 0.0575
INFO - 2021-07-08 12:42:05 --> Config Class Initialized
INFO - 2021-07-08 12:42:05 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:42:05 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:42:05 --> Utf8 Class Initialized
INFO - 2021-07-08 12:42:05 --> URI Class Initialized
INFO - 2021-07-08 12:42:05 --> Router Class Initialized
INFO - 2021-07-08 12:42:05 --> Output Class Initialized
INFO - 2021-07-08 12:42:05 --> Security Class Initialized
DEBUG - 2021-07-08 12:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:42:05 --> Input Class Initialized
INFO - 2021-07-08 12:42:05 --> Language Class Initialized
INFO - 2021-07-08 12:42:05 --> Loader Class Initialized
INFO - 2021-07-08 12:42:05 --> Helper loaded: html_helper
INFO - 2021-07-08 12:42:05 --> Helper loaded: url_helper
INFO - 2021-07-08 12:42:05 --> Helper loaded: form_helper
INFO - 2021-07-08 12:42:05 --> Database Driver Class Initialized
INFO - 2021-07-08 12:42:05 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:42:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:42:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:42:05 --> Encryption Class Initialized
INFO - 2021-07-08 12:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:42:05 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:42:05 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:42:05 --> Model "user_model" initialized
INFO - 2021-07-08 12:42:05 --> Model "role_model" initialized
INFO - 2021-07-08 12:42:05 --> Controller Class Initialized
INFO - 2021-07-08 12:42:05 --> Helper loaded: language_helper
INFO - 2021-07-08 12:42:05 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:42:05 --> Model "Product_model" initialized
INFO - 2021-07-08 12:42:05 --> Final output sent to browser
DEBUG - 2021-07-08 12:42:05 --> Total execution time: 0.0574
INFO - 2021-07-08 12:42:08 --> Config Class Initialized
INFO - 2021-07-08 12:42:08 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:42:08 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:42:08 --> Utf8 Class Initialized
INFO - 2021-07-08 12:42:08 --> URI Class Initialized
INFO - 2021-07-08 12:42:08 --> Router Class Initialized
INFO - 2021-07-08 12:42:08 --> Output Class Initialized
INFO - 2021-07-08 12:42:08 --> Security Class Initialized
DEBUG - 2021-07-08 12:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:42:08 --> Input Class Initialized
INFO - 2021-07-08 12:42:08 --> Language Class Initialized
INFO - 2021-07-08 12:42:08 --> Loader Class Initialized
INFO - 2021-07-08 12:42:08 --> Helper loaded: html_helper
INFO - 2021-07-08 12:42:08 --> Helper loaded: url_helper
INFO - 2021-07-08 12:42:08 --> Helper loaded: form_helper
INFO - 2021-07-08 12:42:08 --> Database Driver Class Initialized
INFO - 2021-07-08 12:42:08 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:42:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:42:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:42:08 --> Encryption Class Initialized
INFO - 2021-07-08 12:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:42:08 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:42:08 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:42:08 --> Model "user_model" initialized
INFO - 2021-07-08 12:42:08 --> Model "role_model" initialized
INFO - 2021-07-08 12:42:08 --> Controller Class Initialized
INFO - 2021-07-08 12:42:08 --> Helper loaded: language_helper
INFO - 2021-07-08 12:42:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:42:08 --> Model "Product_model" initialized
INFO - 2021-07-08 12:42:08 --> Final output sent to browser
DEBUG - 2021-07-08 12:42:08 --> Total execution time: 0.2142
INFO - 2021-07-08 12:42:10 --> Config Class Initialized
INFO - 2021-07-08 12:42:10 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:42:10 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:42:10 --> Utf8 Class Initialized
INFO - 2021-07-08 12:42:10 --> URI Class Initialized
INFO - 2021-07-08 12:42:10 --> Router Class Initialized
INFO - 2021-07-08 12:42:10 --> Output Class Initialized
INFO - 2021-07-08 12:42:10 --> Security Class Initialized
DEBUG - 2021-07-08 12:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:42:10 --> Input Class Initialized
INFO - 2021-07-08 12:42:10 --> Language Class Initialized
INFO - 2021-07-08 12:42:10 --> Loader Class Initialized
INFO - 2021-07-08 12:42:10 --> Helper loaded: html_helper
INFO - 2021-07-08 12:42:10 --> Helper loaded: url_helper
INFO - 2021-07-08 12:42:10 --> Helper loaded: form_helper
INFO - 2021-07-08 12:42:10 --> Database Driver Class Initialized
INFO - 2021-07-08 12:42:10 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:42:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:42:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:42:10 --> Encryption Class Initialized
INFO - 2021-07-08 12:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:42:10 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:42:10 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:42:10 --> Model "user_model" initialized
INFO - 2021-07-08 12:42:10 --> Model "role_model" initialized
INFO - 2021-07-08 12:42:10 --> Controller Class Initialized
INFO - 2021-07-08 12:42:10 --> Helper loaded: language_helper
INFO - 2021-07-08 12:42:10 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:42:10 --> Model "Product_model" initialized
INFO - 2021-07-08 12:42:10 --> Final output sent to browser
DEBUG - 2021-07-08 12:42:10 --> Total execution time: 0.0832
INFO - 2021-07-08 12:42:32 --> Config Class Initialized
INFO - 2021-07-08 12:42:32 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:42:32 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:42:32 --> Utf8 Class Initialized
INFO - 2021-07-08 12:42:32 --> URI Class Initialized
INFO - 2021-07-08 12:42:32 --> Router Class Initialized
INFO - 2021-07-08 12:42:32 --> Output Class Initialized
INFO - 2021-07-08 12:42:32 --> Security Class Initialized
DEBUG - 2021-07-08 12:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:42:32 --> Input Class Initialized
INFO - 2021-07-08 12:42:32 --> Language Class Initialized
INFO - 2021-07-08 12:42:32 --> Loader Class Initialized
INFO - 2021-07-08 12:42:32 --> Helper loaded: html_helper
INFO - 2021-07-08 12:42:32 --> Helper loaded: url_helper
INFO - 2021-07-08 12:42:32 --> Helper loaded: form_helper
INFO - 2021-07-08 12:42:32 --> Database Driver Class Initialized
INFO - 2021-07-08 12:42:32 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:42:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:42:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:42:32 --> Encryption Class Initialized
INFO - 2021-07-08 12:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:42:32 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:42:32 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:42:32 --> Model "user_model" initialized
INFO - 2021-07-08 12:42:32 --> Model "role_model" initialized
INFO - 2021-07-08 12:42:32 --> Controller Class Initialized
INFO - 2021-07-08 12:42:32 --> Helper loaded: language_helper
INFO - 2021-07-08 12:42:32 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:42:32 --> Model "Product_model" initialized
INFO - 2021-07-08 12:42:32 --> Final output sent to browser
DEBUG - 2021-07-08 12:42:32 --> Total execution time: 0.0618
INFO - 2021-07-08 12:42:35 --> Config Class Initialized
INFO - 2021-07-08 12:42:35 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:42:35 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:42:35 --> Utf8 Class Initialized
INFO - 2021-07-08 12:42:35 --> URI Class Initialized
INFO - 2021-07-08 12:42:35 --> Router Class Initialized
INFO - 2021-07-08 12:42:35 --> Output Class Initialized
INFO - 2021-07-08 12:42:35 --> Security Class Initialized
DEBUG - 2021-07-08 12:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:42:35 --> Input Class Initialized
INFO - 2021-07-08 12:42:35 --> Language Class Initialized
INFO - 2021-07-08 12:42:35 --> Loader Class Initialized
INFO - 2021-07-08 12:42:35 --> Helper loaded: html_helper
INFO - 2021-07-08 12:42:35 --> Helper loaded: url_helper
INFO - 2021-07-08 12:42:35 --> Helper loaded: form_helper
INFO - 2021-07-08 12:42:35 --> Database Driver Class Initialized
INFO - 2021-07-08 12:42:35 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:42:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:42:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:42:35 --> Encryption Class Initialized
INFO - 2021-07-08 12:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:42:35 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:42:35 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:42:35 --> Model "user_model" initialized
INFO - 2021-07-08 12:42:35 --> Model "role_model" initialized
INFO - 2021-07-08 12:42:35 --> Controller Class Initialized
INFO - 2021-07-08 12:42:35 --> Helper loaded: language_helper
INFO - 2021-07-08 12:42:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:42:35 --> Model "Product_model" initialized
INFO - 2021-07-08 12:42:35 --> Final output sent to browser
DEBUG - 2021-07-08 12:42:35 --> Total execution time: 0.0601
INFO - 2021-07-08 12:42:36 --> Config Class Initialized
INFO - 2021-07-08 12:42:36 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:42:36 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:42:36 --> Utf8 Class Initialized
INFO - 2021-07-08 12:42:36 --> URI Class Initialized
INFO - 2021-07-08 12:42:36 --> Router Class Initialized
INFO - 2021-07-08 12:42:36 --> Output Class Initialized
INFO - 2021-07-08 12:42:36 --> Security Class Initialized
DEBUG - 2021-07-08 12:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:42:36 --> Input Class Initialized
INFO - 2021-07-08 12:42:36 --> Language Class Initialized
INFO - 2021-07-08 12:42:36 --> Loader Class Initialized
INFO - 2021-07-08 12:42:36 --> Helper loaded: html_helper
INFO - 2021-07-08 12:42:36 --> Helper loaded: url_helper
INFO - 2021-07-08 12:42:36 --> Helper loaded: form_helper
INFO - 2021-07-08 12:42:36 --> Database Driver Class Initialized
INFO - 2021-07-08 12:42:36 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:42:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:42:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:42:36 --> Encryption Class Initialized
INFO - 2021-07-08 12:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:42:37 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:42:37 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:42:37 --> Model "user_model" initialized
INFO - 2021-07-08 12:42:37 --> Model "role_model" initialized
INFO - 2021-07-08 12:42:37 --> Controller Class Initialized
INFO - 2021-07-08 12:42:37 --> Helper loaded: language_helper
INFO - 2021-07-08 12:42:37 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:42:37 --> Model "Product_model" initialized
INFO - 2021-07-08 12:42:37 --> Final output sent to browser
DEBUG - 2021-07-08 12:42:37 --> Total execution time: 0.0587
INFO - 2021-07-08 12:42:38 --> Config Class Initialized
INFO - 2021-07-08 12:42:38 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:42:38 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:42:38 --> Utf8 Class Initialized
INFO - 2021-07-08 12:42:38 --> URI Class Initialized
INFO - 2021-07-08 12:42:38 --> Router Class Initialized
INFO - 2021-07-08 12:42:38 --> Output Class Initialized
INFO - 2021-07-08 12:42:38 --> Security Class Initialized
DEBUG - 2021-07-08 12:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:42:38 --> Input Class Initialized
INFO - 2021-07-08 12:42:38 --> Language Class Initialized
INFO - 2021-07-08 12:42:38 --> Loader Class Initialized
INFO - 2021-07-08 12:42:38 --> Helper loaded: html_helper
INFO - 2021-07-08 12:42:38 --> Helper loaded: url_helper
INFO - 2021-07-08 12:42:38 --> Helper loaded: form_helper
INFO - 2021-07-08 12:42:38 --> Database Driver Class Initialized
INFO - 2021-07-08 12:42:38 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:42:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:42:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:42:38 --> Encryption Class Initialized
INFO - 2021-07-08 12:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:42:38 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:42:38 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:42:38 --> Model "user_model" initialized
INFO - 2021-07-08 12:42:38 --> Model "role_model" initialized
INFO - 2021-07-08 12:42:38 --> Controller Class Initialized
INFO - 2021-07-08 12:42:38 --> Helper loaded: language_helper
INFO - 2021-07-08 12:42:38 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:42:38 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:42:38 --> Model "Product_model" initialized
INFO - 2021-07-08 12:42:38 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:42:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:42:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:42:38 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 12:42:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 12:42:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:42:38 --> Final output sent to browser
DEBUG - 2021-07-08 12:42:38 --> Total execution time: 0.0745
INFO - 2021-07-08 12:48:13 --> Config Class Initialized
INFO - 2021-07-08 12:48:13 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:48:13 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:48:13 --> Utf8 Class Initialized
INFO - 2021-07-08 12:48:13 --> URI Class Initialized
INFO - 2021-07-08 12:48:13 --> Router Class Initialized
INFO - 2021-07-08 12:48:13 --> Output Class Initialized
INFO - 2021-07-08 12:48:13 --> Security Class Initialized
DEBUG - 2021-07-08 12:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:48:13 --> Input Class Initialized
INFO - 2021-07-08 12:48:13 --> Language Class Initialized
INFO - 2021-07-08 12:48:13 --> Loader Class Initialized
INFO - 2021-07-08 12:48:13 --> Helper loaded: html_helper
INFO - 2021-07-08 12:48:13 --> Helper loaded: url_helper
INFO - 2021-07-08 12:48:13 --> Helper loaded: form_helper
INFO - 2021-07-08 12:48:13 --> Database Driver Class Initialized
INFO - 2021-07-08 12:48:13 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:48:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:48:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:48:13 --> Encryption Class Initialized
INFO - 2021-07-08 12:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:48:13 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:48:13 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:48:13 --> Model "user_model" initialized
INFO - 2021-07-08 12:48:13 --> Model "role_model" initialized
INFO - 2021-07-08 12:48:13 --> Controller Class Initialized
INFO - 2021-07-08 12:48:13 --> Helper loaded: language_helper
INFO - 2021-07-08 12:48:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:48:13 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:48:13 --> Final output sent to browser
DEBUG - 2021-07-08 12:48:13 --> Total execution time: 0.0681
INFO - 2021-07-08 12:48:13 --> Config Class Initialized
INFO - 2021-07-08 12:48:13 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:48:13 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:48:13 --> Utf8 Class Initialized
INFO - 2021-07-08 12:48:13 --> URI Class Initialized
INFO - 2021-07-08 12:48:13 --> Router Class Initialized
INFO - 2021-07-08 12:48:13 --> Output Class Initialized
INFO - 2021-07-08 12:48:13 --> Security Class Initialized
DEBUG - 2021-07-08 12:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:48:13 --> Input Class Initialized
INFO - 2021-07-08 12:48:13 --> Language Class Initialized
INFO - 2021-07-08 12:48:13 --> Loader Class Initialized
INFO - 2021-07-08 12:48:13 --> Helper loaded: html_helper
INFO - 2021-07-08 12:48:13 --> Helper loaded: url_helper
INFO - 2021-07-08 12:48:13 --> Helper loaded: form_helper
INFO - 2021-07-08 12:48:13 --> Database Driver Class Initialized
INFO - 2021-07-08 12:48:13 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:48:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:48:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:48:13 --> Encryption Class Initialized
INFO - 2021-07-08 12:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:48:13 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:48:13 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:48:13 --> Model "user_model" initialized
INFO - 2021-07-08 12:48:13 --> Model "role_model" initialized
INFO - 2021-07-08 12:48:13 --> Controller Class Initialized
INFO - 2021-07-08 12:48:13 --> Helper loaded: language_helper
INFO - 2021-07-08 12:48:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:48:13 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:48:13 --> Final output sent to browser
DEBUG - 2021-07-08 12:48:13 --> Total execution time: 0.0644
INFO - 2021-07-08 12:51:42 --> Config Class Initialized
INFO - 2021-07-08 12:51:42 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:51:42 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:51:42 --> Utf8 Class Initialized
INFO - 2021-07-08 12:51:42 --> URI Class Initialized
INFO - 2021-07-08 12:51:42 --> Router Class Initialized
INFO - 2021-07-08 12:51:42 --> Output Class Initialized
INFO - 2021-07-08 12:51:42 --> Security Class Initialized
DEBUG - 2021-07-08 12:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:51:42 --> Input Class Initialized
INFO - 2021-07-08 12:51:42 --> Language Class Initialized
INFO - 2021-07-08 12:51:42 --> Loader Class Initialized
INFO - 2021-07-08 12:51:42 --> Helper loaded: html_helper
INFO - 2021-07-08 12:51:42 --> Helper loaded: url_helper
INFO - 2021-07-08 12:51:42 --> Helper loaded: form_helper
INFO - 2021-07-08 12:51:42 --> Database Driver Class Initialized
INFO - 2021-07-08 12:51:42 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:51:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:51:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:51:42 --> Encryption Class Initialized
INFO - 2021-07-08 12:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:51:42 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:51:42 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:51:42 --> Model "user_model" initialized
INFO - 2021-07-08 12:51:42 --> Model "role_model" initialized
INFO - 2021-07-08 12:51:42 --> Controller Class Initialized
INFO - 2021-07-08 12:51:42 --> Helper loaded: language_helper
INFO - 2021-07-08 12:51:42 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:51:42 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:51:42 --> Model "Product_model" initialized
INFO - 2021-07-08 12:51:42 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:51:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:51:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:51:42 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 12:51:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 12:51:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:51:42 --> Final output sent to browser
DEBUG - 2021-07-08 12:51:42 --> Total execution time: 0.1227
INFO - 2021-07-08 12:51:51 --> Config Class Initialized
INFO - 2021-07-08 12:51:51 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:51:51 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:51:51 --> Utf8 Class Initialized
INFO - 2021-07-08 12:51:51 --> URI Class Initialized
INFO - 2021-07-08 12:51:51 --> Router Class Initialized
INFO - 2021-07-08 12:51:51 --> Output Class Initialized
INFO - 2021-07-08 12:51:51 --> Security Class Initialized
DEBUG - 2021-07-08 12:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:51:51 --> Input Class Initialized
INFO - 2021-07-08 12:51:51 --> Language Class Initialized
INFO - 2021-07-08 12:51:51 --> Loader Class Initialized
INFO - 2021-07-08 12:51:51 --> Helper loaded: html_helper
INFO - 2021-07-08 12:51:51 --> Helper loaded: url_helper
INFO - 2021-07-08 12:51:51 --> Helper loaded: form_helper
INFO - 2021-07-08 12:51:51 --> Database Driver Class Initialized
INFO - 2021-07-08 12:51:51 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:51:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:51:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:51:51 --> Encryption Class Initialized
INFO - 2021-07-08 12:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:51:51 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:51:51 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:51:51 --> Model "user_model" initialized
INFO - 2021-07-08 12:51:51 --> Model "role_model" initialized
INFO - 2021-07-08 12:51:51 --> Controller Class Initialized
INFO - 2021-07-08 12:51:51 --> Helper loaded: language_helper
INFO - 2021-07-08 12:51:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:51:51 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:51:51 --> Final output sent to browser
DEBUG - 2021-07-08 12:51:51 --> Total execution time: 0.0576
INFO - 2021-07-08 12:51:51 --> Config Class Initialized
INFO - 2021-07-08 12:51:51 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:51:51 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:51:51 --> Utf8 Class Initialized
INFO - 2021-07-08 12:51:51 --> URI Class Initialized
INFO - 2021-07-08 12:51:51 --> Router Class Initialized
INFO - 2021-07-08 12:51:51 --> Output Class Initialized
INFO - 2021-07-08 12:51:51 --> Security Class Initialized
DEBUG - 2021-07-08 12:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:51:51 --> Input Class Initialized
INFO - 2021-07-08 12:51:51 --> Language Class Initialized
INFO - 2021-07-08 12:51:51 --> Loader Class Initialized
INFO - 2021-07-08 12:51:51 --> Helper loaded: html_helper
INFO - 2021-07-08 12:51:51 --> Helper loaded: url_helper
INFO - 2021-07-08 12:51:51 --> Helper loaded: form_helper
INFO - 2021-07-08 12:51:51 --> Database Driver Class Initialized
INFO - 2021-07-08 12:51:51 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:51:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:51:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:51:51 --> Encryption Class Initialized
INFO - 2021-07-08 12:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:51:51 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:51:51 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:51:51 --> Model "user_model" initialized
INFO - 2021-07-08 12:51:51 --> Model "role_model" initialized
INFO - 2021-07-08 12:51:51 --> Controller Class Initialized
INFO - 2021-07-08 12:51:51 --> Helper loaded: language_helper
INFO - 2021-07-08 12:51:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:51:51 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:51:51 --> Final output sent to browser
DEBUG - 2021-07-08 12:51:51 --> Total execution time: 0.0615
INFO - 2021-07-08 12:52:34 --> Config Class Initialized
INFO - 2021-07-08 12:52:34 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:52:34 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:52:34 --> Utf8 Class Initialized
INFO - 2021-07-08 12:52:34 --> URI Class Initialized
INFO - 2021-07-08 12:52:34 --> Router Class Initialized
INFO - 2021-07-08 12:52:34 --> Output Class Initialized
INFO - 2021-07-08 12:52:34 --> Security Class Initialized
DEBUG - 2021-07-08 12:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:52:34 --> Input Class Initialized
INFO - 2021-07-08 12:52:34 --> Language Class Initialized
INFO - 2021-07-08 12:52:34 --> Loader Class Initialized
INFO - 2021-07-08 12:52:34 --> Helper loaded: html_helper
INFO - 2021-07-08 12:52:34 --> Helper loaded: url_helper
INFO - 2021-07-08 12:52:34 --> Helper loaded: form_helper
INFO - 2021-07-08 12:52:34 --> Database Driver Class Initialized
INFO - 2021-07-08 12:52:34 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:52:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:52:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:52:34 --> Encryption Class Initialized
INFO - 2021-07-08 12:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:52:34 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:52:34 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:52:34 --> Model "user_model" initialized
INFO - 2021-07-08 12:52:34 --> Model "role_model" initialized
INFO - 2021-07-08 12:52:34 --> Controller Class Initialized
INFO - 2021-07-08 12:52:34 --> Helper loaded: language_helper
INFO - 2021-07-08 12:52:34 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:52:34 --> Model "Product_model" initialized
INFO - 2021-07-08 12:52:34 --> Final output sent to browser
DEBUG - 2021-07-08 12:52:34 --> Total execution time: 0.0662
INFO - 2021-07-08 12:54:19 --> Config Class Initialized
INFO - 2021-07-08 12:54:19 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:54:19 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:54:19 --> Utf8 Class Initialized
INFO - 2021-07-08 12:54:19 --> URI Class Initialized
INFO - 2021-07-08 12:54:19 --> Router Class Initialized
INFO - 2021-07-08 12:54:19 --> Output Class Initialized
INFO - 2021-07-08 12:54:19 --> Security Class Initialized
DEBUG - 2021-07-08 12:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:54:19 --> Input Class Initialized
INFO - 2021-07-08 12:54:19 --> Language Class Initialized
INFO - 2021-07-08 12:54:19 --> Loader Class Initialized
INFO - 2021-07-08 12:54:19 --> Helper loaded: html_helper
INFO - 2021-07-08 12:54:19 --> Helper loaded: url_helper
INFO - 2021-07-08 12:54:19 --> Helper loaded: form_helper
INFO - 2021-07-08 12:54:19 --> Database Driver Class Initialized
INFO - 2021-07-08 12:54:19 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:54:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:54:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:54:19 --> Encryption Class Initialized
INFO - 2021-07-08 12:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:54:19 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:54:19 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:54:19 --> Model "user_model" initialized
INFO - 2021-07-08 12:54:19 --> Model "role_model" initialized
INFO - 2021-07-08 12:54:19 --> Controller Class Initialized
INFO - 2021-07-08 12:54:19 --> Helper loaded: language_helper
INFO - 2021-07-08 12:54:19 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:54:19 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:54:19 --> Model "Product_model" initialized
INFO - 2021-07-08 12:54:19 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:54:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:54:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:54:19 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 12:54:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 12:54:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:54:19 --> Final output sent to browser
DEBUG - 2021-07-08 12:54:19 --> Total execution time: 0.0797
INFO - 2021-07-08 12:54:30 --> Config Class Initialized
INFO - 2021-07-08 12:54:30 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:54:30 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:54:30 --> Utf8 Class Initialized
INFO - 2021-07-08 12:54:30 --> URI Class Initialized
INFO - 2021-07-08 12:54:30 --> Router Class Initialized
INFO - 2021-07-08 12:54:30 --> Output Class Initialized
INFO - 2021-07-08 12:54:30 --> Security Class Initialized
DEBUG - 2021-07-08 12:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:54:30 --> Input Class Initialized
INFO - 2021-07-08 12:54:30 --> Language Class Initialized
INFO - 2021-07-08 12:54:30 --> Loader Class Initialized
INFO - 2021-07-08 12:54:30 --> Helper loaded: html_helper
INFO - 2021-07-08 12:54:30 --> Helper loaded: url_helper
INFO - 2021-07-08 12:54:30 --> Helper loaded: form_helper
INFO - 2021-07-08 12:54:30 --> Database Driver Class Initialized
INFO - 2021-07-08 12:54:30 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:54:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:54:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:54:30 --> Encryption Class Initialized
INFO - 2021-07-08 12:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:54:30 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:54:30 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:54:30 --> Model "user_model" initialized
INFO - 2021-07-08 12:54:30 --> Model "role_model" initialized
INFO - 2021-07-08 12:54:30 --> Controller Class Initialized
INFO - 2021-07-08 12:54:30 --> Helper loaded: language_helper
INFO - 2021-07-08 12:54:30 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:54:30 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:54:30 --> Model "Product_model" initialized
INFO - 2021-07-08 12:54:30 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:54:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:54:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:54:30 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 12:54:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 12:54:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:54:30 --> Final output sent to browser
DEBUG - 2021-07-08 12:54:30 --> Total execution time: 0.0757
INFO - 2021-07-08 12:54:55 --> Config Class Initialized
INFO - 2021-07-08 12:54:55 --> Hooks Class Initialized
DEBUG - 2021-07-08 12:54:55 --> UTF-8 Support Enabled
INFO - 2021-07-08 12:54:55 --> Utf8 Class Initialized
INFO - 2021-07-08 12:54:55 --> URI Class Initialized
INFO - 2021-07-08 12:54:55 --> Router Class Initialized
INFO - 2021-07-08 12:54:55 --> Output Class Initialized
INFO - 2021-07-08 12:54:55 --> Security Class Initialized
DEBUG - 2021-07-08 12:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 12:54:55 --> Input Class Initialized
INFO - 2021-07-08 12:54:55 --> Language Class Initialized
INFO - 2021-07-08 12:54:55 --> Loader Class Initialized
INFO - 2021-07-08 12:54:55 --> Helper loaded: html_helper
INFO - 2021-07-08 12:54:55 --> Helper loaded: url_helper
INFO - 2021-07-08 12:54:55 --> Helper loaded: form_helper
INFO - 2021-07-08 12:54:55 --> Database Driver Class Initialized
INFO - 2021-07-08 12:54:55 --> Form Validation Class Initialized
DEBUG - 2021-07-08 12:54:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 12:54:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 12:54:55 --> Encryption Class Initialized
INFO - 2021-07-08 12:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 12:54:55 --> Model "vendor_model" initialized
INFO - 2021-07-08 12:54:55 --> Model "coupon_model" initialized
INFO - 2021-07-08 12:54:55 --> Model "user_model" initialized
INFO - 2021-07-08 12:54:55 --> Model "role_model" initialized
INFO - 2021-07-08 12:54:55 --> Controller Class Initialized
INFO - 2021-07-08 12:54:55 --> Helper loaded: language_helper
INFO - 2021-07-08 12:54:55 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 12:54:55 --> Model "Customer_model" initialized
INFO - 2021-07-08 12:54:55 --> Model "Product_model" initialized
INFO - 2021-07-08 12:54:55 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 12:54:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 12:54:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 12:54:55 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 12:54:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 12:54:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 12:54:55 --> Final output sent to browser
DEBUG - 2021-07-08 12:54:55 --> Total execution time: 0.0807
INFO - 2021-07-08 13:00:12 --> Config Class Initialized
INFO - 2021-07-08 13:00:12 --> Hooks Class Initialized
DEBUG - 2021-07-08 13:00:12 --> UTF-8 Support Enabled
INFO - 2021-07-08 13:00:12 --> Utf8 Class Initialized
INFO - 2021-07-08 13:00:12 --> URI Class Initialized
INFO - 2021-07-08 13:00:12 --> Router Class Initialized
INFO - 2021-07-08 13:00:12 --> Output Class Initialized
INFO - 2021-07-08 13:00:12 --> Security Class Initialized
DEBUG - 2021-07-08 13:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 13:00:12 --> Input Class Initialized
INFO - 2021-07-08 13:00:12 --> Language Class Initialized
INFO - 2021-07-08 13:00:12 --> Loader Class Initialized
INFO - 2021-07-08 13:00:12 --> Helper loaded: html_helper
INFO - 2021-07-08 13:00:12 --> Helper loaded: url_helper
INFO - 2021-07-08 13:00:12 --> Helper loaded: form_helper
INFO - 2021-07-08 13:00:12 --> Database Driver Class Initialized
INFO - 2021-07-08 13:00:12 --> Form Validation Class Initialized
DEBUG - 2021-07-08 13:00:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 13:00:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 13:00:12 --> Encryption Class Initialized
INFO - 2021-07-08 13:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 13:00:12 --> Model "vendor_model" initialized
INFO - 2021-07-08 13:00:12 --> Model "coupon_model" initialized
INFO - 2021-07-08 13:00:12 --> Model "user_model" initialized
INFO - 2021-07-08 13:00:12 --> Model "role_model" initialized
INFO - 2021-07-08 13:00:12 --> Controller Class Initialized
INFO - 2021-07-08 13:00:12 --> Helper loaded: language_helper
INFO - 2021-07-08 13:00:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 13:00:12 --> Model "Product_model" initialized
INFO - 2021-07-08 13:00:12 --> Final output sent to browser
DEBUG - 2021-07-08 13:00:12 --> Total execution time: 0.0615
INFO - 2021-07-08 13:05:27 --> Config Class Initialized
INFO - 2021-07-08 13:05:27 --> Hooks Class Initialized
DEBUG - 2021-07-08 13:05:27 --> UTF-8 Support Enabled
INFO - 2021-07-08 13:05:27 --> Utf8 Class Initialized
INFO - 2021-07-08 13:05:27 --> URI Class Initialized
INFO - 2021-07-08 13:05:27 --> Router Class Initialized
INFO - 2021-07-08 13:05:27 --> Output Class Initialized
INFO - 2021-07-08 13:05:27 --> Security Class Initialized
DEBUG - 2021-07-08 13:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 13:05:27 --> Input Class Initialized
INFO - 2021-07-08 13:05:27 --> Language Class Initialized
INFO - 2021-07-08 13:05:27 --> Loader Class Initialized
INFO - 2021-07-08 13:05:27 --> Helper loaded: html_helper
INFO - 2021-07-08 13:05:27 --> Helper loaded: url_helper
INFO - 2021-07-08 13:05:27 --> Helper loaded: form_helper
INFO - 2021-07-08 13:05:27 --> Database Driver Class Initialized
INFO - 2021-07-08 13:05:27 --> Form Validation Class Initialized
DEBUG - 2021-07-08 13:05:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 13:05:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 13:05:27 --> Encryption Class Initialized
INFO - 2021-07-08 13:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 13:05:27 --> Model "vendor_model" initialized
INFO - 2021-07-08 13:05:27 --> Model "coupon_model" initialized
INFO - 2021-07-08 13:05:27 --> Model "user_model" initialized
INFO - 2021-07-08 13:05:27 --> Model "role_model" initialized
INFO - 2021-07-08 13:05:27 --> Controller Class Initialized
INFO - 2021-07-08 13:05:27 --> Helper loaded: language_helper
INFO - 2021-07-08 13:05:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 13:05:27 --> Model "Customer_model" initialized
INFO - 2021-07-08 13:05:27 --> Model "Product_model" initialized
INFO - 2021-07-08 13:05:27 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 13:05:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 13:05:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 13:05:27 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 13:05:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 13:05:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 13:05:27 --> Final output sent to browser
DEBUG - 2021-07-08 13:05:27 --> Total execution time: 0.0788
INFO - 2021-07-08 13:05:56 --> Config Class Initialized
INFO - 2021-07-08 13:05:56 --> Hooks Class Initialized
DEBUG - 2021-07-08 13:05:56 --> UTF-8 Support Enabled
INFO - 2021-07-08 13:05:56 --> Utf8 Class Initialized
INFO - 2021-07-08 13:05:56 --> URI Class Initialized
INFO - 2021-07-08 13:05:56 --> Router Class Initialized
INFO - 2021-07-08 13:05:56 --> Output Class Initialized
INFO - 2021-07-08 13:05:56 --> Security Class Initialized
DEBUG - 2021-07-08 13:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 13:05:56 --> Input Class Initialized
INFO - 2021-07-08 13:05:56 --> Language Class Initialized
INFO - 2021-07-08 13:05:56 --> Loader Class Initialized
INFO - 2021-07-08 13:05:56 --> Helper loaded: html_helper
INFO - 2021-07-08 13:05:56 --> Helper loaded: url_helper
INFO - 2021-07-08 13:05:56 --> Helper loaded: form_helper
INFO - 2021-07-08 13:05:56 --> Database Driver Class Initialized
INFO - 2021-07-08 13:05:56 --> Form Validation Class Initialized
DEBUG - 2021-07-08 13:05:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 13:05:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 13:05:56 --> Encryption Class Initialized
INFO - 2021-07-08 13:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 13:05:56 --> Model "vendor_model" initialized
INFO - 2021-07-08 13:05:56 --> Model "coupon_model" initialized
INFO - 2021-07-08 13:05:56 --> Model "user_model" initialized
INFO - 2021-07-08 13:05:56 --> Model "role_model" initialized
INFO - 2021-07-08 13:05:56 --> Controller Class Initialized
INFO - 2021-07-08 13:05:56 --> Helper loaded: language_helper
INFO - 2021-07-08 13:05:56 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 13:05:56 --> Model "Product_model" initialized
INFO - 2021-07-08 13:05:56 --> Final output sent to browser
DEBUG - 2021-07-08 13:05:56 --> Total execution time: 0.0606
INFO - 2021-07-08 13:30:59 --> Config Class Initialized
INFO - 2021-07-08 13:30:59 --> Hooks Class Initialized
DEBUG - 2021-07-08 13:30:59 --> UTF-8 Support Enabled
INFO - 2021-07-08 13:30:59 --> Utf8 Class Initialized
INFO - 2021-07-08 13:30:59 --> URI Class Initialized
INFO - 2021-07-08 13:30:59 --> Router Class Initialized
INFO - 2021-07-08 13:30:59 --> Output Class Initialized
INFO - 2021-07-08 13:30:59 --> Security Class Initialized
DEBUG - 2021-07-08 13:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 13:30:59 --> Input Class Initialized
INFO - 2021-07-08 13:30:59 --> Language Class Initialized
INFO - 2021-07-08 13:30:59 --> Loader Class Initialized
INFO - 2021-07-08 13:30:59 --> Helper loaded: html_helper
INFO - 2021-07-08 13:30:59 --> Helper loaded: url_helper
INFO - 2021-07-08 13:30:59 --> Helper loaded: form_helper
INFO - 2021-07-08 13:30:59 --> Database Driver Class Initialized
INFO - 2021-07-08 13:30:59 --> Form Validation Class Initialized
DEBUG - 2021-07-08 13:30:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 13:30:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 13:30:59 --> Encryption Class Initialized
INFO - 2021-07-08 13:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 13:30:59 --> Model "vendor_model" initialized
INFO - 2021-07-08 13:30:59 --> Model "coupon_model" initialized
INFO - 2021-07-08 13:30:59 --> Model "user_model" initialized
INFO - 2021-07-08 13:30:59 --> Model "role_model" initialized
INFO - 2021-07-08 13:30:59 --> Controller Class Initialized
INFO - 2021-07-08 13:30:59 --> Helper loaded: language_helper
INFO - 2021-07-08 13:30:59 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 13:30:59 --> Model "Customer_model" initialized
INFO - 2021-07-08 13:30:59 --> Model "Product_model" initialized
INFO - 2021-07-08 13:30:59 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 13:30:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 13:30:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 13:30:59 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 13:30:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 13:30:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 13:30:59 --> Final output sent to browser
DEBUG - 2021-07-08 13:30:59 --> Total execution time: 0.0791
INFO - 2021-07-08 13:31:08 --> Config Class Initialized
INFO - 2021-07-08 13:31:08 --> Hooks Class Initialized
DEBUG - 2021-07-08 13:31:08 --> UTF-8 Support Enabled
INFO - 2021-07-08 13:31:08 --> Utf8 Class Initialized
INFO - 2021-07-08 13:31:08 --> URI Class Initialized
INFO - 2021-07-08 13:31:08 --> Router Class Initialized
INFO - 2021-07-08 13:31:08 --> Output Class Initialized
INFO - 2021-07-08 13:31:08 --> Security Class Initialized
DEBUG - 2021-07-08 13:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 13:31:08 --> Input Class Initialized
INFO - 2021-07-08 13:31:08 --> Language Class Initialized
INFO - 2021-07-08 13:31:08 --> Loader Class Initialized
INFO - 2021-07-08 13:31:08 --> Helper loaded: html_helper
INFO - 2021-07-08 13:31:08 --> Helper loaded: url_helper
INFO - 2021-07-08 13:31:08 --> Helper loaded: form_helper
INFO - 2021-07-08 13:31:08 --> Database Driver Class Initialized
INFO - 2021-07-08 13:31:08 --> Form Validation Class Initialized
DEBUG - 2021-07-08 13:31:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 13:31:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 13:31:08 --> Encryption Class Initialized
INFO - 2021-07-08 13:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 13:31:08 --> Model "vendor_model" initialized
INFO - 2021-07-08 13:31:08 --> Model "coupon_model" initialized
INFO - 2021-07-08 13:31:08 --> Model "user_model" initialized
INFO - 2021-07-08 13:31:08 --> Model "role_model" initialized
INFO - 2021-07-08 13:31:08 --> Controller Class Initialized
INFO - 2021-07-08 13:31:08 --> Helper loaded: language_helper
INFO - 2021-07-08 13:31:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 13:31:08 --> Model "Quotation_model" initialized
INFO - 2021-07-08 13:31:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 13:31:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 13:31:08 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-08 13:31:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-08 13:31:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 13:31:08 --> Final output sent to browser
DEBUG - 2021-07-08 13:31:08 --> Total execution time: 0.0866
INFO - 2021-07-08 13:31:11 --> Config Class Initialized
INFO - 2021-07-08 13:31:11 --> Hooks Class Initialized
INFO - 2021-07-08 13:31:11 --> Config Class Initialized
INFO - 2021-07-08 13:31:11 --> Hooks Class Initialized
DEBUG - 2021-07-08 13:31:11 --> UTF-8 Support Enabled
INFO - 2021-07-08 13:31:11 --> Utf8 Class Initialized
DEBUG - 2021-07-08 13:31:11 --> UTF-8 Support Enabled
INFO - 2021-07-08 13:31:11 --> Utf8 Class Initialized
INFO - 2021-07-08 13:31:11 --> URI Class Initialized
INFO - 2021-07-08 13:31:11 --> URI Class Initialized
INFO - 2021-07-08 13:31:11 --> Router Class Initialized
INFO - 2021-07-08 13:31:11 --> Router Class Initialized
INFO - 2021-07-08 13:31:11 --> Output Class Initialized
INFO - 2021-07-08 13:31:11 --> Output Class Initialized
INFO - 2021-07-08 13:31:11 --> Security Class Initialized
INFO - 2021-07-08 13:31:11 --> Security Class Initialized
DEBUG - 2021-07-08 13:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-08 13:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 13:31:11 --> Input Class Initialized
INFO - 2021-07-08 13:31:11 --> Input Class Initialized
INFO - 2021-07-08 13:31:11 --> Language Class Initialized
INFO - 2021-07-08 13:31:11 --> Language Class Initialized
INFO - 2021-07-08 13:31:11 --> Loader Class Initialized
INFO - 2021-07-08 13:31:11 --> Loader Class Initialized
INFO - 2021-07-08 13:31:11 --> Helper loaded: html_helper
INFO - 2021-07-08 13:31:11 --> Helper loaded: html_helper
INFO - 2021-07-08 13:31:11 --> Helper loaded: url_helper
INFO - 2021-07-08 13:31:11 --> Helper loaded: url_helper
INFO - 2021-07-08 13:31:11 --> Helper loaded: form_helper
INFO - 2021-07-08 13:31:11 --> Helper loaded: form_helper
INFO - 2021-07-08 13:31:11 --> Database Driver Class Initialized
INFO - 2021-07-08 13:31:11 --> Database Driver Class Initialized
INFO - 2021-07-08 13:31:11 --> Form Validation Class Initialized
DEBUG - 2021-07-08 13:31:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 13:31:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 13:31:11 --> Encryption Class Initialized
INFO - 2021-07-08 13:31:11 --> Form Validation Class Initialized
DEBUG - 2021-07-08 13:31:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 13:31:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 13:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 13:31:11 --> Encryption Class Initialized
INFO - 2021-07-08 13:31:11 --> Model "vendor_model" initialized
INFO - 2021-07-08 13:31:11 --> Model "coupon_model" initialized
INFO - 2021-07-08 13:31:11 --> Model "user_model" initialized
INFO - 2021-07-08 13:31:11 --> Model "role_model" initialized
INFO - 2021-07-08 13:31:11 --> Controller Class Initialized
INFO - 2021-07-08 13:31:11 --> Helper loaded: language_helper
INFO - 2021-07-08 13:31:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 13:31:11 --> Model "Quotation_model" initialized
INFO - 2021-07-08 13:31:11 --> Final output sent to browser
DEBUG - 2021-07-08 13:31:11 --> Total execution time: 0.0754
INFO - 2021-07-08 13:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 13:31:11 --> Model "vendor_model" initialized
INFO - 2021-07-08 13:31:11 --> Model "coupon_model" initialized
INFO - 2021-07-08 13:31:11 --> Model "user_model" initialized
INFO - 2021-07-08 13:31:11 --> Model "role_model" initialized
INFO - 2021-07-08 13:31:11 --> Controller Class Initialized
INFO - 2021-07-08 13:31:11 --> Helper loaded: language_helper
INFO - 2021-07-08 13:31:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 13:31:11 --> Model "Quotation_model" initialized
INFO - 2021-07-08 13:31:11 --> Final output sent to browser
DEBUG - 2021-07-08 13:31:11 --> Total execution time: 0.0844
INFO - 2021-07-08 13:31:27 --> Config Class Initialized
INFO - 2021-07-08 13:31:27 --> Config Class Initialized
INFO - 2021-07-08 13:31:27 --> Hooks Class Initialized
INFO - 2021-07-08 13:31:27 --> Hooks Class Initialized
DEBUG - 2021-07-08 13:31:27 --> UTF-8 Support Enabled
DEBUG - 2021-07-08 13:31:27 --> UTF-8 Support Enabled
INFO - 2021-07-08 13:31:27 --> Utf8 Class Initialized
INFO - 2021-07-08 13:31:27 --> Utf8 Class Initialized
INFO - 2021-07-08 13:31:27 --> URI Class Initialized
INFO - 2021-07-08 13:31:27 --> URI Class Initialized
INFO - 2021-07-08 13:31:27 --> Router Class Initialized
INFO - 2021-07-08 13:31:27 --> Router Class Initialized
INFO - 2021-07-08 13:31:27 --> Output Class Initialized
INFO - 2021-07-08 13:31:27 --> Output Class Initialized
INFO - 2021-07-08 13:31:27 --> Security Class Initialized
INFO - 2021-07-08 13:31:27 --> Security Class Initialized
DEBUG - 2021-07-08 13:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-08 13:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 13:31:27 --> Input Class Initialized
INFO - 2021-07-08 13:31:27 --> Input Class Initialized
INFO - 2021-07-08 13:31:27 --> Language Class Initialized
INFO - 2021-07-08 13:31:27 --> Language Class Initialized
INFO - 2021-07-08 13:31:27 --> Loader Class Initialized
INFO - 2021-07-08 13:31:27 --> Loader Class Initialized
INFO - 2021-07-08 13:31:27 --> Helper loaded: html_helper
INFO - 2021-07-08 13:31:27 --> Helper loaded: html_helper
INFO - 2021-07-08 13:31:27 --> Helper loaded: url_helper
INFO - 2021-07-08 13:31:27 --> Helper loaded: url_helper
INFO - 2021-07-08 13:31:27 --> Helper loaded: form_helper
INFO - 2021-07-08 13:31:27 --> Helper loaded: form_helper
INFO - 2021-07-08 13:31:27 --> Database Driver Class Initialized
INFO - 2021-07-08 13:31:27 --> Database Driver Class Initialized
INFO - 2021-07-08 13:31:27 --> Form Validation Class Initialized
INFO - 2021-07-08 13:31:27 --> Form Validation Class Initialized
DEBUG - 2021-07-08 13:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-08 13:31:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 13:31:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 13:31:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 13:31:27 --> Encryption Class Initialized
INFO - 2021-07-08 13:31:27 --> Encryption Class Initialized
INFO - 2021-07-08 13:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 13:31:27 --> Model "vendor_model" initialized
INFO - 2021-07-08 13:31:27 --> Model "coupon_model" initialized
INFO - 2021-07-08 13:31:27 --> Model "user_model" initialized
INFO - 2021-07-08 13:31:27 --> Model "role_model" initialized
INFO - 2021-07-08 13:31:27 --> Controller Class Initialized
INFO - 2021-07-08 13:31:27 --> Helper loaded: language_helper
INFO - 2021-07-08 13:31:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 13:31:27 --> Model "Quotation_model" initialized
INFO - 2021-07-08 13:31:27 --> Final output sent to browser
DEBUG - 2021-07-08 13:31:27 --> Total execution time: 0.0677
INFO - 2021-07-08 13:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 13:31:27 --> Model "vendor_model" initialized
INFO - 2021-07-08 13:31:27 --> Model "coupon_model" initialized
INFO - 2021-07-08 13:31:27 --> Model "user_model" initialized
INFO - 2021-07-08 13:31:27 --> Model "role_model" initialized
INFO - 2021-07-08 13:31:27 --> Controller Class Initialized
INFO - 2021-07-08 13:31:27 --> Helper loaded: language_helper
INFO - 2021-07-08 13:31:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 13:31:27 --> Model "Quotation_model" initialized
INFO - 2021-07-08 13:31:27 --> Final output sent to browser
DEBUG - 2021-07-08 13:31:27 --> Total execution time: 0.0778
INFO - 2021-07-08 13:31:30 --> Config Class Initialized
INFO - 2021-07-08 13:31:30 --> Config Class Initialized
INFO - 2021-07-08 13:31:30 --> Hooks Class Initialized
INFO - 2021-07-08 13:31:30 --> Hooks Class Initialized
DEBUG - 2021-07-08 13:31:30 --> UTF-8 Support Enabled
DEBUG - 2021-07-08 13:31:30 --> UTF-8 Support Enabled
INFO - 2021-07-08 13:31:30 --> Utf8 Class Initialized
INFO - 2021-07-08 13:31:30 --> Utf8 Class Initialized
INFO - 2021-07-08 13:31:30 --> URI Class Initialized
INFO - 2021-07-08 13:31:30 --> URI Class Initialized
INFO - 2021-07-08 13:31:30 --> Router Class Initialized
INFO - 2021-07-08 13:31:30 --> Router Class Initialized
INFO - 2021-07-08 13:31:30 --> Output Class Initialized
INFO - 2021-07-08 13:31:30 --> Output Class Initialized
INFO - 2021-07-08 13:31:30 --> Security Class Initialized
INFO - 2021-07-08 13:31:30 --> Security Class Initialized
DEBUG - 2021-07-08 13:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-08 13:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 13:31:30 --> Input Class Initialized
INFO - 2021-07-08 13:31:30 --> Input Class Initialized
INFO - 2021-07-08 13:31:30 --> Language Class Initialized
INFO - 2021-07-08 13:31:30 --> Language Class Initialized
INFO - 2021-07-08 13:31:30 --> Loader Class Initialized
INFO - 2021-07-08 13:31:30 --> Loader Class Initialized
INFO - 2021-07-08 13:31:30 --> Helper loaded: html_helper
INFO - 2021-07-08 13:31:30 --> Helper loaded: html_helper
INFO - 2021-07-08 13:31:30 --> Helper loaded: url_helper
INFO - 2021-07-08 13:31:30 --> Helper loaded: url_helper
INFO - 2021-07-08 13:31:30 --> Helper loaded: form_helper
INFO - 2021-07-08 13:31:30 --> Helper loaded: form_helper
INFO - 2021-07-08 13:31:30 --> Database Driver Class Initialized
INFO - 2021-07-08 13:31:30 --> Database Driver Class Initialized
INFO - 2021-07-08 13:31:30 --> Form Validation Class Initialized
INFO - 2021-07-08 13:31:30 --> Form Validation Class Initialized
DEBUG - 2021-07-08 13:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-08 13:31:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 13:31:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 13:31:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 13:31:30 --> Encryption Class Initialized
INFO - 2021-07-08 13:31:30 --> Encryption Class Initialized
INFO - 2021-07-08 13:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 13:31:30 --> Model "vendor_model" initialized
INFO - 2021-07-08 13:31:30 --> Model "coupon_model" initialized
INFO - 2021-07-08 13:31:30 --> Model "user_model" initialized
INFO - 2021-07-08 13:31:30 --> Model "role_model" initialized
INFO - 2021-07-08 13:31:30 --> Controller Class Initialized
INFO - 2021-07-08 13:31:30 --> Helper loaded: language_helper
INFO - 2021-07-08 13:31:30 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 13:31:30 --> Model "Quotation_model" initialized
INFO - 2021-07-08 13:31:30 --> Final output sent to browser
DEBUG - 2021-07-08 13:31:30 --> Total execution time: 0.0719
INFO - 2021-07-08 13:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 13:31:30 --> Model "vendor_model" initialized
INFO - 2021-07-08 13:31:30 --> Model "coupon_model" initialized
INFO - 2021-07-08 13:31:30 --> Model "user_model" initialized
INFO - 2021-07-08 13:31:30 --> Model "role_model" initialized
INFO - 2021-07-08 13:31:30 --> Controller Class Initialized
INFO - 2021-07-08 13:31:30 --> Helper loaded: language_helper
INFO - 2021-07-08 13:31:30 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 13:31:30 --> Model "Quotation_model" initialized
INFO - 2021-07-08 13:31:30 --> Final output sent to browser
DEBUG - 2021-07-08 13:31:30 --> Total execution time: 0.0819
INFO - 2021-07-08 13:32:11 --> Config Class Initialized
INFO - 2021-07-08 13:32:11 --> Hooks Class Initialized
DEBUG - 2021-07-08 13:32:11 --> UTF-8 Support Enabled
INFO - 2021-07-08 13:32:11 --> Utf8 Class Initialized
INFO - 2021-07-08 13:32:11 --> URI Class Initialized
INFO - 2021-07-08 13:32:11 --> Router Class Initialized
INFO - 2021-07-08 13:32:11 --> Output Class Initialized
INFO - 2021-07-08 13:32:11 --> Security Class Initialized
INFO - 2021-07-08 13:32:11 --> Config Class Initialized
INFO - 2021-07-08 13:32:11 --> Hooks Class Initialized
DEBUG - 2021-07-08 13:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 13:32:11 --> Input Class Initialized
INFO - 2021-07-08 13:32:11 --> Language Class Initialized
DEBUG - 2021-07-08 13:32:11 --> UTF-8 Support Enabled
INFO - 2021-07-08 13:32:11 --> Utf8 Class Initialized
INFO - 2021-07-08 13:32:11 --> Loader Class Initialized
INFO - 2021-07-08 13:32:11 --> URI Class Initialized
INFO - 2021-07-08 13:32:11 --> Helper loaded: html_helper
INFO - 2021-07-08 13:32:11 --> Router Class Initialized
INFO - 2021-07-08 13:32:11 --> Helper loaded: url_helper
INFO - 2021-07-08 13:32:11 --> Output Class Initialized
INFO - 2021-07-08 13:32:11 --> Helper loaded: form_helper
INFO - 2021-07-08 13:32:11 --> Security Class Initialized
DEBUG - 2021-07-08 13:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 13:32:11 --> Input Class Initialized
INFO - 2021-07-08 13:32:11 --> Language Class Initialized
INFO - 2021-07-08 13:32:11 --> Database Driver Class Initialized
INFO - 2021-07-08 13:32:11 --> Loader Class Initialized
INFO - 2021-07-08 13:32:11 --> Helper loaded: html_helper
INFO - 2021-07-08 13:32:11 --> Helper loaded: url_helper
INFO - 2021-07-08 13:32:11 --> Helper loaded: form_helper
INFO - 2021-07-08 13:32:11 --> Database Driver Class Initialized
INFO - 2021-07-08 13:32:11 --> Form Validation Class Initialized
DEBUG - 2021-07-08 13:32:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 13:32:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 13:32:11 --> Encryption Class Initialized
INFO - 2021-07-08 13:32:11 --> Form Validation Class Initialized
DEBUG - 2021-07-08 13:32:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 13:32:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 13:32:11 --> Encryption Class Initialized
INFO - 2021-07-08 13:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 13:32:11 --> Model "vendor_model" initialized
INFO - 2021-07-08 13:32:11 --> Model "coupon_model" initialized
INFO - 2021-07-08 13:32:11 --> Model "user_model" initialized
INFO - 2021-07-08 13:32:11 --> Model "role_model" initialized
INFO - 2021-07-08 13:32:11 --> Controller Class Initialized
INFO - 2021-07-08 13:32:11 --> Helper loaded: language_helper
INFO - 2021-07-08 13:32:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 13:32:11 --> Model "Quotation_model" initialized
INFO - 2021-07-08 13:32:11 --> Final output sent to browser
DEBUG - 2021-07-08 13:32:11 --> Total execution time: 0.0971
INFO - 2021-07-08 13:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 13:32:11 --> Model "vendor_model" initialized
INFO - 2021-07-08 13:32:11 --> Model "coupon_model" initialized
INFO - 2021-07-08 13:32:11 --> Model "user_model" initialized
INFO - 2021-07-08 13:32:11 --> Model "role_model" initialized
INFO - 2021-07-08 13:32:11 --> Controller Class Initialized
INFO - 2021-07-08 13:32:11 --> Helper loaded: language_helper
INFO - 2021-07-08 13:32:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 13:32:11 --> Model "Quotation_model" initialized
INFO - 2021-07-08 13:32:11 --> Final output sent to browser
DEBUG - 2021-07-08 13:32:11 --> Total execution time: 0.1192
INFO - 2021-07-08 13:32:14 --> Config Class Initialized
INFO - 2021-07-08 13:32:14 --> Hooks Class Initialized
INFO - 2021-07-08 13:32:14 --> Config Class Initialized
INFO - 2021-07-08 13:32:14 --> Hooks Class Initialized
DEBUG - 2021-07-08 13:32:14 --> UTF-8 Support Enabled
INFO - 2021-07-08 13:32:14 --> Utf8 Class Initialized
DEBUG - 2021-07-08 13:32:14 --> UTF-8 Support Enabled
INFO - 2021-07-08 13:32:14 --> Utf8 Class Initialized
INFO - 2021-07-08 13:32:14 --> URI Class Initialized
INFO - 2021-07-08 13:32:14 --> URI Class Initialized
INFO - 2021-07-08 13:32:14 --> Router Class Initialized
INFO - 2021-07-08 13:32:14 --> Router Class Initialized
INFO - 2021-07-08 13:32:14 --> Output Class Initialized
INFO - 2021-07-08 13:32:14 --> Output Class Initialized
INFO - 2021-07-08 13:32:14 --> Security Class Initialized
INFO - 2021-07-08 13:32:14 --> Security Class Initialized
DEBUG - 2021-07-08 13:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 13:32:14 --> Input Class Initialized
DEBUG - 2021-07-08 13:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 13:32:14 --> Language Class Initialized
INFO - 2021-07-08 13:32:14 --> Input Class Initialized
INFO - 2021-07-08 13:32:14 --> Language Class Initialized
INFO - 2021-07-08 13:32:14 --> Loader Class Initialized
INFO - 2021-07-08 13:32:14 --> Loader Class Initialized
INFO - 2021-07-08 13:32:14 --> Helper loaded: html_helper
INFO - 2021-07-08 13:32:14 --> Helper loaded: html_helper
INFO - 2021-07-08 13:32:14 --> Helper loaded: url_helper
INFO - 2021-07-08 13:32:14 --> Helper loaded: url_helper
INFO - 2021-07-08 13:32:14 --> Helper loaded: form_helper
INFO - 2021-07-08 13:32:14 --> Helper loaded: form_helper
INFO - 2021-07-08 13:32:14 --> Database Driver Class Initialized
INFO - 2021-07-08 13:32:14 --> Database Driver Class Initialized
INFO - 2021-07-08 13:32:14 --> Form Validation Class Initialized
INFO - 2021-07-08 13:32:14 --> Form Validation Class Initialized
DEBUG - 2021-07-08 13:32:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 13:32:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 13:32:14 --> Encryption Class Initialized
DEBUG - 2021-07-08 13:32:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 13:32:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 13:32:14 --> Encryption Class Initialized
INFO - 2021-07-08 13:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 13:32:14 --> Model "vendor_model" initialized
INFO - 2021-07-08 13:32:14 --> Model "coupon_model" initialized
INFO - 2021-07-08 13:32:14 --> Model "user_model" initialized
INFO - 2021-07-08 13:32:14 --> Model "role_model" initialized
INFO - 2021-07-08 13:32:14 --> Controller Class Initialized
INFO - 2021-07-08 13:32:14 --> Helper loaded: language_helper
INFO - 2021-07-08 13:32:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 13:32:14 --> Model "Quotation_model" initialized
INFO - 2021-07-08 13:32:14 --> Final output sent to browser
DEBUG - 2021-07-08 13:32:14 --> Total execution time: 0.0667
INFO - 2021-07-08 13:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 13:32:14 --> Model "vendor_model" initialized
INFO - 2021-07-08 13:32:14 --> Model "coupon_model" initialized
INFO - 2021-07-08 13:32:14 --> Model "user_model" initialized
INFO - 2021-07-08 13:32:14 --> Model "role_model" initialized
INFO - 2021-07-08 13:32:14 --> Controller Class Initialized
INFO - 2021-07-08 13:32:14 --> Helper loaded: language_helper
INFO - 2021-07-08 13:32:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 13:32:14 --> Model "Quotation_model" initialized
INFO - 2021-07-08 13:32:14 --> Final output sent to browser
DEBUG - 2021-07-08 13:32:14 --> Total execution time: 0.0774
INFO - 2021-07-08 13:32:19 --> Config Class Initialized
INFO - 2021-07-08 13:32:19 --> Hooks Class Initialized
DEBUG - 2021-07-08 13:32:19 --> UTF-8 Support Enabled
INFO - 2021-07-08 13:32:19 --> Utf8 Class Initialized
INFO - 2021-07-08 13:32:19 --> URI Class Initialized
INFO - 2021-07-08 13:32:19 --> Router Class Initialized
INFO - 2021-07-08 13:32:19 --> Output Class Initialized
INFO - 2021-07-08 13:32:19 --> Security Class Initialized
DEBUG - 2021-07-08 13:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 13:32:19 --> Input Class Initialized
INFO - 2021-07-08 13:32:19 --> Language Class Initialized
INFO - 2021-07-08 13:32:19 --> Loader Class Initialized
INFO - 2021-07-08 13:32:19 --> Helper loaded: html_helper
INFO - 2021-07-08 13:32:19 --> Helper loaded: url_helper
INFO - 2021-07-08 13:32:19 --> Helper loaded: form_helper
INFO - 2021-07-08 13:32:19 --> Database Driver Class Initialized
INFO - 2021-07-08 13:32:19 --> Form Validation Class Initialized
DEBUG - 2021-07-08 13:32:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 13:32:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 13:32:19 --> Encryption Class Initialized
INFO - 2021-07-08 13:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 13:32:19 --> Model "vendor_model" initialized
INFO - 2021-07-08 13:32:19 --> Model "coupon_model" initialized
INFO - 2021-07-08 13:32:19 --> Model "user_model" initialized
INFO - 2021-07-08 13:32:19 --> Model "role_model" initialized
INFO - 2021-07-08 13:32:19 --> Controller Class Initialized
INFO - 2021-07-08 13:32:19 --> Helper loaded: language_helper
INFO - 2021-07-08 13:32:19 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 13:32:19 --> Model "Customer_model" initialized
INFO - 2021-07-08 13:32:19 --> Model "Product_model" initialized
INFO - 2021-07-08 13:32:19 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 13:32:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 13:32:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 13:32:19 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 13:32:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 13:32:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 13:32:19 --> Final output sent to browser
DEBUG - 2021-07-08 13:32:19 --> Total execution time: 0.0764
INFO - 2021-07-08 13:32:33 --> Config Class Initialized
INFO - 2021-07-08 13:32:33 --> Hooks Class Initialized
DEBUG - 2021-07-08 13:32:33 --> UTF-8 Support Enabled
INFO - 2021-07-08 13:32:33 --> Utf8 Class Initialized
INFO - 2021-07-08 13:32:33 --> URI Class Initialized
INFO - 2021-07-08 13:32:33 --> Router Class Initialized
INFO - 2021-07-08 13:32:33 --> Output Class Initialized
INFO - 2021-07-08 13:32:33 --> Security Class Initialized
DEBUG - 2021-07-08 13:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 13:32:33 --> Input Class Initialized
INFO - 2021-07-08 13:32:33 --> Language Class Initialized
INFO - 2021-07-08 13:32:33 --> Loader Class Initialized
INFO - 2021-07-08 13:32:33 --> Helper loaded: html_helper
INFO - 2021-07-08 13:32:33 --> Helper loaded: url_helper
INFO - 2021-07-08 13:32:33 --> Helper loaded: form_helper
INFO - 2021-07-08 13:32:33 --> Database Driver Class Initialized
INFO - 2021-07-08 13:32:33 --> Form Validation Class Initialized
DEBUG - 2021-07-08 13:32:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 13:32:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 13:32:33 --> Encryption Class Initialized
INFO - 2021-07-08 13:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 13:32:33 --> Model "vendor_model" initialized
INFO - 2021-07-08 13:32:33 --> Model "coupon_model" initialized
INFO - 2021-07-08 13:32:33 --> Model "user_model" initialized
INFO - 2021-07-08 13:32:33 --> Model "role_model" initialized
INFO - 2021-07-08 13:32:33 --> Controller Class Initialized
INFO - 2021-07-08 13:32:33 --> Helper loaded: language_helper
INFO - 2021-07-08 13:32:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 13:32:33 --> Model "Product_model" initialized
INFO - 2021-07-08 13:32:33 --> Final output sent to browser
DEBUG - 2021-07-08 13:32:33 --> Total execution time: 0.0583
INFO - 2021-07-08 13:33:51 --> Config Class Initialized
INFO - 2021-07-08 13:33:51 --> Hooks Class Initialized
DEBUG - 2021-07-08 13:33:51 --> UTF-8 Support Enabled
INFO - 2021-07-08 13:33:51 --> Utf8 Class Initialized
INFO - 2021-07-08 13:33:51 --> URI Class Initialized
INFO - 2021-07-08 13:33:51 --> Router Class Initialized
INFO - 2021-07-08 13:33:51 --> Output Class Initialized
INFO - 2021-07-08 13:33:51 --> Security Class Initialized
DEBUG - 2021-07-08 13:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 13:33:51 --> Input Class Initialized
INFO - 2021-07-08 13:33:51 --> Language Class Initialized
INFO - 2021-07-08 13:33:51 --> Loader Class Initialized
INFO - 2021-07-08 13:33:51 --> Helper loaded: html_helper
INFO - 2021-07-08 13:33:51 --> Helper loaded: url_helper
INFO - 2021-07-08 13:33:51 --> Helper loaded: form_helper
INFO - 2021-07-08 13:33:51 --> Database Driver Class Initialized
INFO - 2021-07-08 13:33:51 --> Form Validation Class Initialized
DEBUG - 2021-07-08 13:33:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 13:33:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 13:33:51 --> Encryption Class Initialized
INFO - 2021-07-08 13:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 13:33:51 --> Model "vendor_model" initialized
INFO - 2021-07-08 13:33:51 --> Model "coupon_model" initialized
INFO - 2021-07-08 13:33:51 --> Model "user_model" initialized
INFO - 2021-07-08 13:33:51 --> Model "role_model" initialized
INFO - 2021-07-08 13:33:51 --> Controller Class Initialized
INFO - 2021-07-08 13:33:51 --> Helper loaded: language_helper
INFO - 2021-07-08 13:33:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 13:33:51 --> Model "Customer_model" initialized
INFO - 2021-07-08 13:33:51 --> Model "Product_model" initialized
INFO - 2021-07-08 13:33:51 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 13:33:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 13:33:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 13:33:51 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 13:33:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 13:33:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 13:33:51 --> Final output sent to browser
DEBUG - 2021-07-08 13:33:51 --> Total execution time: 0.0734
INFO - 2021-07-08 13:34:01 --> Config Class Initialized
INFO - 2021-07-08 13:34:01 --> Hooks Class Initialized
DEBUG - 2021-07-08 13:34:01 --> UTF-8 Support Enabled
INFO - 2021-07-08 13:34:01 --> Utf8 Class Initialized
INFO - 2021-07-08 13:34:01 --> URI Class Initialized
INFO - 2021-07-08 13:34:01 --> Router Class Initialized
INFO - 2021-07-08 13:34:01 --> Output Class Initialized
INFO - 2021-07-08 13:34:01 --> Security Class Initialized
DEBUG - 2021-07-08 13:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 13:34:01 --> Input Class Initialized
INFO - 2021-07-08 13:34:01 --> Language Class Initialized
INFO - 2021-07-08 13:34:02 --> Loader Class Initialized
INFO - 2021-07-08 13:34:02 --> Helper loaded: html_helper
INFO - 2021-07-08 13:34:02 --> Helper loaded: url_helper
INFO - 2021-07-08 13:34:02 --> Helper loaded: form_helper
INFO - 2021-07-08 13:34:02 --> Database Driver Class Initialized
INFO - 2021-07-08 13:34:02 --> Form Validation Class Initialized
DEBUG - 2021-07-08 13:34:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 13:34:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 13:34:02 --> Encryption Class Initialized
INFO - 2021-07-08 13:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 13:34:02 --> Model "vendor_model" initialized
INFO - 2021-07-08 13:34:02 --> Model "coupon_model" initialized
INFO - 2021-07-08 13:34:02 --> Model "user_model" initialized
INFO - 2021-07-08 13:34:02 --> Model "role_model" initialized
INFO - 2021-07-08 13:34:02 --> Controller Class Initialized
INFO - 2021-07-08 13:34:02 --> Helper loaded: language_helper
INFO - 2021-07-08 13:34:02 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 13:34:02 --> Model "Product_model" initialized
INFO - 2021-07-08 13:34:02 --> Final output sent to browser
DEBUG - 2021-07-08 13:34:02 --> Total execution time: 0.0642
INFO - 2021-07-08 13:57:48 --> Config Class Initialized
INFO - 2021-07-08 13:57:48 --> Hooks Class Initialized
DEBUG - 2021-07-08 13:57:48 --> UTF-8 Support Enabled
INFO - 2021-07-08 13:57:48 --> Utf8 Class Initialized
INFO - 2021-07-08 13:57:48 --> URI Class Initialized
INFO - 2021-07-08 13:57:48 --> Router Class Initialized
INFO - 2021-07-08 13:57:48 --> Output Class Initialized
INFO - 2021-07-08 13:57:48 --> Security Class Initialized
DEBUG - 2021-07-08 13:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 13:57:48 --> Input Class Initialized
INFO - 2021-07-08 13:57:48 --> Language Class Initialized
INFO - 2021-07-08 13:57:48 --> Loader Class Initialized
INFO - 2021-07-08 13:57:48 --> Helper loaded: html_helper
INFO - 2021-07-08 13:57:48 --> Helper loaded: url_helper
INFO - 2021-07-08 13:57:48 --> Helper loaded: form_helper
INFO - 2021-07-08 13:57:48 --> Database Driver Class Initialized
INFO - 2021-07-08 13:57:48 --> Form Validation Class Initialized
DEBUG - 2021-07-08 13:57:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 13:57:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 13:57:48 --> Encryption Class Initialized
INFO - 2021-07-08 13:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 13:57:48 --> Model "vendor_model" initialized
INFO - 2021-07-08 13:57:48 --> Model "coupon_model" initialized
INFO - 2021-07-08 13:57:48 --> Model "user_model" initialized
INFO - 2021-07-08 13:57:48 --> Model "role_model" initialized
INFO - 2021-07-08 13:57:48 --> Controller Class Initialized
INFO - 2021-07-08 13:57:48 --> Helper loaded: language_helper
INFO - 2021-07-08 13:57:48 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 13:57:48 --> Model "Invoice_model" initialized
INFO - 2021-07-08 13:57:48 --> Model "Customer_model" initialized
INFO - 2021-07-08 13:57:48 --> Model "Product_model" initialized
INFO - 2021-07-08 13:57:48 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 13:57:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 13:57:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 13:57:48 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Invoices\edit_invoice.php 32
INFO - 2021-07-08 13:57:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Invoices/edit_invoice.php
INFO - 2021-07-08 13:57:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 13:57:48 --> Final output sent to browser
DEBUG - 2021-07-08 13:57:48 --> Total execution time: 0.4328
INFO - 2021-07-08 13:57:57 --> Config Class Initialized
INFO - 2021-07-08 13:57:57 --> Hooks Class Initialized
DEBUG - 2021-07-08 13:57:57 --> UTF-8 Support Enabled
INFO - 2021-07-08 13:57:57 --> Utf8 Class Initialized
INFO - 2021-07-08 13:57:57 --> URI Class Initialized
INFO - 2021-07-08 13:57:57 --> Router Class Initialized
INFO - 2021-07-08 13:57:57 --> Output Class Initialized
INFO - 2021-07-08 13:57:57 --> Security Class Initialized
DEBUG - 2021-07-08 13:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 13:57:57 --> Input Class Initialized
INFO - 2021-07-08 13:57:57 --> Language Class Initialized
INFO - 2021-07-08 13:57:57 --> Loader Class Initialized
INFO - 2021-07-08 13:57:57 --> Helper loaded: html_helper
INFO - 2021-07-08 13:57:57 --> Helper loaded: url_helper
INFO - 2021-07-08 13:57:57 --> Helper loaded: form_helper
INFO - 2021-07-08 13:57:57 --> Database Driver Class Initialized
INFO - 2021-07-08 13:57:57 --> Form Validation Class Initialized
DEBUG - 2021-07-08 13:57:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 13:57:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 13:57:57 --> Encryption Class Initialized
INFO - 2021-07-08 13:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 13:57:57 --> Model "vendor_model" initialized
INFO - 2021-07-08 13:57:57 --> Model "coupon_model" initialized
INFO - 2021-07-08 13:57:57 --> Model "user_model" initialized
INFO - 2021-07-08 13:57:57 --> Model "role_model" initialized
INFO - 2021-07-08 13:57:57 --> Controller Class Initialized
INFO - 2021-07-08 13:57:57 --> Helper loaded: language_helper
INFO - 2021-07-08 13:57:57 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 13:57:57 --> Model "Quotation_model" initialized
INFO - 2021-07-08 13:57:57 --> Model "Customer_model" initialized
INFO - 2021-07-08 13:57:57 --> Model "Product_model" initialized
INFO - 2021-07-08 13:57:57 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 13:57:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 13:57:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 13:57:57 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 13:57:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 13:57:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 13:57:57 --> Final output sent to browser
DEBUG - 2021-07-08 13:57:57 --> Total execution time: 0.1224
INFO - 2021-07-08 13:59:49 --> Config Class Initialized
INFO - 2021-07-08 13:59:49 --> Hooks Class Initialized
DEBUG - 2021-07-08 13:59:49 --> UTF-8 Support Enabled
INFO - 2021-07-08 13:59:49 --> Utf8 Class Initialized
INFO - 2021-07-08 13:59:49 --> URI Class Initialized
INFO - 2021-07-08 13:59:49 --> Router Class Initialized
INFO - 2021-07-08 13:59:49 --> Output Class Initialized
INFO - 2021-07-08 13:59:49 --> Security Class Initialized
DEBUG - 2021-07-08 13:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 13:59:49 --> Input Class Initialized
INFO - 2021-07-08 13:59:49 --> Language Class Initialized
INFO - 2021-07-08 13:59:49 --> Loader Class Initialized
INFO - 2021-07-08 13:59:49 --> Helper loaded: html_helper
INFO - 2021-07-08 13:59:49 --> Helper loaded: url_helper
INFO - 2021-07-08 13:59:49 --> Helper loaded: form_helper
INFO - 2021-07-08 13:59:49 --> Database Driver Class Initialized
INFO - 2021-07-08 13:59:49 --> Form Validation Class Initialized
DEBUG - 2021-07-08 13:59:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 13:59:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 13:59:49 --> Encryption Class Initialized
INFO - 2021-07-08 13:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 13:59:49 --> Model "vendor_model" initialized
INFO - 2021-07-08 13:59:49 --> Model "coupon_model" initialized
INFO - 2021-07-08 13:59:49 --> Model "user_model" initialized
INFO - 2021-07-08 13:59:49 --> Model "role_model" initialized
INFO - 2021-07-08 13:59:49 --> Controller Class Initialized
INFO - 2021-07-08 13:59:49 --> Helper loaded: language_helper
INFO - 2021-07-08 13:59:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 13:59:49 --> Model "Quotation_model" initialized
INFO - 2021-07-08 13:59:49 --> Model "Customer_model" initialized
INFO - 2021-07-08 13:59:49 --> Model "Product_model" initialized
INFO - 2021-07-08 13:59:49 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 13:59:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 13:59:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 13:59:49 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 13:59:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 13:59:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 13:59:49 --> Final output sent to browser
DEBUG - 2021-07-08 13:59:49 --> Total execution time: 0.0853
INFO - 2021-07-08 13:59:55 --> Config Class Initialized
INFO - 2021-07-08 13:59:55 --> Hooks Class Initialized
DEBUG - 2021-07-08 13:59:55 --> UTF-8 Support Enabled
INFO - 2021-07-08 13:59:55 --> Utf8 Class Initialized
INFO - 2021-07-08 13:59:55 --> URI Class Initialized
INFO - 2021-07-08 13:59:55 --> Router Class Initialized
INFO - 2021-07-08 13:59:55 --> Output Class Initialized
INFO - 2021-07-08 13:59:55 --> Security Class Initialized
DEBUG - 2021-07-08 13:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 13:59:55 --> Input Class Initialized
INFO - 2021-07-08 13:59:55 --> Language Class Initialized
INFO - 2021-07-08 13:59:55 --> Loader Class Initialized
INFO - 2021-07-08 13:59:55 --> Helper loaded: html_helper
INFO - 2021-07-08 13:59:55 --> Helper loaded: url_helper
INFO - 2021-07-08 13:59:55 --> Helper loaded: form_helper
INFO - 2021-07-08 13:59:55 --> Database Driver Class Initialized
INFO - 2021-07-08 13:59:55 --> Form Validation Class Initialized
DEBUG - 2021-07-08 13:59:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 13:59:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 13:59:55 --> Encryption Class Initialized
INFO - 2021-07-08 13:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 13:59:55 --> Model "vendor_model" initialized
INFO - 2021-07-08 13:59:55 --> Model "coupon_model" initialized
INFO - 2021-07-08 13:59:55 --> Model "user_model" initialized
INFO - 2021-07-08 13:59:55 --> Model "role_model" initialized
INFO - 2021-07-08 13:59:55 --> Controller Class Initialized
INFO - 2021-07-08 13:59:55 --> Helper loaded: language_helper
INFO - 2021-07-08 13:59:55 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 13:59:55 --> Model "Quotation_model" initialized
INFO - 2021-07-08 13:59:55 --> Model "Customer_model" initialized
INFO - 2021-07-08 13:59:55 --> Model "Product_model" initialized
INFO - 2021-07-08 13:59:55 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 13:59:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 13:59:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 13:59:55 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 13:59:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 13:59:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 13:59:55 --> Final output sent to browser
DEBUG - 2021-07-08 13:59:55 --> Total execution time: 0.0793
INFO - 2021-07-08 13:59:58 --> Config Class Initialized
INFO - 2021-07-08 13:59:58 --> Config Class Initialized
INFO - 2021-07-08 13:59:58 --> Hooks Class Initialized
INFO - 2021-07-08 13:59:58 --> Hooks Class Initialized
DEBUG - 2021-07-08 13:59:58 --> UTF-8 Support Enabled
DEBUG - 2021-07-08 13:59:58 --> UTF-8 Support Enabled
INFO - 2021-07-08 13:59:58 --> Utf8 Class Initialized
INFO - 2021-07-08 13:59:58 --> Utf8 Class Initialized
INFO - 2021-07-08 13:59:58 --> URI Class Initialized
INFO - 2021-07-08 13:59:58 --> URI Class Initialized
INFO - 2021-07-08 13:59:58 --> Router Class Initialized
INFO - 2021-07-08 13:59:58 --> Router Class Initialized
INFO - 2021-07-08 13:59:58 --> Output Class Initialized
INFO - 2021-07-08 13:59:58 --> Output Class Initialized
INFO - 2021-07-08 13:59:58 --> Security Class Initialized
INFO - 2021-07-08 13:59:58 --> Security Class Initialized
DEBUG - 2021-07-08 13:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-08 13:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 13:59:58 --> Input Class Initialized
INFO - 2021-07-08 13:59:58 --> Input Class Initialized
INFO - 2021-07-08 13:59:58 --> Language Class Initialized
INFO - 2021-07-08 13:59:58 --> Language Class Initialized
INFO - 2021-07-08 13:59:58 --> Loader Class Initialized
INFO - 2021-07-08 13:59:58 --> Loader Class Initialized
INFO - 2021-07-08 13:59:58 --> Helper loaded: html_helper
INFO - 2021-07-08 13:59:58 --> Helper loaded: html_helper
INFO - 2021-07-08 13:59:58 --> Helper loaded: url_helper
INFO - 2021-07-08 13:59:58 --> Helper loaded: url_helper
INFO - 2021-07-08 13:59:58 --> Helper loaded: form_helper
INFO - 2021-07-08 13:59:58 --> Helper loaded: form_helper
INFO - 2021-07-08 13:59:58 --> Database Driver Class Initialized
INFO - 2021-07-08 13:59:58 --> Database Driver Class Initialized
INFO - 2021-07-08 13:59:58 --> Form Validation Class Initialized
DEBUG - 2021-07-08 13:59:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 13:59:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 13:59:58 --> Encryption Class Initialized
INFO - 2021-07-08 13:59:58 --> Form Validation Class Initialized
DEBUG - 2021-07-08 13:59:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 13:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 13:59:58 --> Model "vendor_model" initialized
INFO - 2021-07-08 13:59:58 --> Model "coupon_model" initialized
INFO - 2021-07-08 13:59:58 --> Model "user_model" initialized
INFO - 2021-07-08 13:59:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 13:59:58 --> Encryption Class Initialized
INFO - 2021-07-08 13:59:58 --> Model "role_model" initialized
INFO - 2021-07-08 13:59:58 --> Controller Class Initialized
INFO - 2021-07-08 13:59:58 --> Helper loaded: language_helper
INFO - 2021-07-08 13:59:58 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 13:59:58 --> Model "Quotation_model" initialized
INFO - 2021-07-08 13:59:58 --> Final output sent to browser
DEBUG - 2021-07-08 13:59:58 --> Total execution time: 0.0747
INFO - 2021-07-08 13:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 13:59:58 --> Model "vendor_model" initialized
INFO - 2021-07-08 13:59:58 --> Model "coupon_model" initialized
INFO - 2021-07-08 13:59:58 --> Model "user_model" initialized
INFO - 2021-07-08 13:59:58 --> Model "role_model" initialized
INFO - 2021-07-08 13:59:58 --> Controller Class Initialized
INFO - 2021-07-08 13:59:59 --> Helper loaded: language_helper
INFO - 2021-07-08 13:59:59 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 13:59:59 --> Model "Quotation_model" initialized
INFO - 2021-07-08 13:59:59 --> Final output sent to browser
DEBUG - 2021-07-08 13:59:59 --> Total execution time: 0.0895
INFO - 2021-07-08 14:01:08 --> Config Class Initialized
INFO - 2021-07-08 14:01:08 --> Hooks Class Initialized
DEBUG - 2021-07-08 14:01:08 --> UTF-8 Support Enabled
INFO - 2021-07-08 14:01:08 --> Utf8 Class Initialized
INFO - 2021-07-08 14:01:08 --> URI Class Initialized
DEBUG - 2021-07-08 14:01:08 --> No URI present. Default controller set.
INFO - 2021-07-08 14:01:08 --> Router Class Initialized
INFO - 2021-07-08 14:01:08 --> Output Class Initialized
INFO - 2021-07-08 14:01:08 --> Security Class Initialized
DEBUG - 2021-07-08 14:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 14:01:08 --> Input Class Initialized
INFO - 2021-07-08 14:01:08 --> Language Class Initialized
INFO - 2021-07-08 14:01:08 --> Loader Class Initialized
INFO - 2021-07-08 14:01:08 --> Helper loaded: html_helper
INFO - 2021-07-08 14:01:08 --> Helper loaded: url_helper
INFO - 2021-07-08 14:01:08 --> Helper loaded: form_helper
INFO - 2021-07-08 14:01:08 --> Database Driver Class Initialized
INFO - 2021-07-08 14:01:08 --> Form Validation Class Initialized
DEBUG - 2021-07-08 14:01:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 14:01:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 14:01:08 --> Encryption Class Initialized
INFO - 2021-07-08 14:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 14:01:08 --> Model "vendor_model" initialized
INFO - 2021-07-08 14:01:08 --> Model "coupon_model" initialized
INFO - 2021-07-08 14:01:08 --> Model "user_model" initialized
INFO - 2021-07-08 14:01:08 --> Model "role_model" initialized
INFO - 2021-07-08 14:01:08 --> Controller Class Initialized
INFO - 2021-07-08 14:01:08 --> Helper loaded: language_helper
INFO - 2021-07-08 14:01:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 14:01:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-08 14:01:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-08 14:01:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-08 14:01:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 14:01:08 --> Final output sent to browser
DEBUG - 2021-07-08 14:01:08 --> Total execution time: 0.0754
INFO - 2021-07-08 14:01:09 --> Config Class Initialized
INFO - 2021-07-08 14:01:09 --> Hooks Class Initialized
DEBUG - 2021-07-08 14:01:09 --> UTF-8 Support Enabled
INFO - 2021-07-08 14:01:09 --> Utf8 Class Initialized
INFO - 2021-07-08 14:01:09 --> URI Class Initialized
DEBUG - 2021-07-08 14:01:09 --> No URI present. Default controller set.
INFO - 2021-07-08 14:01:09 --> Router Class Initialized
INFO - 2021-07-08 14:01:09 --> Output Class Initialized
INFO - 2021-07-08 14:01:09 --> Security Class Initialized
DEBUG - 2021-07-08 14:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 14:01:09 --> Input Class Initialized
INFO - 2021-07-08 14:01:09 --> Language Class Initialized
INFO - 2021-07-08 14:01:09 --> Loader Class Initialized
INFO - 2021-07-08 14:01:09 --> Helper loaded: html_helper
INFO - 2021-07-08 14:01:09 --> Helper loaded: url_helper
INFO - 2021-07-08 14:01:09 --> Helper loaded: form_helper
INFO - 2021-07-08 14:01:09 --> Database Driver Class Initialized
INFO - 2021-07-08 14:01:09 --> Form Validation Class Initialized
DEBUG - 2021-07-08 14:01:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 14:01:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 14:01:09 --> Encryption Class Initialized
INFO - 2021-07-08 14:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 14:01:09 --> Model "vendor_model" initialized
INFO - 2021-07-08 14:01:09 --> Model "coupon_model" initialized
INFO - 2021-07-08 14:01:09 --> Model "user_model" initialized
INFO - 2021-07-08 14:01:09 --> Model "role_model" initialized
INFO - 2021-07-08 14:01:09 --> Controller Class Initialized
INFO - 2021-07-08 14:01:09 --> Helper loaded: language_helper
INFO - 2021-07-08 14:01:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 14:01:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-08 14:01:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-08 14:01:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-08 14:01:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 14:01:09 --> Final output sent to browser
DEBUG - 2021-07-08 14:01:09 --> Total execution time: 0.2830
INFO - 2021-07-08 14:01:15 --> Config Class Initialized
INFO - 2021-07-08 14:01:15 --> Hooks Class Initialized
DEBUG - 2021-07-08 14:01:15 --> UTF-8 Support Enabled
INFO - 2021-07-08 14:01:15 --> Utf8 Class Initialized
INFO - 2021-07-08 14:01:15 --> URI Class Initialized
INFO - 2021-07-08 14:01:15 --> Router Class Initialized
INFO - 2021-07-08 14:01:15 --> Output Class Initialized
INFO - 2021-07-08 14:01:15 --> Security Class Initialized
DEBUG - 2021-07-08 14:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 14:01:15 --> Input Class Initialized
INFO - 2021-07-08 14:01:15 --> Language Class Initialized
INFO - 2021-07-08 14:01:15 --> Loader Class Initialized
INFO - 2021-07-08 14:01:15 --> Helper loaded: html_helper
INFO - 2021-07-08 14:01:15 --> Helper loaded: url_helper
INFO - 2021-07-08 14:01:15 --> Helper loaded: form_helper
INFO - 2021-07-08 14:01:15 --> Database Driver Class Initialized
INFO - 2021-07-08 14:01:15 --> Form Validation Class Initialized
DEBUG - 2021-07-08 14:01:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 14:01:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 14:01:15 --> Encryption Class Initialized
INFO - 2021-07-08 14:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 14:01:15 --> Model "vendor_model" initialized
INFO - 2021-07-08 14:01:15 --> Model "coupon_model" initialized
INFO - 2021-07-08 14:01:15 --> Model "user_model" initialized
INFO - 2021-07-08 14:01:15 --> Model "role_model" initialized
INFO - 2021-07-08 14:01:15 --> Controller Class Initialized
INFO - 2021-07-08 14:01:15 --> Helper loaded: language_helper
INFO - 2021-07-08 14:01:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 14:01:15 --> Model "Customer_model" initialized
INFO - 2021-07-08 14:01:15 --> Model "Product_model" initialized
INFO - 2021-07-08 14:01:15 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-08 14:01:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-08 14:01:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-08 14:01:15 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-08 14:01:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-08 14:01:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-08 14:01:15 --> Final output sent to browser
DEBUG - 2021-07-08 14:01:15 --> Total execution time: 0.0695
INFO - 2021-07-08 14:01:20 --> Config Class Initialized
INFO - 2021-07-08 14:01:20 --> Hooks Class Initialized
DEBUG - 2021-07-08 14:01:20 --> UTF-8 Support Enabled
INFO - 2021-07-08 14:01:20 --> Utf8 Class Initialized
INFO - 2021-07-08 14:01:20 --> URI Class Initialized
INFO - 2021-07-08 14:01:20 --> Router Class Initialized
INFO - 2021-07-08 14:01:20 --> Output Class Initialized
INFO - 2021-07-08 14:01:20 --> Security Class Initialized
DEBUG - 2021-07-08 14:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 14:01:20 --> Input Class Initialized
INFO - 2021-07-08 14:01:20 --> Language Class Initialized
INFO - 2021-07-08 14:01:20 --> Loader Class Initialized
INFO - 2021-07-08 14:01:20 --> Helper loaded: html_helper
INFO - 2021-07-08 14:01:20 --> Helper loaded: url_helper
INFO - 2021-07-08 14:01:20 --> Helper loaded: form_helper
INFO - 2021-07-08 14:01:20 --> Database Driver Class Initialized
INFO - 2021-07-08 14:01:20 --> Form Validation Class Initialized
DEBUG - 2021-07-08 14:01:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-08 14:01:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-08 14:01:20 --> Encryption Class Initialized
INFO - 2021-07-08 14:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 14:01:20 --> Model "vendor_model" initialized
INFO - 2021-07-08 14:01:20 --> Model "coupon_model" initialized
INFO - 2021-07-08 14:01:20 --> Model "user_model" initialized
INFO - 2021-07-08 14:01:20 --> Model "role_model" initialized
INFO - 2021-07-08 14:01:20 --> Controller Class Initialized
INFO - 2021-07-08 14:01:20 --> Helper loaded: language_helper
INFO - 2021-07-08 14:01:20 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-08 14:01:20 --> Model "Product_model" initialized
INFO - 2021-07-08 14:01:20 --> Final output sent to browser
DEBUG - 2021-07-08 14:01:20 --> Total execution time: 0.0575
