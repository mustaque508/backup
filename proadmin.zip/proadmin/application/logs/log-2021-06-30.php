<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-06-30 07:06:20 --> Config Class Initialized
INFO - 2021-06-30 07:06:20 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:06:20 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:06:20 --> Utf8 Class Initialized
INFO - 2021-06-30 07:06:20 --> URI Class Initialized
DEBUG - 2021-06-30 07:06:20 --> No URI present. Default controller set.
INFO - 2021-06-30 07:06:20 --> Router Class Initialized
INFO - 2021-06-30 07:06:20 --> Output Class Initialized
INFO - 2021-06-30 07:06:20 --> Security Class Initialized
DEBUG - 2021-06-30 07:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:06:20 --> Input Class Initialized
INFO - 2021-06-30 07:06:20 --> Language Class Initialized
INFO - 2021-06-30 07:06:20 --> Loader Class Initialized
INFO - 2021-06-30 07:06:20 --> Helper loaded: html_helper
INFO - 2021-06-30 07:06:20 --> Helper loaded: url_helper
INFO - 2021-06-30 07:06:20 --> Helper loaded: form_helper
INFO - 2021-06-30 07:06:21 --> Database Driver Class Initialized
INFO - 2021-06-30 07:06:21 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:06:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:06:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:06:21 --> Encryption Class Initialized
INFO - 2021-06-30 07:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:06:21 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:06:21 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:06:21 --> Model "user_model" initialized
INFO - 2021-06-30 07:06:21 --> Model "role_model" initialized
INFO - 2021-06-30 07:06:21 --> Controller Class Initialized
INFO - 2021-06-30 07:06:21 --> Helper loaded: language_helper
INFO - 2021-06-30 07:06:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:06:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\login.php
INFO - 2021-06-30 07:06:21 --> Final output sent to browser
DEBUG - 2021-06-30 07:06:21 --> Total execution time: 1.7654
INFO - 2021-06-30 07:06:55 --> Config Class Initialized
INFO - 2021-06-30 07:06:55 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:06:55 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:06:55 --> Utf8 Class Initialized
INFO - 2021-06-30 07:06:55 --> URI Class Initialized
INFO - 2021-06-30 07:06:55 --> Router Class Initialized
INFO - 2021-06-30 07:06:55 --> Output Class Initialized
INFO - 2021-06-30 07:06:55 --> Security Class Initialized
DEBUG - 2021-06-30 07:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:06:55 --> Input Class Initialized
INFO - 2021-06-30 07:06:55 --> Language Class Initialized
INFO - 2021-06-30 07:06:55 --> Loader Class Initialized
INFO - 2021-06-30 07:06:55 --> Helper loaded: html_helper
INFO - 2021-06-30 07:06:55 --> Helper loaded: url_helper
INFO - 2021-06-30 07:06:55 --> Helper loaded: form_helper
INFO - 2021-06-30 07:06:55 --> Database Driver Class Initialized
INFO - 2021-06-30 07:06:55 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:06:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:06:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:06:55 --> Encryption Class Initialized
INFO - 2021-06-30 07:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:06:55 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:06:55 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:06:55 --> Model "user_model" initialized
INFO - 2021-06-30 07:06:55 --> Model "role_model" initialized
INFO - 2021-06-30 07:06:55 --> Controller Class Initialized
INFO - 2021-06-30 07:06:55 --> Helper loaded: language_helper
INFO - 2021-06-30 07:06:55 --> Language file loaded: language/english/content_lang.php
DEBUG - 2021-06-30 07:06:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-30 07:06:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-06-30 07:06:55 --> Model "User" initialized
INFO - 2021-06-30 07:06:56 --> Config Class Initialized
INFO - 2021-06-30 07:06:56 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:06:56 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:06:56 --> Utf8 Class Initialized
INFO - 2021-06-30 07:06:56 --> URI Class Initialized
INFO - 2021-06-30 07:06:56 --> Router Class Initialized
INFO - 2021-06-30 07:06:56 --> Output Class Initialized
INFO - 2021-06-30 07:06:56 --> Security Class Initialized
DEBUG - 2021-06-30 07:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:06:56 --> Input Class Initialized
INFO - 2021-06-30 07:06:56 --> Language Class Initialized
INFO - 2021-06-30 07:06:56 --> Loader Class Initialized
INFO - 2021-06-30 07:06:56 --> Helper loaded: html_helper
INFO - 2021-06-30 07:06:56 --> Helper loaded: url_helper
INFO - 2021-06-30 07:06:56 --> Helper loaded: form_helper
INFO - 2021-06-30 07:06:56 --> Database Driver Class Initialized
INFO - 2021-06-30 07:06:56 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:06:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:06:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:06:56 --> Encryption Class Initialized
INFO - 2021-06-30 07:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:06:56 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:06:56 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:06:56 --> Model "user_model" initialized
INFO - 2021-06-30 07:06:56 --> Model "role_model" initialized
INFO - 2021-06-30 07:06:56 --> Controller Class Initialized
INFO - 2021-06-30 07:06:56 --> Helper loaded: language_helper
INFO - 2021-06-30 07:06:56 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:06:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-06-30 07:06:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-06-30 07:06:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-06-30 07:06:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:06:56 --> Final output sent to browser
DEBUG - 2021-06-30 07:06:56 --> Total execution time: 0.1953
INFO - 2021-06-30 07:14:12 --> Config Class Initialized
INFO - 2021-06-30 07:14:12 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:14:12 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:14:12 --> Utf8 Class Initialized
INFO - 2021-06-30 07:14:12 --> URI Class Initialized
INFO - 2021-06-30 07:14:12 --> Router Class Initialized
INFO - 2021-06-30 07:14:12 --> Output Class Initialized
INFO - 2021-06-30 07:14:12 --> Security Class Initialized
DEBUG - 2021-06-30 07:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:14:12 --> Input Class Initialized
INFO - 2021-06-30 07:14:12 --> Language Class Initialized
INFO - 2021-06-30 07:14:12 --> Loader Class Initialized
INFO - 2021-06-30 07:14:12 --> Helper loaded: html_helper
INFO - 2021-06-30 07:14:12 --> Helper loaded: url_helper
INFO - 2021-06-30 07:14:12 --> Helper loaded: form_helper
INFO - 2021-06-30 07:14:12 --> Database Driver Class Initialized
INFO - 2021-06-30 07:14:12 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:14:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:14:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:14:12 --> Encryption Class Initialized
INFO - 2021-06-30 07:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:14:12 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:14:12 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:14:12 --> Model "user_model" initialized
INFO - 2021-06-30 07:14:12 --> Model "role_model" initialized
INFO - 2021-06-30 07:14:12 --> Controller Class Initialized
INFO - 2021-06-30 07:14:12 --> Helper loaded: language_helper
INFO - 2021-06-30 07:14:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:14:12 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:14:12 --> Model "Product_model" initialized
INFO - 2021-06-30 07:14:12 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:14:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:14:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:14:12 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:14:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:14:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:14:12 --> Final output sent to browser
DEBUG - 2021-06-30 07:14:12 --> Total execution time: 0.4795
INFO - 2021-06-30 07:14:35 --> Config Class Initialized
INFO - 2021-06-30 07:14:35 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:14:35 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:14:35 --> Utf8 Class Initialized
INFO - 2021-06-30 07:14:35 --> URI Class Initialized
INFO - 2021-06-30 07:14:35 --> Router Class Initialized
INFO - 2021-06-30 07:14:35 --> Output Class Initialized
INFO - 2021-06-30 07:14:35 --> Security Class Initialized
DEBUG - 2021-06-30 07:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:14:35 --> Input Class Initialized
INFO - 2021-06-30 07:14:35 --> Language Class Initialized
INFO - 2021-06-30 07:14:35 --> Loader Class Initialized
INFO - 2021-06-30 07:14:35 --> Helper loaded: html_helper
INFO - 2021-06-30 07:14:35 --> Helper loaded: url_helper
INFO - 2021-06-30 07:14:35 --> Helper loaded: form_helper
INFO - 2021-06-30 07:14:35 --> Database Driver Class Initialized
INFO - 2021-06-30 07:14:35 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:14:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:14:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:14:35 --> Encryption Class Initialized
INFO - 2021-06-30 07:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:14:35 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:14:35 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:14:35 --> Model "user_model" initialized
INFO - 2021-06-30 07:14:35 --> Model "role_model" initialized
INFO - 2021-06-30 07:14:35 --> Controller Class Initialized
INFO - 2021-06-30 07:14:35 --> Helper loaded: language_helper
INFO - 2021-06-30 07:14:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:14:35 --> Model "Customer_model" initialized
ERROR - 2021-06-30 07:14:35 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server][SQL Server]Invalid object name '[prosoft_testdb].[dbo].[CUSTOMER]'. - Invalid query: INSERT INTO "[prosoft_testdb]"."[dbo]"."[CUSTOMER]" ("customer_id", "customer_name", "Customer_Address", "Customer_City", "Customer_State", "Customer_Country", "GSTIN_No", "PAN_No", "TAN_No") VALUES ('c5ebef67-187e-4737-a31d-ea8d7d518f20', 'test', 'test', 'test', 'test', 'test', 'test', 'test', 'test')
INFO - 2021-06-30 07:14:35 --> Language file loaded: language/english/db_lang.php
INFO - 2021-06-30 07:15:09 --> Config Class Initialized
INFO - 2021-06-30 07:15:09 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:15:09 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:15:09 --> Utf8 Class Initialized
INFO - 2021-06-30 07:15:09 --> URI Class Initialized
INFO - 2021-06-30 07:15:09 --> Router Class Initialized
INFO - 2021-06-30 07:15:09 --> Output Class Initialized
INFO - 2021-06-30 07:15:09 --> Security Class Initialized
DEBUG - 2021-06-30 07:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:15:09 --> Input Class Initialized
INFO - 2021-06-30 07:15:09 --> Language Class Initialized
INFO - 2021-06-30 07:15:09 --> Loader Class Initialized
INFO - 2021-06-30 07:15:09 --> Helper loaded: html_helper
INFO - 2021-06-30 07:15:09 --> Helper loaded: url_helper
INFO - 2021-06-30 07:15:09 --> Helper loaded: form_helper
INFO - 2021-06-30 07:15:09 --> Database Driver Class Initialized
INFO - 2021-06-30 07:15:09 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:15:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:15:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:15:09 --> Encryption Class Initialized
INFO - 2021-06-30 07:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:15:09 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:15:09 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:15:09 --> Model "user_model" initialized
INFO - 2021-06-30 07:15:09 --> Model "role_model" initialized
INFO - 2021-06-30 07:15:09 --> Controller Class Initialized
INFO - 2021-06-30 07:15:09 --> Helper loaded: language_helper
INFO - 2021-06-30 07:15:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:15:09 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:15:09 --> Model "Product_model" initialized
INFO - 2021-06-30 07:15:09 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:15:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:15:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:15:09 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:15:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:15:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:15:09 --> Final output sent to browser
DEBUG - 2021-06-30 07:15:09 --> Total execution time: 0.0880
INFO - 2021-06-30 07:15:16 --> Config Class Initialized
INFO - 2021-06-30 07:15:16 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:15:16 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:15:16 --> Utf8 Class Initialized
INFO - 2021-06-30 07:15:16 --> URI Class Initialized
INFO - 2021-06-30 07:15:16 --> Router Class Initialized
INFO - 2021-06-30 07:15:16 --> Output Class Initialized
INFO - 2021-06-30 07:15:16 --> Security Class Initialized
DEBUG - 2021-06-30 07:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:15:16 --> Input Class Initialized
INFO - 2021-06-30 07:15:16 --> Language Class Initialized
INFO - 2021-06-30 07:15:16 --> Loader Class Initialized
INFO - 2021-06-30 07:15:16 --> Helper loaded: html_helper
INFO - 2021-06-30 07:15:16 --> Helper loaded: url_helper
INFO - 2021-06-30 07:15:16 --> Helper loaded: form_helper
INFO - 2021-06-30 07:15:16 --> Database Driver Class Initialized
INFO - 2021-06-30 07:15:16 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:15:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:15:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:15:16 --> Encryption Class Initialized
INFO - 2021-06-30 07:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:15:16 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:15:16 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:15:16 --> Model "user_model" initialized
INFO - 2021-06-30 07:15:16 --> Model "role_model" initialized
INFO - 2021-06-30 07:15:16 --> Controller Class Initialized
INFO - 2021-06-30 07:15:16 --> Helper loaded: language_helper
INFO - 2021-06-30 07:15:16 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:15:16 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:15:16 --> Model "Product_model" initialized
INFO - 2021-06-30 07:15:16 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:15:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:15:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:15:16 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:15:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:15:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:15:16 --> Final output sent to browser
DEBUG - 2021-06-30 07:15:16 --> Total execution time: 0.0764
INFO - 2021-06-30 07:16:06 --> Config Class Initialized
INFO - 2021-06-30 07:16:06 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:16:06 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:16:06 --> Utf8 Class Initialized
INFO - 2021-06-30 07:16:06 --> URI Class Initialized
INFO - 2021-06-30 07:16:06 --> Router Class Initialized
INFO - 2021-06-30 07:16:06 --> Output Class Initialized
INFO - 2021-06-30 07:16:06 --> Security Class Initialized
DEBUG - 2021-06-30 07:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:16:06 --> Input Class Initialized
INFO - 2021-06-30 07:16:06 --> Language Class Initialized
INFO - 2021-06-30 07:16:06 --> Loader Class Initialized
INFO - 2021-06-30 07:16:06 --> Helper loaded: html_helper
INFO - 2021-06-30 07:16:06 --> Helper loaded: url_helper
INFO - 2021-06-30 07:16:06 --> Helper loaded: form_helper
INFO - 2021-06-30 07:16:06 --> Database Driver Class Initialized
INFO - 2021-06-30 07:16:06 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:16:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:16:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:16:06 --> Encryption Class Initialized
INFO - 2021-06-30 07:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:16:06 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:16:06 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:16:06 --> Model "user_model" initialized
INFO - 2021-06-30 07:16:06 --> Model "role_model" initialized
INFO - 2021-06-30 07:16:06 --> Controller Class Initialized
INFO - 2021-06-30 07:16:06 --> Helper loaded: language_helper
INFO - 2021-06-30 07:16:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:16:06 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:16:06 --> Model "Product_model" initialized
INFO - 2021-06-30 07:16:06 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:16:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:16:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:16:06 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:16:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:16:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:16:06 --> Final output sent to browser
DEBUG - 2021-06-30 07:16:06 --> Total execution time: 0.0818
INFO - 2021-06-30 07:16:41 --> Config Class Initialized
INFO - 2021-06-30 07:16:41 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:16:41 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:16:41 --> Utf8 Class Initialized
INFO - 2021-06-30 07:16:41 --> URI Class Initialized
INFO - 2021-06-30 07:16:41 --> Router Class Initialized
INFO - 2021-06-30 07:16:41 --> Output Class Initialized
INFO - 2021-06-30 07:16:41 --> Security Class Initialized
DEBUG - 2021-06-30 07:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:16:41 --> Input Class Initialized
INFO - 2021-06-30 07:16:41 --> Language Class Initialized
INFO - 2021-06-30 07:16:41 --> Loader Class Initialized
INFO - 2021-06-30 07:16:41 --> Helper loaded: html_helper
INFO - 2021-06-30 07:16:41 --> Helper loaded: url_helper
INFO - 2021-06-30 07:16:41 --> Helper loaded: form_helper
INFO - 2021-06-30 07:16:41 --> Database Driver Class Initialized
INFO - 2021-06-30 07:16:41 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:16:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:16:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:16:41 --> Encryption Class Initialized
INFO - 2021-06-30 07:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:16:41 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:16:41 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:16:41 --> Model "user_model" initialized
INFO - 2021-06-30 07:16:41 --> Model "role_model" initialized
INFO - 2021-06-30 07:16:41 --> Controller Class Initialized
INFO - 2021-06-30 07:16:41 --> Helper loaded: language_helper
INFO - 2021-06-30 07:16:41 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:16:41 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:16:41 --> Model "Product_model" initialized
INFO - 2021-06-30 07:16:41 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:16:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:16:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:16:41 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:16:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:16:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:16:41 --> Final output sent to browser
DEBUG - 2021-06-30 07:16:41 --> Total execution time: 0.0767
INFO - 2021-06-30 07:17:17 --> Config Class Initialized
INFO - 2021-06-30 07:17:17 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:17:17 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:17:17 --> Utf8 Class Initialized
INFO - 2021-06-30 07:17:17 --> URI Class Initialized
INFO - 2021-06-30 07:17:17 --> Router Class Initialized
INFO - 2021-06-30 07:17:17 --> Output Class Initialized
INFO - 2021-06-30 07:17:17 --> Security Class Initialized
DEBUG - 2021-06-30 07:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:17:17 --> Input Class Initialized
INFO - 2021-06-30 07:17:17 --> Language Class Initialized
INFO - 2021-06-30 07:17:17 --> Loader Class Initialized
INFO - 2021-06-30 07:17:17 --> Helper loaded: html_helper
INFO - 2021-06-30 07:17:17 --> Helper loaded: url_helper
INFO - 2021-06-30 07:17:17 --> Helper loaded: form_helper
INFO - 2021-06-30 07:17:17 --> Database Driver Class Initialized
INFO - 2021-06-30 07:17:17 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:17:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:17:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:17:17 --> Encryption Class Initialized
INFO - 2021-06-30 07:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:17:17 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:17:17 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:17:17 --> Model "user_model" initialized
INFO - 2021-06-30 07:17:17 --> Model "role_model" initialized
INFO - 2021-06-30 07:17:17 --> Controller Class Initialized
INFO - 2021-06-30 07:17:17 --> Helper loaded: language_helper
INFO - 2021-06-30 07:17:17 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:17:17 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:17:17 --> Model "Product_model" initialized
INFO - 2021-06-30 07:17:17 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:17:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:17:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:17:17 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:17:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:17:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:17:17 --> Final output sent to browser
DEBUG - 2021-06-30 07:17:17 --> Total execution time: 0.0807
INFO - 2021-06-30 07:17:33 --> Config Class Initialized
INFO - 2021-06-30 07:17:33 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:17:33 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:17:33 --> Utf8 Class Initialized
INFO - 2021-06-30 07:17:33 --> URI Class Initialized
INFO - 2021-06-30 07:17:33 --> Router Class Initialized
INFO - 2021-06-30 07:17:33 --> Output Class Initialized
INFO - 2021-06-30 07:17:33 --> Security Class Initialized
DEBUG - 2021-06-30 07:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:17:33 --> Input Class Initialized
INFO - 2021-06-30 07:17:33 --> Language Class Initialized
INFO - 2021-06-30 07:17:33 --> Loader Class Initialized
INFO - 2021-06-30 07:17:33 --> Helper loaded: html_helper
INFO - 2021-06-30 07:17:33 --> Helper loaded: url_helper
INFO - 2021-06-30 07:17:33 --> Helper loaded: form_helper
INFO - 2021-06-30 07:17:33 --> Database Driver Class Initialized
INFO - 2021-06-30 07:17:33 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:17:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:17:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:17:33 --> Encryption Class Initialized
INFO - 2021-06-30 07:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:17:33 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:17:33 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:17:33 --> Model "user_model" initialized
INFO - 2021-06-30 07:17:33 --> Model "role_model" initialized
INFO - 2021-06-30 07:17:33 --> Controller Class Initialized
INFO - 2021-06-30 07:17:33 --> Helper loaded: language_helper
INFO - 2021-06-30 07:17:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:17:33 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:17:33 --> Model "Product_model" initialized
INFO - 2021-06-30 07:17:33 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:17:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:17:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:17:33 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:17:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:17:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:17:33 --> Final output sent to browser
DEBUG - 2021-06-30 07:17:33 --> Total execution time: 0.0828
INFO - 2021-06-30 07:24:50 --> Config Class Initialized
INFO - 2021-06-30 07:24:50 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:24:50 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:24:50 --> Utf8 Class Initialized
INFO - 2021-06-30 07:24:50 --> URI Class Initialized
INFO - 2021-06-30 07:24:50 --> Router Class Initialized
INFO - 2021-06-30 07:24:50 --> Output Class Initialized
INFO - 2021-06-30 07:24:50 --> Security Class Initialized
DEBUG - 2021-06-30 07:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:24:50 --> Input Class Initialized
INFO - 2021-06-30 07:24:50 --> Language Class Initialized
INFO - 2021-06-30 07:24:50 --> Loader Class Initialized
INFO - 2021-06-30 07:24:50 --> Helper loaded: html_helper
INFO - 2021-06-30 07:24:50 --> Helper loaded: url_helper
INFO - 2021-06-30 07:24:50 --> Helper loaded: form_helper
INFO - 2021-06-30 07:24:50 --> Database Driver Class Initialized
INFO - 2021-06-30 07:24:50 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:24:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:24:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:24:50 --> Encryption Class Initialized
INFO - 2021-06-30 07:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:24:50 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:24:50 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:24:50 --> Model "user_model" initialized
INFO - 2021-06-30 07:24:50 --> Model "role_model" initialized
INFO - 2021-06-30 07:24:50 --> Controller Class Initialized
INFO - 2021-06-30 07:24:50 --> Helper loaded: language_helper
INFO - 2021-06-30 07:24:50 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:24:50 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:24:50 --> Final output sent to browser
DEBUG - 2021-06-30 07:24:50 --> Total execution time: 0.0752
INFO - 2021-06-30 07:25:14 --> Config Class Initialized
INFO - 2021-06-30 07:25:14 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:25:14 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:25:14 --> Utf8 Class Initialized
INFO - 2021-06-30 07:25:14 --> URI Class Initialized
INFO - 2021-06-30 07:25:14 --> Router Class Initialized
INFO - 2021-06-30 07:25:14 --> Output Class Initialized
INFO - 2021-06-30 07:25:14 --> Security Class Initialized
DEBUG - 2021-06-30 07:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:25:14 --> Input Class Initialized
INFO - 2021-06-30 07:25:14 --> Language Class Initialized
INFO - 2021-06-30 07:25:14 --> Loader Class Initialized
INFO - 2021-06-30 07:25:14 --> Helper loaded: html_helper
INFO - 2021-06-30 07:25:14 --> Helper loaded: url_helper
INFO - 2021-06-30 07:25:14 --> Helper loaded: form_helper
INFO - 2021-06-30 07:25:14 --> Database Driver Class Initialized
INFO - 2021-06-30 07:25:14 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:25:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:25:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:25:14 --> Encryption Class Initialized
INFO - 2021-06-30 07:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:25:14 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:25:14 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:25:14 --> Model "user_model" initialized
INFO - 2021-06-30 07:25:14 --> Model "role_model" initialized
INFO - 2021-06-30 07:25:14 --> Controller Class Initialized
INFO - 2021-06-30 07:25:14 --> Helper loaded: language_helper
INFO - 2021-06-30 07:25:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:25:14 --> Model "Customer_model" initialized
ERROR - 2021-06-30 07:25:14 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server][SQL Server]Invalid object name '[prosoft_testdb].[dbo].[CUSTOMER]'. - Invalid query: INSERT INTO "[prosoft_testdb]"."[dbo]"."[CUSTOMER]" ("customer_id", "customer_name", "Customer_Address", "Customer_City", "Customer_State", "Customer_Country", "GSTIN_No", "PAN_No", "TAN_No") VALUES ('02a13c6a-b664-49b9-ad96-129ef2efaa1d', 'test', 'test', 'test', 'test', 'test', 'test', 'test', 'test')
INFO - 2021-06-30 07:25:14 --> Language file loaded: language/english/db_lang.php
INFO - 2021-06-30 07:25:26 --> Config Class Initialized
INFO - 2021-06-30 07:25:26 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:25:26 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:25:26 --> Utf8 Class Initialized
INFO - 2021-06-30 07:25:26 --> URI Class Initialized
INFO - 2021-06-30 07:25:26 --> Router Class Initialized
INFO - 2021-06-30 07:25:26 --> Output Class Initialized
INFO - 2021-06-30 07:25:26 --> Security Class Initialized
DEBUG - 2021-06-30 07:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:25:26 --> Input Class Initialized
INFO - 2021-06-30 07:25:26 --> Language Class Initialized
INFO - 2021-06-30 07:25:26 --> Loader Class Initialized
INFO - 2021-06-30 07:25:26 --> Helper loaded: html_helper
INFO - 2021-06-30 07:25:26 --> Helper loaded: url_helper
INFO - 2021-06-30 07:25:27 --> Helper loaded: form_helper
INFO - 2021-06-30 07:25:27 --> Database Driver Class Initialized
INFO - 2021-06-30 07:25:27 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:25:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:25:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:25:27 --> Encryption Class Initialized
INFO - 2021-06-30 07:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:25:27 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:25:27 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:25:27 --> Model "user_model" initialized
INFO - 2021-06-30 07:25:27 --> Model "role_model" initialized
INFO - 2021-06-30 07:25:27 --> Controller Class Initialized
INFO - 2021-06-30 07:25:27 --> Helper loaded: language_helper
INFO - 2021-06-30 07:25:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:25:27 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:25:27 --> Model "Product_model" initialized
INFO - 2021-06-30 07:25:27 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:25:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:25:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:25:27 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:25:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:25:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:25:27 --> Final output sent to browser
DEBUG - 2021-06-30 07:25:27 --> Total execution time: 0.0703
INFO - 2021-06-30 07:26:24 --> Config Class Initialized
INFO - 2021-06-30 07:26:24 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:26:24 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:26:24 --> Utf8 Class Initialized
INFO - 2021-06-30 07:26:24 --> URI Class Initialized
INFO - 2021-06-30 07:26:24 --> Router Class Initialized
INFO - 2021-06-30 07:26:24 --> Output Class Initialized
INFO - 2021-06-30 07:26:24 --> Security Class Initialized
DEBUG - 2021-06-30 07:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:26:24 --> Input Class Initialized
INFO - 2021-06-30 07:26:24 --> Language Class Initialized
INFO - 2021-06-30 07:26:24 --> Loader Class Initialized
INFO - 2021-06-30 07:26:24 --> Helper loaded: html_helper
INFO - 2021-06-30 07:26:24 --> Helper loaded: url_helper
INFO - 2021-06-30 07:26:24 --> Helper loaded: form_helper
INFO - 2021-06-30 07:26:24 --> Database Driver Class Initialized
INFO - 2021-06-30 07:26:24 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:26:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:26:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:26:24 --> Encryption Class Initialized
INFO - 2021-06-30 07:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:26:24 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:26:24 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:26:24 --> Model "user_model" initialized
INFO - 2021-06-30 07:26:24 --> Model "role_model" initialized
INFO - 2021-06-30 07:26:24 --> Controller Class Initialized
INFO - 2021-06-30 07:26:24 --> Helper loaded: language_helper
INFO - 2021-06-30 07:26:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:26:24 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:26:24 --> Final output sent to browser
DEBUG - 2021-06-30 07:26:24 --> Total execution time: 0.0704
INFO - 2021-06-30 07:27:41 --> Config Class Initialized
INFO - 2021-06-30 07:27:41 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:27:41 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:27:41 --> Utf8 Class Initialized
INFO - 2021-06-30 07:27:41 --> URI Class Initialized
INFO - 2021-06-30 07:27:41 --> Router Class Initialized
INFO - 2021-06-30 07:27:41 --> Output Class Initialized
INFO - 2021-06-30 07:27:41 --> Security Class Initialized
DEBUG - 2021-06-30 07:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:27:41 --> Input Class Initialized
INFO - 2021-06-30 07:27:41 --> Language Class Initialized
INFO - 2021-06-30 07:27:41 --> Loader Class Initialized
INFO - 2021-06-30 07:27:41 --> Helper loaded: html_helper
INFO - 2021-06-30 07:27:41 --> Helper loaded: url_helper
INFO - 2021-06-30 07:27:41 --> Helper loaded: form_helper
INFO - 2021-06-30 07:27:41 --> Database Driver Class Initialized
INFO - 2021-06-30 07:27:41 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:27:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:27:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:27:41 --> Encryption Class Initialized
INFO - 2021-06-30 07:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:27:41 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:27:41 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:27:41 --> Model "user_model" initialized
INFO - 2021-06-30 07:27:41 --> Model "role_model" initialized
INFO - 2021-06-30 07:27:41 --> Controller Class Initialized
INFO - 2021-06-30 07:27:41 --> Helper loaded: language_helper
INFO - 2021-06-30 07:27:41 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:27:41 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:27:41 --> Model "Product_model" initialized
INFO - 2021-06-30 07:27:41 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:27:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:27:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:27:41 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:27:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:27:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:27:41 --> Final output sent to browser
DEBUG - 2021-06-30 07:27:41 --> Total execution time: 0.0756
INFO - 2021-06-30 07:30:02 --> Config Class Initialized
INFO - 2021-06-30 07:30:02 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:30:02 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:30:02 --> Utf8 Class Initialized
INFO - 2021-06-30 07:30:02 --> URI Class Initialized
INFO - 2021-06-30 07:30:02 --> Router Class Initialized
INFO - 2021-06-30 07:30:02 --> Output Class Initialized
INFO - 2021-06-30 07:30:02 --> Security Class Initialized
DEBUG - 2021-06-30 07:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:30:02 --> Input Class Initialized
INFO - 2021-06-30 07:30:02 --> Language Class Initialized
INFO - 2021-06-30 07:30:02 --> Loader Class Initialized
INFO - 2021-06-30 07:30:02 --> Helper loaded: html_helper
INFO - 2021-06-30 07:30:02 --> Helper loaded: url_helper
INFO - 2021-06-30 07:30:02 --> Helper loaded: form_helper
INFO - 2021-06-30 07:30:02 --> Database Driver Class Initialized
INFO - 2021-06-30 07:30:02 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:30:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:30:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:30:02 --> Encryption Class Initialized
INFO - 2021-06-30 07:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:30:02 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:30:02 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:30:02 --> Model "user_model" initialized
INFO - 2021-06-30 07:30:02 --> Model "role_model" initialized
INFO - 2021-06-30 07:30:02 --> Controller Class Initialized
INFO - 2021-06-30 07:30:02 --> Helper loaded: language_helper
INFO - 2021-06-30 07:30:02 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:30:02 --> Model "Product_model" initialized
INFO - 2021-06-30 07:30:02 --> Final output sent to browser
DEBUG - 2021-06-30 07:30:02 --> Total execution time: 0.1079
INFO - 2021-06-30 07:30:22 --> Config Class Initialized
INFO - 2021-06-30 07:30:22 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:30:22 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:30:22 --> Utf8 Class Initialized
INFO - 2021-06-30 07:30:22 --> URI Class Initialized
INFO - 2021-06-30 07:30:22 --> Router Class Initialized
INFO - 2021-06-30 07:30:22 --> Output Class Initialized
INFO - 2021-06-30 07:30:22 --> Security Class Initialized
DEBUG - 2021-06-30 07:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:30:22 --> Input Class Initialized
INFO - 2021-06-30 07:30:22 --> Language Class Initialized
INFO - 2021-06-30 07:30:22 --> Loader Class Initialized
INFO - 2021-06-30 07:30:22 --> Helper loaded: html_helper
INFO - 2021-06-30 07:30:22 --> Helper loaded: url_helper
INFO - 2021-06-30 07:30:22 --> Helper loaded: form_helper
INFO - 2021-06-30 07:30:22 --> Database Driver Class Initialized
INFO - 2021-06-30 07:30:22 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:30:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:30:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:30:22 --> Encryption Class Initialized
INFO - 2021-06-30 07:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:30:22 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:30:22 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:30:22 --> Model "user_model" initialized
INFO - 2021-06-30 07:30:22 --> Model "role_model" initialized
INFO - 2021-06-30 07:30:22 --> Controller Class Initialized
INFO - 2021-06-30 07:30:22 --> Helper loaded: language_helper
INFO - 2021-06-30 07:30:22 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:30:22 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:30:22 --> Model "Product_model" initialized
INFO - 2021-06-30 07:30:22 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:30:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:30:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:30:22 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:30:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:30:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:30:22 --> Final output sent to browser
DEBUG - 2021-06-30 07:30:22 --> Total execution time: 0.0737
INFO - 2021-06-30 07:31:30 --> Config Class Initialized
INFO - 2021-06-30 07:31:30 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:31:30 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:31:30 --> Utf8 Class Initialized
INFO - 2021-06-30 07:31:30 --> URI Class Initialized
INFO - 2021-06-30 07:31:30 --> Router Class Initialized
INFO - 2021-06-30 07:31:30 --> Output Class Initialized
INFO - 2021-06-30 07:31:30 --> Security Class Initialized
DEBUG - 2021-06-30 07:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:31:30 --> Input Class Initialized
INFO - 2021-06-30 07:31:30 --> Language Class Initialized
INFO - 2021-06-30 07:31:30 --> Loader Class Initialized
INFO - 2021-06-30 07:31:30 --> Helper loaded: html_helper
INFO - 2021-06-30 07:31:30 --> Helper loaded: url_helper
INFO - 2021-06-30 07:31:30 --> Helper loaded: form_helper
INFO - 2021-06-30 07:31:30 --> Database Driver Class Initialized
INFO - 2021-06-30 07:31:30 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:31:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:31:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:31:30 --> Encryption Class Initialized
INFO - 2021-06-30 07:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:31:30 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:31:30 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:31:30 --> Model "user_model" initialized
INFO - 2021-06-30 07:31:30 --> Model "role_model" initialized
INFO - 2021-06-30 07:31:30 --> Controller Class Initialized
INFO - 2021-06-30 07:31:30 --> Helper loaded: language_helper
INFO - 2021-06-30 07:31:30 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:31:30 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:31:30 --> Model "Product_model" initialized
INFO - 2021-06-30 07:31:30 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:31:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:31:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:31:30 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:31:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:31:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:31:30 --> Final output sent to browser
DEBUG - 2021-06-30 07:31:30 --> Total execution time: 0.1273
INFO - 2021-06-30 07:32:02 --> Config Class Initialized
INFO - 2021-06-30 07:32:02 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:32:02 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:32:02 --> Utf8 Class Initialized
INFO - 2021-06-30 07:32:02 --> URI Class Initialized
INFO - 2021-06-30 07:32:02 --> Router Class Initialized
INFO - 2021-06-30 07:32:02 --> Output Class Initialized
INFO - 2021-06-30 07:32:02 --> Security Class Initialized
DEBUG - 2021-06-30 07:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:32:02 --> Input Class Initialized
INFO - 2021-06-30 07:32:02 --> Language Class Initialized
INFO - 2021-06-30 07:32:02 --> Loader Class Initialized
INFO - 2021-06-30 07:32:02 --> Helper loaded: html_helper
INFO - 2021-06-30 07:32:02 --> Helper loaded: url_helper
INFO - 2021-06-30 07:32:02 --> Helper loaded: form_helper
INFO - 2021-06-30 07:32:02 --> Database Driver Class Initialized
INFO - 2021-06-30 07:32:02 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:32:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:32:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:32:02 --> Encryption Class Initialized
INFO - 2021-06-30 07:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:32:02 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:32:02 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:32:02 --> Model "user_model" initialized
INFO - 2021-06-30 07:32:02 --> Model "role_model" initialized
INFO - 2021-06-30 07:32:02 --> Controller Class Initialized
INFO - 2021-06-30 07:32:02 --> Helper loaded: language_helper
INFO - 2021-06-30 07:32:02 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:32:02 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:32:02 --> Model "Product_model" initialized
INFO - 2021-06-30 07:32:02 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:32:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:32:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:32:02 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:32:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:32:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:32:02 --> Final output sent to browser
DEBUG - 2021-06-30 07:32:02 --> Total execution time: 0.0763
INFO - 2021-06-30 07:32:04 --> Config Class Initialized
INFO - 2021-06-30 07:32:04 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:32:04 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:32:04 --> Utf8 Class Initialized
INFO - 2021-06-30 07:32:04 --> URI Class Initialized
INFO - 2021-06-30 07:32:04 --> Router Class Initialized
INFO - 2021-06-30 07:32:04 --> Output Class Initialized
INFO - 2021-06-30 07:32:04 --> Security Class Initialized
DEBUG - 2021-06-30 07:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:32:04 --> Input Class Initialized
INFO - 2021-06-30 07:32:04 --> Language Class Initialized
INFO - 2021-06-30 07:32:04 --> Loader Class Initialized
INFO - 2021-06-30 07:32:04 --> Helper loaded: html_helper
INFO - 2021-06-30 07:32:04 --> Helper loaded: url_helper
INFO - 2021-06-30 07:32:04 --> Helper loaded: form_helper
INFO - 2021-06-30 07:32:04 --> Database Driver Class Initialized
INFO - 2021-06-30 07:32:04 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:32:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:32:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:32:04 --> Encryption Class Initialized
INFO - 2021-06-30 07:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:32:04 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:32:04 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:32:04 --> Model "user_model" initialized
INFO - 2021-06-30 07:32:04 --> Model "role_model" initialized
INFO - 2021-06-30 07:32:04 --> Controller Class Initialized
INFO - 2021-06-30 07:32:04 --> Helper loaded: language_helper
INFO - 2021-06-30 07:32:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:32:04 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:32:04 --> Model "Product_model" initialized
INFO - 2021-06-30 07:32:04 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:32:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:32:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:32:04 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:32:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:32:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:32:04 --> Final output sent to browser
DEBUG - 2021-06-30 07:32:04 --> Total execution time: 0.0742
INFO - 2021-06-30 07:32:06 --> Config Class Initialized
INFO - 2021-06-30 07:32:06 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:32:06 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:32:06 --> Utf8 Class Initialized
INFO - 2021-06-30 07:32:06 --> URI Class Initialized
INFO - 2021-06-30 07:32:06 --> Router Class Initialized
INFO - 2021-06-30 07:32:06 --> Output Class Initialized
INFO - 2021-06-30 07:32:06 --> Security Class Initialized
DEBUG - 2021-06-30 07:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:32:06 --> Input Class Initialized
INFO - 2021-06-30 07:32:06 --> Language Class Initialized
INFO - 2021-06-30 07:32:06 --> Loader Class Initialized
INFO - 2021-06-30 07:32:06 --> Helper loaded: html_helper
INFO - 2021-06-30 07:32:06 --> Helper loaded: url_helper
INFO - 2021-06-30 07:32:06 --> Helper loaded: form_helper
INFO - 2021-06-30 07:32:06 --> Database Driver Class Initialized
INFO - 2021-06-30 07:32:06 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:32:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:32:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:32:06 --> Encryption Class Initialized
INFO - 2021-06-30 07:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:32:06 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:32:06 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:32:06 --> Model "user_model" initialized
INFO - 2021-06-30 07:32:06 --> Model "role_model" initialized
INFO - 2021-06-30 07:32:06 --> Controller Class Initialized
INFO - 2021-06-30 07:32:06 --> Helper loaded: language_helper
INFO - 2021-06-30 07:32:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:32:06 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:32:06 --> Model "Product_model" initialized
INFO - 2021-06-30 07:32:06 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:32:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:32:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:32:06 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:32:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:32:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:32:06 --> Final output sent to browser
DEBUG - 2021-06-30 07:32:06 --> Total execution time: 0.0728
INFO - 2021-06-30 07:32:08 --> Config Class Initialized
INFO - 2021-06-30 07:32:08 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:32:08 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:32:08 --> Utf8 Class Initialized
INFO - 2021-06-30 07:32:08 --> URI Class Initialized
INFO - 2021-06-30 07:32:08 --> Router Class Initialized
INFO - 2021-06-30 07:32:08 --> Output Class Initialized
INFO - 2021-06-30 07:32:08 --> Security Class Initialized
DEBUG - 2021-06-30 07:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:32:08 --> Input Class Initialized
INFO - 2021-06-30 07:32:08 --> Language Class Initialized
INFO - 2021-06-30 07:32:08 --> Loader Class Initialized
INFO - 2021-06-30 07:32:08 --> Helper loaded: html_helper
INFO - 2021-06-30 07:32:08 --> Helper loaded: url_helper
INFO - 2021-06-30 07:32:08 --> Helper loaded: form_helper
INFO - 2021-06-30 07:32:08 --> Database Driver Class Initialized
INFO - 2021-06-30 07:32:08 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:32:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:32:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:32:08 --> Encryption Class Initialized
INFO - 2021-06-30 07:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:32:08 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:32:08 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:32:08 --> Model "user_model" initialized
INFO - 2021-06-30 07:32:08 --> Model "role_model" initialized
INFO - 2021-06-30 07:32:08 --> Controller Class Initialized
INFO - 2021-06-30 07:32:08 --> Helper loaded: language_helper
INFO - 2021-06-30 07:32:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:32:08 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:32:08 --> Model "Product_model" initialized
INFO - 2021-06-30 07:32:08 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:32:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:32:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:32:08 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:32:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:32:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:32:08 --> Final output sent to browser
DEBUG - 2021-06-30 07:32:08 --> Total execution time: 0.0757
INFO - 2021-06-30 07:32:09 --> Config Class Initialized
INFO - 2021-06-30 07:32:09 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:32:09 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:32:09 --> Utf8 Class Initialized
INFO - 2021-06-30 07:32:09 --> URI Class Initialized
INFO - 2021-06-30 07:32:09 --> Router Class Initialized
INFO - 2021-06-30 07:32:09 --> Output Class Initialized
INFO - 2021-06-30 07:32:09 --> Security Class Initialized
DEBUG - 2021-06-30 07:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:32:09 --> Input Class Initialized
INFO - 2021-06-30 07:32:09 --> Language Class Initialized
INFO - 2021-06-30 07:32:09 --> Loader Class Initialized
INFO - 2021-06-30 07:32:09 --> Helper loaded: html_helper
INFO - 2021-06-30 07:32:09 --> Helper loaded: url_helper
INFO - 2021-06-30 07:32:09 --> Helper loaded: form_helper
INFO - 2021-06-30 07:32:09 --> Database Driver Class Initialized
INFO - 2021-06-30 07:32:09 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:32:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:32:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:32:09 --> Encryption Class Initialized
INFO - 2021-06-30 07:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:32:09 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:32:09 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:32:09 --> Model "user_model" initialized
INFO - 2021-06-30 07:32:09 --> Model "role_model" initialized
INFO - 2021-06-30 07:32:09 --> Controller Class Initialized
INFO - 2021-06-30 07:32:09 --> Helper loaded: language_helper
INFO - 2021-06-30 07:32:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:32:09 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:32:09 --> Model "Product_model" initialized
INFO - 2021-06-30 07:32:09 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:32:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:32:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:32:09 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:32:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:32:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:32:09 --> Final output sent to browser
DEBUG - 2021-06-30 07:32:09 --> Total execution time: 0.0725
INFO - 2021-06-30 07:32:36 --> Config Class Initialized
INFO - 2021-06-30 07:32:36 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:32:36 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:32:36 --> Utf8 Class Initialized
INFO - 2021-06-30 07:32:36 --> URI Class Initialized
INFO - 2021-06-30 07:32:36 --> Router Class Initialized
INFO - 2021-06-30 07:32:36 --> Output Class Initialized
INFO - 2021-06-30 07:32:36 --> Security Class Initialized
DEBUG - 2021-06-30 07:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:32:36 --> Input Class Initialized
INFO - 2021-06-30 07:32:36 --> Language Class Initialized
INFO - 2021-06-30 07:32:36 --> Loader Class Initialized
INFO - 2021-06-30 07:32:36 --> Helper loaded: html_helper
INFO - 2021-06-30 07:32:36 --> Helper loaded: url_helper
INFO - 2021-06-30 07:32:36 --> Helper loaded: form_helper
INFO - 2021-06-30 07:32:36 --> Database Driver Class Initialized
INFO - 2021-06-30 07:32:36 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:32:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:32:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:32:36 --> Encryption Class Initialized
INFO - 2021-06-30 07:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:32:36 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:32:36 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:32:36 --> Model "user_model" initialized
INFO - 2021-06-30 07:32:36 --> Model "role_model" initialized
INFO - 2021-06-30 07:32:36 --> Controller Class Initialized
INFO - 2021-06-30 07:32:36 --> Helper loaded: language_helper
INFO - 2021-06-30 07:32:36 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:32:36 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:32:36 --> Model "Product_model" initialized
INFO - 2021-06-30 07:32:36 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:32:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:32:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:32:36 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:32:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:32:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:32:36 --> Final output sent to browser
DEBUG - 2021-06-30 07:32:36 --> Total execution time: 0.1122
INFO - 2021-06-30 07:34:25 --> Config Class Initialized
INFO - 2021-06-30 07:34:25 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:34:25 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:34:25 --> Utf8 Class Initialized
INFO - 2021-06-30 07:34:25 --> URI Class Initialized
INFO - 2021-06-30 07:34:25 --> Router Class Initialized
INFO - 2021-06-30 07:34:25 --> Output Class Initialized
INFO - 2021-06-30 07:34:25 --> Security Class Initialized
DEBUG - 2021-06-30 07:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:34:25 --> Input Class Initialized
INFO - 2021-06-30 07:34:25 --> Language Class Initialized
INFO - 2021-06-30 07:34:25 --> Loader Class Initialized
INFO - 2021-06-30 07:34:25 --> Helper loaded: html_helper
INFO - 2021-06-30 07:34:25 --> Helper loaded: url_helper
INFO - 2021-06-30 07:34:25 --> Helper loaded: form_helper
INFO - 2021-06-30 07:34:25 --> Database Driver Class Initialized
INFO - 2021-06-30 07:34:25 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:34:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:34:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:34:25 --> Encryption Class Initialized
INFO - 2021-06-30 07:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:34:25 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:34:25 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:34:25 --> Model "user_model" initialized
INFO - 2021-06-30 07:34:25 --> Model "role_model" initialized
INFO - 2021-06-30 07:34:25 --> Controller Class Initialized
INFO - 2021-06-30 07:34:25 --> Helper loaded: language_helper
INFO - 2021-06-30 07:34:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:34:25 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:34:25 --> Model "Product_model" initialized
INFO - 2021-06-30 07:34:25 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:34:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:34:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:34:25 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:34:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:34:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:34:25 --> Final output sent to browser
DEBUG - 2021-06-30 07:34:25 --> Total execution time: 0.1239
INFO - 2021-06-30 07:34:46 --> Config Class Initialized
INFO - 2021-06-30 07:34:46 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:34:46 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:34:46 --> Utf8 Class Initialized
INFO - 2021-06-30 07:34:46 --> URI Class Initialized
INFO - 2021-06-30 07:34:46 --> Router Class Initialized
INFO - 2021-06-30 07:34:46 --> Output Class Initialized
INFO - 2021-06-30 07:34:46 --> Security Class Initialized
DEBUG - 2021-06-30 07:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:34:46 --> Input Class Initialized
INFO - 2021-06-30 07:34:46 --> Language Class Initialized
INFO - 2021-06-30 07:34:46 --> Loader Class Initialized
INFO - 2021-06-30 07:34:46 --> Helper loaded: html_helper
INFO - 2021-06-30 07:34:46 --> Helper loaded: url_helper
INFO - 2021-06-30 07:34:46 --> Helper loaded: form_helper
INFO - 2021-06-30 07:34:46 --> Database Driver Class Initialized
INFO - 2021-06-30 07:34:46 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:34:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:34:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:34:46 --> Encryption Class Initialized
INFO - 2021-06-30 07:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:34:46 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:34:46 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:34:46 --> Model "user_model" initialized
INFO - 2021-06-30 07:34:46 --> Model "role_model" initialized
INFO - 2021-06-30 07:34:46 --> Controller Class Initialized
INFO - 2021-06-30 07:34:46 --> Helper loaded: language_helper
INFO - 2021-06-30 07:34:46 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:34:46 --> Model "Customer_model" initialized
ERROR - 2021-06-30 07:34:46 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server][SQL Server]Invalid object name '[prosoft_testdb].[dbo].[CUSTOMER]'. - Invalid query: INSERT INTO "[prosoft_testdb]"."[dbo]"."[CUSTOMER]" ("customer_id", "customer_name", "Customer_Address", "Customer_City", "Customer_State", "Customer_Country", "GSTIN_No", "PAN_No", "TAN_No") VALUES ('ebe64a7f-56a0-45d6-9107-b4a03be92d32', 'test', 'test', 'test', 'test', 'test', 'test', 'test', 'test')
INFO - 2021-06-30 07:34:46 --> Language file loaded: language/english/db_lang.php
INFO - 2021-06-30 07:36:05 --> Config Class Initialized
INFO - 2021-06-30 07:36:05 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:36:05 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:36:05 --> Utf8 Class Initialized
INFO - 2021-06-30 07:36:05 --> URI Class Initialized
INFO - 2021-06-30 07:36:05 --> Router Class Initialized
INFO - 2021-06-30 07:36:05 --> Output Class Initialized
INFO - 2021-06-30 07:36:05 --> Security Class Initialized
DEBUG - 2021-06-30 07:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:36:05 --> Input Class Initialized
INFO - 2021-06-30 07:36:05 --> Language Class Initialized
INFO - 2021-06-30 07:36:05 --> Loader Class Initialized
INFO - 2021-06-30 07:36:05 --> Helper loaded: html_helper
INFO - 2021-06-30 07:36:05 --> Helper loaded: url_helper
INFO - 2021-06-30 07:36:05 --> Helper loaded: form_helper
INFO - 2021-06-30 07:36:05 --> Database Driver Class Initialized
INFO - 2021-06-30 07:36:05 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:36:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:36:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:36:05 --> Encryption Class Initialized
INFO - 2021-06-30 07:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:36:05 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:36:05 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:36:05 --> Model "user_model" initialized
INFO - 2021-06-30 07:36:05 --> Model "role_model" initialized
INFO - 2021-06-30 07:36:05 --> Controller Class Initialized
INFO - 2021-06-30 07:36:05 --> Helper loaded: language_helper
INFO - 2021-06-30 07:36:05 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:36:05 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:36:05 --> Model "Product_model" initialized
INFO - 2021-06-30 07:36:05 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:36:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:36:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:36:05 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:36:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:36:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:36:05 --> Final output sent to browser
DEBUG - 2021-06-30 07:36:05 --> Total execution time: 0.1199
INFO - 2021-06-30 07:37:45 --> Config Class Initialized
INFO - 2021-06-30 07:37:45 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:37:45 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:37:45 --> Utf8 Class Initialized
INFO - 2021-06-30 07:37:45 --> URI Class Initialized
INFO - 2021-06-30 07:37:45 --> Router Class Initialized
INFO - 2021-06-30 07:37:45 --> Output Class Initialized
INFO - 2021-06-30 07:37:45 --> Security Class Initialized
DEBUG - 2021-06-30 07:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:37:45 --> Input Class Initialized
INFO - 2021-06-30 07:37:45 --> Language Class Initialized
INFO - 2021-06-30 07:37:45 --> Loader Class Initialized
INFO - 2021-06-30 07:37:45 --> Helper loaded: html_helper
INFO - 2021-06-30 07:37:45 --> Helper loaded: url_helper
INFO - 2021-06-30 07:37:45 --> Helper loaded: form_helper
INFO - 2021-06-30 07:37:45 --> Database Driver Class Initialized
INFO - 2021-06-30 07:37:45 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:37:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:37:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:37:45 --> Encryption Class Initialized
INFO - 2021-06-30 07:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:37:45 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:37:45 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:37:45 --> Model "user_model" initialized
INFO - 2021-06-30 07:37:45 --> Model "role_model" initialized
INFO - 2021-06-30 07:37:45 --> Controller Class Initialized
INFO - 2021-06-30 07:37:45 --> Helper loaded: language_helper
INFO - 2021-06-30 07:37:45 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:37:45 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:37:45 --> Model "Product_model" initialized
INFO - 2021-06-30 07:37:45 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:37:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:37:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:37:45 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:37:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:37:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:37:45 --> Final output sent to browser
DEBUG - 2021-06-30 07:37:45 --> Total execution time: 0.1324
INFO - 2021-06-30 07:38:06 --> Config Class Initialized
INFO - 2021-06-30 07:38:06 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:38:06 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:38:06 --> Utf8 Class Initialized
INFO - 2021-06-30 07:38:06 --> URI Class Initialized
INFO - 2021-06-30 07:38:06 --> Router Class Initialized
INFO - 2021-06-30 07:38:06 --> Output Class Initialized
INFO - 2021-06-30 07:38:06 --> Security Class Initialized
DEBUG - 2021-06-30 07:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:38:06 --> Input Class Initialized
INFO - 2021-06-30 07:38:06 --> Language Class Initialized
INFO - 2021-06-30 07:38:06 --> Loader Class Initialized
INFO - 2021-06-30 07:38:06 --> Helper loaded: html_helper
INFO - 2021-06-30 07:38:06 --> Helper loaded: url_helper
INFO - 2021-06-30 07:38:06 --> Helper loaded: form_helper
INFO - 2021-06-30 07:38:06 --> Database Driver Class Initialized
INFO - 2021-06-30 07:38:06 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:38:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:38:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:38:06 --> Encryption Class Initialized
INFO - 2021-06-30 07:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:38:06 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:38:06 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:38:06 --> Model "user_model" initialized
INFO - 2021-06-30 07:38:06 --> Model "role_model" initialized
INFO - 2021-06-30 07:38:06 --> Controller Class Initialized
INFO - 2021-06-30 07:38:06 --> Helper loaded: language_helper
INFO - 2021-06-30 07:38:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:38:06 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:38:06 --> Model "Product_model" initialized
INFO - 2021-06-30 07:38:06 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:38:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:38:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:38:06 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:38:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:38:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:38:06 --> Final output sent to browser
DEBUG - 2021-06-30 07:38:06 --> Total execution time: 0.1228
INFO - 2021-06-30 07:38:19 --> Config Class Initialized
INFO - 2021-06-30 07:38:19 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:38:19 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:38:19 --> Utf8 Class Initialized
INFO - 2021-06-30 07:38:19 --> URI Class Initialized
INFO - 2021-06-30 07:38:19 --> Router Class Initialized
INFO - 2021-06-30 07:38:19 --> Output Class Initialized
INFO - 2021-06-30 07:38:19 --> Security Class Initialized
DEBUG - 2021-06-30 07:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:38:19 --> Input Class Initialized
INFO - 2021-06-30 07:38:19 --> Language Class Initialized
INFO - 2021-06-30 07:38:19 --> Loader Class Initialized
INFO - 2021-06-30 07:38:19 --> Helper loaded: html_helper
INFO - 2021-06-30 07:38:19 --> Helper loaded: url_helper
INFO - 2021-06-30 07:38:19 --> Helper loaded: form_helper
INFO - 2021-06-30 07:38:19 --> Database Driver Class Initialized
INFO - 2021-06-30 07:38:19 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:38:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:38:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:38:19 --> Encryption Class Initialized
INFO - 2021-06-30 07:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:38:19 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:38:19 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:38:19 --> Model "user_model" initialized
INFO - 2021-06-30 07:38:19 --> Model "role_model" initialized
INFO - 2021-06-30 07:38:19 --> Controller Class Initialized
INFO - 2021-06-30 07:38:19 --> Helper loaded: language_helper
INFO - 2021-06-30 07:38:19 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:38:19 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:38:19 --> Model "Product_model" initialized
INFO - 2021-06-30 07:38:19 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:38:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:38:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:38:19 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:38:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:38:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:38:19 --> Final output sent to browser
DEBUG - 2021-06-30 07:38:19 --> Total execution time: 0.0784
INFO - 2021-06-30 07:39:13 --> Config Class Initialized
INFO - 2021-06-30 07:39:13 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:39:13 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:39:13 --> Utf8 Class Initialized
INFO - 2021-06-30 07:39:13 --> URI Class Initialized
INFO - 2021-06-30 07:39:13 --> Router Class Initialized
INFO - 2021-06-30 07:39:13 --> Output Class Initialized
INFO - 2021-06-30 07:39:13 --> Security Class Initialized
DEBUG - 2021-06-30 07:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:39:13 --> Input Class Initialized
INFO - 2021-06-30 07:39:13 --> Language Class Initialized
INFO - 2021-06-30 07:39:13 --> Loader Class Initialized
INFO - 2021-06-30 07:39:13 --> Helper loaded: html_helper
INFO - 2021-06-30 07:39:13 --> Helper loaded: url_helper
INFO - 2021-06-30 07:39:13 --> Helper loaded: form_helper
INFO - 2021-06-30 07:39:13 --> Database Driver Class Initialized
INFO - 2021-06-30 07:39:13 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:39:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:39:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:39:13 --> Encryption Class Initialized
INFO - 2021-06-30 07:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:39:13 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:39:13 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:39:13 --> Model "user_model" initialized
INFO - 2021-06-30 07:39:13 --> Model "role_model" initialized
INFO - 2021-06-30 07:39:13 --> Controller Class Initialized
INFO - 2021-06-30 07:39:13 --> Helper loaded: language_helper
INFO - 2021-06-30 07:39:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:39:13 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:39:13 --> Model "Product_model" initialized
INFO - 2021-06-30 07:39:13 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:39:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:39:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:39:13 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:39:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:39:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:39:13 --> Final output sent to browser
DEBUG - 2021-06-30 07:39:13 --> Total execution time: 0.1169
INFO - 2021-06-30 07:40:27 --> Config Class Initialized
INFO - 2021-06-30 07:40:27 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:40:27 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:40:27 --> Utf8 Class Initialized
INFO - 2021-06-30 07:40:27 --> URI Class Initialized
INFO - 2021-06-30 07:40:27 --> Router Class Initialized
INFO - 2021-06-30 07:40:27 --> Output Class Initialized
INFO - 2021-06-30 07:40:27 --> Security Class Initialized
DEBUG - 2021-06-30 07:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:40:27 --> Input Class Initialized
INFO - 2021-06-30 07:40:27 --> Language Class Initialized
INFO - 2021-06-30 07:40:27 --> Loader Class Initialized
INFO - 2021-06-30 07:40:27 --> Helper loaded: html_helper
INFO - 2021-06-30 07:40:27 --> Helper loaded: url_helper
INFO - 2021-06-30 07:40:27 --> Helper loaded: form_helper
INFO - 2021-06-30 07:40:27 --> Database Driver Class Initialized
INFO - 2021-06-30 07:40:27 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:40:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:40:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:40:27 --> Encryption Class Initialized
INFO - 2021-06-30 07:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:40:27 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:40:27 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:40:27 --> Model "user_model" initialized
INFO - 2021-06-30 07:40:27 --> Model "role_model" initialized
INFO - 2021-06-30 07:40:27 --> Controller Class Initialized
INFO - 2021-06-30 07:40:27 --> Helper loaded: language_helper
INFO - 2021-06-30 07:40:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:40:27 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:40:27 --> Model "Product_model" initialized
INFO - 2021-06-30 07:40:27 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:40:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:40:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:40:27 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:40:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:40:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:40:27 --> Final output sent to browser
DEBUG - 2021-06-30 07:40:27 --> Total execution time: 0.1225
INFO - 2021-06-30 07:40:52 --> Config Class Initialized
INFO - 2021-06-30 07:40:52 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:40:52 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:40:52 --> Utf8 Class Initialized
INFO - 2021-06-30 07:40:52 --> URI Class Initialized
INFO - 2021-06-30 07:40:52 --> Router Class Initialized
INFO - 2021-06-30 07:40:52 --> Output Class Initialized
INFO - 2021-06-30 07:40:52 --> Security Class Initialized
DEBUG - 2021-06-30 07:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:40:52 --> Input Class Initialized
INFO - 2021-06-30 07:40:52 --> Language Class Initialized
INFO - 2021-06-30 07:40:52 --> Loader Class Initialized
INFO - 2021-06-30 07:40:52 --> Helper loaded: html_helper
INFO - 2021-06-30 07:40:52 --> Helper loaded: url_helper
INFO - 2021-06-30 07:40:52 --> Helper loaded: form_helper
INFO - 2021-06-30 07:40:52 --> Database Driver Class Initialized
INFO - 2021-06-30 07:40:52 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:40:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:40:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:40:52 --> Encryption Class Initialized
INFO - 2021-06-30 07:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:40:52 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:40:52 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:40:52 --> Model "user_model" initialized
INFO - 2021-06-30 07:40:52 --> Model "role_model" initialized
INFO - 2021-06-30 07:40:52 --> Controller Class Initialized
INFO - 2021-06-30 07:40:52 --> Helper loaded: language_helper
INFO - 2021-06-30 07:40:52 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:40:52 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:40:52 --> Model "Product_model" initialized
INFO - 2021-06-30 07:40:52 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:40:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:40:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:40:52 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:40:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:40:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:40:52 --> Final output sent to browser
DEBUG - 2021-06-30 07:40:52 --> Total execution time: 0.1129
INFO - 2021-06-30 07:42:19 --> Config Class Initialized
INFO - 2021-06-30 07:42:19 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:42:19 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:42:19 --> Utf8 Class Initialized
INFO - 2021-06-30 07:42:19 --> URI Class Initialized
INFO - 2021-06-30 07:42:19 --> Router Class Initialized
INFO - 2021-06-30 07:42:19 --> Output Class Initialized
INFO - 2021-06-30 07:42:19 --> Security Class Initialized
DEBUG - 2021-06-30 07:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:42:19 --> Input Class Initialized
INFO - 2021-06-30 07:42:19 --> Language Class Initialized
INFO - 2021-06-30 07:42:19 --> Loader Class Initialized
INFO - 2021-06-30 07:42:19 --> Helper loaded: html_helper
INFO - 2021-06-30 07:42:19 --> Helper loaded: url_helper
INFO - 2021-06-30 07:42:19 --> Helper loaded: form_helper
INFO - 2021-06-30 07:42:19 --> Database Driver Class Initialized
INFO - 2021-06-30 07:42:19 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:42:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:42:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:42:19 --> Encryption Class Initialized
INFO - 2021-06-30 07:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:42:19 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:42:19 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:42:19 --> Model "user_model" initialized
INFO - 2021-06-30 07:42:19 --> Model "role_model" initialized
INFO - 2021-06-30 07:42:19 --> Controller Class Initialized
INFO - 2021-06-30 07:42:19 --> Helper loaded: language_helper
INFO - 2021-06-30 07:42:19 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:42:19 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:42:19 --> Model "Product_model" initialized
INFO - 2021-06-30 07:42:19 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:42:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:42:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:42:19 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:42:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:42:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:42:19 --> Final output sent to browser
DEBUG - 2021-06-30 07:42:19 --> Total execution time: 0.1195
INFO - 2021-06-30 07:42:36 --> Config Class Initialized
INFO - 2021-06-30 07:42:36 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:42:36 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:42:36 --> Utf8 Class Initialized
INFO - 2021-06-30 07:42:36 --> URI Class Initialized
INFO - 2021-06-30 07:42:36 --> Router Class Initialized
INFO - 2021-06-30 07:42:36 --> Output Class Initialized
INFO - 2021-06-30 07:42:36 --> Security Class Initialized
DEBUG - 2021-06-30 07:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:42:36 --> Input Class Initialized
INFO - 2021-06-30 07:42:36 --> Language Class Initialized
INFO - 2021-06-30 07:42:36 --> Loader Class Initialized
INFO - 2021-06-30 07:42:36 --> Helper loaded: html_helper
INFO - 2021-06-30 07:42:36 --> Helper loaded: url_helper
INFO - 2021-06-30 07:42:36 --> Helper loaded: form_helper
INFO - 2021-06-30 07:42:36 --> Database Driver Class Initialized
INFO - 2021-06-30 07:42:36 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:42:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:42:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:42:36 --> Encryption Class Initialized
INFO - 2021-06-30 07:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:42:36 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:42:36 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:42:36 --> Model "user_model" initialized
INFO - 2021-06-30 07:42:36 --> Model "role_model" initialized
INFO - 2021-06-30 07:42:36 --> Controller Class Initialized
INFO - 2021-06-30 07:42:36 --> Helper loaded: language_helper
INFO - 2021-06-30 07:42:36 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:42:36 --> Model "Customer_model" initialized
ERROR - 2021-06-30 07:42:36 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server][SQL Server]Invalid object name '[prosoft_testdb].[dbo].[CUSTOMER]'. - Invalid query: INSERT INTO "[prosoft_testdb]"."[dbo]"."[CUSTOMER]" ("customer_id", "customer_name", "Customer_Address", "Customer_City", "Customer_State", "Customer_Country", "GSTIN_No", "PAN_No", "TAN_No") VALUES ('df94c3a4-7f89-499f-80c2-1b1a180561d5', 'test', 'test', 'test', 'test', 'test', 'test', 'test', 'test')
INFO - 2021-06-30 07:42:36 --> Language file loaded: language/english/db_lang.php
INFO - 2021-06-30 07:42:54 --> Config Class Initialized
INFO - 2021-06-30 07:42:54 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:42:54 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:42:54 --> Utf8 Class Initialized
INFO - 2021-06-30 07:42:54 --> URI Class Initialized
INFO - 2021-06-30 07:42:54 --> Router Class Initialized
INFO - 2021-06-30 07:42:54 --> Output Class Initialized
INFO - 2021-06-30 07:42:54 --> Security Class Initialized
DEBUG - 2021-06-30 07:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:42:54 --> Input Class Initialized
INFO - 2021-06-30 07:42:54 --> Language Class Initialized
INFO - 2021-06-30 07:42:54 --> Loader Class Initialized
INFO - 2021-06-30 07:42:54 --> Helper loaded: html_helper
INFO - 2021-06-30 07:42:54 --> Helper loaded: url_helper
INFO - 2021-06-30 07:42:54 --> Helper loaded: form_helper
INFO - 2021-06-30 07:42:54 --> Database Driver Class Initialized
INFO - 2021-06-30 07:42:54 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:42:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:42:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:42:54 --> Encryption Class Initialized
INFO - 2021-06-30 07:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:42:54 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:42:54 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:42:54 --> Model "user_model" initialized
INFO - 2021-06-30 07:42:54 --> Model "role_model" initialized
INFO - 2021-06-30 07:42:54 --> Controller Class Initialized
INFO - 2021-06-30 07:42:54 --> Helper loaded: language_helper
INFO - 2021-06-30 07:42:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:42:54 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:42:54 --> Model "Product_model" initialized
INFO - 2021-06-30 07:42:54 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:42:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:42:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:42:54 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:42:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:42:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:42:54 --> Final output sent to browser
DEBUG - 2021-06-30 07:42:54 --> Total execution time: 0.0693
INFO - 2021-06-30 07:43:14 --> Config Class Initialized
INFO - 2021-06-30 07:43:14 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:43:14 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:43:14 --> Utf8 Class Initialized
INFO - 2021-06-30 07:43:14 --> URI Class Initialized
INFO - 2021-06-30 07:43:14 --> Router Class Initialized
INFO - 2021-06-30 07:43:14 --> Output Class Initialized
INFO - 2021-06-30 07:43:14 --> Security Class Initialized
DEBUG - 2021-06-30 07:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:43:14 --> Input Class Initialized
INFO - 2021-06-30 07:43:14 --> Language Class Initialized
INFO - 2021-06-30 07:43:14 --> Loader Class Initialized
INFO - 2021-06-30 07:43:14 --> Helper loaded: html_helper
INFO - 2021-06-30 07:43:14 --> Helper loaded: url_helper
INFO - 2021-06-30 07:43:14 --> Helper loaded: form_helper
INFO - 2021-06-30 07:43:14 --> Database Driver Class Initialized
INFO - 2021-06-30 07:43:14 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:43:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:43:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:43:14 --> Encryption Class Initialized
INFO - 2021-06-30 07:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:43:14 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:43:14 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:43:14 --> Model "user_model" initialized
INFO - 2021-06-30 07:43:14 --> Model "role_model" initialized
INFO - 2021-06-30 07:43:14 --> Controller Class Initialized
INFO - 2021-06-30 07:43:14 --> Helper loaded: language_helper
INFO - 2021-06-30 07:43:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:43:14 --> Model "Customer_model" initialized
ERROR - 2021-06-30 07:43:14 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server][SQL Server]Invalid object name '[prosoft_testdb].[dbo].[CUSTOMER]'. - Invalid query: INSERT INTO "[prosoft_testdb]"."[dbo]"."[CUSTOMER]" ("customer_id", "customer_name", "Customer_Address", "Customer_City", "Customer_State", "Customer_Country", "GSTIN_No", "PAN_No", "TAN_No") VALUES ('49c1ca73-7d0a-4fd2-8857-726c913fa496', 'test', 'test', 'test', 'test', 'test', 'test', 'test', 'test')
INFO - 2021-06-30 07:43:14 --> Language file loaded: language/english/db_lang.php
INFO - 2021-06-30 07:45:02 --> Config Class Initialized
INFO - 2021-06-30 07:45:02 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:45:02 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:45:02 --> Utf8 Class Initialized
INFO - 2021-06-30 07:45:02 --> URI Class Initialized
INFO - 2021-06-30 07:45:02 --> Router Class Initialized
INFO - 2021-06-30 07:45:02 --> Output Class Initialized
INFO - 2021-06-30 07:45:02 --> Security Class Initialized
DEBUG - 2021-06-30 07:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:45:02 --> Input Class Initialized
INFO - 2021-06-30 07:45:02 --> Language Class Initialized
INFO - 2021-06-30 07:45:02 --> Loader Class Initialized
INFO - 2021-06-30 07:45:02 --> Helper loaded: html_helper
INFO - 2021-06-30 07:45:02 --> Helper loaded: url_helper
INFO - 2021-06-30 07:45:02 --> Helper loaded: form_helper
INFO - 2021-06-30 07:45:02 --> Database Driver Class Initialized
INFO - 2021-06-30 07:45:02 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:45:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:45:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:45:02 --> Encryption Class Initialized
INFO - 2021-06-30 07:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:45:02 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:45:02 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:45:02 --> Model "user_model" initialized
INFO - 2021-06-30 07:45:02 --> Model "role_model" initialized
INFO - 2021-06-30 07:45:02 --> Controller Class Initialized
INFO - 2021-06-30 07:45:02 --> Helper loaded: language_helper
INFO - 2021-06-30 07:45:02 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:45:02 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:45:02 --> Model "Product_model" initialized
INFO - 2021-06-30 07:45:02 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:45:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:45:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:45:02 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:45:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:45:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:45:02 --> Final output sent to browser
DEBUG - 2021-06-30 07:45:02 --> Total execution time: 0.0792
INFO - 2021-06-30 07:45:27 --> Config Class Initialized
INFO - 2021-06-30 07:45:27 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:45:27 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:45:27 --> Utf8 Class Initialized
INFO - 2021-06-30 07:45:27 --> URI Class Initialized
INFO - 2021-06-30 07:45:27 --> Router Class Initialized
INFO - 2021-06-30 07:45:27 --> Output Class Initialized
INFO - 2021-06-30 07:45:27 --> Security Class Initialized
DEBUG - 2021-06-30 07:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:45:27 --> Input Class Initialized
INFO - 2021-06-30 07:45:27 --> Language Class Initialized
INFO - 2021-06-30 07:45:27 --> Loader Class Initialized
INFO - 2021-06-30 07:45:27 --> Helper loaded: html_helper
INFO - 2021-06-30 07:45:27 --> Helper loaded: url_helper
INFO - 2021-06-30 07:45:27 --> Helper loaded: form_helper
INFO - 2021-06-30 07:45:27 --> Database Driver Class Initialized
INFO - 2021-06-30 07:45:27 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:45:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:45:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:45:27 --> Encryption Class Initialized
INFO - 2021-06-30 07:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:45:27 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:45:27 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:45:27 --> Model "user_model" initialized
INFO - 2021-06-30 07:45:27 --> Model "role_model" initialized
INFO - 2021-06-30 07:45:27 --> Controller Class Initialized
INFO - 2021-06-30 07:45:27 --> Helper loaded: language_helper
INFO - 2021-06-30 07:45:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:45:27 --> Final output sent to browser
DEBUG - 2021-06-30 07:45:27 --> Total execution time: 0.0853
INFO - 2021-06-30 07:45:57 --> Config Class Initialized
INFO - 2021-06-30 07:45:57 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:45:57 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:45:57 --> Utf8 Class Initialized
INFO - 2021-06-30 07:45:57 --> URI Class Initialized
INFO - 2021-06-30 07:45:57 --> Router Class Initialized
INFO - 2021-06-30 07:45:57 --> Output Class Initialized
INFO - 2021-06-30 07:45:57 --> Security Class Initialized
DEBUG - 2021-06-30 07:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:45:57 --> Input Class Initialized
INFO - 2021-06-30 07:45:57 --> Language Class Initialized
INFO - 2021-06-30 07:45:57 --> Loader Class Initialized
INFO - 2021-06-30 07:45:57 --> Helper loaded: html_helper
INFO - 2021-06-30 07:45:57 --> Helper loaded: url_helper
INFO - 2021-06-30 07:45:57 --> Helper loaded: form_helper
INFO - 2021-06-30 07:45:57 --> Database Driver Class Initialized
INFO - 2021-06-30 07:45:57 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:45:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:45:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:45:57 --> Encryption Class Initialized
INFO - 2021-06-30 07:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:45:57 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:45:57 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:45:57 --> Model "user_model" initialized
INFO - 2021-06-30 07:45:57 --> Model "role_model" initialized
INFO - 2021-06-30 07:45:57 --> Controller Class Initialized
INFO - 2021-06-30 07:45:57 --> Helper loaded: language_helper
INFO - 2021-06-30 07:45:57 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:45:57 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:45:57 --> Model "Product_model" initialized
INFO - 2021-06-30 07:45:57 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:45:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:45:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:45:57 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:45:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:45:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:45:57 --> Final output sent to browser
DEBUG - 2021-06-30 07:45:57 --> Total execution time: 0.0758
INFO - 2021-06-30 07:46:43 --> Config Class Initialized
INFO - 2021-06-30 07:46:43 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:46:43 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:46:43 --> Utf8 Class Initialized
INFO - 2021-06-30 07:46:43 --> URI Class Initialized
INFO - 2021-06-30 07:46:43 --> Router Class Initialized
INFO - 2021-06-30 07:46:43 --> Output Class Initialized
INFO - 2021-06-30 07:46:43 --> Security Class Initialized
DEBUG - 2021-06-30 07:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:46:43 --> Input Class Initialized
INFO - 2021-06-30 07:46:43 --> Language Class Initialized
INFO - 2021-06-30 07:46:43 --> Loader Class Initialized
INFO - 2021-06-30 07:46:43 --> Helper loaded: html_helper
INFO - 2021-06-30 07:46:43 --> Helper loaded: url_helper
INFO - 2021-06-30 07:46:43 --> Helper loaded: form_helper
INFO - 2021-06-30 07:46:43 --> Database Driver Class Initialized
INFO - 2021-06-30 07:46:43 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:46:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:46:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:46:43 --> Encryption Class Initialized
INFO - 2021-06-30 07:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:46:43 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:46:43 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:46:43 --> Model "user_model" initialized
INFO - 2021-06-30 07:46:43 --> Model "role_model" initialized
INFO - 2021-06-30 07:46:43 --> Controller Class Initialized
INFO - 2021-06-30 07:46:43 --> Helper loaded: language_helper
INFO - 2021-06-30 07:46:43 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:46:43 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:46:43 --> Model "Product_model" initialized
INFO - 2021-06-30 07:46:43 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:46:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:46:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:46:43 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:46:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:46:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:46:43 --> Final output sent to browser
DEBUG - 2021-06-30 07:46:43 --> Total execution time: 0.0768
INFO - 2021-06-30 07:47:00 --> Config Class Initialized
INFO - 2021-06-30 07:47:00 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:47:00 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:47:00 --> Utf8 Class Initialized
INFO - 2021-06-30 07:47:00 --> URI Class Initialized
INFO - 2021-06-30 07:47:00 --> Router Class Initialized
INFO - 2021-06-30 07:47:00 --> Output Class Initialized
INFO - 2021-06-30 07:47:00 --> Security Class Initialized
DEBUG - 2021-06-30 07:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:47:00 --> Input Class Initialized
INFO - 2021-06-30 07:47:00 --> Language Class Initialized
INFO - 2021-06-30 07:47:00 --> Loader Class Initialized
INFO - 2021-06-30 07:47:00 --> Helper loaded: html_helper
INFO - 2021-06-30 07:47:00 --> Helper loaded: url_helper
INFO - 2021-06-30 07:47:00 --> Helper loaded: form_helper
INFO - 2021-06-30 07:47:00 --> Database Driver Class Initialized
INFO - 2021-06-30 07:47:00 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:47:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:47:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:47:00 --> Encryption Class Initialized
INFO - 2021-06-30 07:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:47:00 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:47:00 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:47:00 --> Model "user_model" initialized
INFO - 2021-06-30 07:47:00 --> Model "role_model" initialized
INFO - 2021-06-30 07:47:00 --> Controller Class Initialized
INFO - 2021-06-30 07:47:00 --> Helper loaded: language_helper
INFO - 2021-06-30 07:47:00 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:47:00 --> Final output sent to browser
DEBUG - 2021-06-30 07:47:00 --> Total execution time: 0.0666
INFO - 2021-06-30 07:47:31 --> Config Class Initialized
INFO - 2021-06-30 07:47:31 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:47:31 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:47:31 --> Utf8 Class Initialized
INFO - 2021-06-30 07:47:31 --> URI Class Initialized
INFO - 2021-06-30 07:47:31 --> Router Class Initialized
INFO - 2021-06-30 07:47:31 --> Output Class Initialized
INFO - 2021-06-30 07:47:31 --> Security Class Initialized
DEBUG - 2021-06-30 07:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:47:31 --> Input Class Initialized
INFO - 2021-06-30 07:47:31 --> Language Class Initialized
INFO - 2021-06-30 07:47:31 --> Loader Class Initialized
INFO - 2021-06-30 07:47:31 --> Helper loaded: html_helper
INFO - 2021-06-30 07:47:31 --> Helper loaded: url_helper
INFO - 2021-06-30 07:47:31 --> Helper loaded: form_helper
INFO - 2021-06-30 07:47:31 --> Database Driver Class Initialized
INFO - 2021-06-30 07:47:31 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:47:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:47:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:47:31 --> Encryption Class Initialized
INFO - 2021-06-30 07:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:47:31 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:47:31 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:47:31 --> Model "user_model" initialized
INFO - 2021-06-30 07:47:31 --> Model "role_model" initialized
INFO - 2021-06-30 07:47:31 --> Controller Class Initialized
INFO - 2021-06-30 07:47:31 --> Helper loaded: language_helper
INFO - 2021-06-30 07:47:31 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:47:31 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:47:31 --> Model "Product_model" initialized
INFO - 2021-06-30 07:47:31 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:47:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:47:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:47:31 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:47:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:47:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:47:31 --> Final output sent to browser
DEBUG - 2021-06-30 07:47:31 --> Total execution time: 0.0740
INFO - 2021-06-30 07:47:48 --> Config Class Initialized
INFO - 2021-06-30 07:47:48 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:47:48 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:47:48 --> Utf8 Class Initialized
INFO - 2021-06-30 07:47:48 --> URI Class Initialized
INFO - 2021-06-30 07:47:48 --> Router Class Initialized
INFO - 2021-06-30 07:47:48 --> Output Class Initialized
INFO - 2021-06-30 07:47:48 --> Security Class Initialized
DEBUG - 2021-06-30 07:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:47:48 --> Input Class Initialized
INFO - 2021-06-30 07:47:48 --> Language Class Initialized
INFO - 2021-06-30 07:47:48 --> Loader Class Initialized
INFO - 2021-06-30 07:47:48 --> Helper loaded: html_helper
INFO - 2021-06-30 07:47:48 --> Helper loaded: url_helper
INFO - 2021-06-30 07:47:48 --> Helper loaded: form_helper
INFO - 2021-06-30 07:47:48 --> Database Driver Class Initialized
INFO - 2021-06-30 07:47:48 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:47:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:47:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:47:48 --> Encryption Class Initialized
INFO - 2021-06-30 07:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:47:48 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:47:48 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:47:48 --> Model "user_model" initialized
INFO - 2021-06-30 07:47:48 --> Model "role_model" initialized
INFO - 2021-06-30 07:47:48 --> Controller Class Initialized
INFO - 2021-06-30 07:47:48 --> Helper loaded: language_helper
INFO - 2021-06-30 07:47:48 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:47:48 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:47:48 --> Model "Product_model" initialized
INFO - 2021-06-30 07:47:48 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:47:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:47:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:47:48 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:47:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:47:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:47:48 --> Final output sent to browser
DEBUG - 2021-06-30 07:47:48 --> Total execution time: 0.0716
INFO - 2021-06-30 07:48:05 --> Config Class Initialized
INFO - 2021-06-30 07:48:05 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:48:05 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:48:05 --> Utf8 Class Initialized
INFO - 2021-06-30 07:48:05 --> URI Class Initialized
INFO - 2021-06-30 07:48:05 --> Router Class Initialized
INFO - 2021-06-30 07:48:05 --> Output Class Initialized
INFO - 2021-06-30 07:48:05 --> Security Class Initialized
DEBUG - 2021-06-30 07:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:48:05 --> Input Class Initialized
INFO - 2021-06-30 07:48:05 --> Language Class Initialized
INFO - 2021-06-30 07:48:05 --> Loader Class Initialized
INFO - 2021-06-30 07:48:05 --> Helper loaded: html_helper
INFO - 2021-06-30 07:48:05 --> Helper loaded: url_helper
INFO - 2021-06-30 07:48:05 --> Helper loaded: form_helper
INFO - 2021-06-30 07:48:05 --> Database Driver Class Initialized
INFO - 2021-06-30 07:48:05 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:48:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:48:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:48:05 --> Encryption Class Initialized
INFO - 2021-06-30 07:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:48:05 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:48:05 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:48:05 --> Model "user_model" initialized
INFO - 2021-06-30 07:48:05 --> Model "role_model" initialized
INFO - 2021-06-30 07:48:05 --> Controller Class Initialized
INFO - 2021-06-30 07:48:05 --> Helper loaded: language_helper
INFO - 2021-06-30 07:48:05 --> Language file loaded: language/english/content_lang.php
ERROR - 2021-06-30 07:48:05 --> Severity: error --> Exception: Call to undefined method Customer_controller::filter_field() D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 75
INFO - 2021-06-30 07:49:33 --> Config Class Initialized
INFO - 2021-06-30 07:49:33 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:49:33 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:49:33 --> Utf8 Class Initialized
INFO - 2021-06-30 07:49:33 --> URI Class Initialized
INFO - 2021-06-30 07:49:33 --> Router Class Initialized
INFO - 2021-06-30 07:49:33 --> Output Class Initialized
INFO - 2021-06-30 07:49:33 --> Security Class Initialized
DEBUG - 2021-06-30 07:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:49:33 --> Input Class Initialized
INFO - 2021-06-30 07:49:33 --> Language Class Initialized
INFO - 2021-06-30 07:49:33 --> Loader Class Initialized
INFO - 2021-06-30 07:49:33 --> Helper loaded: html_helper
INFO - 2021-06-30 07:49:33 --> Helper loaded: url_helper
INFO - 2021-06-30 07:49:33 --> Helper loaded: form_helper
INFO - 2021-06-30 07:49:33 --> Database Driver Class Initialized
INFO - 2021-06-30 07:49:33 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:49:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:49:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:49:33 --> Encryption Class Initialized
INFO - 2021-06-30 07:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:49:33 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:49:33 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:49:33 --> Model "user_model" initialized
INFO - 2021-06-30 07:49:33 --> Model "role_model" initialized
INFO - 2021-06-30 07:49:33 --> Controller Class Initialized
INFO - 2021-06-30 07:49:33 --> Helper loaded: language_helper
INFO - 2021-06-30 07:49:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:49:33 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:49:33 --> Model "Product_model" initialized
INFO - 2021-06-30 07:49:33 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:49:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:49:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:49:33 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:49:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:49:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:49:33 --> Final output sent to browser
DEBUG - 2021-06-30 07:49:33 --> Total execution time: 0.0841
INFO - 2021-06-30 07:50:03 --> Config Class Initialized
INFO - 2021-06-30 07:50:03 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:50:03 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:50:03 --> Utf8 Class Initialized
INFO - 2021-06-30 07:50:03 --> URI Class Initialized
INFO - 2021-06-30 07:50:03 --> Router Class Initialized
INFO - 2021-06-30 07:50:03 --> Output Class Initialized
INFO - 2021-06-30 07:50:03 --> Security Class Initialized
DEBUG - 2021-06-30 07:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:50:03 --> Input Class Initialized
INFO - 2021-06-30 07:50:03 --> Language Class Initialized
INFO - 2021-06-30 07:50:03 --> Loader Class Initialized
INFO - 2021-06-30 07:50:03 --> Helper loaded: html_helper
INFO - 2021-06-30 07:50:03 --> Helper loaded: url_helper
INFO - 2021-06-30 07:50:03 --> Helper loaded: form_helper
INFO - 2021-06-30 07:50:03 --> Database Driver Class Initialized
INFO - 2021-06-30 07:50:03 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:50:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:50:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:50:03 --> Encryption Class Initialized
INFO - 2021-06-30 07:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:50:03 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:50:03 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:50:03 --> Model "user_model" initialized
INFO - 2021-06-30 07:50:03 --> Model "role_model" initialized
INFO - 2021-06-30 07:50:03 --> Controller Class Initialized
INFO - 2021-06-30 07:50:03 --> Helper loaded: language_helper
INFO - 2021-06-30 07:50:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:50:03 --> Final output sent to browser
DEBUG - 2021-06-30 07:50:03 --> Total execution time: 0.0742
INFO - 2021-06-30 07:51:24 --> Config Class Initialized
INFO - 2021-06-30 07:51:24 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:51:24 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:51:24 --> Utf8 Class Initialized
INFO - 2021-06-30 07:51:24 --> URI Class Initialized
INFO - 2021-06-30 07:51:24 --> Router Class Initialized
INFO - 2021-06-30 07:51:24 --> Output Class Initialized
INFO - 2021-06-30 07:51:24 --> Security Class Initialized
DEBUG - 2021-06-30 07:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:51:24 --> Input Class Initialized
INFO - 2021-06-30 07:51:24 --> Language Class Initialized
INFO - 2021-06-30 07:51:24 --> Loader Class Initialized
INFO - 2021-06-30 07:51:24 --> Helper loaded: html_helper
INFO - 2021-06-30 07:51:24 --> Helper loaded: url_helper
INFO - 2021-06-30 07:51:24 --> Helper loaded: form_helper
INFO - 2021-06-30 07:51:24 --> Database Driver Class Initialized
INFO - 2021-06-30 07:51:24 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:51:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:51:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:51:24 --> Encryption Class Initialized
INFO - 2021-06-30 07:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:51:24 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:51:24 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:51:24 --> Model "user_model" initialized
INFO - 2021-06-30 07:51:24 --> Model "role_model" initialized
INFO - 2021-06-30 07:51:24 --> Controller Class Initialized
INFO - 2021-06-30 07:51:24 --> Helper loaded: language_helper
INFO - 2021-06-30 07:51:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:51:24 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:51:24 --> Model "Product_model" initialized
INFO - 2021-06-30 07:51:24 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:51:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:51:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:51:24 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:51:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:51:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:51:24 --> Final output sent to browser
DEBUG - 2021-06-30 07:51:24 --> Total execution time: 0.0785
INFO - 2021-06-30 07:51:40 --> Config Class Initialized
INFO - 2021-06-30 07:51:40 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:51:40 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:51:40 --> Utf8 Class Initialized
INFO - 2021-06-30 07:51:40 --> URI Class Initialized
INFO - 2021-06-30 07:51:40 --> Router Class Initialized
INFO - 2021-06-30 07:51:40 --> Output Class Initialized
INFO - 2021-06-30 07:51:40 --> Security Class Initialized
DEBUG - 2021-06-30 07:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:51:40 --> Input Class Initialized
INFO - 2021-06-30 07:51:40 --> Language Class Initialized
INFO - 2021-06-30 07:51:40 --> Loader Class Initialized
INFO - 2021-06-30 07:51:40 --> Helper loaded: html_helper
INFO - 2021-06-30 07:51:40 --> Helper loaded: url_helper
INFO - 2021-06-30 07:51:40 --> Helper loaded: form_helper
INFO - 2021-06-30 07:51:40 --> Database Driver Class Initialized
INFO - 2021-06-30 07:51:40 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:51:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:51:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:51:40 --> Encryption Class Initialized
INFO - 2021-06-30 07:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:51:40 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:51:40 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:51:40 --> Model "user_model" initialized
INFO - 2021-06-30 07:51:40 --> Model "role_model" initialized
INFO - 2021-06-30 07:51:40 --> Controller Class Initialized
INFO - 2021-06-30 07:51:40 --> Helper loaded: language_helper
INFO - 2021-06-30 07:51:40 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:51:40 --> Model "Customer_model" initialized
ERROR - 2021-06-30 07:51:40 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server][SQL Server]Invalid object name '[prosoft_testdb].[dbo].[CUSTOMER]'. - Invalid query: INSERT INTO "[prosoft_testdb]"."[dbo]"."[CUSTOMER]" ("customer_id", "customer_name", "Customer_Address", "Customer_City", "Customer_State", "Customer_Country", "GSTIN_No", "PAN_No", "TAN_No") VALUES ('0c54f2eb-2ee7-4e65-af83-1c4190a27999', 'test', 'test', 'test', 'test', 'test', 'test', 'test', 'test')
INFO - 2021-06-30 07:51:40 --> Language file loaded: language/english/db_lang.php
INFO - 2021-06-30 07:52:48 --> Config Class Initialized
INFO - 2021-06-30 07:52:48 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:52:48 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:52:48 --> Utf8 Class Initialized
INFO - 2021-06-30 07:52:48 --> URI Class Initialized
INFO - 2021-06-30 07:52:48 --> Router Class Initialized
INFO - 2021-06-30 07:52:48 --> Output Class Initialized
INFO - 2021-06-30 07:52:48 --> Security Class Initialized
DEBUG - 2021-06-30 07:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:52:48 --> Input Class Initialized
INFO - 2021-06-30 07:52:48 --> Language Class Initialized
INFO - 2021-06-30 07:52:48 --> Loader Class Initialized
INFO - 2021-06-30 07:52:48 --> Helper loaded: html_helper
INFO - 2021-06-30 07:52:48 --> Helper loaded: url_helper
INFO - 2021-06-30 07:52:48 --> Helper loaded: form_helper
INFO - 2021-06-30 07:52:48 --> Database Driver Class Initialized
INFO - 2021-06-30 07:52:48 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:52:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:52:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:52:48 --> Encryption Class Initialized
INFO - 2021-06-30 07:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:52:48 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:52:48 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:52:48 --> Model "user_model" initialized
INFO - 2021-06-30 07:52:48 --> Model "role_model" initialized
INFO - 2021-06-30 07:52:48 --> Controller Class Initialized
INFO - 2021-06-30 07:52:48 --> Helper loaded: language_helper
INFO - 2021-06-30 07:52:48 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:52:48 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:52:48 --> Model "Product_model" initialized
INFO - 2021-06-30 07:52:48 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:52:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:52:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:52:48 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:52:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:52:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:52:48 --> Final output sent to browser
DEBUG - 2021-06-30 07:52:48 --> Total execution time: 0.0957
INFO - 2021-06-30 07:53:06 --> Config Class Initialized
INFO - 2021-06-30 07:53:06 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:53:06 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:53:06 --> Utf8 Class Initialized
INFO - 2021-06-30 07:53:06 --> URI Class Initialized
INFO - 2021-06-30 07:53:06 --> Router Class Initialized
INFO - 2021-06-30 07:53:06 --> Output Class Initialized
INFO - 2021-06-30 07:53:06 --> Security Class Initialized
DEBUG - 2021-06-30 07:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:53:06 --> Input Class Initialized
INFO - 2021-06-30 07:53:06 --> Language Class Initialized
INFO - 2021-06-30 07:53:06 --> Loader Class Initialized
INFO - 2021-06-30 07:53:06 --> Helper loaded: html_helper
INFO - 2021-06-30 07:53:06 --> Helper loaded: url_helper
INFO - 2021-06-30 07:53:06 --> Helper loaded: form_helper
INFO - 2021-06-30 07:53:06 --> Database Driver Class Initialized
INFO - 2021-06-30 07:53:06 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:53:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:53:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:53:06 --> Encryption Class Initialized
INFO - 2021-06-30 07:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:53:06 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:53:06 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:53:06 --> Model "user_model" initialized
INFO - 2021-06-30 07:53:06 --> Model "role_model" initialized
INFO - 2021-06-30 07:53:06 --> Controller Class Initialized
INFO - 2021-06-30 07:53:06 --> Helper loaded: language_helper
INFO - 2021-06-30 07:53:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:53:06 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:53:06 --> Final output sent to browser
DEBUG - 2021-06-30 07:53:06 --> Total execution time: 0.0687
INFO - 2021-06-30 07:53:38 --> Config Class Initialized
INFO - 2021-06-30 07:53:38 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:53:38 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:53:38 --> Utf8 Class Initialized
INFO - 2021-06-30 07:53:38 --> URI Class Initialized
INFO - 2021-06-30 07:53:38 --> Router Class Initialized
INFO - 2021-06-30 07:53:38 --> Output Class Initialized
INFO - 2021-06-30 07:53:38 --> Security Class Initialized
DEBUG - 2021-06-30 07:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:53:38 --> Input Class Initialized
INFO - 2021-06-30 07:53:38 --> Language Class Initialized
INFO - 2021-06-30 07:53:38 --> Loader Class Initialized
INFO - 2021-06-30 07:53:38 --> Helper loaded: html_helper
INFO - 2021-06-30 07:53:38 --> Helper loaded: url_helper
INFO - 2021-06-30 07:53:38 --> Helper loaded: form_helper
INFO - 2021-06-30 07:53:38 --> Database Driver Class Initialized
INFO - 2021-06-30 07:53:38 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:53:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:53:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:53:38 --> Encryption Class Initialized
INFO - 2021-06-30 07:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:53:38 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:53:38 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:53:38 --> Model "user_model" initialized
INFO - 2021-06-30 07:53:38 --> Model "role_model" initialized
INFO - 2021-06-30 07:53:38 --> Controller Class Initialized
INFO - 2021-06-30 07:53:38 --> Helper loaded: language_helper
INFO - 2021-06-30 07:53:38 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:53:38 --> Model "Customer_model" initialized
INFO - 2021-06-30 07:53:38 --> Model "Product_model" initialized
INFO - 2021-06-30 07:53:38 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 07:53:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 07:53:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 07:53:38 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 07:53:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 07:53:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 07:53:38 --> Final output sent to browser
DEBUG - 2021-06-30 07:53:38 --> Total execution time: 0.0904
INFO - 2021-06-30 07:53:56 --> Config Class Initialized
INFO - 2021-06-30 07:53:56 --> Hooks Class Initialized
DEBUG - 2021-06-30 07:53:56 --> UTF-8 Support Enabled
INFO - 2021-06-30 07:53:56 --> Utf8 Class Initialized
INFO - 2021-06-30 07:53:56 --> URI Class Initialized
INFO - 2021-06-30 07:53:56 --> Router Class Initialized
INFO - 2021-06-30 07:53:56 --> Output Class Initialized
INFO - 2021-06-30 07:53:56 --> Security Class Initialized
DEBUG - 2021-06-30 07:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 07:53:56 --> Input Class Initialized
INFO - 2021-06-30 07:53:56 --> Language Class Initialized
INFO - 2021-06-30 07:53:56 --> Loader Class Initialized
INFO - 2021-06-30 07:53:56 --> Helper loaded: html_helper
INFO - 2021-06-30 07:53:56 --> Helper loaded: url_helper
INFO - 2021-06-30 07:53:56 --> Helper loaded: form_helper
INFO - 2021-06-30 07:53:56 --> Database Driver Class Initialized
INFO - 2021-06-30 07:53:56 --> Form Validation Class Initialized
DEBUG - 2021-06-30 07:53:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 07:53:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 07:53:56 --> Encryption Class Initialized
INFO - 2021-06-30 07:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 07:53:56 --> Model "vendor_model" initialized
INFO - 2021-06-30 07:53:56 --> Model "coupon_model" initialized
INFO - 2021-06-30 07:53:56 --> Model "user_model" initialized
INFO - 2021-06-30 07:53:56 --> Model "role_model" initialized
INFO - 2021-06-30 07:53:56 --> Controller Class Initialized
INFO - 2021-06-30 07:53:56 --> Helper loaded: language_helper
INFO - 2021-06-30 07:53:56 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 07:53:56 --> Model "Customer_model" initialized
ERROR - 2021-06-30 07:53:56 --> Severity: error --> Exception: Object of class Customer_model could not be converted to string D:\development\web\xampp\htdocs\proadmin\proadmin\application\models\Customer_model.php 67
INFO - 2021-06-30 08:06:13 --> Config Class Initialized
INFO - 2021-06-30 08:06:13 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:06:13 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:06:13 --> Utf8 Class Initialized
INFO - 2021-06-30 08:06:13 --> URI Class Initialized
INFO - 2021-06-30 08:06:13 --> Router Class Initialized
INFO - 2021-06-30 08:06:13 --> Output Class Initialized
INFO - 2021-06-30 08:06:13 --> Security Class Initialized
DEBUG - 2021-06-30 08:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:06:13 --> Input Class Initialized
INFO - 2021-06-30 08:06:13 --> Language Class Initialized
INFO - 2021-06-30 08:06:13 --> Loader Class Initialized
INFO - 2021-06-30 08:06:13 --> Helper loaded: html_helper
INFO - 2021-06-30 08:06:13 --> Helper loaded: url_helper
INFO - 2021-06-30 08:06:13 --> Helper loaded: form_helper
INFO - 2021-06-30 08:06:13 --> Database Driver Class Initialized
INFO - 2021-06-30 08:06:13 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:06:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:06:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:06:13 --> Encryption Class Initialized
INFO - 2021-06-30 08:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:06:13 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:06:13 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:06:13 --> Model "user_model" initialized
INFO - 2021-06-30 08:06:13 --> Model "role_model" initialized
INFO - 2021-06-30 08:06:13 --> Controller Class Initialized
INFO - 2021-06-30 08:06:13 --> Helper loaded: language_helper
INFO - 2021-06-30 08:06:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:06:13 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:06:13 --> Model "Product_model" initialized
INFO - 2021-06-30 08:06:13 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 08:06:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 08:06:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 08:06:13 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 08:06:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 08:06:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 08:06:13 --> Final output sent to browser
DEBUG - 2021-06-30 08:06:13 --> Total execution time: 0.1088
INFO - 2021-06-30 08:06:34 --> Config Class Initialized
INFO - 2021-06-30 08:06:34 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:06:34 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:06:34 --> Utf8 Class Initialized
INFO - 2021-06-30 08:06:34 --> URI Class Initialized
INFO - 2021-06-30 08:06:34 --> Router Class Initialized
INFO - 2021-06-30 08:06:34 --> Output Class Initialized
INFO - 2021-06-30 08:06:34 --> Security Class Initialized
DEBUG - 2021-06-30 08:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:06:34 --> Input Class Initialized
INFO - 2021-06-30 08:06:34 --> Language Class Initialized
ERROR - 2021-06-30 08:06:34 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 97
INFO - 2021-06-30 08:10:49 --> Config Class Initialized
INFO - 2021-06-30 08:10:49 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:10:49 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:10:49 --> Utf8 Class Initialized
INFO - 2021-06-30 08:10:49 --> URI Class Initialized
INFO - 2021-06-30 08:10:49 --> Router Class Initialized
INFO - 2021-06-30 08:10:49 --> Output Class Initialized
INFO - 2021-06-30 08:10:49 --> Security Class Initialized
DEBUG - 2021-06-30 08:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:10:49 --> Input Class Initialized
INFO - 2021-06-30 08:10:49 --> Language Class Initialized
INFO - 2021-06-30 08:10:49 --> Loader Class Initialized
INFO - 2021-06-30 08:10:49 --> Helper loaded: html_helper
INFO - 2021-06-30 08:10:49 --> Helper loaded: url_helper
INFO - 2021-06-30 08:10:49 --> Helper loaded: form_helper
INFO - 2021-06-30 08:10:49 --> Database Driver Class Initialized
INFO - 2021-06-30 08:10:49 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:10:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:10:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:10:49 --> Encryption Class Initialized
INFO - 2021-06-30 08:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:10:49 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:10:49 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:10:49 --> Model "user_model" initialized
INFO - 2021-06-30 08:10:49 --> Model "role_model" initialized
INFO - 2021-06-30 08:10:49 --> Controller Class Initialized
INFO - 2021-06-30 08:10:49 --> Helper loaded: language_helper
INFO - 2021-06-30 08:10:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:10:49 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:10:49 --> Model "Product_model" initialized
INFO - 2021-06-30 08:10:49 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 08:10:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 08:10:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 08:10:49 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 08:10:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 08:10:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 08:10:49 --> Final output sent to browser
DEBUG - 2021-06-30 08:10:49 --> Total execution time: 0.0946
INFO - 2021-06-30 08:11:09 --> Config Class Initialized
INFO - 2021-06-30 08:11:09 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:11:09 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:11:09 --> Utf8 Class Initialized
INFO - 2021-06-30 08:11:09 --> URI Class Initialized
INFO - 2021-06-30 08:11:09 --> Router Class Initialized
INFO - 2021-06-30 08:11:09 --> Output Class Initialized
INFO - 2021-06-30 08:11:09 --> Security Class Initialized
DEBUG - 2021-06-30 08:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:11:09 --> Input Class Initialized
INFO - 2021-06-30 08:11:09 --> Language Class Initialized
ERROR - 2021-06-30 08:11:09 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 97
INFO - 2021-06-30 08:11:58 --> Config Class Initialized
INFO - 2021-06-30 08:11:58 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:11:58 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:11:58 --> Utf8 Class Initialized
INFO - 2021-06-30 08:11:58 --> URI Class Initialized
INFO - 2021-06-30 08:11:58 --> Router Class Initialized
INFO - 2021-06-30 08:11:58 --> Output Class Initialized
INFO - 2021-06-30 08:11:58 --> Security Class Initialized
DEBUG - 2021-06-30 08:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:11:58 --> Input Class Initialized
INFO - 2021-06-30 08:11:58 --> Language Class Initialized
INFO - 2021-06-30 08:11:58 --> Loader Class Initialized
INFO - 2021-06-30 08:11:58 --> Helper loaded: html_helper
INFO - 2021-06-30 08:11:58 --> Helper loaded: url_helper
INFO - 2021-06-30 08:11:58 --> Helper loaded: form_helper
INFO - 2021-06-30 08:11:58 --> Database Driver Class Initialized
INFO - 2021-06-30 08:11:58 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:11:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:11:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:11:58 --> Encryption Class Initialized
INFO - 2021-06-30 08:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:11:58 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:11:58 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:11:58 --> Model "user_model" initialized
INFO - 2021-06-30 08:11:58 --> Model "role_model" initialized
INFO - 2021-06-30 08:11:58 --> Controller Class Initialized
INFO - 2021-06-30 08:11:58 --> Helper loaded: language_helper
INFO - 2021-06-30 08:11:58 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:11:58 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:11:58 --> Model "Product_model" initialized
INFO - 2021-06-30 08:11:58 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 08:11:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 08:11:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 08:11:58 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 08:11:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 08:11:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 08:11:58 --> Final output sent to browser
DEBUG - 2021-06-30 08:11:58 --> Total execution time: 0.0755
INFO - 2021-06-30 08:12:43 --> Config Class Initialized
INFO - 2021-06-30 08:12:43 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:12:43 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:12:43 --> Utf8 Class Initialized
INFO - 2021-06-30 08:12:43 --> URI Class Initialized
INFO - 2021-06-30 08:12:43 --> Router Class Initialized
INFO - 2021-06-30 08:12:43 --> Output Class Initialized
INFO - 2021-06-30 08:12:43 --> Security Class Initialized
DEBUG - 2021-06-30 08:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:12:43 --> Input Class Initialized
INFO - 2021-06-30 08:12:43 --> Language Class Initialized
INFO - 2021-06-30 08:12:43 --> Loader Class Initialized
INFO - 2021-06-30 08:12:43 --> Helper loaded: html_helper
INFO - 2021-06-30 08:12:43 --> Helper loaded: url_helper
INFO - 2021-06-30 08:12:43 --> Helper loaded: form_helper
INFO - 2021-06-30 08:12:43 --> Database Driver Class Initialized
INFO - 2021-06-30 08:12:43 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:12:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:12:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:12:43 --> Encryption Class Initialized
INFO - 2021-06-30 08:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:12:43 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:12:43 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:12:43 --> Model "user_model" initialized
INFO - 2021-06-30 08:12:43 --> Model "role_model" initialized
INFO - 2021-06-30 08:12:43 --> Controller Class Initialized
INFO - 2021-06-30 08:12:43 --> Helper loaded: language_helper
INFO - 2021-06-30 08:12:43 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:12:43 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:12:43 --> Model "Product_model" initialized
INFO - 2021-06-30 08:12:43 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 08:12:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 08:12:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 08:12:43 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 08:12:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 08:12:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 08:12:43 --> Final output sent to browser
DEBUG - 2021-06-30 08:12:43 --> Total execution time: 0.0959
INFO - 2021-06-30 08:12:59 --> Config Class Initialized
INFO - 2021-06-30 08:12:59 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:12:59 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:12:59 --> Utf8 Class Initialized
INFO - 2021-06-30 08:12:59 --> URI Class Initialized
INFO - 2021-06-30 08:12:59 --> Router Class Initialized
INFO - 2021-06-30 08:12:59 --> Output Class Initialized
INFO - 2021-06-30 08:12:59 --> Security Class Initialized
DEBUG - 2021-06-30 08:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:12:59 --> Input Class Initialized
INFO - 2021-06-30 08:12:59 --> Language Class Initialized
ERROR - 2021-06-30 08:12:59 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 97
INFO - 2021-06-30 08:13:52 --> Config Class Initialized
INFO - 2021-06-30 08:13:52 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:13:52 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:13:52 --> Utf8 Class Initialized
INFO - 2021-06-30 08:13:52 --> URI Class Initialized
INFO - 2021-06-30 08:13:52 --> Router Class Initialized
INFO - 2021-06-30 08:13:52 --> Output Class Initialized
INFO - 2021-06-30 08:13:52 --> Security Class Initialized
DEBUG - 2021-06-30 08:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:13:52 --> Input Class Initialized
INFO - 2021-06-30 08:13:52 --> Language Class Initialized
INFO - 2021-06-30 08:13:52 --> Loader Class Initialized
INFO - 2021-06-30 08:13:52 --> Helper loaded: html_helper
INFO - 2021-06-30 08:13:52 --> Helper loaded: url_helper
INFO - 2021-06-30 08:13:52 --> Helper loaded: form_helper
INFO - 2021-06-30 08:13:52 --> Database Driver Class Initialized
INFO - 2021-06-30 08:13:52 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:13:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:13:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:13:52 --> Encryption Class Initialized
INFO - 2021-06-30 08:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:13:52 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:13:52 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:13:52 --> Model "user_model" initialized
INFO - 2021-06-30 08:13:52 --> Model "role_model" initialized
INFO - 2021-06-30 08:13:52 --> Controller Class Initialized
INFO - 2021-06-30 08:13:52 --> Helper loaded: language_helper
INFO - 2021-06-30 08:13:52 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:13:52 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:13:52 --> Model "Product_model" initialized
INFO - 2021-06-30 08:13:52 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 08:13:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 08:13:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 08:13:52 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 08:13:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 08:13:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 08:13:52 --> Final output sent to browser
DEBUG - 2021-06-30 08:13:52 --> Total execution time: 0.1112
INFO - 2021-06-30 08:14:08 --> Config Class Initialized
INFO - 2021-06-30 08:14:08 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:14:08 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:14:08 --> Utf8 Class Initialized
INFO - 2021-06-30 08:14:08 --> URI Class Initialized
INFO - 2021-06-30 08:14:08 --> Router Class Initialized
INFO - 2021-06-30 08:14:08 --> Output Class Initialized
INFO - 2021-06-30 08:14:08 --> Security Class Initialized
DEBUG - 2021-06-30 08:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:14:08 --> Input Class Initialized
INFO - 2021-06-30 08:14:08 --> Language Class Initialized
ERROR - 2021-06-30 08:14:08 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 97
INFO - 2021-06-30 08:14:42 --> Config Class Initialized
INFO - 2021-06-30 08:14:42 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:14:42 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:14:42 --> Utf8 Class Initialized
INFO - 2021-06-30 08:14:42 --> URI Class Initialized
INFO - 2021-06-30 08:14:42 --> Router Class Initialized
INFO - 2021-06-30 08:14:42 --> Output Class Initialized
INFO - 2021-06-30 08:14:42 --> Security Class Initialized
DEBUG - 2021-06-30 08:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:14:42 --> Input Class Initialized
INFO - 2021-06-30 08:14:42 --> Language Class Initialized
INFO - 2021-06-30 08:14:42 --> Loader Class Initialized
INFO - 2021-06-30 08:14:42 --> Helper loaded: html_helper
INFO - 2021-06-30 08:14:42 --> Helper loaded: url_helper
INFO - 2021-06-30 08:14:42 --> Helper loaded: form_helper
INFO - 2021-06-30 08:14:42 --> Database Driver Class Initialized
INFO - 2021-06-30 08:14:42 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:14:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:14:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:14:42 --> Encryption Class Initialized
INFO - 2021-06-30 08:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:14:42 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:14:42 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:14:42 --> Model "user_model" initialized
INFO - 2021-06-30 08:14:42 --> Model "role_model" initialized
INFO - 2021-06-30 08:14:42 --> Controller Class Initialized
INFO - 2021-06-30 08:14:42 --> Helper loaded: language_helper
INFO - 2021-06-30 08:14:42 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:14:42 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:14:42 --> Model "Product_model" initialized
INFO - 2021-06-30 08:14:42 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 08:14:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 08:14:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 08:14:42 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 08:14:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 08:14:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 08:14:42 --> Final output sent to browser
DEBUG - 2021-06-30 08:14:42 --> Total execution time: 0.0653
INFO - 2021-06-30 08:14:56 --> Config Class Initialized
INFO - 2021-06-30 08:14:56 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:14:56 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:14:56 --> Utf8 Class Initialized
INFO - 2021-06-30 08:14:56 --> URI Class Initialized
INFO - 2021-06-30 08:14:56 --> Router Class Initialized
INFO - 2021-06-30 08:14:56 --> Output Class Initialized
INFO - 2021-06-30 08:14:56 --> Security Class Initialized
DEBUG - 2021-06-30 08:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:14:56 --> Input Class Initialized
INFO - 2021-06-30 08:14:56 --> Language Class Initialized
ERROR - 2021-06-30 08:14:56 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 97
INFO - 2021-06-30 08:16:36 --> Config Class Initialized
INFO - 2021-06-30 08:16:36 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:16:36 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:16:36 --> Utf8 Class Initialized
INFO - 2021-06-30 08:16:36 --> URI Class Initialized
INFO - 2021-06-30 08:16:36 --> Router Class Initialized
INFO - 2021-06-30 08:16:36 --> Output Class Initialized
INFO - 2021-06-30 08:16:36 --> Security Class Initialized
DEBUG - 2021-06-30 08:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:16:36 --> Input Class Initialized
INFO - 2021-06-30 08:16:36 --> Language Class Initialized
INFO - 2021-06-30 08:16:36 --> Loader Class Initialized
INFO - 2021-06-30 08:16:36 --> Helper loaded: html_helper
INFO - 2021-06-30 08:16:36 --> Helper loaded: url_helper
INFO - 2021-06-30 08:16:36 --> Helper loaded: form_helper
INFO - 2021-06-30 08:16:36 --> Database Driver Class Initialized
INFO - 2021-06-30 08:16:36 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:16:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:16:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:16:36 --> Encryption Class Initialized
INFO - 2021-06-30 08:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:16:36 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:16:36 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:16:36 --> Model "user_model" initialized
INFO - 2021-06-30 08:16:36 --> Model "role_model" initialized
INFO - 2021-06-30 08:16:36 --> Controller Class Initialized
INFO - 2021-06-30 08:16:36 --> Helper loaded: language_helper
INFO - 2021-06-30 08:16:36 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:16:36 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:16:36 --> Model "Product_model" initialized
INFO - 2021-06-30 08:16:36 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 08:16:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 08:16:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 08:16:36 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 08:16:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 08:16:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 08:16:36 --> Final output sent to browser
DEBUG - 2021-06-30 08:16:36 --> Total execution time: 0.1134
INFO - 2021-06-30 08:19:06 --> Config Class Initialized
INFO - 2021-06-30 08:19:06 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:19:06 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:19:06 --> Utf8 Class Initialized
INFO - 2021-06-30 08:19:06 --> URI Class Initialized
INFO - 2021-06-30 08:19:06 --> Router Class Initialized
INFO - 2021-06-30 08:19:06 --> Output Class Initialized
INFO - 2021-06-30 08:19:06 --> Security Class Initialized
DEBUG - 2021-06-30 08:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:19:06 --> Input Class Initialized
INFO - 2021-06-30 08:19:06 --> Language Class Initialized
INFO - 2021-06-30 08:19:06 --> Loader Class Initialized
INFO - 2021-06-30 08:19:06 --> Helper loaded: html_helper
INFO - 2021-06-30 08:19:06 --> Helper loaded: url_helper
INFO - 2021-06-30 08:19:06 --> Helper loaded: form_helper
INFO - 2021-06-30 08:19:06 --> Database Driver Class Initialized
INFO - 2021-06-30 08:19:06 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:19:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:19:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:19:06 --> Encryption Class Initialized
INFO - 2021-06-30 08:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:19:06 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:19:06 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:19:06 --> Model "user_model" initialized
INFO - 2021-06-30 08:19:06 --> Model "role_model" initialized
INFO - 2021-06-30 08:19:06 --> Controller Class Initialized
INFO - 2021-06-30 08:19:06 --> Helper loaded: language_helper
INFO - 2021-06-30 08:19:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:19:06 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:19:06 --> Model "Product_model" initialized
INFO - 2021-06-30 08:19:06 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 08:19:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 08:19:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 08:19:06 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 08:19:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 08:19:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 08:19:06 --> Final output sent to browser
DEBUG - 2021-06-30 08:19:06 --> Total execution time: 0.1200
INFO - 2021-06-30 08:19:20 --> Config Class Initialized
INFO - 2021-06-30 08:19:20 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:19:20 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:19:20 --> Utf8 Class Initialized
INFO - 2021-06-30 08:19:20 --> URI Class Initialized
INFO - 2021-06-30 08:19:20 --> Router Class Initialized
INFO - 2021-06-30 08:19:20 --> Output Class Initialized
INFO - 2021-06-30 08:19:20 --> Security Class Initialized
DEBUG - 2021-06-30 08:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:19:20 --> Input Class Initialized
INFO - 2021-06-30 08:19:20 --> Language Class Initialized
INFO - 2021-06-30 08:19:20 --> Loader Class Initialized
INFO - 2021-06-30 08:19:20 --> Helper loaded: html_helper
INFO - 2021-06-30 08:19:20 --> Helper loaded: url_helper
INFO - 2021-06-30 08:19:20 --> Helper loaded: form_helper
INFO - 2021-06-30 08:19:20 --> Database Driver Class Initialized
INFO - 2021-06-30 08:19:20 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:19:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:19:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:19:20 --> Encryption Class Initialized
INFO - 2021-06-30 08:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:19:20 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:19:20 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:19:20 --> Model "user_model" initialized
INFO - 2021-06-30 08:19:20 --> Model "role_model" initialized
INFO - 2021-06-30 08:19:20 --> Controller Class Initialized
INFO - 2021-06-30 08:19:20 --> Helper loaded: language_helper
INFO - 2021-06-30 08:19:20 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:19:20 --> Model "Customer_model" initialized
ERROR - 2021-06-30 08:19:20 --> Severity: Notice --> Undefined variable: store_data D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 108
INFO - 2021-06-30 08:19:21 --> Final output sent to browser
DEBUG - 2021-06-30 08:19:21 --> Total execution time: 0.0871
INFO - 2021-06-30 08:19:22 --> Config Class Initialized
INFO - 2021-06-30 08:19:22 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:19:22 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:19:22 --> Utf8 Class Initialized
INFO - 2021-06-30 08:19:22 --> URI Class Initialized
INFO - 2021-06-30 08:19:22 --> Router Class Initialized
INFO - 2021-06-30 08:19:22 --> Output Class Initialized
INFO - 2021-06-30 08:19:22 --> Security Class Initialized
DEBUG - 2021-06-30 08:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:19:22 --> Input Class Initialized
INFO - 2021-06-30 08:19:22 --> Language Class Initialized
INFO - 2021-06-30 08:19:22 --> Loader Class Initialized
INFO - 2021-06-30 08:19:22 --> Helper loaded: html_helper
INFO - 2021-06-30 08:19:22 --> Helper loaded: url_helper
INFO - 2021-06-30 08:19:22 --> Helper loaded: form_helper
INFO - 2021-06-30 08:19:22 --> Database Driver Class Initialized
INFO - 2021-06-30 08:19:22 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:19:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:19:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:19:22 --> Encryption Class Initialized
INFO - 2021-06-30 08:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:19:22 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:19:22 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:19:22 --> Model "user_model" initialized
INFO - 2021-06-30 08:19:22 --> Model "role_model" initialized
INFO - 2021-06-30 08:19:22 --> Controller Class Initialized
INFO - 2021-06-30 08:19:22 --> Helper loaded: language_helper
INFO - 2021-06-30 08:19:22 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:19:22 --> Model "Customer_model" initialized
ERROR - 2021-06-30 08:19:22 --> Severity: Notice --> Undefined variable: store_data D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 108
INFO - 2021-06-30 08:19:22 --> Final output sent to browser
DEBUG - 2021-06-30 08:19:22 --> Total execution time: 0.0650
INFO - 2021-06-30 08:19:24 --> Config Class Initialized
INFO - 2021-06-30 08:19:24 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:19:24 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:19:24 --> Utf8 Class Initialized
INFO - 2021-06-30 08:19:24 --> URI Class Initialized
INFO - 2021-06-30 08:19:24 --> Router Class Initialized
INFO - 2021-06-30 08:19:24 --> Output Class Initialized
INFO - 2021-06-30 08:19:24 --> Security Class Initialized
DEBUG - 2021-06-30 08:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:19:24 --> Input Class Initialized
INFO - 2021-06-30 08:19:24 --> Language Class Initialized
INFO - 2021-06-30 08:19:24 --> Loader Class Initialized
INFO - 2021-06-30 08:19:24 --> Helper loaded: html_helper
INFO - 2021-06-30 08:19:24 --> Helper loaded: url_helper
INFO - 2021-06-30 08:19:24 --> Helper loaded: form_helper
INFO - 2021-06-30 08:19:24 --> Database Driver Class Initialized
INFO - 2021-06-30 08:19:24 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:19:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:19:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:19:24 --> Encryption Class Initialized
INFO - 2021-06-30 08:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:19:24 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:19:24 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:19:24 --> Model "user_model" initialized
INFO - 2021-06-30 08:19:24 --> Model "role_model" initialized
INFO - 2021-06-30 08:19:24 --> Controller Class Initialized
INFO - 2021-06-30 08:19:24 --> Helper loaded: language_helper
INFO - 2021-06-30 08:19:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:19:24 --> Model "Customer_model" initialized
ERROR - 2021-06-30 08:19:24 --> Severity: Notice --> Undefined variable: store_data D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 108
INFO - 2021-06-30 08:19:24 --> Final output sent to browser
DEBUG - 2021-06-30 08:19:24 --> Total execution time: 0.0693
INFO - 2021-06-30 08:19:36 --> Config Class Initialized
INFO - 2021-06-30 08:19:36 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:19:36 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:19:36 --> Utf8 Class Initialized
INFO - 2021-06-30 08:19:36 --> URI Class Initialized
INFO - 2021-06-30 08:19:36 --> Router Class Initialized
INFO - 2021-06-30 08:19:36 --> Output Class Initialized
INFO - 2021-06-30 08:19:36 --> Security Class Initialized
DEBUG - 2021-06-30 08:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:19:36 --> Input Class Initialized
INFO - 2021-06-30 08:19:36 --> Language Class Initialized
INFO - 2021-06-30 08:19:36 --> Loader Class Initialized
INFO - 2021-06-30 08:19:36 --> Helper loaded: html_helper
INFO - 2021-06-30 08:19:36 --> Helper loaded: url_helper
INFO - 2021-06-30 08:19:36 --> Helper loaded: form_helper
INFO - 2021-06-30 08:19:36 --> Database Driver Class Initialized
INFO - 2021-06-30 08:19:36 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:19:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:19:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:19:36 --> Encryption Class Initialized
INFO - 2021-06-30 08:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:19:36 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:19:36 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:19:36 --> Model "user_model" initialized
INFO - 2021-06-30 08:19:36 --> Model "role_model" initialized
INFO - 2021-06-30 08:19:36 --> Controller Class Initialized
INFO - 2021-06-30 08:19:36 --> Helper loaded: language_helper
INFO - 2021-06-30 08:19:36 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:19:36 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:19:36 --> Model "Product_model" initialized
INFO - 2021-06-30 08:19:36 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 08:19:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 08:19:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 08:19:36 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 08:19:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 08:19:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 08:19:36 --> Final output sent to browser
DEBUG - 2021-06-30 08:19:36 --> Total execution time: 0.0758
INFO - 2021-06-30 08:19:56 --> Config Class Initialized
INFO - 2021-06-30 08:19:56 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:19:56 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:19:56 --> Utf8 Class Initialized
INFO - 2021-06-30 08:19:56 --> URI Class Initialized
INFO - 2021-06-30 08:19:56 --> Router Class Initialized
INFO - 2021-06-30 08:19:56 --> Output Class Initialized
INFO - 2021-06-30 08:19:56 --> Security Class Initialized
DEBUG - 2021-06-30 08:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:19:56 --> Input Class Initialized
INFO - 2021-06-30 08:19:56 --> Language Class Initialized
ERROR - 2021-06-30 08:19:56 --> Severity: error --> Exception: syntax error, unexpected '"testing"' (T_CONSTANT_ENCAPSED_STRING) D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 65
INFO - 2021-06-30 08:20:32 --> Config Class Initialized
INFO - 2021-06-30 08:20:32 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:20:32 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:20:32 --> Utf8 Class Initialized
INFO - 2021-06-30 08:20:32 --> URI Class Initialized
INFO - 2021-06-30 08:20:32 --> Router Class Initialized
INFO - 2021-06-30 08:20:32 --> Output Class Initialized
INFO - 2021-06-30 08:20:32 --> Security Class Initialized
DEBUG - 2021-06-30 08:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:20:32 --> Input Class Initialized
INFO - 2021-06-30 08:20:32 --> Language Class Initialized
INFO - 2021-06-30 08:20:32 --> Loader Class Initialized
INFO - 2021-06-30 08:20:32 --> Helper loaded: html_helper
INFO - 2021-06-30 08:20:32 --> Helper loaded: url_helper
INFO - 2021-06-30 08:20:32 --> Helper loaded: form_helper
INFO - 2021-06-30 08:20:32 --> Database Driver Class Initialized
INFO - 2021-06-30 08:20:32 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:20:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:20:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:20:32 --> Encryption Class Initialized
INFO - 2021-06-30 08:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:20:32 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:20:32 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:20:32 --> Model "user_model" initialized
INFO - 2021-06-30 08:20:32 --> Model "role_model" initialized
INFO - 2021-06-30 08:20:32 --> Controller Class Initialized
INFO - 2021-06-30 08:20:32 --> Helper loaded: language_helper
INFO - 2021-06-30 08:20:32 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:20:32 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:20:32 --> Model "Product_model" initialized
INFO - 2021-06-30 08:20:32 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 08:20:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 08:20:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 08:20:32 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 08:20:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 08:20:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 08:20:32 --> Final output sent to browser
DEBUG - 2021-06-30 08:20:32 --> Total execution time: 0.0770
INFO - 2021-06-30 08:20:52 --> Config Class Initialized
INFO - 2021-06-30 08:20:52 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:20:52 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:20:52 --> Utf8 Class Initialized
INFO - 2021-06-30 08:20:52 --> URI Class Initialized
INFO - 2021-06-30 08:20:52 --> Router Class Initialized
INFO - 2021-06-30 08:20:52 --> Output Class Initialized
INFO - 2021-06-30 08:20:52 --> Security Class Initialized
DEBUG - 2021-06-30 08:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:20:52 --> Input Class Initialized
INFO - 2021-06-30 08:20:52 --> Language Class Initialized
ERROR - 2021-06-30 08:20:52 --> Severity: error --> Exception: syntax error, unexpected '"testing"' (T_CONSTANT_ENCAPSED_STRING) D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 65
INFO - 2021-06-30 08:24:20 --> Config Class Initialized
INFO - 2021-06-30 08:24:20 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:24:20 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:24:20 --> Utf8 Class Initialized
INFO - 2021-06-30 08:24:20 --> URI Class Initialized
INFO - 2021-06-30 08:24:20 --> Router Class Initialized
INFO - 2021-06-30 08:24:20 --> Output Class Initialized
INFO - 2021-06-30 08:24:20 --> Security Class Initialized
DEBUG - 2021-06-30 08:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:24:20 --> Input Class Initialized
INFO - 2021-06-30 08:24:20 --> Language Class Initialized
INFO - 2021-06-30 08:24:20 --> Loader Class Initialized
INFO - 2021-06-30 08:24:20 --> Helper loaded: html_helper
INFO - 2021-06-30 08:24:20 --> Helper loaded: url_helper
INFO - 2021-06-30 08:24:20 --> Helper loaded: form_helper
INFO - 2021-06-30 08:24:20 --> Database Driver Class Initialized
INFO - 2021-06-30 08:24:20 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:24:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:24:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:24:20 --> Encryption Class Initialized
INFO - 2021-06-30 08:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:24:20 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:24:20 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:24:20 --> Model "user_model" initialized
INFO - 2021-06-30 08:24:20 --> Model "role_model" initialized
INFO - 2021-06-30 08:24:20 --> Controller Class Initialized
INFO - 2021-06-30 08:24:20 --> Helper loaded: language_helper
INFO - 2021-06-30 08:24:20 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:24:20 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:24:20 --> Model "Product_model" initialized
INFO - 2021-06-30 08:24:20 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 08:24:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 08:24:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 08:24:20 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 08:24:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 08:24:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 08:24:20 --> Final output sent to browser
DEBUG - 2021-06-30 08:24:20 --> Total execution time: 0.1523
INFO - 2021-06-30 08:25:48 --> Config Class Initialized
INFO - 2021-06-30 08:25:48 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:25:48 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:25:48 --> Utf8 Class Initialized
INFO - 2021-06-30 08:25:48 --> URI Class Initialized
INFO - 2021-06-30 08:25:48 --> Router Class Initialized
INFO - 2021-06-30 08:25:48 --> Output Class Initialized
INFO - 2021-06-30 08:25:48 --> Security Class Initialized
DEBUG - 2021-06-30 08:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:25:48 --> Input Class Initialized
INFO - 2021-06-30 08:25:48 --> Language Class Initialized
INFO - 2021-06-30 08:25:48 --> Loader Class Initialized
INFO - 2021-06-30 08:25:48 --> Helper loaded: html_helper
INFO - 2021-06-30 08:25:48 --> Helper loaded: url_helper
INFO - 2021-06-30 08:25:48 --> Helper loaded: form_helper
INFO - 2021-06-30 08:25:48 --> Database Driver Class Initialized
INFO - 2021-06-30 08:25:48 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:25:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:25:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:25:48 --> Encryption Class Initialized
INFO - 2021-06-30 08:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:25:48 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:25:48 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:25:48 --> Model "user_model" initialized
INFO - 2021-06-30 08:25:48 --> Model "role_model" initialized
INFO - 2021-06-30 08:25:48 --> Controller Class Initialized
INFO - 2021-06-30 08:25:48 --> Helper loaded: language_helper
INFO - 2021-06-30 08:25:48 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:25:48 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:25:48 --> Model "Product_model" initialized
INFO - 2021-06-30 08:25:48 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 08:25:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 08:25:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 08:25:48 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 08:25:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 08:25:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 08:25:48 --> Final output sent to browser
DEBUG - 2021-06-30 08:25:48 --> Total execution time: 0.1087
INFO - 2021-06-30 08:26:10 --> Config Class Initialized
INFO - 2021-06-30 08:26:10 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:26:10 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:26:10 --> Utf8 Class Initialized
INFO - 2021-06-30 08:26:10 --> URI Class Initialized
INFO - 2021-06-30 08:26:10 --> Router Class Initialized
INFO - 2021-06-30 08:26:10 --> Output Class Initialized
INFO - 2021-06-30 08:26:10 --> Security Class Initialized
DEBUG - 2021-06-30 08:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:26:10 --> Input Class Initialized
INFO - 2021-06-30 08:26:10 --> Language Class Initialized
INFO - 2021-06-30 08:26:10 --> Loader Class Initialized
INFO - 2021-06-30 08:26:10 --> Helper loaded: html_helper
INFO - 2021-06-30 08:26:10 --> Helper loaded: url_helper
INFO - 2021-06-30 08:26:10 --> Helper loaded: form_helper
INFO - 2021-06-30 08:26:10 --> Database Driver Class Initialized
INFO - 2021-06-30 08:26:10 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:26:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:26:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:26:10 --> Encryption Class Initialized
INFO - 2021-06-30 08:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:26:10 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:26:10 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:26:10 --> Model "user_model" initialized
INFO - 2021-06-30 08:26:10 --> Model "role_model" initialized
INFO - 2021-06-30 08:26:10 --> Controller Class Initialized
INFO - 2021-06-30 08:26:10 --> Helper loaded: language_helper
INFO - 2021-06-30 08:26:10 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:26:10 --> Final output sent to browser
DEBUG - 2021-06-30 08:26:10 --> Total execution time: 0.0926
INFO - 2021-06-30 08:26:11 --> Config Class Initialized
INFO - 2021-06-30 08:26:11 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:26:11 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:26:11 --> Utf8 Class Initialized
INFO - 2021-06-30 08:26:11 --> URI Class Initialized
INFO - 2021-06-30 08:26:11 --> Router Class Initialized
INFO - 2021-06-30 08:26:11 --> Output Class Initialized
INFO - 2021-06-30 08:26:11 --> Security Class Initialized
DEBUG - 2021-06-30 08:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:26:11 --> Input Class Initialized
INFO - 2021-06-30 08:26:11 --> Language Class Initialized
INFO - 2021-06-30 08:26:11 --> Loader Class Initialized
INFO - 2021-06-30 08:26:11 --> Helper loaded: html_helper
INFO - 2021-06-30 08:26:11 --> Helper loaded: url_helper
INFO - 2021-06-30 08:26:11 --> Helper loaded: form_helper
INFO - 2021-06-30 08:26:11 --> Database Driver Class Initialized
INFO - 2021-06-30 08:26:11 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:26:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:26:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:26:11 --> Encryption Class Initialized
INFO - 2021-06-30 08:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:26:11 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:26:11 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:26:11 --> Model "user_model" initialized
INFO - 2021-06-30 08:26:11 --> Model "role_model" initialized
INFO - 2021-06-30 08:26:11 --> Controller Class Initialized
INFO - 2021-06-30 08:26:11 --> Helper loaded: language_helper
INFO - 2021-06-30 08:26:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:26:11 --> Final output sent to browser
DEBUG - 2021-06-30 08:26:11 --> Total execution time: 0.0621
INFO - 2021-06-30 08:26:12 --> Config Class Initialized
INFO - 2021-06-30 08:26:12 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:26:12 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:26:12 --> Utf8 Class Initialized
INFO - 2021-06-30 08:26:12 --> URI Class Initialized
INFO - 2021-06-30 08:26:12 --> Router Class Initialized
INFO - 2021-06-30 08:26:12 --> Output Class Initialized
INFO - 2021-06-30 08:26:12 --> Security Class Initialized
DEBUG - 2021-06-30 08:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:26:12 --> Input Class Initialized
INFO - 2021-06-30 08:26:12 --> Language Class Initialized
INFO - 2021-06-30 08:26:12 --> Loader Class Initialized
INFO - 2021-06-30 08:26:12 --> Helper loaded: html_helper
INFO - 2021-06-30 08:26:12 --> Helper loaded: url_helper
INFO - 2021-06-30 08:26:12 --> Helper loaded: form_helper
INFO - 2021-06-30 08:26:12 --> Database Driver Class Initialized
INFO - 2021-06-30 08:26:12 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:26:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:26:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:26:12 --> Encryption Class Initialized
INFO - 2021-06-30 08:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:26:12 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:26:12 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:26:12 --> Model "user_model" initialized
INFO - 2021-06-30 08:26:12 --> Model "role_model" initialized
INFO - 2021-06-30 08:26:12 --> Controller Class Initialized
INFO - 2021-06-30 08:26:12 --> Helper loaded: language_helper
INFO - 2021-06-30 08:26:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:26:12 --> Final output sent to browser
DEBUG - 2021-06-30 08:26:12 --> Total execution time: 0.0621
INFO - 2021-06-30 08:26:12 --> Config Class Initialized
INFO - 2021-06-30 08:26:12 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:26:12 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:26:12 --> Utf8 Class Initialized
INFO - 2021-06-30 08:26:12 --> URI Class Initialized
INFO - 2021-06-30 08:26:12 --> Router Class Initialized
INFO - 2021-06-30 08:26:12 --> Output Class Initialized
INFO - 2021-06-30 08:26:12 --> Security Class Initialized
DEBUG - 2021-06-30 08:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:26:12 --> Input Class Initialized
INFO - 2021-06-30 08:26:12 --> Language Class Initialized
INFO - 2021-06-30 08:26:12 --> Loader Class Initialized
INFO - 2021-06-30 08:26:12 --> Helper loaded: html_helper
INFO - 2021-06-30 08:26:12 --> Helper loaded: url_helper
INFO - 2021-06-30 08:26:12 --> Helper loaded: form_helper
INFO - 2021-06-30 08:26:12 --> Database Driver Class Initialized
INFO - 2021-06-30 08:26:12 --> Config Class Initialized
INFO - 2021-06-30 08:26:12 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:26:12 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:26:12 --> Utf8 Class Initialized
INFO - 2021-06-30 08:26:12 --> URI Class Initialized
INFO - 2021-06-30 08:26:12 --> Router Class Initialized
INFO - 2021-06-30 08:26:12 --> Output Class Initialized
INFO - 2021-06-30 08:26:12 --> Security Class Initialized
DEBUG - 2021-06-30 08:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:26:12 --> Input Class Initialized
INFO - 2021-06-30 08:26:12 --> Language Class Initialized
INFO - 2021-06-30 08:26:12 --> Loader Class Initialized
INFO - 2021-06-30 08:26:12 --> Helper loaded: html_helper
INFO - 2021-06-30 08:26:12 --> Helper loaded: url_helper
INFO - 2021-06-30 08:26:12 --> Helper loaded: form_helper
INFO - 2021-06-30 08:26:12 --> Database Driver Class Initialized
INFO - 2021-06-30 08:26:12 --> Config Class Initialized
INFO - 2021-06-30 08:26:12 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:26:12 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:26:12 --> Utf8 Class Initialized
INFO - 2021-06-30 08:26:12 --> URI Class Initialized
INFO - 2021-06-30 08:26:12 --> Router Class Initialized
INFO - 2021-06-30 08:26:12 --> Output Class Initialized
INFO - 2021-06-30 08:26:12 --> Security Class Initialized
DEBUG - 2021-06-30 08:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:26:12 --> Input Class Initialized
INFO - 2021-06-30 08:26:12 --> Language Class Initialized
INFO - 2021-06-30 08:26:12 --> Loader Class Initialized
INFO - 2021-06-30 08:26:12 --> Helper loaded: html_helper
INFO - 2021-06-30 08:26:12 --> Helper loaded: url_helper
INFO - 2021-06-30 08:26:12 --> Helper loaded: form_helper
INFO - 2021-06-30 08:26:12 --> Database Driver Class Initialized
INFO - 2021-06-30 08:26:13 --> Config Class Initialized
INFO - 2021-06-30 08:26:13 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:26:13 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:26:13 --> Utf8 Class Initialized
INFO - 2021-06-30 08:26:13 --> URI Class Initialized
INFO - 2021-06-30 08:26:13 --> Router Class Initialized
INFO - 2021-06-30 08:26:13 --> Output Class Initialized
INFO - 2021-06-30 08:26:13 --> Security Class Initialized
DEBUG - 2021-06-30 08:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:26:13 --> Input Class Initialized
INFO - 2021-06-30 08:26:13 --> Language Class Initialized
INFO - 2021-06-30 08:26:13 --> Loader Class Initialized
INFO - 2021-06-30 08:26:13 --> Helper loaded: html_helper
INFO - 2021-06-30 08:26:13 --> Helper loaded: url_helper
INFO - 2021-06-30 08:26:13 --> Helper loaded: form_helper
INFO - 2021-06-30 08:26:13 --> Database Driver Class Initialized
INFO - 2021-06-30 08:26:13 --> Config Class Initialized
INFO - 2021-06-30 08:26:13 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:26:13 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:26:13 --> Utf8 Class Initialized
INFO - 2021-06-30 08:26:13 --> URI Class Initialized
INFO - 2021-06-30 08:26:13 --> Router Class Initialized
INFO - 2021-06-30 08:26:13 --> Output Class Initialized
INFO - 2021-06-30 08:26:13 --> Security Class Initialized
DEBUG - 2021-06-30 08:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:26:13 --> Input Class Initialized
INFO - 2021-06-30 08:26:13 --> Language Class Initialized
INFO - 2021-06-30 08:26:13 --> Loader Class Initialized
INFO - 2021-06-30 08:26:13 --> Helper loaded: html_helper
INFO - 2021-06-30 08:26:13 --> Helper loaded: url_helper
INFO - 2021-06-30 08:26:13 --> Helper loaded: form_helper
INFO - 2021-06-30 08:26:13 --> Database Driver Class Initialized
INFO - 2021-06-30 08:26:13 --> Form Validation Class Initialized
INFO - 2021-06-30 08:26:13 --> Form Validation Class Initialized
INFO - 2021-06-30 08:26:13 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:26:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:26:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:26:13 --> Encryption Class Initialized
DEBUG - 2021-06-30 08:26:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:26:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:26:13 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:26:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:26:13 --> Encryption Class Initialized
INFO - 2021-06-30 08:26:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:26:13 --> Encryption Class Initialized
INFO - 2021-06-30 08:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:26:13 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:26:13 --> Model "coupon_model" initialized
DEBUG - 2021-06-30 08:26:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:26:13 --> Model "user_model" initialized
INFO - 2021-06-30 08:26:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:26:13 --> Model "role_model" initialized
INFO - 2021-06-30 08:26:13 --> Encryption Class Initialized
INFO - 2021-06-30 08:26:13 --> Controller Class Initialized
INFO - 2021-06-30 08:26:13 --> Helper loaded: language_helper
INFO - 2021-06-30 08:26:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:26:13 --> Final output sent to browser
DEBUG - 2021-06-30 08:26:13 --> Total execution time: 0.5907
INFO - 2021-06-30 08:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:26:13 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:26:13 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:26:13 --> Model "user_model" initialized
INFO - 2021-06-30 08:26:13 --> Model "role_model" initialized
INFO - 2021-06-30 08:26:13 --> Controller Class Initialized
INFO - 2021-06-30 08:26:13 --> Helper loaded: language_helper
INFO - 2021-06-30 08:26:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:26:13 --> Final output sent to browser
DEBUG - 2021-06-30 08:26:13 --> Total execution time: 0.9231
INFO - 2021-06-30 08:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:26:13 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:26:13 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:26:13 --> Model "user_model" initialized
INFO - 2021-06-30 08:26:13 --> Model "role_model" initialized
INFO - 2021-06-30 08:26:13 --> Controller Class Initialized
INFO - 2021-06-30 08:26:13 --> Helper loaded: language_helper
INFO - 2021-06-30 08:26:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:26:13 --> Final output sent to browser
DEBUG - 2021-06-30 08:26:13 --> Total execution time: 0.4096
INFO - 2021-06-30 08:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:26:13 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:26:13 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:26:13 --> Model "user_model" initialized
INFO - 2021-06-30 08:26:13 --> Model "role_model" initialized
INFO - 2021-06-30 08:26:13 --> Controller Class Initialized
INFO - 2021-06-30 08:26:13 --> Helper loaded: language_helper
INFO - 2021-06-30 08:26:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:26:13 --> Final output sent to browser
DEBUG - 2021-06-30 08:26:13 --> Total execution time: 0.2001
INFO - 2021-06-30 08:26:13 --> Config Class Initialized
INFO - 2021-06-30 08:26:13 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:26:13 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:26:13 --> Utf8 Class Initialized
INFO - 2021-06-30 08:26:13 --> URI Class Initialized
INFO - 2021-06-30 08:26:13 --> Router Class Initialized
INFO - 2021-06-30 08:26:13 --> Form Validation Class Initialized
INFO - 2021-06-30 08:26:13 --> Output Class Initialized
INFO - 2021-06-30 08:26:13 --> Security Class Initialized
DEBUG - 2021-06-30 08:26:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:26:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:26:13 --> Encryption Class Initialized
DEBUG - 2021-06-30 08:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:26:13 --> Input Class Initialized
INFO - 2021-06-30 08:26:13 --> Language Class Initialized
INFO - 2021-06-30 08:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:26:13 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:26:13 --> Loader Class Initialized
INFO - 2021-06-30 08:26:13 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:26:13 --> Model "user_model" initialized
INFO - 2021-06-30 08:26:13 --> Model "role_model" initialized
INFO - 2021-06-30 08:26:13 --> Helper loaded: html_helper
INFO - 2021-06-30 08:26:13 --> Controller Class Initialized
INFO - 2021-06-30 08:26:13 --> Helper loaded: language_helper
INFO - 2021-06-30 08:26:13 --> Helper loaded: url_helper
INFO - 2021-06-30 08:26:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:26:13 --> Final output sent to browser
DEBUG - 2021-06-30 08:26:13 --> Total execution time: 0.8003
INFO - 2021-06-30 08:26:13 --> Helper loaded: form_helper
INFO - 2021-06-30 08:26:13 --> Database Driver Class Initialized
INFO - 2021-06-30 08:26:13 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:26:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:26:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:26:13 --> Encryption Class Initialized
INFO - 2021-06-30 08:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:26:13 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:26:13 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:26:13 --> Model "user_model" initialized
INFO - 2021-06-30 08:26:13 --> Model "role_model" initialized
INFO - 2021-06-30 08:26:13 --> Controller Class Initialized
INFO - 2021-06-30 08:26:13 --> Helper loaded: language_helper
INFO - 2021-06-30 08:26:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:26:13 --> Final output sent to browser
DEBUG - 2021-06-30 08:26:13 --> Total execution time: 0.0739
INFO - 2021-06-30 08:26:13 --> Config Class Initialized
INFO - 2021-06-30 08:26:13 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:26:13 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:26:13 --> Utf8 Class Initialized
INFO - 2021-06-30 08:26:13 --> URI Class Initialized
INFO - 2021-06-30 08:26:13 --> Router Class Initialized
INFO - 2021-06-30 08:26:13 --> Output Class Initialized
INFO - 2021-06-30 08:26:13 --> Security Class Initialized
DEBUG - 2021-06-30 08:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:26:13 --> Input Class Initialized
INFO - 2021-06-30 08:26:13 --> Language Class Initialized
INFO - 2021-06-30 08:26:13 --> Loader Class Initialized
INFO - 2021-06-30 08:26:13 --> Helper loaded: html_helper
INFO - 2021-06-30 08:26:13 --> Helper loaded: url_helper
INFO - 2021-06-30 08:26:13 --> Helper loaded: form_helper
INFO - 2021-06-30 08:26:13 --> Database Driver Class Initialized
INFO - 2021-06-30 08:26:13 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:26:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:26:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:26:13 --> Encryption Class Initialized
INFO - 2021-06-30 08:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:26:13 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:26:13 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:26:13 --> Model "user_model" initialized
INFO - 2021-06-30 08:26:13 --> Model "role_model" initialized
INFO - 2021-06-30 08:26:13 --> Controller Class Initialized
INFO - 2021-06-30 08:26:13 --> Helper loaded: language_helper
INFO - 2021-06-30 08:26:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:26:13 --> Final output sent to browser
DEBUG - 2021-06-30 08:26:13 --> Total execution time: 0.0659
INFO - 2021-06-30 08:26:13 --> Config Class Initialized
INFO - 2021-06-30 08:26:13 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:26:13 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:26:13 --> Utf8 Class Initialized
INFO - 2021-06-30 08:26:13 --> URI Class Initialized
INFO - 2021-06-30 08:26:13 --> Router Class Initialized
INFO - 2021-06-30 08:26:13 --> Output Class Initialized
INFO - 2021-06-30 08:26:13 --> Security Class Initialized
DEBUG - 2021-06-30 08:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:26:13 --> Input Class Initialized
INFO - 2021-06-30 08:26:13 --> Language Class Initialized
INFO - 2021-06-30 08:26:13 --> Loader Class Initialized
INFO - 2021-06-30 08:26:13 --> Helper loaded: html_helper
INFO - 2021-06-30 08:26:13 --> Helper loaded: url_helper
INFO - 2021-06-30 08:26:13 --> Helper loaded: form_helper
INFO - 2021-06-30 08:26:13 --> Database Driver Class Initialized
INFO - 2021-06-30 08:26:13 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:26:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:26:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:26:13 --> Encryption Class Initialized
INFO - 2021-06-30 08:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:26:13 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:26:13 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:26:13 --> Model "user_model" initialized
INFO - 2021-06-30 08:26:13 --> Model "role_model" initialized
INFO - 2021-06-30 08:26:13 --> Controller Class Initialized
INFO - 2021-06-30 08:26:13 --> Helper loaded: language_helper
INFO - 2021-06-30 08:26:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:26:13 --> Final output sent to browser
DEBUG - 2021-06-30 08:26:13 --> Total execution time: 0.0631
INFO - 2021-06-30 08:26:14 --> Config Class Initialized
INFO - 2021-06-30 08:26:14 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:26:14 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:26:14 --> Utf8 Class Initialized
INFO - 2021-06-30 08:26:14 --> URI Class Initialized
INFO - 2021-06-30 08:26:14 --> Router Class Initialized
INFO - 2021-06-30 08:26:14 --> Output Class Initialized
INFO - 2021-06-30 08:26:14 --> Security Class Initialized
DEBUG - 2021-06-30 08:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:26:14 --> Input Class Initialized
INFO - 2021-06-30 08:26:14 --> Language Class Initialized
INFO - 2021-06-30 08:26:14 --> Loader Class Initialized
INFO - 2021-06-30 08:26:14 --> Helper loaded: html_helper
INFO - 2021-06-30 08:26:14 --> Helper loaded: url_helper
INFO - 2021-06-30 08:26:14 --> Helper loaded: form_helper
INFO - 2021-06-30 08:26:14 --> Database Driver Class Initialized
INFO - 2021-06-30 08:26:14 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:26:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:26:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:26:14 --> Encryption Class Initialized
INFO - 2021-06-30 08:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:26:14 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:26:14 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:26:14 --> Model "user_model" initialized
INFO - 2021-06-30 08:26:14 --> Model "role_model" initialized
INFO - 2021-06-30 08:26:14 --> Controller Class Initialized
INFO - 2021-06-30 08:26:14 --> Helper loaded: language_helper
INFO - 2021-06-30 08:26:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:26:14 --> Final output sent to browser
DEBUG - 2021-06-30 08:26:14 --> Total execution time: 0.0636
INFO - 2021-06-30 08:26:14 --> Config Class Initialized
INFO - 2021-06-30 08:26:14 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:26:14 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:26:14 --> Utf8 Class Initialized
INFO - 2021-06-30 08:26:14 --> URI Class Initialized
INFO - 2021-06-30 08:26:14 --> Router Class Initialized
INFO - 2021-06-30 08:26:14 --> Output Class Initialized
INFO - 2021-06-30 08:26:14 --> Security Class Initialized
DEBUG - 2021-06-30 08:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:26:14 --> Input Class Initialized
INFO - 2021-06-30 08:26:14 --> Language Class Initialized
INFO - 2021-06-30 08:26:14 --> Loader Class Initialized
INFO - 2021-06-30 08:26:14 --> Helper loaded: html_helper
INFO - 2021-06-30 08:26:14 --> Helper loaded: url_helper
INFO - 2021-06-30 08:26:14 --> Helper loaded: form_helper
INFO - 2021-06-30 08:26:14 --> Database Driver Class Initialized
INFO - 2021-06-30 08:26:14 --> Config Class Initialized
INFO - 2021-06-30 08:26:14 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:26:14 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:26:14 --> Utf8 Class Initialized
INFO - 2021-06-30 08:26:14 --> URI Class Initialized
INFO - 2021-06-30 08:26:14 --> Router Class Initialized
INFO - 2021-06-30 08:26:14 --> Output Class Initialized
INFO - 2021-06-30 08:26:14 --> Security Class Initialized
DEBUG - 2021-06-30 08:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:26:14 --> Input Class Initialized
INFO - 2021-06-30 08:26:14 --> Language Class Initialized
INFO - 2021-06-30 08:26:14 --> Loader Class Initialized
INFO - 2021-06-30 08:26:14 --> Helper loaded: html_helper
INFO - 2021-06-30 08:26:14 --> Helper loaded: url_helper
INFO - 2021-06-30 08:26:14 --> Helper loaded: form_helper
INFO - 2021-06-30 08:26:14 --> Database Driver Class Initialized
INFO - 2021-06-30 08:26:15 --> Config Class Initialized
INFO - 2021-06-30 08:26:15 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:26:15 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:26:15 --> Utf8 Class Initialized
INFO - 2021-06-30 08:26:15 --> URI Class Initialized
INFO - 2021-06-30 08:26:15 --> Router Class Initialized
INFO - 2021-06-30 08:26:15 --> Output Class Initialized
INFO - 2021-06-30 08:26:15 --> Security Class Initialized
DEBUG - 2021-06-30 08:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:26:15 --> Input Class Initialized
INFO - 2021-06-30 08:26:15 --> Language Class Initialized
INFO - 2021-06-30 08:26:15 --> Loader Class Initialized
INFO - 2021-06-30 08:26:15 --> Helper loaded: html_helper
INFO - 2021-06-30 08:26:15 --> Helper loaded: url_helper
INFO - 2021-06-30 08:26:15 --> Helper loaded: form_helper
INFO - 2021-06-30 08:26:15 --> Database Driver Class Initialized
INFO - 2021-06-30 08:26:15 --> Form Validation Class Initialized
INFO - 2021-06-30 08:26:15 --> Form Validation Class Initialized
INFO - 2021-06-30 08:26:15 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:26:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:26:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:26:15 --> Encryption Class Initialized
DEBUG - 2021-06-30 08:26:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:26:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:26:15 --> Encryption Class Initialized
DEBUG - 2021-06-30 08:26:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:26:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:26:15 --> Encryption Class Initialized
INFO - 2021-06-30 08:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:26:15 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:26:15 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:26:15 --> Model "user_model" initialized
INFO - 2021-06-30 08:26:15 --> Model "role_model" initialized
INFO - 2021-06-30 08:26:15 --> Controller Class Initialized
INFO - 2021-06-30 08:26:15 --> Helper loaded: language_helper
INFO - 2021-06-30 08:26:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:26:15 --> Final output sent to browser
DEBUG - 2021-06-30 08:26:15 --> Total execution time: 0.3425
INFO - 2021-06-30 08:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:26:15 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:26:15 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:26:15 --> Model "user_model" initialized
INFO - 2021-06-30 08:26:15 --> Model "role_model" initialized
INFO - 2021-06-30 08:26:15 --> Controller Class Initialized
INFO - 2021-06-30 08:26:15 --> Helper loaded: language_helper
INFO - 2021-06-30 08:26:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:26:15 --> Final output sent to browser
DEBUG - 2021-06-30 08:26:15 --> Total execution time: 0.1387
INFO - 2021-06-30 08:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:26:15 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:26:15 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:26:15 --> Model "user_model" initialized
INFO - 2021-06-30 08:26:15 --> Model "role_model" initialized
INFO - 2021-06-30 08:26:15 --> Controller Class Initialized
INFO - 2021-06-30 08:26:15 --> Helper loaded: language_helper
INFO - 2021-06-30 08:26:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:26:15 --> Final output sent to browser
DEBUG - 2021-06-30 08:26:15 --> Total execution time: 0.6375
INFO - 2021-06-30 08:26:15 --> Config Class Initialized
INFO - 2021-06-30 08:26:15 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:26:15 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:26:15 --> Utf8 Class Initialized
INFO - 2021-06-30 08:26:15 --> URI Class Initialized
INFO - 2021-06-30 08:26:15 --> Router Class Initialized
INFO - 2021-06-30 08:26:15 --> Output Class Initialized
INFO - 2021-06-30 08:26:15 --> Security Class Initialized
DEBUG - 2021-06-30 08:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:26:15 --> Input Class Initialized
INFO - 2021-06-30 08:26:15 --> Language Class Initialized
INFO - 2021-06-30 08:26:15 --> Loader Class Initialized
INFO - 2021-06-30 08:26:15 --> Helper loaded: html_helper
INFO - 2021-06-30 08:26:15 --> Helper loaded: url_helper
INFO - 2021-06-30 08:26:15 --> Helper loaded: form_helper
INFO - 2021-06-30 08:26:15 --> Database Driver Class Initialized
INFO - 2021-06-30 08:26:15 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:26:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:26:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:26:15 --> Encryption Class Initialized
INFO - 2021-06-30 08:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:26:15 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:26:15 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:26:15 --> Model "user_model" initialized
INFO - 2021-06-30 08:26:15 --> Model "role_model" initialized
INFO - 2021-06-30 08:26:15 --> Controller Class Initialized
INFO - 2021-06-30 08:26:15 --> Helper loaded: language_helper
INFO - 2021-06-30 08:26:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:26:15 --> Final output sent to browser
DEBUG - 2021-06-30 08:26:15 --> Total execution time: 0.0666
INFO - 2021-06-30 08:26:15 --> Config Class Initialized
INFO - 2021-06-30 08:26:15 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:26:15 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:26:15 --> Utf8 Class Initialized
INFO - 2021-06-30 08:26:15 --> URI Class Initialized
INFO - 2021-06-30 08:26:15 --> Router Class Initialized
INFO - 2021-06-30 08:26:15 --> Output Class Initialized
INFO - 2021-06-30 08:26:15 --> Security Class Initialized
DEBUG - 2021-06-30 08:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:26:15 --> Input Class Initialized
INFO - 2021-06-30 08:26:15 --> Language Class Initialized
INFO - 2021-06-30 08:26:15 --> Loader Class Initialized
INFO - 2021-06-30 08:26:15 --> Helper loaded: html_helper
INFO - 2021-06-30 08:26:15 --> Helper loaded: url_helper
INFO - 2021-06-30 08:26:15 --> Helper loaded: form_helper
INFO - 2021-06-30 08:26:15 --> Database Driver Class Initialized
INFO - 2021-06-30 08:26:15 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:26:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:26:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:26:15 --> Encryption Class Initialized
INFO - 2021-06-30 08:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:26:15 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:26:15 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:26:15 --> Model "user_model" initialized
INFO - 2021-06-30 08:26:15 --> Model "role_model" initialized
INFO - 2021-06-30 08:26:15 --> Controller Class Initialized
INFO - 2021-06-30 08:26:15 --> Helper loaded: language_helper
INFO - 2021-06-30 08:26:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:26:15 --> Final output sent to browser
DEBUG - 2021-06-30 08:26:15 --> Total execution time: 0.0621
INFO - 2021-06-30 08:26:51 --> Config Class Initialized
INFO - 2021-06-30 08:26:51 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:26:51 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:26:51 --> Utf8 Class Initialized
INFO - 2021-06-30 08:26:51 --> URI Class Initialized
INFO - 2021-06-30 08:26:51 --> Router Class Initialized
INFO - 2021-06-30 08:26:51 --> Output Class Initialized
INFO - 2021-06-30 08:26:51 --> Security Class Initialized
DEBUG - 2021-06-30 08:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:26:51 --> Input Class Initialized
INFO - 2021-06-30 08:26:51 --> Language Class Initialized
INFO - 2021-06-30 08:26:51 --> Loader Class Initialized
INFO - 2021-06-30 08:26:51 --> Helper loaded: html_helper
INFO - 2021-06-30 08:26:51 --> Helper loaded: url_helper
INFO - 2021-06-30 08:26:51 --> Helper loaded: form_helper
INFO - 2021-06-30 08:26:51 --> Database Driver Class Initialized
INFO - 2021-06-30 08:26:51 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:26:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:26:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:26:51 --> Encryption Class Initialized
INFO - 2021-06-30 08:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:26:51 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:26:51 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:26:51 --> Model "user_model" initialized
INFO - 2021-06-30 08:26:51 --> Model "role_model" initialized
INFO - 2021-06-30 08:26:51 --> Controller Class Initialized
INFO - 2021-06-30 08:26:51 --> Helper loaded: language_helper
INFO - 2021-06-30 08:26:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:26:51 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:26:51 --> Model "Product_model" initialized
INFO - 2021-06-30 08:26:51 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 08:26:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 08:26:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 08:26:51 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 08:26:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 08:26:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 08:26:51 --> Final output sent to browser
DEBUG - 2021-06-30 08:26:51 --> Total execution time: 0.1142
INFO - 2021-06-30 08:27:12 --> Config Class Initialized
INFO - 2021-06-30 08:27:12 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:27:12 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:27:12 --> Utf8 Class Initialized
INFO - 2021-06-30 08:27:12 --> URI Class Initialized
INFO - 2021-06-30 08:27:12 --> Router Class Initialized
INFO - 2021-06-30 08:27:12 --> Output Class Initialized
INFO - 2021-06-30 08:27:12 --> Security Class Initialized
DEBUG - 2021-06-30 08:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:27:12 --> Input Class Initialized
INFO - 2021-06-30 08:27:12 --> Language Class Initialized
INFO - 2021-06-30 08:27:12 --> Loader Class Initialized
INFO - 2021-06-30 08:27:12 --> Helper loaded: html_helper
INFO - 2021-06-30 08:27:12 --> Helper loaded: url_helper
INFO - 2021-06-30 08:27:12 --> Helper loaded: form_helper
INFO - 2021-06-30 08:27:12 --> Database Driver Class Initialized
INFO - 2021-06-30 08:27:12 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:27:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:27:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:27:12 --> Encryption Class Initialized
INFO - 2021-06-30 08:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:27:12 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:27:12 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:27:12 --> Model "user_model" initialized
INFO - 2021-06-30 08:27:12 --> Model "role_model" initialized
INFO - 2021-06-30 08:27:12 --> Controller Class Initialized
INFO - 2021-06-30 08:27:12 --> Helper loaded: language_helper
INFO - 2021-06-30 08:27:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:27:12 --> Final output sent to browser
DEBUG - 2021-06-30 08:27:12 --> Total execution time: 0.0619
INFO - 2021-06-30 08:27:14 --> Config Class Initialized
INFO - 2021-06-30 08:27:14 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:27:14 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:27:14 --> Utf8 Class Initialized
INFO - 2021-06-30 08:27:14 --> URI Class Initialized
INFO - 2021-06-30 08:27:14 --> Router Class Initialized
INFO - 2021-06-30 08:27:14 --> Output Class Initialized
INFO - 2021-06-30 08:27:14 --> Security Class Initialized
DEBUG - 2021-06-30 08:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:27:14 --> Input Class Initialized
INFO - 2021-06-30 08:27:14 --> Language Class Initialized
INFO - 2021-06-30 08:27:14 --> Loader Class Initialized
INFO - 2021-06-30 08:27:14 --> Helper loaded: html_helper
INFO - 2021-06-30 08:27:14 --> Helper loaded: url_helper
INFO - 2021-06-30 08:27:14 --> Helper loaded: form_helper
INFO - 2021-06-30 08:27:14 --> Database Driver Class Initialized
INFO - 2021-06-30 08:27:14 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:27:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:27:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:27:14 --> Encryption Class Initialized
INFO - 2021-06-30 08:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:27:14 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:27:14 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:27:14 --> Model "user_model" initialized
INFO - 2021-06-30 08:27:14 --> Model "role_model" initialized
INFO - 2021-06-30 08:27:14 --> Controller Class Initialized
INFO - 2021-06-30 08:27:14 --> Helper loaded: language_helper
INFO - 2021-06-30 08:27:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:27:14 --> Final output sent to browser
DEBUG - 2021-06-30 08:27:14 --> Total execution time: 0.0556
INFO - 2021-06-30 08:27:21 --> Config Class Initialized
INFO - 2021-06-30 08:27:21 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:27:21 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:27:21 --> Utf8 Class Initialized
INFO - 2021-06-30 08:27:21 --> URI Class Initialized
INFO - 2021-06-30 08:27:21 --> Router Class Initialized
INFO - 2021-06-30 08:27:21 --> Output Class Initialized
INFO - 2021-06-30 08:27:21 --> Security Class Initialized
DEBUG - 2021-06-30 08:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:27:21 --> Input Class Initialized
INFO - 2021-06-30 08:27:21 --> Language Class Initialized
INFO - 2021-06-30 08:27:21 --> Loader Class Initialized
INFO - 2021-06-30 08:27:21 --> Helper loaded: html_helper
INFO - 2021-06-30 08:27:21 --> Helper loaded: url_helper
INFO - 2021-06-30 08:27:21 --> Helper loaded: form_helper
INFO - 2021-06-30 08:27:21 --> Database Driver Class Initialized
INFO - 2021-06-30 08:27:21 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:27:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:27:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:27:21 --> Encryption Class Initialized
INFO - 2021-06-30 08:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:27:21 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:27:21 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:27:21 --> Model "user_model" initialized
INFO - 2021-06-30 08:27:21 --> Model "role_model" initialized
INFO - 2021-06-30 08:27:21 --> Controller Class Initialized
INFO - 2021-06-30 08:27:21 --> Helper loaded: language_helper
INFO - 2021-06-30 08:27:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:27:21 --> Final output sent to browser
DEBUG - 2021-06-30 08:27:21 --> Total execution time: 0.0915
INFO - 2021-06-30 08:27:26 --> Config Class Initialized
INFO - 2021-06-30 08:27:26 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:27:26 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:27:26 --> Utf8 Class Initialized
INFO - 2021-06-30 08:27:26 --> URI Class Initialized
INFO - 2021-06-30 08:27:26 --> Router Class Initialized
INFO - 2021-06-30 08:27:26 --> Output Class Initialized
INFO - 2021-06-30 08:27:26 --> Security Class Initialized
DEBUG - 2021-06-30 08:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:27:26 --> Input Class Initialized
INFO - 2021-06-30 08:27:26 --> Language Class Initialized
INFO - 2021-06-30 08:27:26 --> Loader Class Initialized
INFO - 2021-06-30 08:27:26 --> Helper loaded: html_helper
INFO - 2021-06-30 08:27:26 --> Helper loaded: url_helper
INFO - 2021-06-30 08:27:26 --> Helper loaded: form_helper
INFO - 2021-06-30 08:27:26 --> Database Driver Class Initialized
INFO - 2021-06-30 08:27:26 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:27:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:27:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:27:26 --> Encryption Class Initialized
INFO - 2021-06-30 08:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:27:26 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:27:26 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:27:26 --> Model "user_model" initialized
INFO - 2021-06-30 08:27:26 --> Model "role_model" initialized
INFO - 2021-06-30 08:27:26 --> Controller Class Initialized
INFO - 2021-06-30 08:27:26 --> Helper loaded: language_helper
INFO - 2021-06-30 08:27:26 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:27:26 --> Final output sent to browser
DEBUG - 2021-06-30 08:27:26 --> Total execution time: 0.0707
INFO - 2021-06-30 08:28:06 --> Config Class Initialized
INFO - 2021-06-30 08:28:06 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:28:06 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:28:06 --> Utf8 Class Initialized
INFO - 2021-06-30 08:28:06 --> URI Class Initialized
INFO - 2021-06-30 08:28:06 --> Router Class Initialized
INFO - 2021-06-30 08:28:06 --> Output Class Initialized
INFO - 2021-06-30 08:28:06 --> Security Class Initialized
DEBUG - 2021-06-30 08:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:28:06 --> Input Class Initialized
INFO - 2021-06-30 08:28:06 --> Language Class Initialized
INFO - 2021-06-30 08:28:06 --> Loader Class Initialized
INFO - 2021-06-30 08:28:06 --> Helper loaded: html_helper
INFO - 2021-06-30 08:28:06 --> Helper loaded: url_helper
INFO - 2021-06-30 08:28:06 --> Helper loaded: form_helper
INFO - 2021-06-30 08:28:06 --> Database Driver Class Initialized
INFO - 2021-06-30 08:28:06 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:28:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:28:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:28:06 --> Encryption Class Initialized
INFO - 2021-06-30 08:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:28:06 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:28:06 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:28:06 --> Model "user_model" initialized
INFO - 2021-06-30 08:28:06 --> Model "role_model" initialized
INFO - 2021-06-30 08:28:06 --> Controller Class Initialized
INFO - 2021-06-30 08:28:06 --> Helper loaded: language_helper
INFO - 2021-06-30 08:28:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:28:06 --> Final output sent to browser
DEBUG - 2021-06-30 08:28:06 --> Total execution time: 0.0848
INFO - 2021-06-30 08:28:08 --> Config Class Initialized
INFO - 2021-06-30 08:28:08 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:28:08 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:28:08 --> Utf8 Class Initialized
INFO - 2021-06-30 08:28:08 --> URI Class Initialized
INFO - 2021-06-30 08:28:08 --> Router Class Initialized
INFO - 2021-06-30 08:28:08 --> Output Class Initialized
INFO - 2021-06-30 08:28:08 --> Security Class Initialized
DEBUG - 2021-06-30 08:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:28:08 --> Input Class Initialized
INFO - 2021-06-30 08:28:08 --> Language Class Initialized
INFO - 2021-06-30 08:28:08 --> Loader Class Initialized
INFO - 2021-06-30 08:28:08 --> Helper loaded: html_helper
INFO - 2021-06-30 08:28:08 --> Helper loaded: url_helper
INFO - 2021-06-30 08:28:08 --> Helper loaded: form_helper
INFO - 2021-06-30 08:28:08 --> Database Driver Class Initialized
INFO - 2021-06-30 08:28:08 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:28:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:28:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:28:08 --> Encryption Class Initialized
INFO - 2021-06-30 08:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:28:08 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:28:08 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:28:08 --> Model "user_model" initialized
INFO - 2021-06-30 08:28:08 --> Model "role_model" initialized
INFO - 2021-06-30 08:28:08 --> Controller Class Initialized
INFO - 2021-06-30 08:28:08 --> Helper loaded: language_helper
INFO - 2021-06-30 08:28:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:28:08 --> Final output sent to browser
DEBUG - 2021-06-30 08:28:08 --> Total execution time: 0.0775
INFO - 2021-06-30 08:28:12 --> Config Class Initialized
INFO - 2021-06-30 08:28:12 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:28:12 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:28:12 --> Utf8 Class Initialized
INFO - 2021-06-30 08:28:12 --> URI Class Initialized
INFO - 2021-06-30 08:28:12 --> Router Class Initialized
INFO - 2021-06-30 08:28:12 --> Output Class Initialized
INFO - 2021-06-30 08:28:12 --> Security Class Initialized
DEBUG - 2021-06-30 08:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:28:12 --> Input Class Initialized
INFO - 2021-06-30 08:28:12 --> Language Class Initialized
INFO - 2021-06-30 08:28:12 --> Loader Class Initialized
INFO - 2021-06-30 08:28:12 --> Helper loaded: html_helper
INFO - 2021-06-30 08:28:12 --> Helper loaded: url_helper
INFO - 2021-06-30 08:28:12 --> Helper loaded: form_helper
INFO - 2021-06-30 08:28:12 --> Database Driver Class Initialized
INFO - 2021-06-30 08:28:12 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:28:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:28:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:28:12 --> Encryption Class Initialized
INFO - 2021-06-30 08:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:28:12 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:28:12 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:28:12 --> Model "user_model" initialized
INFO - 2021-06-30 08:28:12 --> Model "role_model" initialized
INFO - 2021-06-30 08:28:12 --> Controller Class Initialized
INFO - 2021-06-30 08:28:12 --> Helper loaded: language_helper
INFO - 2021-06-30 08:28:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:28:12 --> Final output sent to browser
DEBUG - 2021-06-30 08:28:12 --> Total execution time: 0.0752
INFO - 2021-06-30 08:29:05 --> Config Class Initialized
INFO - 2021-06-30 08:29:05 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:29:05 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:29:05 --> Utf8 Class Initialized
INFO - 2021-06-30 08:29:05 --> URI Class Initialized
INFO - 2021-06-30 08:29:05 --> Router Class Initialized
INFO - 2021-06-30 08:29:05 --> Output Class Initialized
INFO - 2021-06-30 08:29:05 --> Security Class Initialized
DEBUG - 2021-06-30 08:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:29:05 --> Input Class Initialized
INFO - 2021-06-30 08:29:05 --> Language Class Initialized
INFO - 2021-06-30 08:29:05 --> Loader Class Initialized
INFO - 2021-06-30 08:29:05 --> Helper loaded: html_helper
INFO - 2021-06-30 08:29:05 --> Helper loaded: url_helper
INFO - 2021-06-30 08:29:05 --> Helper loaded: form_helper
INFO - 2021-06-30 08:29:05 --> Database Driver Class Initialized
INFO - 2021-06-30 08:29:05 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:29:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:29:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:29:05 --> Encryption Class Initialized
INFO - 2021-06-30 08:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:29:05 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:29:05 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:29:05 --> Model "user_model" initialized
INFO - 2021-06-30 08:29:05 --> Model "role_model" initialized
INFO - 2021-06-30 08:29:05 --> Controller Class Initialized
INFO - 2021-06-30 08:29:05 --> Helper loaded: language_helper
INFO - 2021-06-30 08:29:05 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:29:05 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:29:05 --> Model "Product_model" initialized
INFO - 2021-06-30 08:29:05 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 08:29:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 08:29:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 08:29:05 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 08:29:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 08:29:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 08:29:05 --> Final output sent to browser
DEBUG - 2021-06-30 08:29:05 --> Total execution time: 0.0755
INFO - 2021-06-30 08:29:25 --> Config Class Initialized
INFO - 2021-06-30 08:29:25 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:29:25 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:29:25 --> Utf8 Class Initialized
INFO - 2021-06-30 08:29:25 --> URI Class Initialized
INFO - 2021-06-30 08:29:25 --> Router Class Initialized
INFO - 2021-06-30 08:29:25 --> Output Class Initialized
INFO - 2021-06-30 08:29:25 --> Security Class Initialized
DEBUG - 2021-06-30 08:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:29:25 --> Input Class Initialized
INFO - 2021-06-30 08:29:25 --> Language Class Initialized
ERROR - 2021-06-30 08:29:25 --> Severity: error --> Exception: syntax error, unexpected ';' D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 65
INFO - 2021-06-30 08:29:41 --> Config Class Initialized
INFO - 2021-06-30 08:29:41 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:29:41 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:29:41 --> Utf8 Class Initialized
INFO - 2021-06-30 08:29:41 --> URI Class Initialized
INFO - 2021-06-30 08:29:41 --> Router Class Initialized
INFO - 2021-06-30 08:29:41 --> Output Class Initialized
INFO - 2021-06-30 08:29:41 --> Security Class Initialized
DEBUG - 2021-06-30 08:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:29:41 --> Input Class Initialized
INFO - 2021-06-30 08:29:41 --> Language Class Initialized
INFO - 2021-06-30 08:29:41 --> Loader Class Initialized
INFO - 2021-06-30 08:29:41 --> Helper loaded: html_helper
INFO - 2021-06-30 08:29:41 --> Helper loaded: url_helper
INFO - 2021-06-30 08:29:41 --> Helper loaded: form_helper
INFO - 2021-06-30 08:29:41 --> Database Driver Class Initialized
INFO - 2021-06-30 08:29:41 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:29:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:29:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:29:41 --> Encryption Class Initialized
INFO - 2021-06-30 08:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:29:41 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:29:41 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:29:41 --> Model "user_model" initialized
INFO - 2021-06-30 08:29:41 --> Model "role_model" initialized
INFO - 2021-06-30 08:29:41 --> Controller Class Initialized
INFO - 2021-06-30 08:29:41 --> Helper loaded: language_helper
INFO - 2021-06-30 08:29:41 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:29:41 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:29:41 --> Model "Product_model" initialized
INFO - 2021-06-30 08:29:41 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 08:29:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 08:29:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 08:29:41 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 08:29:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 08:29:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 08:29:41 --> Final output sent to browser
DEBUG - 2021-06-30 08:29:41 --> Total execution time: 0.0761
INFO - 2021-06-30 08:29:59 --> Config Class Initialized
INFO - 2021-06-30 08:29:59 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:29:59 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:29:59 --> Utf8 Class Initialized
INFO - 2021-06-30 08:29:59 --> URI Class Initialized
INFO - 2021-06-30 08:29:59 --> Router Class Initialized
INFO - 2021-06-30 08:29:59 --> Output Class Initialized
INFO - 2021-06-30 08:29:59 --> Security Class Initialized
DEBUG - 2021-06-30 08:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:29:59 --> Input Class Initialized
INFO - 2021-06-30 08:29:59 --> Language Class Initialized
ERROR - 2021-06-30 08:29:59 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 65
INFO - 2021-06-30 08:33:39 --> Config Class Initialized
INFO - 2021-06-30 08:33:39 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:33:39 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:33:39 --> Utf8 Class Initialized
INFO - 2021-06-30 08:33:39 --> URI Class Initialized
INFO - 2021-06-30 08:33:39 --> Router Class Initialized
INFO - 2021-06-30 08:33:39 --> Output Class Initialized
INFO - 2021-06-30 08:33:39 --> Security Class Initialized
DEBUG - 2021-06-30 08:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:33:39 --> Input Class Initialized
INFO - 2021-06-30 08:33:39 --> Language Class Initialized
INFO - 2021-06-30 08:33:39 --> Loader Class Initialized
INFO - 2021-06-30 08:33:39 --> Helper loaded: html_helper
INFO - 2021-06-30 08:33:39 --> Helper loaded: url_helper
INFO - 2021-06-30 08:33:39 --> Helper loaded: form_helper
INFO - 2021-06-30 08:33:39 --> Database Driver Class Initialized
INFO - 2021-06-30 08:33:40 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:33:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:33:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:33:40 --> Encryption Class Initialized
INFO - 2021-06-30 08:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:33:40 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:33:40 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:33:40 --> Model "user_model" initialized
INFO - 2021-06-30 08:33:40 --> Model "role_model" initialized
INFO - 2021-06-30 08:33:40 --> Controller Class Initialized
INFO - 2021-06-30 08:33:40 --> Helper loaded: language_helper
INFO - 2021-06-30 08:33:40 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:33:40 --> Final output sent to browser
DEBUG - 2021-06-30 08:33:40 --> Total execution time: 0.0847
INFO - 2021-06-30 08:34:06 --> Config Class Initialized
INFO - 2021-06-30 08:34:06 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:34:06 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:34:06 --> Utf8 Class Initialized
INFO - 2021-06-30 08:34:06 --> URI Class Initialized
INFO - 2021-06-30 08:34:06 --> Router Class Initialized
INFO - 2021-06-30 08:34:06 --> Output Class Initialized
INFO - 2021-06-30 08:34:06 --> Security Class Initialized
DEBUG - 2021-06-30 08:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:34:06 --> Input Class Initialized
INFO - 2021-06-30 08:34:06 --> Language Class Initialized
INFO - 2021-06-30 08:34:06 --> Loader Class Initialized
INFO - 2021-06-30 08:34:06 --> Helper loaded: html_helper
INFO - 2021-06-30 08:34:06 --> Helper loaded: url_helper
INFO - 2021-06-30 08:34:06 --> Helper loaded: form_helper
INFO - 2021-06-30 08:34:06 --> Database Driver Class Initialized
INFO - 2021-06-30 08:34:06 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:34:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:34:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:34:06 --> Encryption Class Initialized
INFO - 2021-06-30 08:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:34:06 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:34:06 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:34:06 --> Model "user_model" initialized
INFO - 2021-06-30 08:34:06 --> Model "role_model" initialized
INFO - 2021-06-30 08:34:06 --> Controller Class Initialized
INFO - 2021-06-30 08:34:06 --> Helper loaded: language_helper
INFO - 2021-06-30 08:34:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:34:06 --> Final output sent to browser
DEBUG - 2021-06-30 08:34:06 --> Total execution time: 0.0855
INFO - 2021-06-30 08:34:15 --> Config Class Initialized
INFO - 2021-06-30 08:34:15 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:34:15 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:34:15 --> Utf8 Class Initialized
INFO - 2021-06-30 08:34:15 --> URI Class Initialized
INFO - 2021-06-30 08:34:15 --> Router Class Initialized
INFO - 2021-06-30 08:34:15 --> Output Class Initialized
INFO - 2021-06-30 08:34:15 --> Security Class Initialized
DEBUG - 2021-06-30 08:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:34:15 --> Input Class Initialized
INFO - 2021-06-30 08:34:15 --> Language Class Initialized
INFO - 2021-06-30 08:34:15 --> Loader Class Initialized
INFO - 2021-06-30 08:34:15 --> Helper loaded: html_helper
INFO - 2021-06-30 08:34:15 --> Helper loaded: url_helper
INFO - 2021-06-30 08:34:15 --> Helper loaded: form_helper
INFO - 2021-06-30 08:34:15 --> Database Driver Class Initialized
INFO - 2021-06-30 08:34:15 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:34:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:34:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:34:15 --> Encryption Class Initialized
INFO - 2021-06-30 08:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:34:15 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:34:15 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:34:15 --> Model "user_model" initialized
INFO - 2021-06-30 08:34:15 --> Model "role_model" initialized
INFO - 2021-06-30 08:34:15 --> Controller Class Initialized
INFO - 2021-06-30 08:34:15 --> Helper loaded: language_helper
INFO - 2021-06-30 08:34:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:34:15 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:34:15 --> Model "Product_model" initialized
INFO - 2021-06-30 08:34:15 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 08:34:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 08:34:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 08:34:15 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 08:34:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 08:34:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 08:34:15 --> Final output sent to browser
DEBUG - 2021-06-30 08:34:15 --> Total execution time: 0.0679
INFO - 2021-06-30 08:34:17 --> Config Class Initialized
INFO - 2021-06-30 08:34:17 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:34:17 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:34:17 --> Utf8 Class Initialized
INFO - 2021-06-30 08:34:17 --> URI Class Initialized
INFO - 2021-06-30 08:34:17 --> Router Class Initialized
INFO - 2021-06-30 08:34:17 --> Output Class Initialized
INFO - 2021-06-30 08:34:17 --> Security Class Initialized
DEBUG - 2021-06-30 08:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:34:17 --> Input Class Initialized
INFO - 2021-06-30 08:34:17 --> Language Class Initialized
INFO - 2021-06-30 08:34:17 --> Loader Class Initialized
INFO - 2021-06-30 08:34:17 --> Helper loaded: html_helper
INFO - 2021-06-30 08:34:17 --> Helper loaded: url_helper
INFO - 2021-06-30 08:34:17 --> Helper loaded: form_helper
INFO - 2021-06-30 08:34:17 --> Database Driver Class Initialized
INFO - 2021-06-30 08:34:17 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:34:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:34:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:34:17 --> Encryption Class Initialized
INFO - 2021-06-30 08:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:34:17 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:34:17 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:34:17 --> Model "user_model" initialized
INFO - 2021-06-30 08:34:17 --> Model "role_model" initialized
INFO - 2021-06-30 08:34:17 --> Controller Class Initialized
INFO - 2021-06-30 08:34:17 --> Helper loaded: language_helper
INFO - 2021-06-30 08:34:17 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:34:17 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:34:17 --> Model "Product_model" initialized
INFO - 2021-06-30 08:34:17 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 08:34:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 08:34:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 08:34:17 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 08:34:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 08:34:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 08:34:17 --> Final output sent to browser
DEBUG - 2021-06-30 08:34:17 --> Total execution time: 0.0897
INFO - 2021-06-30 08:34:52 --> Config Class Initialized
INFO - 2021-06-30 08:34:52 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:34:52 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:34:52 --> Utf8 Class Initialized
INFO - 2021-06-30 08:34:52 --> URI Class Initialized
INFO - 2021-06-30 08:34:52 --> Router Class Initialized
INFO - 2021-06-30 08:34:52 --> Output Class Initialized
INFO - 2021-06-30 08:34:52 --> Security Class Initialized
DEBUG - 2021-06-30 08:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:34:52 --> Input Class Initialized
INFO - 2021-06-30 08:34:52 --> Language Class Initialized
INFO - 2021-06-30 08:34:52 --> Loader Class Initialized
INFO - 2021-06-30 08:34:52 --> Helper loaded: html_helper
INFO - 2021-06-30 08:34:52 --> Helper loaded: url_helper
INFO - 2021-06-30 08:34:52 --> Helper loaded: form_helper
INFO - 2021-06-30 08:34:52 --> Database Driver Class Initialized
INFO - 2021-06-30 08:34:52 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:34:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:34:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:34:52 --> Encryption Class Initialized
INFO - 2021-06-30 08:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:34:52 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:34:52 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:34:52 --> Model "user_model" initialized
INFO - 2021-06-30 08:34:52 --> Model "role_model" initialized
INFO - 2021-06-30 08:34:52 --> Controller Class Initialized
INFO - 2021-06-30 08:34:52 --> Helper loaded: language_helper
INFO - 2021-06-30 08:34:52 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:34:52 --> Final output sent to browser
DEBUG - 2021-06-30 08:34:52 --> Total execution time: 0.0839
INFO - 2021-06-30 08:35:02 --> Config Class Initialized
INFO - 2021-06-30 08:35:02 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:35:02 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:35:02 --> Utf8 Class Initialized
INFO - 2021-06-30 08:35:02 --> URI Class Initialized
INFO - 2021-06-30 08:35:02 --> Router Class Initialized
INFO - 2021-06-30 08:35:02 --> Output Class Initialized
INFO - 2021-06-30 08:35:02 --> Security Class Initialized
DEBUG - 2021-06-30 08:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:35:02 --> Input Class Initialized
INFO - 2021-06-30 08:35:02 --> Language Class Initialized
INFO - 2021-06-30 08:35:02 --> Loader Class Initialized
INFO - 2021-06-30 08:35:02 --> Helper loaded: html_helper
INFO - 2021-06-30 08:35:02 --> Helper loaded: url_helper
INFO - 2021-06-30 08:35:02 --> Helper loaded: form_helper
INFO - 2021-06-30 08:35:02 --> Database Driver Class Initialized
INFO - 2021-06-30 08:35:02 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:35:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:35:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:35:02 --> Encryption Class Initialized
INFO - 2021-06-30 08:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:35:02 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:35:02 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:35:02 --> Model "user_model" initialized
INFO - 2021-06-30 08:35:02 --> Model "role_model" initialized
INFO - 2021-06-30 08:35:02 --> Controller Class Initialized
INFO - 2021-06-30 08:35:02 --> Helper loaded: language_helper
INFO - 2021-06-30 08:35:02 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:35:02 --> Final output sent to browser
DEBUG - 2021-06-30 08:35:02 --> Total execution time: 0.0638
INFO - 2021-06-30 08:35:03 --> Config Class Initialized
INFO - 2021-06-30 08:35:03 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:35:03 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:35:03 --> Utf8 Class Initialized
INFO - 2021-06-30 08:35:03 --> URI Class Initialized
INFO - 2021-06-30 08:35:03 --> Router Class Initialized
INFO - 2021-06-30 08:35:03 --> Output Class Initialized
INFO - 2021-06-30 08:35:03 --> Security Class Initialized
DEBUG - 2021-06-30 08:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:35:03 --> Input Class Initialized
INFO - 2021-06-30 08:35:03 --> Language Class Initialized
INFO - 2021-06-30 08:35:03 --> Loader Class Initialized
INFO - 2021-06-30 08:35:03 --> Helper loaded: html_helper
INFO - 2021-06-30 08:35:03 --> Helper loaded: url_helper
INFO - 2021-06-30 08:35:03 --> Helper loaded: form_helper
INFO - 2021-06-30 08:35:03 --> Database Driver Class Initialized
INFO - 2021-06-30 08:35:03 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:35:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:35:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:35:03 --> Encryption Class Initialized
INFO - 2021-06-30 08:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:35:03 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:35:03 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:35:03 --> Model "user_model" initialized
INFO - 2021-06-30 08:35:03 --> Model "role_model" initialized
INFO - 2021-06-30 08:35:03 --> Controller Class Initialized
INFO - 2021-06-30 08:35:03 --> Helper loaded: language_helper
INFO - 2021-06-30 08:35:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:35:03 --> Final output sent to browser
DEBUG - 2021-06-30 08:35:03 --> Total execution time: 0.0628
INFO - 2021-06-30 08:35:22 --> Config Class Initialized
INFO - 2021-06-30 08:35:22 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:35:22 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:35:22 --> Utf8 Class Initialized
INFO - 2021-06-30 08:35:22 --> URI Class Initialized
INFO - 2021-06-30 08:35:22 --> Router Class Initialized
INFO - 2021-06-30 08:35:22 --> Output Class Initialized
INFO - 2021-06-30 08:35:22 --> Security Class Initialized
DEBUG - 2021-06-30 08:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:35:22 --> Input Class Initialized
INFO - 2021-06-30 08:35:22 --> Language Class Initialized
INFO - 2021-06-30 08:35:22 --> Loader Class Initialized
INFO - 2021-06-30 08:35:22 --> Helper loaded: html_helper
INFO - 2021-06-30 08:35:22 --> Helper loaded: url_helper
INFO - 2021-06-30 08:35:22 --> Helper loaded: form_helper
INFO - 2021-06-30 08:35:22 --> Database Driver Class Initialized
INFO - 2021-06-30 08:35:22 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:35:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:35:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:35:22 --> Encryption Class Initialized
INFO - 2021-06-30 08:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:35:22 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:35:22 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:35:22 --> Model "user_model" initialized
INFO - 2021-06-30 08:35:22 --> Model "role_model" initialized
INFO - 2021-06-30 08:35:22 --> Controller Class Initialized
INFO - 2021-06-30 08:35:22 --> Helper loaded: language_helper
INFO - 2021-06-30 08:35:22 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:35:22 --> Final output sent to browser
DEBUG - 2021-06-30 08:35:22 --> Total execution time: 0.0754
INFO - 2021-06-30 08:35:34 --> Config Class Initialized
INFO - 2021-06-30 08:35:34 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:35:34 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:35:34 --> Utf8 Class Initialized
INFO - 2021-06-30 08:35:34 --> URI Class Initialized
INFO - 2021-06-30 08:35:34 --> Router Class Initialized
INFO - 2021-06-30 08:35:34 --> Output Class Initialized
INFO - 2021-06-30 08:35:34 --> Security Class Initialized
DEBUG - 2021-06-30 08:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:35:34 --> Input Class Initialized
INFO - 2021-06-30 08:35:34 --> Language Class Initialized
INFO - 2021-06-30 08:35:34 --> Loader Class Initialized
INFO - 2021-06-30 08:35:34 --> Helper loaded: html_helper
INFO - 2021-06-30 08:35:34 --> Helper loaded: url_helper
INFO - 2021-06-30 08:35:34 --> Helper loaded: form_helper
INFO - 2021-06-30 08:35:34 --> Database Driver Class Initialized
INFO - 2021-06-30 08:35:34 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:35:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:35:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:35:34 --> Encryption Class Initialized
INFO - 2021-06-30 08:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:35:34 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:35:34 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:35:34 --> Model "user_model" initialized
INFO - 2021-06-30 08:35:34 --> Model "role_model" initialized
INFO - 2021-06-30 08:35:34 --> Controller Class Initialized
INFO - 2021-06-30 08:35:34 --> Helper loaded: language_helper
INFO - 2021-06-30 08:35:34 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:35:34 --> Final output sent to browser
DEBUG - 2021-06-30 08:35:34 --> Total execution time: 0.0672
INFO - 2021-06-30 08:36:04 --> Config Class Initialized
INFO - 2021-06-30 08:36:04 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:36:04 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:36:04 --> Utf8 Class Initialized
INFO - 2021-06-30 08:36:04 --> URI Class Initialized
INFO - 2021-06-30 08:36:04 --> Router Class Initialized
INFO - 2021-06-30 08:36:04 --> Output Class Initialized
INFO - 2021-06-30 08:36:04 --> Security Class Initialized
DEBUG - 2021-06-30 08:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:36:04 --> Input Class Initialized
INFO - 2021-06-30 08:36:04 --> Language Class Initialized
INFO - 2021-06-30 08:36:04 --> Loader Class Initialized
INFO - 2021-06-30 08:36:04 --> Helper loaded: html_helper
INFO - 2021-06-30 08:36:04 --> Helper loaded: url_helper
INFO - 2021-06-30 08:36:04 --> Helper loaded: form_helper
INFO - 2021-06-30 08:36:04 --> Database Driver Class Initialized
INFO - 2021-06-30 08:36:04 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:36:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:36:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:36:04 --> Encryption Class Initialized
INFO - 2021-06-30 08:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:36:04 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:36:04 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:36:04 --> Model "user_model" initialized
INFO - 2021-06-30 08:36:04 --> Model "role_model" initialized
INFO - 2021-06-30 08:36:04 --> Controller Class Initialized
INFO - 2021-06-30 08:36:04 --> Helper loaded: language_helper
INFO - 2021-06-30 08:36:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:36:04 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:36:04 --> Model "Product_model" initialized
INFO - 2021-06-30 08:36:04 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 08:36:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 08:36:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 08:36:05 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 08:36:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 08:36:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 08:36:05 --> Final output sent to browser
DEBUG - 2021-06-30 08:36:05 --> Total execution time: 0.1163
INFO - 2021-06-30 08:37:50 --> Config Class Initialized
INFO - 2021-06-30 08:37:50 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:37:50 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:37:50 --> Utf8 Class Initialized
INFO - 2021-06-30 08:37:50 --> URI Class Initialized
INFO - 2021-06-30 08:37:50 --> Router Class Initialized
INFO - 2021-06-30 08:37:50 --> Output Class Initialized
INFO - 2021-06-30 08:37:50 --> Security Class Initialized
DEBUG - 2021-06-30 08:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:37:50 --> Input Class Initialized
INFO - 2021-06-30 08:37:50 --> Language Class Initialized
INFO - 2021-06-30 08:37:50 --> Loader Class Initialized
INFO - 2021-06-30 08:37:50 --> Helper loaded: html_helper
INFO - 2021-06-30 08:37:50 --> Helper loaded: url_helper
INFO - 2021-06-30 08:37:50 --> Helper loaded: form_helper
INFO - 2021-06-30 08:37:50 --> Database Driver Class Initialized
INFO - 2021-06-30 08:37:50 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:37:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:37:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:37:50 --> Encryption Class Initialized
INFO - 2021-06-30 08:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:37:50 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:37:50 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:37:50 --> Model "user_model" initialized
INFO - 2021-06-30 08:37:50 --> Model "role_model" initialized
INFO - 2021-06-30 08:37:50 --> Controller Class Initialized
INFO - 2021-06-30 08:37:50 --> Helper loaded: language_helper
INFO - 2021-06-30 08:37:50 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:37:50 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:37:50 --> Model "Product_model" initialized
INFO - 2021-06-30 08:37:50 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 08:37:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 08:37:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 08:37:50 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 08:37:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 08:37:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 08:37:50 --> Final output sent to browser
DEBUG - 2021-06-30 08:37:50 --> Total execution time: 0.1113
INFO - 2021-06-30 08:38:15 --> Config Class Initialized
INFO - 2021-06-30 08:38:15 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:38:15 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:38:15 --> Utf8 Class Initialized
INFO - 2021-06-30 08:38:15 --> URI Class Initialized
INFO - 2021-06-30 08:38:15 --> Router Class Initialized
INFO - 2021-06-30 08:38:15 --> Output Class Initialized
INFO - 2021-06-30 08:38:15 --> Security Class Initialized
DEBUG - 2021-06-30 08:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:38:15 --> Input Class Initialized
INFO - 2021-06-30 08:38:15 --> Language Class Initialized
INFO - 2021-06-30 08:38:15 --> Loader Class Initialized
INFO - 2021-06-30 08:38:15 --> Helper loaded: html_helper
INFO - 2021-06-30 08:38:15 --> Helper loaded: url_helper
INFO - 2021-06-30 08:38:15 --> Helper loaded: form_helper
INFO - 2021-06-30 08:38:15 --> Database Driver Class Initialized
INFO - 2021-06-30 08:38:15 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:38:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:38:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:38:15 --> Encryption Class Initialized
INFO - 2021-06-30 08:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:38:15 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:38:15 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:38:15 --> Model "user_model" initialized
INFO - 2021-06-30 08:38:15 --> Model "role_model" initialized
INFO - 2021-06-30 08:38:15 --> Controller Class Initialized
INFO - 2021-06-30 08:38:15 --> Helper loaded: language_helper
INFO - 2021-06-30 08:38:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:38:15 --> Final output sent to browser
DEBUG - 2021-06-30 08:38:15 --> Total execution time: 0.0614
INFO - 2021-06-30 08:38:16 --> Config Class Initialized
INFO - 2021-06-30 08:38:16 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:38:16 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:38:16 --> Utf8 Class Initialized
INFO - 2021-06-30 08:38:16 --> URI Class Initialized
INFO - 2021-06-30 08:38:16 --> Router Class Initialized
INFO - 2021-06-30 08:38:16 --> Output Class Initialized
INFO - 2021-06-30 08:38:16 --> Security Class Initialized
DEBUG - 2021-06-30 08:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:38:16 --> Input Class Initialized
INFO - 2021-06-30 08:38:16 --> Language Class Initialized
INFO - 2021-06-30 08:38:16 --> Loader Class Initialized
INFO - 2021-06-30 08:38:16 --> Helper loaded: html_helper
INFO - 2021-06-30 08:38:16 --> Helper loaded: url_helper
INFO - 2021-06-30 08:38:16 --> Helper loaded: form_helper
INFO - 2021-06-30 08:38:16 --> Database Driver Class Initialized
INFO - 2021-06-30 08:38:17 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:38:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:38:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:38:17 --> Encryption Class Initialized
INFO - 2021-06-30 08:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:38:17 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:38:17 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:38:17 --> Model "user_model" initialized
INFO - 2021-06-30 08:38:17 --> Model "role_model" initialized
INFO - 2021-06-30 08:38:17 --> Controller Class Initialized
INFO - 2021-06-30 08:38:17 --> Helper loaded: language_helper
INFO - 2021-06-30 08:38:17 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:38:17 --> Final output sent to browser
DEBUG - 2021-06-30 08:38:17 --> Total execution time: 0.0636
INFO - 2021-06-30 08:38:20 --> Config Class Initialized
INFO - 2021-06-30 08:38:20 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:38:20 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:38:20 --> Utf8 Class Initialized
INFO - 2021-06-30 08:38:20 --> URI Class Initialized
INFO - 2021-06-30 08:38:20 --> Router Class Initialized
INFO - 2021-06-30 08:38:20 --> Output Class Initialized
INFO - 2021-06-30 08:38:20 --> Security Class Initialized
DEBUG - 2021-06-30 08:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:38:20 --> Input Class Initialized
INFO - 2021-06-30 08:38:20 --> Language Class Initialized
INFO - 2021-06-30 08:38:20 --> Loader Class Initialized
INFO - 2021-06-30 08:38:20 --> Helper loaded: html_helper
INFO - 2021-06-30 08:38:20 --> Helper loaded: url_helper
INFO - 2021-06-30 08:38:20 --> Helper loaded: form_helper
INFO - 2021-06-30 08:38:20 --> Database Driver Class Initialized
INFO - 2021-06-30 08:38:20 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:38:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:38:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:38:20 --> Encryption Class Initialized
INFO - 2021-06-30 08:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:38:20 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:38:20 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:38:20 --> Model "user_model" initialized
INFO - 2021-06-30 08:38:20 --> Model "role_model" initialized
INFO - 2021-06-30 08:38:20 --> Controller Class Initialized
INFO - 2021-06-30 08:38:20 --> Helper loaded: language_helper
INFO - 2021-06-30 08:38:20 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:38:20 --> Final output sent to browser
DEBUG - 2021-06-30 08:38:20 --> Total execution time: 0.0785
INFO - 2021-06-30 08:38:23 --> Config Class Initialized
INFO - 2021-06-30 08:38:23 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:38:23 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:38:23 --> Utf8 Class Initialized
INFO - 2021-06-30 08:38:23 --> URI Class Initialized
INFO - 2021-06-30 08:38:23 --> Router Class Initialized
INFO - 2021-06-30 08:38:23 --> Output Class Initialized
INFO - 2021-06-30 08:38:23 --> Security Class Initialized
DEBUG - 2021-06-30 08:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:38:23 --> Input Class Initialized
INFO - 2021-06-30 08:38:23 --> Language Class Initialized
INFO - 2021-06-30 08:38:23 --> Loader Class Initialized
INFO - 2021-06-30 08:38:23 --> Helper loaded: html_helper
INFO - 2021-06-30 08:38:23 --> Helper loaded: url_helper
INFO - 2021-06-30 08:38:23 --> Helper loaded: form_helper
INFO - 2021-06-30 08:38:23 --> Database Driver Class Initialized
INFO - 2021-06-30 08:38:23 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:38:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:38:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:38:23 --> Encryption Class Initialized
INFO - 2021-06-30 08:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:38:23 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:38:23 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:38:23 --> Model "user_model" initialized
INFO - 2021-06-30 08:38:23 --> Model "role_model" initialized
INFO - 2021-06-30 08:38:23 --> Controller Class Initialized
INFO - 2021-06-30 08:38:23 --> Helper loaded: language_helper
INFO - 2021-06-30 08:38:23 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:38:23 --> Final output sent to browser
DEBUG - 2021-06-30 08:38:23 --> Total execution time: 0.0692
INFO - 2021-06-30 08:38:29 --> Config Class Initialized
INFO - 2021-06-30 08:38:29 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:38:29 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:38:29 --> Utf8 Class Initialized
INFO - 2021-06-30 08:38:29 --> URI Class Initialized
INFO - 2021-06-30 08:38:29 --> Router Class Initialized
INFO - 2021-06-30 08:38:29 --> Output Class Initialized
INFO - 2021-06-30 08:38:29 --> Security Class Initialized
DEBUG - 2021-06-30 08:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:38:29 --> Input Class Initialized
INFO - 2021-06-30 08:38:29 --> Language Class Initialized
INFO - 2021-06-30 08:38:29 --> Loader Class Initialized
INFO - 2021-06-30 08:38:29 --> Helper loaded: html_helper
INFO - 2021-06-30 08:38:29 --> Helper loaded: url_helper
INFO - 2021-06-30 08:38:29 --> Helper loaded: form_helper
INFO - 2021-06-30 08:38:29 --> Database Driver Class Initialized
INFO - 2021-06-30 08:38:29 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:38:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:38:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:38:29 --> Encryption Class Initialized
INFO - 2021-06-30 08:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:38:29 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:38:29 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:38:29 --> Model "user_model" initialized
INFO - 2021-06-30 08:38:29 --> Model "role_model" initialized
INFO - 2021-06-30 08:38:29 --> Controller Class Initialized
INFO - 2021-06-30 08:38:29 --> Helper loaded: language_helper
INFO - 2021-06-30 08:38:29 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:38:29 --> Final output sent to browser
DEBUG - 2021-06-30 08:38:29 --> Total execution time: 0.0741
INFO - 2021-06-30 08:38:45 --> Config Class Initialized
INFO - 2021-06-30 08:38:45 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:38:45 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:38:45 --> Utf8 Class Initialized
INFO - 2021-06-30 08:38:45 --> URI Class Initialized
INFO - 2021-06-30 08:38:45 --> Router Class Initialized
INFO - 2021-06-30 08:38:45 --> Output Class Initialized
INFO - 2021-06-30 08:38:45 --> Security Class Initialized
DEBUG - 2021-06-30 08:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:38:45 --> Input Class Initialized
INFO - 2021-06-30 08:38:45 --> Language Class Initialized
INFO - 2021-06-30 08:38:45 --> Loader Class Initialized
INFO - 2021-06-30 08:38:45 --> Helper loaded: html_helper
INFO - 2021-06-30 08:38:45 --> Helper loaded: url_helper
INFO - 2021-06-30 08:38:45 --> Helper loaded: form_helper
INFO - 2021-06-30 08:38:45 --> Database Driver Class Initialized
INFO - 2021-06-30 08:38:45 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:38:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:38:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:38:45 --> Encryption Class Initialized
INFO - 2021-06-30 08:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:38:45 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:38:45 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:38:45 --> Model "user_model" initialized
INFO - 2021-06-30 08:38:45 --> Model "role_model" initialized
INFO - 2021-06-30 08:38:45 --> Controller Class Initialized
INFO - 2021-06-30 08:38:45 --> Helper loaded: language_helper
INFO - 2021-06-30 08:38:45 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:38:45 --> Final output sent to browser
DEBUG - 2021-06-30 08:38:45 --> Total execution time: 0.0739
INFO - 2021-06-30 08:38:49 --> Config Class Initialized
INFO - 2021-06-30 08:38:49 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:38:49 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:38:49 --> Utf8 Class Initialized
INFO - 2021-06-30 08:38:49 --> URI Class Initialized
INFO - 2021-06-30 08:38:49 --> Router Class Initialized
INFO - 2021-06-30 08:38:49 --> Output Class Initialized
INFO - 2021-06-30 08:38:49 --> Security Class Initialized
DEBUG - 2021-06-30 08:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:38:49 --> Input Class Initialized
INFO - 2021-06-30 08:38:49 --> Language Class Initialized
INFO - 2021-06-30 08:38:49 --> Loader Class Initialized
INFO - 2021-06-30 08:38:49 --> Helper loaded: html_helper
INFO - 2021-06-30 08:38:49 --> Helper loaded: url_helper
INFO - 2021-06-30 08:38:49 --> Helper loaded: form_helper
INFO - 2021-06-30 08:38:49 --> Database Driver Class Initialized
INFO - 2021-06-30 08:38:49 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:38:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:38:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:38:49 --> Encryption Class Initialized
INFO - 2021-06-30 08:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:38:49 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:38:49 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:38:49 --> Model "user_model" initialized
INFO - 2021-06-30 08:38:49 --> Model "role_model" initialized
INFO - 2021-06-30 08:38:49 --> Controller Class Initialized
INFO - 2021-06-30 08:38:49 --> Helper loaded: language_helper
INFO - 2021-06-30 08:38:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:38:49 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:38:49 --> Model "Product_model" initialized
INFO - 2021-06-30 08:38:49 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 08:38:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 08:38:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 08:38:49 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 08:38:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 08:38:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 08:38:49 --> Final output sent to browser
DEBUG - 2021-06-30 08:38:49 --> Total execution time: 0.0732
INFO - 2021-06-30 08:39:11 --> Config Class Initialized
INFO - 2021-06-30 08:39:11 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:39:11 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:39:11 --> Utf8 Class Initialized
INFO - 2021-06-30 08:39:11 --> URI Class Initialized
INFO - 2021-06-30 08:39:11 --> Router Class Initialized
INFO - 2021-06-30 08:39:11 --> Output Class Initialized
INFO - 2021-06-30 08:39:11 --> Security Class Initialized
DEBUG - 2021-06-30 08:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:39:11 --> Input Class Initialized
INFO - 2021-06-30 08:39:11 --> Language Class Initialized
INFO - 2021-06-30 08:39:11 --> Loader Class Initialized
INFO - 2021-06-30 08:39:11 --> Helper loaded: html_helper
INFO - 2021-06-30 08:39:11 --> Helper loaded: url_helper
INFO - 2021-06-30 08:39:11 --> Helper loaded: form_helper
INFO - 2021-06-30 08:39:11 --> Database Driver Class Initialized
INFO - 2021-06-30 08:39:11 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:39:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:39:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:39:11 --> Encryption Class Initialized
INFO - 2021-06-30 08:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:39:11 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:39:11 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:39:11 --> Model "user_model" initialized
INFO - 2021-06-30 08:39:11 --> Model "role_model" initialized
INFO - 2021-06-30 08:39:11 --> Controller Class Initialized
INFO - 2021-06-30 08:39:11 --> Helper loaded: language_helper
INFO - 2021-06-30 08:39:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:39:11 --> Final output sent to browser
DEBUG - 2021-06-30 08:39:11 --> Total execution time: 0.0952
INFO - 2021-06-30 08:40:51 --> Config Class Initialized
INFO - 2021-06-30 08:40:51 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:40:51 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:40:51 --> Utf8 Class Initialized
INFO - 2021-06-30 08:40:51 --> URI Class Initialized
INFO - 2021-06-30 08:40:51 --> Router Class Initialized
INFO - 2021-06-30 08:40:51 --> Output Class Initialized
INFO - 2021-06-30 08:40:51 --> Security Class Initialized
DEBUG - 2021-06-30 08:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:40:51 --> Input Class Initialized
INFO - 2021-06-30 08:40:51 --> Language Class Initialized
INFO - 2021-06-30 08:40:51 --> Loader Class Initialized
INFO - 2021-06-30 08:40:51 --> Helper loaded: html_helper
INFO - 2021-06-30 08:40:51 --> Helper loaded: url_helper
INFO - 2021-06-30 08:40:51 --> Helper loaded: form_helper
INFO - 2021-06-30 08:40:51 --> Database Driver Class Initialized
INFO - 2021-06-30 08:40:51 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:40:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:40:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:40:51 --> Encryption Class Initialized
INFO - 2021-06-30 08:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:40:51 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:40:51 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:40:51 --> Model "user_model" initialized
INFO - 2021-06-30 08:40:51 --> Model "role_model" initialized
INFO - 2021-06-30 08:40:51 --> Controller Class Initialized
INFO - 2021-06-30 08:40:51 --> Helper loaded: language_helper
INFO - 2021-06-30 08:40:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:40:51 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:40:51 --> Model "Product_model" initialized
INFO - 2021-06-30 08:40:51 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 08:40:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 08:40:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 08:40:51 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 08:40:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 08:40:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 08:40:51 --> Final output sent to browser
DEBUG - 2021-06-30 08:40:51 --> Total execution time: 0.0868
INFO - 2021-06-30 08:41:12 --> Config Class Initialized
INFO - 2021-06-30 08:41:12 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:41:12 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:41:12 --> Utf8 Class Initialized
INFO - 2021-06-30 08:41:12 --> URI Class Initialized
INFO - 2021-06-30 08:41:12 --> Router Class Initialized
INFO - 2021-06-30 08:41:12 --> Output Class Initialized
INFO - 2021-06-30 08:41:12 --> Security Class Initialized
DEBUG - 2021-06-30 08:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:41:12 --> Input Class Initialized
INFO - 2021-06-30 08:41:12 --> Language Class Initialized
INFO - 2021-06-30 08:41:12 --> Loader Class Initialized
INFO - 2021-06-30 08:41:12 --> Helper loaded: html_helper
INFO - 2021-06-30 08:41:12 --> Helper loaded: url_helper
INFO - 2021-06-30 08:41:12 --> Helper loaded: form_helper
INFO - 2021-06-30 08:41:12 --> Database Driver Class Initialized
INFO - 2021-06-30 08:41:12 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:41:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:41:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:41:12 --> Encryption Class Initialized
INFO - 2021-06-30 08:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:41:12 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:41:12 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:41:12 --> Model "user_model" initialized
INFO - 2021-06-30 08:41:12 --> Model "role_model" initialized
INFO - 2021-06-30 08:41:12 --> Controller Class Initialized
INFO - 2021-06-30 08:41:12 --> Helper loaded: language_helper
INFO - 2021-06-30 08:41:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:41:12 --> Final output sent to browser
DEBUG - 2021-06-30 08:41:12 --> Total execution time: 0.1100
INFO - 2021-06-30 08:41:48 --> Config Class Initialized
INFO - 2021-06-30 08:41:48 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:41:48 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:41:48 --> Utf8 Class Initialized
INFO - 2021-06-30 08:41:48 --> URI Class Initialized
INFO - 2021-06-30 08:41:48 --> Router Class Initialized
INFO - 2021-06-30 08:41:48 --> Output Class Initialized
INFO - 2021-06-30 08:41:48 --> Security Class Initialized
DEBUG - 2021-06-30 08:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:41:48 --> Input Class Initialized
INFO - 2021-06-30 08:41:48 --> Language Class Initialized
INFO - 2021-06-30 08:41:48 --> Loader Class Initialized
INFO - 2021-06-30 08:41:48 --> Helper loaded: html_helper
INFO - 2021-06-30 08:41:48 --> Helper loaded: url_helper
INFO - 2021-06-30 08:41:48 --> Helper loaded: form_helper
INFO - 2021-06-30 08:41:48 --> Database Driver Class Initialized
INFO - 2021-06-30 08:41:48 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:41:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:41:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:41:48 --> Encryption Class Initialized
INFO - 2021-06-30 08:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:41:48 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:41:48 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:41:48 --> Model "user_model" initialized
INFO - 2021-06-30 08:41:48 --> Model "role_model" initialized
INFO - 2021-06-30 08:41:48 --> Controller Class Initialized
INFO - 2021-06-30 08:41:48 --> Helper loaded: language_helper
INFO - 2021-06-30 08:41:48 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:41:48 --> Final output sent to browser
DEBUG - 2021-06-30 08:41:48 --> Total execution time: 0.0831
INFO - 2021-06-30 08:42:02 --> Config Class Initialized
INFO - 2021-06-30 08:42:02 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:42:02 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:42:02 --> Utf8 Class Initialized
INFO - 2021-06-30 08:42:02 --> URI Class Initialized
INFO - 2021-06-30 08:42:02 --> Router Class Initialized
INFO - 2021-06-30 08:42:02 --> Output Class Initialized
INFO - 2021-06-30 08:42:02 --> Security Class Initialized
DEBUG - 2021-06-30 08:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:42:02 --> Input Class Initialized
INFO - 2021-06-30 08:42:02 --> Language Class Initialized
INFO - 2021-06-30 08:42:02 --> Loader Class Initialized
INFO - 2021-06-30 08:42:02 --> Helper loaded: html_helper
INFO - 2021-06-30 08:42:02 --> Helper loaded: url_helper
INFO - 2021-06-30 08:42:02 --> Helper loaded: form_helper
INFO - 2021-06-30 08:42:02 --> Database Driver Class Initialized
INFO - 2021-06-30 08:42:02 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:42:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:42:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:42:02 --> Encryption Class Initialized
INFO - 2021-06-30 08:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:42:02 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:42:02 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:42:02 --> Model "user_model" initialized
INFO - 2021-06-30 08:42:02 --> Model "role_model" initialized
INFO - 2021-06-30 08:42:02 --> Controller Class Initialized
INFO - 2021-06-30 08:42:02 --> Helper loaded: language_helper
INFO - 2021-06-30 08:42:02 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:42:02 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:42:02 --> Model "Product_model" initialized
INFO - 2021-06-30 08:42:02 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 08:42:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 08:42:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 08:42:02 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 08:42:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 08:42:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 08:42:02 --> Final output sent to browser
DEBUG - 2021-06-30 08:42:02 --> Total execution time: 0.0903
INFO - 2021-06-30 08:42:27 --> Config Class Initialized
INFO - 2021-06-30 08:42:27 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:42:27 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:42:27 --> Utf8 Class Initialized
INFO - 2021-06-30 08:42:27 --> URI Class Initialized
INFO - 2021-06-30 08:42:27 --> Router Class Initialized
INFO - 2021-06-30 08:42:27 --> Output Class Initialized
INFO - 2021-06-30 08:42:27 --> Security Class Initialized
DEBUG - 2021-06-30 08:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:42:27 --> Input Class Initialized
INFO - 2021-06-30 08:42:27 --> Language Class Initialized
INFO - 2021-06-30 08:42:27 --> Loader Class Initialized
INFO - 2021-06-30 08:42:27 --> Helper loaded: html_helper
INFO - 2021-06-30 08:42:27 --> Helper loaded: url_helper
INFO - 2021-06-30 08:42:27 --> Helper loaded: form_helper
INFO - 2021-06-30 08:42:27 --> Database Driver Class Initialized
INFO - 2021-06-30 08:42:27 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:42:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:42:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:42:27 --> Encryption Class Initialized
INFO - 2021-06-30 08:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:42:27 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:42:27 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:42:27 --> Model "user_model" initialized
INFO - 2021-06-30 08:42:27 --> Model "role_model" initialized
INFO - 2021-06-30 08:42:27 --> Controller Class Initialized
INFO - 2021-06-30 08:42:27 --> Helper loaded: language_helper
INFO - 2021-06-30 08:42:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:42:27 --> Final output sent to browser
DEBUG - 2021-06-30 08:42:27 --> Total execution time: 0.0787
INFO - 2021-06-30 08:43:26 --> Config Class Initialized
INFO - 2021-06-30 08:43:26 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:43:26 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:43:26 --> Utf8 Class Initialized
INFO - 2021-06-30 08:43:26 --> URI Class Initialized
INFO - 2021-06-30 08:43:26 --> Router Class Initialized
INFO - 2021-06-30 08:43:26 --> Output Class Initialized
INFO - 2021-06-30 08:43:26 --> Security Class Initialized
DEBUG - 2021-06-30 08:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:43:26 --> Input Class Initialized
INFO - 2021-06-30 08:43:26 --> Language Class Initialized
INFO - 2021-06-30 08:43:26 --> Loader Class Initialized
INFO - 2021-06-30 08:43:26 --> Helper loaded: html_helper
INFO - 2021-06-30 08:43:26 --> Helper loaded: url_helper
INFO - 2021-06-30 08:43:26 --> Helper loaded: form_helper
INFO - 2021-06-30 08:43:26 --> Database Driver Class Initialized
INFO - 2021-06-30 08:43:26 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:43:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:43:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:43:26 --> Encryption Class Initialized
INFO - 2021-06-30 08:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:43:26 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:43:26 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:43:26 --> Model "user_model" initialized
INFO - 2021-06-30 08:43:26 --> Model "role_model" initialized
INFO - 2021-06-30 08:43:26 --> Controller Class Initialized
INFO - 2021-06-30 08:43:26 --> Helper loaded: language_helper
INFO - 2021-06-30 08:43:26 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:43:26 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:43:26 --> Model "Product_model" initialized
INFO - 2021-06-30 08:43:26 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 08:43:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 08:43:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 08:43:26 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 08:43:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 08:43:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 08:43:26 --> Final output sent to browser
DEBUG - 2021-06-30 08:43:26 --> Total execution time: 0.1291
INFO - 2021-06-30 08:43:47 --> Config Class Initialized
INFO - 2021-06-30 08:43:47 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:43:47 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:43:47 --> Utf8 Class Initialized
INFO - 2021-06-30 08:43:47 --> URI Class Initialized
INFO - 2021-06-30 08:43:47 --> Router Class Initialized
INFO - 2021-06-30 08:43:47 --> Output Class Initialized
INFO - 2021-06-30 08:43:47 --> Security Class Initialized
DEBUG - 2021-06-30 08:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:43:47 --> Input Class Initialized
INFO - 2021-06-30 08:43:47 --> Language Class Initialized
INFO - 2021-06-30 08:43:47 --> Loader Class Initialized
INFO - 2021-06-30 08:43:47 --> Helper loaded: html_helper
INFO - 2021-06-30 08:43:47 --> Helper loaded: url_helper
INFO - 2021-06-30 08:43:47 --> Helper loaded: form_helper
INFO - 2021-06-30 08:43:47 --> Database Driver Class Initialized
INFO - 2021-06-30 08:43:47 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:43:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:43:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:43:47 --> Encryption Class Initialized
INFO - 2021-06-30 08:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:43:47 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:43:47 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:43:47 --> Model "user_model" initialized
INFO - 2021-06-30 08:43:47 --> Model "role_model" initialized
INFO - 2021-06-30 08:43:47 --> Controller Class Initialized
INFO - 2021-06-30 08:43:47 --> Helper loaded: language_helper
INFO - 2021-06-30 08:43:47 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:43:47 --> Final output sent to browser
DEBUG - 2021-06-30 08:43:47 --> Total execution time: 0.0762
INFO - 2021-06-30 08:45:27 --> Config Class Initialized
INFO - 2021-06-30 08:45:27 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:45:27 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:45:27 --> Utf8 Class Initialized
INFO - 2021-06-30 08:45:27 --> URI Class Initialized
INFO - 2021-06-30 08:45:27 --> Router Class Initialized
INFO - 2021-06-30 08:45:27 --> Output Class Initialized
INFO - 2021-06-30 08:45:27 --> Security Class Initialized
DEBUG - 2021-06-30 08:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:45:27 --> Input Class Initialized
INFO - 2021-06-30 08:45:27 --> Language Class Initialized
INFO - 2021-06-30 08:45:27 --> Loader Class Initialized
INFO - 2021-06-30 08:45:27 --> Helper loaded: html_helper
INFO - 2021-06-30 08:45:27 --> Helper loaded: url_helper
INFO - 2021-06-30 08:45:27 --> Helper loaded: form_helper
INFO - 2021-06-30 08:45:27 --> Database Driver Class Initialized
INFO - 2021-06-30 08:45:27 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:45:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:45:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:45:27 --> Encryption Class Initialized
INFO - 2021-06-30 08:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:45:27 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:45:27 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:45:27 --> Model "user_model" initialized
INFO - 2021-06-30 08:45:27 --> Model "role_model" initialized
INFO - 2021-06-30 08:45:27 --> Controller Class Initialized
INFO - 2021-06-30 08:45:27 --> Helper loaded: language_helper
INFO - 2021-06-30 08:45:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:45:27 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:45:27 --> Model "Product_model" initialized
INFO - 2021-06-30 08:45:27 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 08:45:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 08:45:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 08:45:27 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 08:45:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 08:45:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 08:45:27 --> Final output sent to browser
DEBUG - 2021-06-30 08:45:27 --> Total execution time: 0.1242
INFO - 2021-06-30 08:45:47 --> Config Class Initialized
INFO - 2021-06-30 08:45:47 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:45:47 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:45:47 --> Utf8 Class Initialized
INFO - 2021-06-30 08:45:47 --> URI Class Initialized
INFO - 2021-06-30 08:45:47 --> Router Class Initialized
INFO - 2021-06-30 08:45:47 --> Output Class Initialized
INFO - 2021-06-30 08:45:47 --> Security Class Initialized
DEBUG - 2021-06-30 08:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:45:47 --> Input Class Initialized
INFO - 2021-06-30 08:45:47 --> Language Class Initialized
ERROR - 2021-06-30 08:45:47 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 99
INFO - 2021-06-30 08:46:28 --> Config Class Initialized
INFO - 2021-06-30 08:46:28 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:46:28 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:46:28 --> Utf8 Class Initialized
INFO - 2021-06-30 08:46:28 --> URI Class Initialized
INFO - 2021-06-30 08:46:28 --> Router Class Initialized
INFO - 2021-06-30 08:46:28 --> Output Class Initialized
INFO - 2021-06-30 08:46:28 --> Security Class Initialized
DEBUG - 2021-06-30 08:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:46:28 --> Input Class Initialized
INFO - 2021-06-30 08:46:28 --> Language Class Initialized
INFO - 2021-06-30 08:46:28 --> Loader Class Initialized
INFO - 2021-06-30 08:46:28 --> Helper loaded: html_helper
INFO - 2021-06-30 08:46:28 --> Helper loaded: url_helper
INFO - 2021-06-30 08:46:28 --> Helper loaded: form_helper
INFO - 2021-06-30 08:46:28 --> Database Driver Class Initialized
INFO - 2021-06-30 08:46:28 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:46:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:46:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:46:28 --> Encryption Class Initialized
INFO - 2021-06-30 08:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:46:28 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:46:28 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:46:28 --> Model "user_model" initialized
INFO - 2021-06-30 08:46:28 --> Model "role_model" initialized
INFO - 2021-06-30 08:46:28 --> Controller Class Initialized
INFO - 2021-06-30 08:46:28 --> Helper loaded: language_helper
INFO - 2021-06-30 08:46:28 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:46:28 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:46:28 --> Model "Product_model" initialized
INFO - 2021-06-30 08:46:28 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 08:46:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 08:46:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 08:46:28 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 08:46:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 08:46:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 08:46:28 --> Final output sent to browser
DEBUG - 2021-06-30 08:46:28 --> Total execution time: 0.0840
INFO - 2021-06-30 08:46:55 --> Config Class Initialized
INFO - 2021-06-30 08:46:55 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:46:55 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:46:55 --> Utf8 Class Initialized
INFO - 2021-06-30 08:46:55 --> URI Class Initialized
INFO - 2021-06-30 08:46:55 --> Router Class Initialized
INFO - 2021-06-30 08:46:55 --> Output Class Initialized
INFO - 2021-06-30 08:46:55 --> Security Class Initialized
DEBUG - 2021-06-30 08:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:46:55 --> Input Class Initialized
INFO - 2021-06-30 08:46:55 --> Language Class Initialized
INFO - 2021-06-30 08:46:55 --> Loader Class Initialized
INFO - 2021-06-30 08:46:55 --> Helper loaded: html_helper
INFO - 2021-06-30 08:46:55 --> Helper loaded: url_helper
INFO - 2021-06-30 08:46:55 --> Helper loaded: form_helper
INFO - 2021-06-30 08:46:55 --> Database Driver Class Initialized
INFO - 2021-06-30 08:46:55 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:46:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:46:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:46:55 --> Encryption Class Initialized
INFO - 2021-06-30 08:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:46:55 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:46:55 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:46:55 --> Model "user_model" initialized
INFO - 2021-06-30 08:46:55 --> Model "role_model" initialized
INFO - 2021-06-30 08:46:55 --> Controller Class Initialized
INFO - 2021-06-30 08:46:55 --> Helper loaded: language_helper
INFO - 2021-06-30 08:46:55 --> Language file loaded: language/english/content_lang.php
ERROR - 2021-06-30 08:46:55 --> Severity: Notice --> Undefined variable: customer_id D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 90
ERROR - 2021-06-30 08:46:55 --> Severity: Notice --> Undefined variable: customer_name D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 91
ERROR - 2021-06-30 08:46:55 --> Severity: Notice --> Undefined variable: address D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 92
ERROR - 2021-06-30 08:46:55 --> Severity: Notice --> Undefined variable: city D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 93
ERROR - 2021-06-30 08:46:55 --> Severity: Notice --> Undefined variable: state D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 94
ERROR - 2021-06-30 08:46:55 --> Severity: Notice --> Undefined variable: country D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 95
ERROR - 2021-06-30 08:46:55 --> Severity: Notice --> Undefined variable: gstin D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 96
ERROR - 2021-06-30 08:46:55 --> Severity: Notice --> Undefined variable: pan D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 97
ERROR - 2021-06-30 08:46:55 --> Severity: Notice --> Undefined variable: tan D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 98
INFO - 2021-06-30 08:46:55 --> Final output sent to browser
DEBUG - 2021-06-30 08:46:55 --> Total execution time: 0.1113
INFO - 2021-06-30 08:47:59 --> Config Class Initialized
INFO - 2021-06-30 08:47:59 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:47:59 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:47:59 --> Utf8 Class Initialized
INFO - 2021-06-30 08:47:59 --> URI Class Initialized
INFO - 2021-06-30 08:47:59 --> Router Class Initialized
INFO - 2021-06-30 08:47:59 --> Output Class Initialized
INFO - 2021-06-30 08:47:59 --> Security Class Initialized
DEBUG - 2021-06-30 08:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:47:59 --> Input Class Initialized
INFO - 2021-06-30 08:47:59 --> Language Class Initialized
INFO - 2021-06-30 08:47:59 --> Loader Class Initialized
INFO - 2021-06-30 08:47:59 --> Helper loaded: html_helper
INFO - 2021-06-30 08:47:59 --> Helper loaded: url_helper
INFO - 2021-06-30 08:47:59 --> Helper loaded: form_helper
INFO - 2021-06-30 08:47:59 --> Database Driver Class Initialized
INFO - 2021-06-30 08:47:59 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:47:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:47:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:47:59 --> Encryption Class Initialized
INFO - 2021-06-30 08:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:47:59 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:47:59 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:47:59 --> Model "user_model" initialized
INFO - 2021-06-30 08:47:59 --> Model "role_model" initialized
INFO - 2021-06-30 08:47:59 --> Controller Class Initialized
INFO - 2021-06-30 08:47:59 --> Helper loaded: language_helper
INFO - 2021-06-30 08:47:59 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:47:59 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:47:59 --> Model "Product_model" initialized
INFO - 2021-06-30 08:47:59 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 08:47:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 08:47:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 08:47:59 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 08:47:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 08:47:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 08:47:59 --> Final output sent to browser
DEBUG - 2021-06-30 08:47:59 --> Total execution time: 0.0813
INFO - 2021-06-30 08:48:24 --> Config Class Initialized
INFO - 2021-06-30 08:48:24 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:48:24 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:48:24 --> Utf8 Class Initialized
INFO - 2021-06-30 08:48:24 --> URI Class Initialized
INFO - 2021-06-30 08:48:24 --> Router Class Initialized
INFO - 2021-06-30 08:48:24 --> Output Class Initialized
INFO - 2021-06-30 08:48:24 --> Security Class Initialized
DEBUG - 2021-06-30 08:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:48:24 --> Input Class Initialized
INFO - 2021-06-30 08:48:24 --> Language Class Initialized
INFO - 2021-06-30 08:48:24 --> Loader Class Initialized
INFO - 2021-06-30 08:48:24 --> Helper loaded: html_helper
INFO - 2021-06-30 08:48:24 --> Helper loaded: url_helper
INFO - 2021-06-30 08:48:24 --> Helper loaded: form_helper
INFO - 2021-06-30 08:48:24 --> Database Driver Class Initialized
INFO - 2021-06-30 08:48:24 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:48:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:48:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:48:24 --> Encryption Class Initialized
INFO - 2021-06-30 08:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:48:24 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:48:24 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:48:24 --> Model "user_model" initialized
INFO - 2021-06-30 08:48:24 --> Model "role_model" initialized
INFO - 2021-06-30 08:48:24 --> Controller Class Initialized
INFO - 2021-06-30 08:48:24 --> Helper loaded: language_helper
INFO - 2021-06-30 08:48:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:48:24 --> Final output sent to browser
DEBUG - 2021-06-30 08:48:24 --> Total execution time: 0.1115
INFO - 2021-06-30 08:52:09 --> Config Class Initialized
INFO - 2021-06-30 08:52:09 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:52:09 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:52:09 --> Utf8 Class Initialized
INFO - 2021-06-30 08:52:09 --> URI Class Initialized
INFO - 2021-06-30 08:52:09 --> Router Class Initialized
INFO - 2021-06-30 08:52:09 --> Output Class Initialized
INFO - 2021-06-30 08:52:09 --> Security Class Initialized
DEBUG - 2021-06-30 08:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:52:09 --> Input Class Initialized
INFO - 2021-06-30 08:52:09 --> Language Class Initialized
INFO - 2021-06-30 08:52:09 --> Loader Class Initialized
INFO - 2021-06-30 08:52:09 --> Helper loaded: html_helper
INFO - 2021-06-30 08:52:09 --> Helper loaded: url_helper
INFO - 2021-06-30 08:52:09 --> Helper loaded: form_helper
INFO - 2021-06-30 08:52:09 --> Database Driver Class Initialized
INFO - 2021-06-30 08:52:09 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:52:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:52:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:52:09 --> Encryption Class Initialized
INFO - 2021-06-30 08:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:52:09 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:52:09 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:52:09 --> Model "user_model" initialized
INFO - 2021-06-30 08:52:09 --> Model "role_model" initialized
INFO - 2021-06-30 08:52:09 --> Controller Class Initialized
INFO - 2021-06-30 08:52:09 --> Helper loaded: language_helper
INFO - 2021-06-30 08:52:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:52:09 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:52:09 --> Model "Product_model" initialized
INFO - 2021-06-30 08:52:09 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 08:52:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 08:52:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 08:52:09 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 08:52:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 08:52:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 08:52:09 --> Final output sent to browser
DEBUG - 2021-06-30 08:52:09 --> Total execution time: 0.0857
INFO - 2021-06-30 08:52:28 --> Config Class Initialized
INFO - 2021-06-30 08:52:28 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:52:28 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:52:28 --> Utf8 Class Initialized
INFO - 2021-06-30 08:52:28 --> URI Class Initialized
INFO - 2021-06-30 08:52:28 --> Router Class Initialized
INFO - 2021-06-30 08:52:28 --> Output Class Initialized
INFO - 2021-06-30 08:52:28 --> Security Class Initialized
DEBUG - 2021-06-30 08:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:52:28 --> Input Class Initialized
INFO - 2021-06-30 08:52:28 --> Language Class Initialized
INFO - 2021-06-30 08:52:28 --> Loader Class Initialized
INFO - 2021-06-30 08:52:28 --> Helper loaded: html_helper
INFO - 2021-06-30 08:52:28 --> Helper loaded: url_helper
INFO - 2021-06-30 08:52:28 --> Helper loaded: form_helper
INFO - 2021-06-30 08:52:28 --> Database Driver Class Initialized
INFO - 2021-06-30 08:52:28 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:52:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:52:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:52:28 --> Encryption Class Initialized
INFO - 2021-06-30 08:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:52:28 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:52:28 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:52:28 --> Model "user_model" initialized
INFO - 2021-06-30 08:52:28 --> Model "role_model" initialized
INFO - 2021-06-30 08:52:28 --> Controller Class Initialized
INFO - 2021-06-30 08:52:28 --> Helper loaded: language_helper
INFO - 2021-06-30 08:52:28 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:52:28 --> Final output sent to browser
DEBUG - 2021-06-30 08:52:28 --> Total execution time: 0.0720
INFO - 2021-06-30 08:54:40 --> Config Class Initialized
INFO - 2021-06-30 08:54:40 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:54:40 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:54:40 --> Utf8 Class Initialized
INFO - 2021-06-30 08:54:40 --> URI Class Initialized
INFO - 2021-06-30 08:54:40 --> Router Class Initialized
INFO - 2021-06-30 08:54:40 --> Output Class Initialized
INFO - 2021-06-30 08:54:40 --> Security Class Initialized
DEBUG - 2021-06-30 08:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:54:40 --> Input Class Initialized
INFO - 2021-06-30 08:54:40 --> Language Class Initialized
INFO - 2021-06-30 08:54:40 --> Loader Class Initialized
INFO - 2021-06-30 08:54:40 --> Helper loaded: html_helper
INFO - 2021-06-30 08:54:40 --> Helper loaded: url_helper
INFO - 2021-06-30 08:54:40 --> Helper loaded: form_helper
INFO - 2021-06-30 08:54:40 --> Database Driver Class Initialized
INFO - 2021-06-30 08:54:40 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:54:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:54:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:54:40 --> Encryption Class Initialized
INFO - 2021-06-30 08:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:54:40 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:54:40 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:54:40 --> Model "user_model" initialized
INFO - 2021-06-30 08:54:40 --> Model "role_model" initialized
INFO - 2021-06-30 08:54:40 --> Controller Class Initialized
INFO - 2021-06-30 08:54:40 --> Helper loaded: language_helper
INFO - 2021-06-30 08:54:40 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:54:40 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:54:40 --> Model "Product_model" initialized
INFO - 2021-06-30 08:54:40 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 08:54:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 08:54:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 08:54:40 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 08:54:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 08:54:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 08:54:40 --> Final output sent to browser
DEBUG - 2021-06-30 08:54:40 --> Total execution time: 0.1007
INFO - 2021-06-30 08:54:58 --> Config Class Initialized
INFO - 2021-06-30 08:54:58 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:54:58 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:54:58 --> Utf8 Class Initialized
INFO - 2021-06-30 08:54:58 --> URI Class Initialized
INFO - 2021-06-30 08:54:58 --> Router Class Initialized
INFO - 2021-06-30 08:54:58 --> Output Class Initialized
INFO - 2021-06-30 08:54:58 --> Security Class Initialized
DEBUG - 2021-06-30 08:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:54:58 --> Input Class Initialized
INFO - 2021-06-30 08:54:58 --> Language Class Initialized
INFO - 2021-06-30 08:54:58 --> Loader Class Initialized
INFO - 2021-06-30 08:54:58 --> Helper loaded: html_helper
INFO - 2021-06-30 08:54:58 --> Helper loaded: url_helper
INFO - 2021-06-30 08:54:58 --> Helper loaded: form_helper
INFO - 2021-06-30 08:54:58 --> Database Driver Class Initialized
INFO - 2021-06-30 08:54:58 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:54:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:54:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:54:58 --> Encryption Class Initialized
INFO - 2021-06-30 08:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:54:58 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:54:58 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:54:58 --> Model "user_model" initialized
INFO - 2021-06-30 08:54:58 --> Model "role_model" initialized
INFO - 2021-06-30 08:54:58 --> Controller Class Initialized
INFO - 2021-06-30 08:54:58 --> Helper loaded: language_helper
INFO - 2021-06-30 08:54:58 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:54:58 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:54:58 --> Final output sent to browser
DEBUG - 2021-06-30 08:54:58 --> Total execution time: 0.0912
INFO - 2021-06-30 08:57:03 --> Config Class Initialized
INFO - 2021-06-30 08:57:03 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:57:03 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:57:03 --> Utf8 Class Initialized
INFO - 2021-06-30 08:57:03 --> URI Class Initialized
INFO - 2021-06-30 08:57:03 --> Router Class Initialized
INFO - 2021-06-30 08:57:03 --> Output Class Initialized
INFO - 2021-06-30 08:57:03 --> Security Class Initialized
DEBUG - 2021-06-30 08:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:57:03 --> Input Class Initialized
INFO - 2021-06-30 08:57:03 --> Language Class Initialized
INFO - 2021-06-30 08:57:03 --> Loader Class Initialized
INFO - 2021-06-30 08:57:03 --> Helper loaded: html_helper
INFO - 2021-06-30 08:57:03 --> Helper loaded: url_helper
INFO - 2021-06-30 08:57:03 --> Helper loaded: form_helper
INFO - 2021-06-30 08:57:03 --> Database Driver Class Initialized
INFO - 2021-06-30 08:57:03 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:57:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:57:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:57:03 --> Encryption Class Initialized
INFO - 2021-06-30 08:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:57:03 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:57:03 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:57:03 --> Model "user_model" initialized
INFO - 2021-06-30 08:57:03 --> Model "role_model" initialized
INFO - 2021-06-30 08:57:03 --> Controller Class Initialized
INFO - 2021-06-30 08:57:03 --> Helper loaded: language_helper
INFO - 2021-06-30 08:57:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:57:03 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:57:03 --> Model "Product_model" initialized
INFO - 2021-06-30 08:57:03 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 08:57:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 08:57:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 08:57:03 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 08:57:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 08:57:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 08:57:03 --> Final output sent to browser
DEBUG - 2021-06-30 08:57:03 --> Total execution time: 0.1115
INFO - 2021-06-30 08:57:21 --> Config Class Initialized
INFO - 2021-06-30 08:57:21 --> Hooks Class Initialized
DEBUG - 2021-06-30 08:57:21 --> UTF-8 Support Enabled
INFO - 2021-06-30 08:57:21 --> Utf8 Class Initialized
INFO - 2021-06-30 08:57:21 --> URI Class Initialized
INFO - 2021-06-30 08:57:21 --> Router Class Initialized
INFO - 2021-06-30 08:57:21 --> Output Class Initialized
INFO - 2021-06-30 08:57:21 --> Security Class Initialized
DEBUG - 2021-06-30 08:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 08:57:21 --> Input Class Initialized
INFO - 2021-06-30 08:57:21 --> Language Class Initialized
INFO - 2021-06-30 08:57:21 --> Loader Class Initialized
INFO - 2021-06-30 08:57:21 --> Helper loaded: html_helper
INFO - 2021-06-30 08:57:21 --> Helper loaded: url_helper
INFO - 2021-06-30 08:57:21 --> Helper loaded: form_helper
INFO - 2021-06-30 08:57:21 --> Database Driver Class Initialized
INFO - 2021-06-30 08:57:22 --> Form Validation Class Initialized
DEBUG - 2021-06-30 08:57:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 08:57:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 08:57:22 --> Encryption Class Initialized
INFO - 2021-06-30 08:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 08:57:22 --> Model "vendor_model" initialized
INFO - 2021-06-30 08:57:22 --> Model "coupon_model" initialized
INFO - 2021-06-30 08:57:22 --> Model "user_model" initialized
INFO - 2021-06-30 08:57:22 --> Model "role_model" initialized
INFO - 2021-06-30 08:57:22 --> Controller Class Initialized
INFO - 2021-06-30 08:57:22 --> Helper loaded: language_helper
INFO - 2021-06-30 08:57:22 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 08:57:22 --> Model "Customer_model" initialized
INFO - 2021-06-30 08:57:22 --> Final output sent to browser
DEBUG - 2021-06-30 08:57:22 --> Total execution time: 0.0917
INFO - 2021-06-30 09:00:53 --> Config Class Initialized
INFO - 2021-06-30 09:00:53 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:00:53 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:00:53 --> Utf8 Class Initialized
INFO - 2021-06-30 09:00:53 --> URI Class Initialized
INFO - 2021-06-30 09:00:53 --> Router Class Initialized
INFO - 2021-06-30 09:00:53 --> Output Class Initialized
INFO - 2021-06-30 09:00:53 --> Security Class Initialized
DEBUG - 2021-06-30 09:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:00:53 --> Input Class Initialized
INFO - 2021-06-30 09:00:53 --> Language Class Initialized
INFO - 2021-06-30 09:00:53 --> Loader Class Initialized
INFO - 2021-06-30 09:00:53 --> Helper loaded: html_helper
INFO - 2021-06-30 09:00:53 --> Helper loaded: url_helper
INFO - 2021-06-30 09:00:53 --> Helper loaded: form_helper
INFO - 2021-06-30 09:00:53 --> Database Driver Class Initialized
INFO - 2021-06-30 09:00:53 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:00:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:00:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:00:53 --> Encryption Class Initialized
INFO - 2021-06-30 09:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:00:53 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:00:53 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:00:53 --> Model "user_model" initialized
INFO - 2021-06-30 09:00:53 --> Model "role_model" initialized
INFO - 2021-06-30 09:00:53 --> Controller Class Initialized
INFO - 2021-06-30 09:00:53 --> Helper loaded: language_helper
INFO - 2021-06-30 09:00:53 --> Language file loaded: language/english/content_lang.php
ERROR - 2021-06-30 09:00:53 --> Severity: error --> Exception: syntax error, unexpected 'return' (T_RETURN) D:\development\web\xampp\htdocs\proadmin\proadmin\application\models\Customer_model.php 84
INFO - 2021-06-30 09:01:28 --> Config Class Initialized
INFO - 2021-06-30 09:01:28 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:01:28 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:01:28 --> Utf8 Class Initialized
INFO - 2021-06-30 09:01:28 --> URI Class Initialized
INFO - 2021-06-30 09:01:28 --> Router Class Initialized
INFO - 2021-06-30 09:01:28 --> Output Class Initialized
INFO - 2021-06-30 09:01:28 --> Security Class Initialized
DEBUG - 2021-06-30 09:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:01:28 --> Input Class Initialized
INFO - 2021-06-30 09:01:28 --> Language Class Initialized
INFO - 2021-06-30 09:01:28 --> Loader Class Initialized
INFO - 2021-06-30 09:01:28 --> Helper loaded: html_helper
INFO - 2021-06-30 09:01:28 --> Helper loaded: url_helper
INFO - 2021-06-30 09:01:28 --> Helper loaded: form_helper
INFO - 2021-06-30 09:01:28 --> Database Driver Class Initialized
INFO - 2021-06-30 09:01:28 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:01:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:01:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:01:28 --> Encryption Class Initialized
INFO - 2021-06-30 09:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:01:28 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:01:28 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:01:28 --> Model "user_model" initialized
INFO - 2021-06-30 09:01:28 --> Model "role_model" initialized
INFO - 2021-06-30 09:01:28 --> Controller Class Initialized
INFO - 2021-06-30 09:01:28 --> Helper loaded: language_helper
INFO - 2021-06-30 09:01:28 --> Language file loaded: language/english/content_lang.php
ERROR - 2021-06-30 09:01:28 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ';' D:\development\web\xampp\htdocs\proadmin\proadmin\application\models\Customer_model.php 85
INFO - 2021-06-30 09:02:05 --> Config Class Initialized
INFO - 2021-06-30 09:02:05 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:02:05 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:02:05 --> Utf8 Class Initialized
INFO - 2021-06-30 09:02:05 --> URI Class Initialized
INFO - 2021-06-30 09:02:05 --> Router Class Initialized
INFO - 2021-06-30 09:02:05 --> Output Class Initialized
INFO - 2021-06-30 09:02:05 --> Security Class Initialized
DEBUG - 2021-06-30 09:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:02:05 --> Input Class Initialized
INFO - 2021-06-30 09:02:05 --> Language Class Initialized
INFO - 2021-06-30 09:02:05 --> Loader Class Initialized
INFO - 2021-06-30 09:02:05 --> Helper loaded: html_helper
INFO - 2021-06-30 09:02:05 --> Helper loaded: url_helper
INFO - 2021-06-30 09:02:05 --> Helper loaded: form_helper
INFO - 2021-06-30 09:02:05 --> Database Driver Class Initialized
INFO - 2021-06-30 09:02:05 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:02:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:02:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:02:05 --> Encryption Class Initialized
INFO - 2021-06-30 09:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:02:05 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:02:05 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:02:05 --> Model "user_model" initialized
INFO - 2021-06-30 09:02:05 --> Model "role_model" initialized
INFO - 2021-06-30 09:02:05 --> Controller Class Initialized
INFO - 2021-06-30 09:02:05 --> Helper loaded: language_helper
INFO - 2021-06-30 09:02:05 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:02:05 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:02:05 --> Model "Product_model" initialized
INFO - 2021-06-30 09:02:05 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 09:02:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 09:02:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 09:02:05 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 09:02:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 09:02:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 09:02:05 --> Final output sent to browser
DEBUG - 2021-06-30 09:02:05 --> Total execution time: 0.0965
INFO - 2021-06-30 09:02:25 --> Config Class Initialized
INFO - 2021-06-30 09:02:25 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:02:25 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:02:25 --> Utf8 Class Initialized
INFO - 2021-06-30 09:02:25 --> URI Class Initialized
INFO - 2021-06-30 09:02:25 --> Router Class Initialized
INFO - 2021-06-30 09:02:25 --> Output Class Initialized
INFO - 2021-06-30 09:02:25 --> Security Class Initialized
DEBUG - 2021-06-30 09:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:02:25 --> Input Class Initialized
INFO - 2021-06-30 09:02:25 --> Language Class Initialized
INFO - 2021-06-30 09:02:25 --> Loader Class Initialized
INFO - 2021-06-30 09:02:25 --> Helper loaded: html_helper
INFO - 2021-06-30 09:02:25 --> Helper loaded: url_helper
INFO - 2021-06-30 09:02:25 --> Helper loaded: form_helper
INFO - 2021-06-30 09:02:25 --> Database Driver Class Initialized
INFO - 2021-06-30 09:02:25 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:02:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:02:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:02:25 --> Encryption Class Initialized
INFO - 2021-06-30 09:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:02:25 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:02:25 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:02:25 --> Model "user_model" initialized
INFO - 2021-06-30 09:02:25 --> Model "role_model" initialized
INFO - 2021-06-30 09:02:25 --> Controller Class Initialized
INFO - 2021-06-30 09:02:25 --> Helper loaded: language_helper
INFO - 2021-06-30 09:02:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:02:25 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:02:25 --> Final output sent to browser
DEBUG - 2021-06-30 09:02:25 --> Total execution time: 0.1113
INFO - 2021-06-30 09:03:54 --> Config Class Initialized
INFO - 2021-06-30 09:03:54 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:03:54 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:03:54 --> Utf8 Class Initialized
INFO - 2021-06-30 09:03:54 --> URI Class Initialized
INFO - 2021-06-30 09:03:54 --> Router Class Initialized
INFO - 2021-06-30 09:03:54 --> Output Class Initialized
INFO - 2021-06-30 09:03:54 --> Security Class Initialized
DEBUG - 2021-06-30 09:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:03:54 --> Input Class Initialized
INFO - 2021-06-30 09:03:54 --> Language Class Initialized
INFO - 2021-06-30 09:03:54 --> Loader Class Initialized
INFO - 2021-06-30 09:03:54 --> Helper loaded: html_helper
INFO - 2021-06-30 09:03:54 --> Helper loaded: url_helper
INFO - 2021-06-30 09:03:54 --> Helper loaded: form_helper
INFO - 2021-06-30 09:03:54 --> Database Driver Class Initialized
INFO - 2021-06-30 09:03:54 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:03:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:03:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:03:54 --> Encryption Class Initialized
INFO - 2021-06-30 09:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:03:54 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:03:54 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:03:54 --> Model "user_model" initialized
INFO - 2021-06-30 09:03:54 --> Model "role_model" initialized
INFO - 2021-06-30 09:03:54 --> Controller Class Initialized
INFO - 2021-06-30 09:03:54 --> Helper loaded: language_helper
INFO - 2021-06-30 09:03:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:03:54 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:03:54 --> Final output sent to browser
DEBUG - 2021-06-30 09:03:54 --> Total execution time: 0.0735
INFO - 2021-06-30 09:03:57 --> Config Class Initialized
INFO - 2021-06-30 09:03:57 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:03:57 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:03:57 --> Utf8 Class Initialized
INFO - 2021-06-30 09:03:57 --> URI Class Initialized
INFO - 2021-06-30 09:03:57 --> Router Class Initialized
INFO - 2021-06-30 09:03:57 --> Output Class Initialized
INFO - 2021-06-30 09:03:57 --> Security Class Initialized
DEBUG - 2021-06-30 09:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:03:57 --> Input Class Initialized
INFO - 2021-06-30 09:03:57 --> Language Class Initialized
INFO - 2021-06-30 09:03:57 --> Loader Class Initialized
INFO - 2021-06-30 09:03:57 --> Helper loaded: html_helper
INFO - 2021-06-30 09:03:57 --> Helper loaded: url_helper
INFO - 2021-06-30 09:03:57 --> Helper loaded: form_helper
INFO - 2021-06-30 09:03:57 --> Database Driver Class Initialized
INFO - 2021-06-30 09:03:57 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:03:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:03:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:03:57 --> Encryption Class Initialized
INFO - 2021-06-30 09:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:03:57 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:03:57 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:03:57 --> Model "user_model" initialized
INFO - 2021-06-30 09:03:57 --> Model "role_model" initialized
INFO - 2021-06-30 09:03:57 --> Controller Class Initialized
INFO - 2021-06-30 09:03:57 --> Helper loaded: language_helper
INFO - 2021-06-30 09:03:57 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:03:57 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:03:57 --> Model "Product_model" initialized
INFO - 2021-06-30 09:03:57 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 09:03:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 09:03:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 09:03:57 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 09:03:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 09:03:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 09:03:57 --> Final output sent to browser
DEBUG - 2021-06-30 09:03:57 --> Total execution time: 0.1098
INFO - 2021-06-30 09:04:14 --> Config Class Initialized
INFO - 2021-06-30 09:04:14 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:04:14 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:04:14 --> Utf8 Class Initialized
INFO - 2021-06-30 09:04:14 --> URI Class Initialized
INFO - 2021-06-30 09:04:14 --> Router Class Initialized
INFO - 2021-06-30 09:04:14 --> Output Class Initialized
INFO - 2021-06-30 09:04:14 --> Security Class Initialized
DEBUG - 2021-06-30 09:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:04:14 --> Input Class Initialized
INFO - 2021-06-30 09:04:14 --> Language Class Initialized
INFO - 2021-06-30 09:04:14 --> Loader Class Initialized
INFO - 2021-06-30 09:04:14 --> Helper loaded: html_helper
INFO - 2021-06-30 09:04:14 --> Helper loaded: url_helper
INFO - 2021-06-30 09:04:14 --> Helper loaded: form_helper
INFO - 2021-06-30 09:04:14 --> Database Driver Class Initialized
INFO - 2021-06-30 09:04:14 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:04:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:04:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:04:14 --> Encryption Class Initialized
INFO - 2021-06-30 09:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:04:14 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:04:14 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:04:14 --> Model "user_model" initialized
INFO - 2021-06-30 09:04:14 --> Model "role_model" initialized
INFO - 2021-06-30 09:04:14 --> Controller Class Initialized
INFO - 2021-06-30 09:04:14 --> Helper loaded: language_helper
INFO - 2021-06-30 09:04:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:04:14 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:04:14 --> Final output sent to browser
DEBUG - 2021-06-30 09:04:14 --> Total execution time: 0.0691
INFO - 2021-06-30 09:07:46 --> Config Class Initialized
INFO - 2021-06-30 09:07:46 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:07:46 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:07:46 --> Utf8 Class Initialized
INFO - 2021-06-30 09:07:46 --> URI Class Initialized
INFO - 2021-06-30 09:07:46 --> Router Class Initialized
INFO - 2021-06-30 09:07:46 --> Output Class Initialized
INFO - 2021-06-30 09:07:46 --> Security Class Initialized
DEBUG - 2021-06-30 09:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:07:46 --> Input Class Initialized
INFO - 2021-06-30 09:07:46 --> Language Class Initialized
INFO - 2021-06-30 09:07:46 --> Loader Class Initialized
INFO - 2021-06-30 09:07:46 --> Helper loaded: html_helper
INFO - 2021-06-30 09:07:46 --> Helper loaded: url_helper
INFO - 2021-06-30 09:07:46 --> Helper loaded: form_helper
INFO - 2021-06-30 09:07:46 --> Database Driver Class Initialized
INFO - 2021-06-30 09:07:47 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:07:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:07:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:07:47 --> Encryption Class Initialized
INFO - 2021-06-30 09:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:07:47 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:07:47 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:07:47 --> Model "user_model" initialized
INFO - 2021-06-30 09:07:47 --> Model "role_model" initialized
INFO - 2021-06-30 09:07:47 --> Controller Class Initialized
INFO - 2021-06-30 09:07:47 --> Helper loaded: language_helper
INFO - 2021-06-30 09:07:47 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:07:47 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:07:47 --> Model "Product_model" initialized
INFO - 2021-06-30 09:07:47 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 09:07:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 09:07:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 09:07:47 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 09:07:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 09:07:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 09:07:47 --> Final output sent to browser
DEBUG - 2021-06-30 09:07:47 --> Total execution time: 0.1146
INFO - 2021-06-30 09:08:18 --> Config Class Initialized
INFO - 2021-06-30 09:08:18 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:08:18 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:08:18 --> Utf8 Class Initialized
INFO - 2021-06-30 09:08:18 --> URI Class Initialized
INFO - 2021-06-30 09:08:18 --> Router Class Initialized
INFO - 2021-06-30 09:08:18 --> Output Class Initialized
INFO - 2021-06-30 09:08:18 --> Security Class Initialized
DEBUG - 2021-06-30 09:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:08:18 --> Input Class Initialized
INFO - 2021-06-30 09:08:18 --> Language Class Initialized
INFO - 2021-06-30 09:08:18 --> Loader Class Initialized
INFO - 2021-06-30 09:08:18 --> Helper loaded: html_helper
INFO - 2021-06-30 09:08:18 --> Helper loaded: url_helper
INFO - 2021-06-30 09:08:18 --> Helper loaded: form_helper
INFO - 2021-06-30 09:08:18 --> Database Driver Class Initialized
INFO - 2021-06-30 09:08:18 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:08:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:08:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:08:18 --> Encryption Class Initialized
INFO - 2021-06-30 09:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:08:18 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:08:18 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:08:18 --> Model "user_model" initialized
INFO - 2021-06-30 09:08:18 --> Model "role_model" initialized
INFO - 2021-06-30 09:08:18 --> Controller Class Initialized
INFO - 2021-06-30 09:08:18 --> Helper loaded: language_helper
INFO - 2021-06-30 09:08:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:08:18 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:08:18 --> Final output sent to browser
DEBUG - 2021-06-30 09:08:18 --> Total execution time: 0.0764
INFO - 2021-06-30 09:09:06 --> Config Class Initialized
INFO - 2021-06-30 09:09:06 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:09:06 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:09:06 --> Utf8 Class Initialized
INFO - 2021-06-30 09:09:06 --> URI Class Initialized
INFO - 2021-06-30 09:09:06 --> Router Class Initialized
INFO - 2021-06-30 09:09:06 --> Output Class Initialized
INFO - 2021-06-30 09:09:06 --> Security Class Initialized
DEBUG - 2021-06-30 09:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:09:06 --> Input Class Initialized
INFO - 2021-06-30 09:09:06 --> Language Class Initialized
INFO - 2021-06-30 09:09:06 --> Loader Class Initialized
INFO - 2021-06-30 09:09:06 --> Helper loaded: html_helper
INFO - 2021-06-30 09:09:06 --> Helper loaded: url_helper
INFO - 2021-06-30 09:09:06 --> Helper loaded: form_helper
INFO - 2021-06-30 09:09:06 --> Database Driver Class Initialized
INFO - 2021-06-30 09:09:06 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:09:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:09:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:09:06 --> Encryption Class Initialized
INFO - 2021-06-30 09:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:09:06 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:09:06 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:09:06 --> Model "user_model" initialized
INFO - 2021-06-30 09:09:06 --> Model "role_model" initialized
INFO - 2021-06-30 09:09:06 --> Controller Class Initialized
INFO - 2021-06-30 09:09:06 --> Helper loaded: language_helper
INFO - 2021-06-30 09:09:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:09:06 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:09:06 --> Model "Product_model" initialized
INFO - 2021-06-30 09:09:06 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 09:09:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 09:09:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 09:09:06 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 09:09:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 09:09:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 09:09:06 --> Final output sent to browser
DEBUG - 2021-06-30 09:09:06 --> Total execution time: 0.1254
INFO - 2021-06-30 09:09:24 --> Config Class Initialized
INFO - 2021-06-30 09:09:24 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:09:24 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:09:24 --> Utf8 Class Initialized
INFO - 2021-06-30 09:09:24 --> URI Class Initialized
INFO - 2021-06-30 09:09:24 --> Router Class Initialized
INFO - 2021-06-30 09:09:24 --> Output Class Initialized
INFO - 2021-06-30 09:09:24 --> Security Class Initialized
DEBUG - 2021-06-30 09:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:09:24 --> Input Class Initialized
INFO - 2021-06-30 09:09:24 --> Language Class Initialized
INFO - 2021-06-30 09:09:24 --> Loader Class Initialized
INFO - 2021-06-30 09:09:24 --> Helper loaded: html_helper
INFO - 2021-06-30 09:09:24 --> Helper loaded: url_helper
INFO - 2021-06-30 09:09:24 --> Helper loaded: form_helper
INFO - 2021-06-30 09:09:24 --> Database Driver Class Initialized
INFO - 2021-06-30 09:09:24 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:09:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:09:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:09:24 --> Encryption Class Initialized
INFO - 2021-06-30 09:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:09:24 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:09:24 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:09:24 --> Model "user_model" initialized
INFO - 2021-06-30 09:09:24 --> Model "role_model" initialized
INFO - 2021-06-30 09:09:24 --> Controller Class Initialized
INFO - 2021-06-30 09:09:24 --> Helper loaded: language_helper
INFO - 2021-06-30 09:09:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:09:24 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:09:24 --> Final output sent to browser
DEBUG - 2021-06-30 09:09:24 --> Total execution time: 0.0880
INFO - 2021-06-30 09:13:33 --> Config Class Initialized
INFO - 2021-06-30 09:13:33 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:13:33 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:13:33 --> Utf8 Class Initialized
INFO - 2021-06-30 09:13:33 --> URI Class Initialized
INFO - 2021-06-30 09:13:33 --> Router Class Initialized
INFO - 2021-06-30 09:13:33 --> Output Class Initialized
INFO - 2021-06-30 09:13:33 --> Security Class Initialized
DEBUG - 2021-06-30 09:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:13:33 --> Input Class Initialized
INFO - 2021-06-30 09:13:33 --> Language Class Initialized
INFO - 2021-06-30 09:13:33 --> Loader Class Initialized
INFO - 2021-06-30 09:13:33 --> Helper loaded: html_helper
INFO - 2021-06-30 09:13:33 --> Helper loaded: url_helper
INFO - 2021-06-30 09:13:33 --> Helper loaded: form_helper
INFO - 2021-06-30 09:13:33 --> Database Driver Class Initialized
INFO - 2021-06-30 09:13:33 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:13:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:13:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:13:33 --> Encryption Class Initialized
INFO - 2021-06-30 09:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:13:33 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:13:33 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:13:33 --> Model "user_model" initialized
INFO - 2021-06-30 09:13:33 --> Model "role_model" initialized
INFO - 2021-06-30 09:13:33 --> Controller Class Initialized
INFO - 2021-06-30 09:13:33 --> Helper loaded: language_helper
INFO - 2021-06-30 09:13:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:13:33 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:13:33 --> Model "Product_model" initialized
INFO - 2021-06-30 09:13:33 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 09:13:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 09:13:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 09:13:33 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 09:13:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 09:13:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 09:13:33 --> Final output sent to browser
DEBUG - 2021-06-30 09:13:33 --> Total execution time: 0.1205
INFO - 2021-06-30 09:13:51 --> Config Class Initialized
INFO - 2021-06-30 09:13:51 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:13:51 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:13:51 --> Utf8 Class Initialized
INFO - 2021-06-30 09:13:51 --> URI Class Initialized
INFO - 2021-06-30 09:13:51 --> Router Class Initialized
INFO - 2021-06-30 09:13:51 --> Output Class Initialized
INFO - 2021-06-30 09:13:51 --> Security Class Initialized
DEBUG - 2021-06-30 09:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:13:51 --> Input Class Initialized
INFO - 2021-06-30 09:13:51 --> Language Class Initialized
INFO - 2021-06-30 09:13:51 --> Loader Class Initialized
INFO - 2021-06-30 09:13:51 --> Helper loaded: html_helper
INFO - 2021-06-30 09:13:51 --> Helper loaded: url_helper
INFO - 2021-06-30 09:13:51 --> Helper loaded: form_helper
INFO - 2021-06-30 09:13:51 --> Database Driver Class Initialized
INFO - 2021-06-30 09:13:51 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:13:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:13:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:13:51 --> Encryption Class Initialized
INFO - 2021-06-30 09:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:13:51 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:13:51 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:13:51 --> Model "user_model" initialized
INFO - 2021-06-30 09:13:51 --> Model "role_model" initialized
INFO - 2021-06-30 09:13:51 --> Controller Class Initialized
INFO - 2021-06-30 09:13:51 --> Helper loaded: language_helper
INFO - 2021-06-30 09:13:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:13:51 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:13:51 --> Final output sent to browser
DEBUG - 2021-06-30 09:13:51 --> Total execution time: 0.0958
INFO - 2021-06-30 09:14:52 --> Config Class Initialized
INFO - 2021-06-30 09:14:52 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:14:52 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:14:52 --> Utf8 Class Initialized
INFO - 2021-06-30 09:14:52 --> URI Class Initialized
INFO - 2021-06-30 09:14:52 --> Router Class Initialized
INFO - 2021-06-30 09:14:52 --> Output Class Initialized
INFO - 2021-06-30 09:14:52 --> Security Class Initialized
DEBUG - 2021-06-30 09:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:14:52 --> Input Class Initialized
INFO - 2021-06-30 09:14:52 --> Language Class Initialized
INFO - 2021-06-30 09:14:52 --> Loader Class Initialized
INFO - 2021-06-30 09:14:52 --> Helper loaded: html_helper
INFO - 2021-06-30 09:14:52 --> Helper loaded: url_helper
INFO - 2021-06-30 09:14:52 --> Helper loaded: form_helper
INFO - 2021-06-30 09:14:52 --> Database Driver Class Initialized
INFO - 2021-06-30 09:14:52 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:14:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:14:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:14:52 --> Encryption Class Initialized
INFO - 2021-06-30 09:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:14:52 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:14:52 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:14:52 --> Model "user_model" initialized
INFO - 2021-06-30 09:14:52 --> Model "role_model" initialized
INFO - 2021-06-30 09:14:52 --> Controller Class Initialized
INFO - 2021-06-30 09:14:52 --> Helper loaded: language_helper
INFO - 2021-06-30 09:14:52 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:14:52 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:14:52 --> Model "Product_model" initialized
INFO - 2021-06-30 09:14:52 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 09:14:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 09:14:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 09:14:52 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 09:14:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 09:14:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 09:14:52 --> Final output sent to browser
DEBUG - 2021-06-30 09:14:52 --> Total execution time: 0.1178
INFO - 2021-06-30 09:15:09 --> Config Class Initialized
INFO - 2021-06-30 09:15:09 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:15:09 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:15:09 --> Utf8 Class Initialized
INFO - 2021-06-30 09:15:09 --> URI Class Initialized
INFO - 2021-06-30 09:15:09 --> Router Class Initialized
INFO - 2021-06-30 09:15:09 --> Output Class Initialized
INFO - 2021-06-30 09:15:09 --> Security Class Initialized
DEBUG - 2021-06-30 09:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:15:09 --> Input Class Initialized
INFO - 2021-06-30 09:15:09 --> Language Class Initialized
INFO - 2021-06-30 09:15:09 --> Loader Class Initialized
INFO - 2021-06-30 09:15:09 --> Helper loaded: html_helper
INFO - 2021-06-30 09:15:09 --> Helper loaded: url_helper
INFO - 2021-06-30 09:15:09 --> Helper loaded: form_helper
INFO - 2021-06-30 09:15:09 --> Database Driver Class Initialized
INFO - 2021-06-30 09:15:09 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:15:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:15:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:15:09 --> Encryption Class Initialized
INFO - 2021-06-30 09:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:15:09 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:15:09 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:15:09 --> Model "user_model" initialized
INFO - 2021-06-30 09:15:09 --> Model "role_model" initialized
INFO - 2021-06-30 09:15:09 --> Controller Class Initialized
INFO - 2021-06-30 09:15:09 --> Helper loaded: language_helper
INFO - 2021-06-30 09:15:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:15:09 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:15:09 --> Final output sent to browser
DEBUG - 2021-06-30 09:15:09 --> Total execution time: 0.0820
INFO - 2021-06-30 09:15:44 --> Config Class Initialized
INFO - 2021-06-30 09:15:44 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:15:44 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:15:44 --> Utf8 Class Initialized
INFO - 2021-06-30 09:15:44 --> URI Class Initialized
INFO - 2021-06-30 09:15:44 --> Router Class Initialized
INFO - 2021-06-30 09:15:44 --> Output Class Initialized
INFO - 2021-06-30 09:15:44 --> Security Class Initialized
DEBUG - 2021-06-30 09:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:15:44 --> Input Class Initialized
INFO - 2021-06-30 09:15:44 --> Language Class Initialized
INFO - 2021-06-30 09:15:44 --> Loader Class Initialized
INFO - 2021-06-30 09:15:44 --> Helper loaded: html_helper
INFO - 2021-06-30 09:15:44 --> Helper loaded: url_helper
INFO - 2021-06-30 09:15:44 --> Helper loaded: form_helper
INFO - 2021-06-30 09:15:44 --> Database Driver Class Initialized
INFO - 2021-06-30 09:15:44 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:15:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:15:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:15:44 --> Encryption Class Initialized
INFO - 2021-06-30 09:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:15:44 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:15:44 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:15:44 --> Model "user_model" initialized
INFO - 2021-06-30 09:15:44 --> Model "role_model" initialized
INFO - 2021-06-30 09:15:44 --> Controller Class Initialized
INFO - 2021-06-30 09:15:44 --> Helper loaded: language_helper
INFO - 2021-06-30 09:15:44 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:15:44 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:15:44 --> Model "Product_model" initialized
INFO - 2021-06-30 09:15:44 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 09:15:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 09:15:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 09:15:44 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 09:15:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 09:15:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 09:15:44 --> Final output sent to browser
DEBUG - 2021-06-30 09:15:44 --> Total execution time: 0.1042
INFO - 2021-06-30 09:16:07 --> Config Class Initialized
INFO - 2021-06-30 09:16:07 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:16:07 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:16:07 --> Utf8 Class Initialized
INFO - 2021-06-30 09:16:07 --> URI Class Initialized
INFO - 2021-06-30 09:16:07 --> Router Class Initialized
INFO - 2021-06-30 09:16:07 --> Output Class Initialized
INFO - 2021-06-30 09:16:07 --> Security Class Initialized
DEBUG - 2021-06-30 09:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:16:07 --> Input Class Initialized
INFO - 2021-06-30 09:16:07 --> Language Class Initialized
INFO - 2021-06-30 09:16:07 --> Loader Class Initialized
INFO - 2021-06-30 09:16:07 --> Helper loaded: html_helper
INFO - 2021-06-30 09:16:07 --> Helper loaded: url_helper
INFO - 2021-06-30 09:16:07 --> Helper loaded: form_helper
INFO - 2021-06-30 09:16:07 --> Database Driver Class Initialized
INFO - 2021-06-30 09:16:07 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:16:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:16:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:16:07 --> Encryption Class Initialized
INFO - 2021-06-30 09:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:16:07 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:16:07 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:16:07 --> Model "user_model" initialized
INFO - 2021-06-30 09:16:07 --> Model "role_model" initialized
INFO - 2021-06-30 09:16:07 --> Controller Class Initialized
INFO - 2021-06-30 09:16:07 --> Helper loaded: language_helper
INFO - 2021-06-30 09:16:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:16:07 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:16:07 --> Final output sent to browser
DEBUG - 2021-06-30 09:16:07 --> Total execution time: 0.1037
INFO - 2021-06-30 09:21:38 --> Config Class Initialized
INFO - 2021-06-30 09:21:38 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:21:38 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:21:38 --> Utf8 Class Initialized
INFO - 2021-06-30 09:21:38 --> URI Class Initialized
INFO - 2021-06-30 09:21:38 --> Router Class Initialized
INFO - 2021-06-30 09:21:38 --> Output Class Initialized
INFO - 2021-06-30 09:21:38 --> Security Class Initialized
DEBUG - 2021-06-30 09:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:21:38 --> Input Class Initialized
INFO - 2021-06-30 09:21:38 --> Language Class Initialized
INFO - 2021-06-30 09:21:38 --> Loader Class Initialized
INFO - 2021-06-30 09:21:38 --> Helper loaded: html_helper
INFO - 2021-06-30 09:21:38 --> Helper loaded: url_helper
INFO - 2021-06-30 09:21:38 --> Helper loaded: form_helper
INFO - 2021-06-30 09:21:38 --> Database Driver Class Initialized
INFO - 2021-06-30 09:21:38 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:21:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:21:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:21:38 --> Encryption Class Initialized
INFO - 2021-06-30 09:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:21:38 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:21:38 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:21:38 --> Model "user_model" initialized
INFO - 2021-06-30 09:21:38 --> Model "role_model" initialized
INFO - 2021-06-30 09:21:38 --> Controller Class Initialized
INFO - 2021-06-30 09:21:38 --> Helper loaded: language_helper
INFO - 2021-06-30 09:21:38 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:21:38 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:21:38 --> Model "Product_model" initialized
INFO - 2021-06-30 09:21:38 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 09:21:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 09:21:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 09:21:38 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 09:21:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 09:21:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 09:21:38 --> Final output sent to browser
DEBUG - 2021-06-30 09:21:38 --> Total execution time: 0.1345
INFO - 2021-06-30 09:21:55 --> Config Class Initialized
INFO - 2021-06-30 09:21:55 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:21:55 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:21:55 --> Utf8 Class Initialized
INFO - 2021-06-30 09:21:55 --> URI Class Initialized
INFO - 2021-06-30 09:21:55 --> Router Class Initialized
INFO - 2021-06-30 09:21:55 --> Output Class Initialized
INFO - 2021-06-30 09:21:55 --> Security Class Initialized
DEBUG - 2021-06-30 09:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:21:55 --> Input Class Initialized
INFO - 2021-06-30 09:21:55 --> Language Class Initialized
INFO - 2021-06-30 09:21:55 --> Loader Class Initialized
INFO - 2021-06-30 09:21:55 --> Helper loaded: html_helper
INFO - 2021-06-30 09:21:55 --> Helper loaded: url_helper
INFO - 2021-06-30 09:21:55 --> Helper loaded: form_helper
INFO - 2021-06-30 09:21:55 --> Database Driver Class Initialized
INFO - 2021-06-30 09:21:55 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:21:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:21:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:21:55 --> Encryption Class Initialized
INFO - 2021-06-30 09:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:21:55 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:21:55 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:21:55 --> Model "user_model" initialized
INFO - 2021-06-30 09:21:55 --> Model "role_model" initialized
INFO - 2021-06-30 09:21:55 --> Controller Class Initialized
INFO - 2021-06-30 09:21:55 --> Helper loaded: language_helper
INFO - 2021-06-30 09:21:55 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:21:55 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:21:55 --> Final output sent to browser
DEBUG - 2021-06-30 09:21:55 --> Total execution time: 0.0916
INFO - 2021-06-30 09:23:27 --> Config Class Initialized
INFO - 2021-06-30 09:23:27 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:23:27 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:23:27 --> Utf8 Class Initialized
INFO - 2021-06-30 09:23:27 --> URI Class Initialized
INFO - 2021-06-30 09:23:27 --> Router Class Initialized
INFO - 2021-06-30 09:23:27 --> Output Class Initialized
INFO - 2021-06-30 09:23:27 --> Security Class Initialized
DEBUG - 2021-06-30 09:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:23:27 --> Input Class Initialized
INFO - 2021-06-30 09:23:27 --> Language Class Initialized
INFO - 2021-06-30 09:23:27 --> Loader Class Initialized
INFO - 2021-06-30 09:23:27 --> Helper loaded: html_helper
INFO - 2021-06-30 09:23:27 --> Helper loaded: url_helper
INFO - 2021-06-30 09:23:27 --> Helper loaded: form_helper
INFO - 2021-06-30 09:23:27 --> Database Driver Class Initialized
INFO - 2021-06-30 09:23:27 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:23:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:23:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:23:27 --> Encryption Class Initialized
INFO - 2021-06-30 09:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:23:27 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:23:27 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:23:27 --> Model "user_model" initialized
INFO - 2021-06-30 09:23:27 --> Model "role_model" initialized
INFO - 2021-06-30 09:23:27 --> Controller Class Initialized
INFO - 2021-06-30 09:23:27 --> Helper loaded: language_helper
INFO - 2021-06-30 09:23:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:23:27 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:23:27 --> Model "Product_model" initialized
INFO - 2021-06-30 09:23:27 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 09:23:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 09:23:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 09:23:27 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 09:23:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 09:23:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 09:23:27 --> Final output sent to browser
DEBUG - 2021-06-30 09:23:27 --> Total execution time: 0.1271
INFO - 2021-06-30 09:23:47 --> Config Class Initialized
INFO - 2021-06-30 09:23:47 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:23:47 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:23:47 --> Utf8 Class Initialized
INFO - 2021-06-30 09:23:47 --> URI Class Initialized
INFO - 2021-06-30 09:23:47 --> Router Class Initialized
INFO - 2021-06-30 09:23:47 --> Output Class Initialized
INFO - 2021-06-30 09:23:47 --> Security Class Initialized
DEBUG - 2021-06-30 09:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:23:47 --> Input Class Initialized
INFO - 2021-06-30 09:23:47 --> Language Class Initialized
INFO - 2021-06-30 09:23:47 --> Loader Class Initialized
INFO - 2021-06-30 09:23:47 --> Helper loaded: html_helper
INFO - 2021-06-30 09:23:47 --> Helper loaded: url_helper
INFO - 2021-06-30 09:23:47 --> Helper loaded: form_helper
INFO - 2021-06-30 09:23:47 --> Database Driver Class Initialized
INFO - 2021-06-30 09:23:47 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:23:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:23:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:23:47 --> Encryption Class Initialized
INFO - 2021-06-30 09:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:23:47 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:23:47 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:23:47 --> Model "user_model" initialized
INFO - 2021-06-30 09:23:47 --> Model "role_model" initialized
INFO - 2021-06-30 09:23:47 --> Controller Class Initialized
INFO - 2021-06-30 09:23:47 --> Helper loaded: language_helper
INFO - 2021-06-30 09:23:47 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:23:47 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:23:47 --> Final output sent to browser
DEBUG - 2021-06-30 09:23:47 --> Total execution time: 0.0708
INFO - 2021-06-30 09:25:14 --> Config Class Initialized
INFO - 2021-06-30 09:25:14 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:25:14 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:25:14 --> Utf8 Class Initialized
INFO - 2021-06-30 09:25:14 --> URI Class Initialized
INFO - 2021-06-30 09:25:14 --> Router Class Initialized
INFO - 2021-06-30 09:25:14 --> Output Class Initialized
INFO - 2021-06-30 09:25:14 --> Security Class Initialized
DEBUG - 2021-06-30 09:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:25:14 --> Input Class Initialized
INFO - 2021-06-30 09:25:14 --> Language Class Initialized
INFO - 2021-06-30 09:25:14 --> Loader Class Initialized
INFO - 2021-06-30 09:25:14 --> Helper loaded: html_helper
INFO - 2021-06-30 09:25:14 --> Helper loaded: url_helper
INFO - 2021-06-30 09:25:14 --> Helper loaded: form_helper
INFO - 2021-06-30 09:25:14 --> Database Driver Class Initialized
INFO - 2021-06-30 09:25:14 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:25:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:25:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:25:14 --> Encryption Class Initialized
INFO - 2021-06-30 09:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:25:14 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:25:14 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:25:14 --> Model "user_model" initialized
INFO - 2021-06-30 09:25:14 --> Model "role_model" initialized
INFO - 2021-06-30 09:25:14 --> Controller Class Initialized
INFO - 2021-06-30 09:25:14 --> Helper loaded: language_helper
INFO - 2021-06-30 09:25:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:25:14 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:25:14 --> Model "Product_model" initialized
INFO - 2021-06-30 09:25:14 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 09:25:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 09:25:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 09:25:14 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 09:25:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 09:25:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 09:25:14 --> Final output sent to browser
DEBUG - 2021-06-30 09:25:14 --> Total execution time: 0.1179
INFO - 2021-06-30 09:25:38 --> Config Class Initialized
INFO - 2021-06-30 09:25:38 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:25:38 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:25:38 --> Utf8 Class Initialized
INFO - 2021-06-30 09:25:38 --> URI Class Initialized
INFO - 2021-06-30 09:25:38 --> Router Class Initialized
INFO - 2021-06-30 09:25:38 --> Output Class Initialized
INFO - 2021-06-30 09:25:38 --> Security Class Initialized
DEBUG - 2021-06-30 09:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:25:38 --> Input Class Initialized
INFO - 2021-06-30 09:25:38 --> Language Class Initialized
INFO - 2021-06-30 09:25:38 --> Loader Class Initialized
INFO - 2021-06-30 09:25:38 --> Helper loaded: html_helper
INFO - 2021-06-30 09:25:38 --> Helper loaded: url_helper
INFO - 2021-06-30 09:25:38 --> Helper loaded: form_helper
INFO - 2021-06-30 09:25:38 --> Database Driver Class Initialized
INFO - 2021-06-30 09:25:38 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:25:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:25:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:25:38 --> Encryption Class Initialized
INFO - 2021-06-30 09:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:25:38 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:25:38 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:25:38 --> Model "user_model" initialized
INFO - 2021-06-30 09:25:38 --> Model "role_model" initialized
INFO - 2021-06-30 09:25:38 --> Controller Class Initialized
INFO - 2021-06-30 09:25:38 --> Helper loaded: language_helper
INFO - 2021-06-30 09:25:38 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:25:38 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:25:38 --> Final output sent to browser
DEBUG - 2021-06-30 09:25:38 --> Total execution time: 0.0852
INFO - 2021-06-30 09:26:22 --> Config Class Initialized
INFO - 2021-06-30 09:26:22 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:26:22 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:26:22 --> Utf8 Class Initialized
INFO - 2021-06-30 09:26:22 --> URI Class Initialized
INFO - 2021-06-30 09:26:22 --> Router Class Initialized
INFO - 2021-06-30 09:26:22 --> Output Class Initialized
INFO - 2021-06-30 09:26:22 --> Security Class Initialized
DEBUG - 2021-06-30 09:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:26:22 --> Input Class Initialized
INFO - 2021-06-30 09:26:22 --> Language Class Initialized
INFO - 2021-06-30 09:26:22 --> Loader Class Initialized
INFO - 2021-06-30 09:26:22 --> Helper loaded: html_helper
INFO - 2021-06-30 09:26:22 --> Helper loaded: url_helper
INFO - 2021-06-30 09:26:22 --> Helper loaded: form_helper
INFO - 2021-06-30 09:26:22 --> Database Driver Class Initialized
INFO - 2021-06-30 09:26:22 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:26:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:26:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:26:22 --> Encryption Class Initialized
INFO - 2021-06-30 09:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:26:22 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:26:22 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:26:22 --> Model "user_model" initialized
INFO - 2021-06-30 09:26:22 --> Model "role_model" initialized
INFO - 2021-06-30 09:26:22 --> Controller Class Initialized
INFO - 2021-06-30 09:26:22 --> Helper loaded: language_helper
INFO - 2021-06-30 09:26:22 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:26:22 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:26:22 --> Model "Product_model" initialized
INFO - 2021-06-30 09:26:22 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 09:26:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 09:26:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 09:26:22 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 09:26:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 09:26:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 09:26:22 --> Final output sent to browser
DEBUG - 2021-06-30 09:26:22 --> Total execution time: 0.1347
INFO - 2021-06-30 09:26:42 --> Config Class Initialized
INFO - 2021-06-30 09:26:42 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:26:42 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:26:42 --> Utf8 Class Initialized
INFO - 2021-06-30 09:26:42 --> URI Class Initialized
INFO - 2021-06-30 09:26:42 --> Router Class Initialized
INFO - 2021-06-30 09:26:42 --> Output Class Initialized
INFO - 2021-06-30 09:26:42 --> Security Class Initialized
DEBUG - 2021-06-30 09:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:26:42 --> Input Class Initialized
INFO - 2021-06-30 09:26:42 --> Language Class Initialized
INFO - 2021-06-30 09:26:42 --> Loader Class Initialized
INFO - 2021-06-30 09:26:42 --> Helper loaded: html_helper
INFO - 2021-06-30 09:26:42 --> Helper loaded: url_helper
INFO - 2021-06-30 09:26:42 --> Helper loaded: form_helper
INFO - 2021-06-30 09:26:42 --> Database Driver Class Initialized
INFO - 2021-06-30 09:26:42 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:26:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:26:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:26:42 --> Encryption Class Initialized
INFO - 2021-06-30 09:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:26:42 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:26:42 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:26:42 --> Model "user_model" initialized
INFO - 2021-06-30 09:26:42 --> Model "role_model" initialized
INFO - 2021-06-30 09:26:42 --> Controller Class Initialized
INFO - 2021-06-30 09:26:42 --> Helper loaded: language_helper
INFO - 2021-06-30 09:26:42 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:26:42 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:26:42 --> Final output sent to browser
DEBUG - 2021-06-30 09:26:42 --> Total execution time: 0.0837
INFO - 2021-06-30 09:27:18 --> Config Class Initialized
INFO - 2021-06-30 09:27:18 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:27:18 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:27:18 --> Utf8 Class Initialized
INFO - 2021-06-30 09:27:18 --> URI Class Initialized
INFO - 2021-06-30 09:27:18 --> Router Class Initialized
INFO - 2021-06-30 09:27:18 --> Output Class Initialized
INFO - 2021-06-30 09:27:18 --> Security Class Initialized
DEBUG - 2021-06-30 09:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:27:18 --> Input Class Initialized
INFO - 2021-06-30 09:27:18 --> Language Class Initialized
INFO - 2021-06-30 09:27:18 --> Loader Class Initialized
INFO - 2021-06-30 09:27:18 --> Helper loaded: html_helper
INFO - 2021-06-30 09:27:18 --> Helper loaded: url_helper
INFO - 2021-06-30 09:27:18 --> Helper loaded: form_helper
INFO - 2021-06-30 09:27:18 --> Database Driver Class Initialized
INFO - 2021-06-30 09:27:18 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:27:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:27:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:27:18 --> Encryption Class Initialized
INFO - 2021-06-30 09:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:27:18 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:27:18 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:27:18 --> Model "user_model" initialized
INFO - 2021-06-30 09:27:18 --> Model "role_model" initialized
INFO - 2021-06-30 09:27:18 --> Controller Class Initialized
INFO - 2021-06-30 09:27:18 --> Helper loaded: language_helper
INFO - 2021-06-30 09:27:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:27:18 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:27:18 --> Model "Product_model" initialized
INFO - 2021-06-30 09:27:18 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 09:27:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 09:27:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 09:27:18 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 09:27:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 09:27:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 09:27:18 --> Final output sent to browser
DEBUG - 2021-06-30 09:27:18 --> Total execution time: 0.1212
INFO - 2021-06-30 09:27:36 --> Config Class Initialized
INFO - 2021-06-30 09:27:36 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:27:36 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:27:36 --> Utf8 Class Initialized
INFO - 2021-06-30 09:27:36 --> URI Class Initialized
INFO - 2021-06-30 09:27:36 --> Router Class Initialized
INFO - 2021-06-30 09:27:36 --> Output Class Initialized
INFO - 2021-06-30 09:27:36 --> Security Class Initialized
DEBUG - 2021-06-30 09:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:27:36 --> Input Class Initialized
INFO - 2021-06-30 09:27:36 --> Language Class Initialized
INFO - 2021-06-30 09:27:37 --> Loader Class Initialized
INFO - 2021-06-30 09:27:37 --> Helper loaded: html_helper
INFO - 2021-06-30 09:27:37 --> Helper loaded: url_helper
INFO - 2021-06-30 09:27:37 --> Helper loaded: form_helper
INFO - 2021-06-30 09:27:37 --> Database Driver Class Initialized
INFO - 2021-06-30 09:27:37 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:27:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:27:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:27:37 --> Encryption Class Initialized
INFO - 2021-06-30 09:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:27:37 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:27:37 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:27:37 --> Model "user_model" initialized
INFO - 2021-06-30 09:27:37 --> Model "role_model" initialized
INFO - 2021-06-30 09:27:37 --> Controller Class Initialized
INFO - 2021-06-30 09:27:37 --> Helper loaded: language_helper
INFO - 2021-06-30 09:27:37 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:27:37 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:27:37 --> Final output sent to browser
DEBUG - 2021-06-30 09:27:37 --> Total execution time: 0.0956
INFO - 2021-06-30 09:30:19 --> Config Class Initialized
INFO - 2021-06-30 09:30:19 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:30:19 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:30:19 --> Utf8 Class Initialized
INFO - 2021-06-30 09:30:19 --> URI Class Initialized
INFO - 2021-06-30 09:30:19 --> Router Class Initialized
INFO - 2021-06-30 09:30:19 --> Output Class Initialized
INFO - 2021-06-30 09:30:19 --> Security Class Initialized
DEBUG - 2021-06-30 09:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:30:19 --> Input Class Initialized
INFO - 2021-06-30 09:30:19 --> Language Class Initialized
INFO - 2021-06-30 09:30:19 --> Loader Class Initialized
INFO - 2021-06-30 09:30:19 --> Helper loaded: html_helper
INFO - 2021-06-30 09:30:19 --> Helper loaded: url_helper
INFO - 2021-06-30 09:30:19 --> Helper loaded: form_helper
INFO - 2021-06-30 09:30:19 --> Database Driver Class Initialized
INFO - 2021-06-30 09:30:19 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:30:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:30:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:30:19 --> Encryption Class Initialized
INFO - 2021-06-30 09:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:30:19 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:30:19 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:30:19 --> Model "user_model" initialized
INFO - 2021-06-30 09:30:19 --> Model "role_model" initialized
INFO - 2021-06-30 09:30:19 --> Controller Class Initialized
INFO - 2021-06-30 09:30:19 --> Helper loaded: language_helper
INFO - 2021-06-30 09:30:19 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:30:19 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:30:19 --> Model "Product_model" initialized
INFO - 2021-06-30 09:30:19 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 09:30:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 09:30:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 09:30:20 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 09:30:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 09:30:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 09:30:20 --> Final output sent to browser
DEBUG - 2021-06-30 09:30:20 --> Total execution time: 0.1191
INFO - 2021-06-30 09:30:41 --> Config Class Initialized
INFO - 2021-06-30 09:30:41 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:30:41 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:30:41 --> Utf8 Class Initialized
INFO - 2021-06-30 09:30:41 --> URI Class Initialized
INFO - 2021-06-30 09:30:41 --> Router Class Initialized
INFO - 2021-06-30 09:30:41 --> Output Class Initialized
INFO - 2021-06-30 09:30:41 --> Security Class Initialized
DEBUG - 2021-06-30 09:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:30:41 --> Input Class Initialized
INFO - 2021-06-30 09:30:41 --> Language Class Initialized
INFO - 2021-06-30 09:30:41 --> Loader Class Initialized
INFO - 2021-06-30 09:30:41 --> Helper loaded: html_helper
INFO - 2021-06-30 09:30:41 --> Helper loaded: url_helper
INFO - 2021-06-30 09:30:41 --> Helper loaded: form_helper
INFO - 2021-06-30 09:30:41 --> Database Driver Class Initialized
INFO - 2021-06-30 09:30:41 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:30:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:30:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:30:41 --> Encryption Class Initialized
INFO - 2021-06-30 09:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:30:41 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:30:41 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:30:41 --> Model "user_model" initialized
INFO - 2021-06-30 09:30:41 --> Model "role_model" initialized
INFO - 2021-06-30 09:30:41 --> Controller Class Initialized
INFO - 2021-06-30 09:30:41 --> Helper loaded: language_helper
INFO - 2021-06-30 09:30:41 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:30:41 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:30:41 --> Final output sent to browser
DEBUG - 2021-06-30 09:30:41 --> Total execution time: 0.0692
INFO - 2021-06-30 09:31:02 --> Config Class Initialized
INFO - 2021-06-30 09:31:02 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:31:02 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:31:02 --> Utf8 Class Initialized
INFO - 2021-06-30 09:31:02 --> URI Class Initialized
INFO - 2021-06-30 09:31:02 --> Router Class Initialized
INFO - 2021-06-30 09:31:02 --> Output Class Initialized
INFO - 2021-06-30 09:31:02 --> Security Class Initialized
DEBUG - 2021-06-30 09:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:31:02 --> Input Class Initialized
INFO - 2021-06-30 09:31:02 --> Language Class Initialized
INFO - 2021-06-30 09:31:02 --> Loader Class Initialized
INFO - 2021-06-30 09:31:02 --> Helper loaded: html_helper
INFO - 2021-06-30 09:31:02 --> Helper loaded: url_helper
INFO - 2021-06-30 09:31:02 --> Helper loaded: form_helper
INFO - 2021-06-30 09:31:02 --> Database Driver Class Initialized
INFO - 2021-06-30 09:31:02 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:31:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:31:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:31:02 --> Encryption Class Initialized
INFO - 2021-06-30 09:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:31:02 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:31:02 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:31:02 --> Model "user_model" initialized
INFO - 2021-06-30 09:31:02 --> Model "role_model" initialized
INFO - 2021-06-30 09:31:02 --> Controller Class Initialized
INFO - 2021-06-30 09:31:02 --> Helper loaded: language_helper
INFO - 2021-06-30 09:31:02 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:31:02 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:31:02 --> Model "Product_model" initialized
INFO - 2021-06-30 09:31:02 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 09:31:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 09:31:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 09:31:02 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 09:31:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 09:31:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 09:31:02 --> Final output sent to browser
DEBUG - 2021-06-30 09:31:02 --> Total execution time: 0.0699
INFO - 2021-06-30 09:32:27 --> Config Class Initialized
INFO - 2021-06-30 09:32:27 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:32:27 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:32:27 --> Utf8 Class Initialized
INFO - 2021-06-30 09:32:27 --> URI Class Initialized
INFO - 2021-06-30 09:32:27 --> Router Class Initialized
INFO - 2021-06-30 09:32:27 --> Output Class Initialized
INFO - 2021-06-30 09:32:27 --> Security Class Initialized
DEBUG - 2021-06-30 09:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:32:27 --> Input Class Initialized
INFO - 2021-06-30 09:32:27 --> Language Class Initialized
INFO - 2021-06-30 09:32:27 --> Loader Class Initialized
INFO - 2021-06-30 09:32:27 --> Helper loaded: html_helper
INFO - 2021-06-30 09:32:27 --> Helper loaded: url_helper
INFO - 2021-06-30 09:32:27 --> Helper loaded: form_helper
INFO - 2021-06-30 09:32:27 --> Database Driver Class Initialized
INFO - 2021-06-30 09:32:27 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:32:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:32:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:32:27 --> Encryption Class Initialized
INFO - 2021-06-30 09:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:32:27 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:32:27 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:32:27 --> Model "user_model" initialized
INFO - 2021-06-30 09:32:27 --> Model "role_model" initialized
INFO - 2021-06-30 09:32:27 --> Controller Class Initialized
INFO - 2021-06-30 09:32:27 --> Helper loaded: language_helper
INFO - 2021-06-30 09:32:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:32:27 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:32:27 --> Model "Product_model" initialized
INFO - 2021-06-30 09:32:27 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 09:32:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 09:32:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 09:32:27 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 09:32:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 09:32:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 09:32:27 --> Final output sent to browser
DEBUG - 2021-06-30 09:32:27 --> Total execution time: 0.1216
INFO - 2021-06-30 09:32:53 --> Config Class Initialized
INFO - 2021-06-30 09:32:53 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:32:53 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:32:53 --> Utf8 Class Initialized
INFO - 2021-06-30 09:32:53 --> URI Class Initialized
INFO - 2021-06-30 09:32:53 --> Router Class Initialized
INFO - 2021-06-30 09:32:53 --> Output Class Initialized
INFO - 2021-06-30 09:32:53 --> Security Class Initialized
DEBUG - 2021-06-30 09:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:32:53 --> Input Class Initialized
INFO - 2021-06-30 09:32:53 --> Language Class Initialized
INFO - 2021-06-30 09:32:53 --> Loader Class Initialized
INFO - 2021-06-30 09:32:53 --> Helper loaded: html_helper
INFO - 2021-06-30 09:32:53 --> Helper loaded: url_helper
INFO - 2021-06-30 09:32:53 --> Helper loaded: form_helper
INFO - 2021-06-30 09:32:53 --> Database Driver Class Initialized
INFO - 2021-06-30 09:32:53 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:32:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:32:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:32:53 --> Encryption Class Initialized
INFO - 2021-06-30 09:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:32:53 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:32:53 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:32:53 --> Model "user_model" initialized
INFO - 2021-06-30 09:32:53 --> Model "role_model" initialized
INFO - 2021-06-30 09:32:53 --> Controller Class Initialized
INFO - 2021-06-30 09:32:53 --> Helper loaded: language_helper
INFO - 2021-06-30 09:32:53 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:32:53 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:32:53 --> Final output sent to browser
DEBUG - 2021-06-30 09:32:53 --> Total execution time: 0.0799
INFO - 2021-06-30 09:34:56 --> Config Class Initialized
INFO - 2021-06-30 09:34:56 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:34:56 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:34:56 --> Utf8 Class Initialized
INFO - 2021-06-30 09:34:56 --> URI Class Initialized
INFO - 2021-06-30 09:34:56 --> Router Class Initialized
INFO - 2021-06-30 09:34:56 --> Output Class Initialized
INFO - 2021-06-30 09:34:56 --> Security Class Initialized
DEBUG - 2021-06-30 09:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:34:56 --> Input Class Initialized
INFO - 2021-06-30 09:34:56 --> Language Class Initialized
INFO - 2021-06-30 09:34:56 --> Loader Class Initialized
INFO - 2021-06-30 09:34:56 --> Helper loaded: html_helper
INFO - 2021-06-30 09:34:56 --> Helper loaded: url_helper
INFO - 2021-06-30 09:34:56 --> Helper loaded: form_helper
INFO - 2021-06-30 09:34:56 --> Database Driver Class Initialized
INFO - 2021-06-30 09:34:56 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:34:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:34:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:34:56 --> Encryption Class Initialized
INFO - 2021-06-30 09:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:34:56 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:34:56 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:34:56 --> Model "user_model" initialized
INFO - 2021-06-30 09:34:56 --> Model "role_model" initialized
INFO - 2021-06-30 09:34:56 --> Controller Class Initialized
INFO - 2021-06-30 09:34:56 --> Helper loaded: language_helper
INFO - 2021-06-30 09:34:56 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:34:56 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:34:56 --> Model "Product_model" initialized
INFO - 2021-06-30 09:34:56 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 09:34:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 09:34:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 09:34:56 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 09:34:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 09:34:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 09:34:56 --> Final output sent to browser
DEBUG - 2021-06-30 09:34:56 --> Total execution time: 0.1135
INFO - 2021-06-30 09:35:14 --> Config Class Initialized
INFO - 2021-06-30 09:35:14 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:35:14 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:35:14 --> Utf8 Class Initialized
INFO - 2021-06-30 09:35:14 --> URI Class Initialized
INFO - 2021-06-30 09:35:14 --> Router Class Initialized
INFO - 2021-06-30 09:35:14 --> Output Class Initialized
INFO - 2021-06-30 09:35:14 --> Security Class Initialized
DEBUG - 2021-06-30 09:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:35:14 --> Input Class Initialized
INFO - 2021-06-30 09:35:14 --> Language Class Initialized
INFO - 2021-06-30 09:35:14 --> Loader Class Initialized
INFO - 2021-06-30 09:35:14 --> Helper loaded: html_helper
INFO - 2021-06-30 09:35:14 --> Helper loaded: url_helper
INFO - 2021-06-30 09:35:14 --> Helper loaded: form_helper
INFO - 2021-06-30 09:35:14 --> Database Driver Class Initialized
INFO - 2021-06-30 09:35:14 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:35:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:35:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:35:14 --> Encryption Class Initialized
INFO - 2021-06-30 09:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:35:14 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:35:14 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:35:14 --> Model "user_model" initialized
INFO - 2021-06-30 09:35:14 --> Model "role_model" initialized
INFO - 2021-06-30 09:35:14 --> Controller Class Initialized
INFO - 2021-06-30 09:35:14 --> Helper loaded: language_helper
INFO - 2021-06-30 09:35:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:35:14 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:35:14 --> Final output sent to browser
DEBUG - 2021-06-30 09:35:14 --> Total execution time: 0.0677
INFO - 2021-06-30 09:36:22 --> Config Class Initialized
INFO - 2021-06-30 09:36:22 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:36:22 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:36:22 --> Utf8 Class Initialized
INFO - 2021-06-30 09:36:22 --> URI Class Initialized
INFO - 2021-06-30 09:36:22 --> Router Class Initialized
INFO - 2021-06-30 09:36:22 --> Output Class Initialized
INFO - 2021-06-30 09:36:22 --> Security Class Initialized
DEBUG - 2021-06-30 09:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:36:22 --> Input Class Initialized
INFO - 2021-06-30 09:36:22 --> Language Class Initialized
INFO - 2021-06-30 09:36:22 --> Loader Class Initialized
INFO - 2021-06-30 09:36:22 --> Helper loaded: html_helper
INFO - 2021-06-30 09:36:22 --> Helper loaded: url_helper
INFO - 2021-06-30 09:36:22 --> Helper loaded: form_helper
INFO - 2021-06-30 09:36:22 --> Database Driver Class Initialized
INFO - 2021-06-30 09:36:23 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:36:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:36:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:36:23 --> Encryption Class Initialized
INFO - 2021-06-30 09:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:36:23 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:36:23 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:36:23 --> Model "user_model" initialized
INFO - 2021-06-30 09:36:23 --> Model "role_model" initialized
INFO - 2021-06-30 09:36:23 --> Controller Class Initialized
INFO - 2021-06-30 09:36:23 --> Helper loaded: language_helper
INFO - 2021-06-30 09:36:23 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:36:23 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:36:23 --> Model "Product_model" initialized
INFO - 2021-06-30 09:36:23 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 09:36:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 09:36:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 09:36:23 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 09:36:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 09:36:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 09:36:23 --> Final output sent to browser
DEBUG - 2021-06-30 09:36:23 --> Total execution time: 0.0788
INFO - 2021-06-30 09:53:08 --> Config Class Initialized
INFO - 2021-06-30 09:53:08 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:53:08 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:53:08 --> Utf8 Class Initialized
INFO - 2021-06-30 09:53:08 --> URI Class Initialized
INFO - 2021-06-30 09:53:08 --> Router Class Initialized
INFO - 2021-06-30 09:53:08 --> Output Class Initialized
INFO - 2021-06-30 09:53:08 --> Security Class Initialized
DEBUG - 2021-06-30 09:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:53:08 --> Input Class Initialized
INFO - 2021-06-30 09:53:08 --> Language Class Initialized
INFO - 2021-06-30 09:53:08 --> Loader Class Initialized
INFO - 2021-06-30 09:53:08 --> Helper loaded: html_helper
INFO - 2021-06-30 09:53:08 --> Helper loaded: url_helper
INFO - 2021-06-30 09:53:08 --> Helper loaded: form_helper
INFO - 2021-06-30 09:53:08 --> Database Driver Class Initialized
INFO - 2021-06-30 09:53:08 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:53:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:53:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:53:08 --> Encryption Class Initialized
INFO - 2021-06-30 09:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:53:08 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:53:08 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:53:08 --> Model "user_model" initialized
INFO - 2021-06-30 09:53:08 --> Model "role_model" initialized
INFO - 2021-06-30 09:53:08 --> Controller Class Initialized
INFO - 2021-06-30 09:53:08 --> Helper loaded: language_helper
INFO - 2021-06-30 09:53:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:53:08 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:53:08 --> Model "Product_model" initialized
INFO - 2021-06-30 09:53:08 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 09:53:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 09:53:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 09:53:09 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 09:53:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 09:53:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 09:53:09 --> Final output sent to browser
DEBUG - 2021-06-30 09:53:09 --> Total execution time: 0.1301
INFO - 2021-06-30 09:53:13 --> Config Class Initialized
INFO - 2021-06-30 09:53:13 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:53:13 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:53:13 --> Utf8 Class Initialized
INFO - 2021-06-30 09:53:13 --> URI Class Initialized
INFO - 2021-06-30 09:53:13 --> Router Class Initialized
INFO - 2021-06-30 09:53:13 --> Output Class Initialized
INFO - 2021-06-30 09:53:13 --> Security Class Initialized
DEBUG - 2021-06-30 09:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:53:13 --> Input Class Initialized
INFO - 2021-06-30 09:53:13 --> Language Class Initialized
INFO - 2021-06-30 09:53:13 --> Loader Class Initialized
INFO - 2021-06-30 09:53:13 --> Helper loaded: html_helper
INFO - 2021-06-30 09:53:13 --> Helper loaded: url_helper
INFO - 2021-06-30 09:53:13 --> Helper loaded: form_helper
INFO - 2021-06-30 09:53:13 --> Database Driver Class Initialized
INFO - 2021-06-30 09:53:13 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:53:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:53:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:53:13 --> Encryption Class Initialized
INFO - 2021-06-30 09:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:53:13 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:53:13 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:53:13 --> Model "user_model" initialized
INFO - 2021-06-30 09:53:13 --> Model "role_model" initialized
INFO - 2021-06-30 09:53:13 --> Controller Class Initialized
INFO - 2021-06-30 09:53:13 --> Helper loaded: language_helper
INFO - 2021-06-30 09:53:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:53:13 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:53:13 --> Model "Product_model" initialized
INFO - 2021-06-30 09:53:13 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 09:53:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 09:53:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 09:53:13 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 09:53:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 09:53:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 09:53:13 --> Final output sent to browser
DEBUG - 2021-06-30 09:53:13 --> Total execution time: 0.0782
INFO - 2021-06-30 09:53:31 --> Config Class Initialized
INFO - 2021-06-30 09:53:31 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:53:31 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:53:31 --> Utf8 Class Initialized
INFO - 2021-06-30 09:53:31 --> URI Class Initialized
INFO - 2021-06-30 09:53:31 --> Router Class Initialized
INFO - 2021-06-30 09:53:31 --> Output Class Initialized
INFO - 2021-06-30 09:53:31 --> Security Class Initialized
DEBUG - 2021-06-30 09:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:53:31 --> Input Class Initialized
INFO - 2021-06-30 09:53:31 --> Language Class Initialized
INFO - 2021-06-30 09:53:31 --> Loader Class Initialized
INFO - 2021-06-30 09:53:31 --> Helper loaded: html_helper
INFO - 2021-06-30 09:53:31 --> Helper loaded: url_helper
INFO - 2021-06-30 09:53:31 --> Helper loaded: form_helper
INFO - 2021-06-30 09:53:31 --> Database Driver Class Initialized
INFO - 2021-06-30 09:53:31 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:53:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:53:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:53:31 --> Encryption Class Initialized
INFO - 2021-06-30 09:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:53:31 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:53:31 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:53:31 --> Model "user_model" initialized
INFO - 2021-06-30 09:53:31 --> Model "role_model" initialized
INFO - 2021-06-30 09:53:31 --> Controller Class Initialized
INFO - 2021-06-30 09:53:31 --> Helper loaded: language_helper
INFO - 2021-06-30 09:53:31 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:53:31 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:53:31 --> Final output sent to browser
DEBUG - 2021-06-30 09:53:31 --> Total execution time: 0.0707
INFO - 2021-06-30 09:53:45 --> Config Class Initialized
INFO - 2021-06-30 09:53:45 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:53:45 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:53:45 --> Utf8 Class Initialized
INFO - 2021-06-30 09:53:45 --> URI Class Initialized
INFO - 2021-06-30 09:53:45 --> Router Class Initialized
INFO - 2021-06-30 09:53:45 --> Output Class Initialized
INFO - 2021-06-30 09:53:45 --> Security Class Initialized
DEBUG - 2021-06-30 09:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:53:45 --> Input Class Initialized
INFO - 2021-06-30 09:53:45 --> Language Class Initialized
INFO - 2021-06-30 09:53:45 --> Loader Class Initialized
INFO - 2021-06-30 09:53:45 --> Helper loaded: html_helper
INFO - 2021-06-30 09:53:45 --> Helper loaded: url_helper
INFO - 2021-06-30 09:53:45 --> Helper loaded: form_helper
INFO - 2021-06-30 09:53:45 --> Database Driver Class Initialized
INFO - 2021-06-30 09:53:45 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:53:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:53:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:53:45 --> Encryption Class Initialized
INFO - 2021-06-30 09:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:53:45 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:53:45 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:53:45 --> Model "user_model" initialized
INFO - 2021-06-30 09:53:45 --> Model "role_model" initialized
INFO - 2021-06-30 09:53:45 --> Controller Class Initialized
INFO - 2021-06-30 09:53:45 --> Helper loaded: language_helper
INFO - 2021-06-30 09:53:45 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:53:45 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:53:45 --> Model "Product_model" initialized
INFO - 2021-06-30 09:53:45 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 09:53:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 09:53:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 09:53:45 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 09:53:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 09:53:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 09:53:45 --> Final output sent to browser
DEBUG - 2021-06-30 09:53:45 --> Total execution time: 0.0904
INFO - 2021-06-30 09:54:06 --> Config Class Initialized
INFO - 2021-06-30 09:54:06 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:54:06 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:54:06 --> Utf8 Class Initialized
INFO - 2021-06-30 09:54:06 --> URI Class Initialized
INFO - 2021-06-30 09:54:06 --> Router Class Initialized
INFO - 2021-06-30 09:54:06 --> Output Class Initialized
INFO - 2021-06-30 09:54:06 --> Security Class Initialized
DEBUG - 2021-06-30 09:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:54:06 --> Input Class Initialized
INFO - 2021-06-30 09:54:06 --> Language Class Initialized
INFO - 2021-06-30 09:54:06 --> Loader Class Initialized
INFO - 2021-06-30 09:54:06 --> Helper loaded: html_helper
INFO - 2021-06-30 09:54:06 --> Helper loaded: url_helper
INFO - 2021-06-30 09:54:06 --> Helper loaded: form_helper
INFO - 2021-06-30 09:54:06 --> Database Driver Class Initialized
INFO - 2021-06-30 09:54:06 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:54:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:54:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:54:06 --> Encryption Class Initialized
INFO - 2021-06-30 09:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:54:06 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:54:06 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:54:06 --> Model "user_model" initialized
INFO - 2021-06-30 09:54:06 --> Model "role_model" initialized
INFO - 2021-06-30 09:54:06 --> Controller Class Initialized
INFO - 2021-06-30 09:54:06 --> Helper loaded: language_helper
INFO - 2021-06-30 09:54:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:54:06 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:54:06 --> Final output sent to browser
DEBUG - 2021-06-30 09:54:06 --> Total execution time: 0.0852
INFO - 2021-06-30 09:55:14 --> Config Class Initialized
INFO - 2021-06-30 09:55:14 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:55:14 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:55:14 --> Utf8 Class Initialized
INFO - 2021-06-30 09:55:14 --> URI Class Initialized
INFO - 2021-06-30 09:55:14 --> Router Class Initialized
INFO - 2021-06-30 09:55:14 --> Output Class Initialized
INFO - 2021-06-30 09:55:14 --> Security Class Initialized
DEBUG - 2021-06-30 09:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:55:14 --> Input Class Initialized
INFO - 2021-06-30 09:55:14 --> Language Class Initialized
INFO - 2021-06-30 09:55:14 --> Loader Class Initialized
INFO - 2021-06-30 09:55:14 --> Helper loaded: html_helper
INFO - 2021-06-30 09:55:14 --> Helper loaded: url_helper
INFO - 2021-06-30 09:55:14 --> Helper loaded: form_helper
INFO - 2021-06-30 09:55:14 --> Database Driver Class Initialized
INFO - 2021-06-30 09:55:14 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:55:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:55:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:55:14 --> Encryption Class Initialized
INFO - 2021-06-30 09:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:55:14 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:55:14 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:55:14 --> Model "user_model" initialized
INFO - 2021-06-30 09:55:14 --> Model "role_model" initialized
INFO - 2021-06-30 09:55:14 --> Controller Class Initialized
INFO - 2021-06-30 09:55:14 --> Helper loaded: language_helper
INFO - 2021-06-30 09:55:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:55:14 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:55:14 --> Model "Product_model" initialized
INFO - 2021-06-30 09:55:14 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 09:55:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 09:55:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 09:55:14 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 09:55:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 09:55:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 09:55:14 --> Final output sent to browser
DEBUG - 2021-06-30 09:55:14 --> Total execution time: 0.1163
INFO - 2021-06-30 09:55:43 --> Config Class Initialized
INFO - 2021-06-30 09:55:43 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:55:43 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:55:43 --> Utf8 Class Initialized
INFO - 2021-06-30 09:55:43 --> URI Class Initialized
INFO - 2021-06-30 09:55:43 --> Router Class Initialized
INFO - 2021-06-30 09:55:43 --> Output Class Initialized
INFO - 2021-06-30 09:55:43 --> Security Class Initialized
DEBUG - 2021-06-30 09:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:55:43 --> Input Class Initialized
INFO - 2021-06-30 09:55:43 --> Language Class Initialized
INFO - 2021-06-30 09:55:43 --> Loader Class Initialized
INFO - 2021-06-30 09:55:43 --> Helper loaded: html_helper
INFO - 2021-06-30 09:55:43 --> Helper loaded: url_helper
INFO - 2021-06-30 09:55:43 --> Helper loaded: form_helper
INFO - 2021-06-30 09:55:43 --> Database Driver Class Initialized
INFO - 2021-06-30 09:55:43 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:55:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:55:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:55:43 --> Encryption Class Initialized
INFO - 2021-06-30 09:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:55:43 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:55:43 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:55:43 --> Model "user_model" initialized
INFO - 2021-06-30 09:55:43 --> Model "role_model" initialized
INFO - 2021-06-30 09:55:43 --> Controller Class Initialized
INFO - 2021-06-30 09:55:43 --> Helper loaded: language_helper
INFO - 2021-06-30 09:55:43 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:55:43 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:55:43 --> Final output sent to browser
DEBUG - 2021-06-30 09:55:43 --> Total execution time: 0.0741
INFO - 2021-06-30 09:57:49 --> Config Class Initialized
INFO - 2021-06-30 09:57:49 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:57:49 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:57:49 --> Utf8 Class Initialized
INFO - 2021-06-30 09:57:49 --> URI Class Initialized
INFO - 2021-06-30 09:57:49 --> Router Class Initialized
INFO - 2021-06-30 09:57:49 --> Output Class Initialized
INFO - 2021-06-30 09:57:49 --> Security Class Initialized
DEBUG - 2021-06-30 09:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:57:49 --> Input Class Initialized
INFO - 2021-06-30 09:57:49 --> Language Class Initialized
INFO - 2021-06-30 09:57:49 --> Loader Class Initialized
INFO - 2021-06-30 09:57:49 --> Helper loaded: html_helper
INFO - 2021-06-30 09:57:49 --> Helper loaded: url_helper
INFO - 2021-06-30 09:57:49 --> Helper loaded: form_helper
INFO - 2021-06-30 09:57:49 --> Database Driver Class Initialized
INFO - 2021-06-30 09:57:49 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:57:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:57:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:57:49 --> Encryption Class Initialized
INFO - 2021-06-30 09:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:57:49 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:57:49 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:57:49 --> Model "user_model" initialized
INFO - 2021-06-30 09:57:49 --> Model "role_model" initialized
INFO - 2021-06-30 09:57:49 --> Controller Class Initialized
INFO - 2021-06-30 09:57:49 --> Helper loaded: language_helper
INFO - 2021-06-30 09:57:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:57:49 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:57:49 --> Model "Product_model" initialized
INFO - 2021-06-30 09:57:49 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 09:57:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 09:57:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 09:57:49 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 09:57:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 09:57:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 09:57:49 --> Final output sent to browser
DEBUG - 2021-06-30 09:57:49 --> Total execution time: 0.1160
INFO - 2021-06-30 09:58:09 --> Config Class Initialized
INFO - 2021-06-30 09:58:09 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:58:09 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:58:09 --> Utf8 Class Initialized
INFO - 2021-06-30 09:58:09 --> URI Class Initialized
INFO - 2021-06-30 09:58:09 --> Router Class Initialized
INFO - 2021-06-30 09:58:09 --> Output Class Initialized
INFO - 2021-06-30 09:58:09 --> Security Class Initialized
DEBUG - 2021-06-30 09:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:58:09 --> Input Class Initialized
INFO - 2021-06-30 09:58:09 --> Language Class Initialized
INFO - 2021-06-30 09:58:09 --> Loader Class Initialized
INFO - 2021-06-30 09:58:09 --> Helper loaded: html_helper
INFO - 2021-06-30 09:58:09 --> Helper loaded: url_helper
INFO - 2021-06-30 09:58:09 --> Helper loaded: form_helper
INFO - 2021-06-30 09:58:09 --> Database Driver Class Initialized
INFO - 2021-06-30 09:58:09 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:58:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:58:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:58:09 --> Encryption Class Initialized
INFO - 2021-06-30 09:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:58:09 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:58:09 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:58:09 --> Model "user_model" initialized
INFO - 2021-06-30 09:58:09 --> Model "role_model" initialized
INFO - 2021-06-30 09:58:09 --> Controller Class Initialized
INFO - 2021-06-30 09:58:09 --> Helper loaded: language_helper
INFO - 2021-06-30 09:58:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:58:09 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:58:09 --> Final output sent to browser
DEBUG - 2021-06-30 09:58:09 --> Total execution time: 0.0784
INFO - 2021-06-30 09:58:22 --> Config Class Initialized
INFO - 2021-06-30 09:58:22 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:58:22 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:58:22 --> Utf8 Class Initialized
INFO - 2021-06-30 09:58:22 --> URI Class Initialized
INFO - 2021-06-30 09:58:22 --> Router Class Initialized
INFO - 2021-06-30 09:58:22 --> Output Class Initialized
INFO - 2021-06-30 09:58:22 --> Security Class Initialized
DEBUG - 2021-06-30 09:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:58:22 --> Input Class Initialized
INFO - 2021-06-30 09:58:22 --> Language Class Initialized
INFO - 2021-06-30 09:58:22 --> Loader Class Initialized
INFO - 2021-06-30 09:58:22 --> Helper loaded: html_helper
INFO - 2021-06-30 09:58:22 --> Helper loaded: url_helper
INFO - 2021-06-30 09:58:22 --> Helper loaded: form_helper
INFO - 2021-06-30 09:58:22 --> Database Driver Class Initialized
INFO - 2021-06-30 09:58:22 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:58:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:58:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:58:22 --> Encryption Class Initialized
INFO - 2021-06-30 09:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:58:22 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:58:22 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:58:22 --> Model "user_model" initialized
INFO - 2021-06-30 09:58:22 --> Model "role_model" initialized
INFO - 2021-06-30 09:58:22 --> Controller Class Initialized
INFO - 2021-06-30 09:58:22 --> Helper loaded: language_helper
INFO - 2021-06-30 09:58:22 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:58:22 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:58:22 --> Model "Product_model" initialized
INFO - 2021-06-30 09:58:22 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 09:58:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 09:58:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 09:58:22 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 09:58:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 09:58:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 09:58:22 --> Final output sent to browser
DEBUG - 2021-06-30 09:58:22 --> Total execution time: 0.1149
INFO - 2021-06-30 09:58:39 --> Config Class Initialized
INFO - 2021-06-30 09:58:39 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:58:39 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:58:39 --> Utf8 Class Initialized
INFO - 2021-06-30 09:58:39 --> URI Class Initialized
INFO - 2021-06-30 09:58:39 --> Router Class Initialized
INFO - 2021-06-30 09:58:39 --> Output Class Initialized
INFO - 2021-06-30 09:58:39 --> Security Class Initialized
DEBUG - 2021-06-30 09:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:58:39 --> Input Class Initialized
INFO - 2021-06-30 09:58:39 --> Language Class Initialized
INFO - 2021-06-30 09:58:39 --> Loader Class Initialized
INFO - 2021-06-30 09:58:39 --> Helper loaded: html_helper
INFO - 2021-06-30 09:58:39 --> Helper loaded: url_helper
INFO - 2021-06-30 09:58:39 --> Helper loaded: form_helper
INFO - 2021-06-30 09:58:39 --> Database Driver Class Initialized
INFO - 2021-06-30 09:58:39 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:58:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:58:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:58:39 --> Encryption Class Initialized
INFO - 2021-06-30 09:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:58:39 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:58:39 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:58:39 --> Model "user_model" initialized
INFO - 2021-06-30 09:58:39 --> Model "role_model" initialized
INFO - 2021-06-30 09:58:39 --> Controller Class Initialized
INFO - 2021-06-30 09:58:39 --> Helper loaded: language_helper
INFO - 2021-06-30 09:58:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:58:39 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:58:39 --> Final output sent to browser
DEBUG - 2021-06-30 09:58:39 --> Total execution time: 0.0736
INFO - 2021-06-30 09:59:34 --> Config Class Initialized
INFO - 2021-06-30 09:59:34 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:59:34 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:59:34 --> Utf8 Class Initialized
INFO - 2021-06-30 09:59:34 --> URI Class Initialized
INFO - 2021-06-30 09:59:34 --> Router Class Initialized
INFO - 2021-06-30 09:59:34 --> Output Class Initialized
INFO - 2021-06-30 09:59:34 --> Security Class Initialized
DEBUG - 2021-06-30 09:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:59:34 --> Input Class Initialized
INFO - 2021-06-30 09:59:34 --> Language Class Initialized
INFO - 2021-06-30 09:59:34 --> Loader Class Initialized
INFO - 2021-06-30 09:59:34 --> Helper loaded: html_helper
INFO - 2021-06-30 09:59:34 --> Helper loaded: url_helper
INFO - 2021-06-30 09:59:34 --> Helper loaded: form_helper
INFO - 2021-06-30 09:59:34 --> Database Driver Class Initialized
INFO - 2021-06-30 09:59:34 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:59:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:59:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:59:34 --> Encryption Class Initialized
INFO - 2021-06-30 09:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:59:34 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:59:34 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:59:34 --> Model "user_model" initialized
INFO - 2021-06-30 09:59:34 --> Model "role_model" initialized
INFO - 2021-06-30 09:59:34 --> Controller Class Initialized
INFO - 2021-06-30 09:59:34 --> Helper loaded: language_helper
INFO - 2021-06-30 09:59:34 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:59:34 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:59:34 --> Model "Product_model" initialized
INFO - 2021-06-30 09:59:34 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 09:59:34 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 09:59:34 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 09:59:34 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 09:59:34 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 09:59:34 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 09:59:34 --> Final output sent to browser
DEBUG - 2021-06-30 09:59:34 --> Total execution time: 0.1108
INFO - 2021-06-30 09:59:54 --> Config Class Initialized
INFO - 2021-06-30 09:59:54 --> Hooks Class Initialized
DEBUG - 2021-06-30 09:59:54 --> UTF-8 Support Enabled
INFO - 2021-06-30 09:59:54 --> Utf8 Class Initialized
INFO - 2021-06-30 09:59:54 --> URI Class Initialized
INFO - 2021-06-30 09:59:54 --> Router Class Initialized
INFO - 2021-06-30 09:59:54 --> Output Class Initialized
INFO - 2021-06-30 09:59:54 --> Security Class Initialized
DEBUG - 2021-06-30 09:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 09:59:54 --> Input Class Initialized
INFO - 2021-06-30 09:59:54 --> Language Class Initialized
INFO - 2021-06-30 09:59:54 --> Loader Class Initialized
INFO - 2021-06-30 09:59:54 --> Helper loaded: html_helper
INFO - 2021-06-30 09:59:54 --> Helper loaded: url_helper
INFO - 2021-06-30 09:59:54 --> Helper loaded: form_helper
INFO - 2021-06-30 09:59:54 --> Database Driver Class Initialized
INFO - 2021-06-30 09:59:54 --> Form Validation Class Initialized
DEBUG - 2021-06-30 09:59:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 09:59:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 09:59:54 --> Encryption Class Initialized
INFO - 2021-06-30 09:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 09:59:54 --> Model "vendor_model" initialized
INFO - 2021-06-30 09:59:54 --> Model "coupon_model" initialized
INFO - 2021-06-30 09:59:54 --> Model "user_model" initialized
INFO - 2021-06-30 09:59:54 --> Model "role_model" initialized
INFO - 2021-06-30 09:59:54 --> Controller Class Initialized
INFO - 2021-06-30 09:59:54 --> Helper loaded: language_helper
INFO - 2021-06-30 09:59:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 09:59:54 --> Model "Customer_model" initialized
INFO - 2021-06-30 09:59:54 --> Model "Product_model" initialized
INFO - 2021-06-30 09:59:54 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 09:59:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 09:59:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 09:59:54 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 09:59:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 09:59:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 09:59:54 --> Final output sent to browser
DEBUG - 2021-06-30 09:59:54 --> Total execution time: 0.0711
INFO - 2021-06-30 10:00:04 --> Config Class Initialized
INFO - 2021-06-30 10:00:04 --> Hooks Class Initialized
DEBUG - 2021-06-30 10:00:04 --> UTF-8 Support Enabled
INFO - 2021-06-30 10:00:04 --> Utf8 Class Initialized
INFO - 2021-06-30 10:00:04 --> URI Class Initialized
INFO - 2021-06-30 10:00:04 --> Router Class Initialized
INFO - 2021-06-30 10:00:04 --> Output Class Initialized
INFO - 2021-06-30 10:00:04 --> Security Class Initialized
DEBUG - 2021-06-30 10:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 10:00:04 --> Input Class Initialized
INFO - 2021-06-30 10:00:04 --> Language Class Initialized
INFO - 2021-06-30 10:00:04 --> Loader Class Initialized
INFO - 2021-06-30 10:00:04 --> Helper loaded: html_helper
INFO - 2021-06-30 10:00:04 --> Helper loaded: url_helper
INFO - 2021-06-30 10:00:04 --> Helper loaded: form_helper
INFO - 2021-06-30 10:00:04 --> Database Driver Class Initialized
INFO - 2021-06-30 10:00:04 --> Form Validation Class Initialized
DEBUG - 2021-06-30 10:00:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 10:00:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 10:00:04 --> Encryption Class Initialized
INFO - 2021-06-30 10:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 10:00:04 --> Model "vendor_model" initialized
INFO - 2021-06-30 10:00:04 --> Model "coupon_model" initialized
INFO - 2021-06-30 10:00:04 --> Model "user_model" initialized
INFO - 2021-06-30 10:00:04 --> Model "role_model" initialized
INFO - 2021-06-30 10:00:04 --> Controller Class Initialized
INFO - 2021-06-30 10:00:04 --> Helper loaded: language_helper
INFO - 2021-06-30 10:00:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 10:00:04 --> Model "Customer_model" initialized
INFO - 2021-06-30 10:00:04 --> Final output sent to browser
DEBUG - 2021-06-30 10:00:04 --> Total execution time: 0.0692
INFO - 2021-06-30 10:00:09 --> Config Class Initialized
INFO - 2021-06-30 10:00:09 --> Hooks Class Initialized
DEBUG - 2021-06-30 10:00:09 --> UTF-8 Support Enabled
INFO - 2021-06-30 10:00:09 --> Utf8 Class Initialized
INFO - 2021-06-30 10:00:09 --> URI Class Initialized
INFO - 2021-06-30 10:00:09 --> Router Class Initialized
INFO - 2021-06-30 10:00:09 --> Output Class Initialized
INFO - 2021-06-30 10:00:09 --> Security Class Initialized
DEBUG - 2021-06-30 10:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 10:00:09 --> Input Class Initialized
INFO - 2021-06-30 10:00:09 --> Language Class Initialized
INFO - 2021-06-30 10:00:09 --> Loader Class Initialized
INFO - 2021-06-30 10:00:09 --> Helper loaded: html_helper
INFO - 2021-06-30 10:00:09 --> Helper loaded: url_helper
INFO - 2021-06-30 10:00:09 --> Helper loaded: form_helper
INFO - 2021-06-30 10:00:09 --> Database Driver Class Initialized
INFO - 2021-06-30 10:00:09 --> Form Validation Class Initialized
DEBUG - 2021-06-30 10:00:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 10:00:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 10:00:09 --> Encryption Class Initialized
INFO - 2021-06-30 10:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 10:00:09 --> Model "vendor_model" initialized
INFO - 2021-06-30 10:00:09 --> Model "coupon_model" initialized
INFO - 2021-06-30 10:00:09 --> Model "user_model" initialized
INFO - 2021-06-30 10:00:09 --> Model "role_model" initialized
INFO - 2021-06-30 10:00:09 --> Controller Class Initialized
INFO - 2021-06-30 10:00:09 --> Helper loaded: language_helper
INFO - 2021-06-30 10:00:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 10:00:09 --> Model "Customer_model" initialized
INFO - 2021-06-30 10:00:09 --> Final output sent to browser
DEBUG - 2021-06-30 10:00:09 --> Total execution time: 0.0614
INFO - 2021-06-30 10:00:11 --> Config Class Initialized
INFO - 2021-06-30 10:00:11 --> Hooks Class Initialized
DEBUG - 2021-06-30 10:00:11 --> UTF-8 Support Enabled
INFO - 2021-06-30 10:00:11 --> Utf8 Class Initialized
INFO - 2021-06-30 10:00:11 --> URI Class Initialized
INFO - 2021-06-30 10:00:11 --> Router Class Initialized
INFO - 2021-06-30 10:00:11 --> Output Class Initialized
INFO - 2021-06-30 10:00:11 --> Security Class Initialized
DEBUG - 2021-06-30 10:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 10:00:11 --> Input Class Initialized
INFO - 2021-06-30 10:00:11 --> Language Class Initialized
INFO - 2021-06-30 10:00:11 --> Loader Class Initialized
INFO - 2021-06-30 10:00:11 --> Helper loaded: html_helper
INFO - 2021-06-30 10:00:11 --> Helper loaded: url_helper
INFO - 2021-06-30 10:00:11 --> Helper loaded: form_helper
INFO - 2021-06-30 10:00:11 --> Database Driver Class Initialized
INFO - 2021-06-30 10:00:11 --> Form Validation Class Initialized
DEBUG - 2021-06-30 10:00:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 10:00:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 10:00:11 --> Encryption Class Initialized
INFO - 2021-06-30 10:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 10:00:11 --> Model "vendor_model" initialized
INFO - 2021-06-30 10:00:11 --> Model "coupon_model" initialized
INFO - 2021-06-30 10:00:11 --> Model "user_model" initialized
INFO - 2021-06-30 10:00:11 --> Model "role_model" initialized
INFO - 2021-06-30 10:00:11 --> Controller Class Initialized
INFO - 2021-06-30 10:00:11 --> Helper loaded: language_helper
INFO - 2021-06-30 10:00:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 10:00:11 --> Model "Customer_model" initialized
INFO - 2021-06-30 10:00:11 --> Model "Product_model" initialized
INFO - 2021-06-30 10:00:11 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 10:00:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 10:00:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 10:00:11 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 10:00:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 10:00:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 10:00:11 --> Final output sent to browser
DEBUG - 2021-06-30 10:00:11 --> Total execution time: 0.0767
INFO - 2021-06-30 10:00:19 --> Config Class Initialized
INFO - 2021-06-30 10:00:19 --> Hooks Class Initialized
DEBUG - 2021-06-30 10:00:19 --> UTF-8 Support Enabled
INFO - 2021-06-30 10:00:19 --> Utf8 Class Initialized
INFO - 2021-06-30 10:00:19 --> URI Class Initialized
INFO - 2021-06-30 10:00:19 --> Router Class Initialized
INFO - 2021-06-30 10:00:19 --> Output Class Initialized
INFO - 2021-06-30 10:00:19 --> Security Class Initialized
DEBUG - 2021-06-30 10:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 10:00:19 --> Input Class Initialized
INFO - 2021-06-30 10:00:19 --> Language Class Initialized
INFO - 2021-06-30 10:00:19 --> Loader Class Initialized
INFO - 2021-06-30 10:00:19 --> Helper loaded: html_helper
INFO - 2021-06-30 10:00:19 --> Helper loaded: url_helper
INFO - 2021-06-30 10:00:19 --> Helper loaded: form_helper
INFO - 2021-06-30 10:00:19 --> Database Driver Class Initialized
INFO - 2021-06-30 10:00:19 --> Form Validation Class Initialized
DEBUG - 2021-06-30 10:00:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 10:00:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 10:00:19 --> Encryption Class Initialized
INFO - 2021-06-30 10:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 10:00:20 --> Model "vendor_model" initialized
INFO - 2021-06-30 10:00:20 --> Model "coupon_model" initialized
INFO - 2021-06-30 10:00:20 --> Model "user_model" initialized
INFO - 2021-06-30 10:00:20 --> Model "role_model" initialized
INFO - 2021-06-30 10:00:20 --> Controller Class Initialized
INFO - 2021-06-30 10:00:20 --> Helper loaded: language_helper
INFO - 2021-06-30 10:00:20 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 10:00:20 --> Model "Customer_model" initialized
INFO - 2021-06-30 10:00:20 --> Model "Product_model" initialized
INFO - 2021-06-30 10:00:20 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 10:00:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 10:00:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 10:00:20 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 10:00:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 10:00:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 10:00:20 --> Final output sent to browser
DEBUG - 2021-06-30 10:00:20 --> Total execution time: 0.0747
INFO - 2021-06-30 10:26:50 --> Config Class Initialized
INFO - 2021-06-30 10:26:50 --> Hooks Class Initialized
DEBUG - 2021-06-30 10:26:50 --> UTF-8 Support Enabled
INFO - 2021-06-30 10:26:50 --> Utf8 Class Initialized
INFO - 2021-06-30 10:26:50 --> URI Class Initialized
INFO - 2021-06-30 10:26:50 --> Router Class Initialized
INFO - 2021-06-30 10:26:50 --> Output Class Initialized
INFO - 2021-06-30 10:26:50 --> Security Class Initialized
DEBUG - 2021-06-30 10:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 10:26:50 --> Input Class Initialized
INFO - 2021-06-30 10:26:50 --> Language Class Initialized
INFO - 2021-06-30 10:26:50 --> Loader Class Initialized
INFO - 2021-06-30 10:26:50 --> Helper loaded: html_helper
INFO - 2021-06-30 10:26:50 --> Helper loaded: url_helper
INFO - 2021-06-30 10:26:50 --> Helper loaded: form_helper
INFO - 2021-06-30 10:26:50 --> Database Driver Class Initialized
INFO - 2021-06-30 10:26:50 --> Form Validation Class Initialized
DEBUG - 2021-06-30 10:26:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 10:26:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 10:26:50 --> Encryption Class Initialized
INFO - 2021-06-30 10:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 10:26:50 --> Model "vendor_model" initialized
INFO - 2021-06-30 10:26:50 --> Model "coupon_model" initialized
INFO - 2021-06-30 10:26:50 --> Model "user_model" initialized
INFO - 2021-06-30 10:26:50 --> Model "role_model" initialized
INFO - 2021-06-30 10:26:50 --> Controller Class Initialized
INFO - 2021-06-30 10:26:50 --> Helper loaded: language_helper
INFO - 2021-06-30 10:26:50 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 10:26:50 --> Model "Customer_model" initialized
INFO - 2021-06-30 10:26:50 --> Model "Product_model" initialized
INFO - 2021-06-30 10:26:50 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 10:26:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 10:26:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 10:26:50 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 10:26:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 10:26:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 10:26:50 --> Final output sent to browser
DEBUG - 2021-06-30 10:26:50 --> Total execution time: 0.0857
INFO - 2021-06-30 10:27:09 --> Config Class Initialized
INFO - 2021-06-30 10:27:09 --> Hooks Class Initialized
DEBUG - 2021-06-30 10:27:09 --> UTF-8 Support Enabled
INFO - 2021-06-30 10:27:09 --> Utf8 Class Initialized
INFO - 2021-06-30 10:27:09 --> URI Class Initialized
INFO - 2021-06-30 10:27:09 --> Router Class Initialized
INFO - 2021-06-30 10:27:09 --> Output Class Initialized
INFO - 2021-06-30 10:27:09 --> Security Class Initialized
DEBUG - 2021-06-30 10:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 10:27:09 --> Input Class Initialized
INFO - 2021-06-30 10:27:09 --> Language Class Initialized
INFO - 2021-06-30 10:27:09 --> Loader Class Initialized
INFO - 2021-06-30 10:27:09 --> Helper loaded: html_helper
INFO - 2021-06-30 10:27:09 --> Helper loaded: url_helper
INFO - 2021-06-30 10:27:09 --> Helper loaded: form_helper
INFO - 2021-06-30 10:27:09 --> Database Driver Class Initialized
INFO - 2021-06-30 10:27:09 --> Form Validation Class Initialized
DEBUG - 2021-06-30 10:27:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 10:27:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 10:27:09 --> Encryption Class Initialized
INFO - 2021-06-30 10:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 10:27:09 --> Model "vendor_model" initialized
INFO - 2021-06-30 10:27:09 --> Model "coupon_model" initialized
INFO - 2021-06-30 10:27:09 --> Model "user_model" initialized
INFO - 2021-06-30 10:27:09 --> Model "role_model" initialized
INFO - 2021-06-30 10:27:09 --> Controller Class Initialized
INFO - 2021-06-30 10:27:09 --> Helper loaded: language_helper
INFO - 2021-06-30 10:27:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 10:27:09 --> Model "Customer_model" initialized
INFO - 2021-06-30 10:27:09 --> Final output sent to browser
DEBUG - 2021-06-30 10:27:09 --> Total execution time: 0.0779
INFO - 2021-06-30 10:27:13 --> Config Class Initialized
INFO - 2021-06-30 10:27:13 --> Hooks Class Initialized
DEBUG - 2021-06-30 10:27:13 --> UTF-8 Support Enabled
INFO - 2021-06-30 10:27:13 --> Utf8 Class Initialized
INFO - 2021-06-30 10:27:13 --> URI Class Initialized
INFO - 2021-06-30 10:27:13 --> Router Class Initialized
INFO - 2021-06-30 10:27:13 --> Output Class Initialized
INFO - 2021-06-30 10:27:13 --> Security Class Initialized
DEBUG - 2021-06-30 10:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 10:27:13 --> Input Class Initialized
INFO - 2021-06-30 10:27:13 --> Language Class Initialized
INFO - 2021-06-30 10:27:13 --> Loader Class Initialized
INFO - 2021-06-30 10:27:13 --> Helper loaded: html_helper
INFO - 2021-06-30 10:27:13 --> Helper loaded: url_helper
INFO - 2021-06-30 10:27:13 --> Helper loaded: form_helper
INFO - 2021-06-30 10:27:13 --> Database Driver Class Initialized
INFO - 2021-06-30 10:27:13 --> Form Validation Class Initialized
DEBUG - 2021-06-30 10:27:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 10:27:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 10:27:13 --> Encryption Class Initialized
INFO - 2021-06-30 10:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 10:27:13 --> Model "vendor_model" initialized
INFO - 2021-06-30 10:27:13 --> Model "coupon_model" initialized
INFO - 2021-06-30 10:27:13 --> Model "user_model" initialized
INFO - 2021-06-30 10:27:13 --> Model "role_model" initialized
INFO - 2021-06-30 10:27:13 --> Controller Class Initialized
INFO - 2021-06-30 10:27:13 --> Helper loaded: language_helper
INFO - 2021-06-30 10:27:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 10:27:13 --> Model "Customer_model" initialized
INFO - 2021-06-30 10:27:13 --> Final output sent to browser
DEBUG - 2021-06-30 10:27:13 --> Total execution time: 0.0634
INFO - 2021-06-30 10:27:18 --> Config Class Initialized
INFO - 2021-06-30 10:27:18 --> Hooks Class Initialized
DEBUG - 2021-06-30 10:27:18 --> UTF-8 Support Enabled
INFO - 2021-06-30 10:27:18 --> Utf8 Class Initialized
INFO - 2021-06-30 10:27:18 --> URI Class Initialized
INFO - 2021-06-30 10:27:18 --> Router Class Initialized
INFO - 2021-06-30 10:27:18 --> Output Class Initialized
INFO - 2021-06-30 10:27:18 --> Security Class Initialized
DEBUG - 2021-06-30 10:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 10:27:18 --> Input Class Initialized
INFO - 2021-06-30 10:27:18 --> Language Class Initialized
INFO - 2021-06-30 10:27:18 --> Loader Class Initialized
INFO - 2021-06-30 10:27:18 --> Helper loaded: html_helper
INFO - 2021-06-30 10:27:18 --> Helper loaded: url_helper
INFO - 2021-06-30 10:27:18 --> Helper loaded: form_helper
INFO - 2021-06-30 10:27:18 --> Database Driver Class Initialized
INFO - 2021-06-30 10:27:18 --> Form Validation Class Initialized
DEBUG - 2021-06-30 10:27:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 10:27:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 10:27:18 --> Encryption Class Initialized
INFO - 2021-06-30 10:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 10:27:18 --> Model "vendor_model" initialized
INFO - 2021-06-30 10:27:18 --> Model "coupon_model" initialized
INFO - 2021-06-30 10:27:18 --> Model "user_model" initialized
INFO - 2021-06-30 10:27:18 --> Model "role_model" initialized
INFO - 2021-06-30 10:27:18 --> Controller Class Initialized
INFO - 2021-06-30 10:27:18 --> Helper loaded: language_helper
INFO - 2021-06-30 10:27:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 10:27:18 --> Model "Customer_model" initialized
INFO - 2021-06-30 10:27:18 --> Final output sent to browser
DEBUG - 2021-06-30 10:27:18 --> Total execution time: 0.0630
INFO - 2021-06-30 10:27:22 --> Config Class Initialized
INFO - 2021-06-30 10:27:22 --> Hooks Class Initialized
DEBUG - 2021-06-30 10:27:22 --> UTF-8 Support Enabled
INFO - 2021-06-30 10:27:22 --> Utf8 Class Initialized
INFO - 2021-06-30 10:27:22 --> URI Class Initialized
INFO - 2021-06-30 10:27:22 --> Router Class Initialized
INFO - 2021-06-30 10:27:22 --> Output Class Initialized
INFO - 2021-06-30 10:27:22 --> Security Class Initialized
DEBUG - 2021-06-30 10:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 10:27:22 --> Input Class Initialized
INFO - 2021-06-30 10:27:22 --> Language Class Initialized
INFO - 2021-06-30 10:27:22 --> Loader Class Initialized
INFO - 2021-06-30 10:27:22 --> Helper loaded: html_helper
INFO - 2021-06-30 10:27:22 --> Helper loaded: url_helper
INFO - 2021-06-30 10:27:22 --> Helper loaded: form_helper
INFO - 2021-06-30 10:27:22 --> Database Driver Class Initialized
INFO - 2021-06-30 10:27:22 --> Form Validation Class Initialized
DEBUG - 2021-06-30 10:27:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 10:27:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 10:27:22 --> Encryption Class Initialized
INFO - 2021-06-30 10:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 10:27:22 --> Model "vendor_model" initialized
INFO - 2021-06-30 10:27:22 --> Model "coupon_model" initialized
INFO - 2021-06-30 10:27:22 --> Model "user_model" initialized
INFO - 2021-06-30 10:27:22 --> Model "role_model" initialized
INFO - 2021-06-30 10:27:22 --> Controller Class Initialized
INFO - 2021-06-30 10:27:22 --> Helper loaded: language_helper
INFO - 2021-06-30 10:27:22 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 10:27:22 --> Model "Customer_model" initialized
INFO - 2021-06-30 10:27:22 --> Final output sent to browser
DEBUG - 2021-06-30 10:27:22 --> Total execution time: 0.0666
INFO - 2021-06-30 10:28:07 --> Config Class Initialized
INFO - 2021-06-30 10:28:07 --> Hooks Class Initialized
DEBUG - 2021-06-30 10:28:07 --> UTF-8 Support Enabled
INFO - 2021-06-30 10:28:07 --> Utf8 Class Initialized
INFO - 2021-06-30 10:28:07 --> URI Class Initialized
INFO - 2021-06-30 10:28:07 --> Router Class Initialized
INFO - 2021-06-30 10:28:07 --> Output Class Initialized
INFO - 2021-06-30 10:28:07 --> Security Class Initialized
DEBUG - 2021-06-30 10:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 10:28:07 --> Input Class Initialized
INFO - 2021-06-30 10:28:07 --> Language Class Initialized
INFO - 2021-06-30 10:28:07 --> Loader Class Initialized
INFO - 2021-06-30 10:28:07 --> Helper loaded: html_helper
INFO - 2021-06-30 10:28:07 --> Helper loaded: url_helper
INFO - 2021-06-30 10:28:07 --> Helper loaded: form_helper
INFO - 2021-06-30 10:28:07 --> Database Driver Class Initialized
INFO - 2021-06-30 10:28:07 --> Form Validation Class Initialized
DEBUG - 2021-06-30 10:28:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 10:28:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 10:28:07 --> Encryption Class Initialized
INFO - 2021-06-30 10:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 10:28:07 --> Model "vendor_model" initialized
INFO - 2021-06-30 10:28:07 --> Model "coupon_model" initialized
INFO - 2021-06-30 10:28:07 --> Model "user_model" initialized
INFO - 2021-06-30 10:28:07 --> Model "role_model" initialized
INFO - 2021-06-30 10:28:07 --> Controller Class Initialized
INFO - 2021-06-30 10:28:07 --> Helper loaded: language_helper
INFO - 2021-06-30 10:28:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 10:28:07 --> Model "Product_model" initialized
INFO - 2021-06-30 10:28:07 --> Final output sent to browser
DEBUG - 2021-06-30 10:28:07 --> Total execution time: 0.0617
INFO - 2021-06-30 10:28:28 --> Config Class Initialized
INFO - 2021-06-30 10:28:28 --> Hooks Class Initialized
DEBUG - 2021-06-30 10:28:28 --> UTF-8 Support Enabled
INFO - 2021-06-30 10:28:28 --> Utf8 Class Initialized
INFO - 2021-06-30 10:28:28 --> URI Class Initialized
INFO - 2021-06-30 10:28:28 --> Router Class Initialized
INFO - 2021-06-30 10:28:28 --> Output Class Initialized
INFO - 2021-06-30 10:28:28 --> Security Class Initialized
DEBUG - 2021-06-30 10:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 10:28:28 --> Input Class Initialized
INFO - 2021-06-30 10:28:28 --> Language Class Initialized
INFO - 2021-06-30 10:28:28 --> Loader Class Initialized
INFO - 2021-06-30 10:28:28 --> Helper loaded: html_helper
INFO - 2021-06-30 10:28:28 --> Helper loaded: url_helper
INFO - 2021-06-30 10:28:28 --> Helper loaded: form_helper
INFO - 2021-06-30 10:28:28 --> Database Driver Class Initialized
INFO - 2021-06-30 10:28:28 --> Form Validation Class Initialized
DEBUG - 2021-06-30 10:28:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 10:28:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 10:28:28 --> Encryption Class Initialized
INFO - 2021-06-30 10:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 10:28:28 --> Model "vendor_model" initialized
INFO - 2021-06-30 10:28:28 --> Model "coupon_model" initialized
INFO - 2021-06-30 10:28:28 --> Model "user_model" initialized
INFO - 2021-06-30 10:28:28 --> Model "role_model" initialized
INFO - 2021-06-30 10:28:28 --> Controller Class Initialized
INFO - 2021-06-30 10:28:28 --> Helper loaded: language_helper
INFO - 2021-06-30 10:28:28 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 10:28:28 --> Model "Customer_model" initialized
INFO - 2021-06-30 10:28:28 --> Model "Product_model" initialized
INFO - 2021-06-30 10:28:28 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 10:28:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 10:28:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 10:28:28 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 10:28:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 10:28:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 10:28:28 --> Final output sent to browser
DEBUG - 2021-06-30 10:28:28 --> Total execution time: 0.0705
INFO - 2021-06-30 10:28:37 --> Config Class Initialized
INFO - 2021-06-30 10:28:37 --> Hooks Class Initialized
DEBUG - 2021-06-30 10:28:37 --> UTF-8 Support Enabled
INFO - 2021-06-30 10:28:37 --> Utf8 Class Initialized
INFO - 2021-06-30 10:28:37 --> URI Class Initialized
INFO - 2021-06-30 10:28:37 --> Router Class Initialized
INFO - 2021-06-30 10:28:37 --> Output Class Initialized
INFO - 2021-06-30 10:28:37 --> Security Class Initialized
DEBUG - 2021-06-30 10:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 10:28:37 --> Input Class Initialized
INFO - 2021-06-30 10:28:37 --> Language Class Initialized
INFO - 2021-06-30 10:28:37 --> Loader Class Initialized
INFO - 2021-06-30 10:28:37 --> Helper loaded: html_helper
INFO - 2021-06-30 10:28:37 --> Helper loaded: url_helper
INFO - 2021-06-30 10:28:37 --> Helper loaded: form_helper
INFO - 2021-06-30 10:28:37 --> Database Driver Class Initialized
INFO - 2021-06-30 10:28:37 --> Form Validation Class Initialized
DEBUG - 2021-06-30 10:28:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 10:28:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 10:28:37 --> Encryption Class Initialized
INFO - 2021-06-30 10:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 10:28:37 --> Model "vendor_model" initialized
INFO - 2021-06-30 10:28:37 --> Model "coupon_model" initialized
INFO - 2021-06-30 10:28:37 --> Model "user_model" initialized
INFO - 2021-06-30 10:28:37 --> Model "role_model" initialized
INFO - 2021-06-30 10:28:37 --> Controller Class Initialized
INFO - 2021-06-30 10:28:37 --> Helper loaded: language_helper
INFO - 2021-06-30 10:28:37 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 10:28:37 --> Model "Customer_model" initialized
INFO - 2021-06-30 10:28:37 --> Model "Product_model" initialized
INFO - 2021-06-30 10:28:37 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 10:28:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 10:28:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 10:28:37 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 10:28:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 10:28:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 10:28:37 --> Final output sent to browser
DEBUG - 2021-06-30 10:28:37 --> Total execution time: 0.0739
INFO - 2021-06-30 10:31:06 --> Config Class Initialized
INFO - 2021-06-30 10:31:06 --> Hooks Class Initialized
DEBUG - 2021-06-30 10:31:06 --> UTF-8 Support Enabled
INFO - 2021-06-30 10:31:06 --> Utf8 Class Initialized
INFO - 2021-06-30 10:31:06 --> URI Class Initialized
INFO - 2021-06-30 10:31:06 --> Router Class Initialized
INFO - 2021-06-30 10:31:06 --> Output Class Initialized
INFO - 2021-06-30 10:31:06 --> Security Class Initialized
DEBUG - 2021-06-30 10:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 10:31:06 --> Input Class Initialized
INFO - 2021-06-30 10:31:06 --> Language Class Initialized
INFO - 2021-06-30 10:31:06 --> Loader Class Initialized
INFO - 2021-06-30 10:31:06 --> Helper loaded: html_helper
INFO - 2021-06-30 10:31:06 --> Helper loaded: url_helper
INFO - 2021-06-30 10:31:06 --> Helper loaded: form_helper
INFO - 2021-06-30 10:31:06 --> Database Driver Class Initialized
INFO - 2021-06-30 10:31:06 --> Form Validation Class Initialized
DEBUG - 2021-06-30 10:31:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 10:31:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 10:31:06 --> Encryption Class Initialized
INFO - 2021-06-30 10:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 10:31:06 --> Model "vendor_model" initialized
INFO - 2021-06-30 10:31:06 --> Model "coupon_model" initialized
INFO - 2021-06-30 10:31:06 --> Model "user_model" initialized
INFO - 2021-06-30 10:31:06 --> Model "role_model" initialized
INFO - 2021-06-30 10:31:06 --> Controller Class Initialized
INFO - 2021-06-30 10:31:06 --> Helper loaded: language_helper
INFO - 2021-06-30 10:31:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 10:31:06 --> Model "Customer_model" initialized
INFO - 2021-06-30 10:31:06 --> Model "Product_model" initialized
INFO - 2021-06-30 10:31:06 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 10:31:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 10:31:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 10:31:06 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 10:31:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 10:31:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 10:31:06 --> Final output sent to browser
DEBUG - 2021-06-30 10:31:06 --> Total execution time: 0.1160
INFO - 2021-06-30 10:31:12 --> Config Class Initialized
INFO - 2021-06-30 10:31:12 --> Hooks Class Initialized
DEBUG - 2021-06-30 10:31:12 --> UTF-8 Support Enabled
INFO - 2021-06-30 10:31:12 --> Utf8 Class Initialized
INFO - 2021-06-30 10:31:12 --> URI Class Initialized
INFO - 2021-06-30 10:31:12 --> Router Class Initialized
INFO - 2021-06-30 10:31:12 --> Output Class Initialized
INFO - 2021-06-30 10:31:12 --> Security Class Initialized
DEBUG - 2021-06-30 10:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 10:31:12 --> Input Class Initialized
INFO - 2021-06-30 10:31:12 --> Language Class Initialized
INFO - 2021-06-30 10:31:12 --> Loader Class Initialized
INFO - 2021-06-30 10:31:12 --> Helper loaded: html_helper
INFO - 2021-06-30 10:31:12 --> Helper loaded: url_helper
INFO - 2021-06-30 10:31:12 --> Helper loaded: form_helper
INFO - 2021-06-30 10:31:12 --> Database Driver Class Initialized
INFO - 2021-06-30 10:31:12 --> Form Validation Class Initialized
DEBUG - 2021-06-30 10:31:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 10:31:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 10:31:12 --> Encryption Class Initialized
INFO - 2021-06-30 10:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 10:31:12 --> Model "vendor_model" initialized
INFO - 2021-06-30 10:31:12 --> Model "coupon_model" initialized
INFO - 2021-06-30 10:31:12 --> Model "user_model" initialized
INFO - 2021-06-30 10:31:12 --> Model "role_model" initialized
INFO - 2021-06-30 10:31:12 --> Controller Class Initialized
INFO - 2021-06-30 10:31:12 --> Helper loaded: language_helper
INFO - 2021-06-30 10:31:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 10:31:12 --> Model "Customer_model" initialized
INFO - 2021-06-30 10:31:12 --> Final output sent to browser
DEBUG - 2021-06-30 10:31:12 --> Total execution time: 0.0650
INFO - 2021-06-30 10:52:13 --> Config Class Initialized
INFO - 2021-06-30 10:52:13 --> Hooks Class Initialized
DEBUG - 2021-06-30 10:52:13 --> UTF-8 Support Enabled
INFO - 2021-06-30 10:52:13 --> Utf8 Class Initialized
INFO - 2021-06-30 10:52:13 --> URI Class Initialized
INFO - 2021-06-30 10:52:13 --> Router Class Initialized
INFO - 2021-06-30 10:52:13 --> Output Class Initialized
INFO - 2021-06-30 10:52:13 --> Security Class Initialized
DEBUG - 2021-06-30 10:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 10:52:13 --> Input Class Initialized
INFO - 2021-06-30 10:52:13 --> Language Class Initialized
INFO - 2021-06-30 10:52:13 --> Loader Class Initialized
INFO - 2021-06-30 10:52:13 --> Helper loaded: html_helper
INFO - 2021-06-30 10:52:13 --> Helper loaded: url_helper
INFO - 2021-06-30 10:52:13 --> Helper loaded: form_helper
INFO - 2021-06-30 10:52:13 --> Database Driver Class Initialized
INFO - 2021-06-30 10:52:13 --> Form Validation Class Initialized
DEBUG - 2021-06-30 10:52:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 10:52:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 10:52:13 --> Encryption Class Initialized
INFO - 2021-06-30 10:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 10:52:13 --> Model "vendor_model" initialized
INFO - 2021-06-30 10:52:13 --> Model "coupon_model" initialized
INFO - 2021-06-30 10:52:13 --> Model "user_model" initialized
INFO - 2021-06-30 10:52:13 --> Model "role_model" initialized
INFO - 2021-06-30 10:52:13 --> Controller Class Initialized
INFO - 2021-06-30 10:52:13 --> Helper loaded: language_helper
INFO - 2021-06-30 10:52:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 10:52:13 --> Model "Product_model" initialized
INFO - 2021-06-30 10:52:13 --> Final output sent to browser
DEBUG - 2021-06-30 10:52:13 --> Total execution time: 0.0711
INFO - 2021-06-30 10:52:27 --> Config Class Initialized
INFO - 2021-06-30 10:52:27 --> Hooks Class Initialized
DEBUG - 2021-06-30 10:52:27 --> UTF-8 Support Enabled
INFO - 2021-06-30 10:52:27 --> Utf8 Class Initialized
INFO - 2021-06-30 10:52:27 --> URI Class Initialized
INFO - 2021-06-30 10:52:27 --> Router Class Initialized
INFO - 2021-06-30 10:52:27 --> Output Class Initialized
INFO - 2021-06-30 10:52:27 --> Security Class Initialized
DEBUG - 2021-06-30 10:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 10:52:27 --> Input Class Initialized
INFO - 2021-06-30 10:52:27 --> Language Class Initialized
INFO - 2021-06-30 10:52:27 --> Loader Class Initialized
INFO - 2021-06-30 10:52:27 --> Helper loaded: html_helper
INFO - 2021-06-30 10:52:27 --> Helper loaded: url_helper
INFO - 2021-06-30 10:52:27 --> Helper loaded: form_helper
INFO - 2021-06-30 10:52:27 --> Database Driver Class Initialized
INFO - 2021-06-30 10:52:27 --> Form Validation Class Initialized
DEBUG - 2021-06-30 10:52:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 10:52:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 10:52:27 --> Encryption Class Initialized
INFO - 2021-06-30 10:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 10:52:27 --> Model "vendor_model" initialized
INFO - 2021-06-30 10:52:27 --> Model "coupon_model" initialized
INFO - 2021-06-30 10:52:27 --> Model "user_model" initialized
INFO - 2021-06-30 10:52:27 --> Model "role_model" initialized
INFO - 2021-06-30 10:52:27 --> Controller Class Initialized
INFO - 2021-06-30 10:52:27 --> Helper loaded: language_helper
INFO - 2021-06-30 10:52:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 10:52:27 --> Model "Customer_model" initialized
INFO - 2021-06-30 10:52:27 --> Model "Product_model" initialized
INFO - 2021-06-30 10:52:27 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 10:52:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 10:52:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 10:52:27 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 10:52:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 10:52:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 10:52:27 --> Final output sent to browser
DEBUG - 2021-06-30 10:52:27 --> Total execution time: 0.0776
INFO - 2021-06-30 10:56:17 --> Config Class Initialized
INFO - 2021-06-30 10:56:17 --> Hooks Class Initialized
DEBUG - 2021-06-30 10:56:17 --> UTF-8 Support Enabled
INFO - 2021-06-30 10:56:17 --> Utf8 Class Initialized
INFO - 2021-06-30 10:56:17 --> URI Class Initialized
INFO - 2021-06-30 10:56:17 --> Router Class Initialized
INFO - 2021-06-30 10:56:17 --> Output Class Initialized
INFO - 2021-06-30 10:56:17 --> Security Class Initialized
DEBUG - 2021-06-30 10:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 10:56:17 --> Input Class Initialized
INFO - 2021-06-30 10:56:17 --> Language Class Initialized
INFO - 2021-06-30 10:56:17 --> Loader Class Initialized
INFO - 2021-06-30 10:56:17 --> Helper loaded: html_helper
INFO - 2021-06-30 10:56:17 --> Helper loaded: url_helper
INFO - 2021-06-30 10:56:17 --> Helper loaded: form_helper
INFO - 2021-06-30 10:56:17 --> Database Driver Class Initialized
INFO - 2021-06-30 10:56:17 --> Form Validation Class Initialized
DEBUG - 2021-06-30 10:56:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 10:56:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 10:56:17 --> Encryption Class Initialized
INFO - 2021-06-30 10:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 10:56:17 --> Model "vendor_model" initialized
INFO - 2021-06-30 10:56:17 --> Model "coupon_model" initialized
INFO - 2021-06-30 10:56:17 --> Model "user_model" initialized
INFO - 2021-06-30 10:56:17 --> Model "role_model" initialized
INFO - 2021-06-30 10:56:17 --> Controller Class Initialized
INFO - 2021-06-30 10:56:17 --> Helper loaded: language_helper
INFO - 2021-06-30 10:56:17 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 10:56:17 --> Model "Customer_model" initialized
INFO - 2021-06-30 10:56:17 --> Model "Product_model" initialized
INFO - 2021-06-30 10:56:17 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 10:56:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 10:56:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 10:56:17 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 10:56:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 10:56:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 10:56:17 --> Final output sent to browser
DEBUG - 2021-06-30 10:56:17 --> Total execution time: 0.0715
INFO - 2021-06-30 10:56:23 --> Config Class Initialized
INFO - 2021-06-30 10:56:23 --> Hooks Class Initialized
DEBUG - 2021-06-30 10:56:23 --> UTF-8 Support Enabled
INFO - 2021-06-30 10:56:23 --> Utf8 Class Initialized
INFO - 2021-06-30 10:56:23 --> URI Class Initialized
INFO - 2021-06-30 10:56:23 --> Router Class Initialized
INFO - 2021-06-30 10:56:23 --> Output Class Initialized
INFO - 2021-06-30 10:56:23 --> Security Class Initialized
DEBUG - 2021-06-30 10:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 10:56:23 --> Input Class Initialized
INFO - 2021-06-30 10:56:23 --> Language Class Initialized
INFO - 2021-06-30 10:56:23 --> Loader Class Initialized
INFO - 2021-06-30 10:56:23 --> Helper loaded: html_helper
INFO - 2021-06-30 10:56:23 --> Helper loaded: url_helper
INFO - 2021-06-30 10:56:23 --> Helper loaded: form_helper
INFO - 2021-06-30 10:56:23 --> Database Driver Class Initialized
INFO - 2021-06-30 10:56:23 --> Form Validation Class Initialized
DEBUG - 2021-06-30 10:56:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 10:56:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 10:56:23 --> Encryption Class Initialized
INFO - 2021-06-30 10:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 10:56:23 --> Model "vendor_model" initialized
INFO - 2021-06-30 10:56:23 --> Model "coupon_model" initialized
INFO - 2021-06-30 10:56:23 --> Model "user_model" initialized
INFO - 2021-06-30 10:56:23 --> Model "role_model" initialized
INFO - 2021-06-30 10:56:23 --> Controller Class Initialized
INFO - 2021-06-30 10:56:23 --> Helper loaded: language_helper
INFO - 2021-06-30 10:56:23 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 10:56:23 --> Model "Product_model" initialized
INFO - 2021-06-30 10:56:23 --> Final output sent to browser
DEBUG - 2021-06-30 10:56:23 --> Total execution time: 0.0605
INFO - 2021-06-30 10:57:49 --> Config Class Initialized
INFO - 2021-06-30 10:57:49 --> Hooks Class Initialized
DEBUG - 2021-06-30 10:57:49 --> UTF-8 Support Enabled
INFO - 2021-06-30 10:57:49 --> Utf8 Class Initialized
INFO - 2021-06-30 10:57:49 --> URI Class Initialized
INFO - 2021-06-30 10:57:49 --> Router Class Initialized
INFO - 2021-06-30 10:57:49 --> Output Class Initialized
INFO - 2021-06-30 10:57:49 --> Security Class Initialized
DEBUG - 2021-06-30 10:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 10:57:49 --> Input Class Initialized
INFO - 2021-06-30 10:57:49 --> Language Class Initialized
INFO - 2021-06-30 10:57:49 --> Loader Class Initialized
INFO - 2021-06-30 10:57:49 --> Helper loaded: html_helper
INFO - 2021-06-30 10:57:49 --> Helper loaded: url_helper
INFO - 2021-06-30 10:57:49 --> Helper loaded: form_helper
INFO - 2021-06-30 10:57:49 --> Database Driver Class Initialized
INFO - 2021-06-30 10:57:49 --> Form Validation Class Initialized
DEBUG - 2021-06-30 10:57:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 10:57:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 10:57:49 --> Encryption Class Initialized
INFO - 2021-06-30 10:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 10:57:49 --> Model "vendor_model" initialized
INFO - 2021-06-30 10:57:49 --> Model "coupon_model" initialized
INFO - 2021-06-30 10:57:49 --> Model "user_model" initialized
INFO - 2021-06-30 10:57:49 --> Model "role_model" initialized
INFO - 2021-06-30 10:57:49 --> Controller Class Initialized
INFO - 2021-06-30 10:57:49 --> Helper loaded: language_helper
INFO - 2021-06-30 10:57:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 10:57:49 --> Model "Customer_model" initialized
INFO - 2021-06-30 10:57:49 --> Model "Product_model" initialized
INFO - 2021-06-30 10:57:49 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 10:57:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 10:57:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 10:57:49 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 10:57:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 10:57:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 10:57:49 --> Final output sent to browser
DEBUG - 2021-06-30 10:57:49 --> Total execution time: 0.1362
INFO - 2021-06-30 10:59:19 --> Config Class Initialized
INFO - 2021-06-30 10:59:19 --> Hooks Class Initialized
DEBUG - 2021-06-30 10:59:19 --> UTF-8 Support Enabled
INFO - 2021-06-30 10:59:19 --> Utf8 Class Initialized
INFO - 2021-06-30 10:59:19 --> URI Class Initialized
INFO - 2021-06-30 10:59:19 --> Router Class Initialized
INFO - 2021-06-30 10:59:19 --> Output Class Initialized
INFO - 2021-06-30 10:59:19 --> Security Class Initialized
DEBUG - 2021-06-30 10:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 10:59:19 --> Input Class Initialized
INFO - 2021-06-30 10:59:19 --> Language Class Initialized
INFO - 2021-06-30 10:59:19 --> Loader Class Initialized
INFO - 2021-06-30 10:59:19 --> Helper loaded: html_helper
INFO - 2021-06-30 10:59:19 --> Helper loaded: url_helper
INFO - 2021-06-30 10:59:19 --> Helper loaded: form_helper
INFO - 2021-06-30 10:59:19 --> Database Driver Class Initialized
INFO - 2021-06-30 10:59:19 --> Form Validation Class Initialized
DEBUG - 2021-06-30 10:59:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 10:59:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 10:59:19 --> Encryption Class Initialized
INFO - 2021-06-30 10:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 10:59:19 --> Model "vendor_model" initialized
INFO - 2021-06-30 10:59:19 --> Model "coupon_model" initialized
INFO - 2021-06-30 10:59:19 --> Model "user_model" initialized
INFO - 2021-06-30 10:59:19 --> Model "role_model" initialized
INFO - 2021-06-30 10:59:19 --> Controller Class Initialized
INFO - 2021-06-30 10:59:19 --> Helper loaded: language_helper
INFO - 2021-06-30 10:59:19 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 10:59:19 --> Model "Product_model" initialized
INFO - 2021-06-30 10:59:19 --> Final output sent to browser
DEBUG - 2021-06-30 10:59:19 --> Total execution time: 0.0767
INFO - 2021-06-30 11:04:10 --> Config Class Initialized
INFO - 2021-06-30 11:04:10 --> Hooks Class Initialized
DEBUG - 2021-06-30 11:04:10 --> UTF-8 Support Enabled
INFO - 2021-06-30 11:04:10 --> Utf8 Class Initialized
INFO - 2021-06-30 11:04:10 --> URI Class Initialized
INFO - 2021-06-30 11:04:10 --> Router Class Initialized
INFO - 2021-06-30 11:04:10 --> Output Class Initialized
INFO - 2021-06-30 11:04:10 --> Security Class Initialized
DEBUG - 2021-06-30 11:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 11:04:10 --> Input Class Initialized
INFO - 2021-06-30 11:04:10 --> Language Class Initialized
INFO - 2021-06-30 11:04:10 --> Loader Class Initialized
INFO - 2021-06-30 11:04:10 --> Helper loaded: html_helper
INFO - 2021-06-30 11:04:10 --> Helper loaded: url_helper
INFO - 2021-06-30 11:04:10 --> Helper loaded: form_helper
INFO - 2021-06-30 11:04:10 --> Database Driver Class Initialized
INFO - 2021-06-30 11:04:10 --> Form Validation Class Initialized
DEBUG - 2021-06-30 11:04:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 11:04:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 11:04:10 --> Encryption Class Initialized
INFO - 2021-06-30 11:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 11:04:10 --> Model "vendor_model" initialized
INFO - 2021-06-30 11:04:10 --> Model "coupon_model" initialized
INFO - 2021-06-30 11:04:10 --> Model "user_model" initialized
INFO - 2021-06-30 11:04:10 --> Model "role_model" initialized
INFO - 2021-06-30 11:04:10 --> Controller Class Initialized
INFO - 2021-06-30 11:04:10 --> Helper loaded: language_helper
INFO - 2021-06-30 11:04:10 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 11:04:10 --> Model "Customer_model" initialized
INFO - 2021-06-30 11:04:10 --> Model "Product_model" initialized
INFO - 2021-06-30 11:04:10 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 11:04:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 11:04:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 11:04:10 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 11:04:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 11:04:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 11:04:10 --> Final output sent to browser
DEBUG - 2021-06-30 11:04:10 --> Total execution time: 0.1284
INFO - 2021-06-30 11:04:15 --> Config Class Initialized
INFO - 2021-06-30 11:04:15 --> Hooks Class Initialized
DEBUG - 2021-06-30 11:04:15 --> UTF-8 Support Enabled
INFO - 2021-06-30 11:04:15 --> Utf8 Class Initialized
INFO - 2021-06-30 11:04:15 --> URI Class Initialized
INFO - 2021-06-30 11:04:15 --> Router Class Initialized
INFO - 2021-06-30 11:04:15 --> Output Class Initialized
INFO - 2021-06-30 11:04:15 --> Security Class Initialized
DEBUG - 2021-06-30 11:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 11:04:15 --> Input Class Initialized
INFO - 2021-06-30 11:04:15 --> Language Class Initialized
INFO - 2021-06-30 11:04:15 --> Loader Class Initialized
INFO - 2021-06-30 11:04:15 --> Helper loaded: html_helper
INFO - 2021-06-30 11:04:15 --> Helper loaded: url_helper
INFO - 2021-06-30 11:04:15 --> Helper loaded: form_helper
INFO - 2021-06-30 11:04:15 --> Database Driver Class Initialized
INFO - 2021-06-30 11:04:15 --> Form Validation Class Initialized
DEBUG - 2021-06-30 11:04:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 11:04:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 11:04:15 --> Encryption Class Initialized
INFO - 2021-06-30 11:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 11:04:15 --> Model "vendor_model" initialized
INFO - 2021-06-30 11:04:15 --> Model "coupon_model" initialized
INFO - 2021-06-30 11:04:15 --> Model "user_model" initialized
INFO - 2021-06-30 11:04:15 --> Model "role_model" initialized
INFO - 2021-06-30 11:04:15 --> Controller Class Initialized
INFO - 2021-06-30 11:04:15 --> Helper loaded: language_helper
INFO - 2021-06-30 11:04:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 11:04:15 --> Model "Product_model" initialized
INFO - 2021-06-30 11:04:15 --> Final output sent to browser
DEBUG - 2021-06-30 11:04:15 --> Total execution time: 0.0747
INFO - 2021-06-30 11:04:33 --> Config Class Initialized
INFO - 2021-06-30 11:04:33 --> Hooks Class Initialized
DEBUG - 2021-06-30 11:04:33 --> UTF-8 Support Enabled
INFO - 2021-06-30 11:04:33 --> Utf8 Class Initialized
INFO - 2021-06-30 11:04:33 --> URI Class Initialized
INFO - 2021-06-30 11:04:33 --> Router Class Initialized
INFO - 2021-06-30 11:04:33 --> Output Class Initialized
INFO - 2021-06-30 11:04:33 --> Security Class Initialized
DEBUG - 2021-06-30 11:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 11:04:33 --> Input Class Initialized
INFO - 2021-06-30 11:04:33 --> Language Class Initialized
INFO - 2021-06-30 11:04:33 --> Loader Class Initialized
INFO - 2021-06-30 11:04:33 --> Helper loaded: html_helper
INFO - 2021-06-30 11:04:33 --> Helper loaded: url_helper
INFO - 2021-06-30 11:04:33 --> Helper loaded: form_helper
INFO - 2021-06-30 11:04:33 --> Database Driver Class Initialized
INFO - 2021-06-30 11:04:33 --> Form Validation Class Initialized
DEBUG - 2021-06-30 11:04:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 11:04:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 11:04:33 --> Encryption Class Initialized
INFO - 2021-06-30 11:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 11:04:33 --> Model "vendor_model" initialized
INFO - 2021-06-30 11:04:33 --> Model "coupon_model" initialized
INFO - 2021-06-30 11:04:33 --> Model "user_model" initialized
INFO - 2021-06-30 11:04:33 --> Model "role_model" initialized
INFO - 2021-06-30 11:04:33 --> Controller Class Initialized
INFO - 2021-06-30 11:04:33 --> Helper loaded: language_helper
INFO - 2021-06-30 11:04:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 11:04:33 --> Model "Customer_model" initialized
INFO - 2021-06-30 11:04:33 --> Model "Product_model" initialized
INFO - 2021-06-30 11:04:33 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 11:04:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 11:04:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 11:04:33 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 11:04:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 11:04:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 11:04:33 --> Final output sent to browser
DEBUG - 2021-06-30 11:04:33 --> Total execution time: 0.0799
INFO - 2021-06-30 11:04:40 --> Config Class Initialized
INFO - 2021-06-30 11:04:40 --> Hooks Class Initialized
DEBUG - 2021-06-30 11:04:40 --> UTF-8 Support Enabled
INFO - 2021-06-30 11:04:40 --> Utf8 Class Initialized
INFO - 2021-06-30 11:04:40 --> URI Class Initialized
INFO - 2021-06-30 11:04:40 --> Router Class Initialized
INFO - 2021-06-30 11:04:40 --> Output Class Initialized
INFO - 2021-06-30 11:04:40 --> Security Class Initialized
DEBUG - 2021-06-30 11:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 11:04:40 --> Input Class Initialized
INFO - 2021-06-30 11:04:40 --> Language Class Initialized
INFO - 2021-06-30 11:04:40 --> Loader Class Initialized
INFO - 2021-06-30 11:04:40 --> Helper loaded: html_helper
INFO - 2021-06-30 11:04:40 --> Helper loaded: url_helper
INFO - 2021-06-30 11:04:40 --> Helper loaded: form_helper
INFO - 2021-06-30 11:04:40 --> Database Driver Class Initialized
INFO - 2021-06-30 11:04:40 --> Form Validation Class Initialized
DEBUG - 2021-06-30 11:04:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 11:04:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 11:04:40 --> Encryption Class Initialized
INFO - 2021-06-30 11:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 11:04:40 --> Model "vendor_model" initialized
INFO - 2021-06-30 11:04:40 --> Model "coupon_model" initialized
INFO - 2021-06-30 11:04:40 --> Model "user_model" initialized
INFO - 2021-06-30 11:04:40 --> Model "role_model" initialized
INFO - 2021-06-30 11:04:40 --> Controller Class Initialized
INFO - 2021-06-30 11:04:40 --> Helper loaded: language_helper
INFO - 2021-06-30 11:04:40 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 11:04:40 --> Model "Customer_model" initialized
INFO - 2021-06-30 11:04:40 --> Final output sent to browser
DEBUG - 2021-06-30 11:04:40 --> Total execution time: 0.0620
INFO - 2021-06-30 11:05:16 --> Config Class Initialized
INFO - 2021-06-30 11:05:16 --> Hooks Class Initialized
DEBUG - 2021-06-30 11:05:16 --> UTF-8 Support Enabled
INFO - 2021-06-30 11:05:16 --> Utf8 Class Initialized
INFO - 2021-06-30 11:05:16 --> URI Class Initialized
INFO - 2021-06-30 11:05:16 --> Router Class Initialized
INFO - 2021-06-30 11:05:16 --> Output Class Initialized
INFO - 2021-06-30 11:05:16 --> Security Class Initialized
DEBUG - 2021-06-30 11:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 11:05:16 --> Input Class Initialized
INFO - 2021-06-30 11:05:16 --> Language Class Initialized
INFO - 2021-06-30 11:05:16 --> Loader Class Initialized
INFO - 2021-06-30 11:05:16 --> Helper loaded: html_helper
INFO - 2021-06-30 11:05:16 --> Helper loaded: url_helper
INFO - 2021-06-30 11:05:16 --> Helper loaded: form_helper
INFO - 2021-06-30 11:05:16 --> Database Driver Class Initialized
INFO - 2021-06-30 11:05:16 --> Form Validation Class Initialized
DEBUG - 2021-06-30 11:05:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 11:05:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 11:05:16 --> Encryption Class Initialized
INFO - 2021-06-30 11:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 11:05:16 --> Model "vendor_model" initialized
INFO - 2021-06-30 11:05:16 --> Model "coupon_model" initialized
INFO - 2021-06-30 11:05:16 --> Model "user_model" initialized
INFO - 2021-06-30 11:05:16 --> Model "role_model" initialized
INFO - 2021-06-30 11:05:16 --> Controller Class Initialized
INFO - 2021-06-30 11:05:16 --> Helper loaded: language_helper
INFO - 2021-06-30 11:05:16 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 11:05:16 --> Model "Product_model" initialized
INFO - 2021-06-30 11:05:16 --> Final output sent to browser
DEBUG - 2021-06-30 11:05:16 --> Total execution time: 0.0704
INFO - 2021-06-30 11:05:32 --> Config Class Initialized
INFO - 2021-06-30 11:05:32 --> Hooks Class Initialized
DEBUG - 2021-06-30 11:05:32 --> UTF-8 Support Enabled
INFO - 2021-06-30 11:05:32 --> Utf8 Class Initialized
INFO - 2021-06-30 11:05:32 --> URI Class Initialized
INFO - 2021-06-30 11:05:32 --> Router Class Initialized
INFO - 2021-06-30 11:05:32 --> Output Class Initialized
INFO - 2021-06-30 11:05:32 --> Security Class Initialized
DEBUG - 2021-06-30 11:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 11:05:32 --> Input Class Initialized
INFO - 2021-06-30 11:05:32 --> Language Class Initialized
INFO - 2021-06-30 11:05:32 --> Loader Class Initialized
INFO - 2021-06-30 11:05:32 --> Helper loaded: html_helper
INFO - 2021-06-30 11:05:32 --> Helper loaded: url_helper
INFO - 2021-06-30 11:05:32 --> Helper loaded: form_helper
INFO - 2021-06-30 11:05:32 --> Database Driver Class Initialized
INFO - 2021-06-30 11:05:32 --> Form Validation Class Initialized
DEBUG - 2021-06-30 11:05:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 11:05:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 11:05:32 --> Encryption Class Initialized
INFO - 2021-06-30 11:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 11:05:32 --> Model "vendor_model" initialized
INFO - 2021-06-30 11:05:32 --> Model "coupon_model" initialized
INFO - 2021-06-30 11:05:32 --> Model "user_model" initialized
INFO - 2021-06-30 11:05:32 --> Model "role_model" initialized
INFO - 2021-06-30 11:05:32 --> Controller Class Initialized
INFO - 2021-06-30 11:05:32 --> Helper loaded: language_helper
INFO - 2021-06-30 11:05:32 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 11:05:32 --> Model "Quotation_model" initialized
INFO - 2021-06-30 11:05:32 --> Final output sent to browser
DEBUG - 2021-06-30 11:05:32 --> Total execution time: 0.1726
INFO - 2021-06-30 11:06:18 --> Config Class Initialized
INFO - 2021-06-30 11:06:18 --> Hooks Class Initialized
DEBUG - 2021-06-30 11:06:18 --> UTF-8 Support Enabled
INFO - 2021-06-30 11:06:18 --> Utf8 Class Initialized
INFO - 2021-06-30 11:06:18 --> URI Class Initialized
INFO - 2021-06-30 11:06:18 --> Router Class Initialized
INFO - 2021-06-30 11:06:18 --> Output Class Initialized
INFO - 2021-06-30 11:06:18 --> Security Class Initialized
DEBUG - 2021-06-30 11:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 11:06:18 --> Input Class Initialized
INFO - 2021-06-30 11:06:18 --> Language Class Initialized
INFO - 2021-06-30 11:06:18 --> Loader Class Initialized
INFO - 2021-06-30 11:06:18 --> Helper loaded: html_helper
INFO - 2021-06-30 11:06:18 --> Helper loaded: url_helper
INFO - 2021-06-30 11:06:18 --> Helper loaded: form_helper
INFO - 2021-06-30 11:06:18 --> Database Driver Class Initialized
INFO - 2021-06-30 11:06:18 --> Form Validation Class Initialized
DEBUG - 2021-06-30 11:06:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 11:06:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 11:06:18 --> Encryption Class Initialized
INFO - 2021-06-30 11:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 11:06:18 --> Model "vendor_model" initialized
INFO - 2021-06-30 11:06:18 --> Model "coupon_model" initialized
INFO - 2021-06-30 11:06:18 --> Model "user_model" initialized
INFO - 2021-06-30 11:06:18 --> Model "role_model" initialized
INFO - 2021-06-30 11:06:18 --> Controller Class Initialized
INFO - 2021-06-30 11:06:18 --> Helper loaded: language_helper
INFO - 2021-06-30 11:06:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 11:06:18 --> Model "Quotation_model" initialized
INFO - 2021-06-30 11:06:18 --> Final output sent to browser
DEBUG - 2021-06-30 11:06:18 --> Total execution time: 0.1031
INFO - 2021-06-30 11:08:38 --> Config Class Initialized
INFO - 2021-06-30 11:08:38 --> Hooks Class Initialized
DEBUG - 2021-06-30 11:08:38 --> UTF-8 Support Enabled
INFO - 2021-06-30 11:08:38 --> Utf8 Class Initialized
INFO - 2021-06-30 11:08:38 --> URI Class Initialized
INFO - 2021-06-30 11:08:38 --> Router Class Initialized
INFO - 2021-06-30 11:08:38 --> Output Class Initialized
INFO - 2021-06-30 11:08:38 --> Security Class Initialized
DEBUG - 2021-06-30 11:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 11:08:38 --> Input Class Initialized
INFO - 2021-06-30 11:08:38 --> Language Class Initialized
INFO - 2021-06-30 11:08:38 --> Loader Class Initialized
INFO - 2021-06-30 11:08:38 --> Helper loaded: html_helper
INFO - 2021-06-30 11:08:38 --> Helper loaded: url_helper
INFO - 2021-06-30 11:08:38 --> Helper loaded: form_helper
INFO - 2021-06-30 11:08:38 --> Database Driver Class Initialized
INFO - 2021-06-30 11:08:38 --> Form Validation Class Initialized
DEBUG - 2021-06-30 11:08:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 11:08:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 11:08:38 --> Encryption Class Initialized
INFO - 2021-06-30 11:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 11:08:38 --> Model "vendor_model" initialized
INFO - 2021-06-30 11:08:38 --> Model "coupon_model" initialized
INFO - 2021-06-30 11:08:38 --> Model "user_model" initialized
INFO - 2021-06-30 11:08:38 --> Model "role_model" initialized
INFO - 2021-06-30 11:08:38 --> Controller Class Initialized
INFO - 2021-06-30 11:08:38 --> Helper loaded: language_helper
INFO - 2021-06-30 11:08:38 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 11:08:38 --> Model "Customer_model" initialized
INFO - 2021-06-30 11:08:38 --> Model "Product_model" initialized
INFO - 2021-06-30 11:08:38 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 11:08:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 11:08:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 11:08:38 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 11:08:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 11:08:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 11:08:38 --> Final output sent to browser
DEBUG - 2021-06-30 11:08:38 --> Total execution time: 0.1177
INFO - 2021-06-30 11:15:55 --> Config Class Initialized
INFO - 2021-06-30 11:15:55 --> Hooks Class Initialized
DEBUG - 2021-06-30 11:15:55 --> UTF-8 Support Enabled
INFO - 2021-06-30 11:15:55 --> Utf8 Class Initialized
INFO - 2021-06-30 11:15:55 --> URI Class Initialized
INFO - 2021-06-30 11:15:55 --> Router Class Initialized
INFO - 2021-06-30 11:15:55 --> Output Class Initialized
INFO - 2021-06-30 11:15:55 --> Security Class Initialized
DEBUG - 2021-06-30 11:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 11:15:55 --> Input Class Initialized
INFO - 2021-06-30 11:15:55 --> Language Class Initialized
INFO - 2021-06-30 11:15:56 --> Loader Class Initialized
INFO - 2021-06-30 11:15:56 --> Helper loaded: html_helper
INFO - 2021-06-30 11:15:56 --> Helper loaded: url_helper
INFO - 2021-06-30 11:15:56 --> Helper loaded: form_helper
INFO - 2021-06-30 11:15:56 --> Database Driver Class Initialized
INFO - 2021-06-30 11:15:56 --> Form Validation Class Initialized
DEBUG - 2021-06-30 11:15:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 11:15:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 11:15:56 --> Encryption Class Initialized
INFO - 2021-06-30 11:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 11:15:56 --> Model "vendor_model" initialized
INFO - 2021-06-30 11:15:56 --> Model "coupon_model" initialized
INFO - 2021-06-30 11:15:56 --> Model "user_model" initialized
INFO - 2021-06-30 11:15:56 --> Model "role_model" initialized
INFO - 2021-06-30 11:15:56 --> Controller Class Initialized
INFO - 2021-06-30 11:15:56 --> Helper loaded: language_helper
INFO - 2021-06-30 11:15:56 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 11:15:56 --> Model "Customer_model" initialized
INFO - 2021-06-30 11:15:56 --> Model "Product_model" initialized
INFO - 2021-06-30 11:15:56 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 11:15:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 11:15:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 11:15:56 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 11:15:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 11:15:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 11:15:56 --> Final output sent to browser
DEBUG - 2021-06-30 11:15:56 --> Total execution time: 0.1396
INFO - 2021-06-30 11:16:04 --> Config Class Initialized
INFO - 2021-06-30 11:16:04 --> Hooks Class Initialized
DEBUG - 2021-06-30 11:16:04 --> UTF-8 Support Enabled
INFO - 2021-06-30 11:16:04 --> Utf8 Class Initialized
INFO - 2021-06-30 11:16:04 --> URI Class Initialized
INFO - 2021-06-30 11:16:04 --> Router Class Initialized
INFO - 2021-06-30 11:16:04 --> Output Class Initialized
INFO - 2021-06-30 11:16:04 --> Security Class Initialized
DEBUG - 2021-06-30 11:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 11:16:04 --> Input Class Initialized
INFO - 2021-06-30 11:16:04 --> Language Class Initialized
INFO - 2021-06-30 11:16:04 --> Loader Class Initialized
INFO - 2021-06-30 11:16:04 --> Helper loaded: html_helper
INFO - 2021-06-30 11:16:04 --> Helper loaded: url_helper
INFO - 2021-06-30 11:16:04 --> Helper loaded: form_helper
INFO - 2021-06-30 11:16:04 --> Database Driver Class Initialized
INFO - 2021-06-30 11:16:04 --> Form Validation Class Initialized
DEBUG - 2021-06-30 11:16:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 11:16:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 11:16:04 --> Encryption Class Initialized
INFO - 2021-06-30 11:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 11:16:04 --> Model "vendor_model" initialized
INFO - 2021-06-30 11:16:04 --> Model "coupon_model" initialized
INFO - 2021-06-30 11:16:04 --> Model "user_model" initialized
INFO - 2021-06-30 11:16:04 --> Model "role_model" initialized
INFO - 2021-06-30 11:16:04 --> Controller Class Initialized
INFO - 2021-06-30 11:16:04 --> Helper loaded: language_helper
INFO - 2021-06-30 11:16:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 11:16:04 --> Model "Customer_model" initialized
INFO - 2021-06-30 11:16:04 --> Final output sent to browser
DEBUG - 2021-06-30 11:16:04 --> Total execution time: 0.0626
INFO - 2021-06-30 11:16:32 --> Config Class Initialized
INFO - 2021-06-30 11:16:32 --> Hooks Class Initialized
DEBUG - 2021-06-30 11:16:32 --> UTF-8 Support Enabled
INFO - 2021-06-30 11:16:32 --> Utf8 Class Initialized
INFO - 2021-06-30 11:16:32 --> URI Class Initialized
INFO - 2021-06-30 11:16:32 --> Router Class Initialized
INFO - 2021-06-30 11:16:32 --> Output Class Initialized
INFO - 2021-06-30 11:16:32 --> Security Class Initialized
DEBUG - 2021-06-30 11:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 11:16:32 --> Input Class Initialized
INFO - 2021-06-30 11:16:32 --> Language Class Initialized
INFO - 2021-06-30 11:16:32 --> Loader Class Initialized
INFO - 2021-06-30 11:16:32 --> Helper loaded: html_helper
INFO - 2021-06-30 11:16:32 --> Helper loaded: url_helper
INFO - 2021-06-30 11:16:32 --> Helper loaded: form_helper
INFO - 2021-06-30 11:16:32 --> Database Driver Class Initialized
INFO - 2021-06-30 11:16:32 --> Form Validation Class Initialized
DEBUG - 2021-06-30 11:16:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 11:16:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 11:16:32 --> Encryption Class Initialized
INFO - 2021-06-30 11:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 11:16:32 --> Model "vendor_model" initialized
INFO - 2021-06-30 11:16:32 --> Model "coupon_model" initialized
INFO - 2021-06-30 11:16:32 --> Model "user_model" initialized
INFO - 2021-06-30 11:16:32 --> Model "role_model" initialized
INFO - 2021-06-30 11:16:32 --> Controller Class Initialized
INFO - 2021-06-30 11:16:32 --> Helper loaded: language_helper
INFO - 2021-06-30 11:16:32 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 11:16:32 --> Model "Product_model" initialized
INFO - 2021-06-30 11:16:32 --> Final output sent to browser
DEBUG - 2021-06-30 11:16:32 --> Total execution time: 0.0669
INFO - 2021-06-30 11:16:45 --> Config Class Initialized
INFO - 2021-06-30 11:16:45 --> Hooks Class Initialized
DEBUG - 2021-06-30 11:16:45 --> UTF-8 Support Enabled
INFO - 2021-06-30 11:16:45 --> Utf8 Class Initialized
INFO - 2021-06-30 11:16:45 --> URI Class Initialized
INFO - 2021-06-30 11:16:45 --> Router Class Initialized
INFO - 2021-06-30 11:16:45 --> Output Class Initialized
INFO - 2021-06-30 11:16:45 --> Security Class Initialized
DEBUG - 2021-06-30 11:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 11:16:45 --> Input Class Initialized
INFO - 2021-06-30 11:16:45 --> Language Class Initialized
INFO - 2021-06-30 11:16:45 --> Loader Class Initialized
INFO - 2021-06-30 11:16:45 --> Helper loaded: html_helper
INFO - 2021-06-30 11:16:45 --> Helper loaded: url_helper
INFO - 2021-06-30 11:16:45 --> Helper loaded: form_helper
INFO - 2021-06-30 11:16:45 --> Database Driver Class Initialized
INFO - 2021-06-30 11:16:45 --> Form Validation Class Initialized
DEBUG - 2021-06-30 11:16:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 11:16:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 11:16:45 --> Encryption Class Initialized
INFO - 2021-06-30 11:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 11:16:45 --> Model "vendor_model" initialized
INFO - 2021-06-30 11:16:45 --> Model "coupon_model" initialized
INFO - 2021-06-30 11:16:45 --> Model "user_model" initialized
INFO - 2021-06-30 11:16:45 --> Model "role_model" initialized
INFO - 2021-06-30 11:16:45 --> Controller Class Initialized
INFO - 2021-06-30 11:16:45 --> Helper loaded: language_helper
INFO - 2021-06-30 11:16:45 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 11:16:45 --> Final output sent to browser
DEBUG - 2021-06-30 11:16:45 --> Total execution time: 0.0827
INFO - 2021-06-30 11:21:53 --> Config Class Initialized
INFO - 2021-06-30 11:21:53 --> Hooks Class Initialized
DEBUG - 2021-06-30 11:21:53 --> UTF-8 Support Enabled
INFO - 2021-06-30 11:21:53 --> Utf8 Class Initialized
INFO - 2021-06-30 11:21:53 --> URI Class Initialized
INFO - 2021-06-30 11:21:53 --> Router Class Initialized
INFO - 2021-06-30 11:21:53 --> Output Class Initialized
INFO - 2021-06-30 11:21:53 --> Security Class Initialized
DEBUG - 2021-06-30 11:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 11:21:53 --> Input Class Initialized
INFO - 2021-06-30 11:21:53 --> Language Class Initialized
INFO - 2021-06-30 11:21:54 --> Loader Class Initialized
INFO - 2021-06-30 11:21:54 --> Helper loaded: html_helper
INFO - 2021-06-30 11:21:54 --> Helper loaded: url_helper
INFO - 2021-06-30 11:21:54 --> Helper loaded: form_helper
INFO - 2021-06-30 11:21:54 --> Database Driver Class Initialized
INFO - 2021-06-30 11:21:54 --> Form Validation Class Initialized
DEBUG - 2021-06-30 11:21:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 11:21:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 11:21:54 --> Encryption Class Initialized
INFO - 2021-06-30 11:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 11:21:54 --> Model "vendor_model" initialized
INFO - 2021-06-30 11:21:54 --> Model "coupon_model" initialized
INFO - 2021-06-30 11:21:54 --> Model "user_model" initialized
INFO - 2021-06-30 11:21:54 --> Model "role_model" initialized
INFO - 2021-06-30 11:21:54 --> Controller Class Initialized
INFO - 2021-06-30 11:21:54 --> Helper loaded: language_helper
INFO - 2021-06-30 11:21:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 11:21:54 --> Model "Customer_model" initialized
INFO - 2021-06-30 11:21:54 --> Model "Product_model" initialized
INFO - 2021-06-30 11:21:54 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 11:21:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 11:21:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 11:21:54 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 11:21:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 11:21:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 11:21:54 --> Final output sent to browser
DEBUG - 2021-06-30 11:21:54 --> Total execution time: 0.1505
INFO - 2021-06-30 11:21:59 --> Config Class Initialized
INFO - 2021-06-30 11:21:59 --> Hooks Class Initialized
DEBUG - 2021-06-30 11:21:59 --> UTF-8 Support Enabled
INFO - 2021-06-30 11:21:59 --> Utf8 Class Initialized
INFO - 2021-06-30 11:21:59 --> URI Class Initialized
INFO - 2021-06-30 11:21:59 --> Router Class Initialized
INFO - 2021-06-30 11:21:59 --> Output Class Initialized
INFO - 2021-06-30 11:21:59 --> Security Class Initialized
DEBUG - 2021-06-30 11:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 11:21:59 --> Input Class Initialized
INFO - 2021-06-30 11:21:59 --> Language Class Initialized
INFO - 2021-06-30 11:21:59 --> Loader Class Initialized
INFO - 2021-06-30 11:21:59 --> Helper loaded: html_helper
INFO - 2021-06-30 11:21:59 --> Helper loaded: url_helper
INFO - 2021-06-30 11:21:59 --> Helper loaded: form_helper
INFO - 2021-06-30 11:21:59 --> Database Driver Class Initialized
INFO - 2021-06-30 11:21:59 --> Form Validation Class Initialized
DEBUG - 2021-06-30 11:21:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 11:21:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 11:21:59 --> Encryption Class Initialized
INFO - 2021-06-30 11:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 11:21:59 --> Model "vendor_model" initialized
INFO - 2021-06-30 11:21:59 --> Model "coupon_model" initialized
INFO - 2021-06-30 11:21:59 --> Model "user_model" initialized
INFO - 2021-06-30 11:21:59 --> Model "role_model" initialized
INFO - 2021-06-30 11:21:59 --> Controller Class Initialized
INFO - 2021-06-30 11:21:59 --> Helper loaded: language_helper
INFO - 2021-06-30 11:21:59 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 11:21:59 --> Model "Customer_model" initialized
INFO - 2021-06-30 11:21:59 --> Final output sent to browser
DEBUG - 2021-06-30 11:21:59 --> Total execution time: 0.0696
INFO - 2021-06-30 11:22:20 --> Config Class Initialized
INFO - 2021-06-30 11:22:20 --> Hooks Class Initialized
DEBUG - 2021-06-30 11:22:20 --> UTF-8 Support Enabled
INFO - 2021-06-30 11:22:20 --> Utf8 Class Initialized
INFO - 2021-06-30 11:22:20 --> URI Class Initialized
INFO - 2021-06-30 11:22:20 --> Router Class Initialized
INFO - 2021-06-30 11:22:20 --> Output Class Initialized
INFO - 2021-06-30 11:22:20 --> Security Class Initialized
DEBUG - 2021-06-30 11:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 11:22:20 --> Input Class Initialized
INFO - 2021-06-30 11:22:20 --> Language Class Initialized
INFO - 2021-06-30 11:22:20 --> Loader Class Initialized
INFO - 2021-06-30 11:22:20 --> Helper loaded: html_helper
INFO - 2021-06-30 11:22:20 --> Helper loaded: url_helper
INFO - 2021-06-30 11:22:20 --> Helper loaded: form_helper
INFO - 2021-06-30 11:22:20 --> Database Driver Class Initialized
INFO - 2021-06-30 11:22:20 --> Form Validation Class Initialized
DEBUG - 2021-06-30 11:22:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 11:22:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 11:22:20 --> Encryption Class Initialized
INFO - 2021-06-30 11:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 11:22:20 --> Model "vendor_model" initialized
INFO - 2021-06-30 11:22:20 --> Model "coupon_model" initialized
INFO - 2021-06-30 11:22:20 --> Model "user_model" initialized
INFO - 2021-06-30 11:22:20 --> Model "role_model" initialized
INFO - 2021-06-30 11:22:20 --> Controller Class Initialized
INFO - 2021-06-30 11:22:20 --> Helper loaded: language_helper
INFO - 2021-06-30 11:22:20 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 11:22:20 --> Model "Product_model" initialized
INFO - 2021-06-30 11:22:20 --> Final output sent to browser
DEBUG - 2021-06-30 11:22:20 --> Total execution time: 0.0953
INFO - 2021-06-30 11:22:33 --> Config Class Initialized
INFO - 2021-06-30 11:22:33 --> Hooks Class Initialized
DEBUG - 2021-06-30 11:22:33 --> UTF-8 Support Enabled
INFO - 2021-06-30 11:22:33 --> Utf8 Class Initialized
INFO - 2021-06-30 11:22:33 --> URI Class Initialized
INFO - 2021-06-30 11:22:33 --> Router Class Initialized
INFO - 2021-06-30 11:22:33 --> Output Class Initialized
INFO - 2021-06-30 11:22:33 --> Security Class Initialized
DEBUG - 2021-06-30 11:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 11:22:33 --> Input Class Initialized
INFO - 2021-06-30 11:22:33 --> Language Class Initialized
INFO - 2021-06-30 11:22:33 --> Loader Class Initialized
INFO - 2021-06-30 11:22:34 --> Helper loaded: html_helper
INFO - 2021-06-30 11:22:34 --> Helper loaded: url_helper
INFO - 2021-06-30 11:22:34 --> Helper loaded: form_helper
INFO - 2021-06-30 11:22:34 --> Database Driver Class Initialized
INFO - 2021-06-30 11:22:34 --> Form Validation Class Initialized
DEBUG - 2021-06-30 11:22:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 11:22:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 11:22:34 --> Encryption Class Initialized
INFO - 2021-06-30 11:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 11:22:34 --> Model "vendor_model" initialized
INFO - 2021-06-30 11:22:34 --> Model "coupon_model" initialized
INFO - 2021-06-30 11:22:34 --> Model "user_model" initialized
INFO - 2021-06-30 11:22:34 --> Model "role_model" initialized
INFO - 2021-06-30 11:22:34 --> Controller Class Initialized
INFO - 2021-06-30 11:22:34 --> Helper loaded: language_helper
INFO - 2021-06-30 11:22:34 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 11:22:34 --> Final output sent to browser
DEBUG - 2021-06-30 11:22:34 --> Total execution time: 0.0862
INFO - 2021-06-30 11:23:31 --> Config Class Initialized
INFO - 2021-06-30 11:23:31 --> Hooks Class Initialized
DEBUG - 2021-06-30 11:23:31 --> UTF-8 Support Enabled
INFO - 2021-06-30 11:23:31 --> Utf8 Class Initialized
INFO - 2021-06-30 11:23:31 --> URI Class Initialized
INFO - 2021-06-30 11:23:31 --> Router Class Initialized
INFO - 2021-06-30 11:23:31 --> Output Class Initialized
INFO - 2021-06-30 11:23:31 --> Security Class Initialized
DEBUG - 2021-06-30 11:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 11:23:31 --> Input Class Initialized
INFO - 2021-06-30 11:23:31 --> Language Class Initialized
INFO - 2021-06-30 11:23:31 --> Loader Class Initialized
INFO - 2021-06-30 11:23:31 --> Helper loaded: html_helper
INFO - 2021-06-30 11:23:31 --> Helper loaded: url_helper
INFO - 2021-06-30 11:23:31 --> Helper loaded: form_helper
INFO - 2021-06-30 11:23:31 --> Database Driver Class Initialized
INFO - 2021-06-30 11:23:31 --> Form Validation Class Initialized
DEBUG - 2021-06-30 11:23:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 11:23:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 11:23:31 --> Encryption Class Initialized
INFO - 2021-06-30 11:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 11:23:31 --> Model "vendor_model" initialized
INFO - 2021-06-30 11:23:31 --> Model "coupon_model" initialized
INFO - 2021-06-30 11:23:31 --> Model "user_model" initialized
INFO - 2021-06-30 11:23:31 --> Model "role_model" initialized
INFO - 2021-06-30 11:23:31 --> Controller Class Initialized
INFO - 2021-06-30 11:23:31 --> Helper loaded: language_helper
INFO - 2021-06-30 11:23:31 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 11:23:31 --> Model "Customer_model" initialized
INFO - 2021-06-30 11:23:31 --> Model "Product_model" initialized
INFO - 2021-06-30 11:23:31 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 11:23:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 11:23:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 11:23:31 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 11:23:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 11:23:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 11:23:31 --> Final output sent to browser
DEBUG - 2021-06-30 11:23:31 --> Total execution time: 0.1383
INFO - 2021-06-30 11:23:37 --> Config Class Initialized
INFO - 2021-06-30 11:23:37 --> Hooks Class Initialized
DEBUG - 2021-06-30 11:23:37 --> UTF-8 Support Enabled
INFO - 2021-06-30 11:23:37 --> Utf8 Class Initialized
INFO - 2021-06-30 11:23:37 --> URI Class Initialized
INFO - 2021-06-30 11:23:37 --> Router Class Initialized
INFO - 2021-06-30 11:23:37 --> Output Class Initialized
INFO - 2021-06-30 11:23:37 --> Security Class Initialized
DEBUG - 2021-06-30 11:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 11:23:37 --> Input Class Initialized
INFO - 2021-06-30 11:23:37 --> Language Class Initialized
INFO - 2021-06-30 11:23:37 --> Loader Class Initialized
INFO - 2021-06-30 11:23:37 --> Helper loaded: html_helper
INFO - 2021-06-30 11:23:37 --> Helper loaded: url_helper
INFO - 2021-06-30 11:23:37 --> Helper loaded: form_helper
INFO - 2021-06-30 11:23:37 --> Database Driver Class Initialized
INFO - 2021-06-30 11:23:37 --> Form Validation Class Initialized
DEBUG - 2021-06-30 11:23:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 11:23:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 11:23:37 --> Encryption Class Initialized
INFO - 2021-06-30 11:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 11:23:37 --> Model "vendor_model" initialized
INFO - 2021-06-30 11:23:37 --> Model "coupon_model" initialized
INFO - 2021-06-30 11:23:37 --> Model "user_model" initialized
INFO - 2021-06-30 11:23:37 --> Model "role_model" initialized
INFO - 2021-06-30 11:23:37 --> Controller Class Initialized
INFO - 2021-06-30 11:23:37 --> Helper loaded: language_helper
INFO - 2021-06-30 11:23:37 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 11:23:37 --> Model "Customer_model" initialized
INFO - 2021-06-30 11:23:37 --> Final output sent to browser
DEBUG - 2021-06-30 11:23:37 --> Total execution time: 0.0612
INFO - 2021-06-30 11:23:57 --> Config Class Initialized
INFO - 2021-06-30 11:23:57 --> Hooks Class Initialized
DEBUG - 2021-06-30 11:23:57 --> UTF-8 Support Enabled
INFO - 2021-06-30 11:23:57 --> Utf8 Class Initialized
INFO - 2021-06-30 11:23:57 --> URI Class Initialized
INFO - 2021-06-30 11:23:57 --> Router Class Initialized
INFO - 2021-06-30 11:23:57 --> Output Class Initialized
INFO - 2021-06-30 11:23:57 --> Security Class Initialized
DEBUG - 2021-06-30 11:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 11:23:57 --> Input Class Initialized
INFO - 2021-06-30 11:23:57 --> Language Class Initialized
INFO - 2021-06-30 11:23:57 --> Loader Class Initialized
INFO - 2021-06-30 11:23:57 --> Helper loaded: html_helper
INFO - 2021-06-30 11:23:57 --> Helper loaded: url_helper
INFO - 2021-06-30 11:23:57 --> Helper loaded: form_helper
INFO - 2021-06-30 11:23:57 --> Database Driver Class Initialized
INFO - 2021-06-30 11:23:57 --> Form Validation Class Initialized
DEBUG - 2021-06-30 11:23:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 11:23:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 11:23:57 --> Encryption Class Initialized
INFO - 2021-06-30 11:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 11:23:57 --> Model "vendor_model" initialized
INFO - 2021-06-30 11:23:57 --> Model "coupon_model" initialized
INFO - 2021-06-30 11:23:57 --> Model "user_model" initialized
INFO - 2021-06-30 11:23:57 --> Model "role_model" initialized
INFO - 2021-06-30 11:23:57 --> Controller Class Initialized
INFO - 2021-06-30 11:23:57 --> Helper loaded: language_helper
INFO - 2021-06-30 11:23:57 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 11:23:57 --> Model "Product_model" initialized
INFO - 2021-06-30 11:23:57 --> Final output sent to browser
DEBUG - 2021-06-30 11:23:57 --> Total execution time: 0.0629
INFO - 2021-06-30 11:24:08 --> Config Class Initialized
INFO - 2021-06-30 11:24:08 --> Hooks Class Initialized
DEBUG - 2021-06-30 11:24:08 --> UTF-8 Support Enabled
INFO - 2021-06-30 11:24:08 --> Utf8 Class Initialized
INFO - 2021-06-30 11:24:08 --> URI Class Initialized
INFO - 2021-06-30 11:24:08 --> Router Class Initialized
INFO - 2021-06-30 11:24:08 --> Output Class Initialized
INFO - 2021-06-30 11:24:08 --> Security Class Initialized
DEBUG - 2021-06-30 11:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 11:24:08 --> Input Class Initialized
INFO - 2021-06-30 11:24:08 --> Language Class Initialized
INFO - 2021-06-30 11:24:08 --> Loader Class Initialized
INFO - 2021-06-30 11:24:08 --> Helper loaded: html_helper
INFO - 2021-06-30 11:24:08 --> Helper loaded: url_helper
INFO - 2021-06-30 11:24:08 --> Helper loaded: form_helper
INFO - 2021-06-30 11:24:08 --> Database Driver Class Initialized
INFO - 2021-06-30 11:24:08 --> Form Validation Class Initialized
DEBUG - 2021-06-30 11:24:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 11:24:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 11:24:08 --> Encryption Class Initialized
INFO - 2021-06-30 11:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 11:24:08 --> Model "vendor_model" initialized
INFO - 2021-06-30 11:24:08 --> Model "coupon_model" initialized
INFO - 2021-06-30 11:24:08 --> Model "user_model" initialized
INFO - 2021-06-30 11:24:08 --> Model "role_model" initialized
INFO - 2021-06-30 11:24:08 --> Controller Class Initialized
INFO - 2021-06-30 11:24:08 --> Helper loaded: language_helper
INFO - 2021-06-30 11:24:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 11:24:08 --> Final output sent to browser
DEBUG - 2021-06-30 11:24:08 --> Total execution time: 0.0761
INFO - 2021-06-30 11:31:50 --> Config Class Initialized
INFO - 2021-06-30 11:31:50 --> Hooks Class Initialized
DEBUG - 2021-06-30 11:31:50 --> UTF-8 Support Enabled
INFO - 2021-06-30 11:31:50 --> Utf8 Class Initialized
INFO - 2021-06-30 11:31:50 --> URI Class Initialized
INFO - 2021-06-30 11:31:50 --> Router Class Initialized
INFO - 2021-06-30 11:31:50 --> Output Class Initialized
INFO - 2021-06-30 11:31:50 --> Security Class Initialized
DEBUG - 2021-06-30 11:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 11:31:50 --> Input Class Initialized
INFO - 2021-06-30 11:31:50 --> Language Class Initialized
INFO - 2021-06-30 11:31:50 --> Loader Class Initialized
INFO - 2021-06-30 11:31:50 --> Helper loaded: html_helper
INFO - 2021-06-30 11:31:50 --> Helper loaded: url_helper
INFO - 2021-06-30 11:31:50 --> Helper loaded: form_helper
INFO - 2021-06-30 11:31:50 --> Database Driver Class Initialized
INFO - 2021-06-30 11:31:50 --> Form Validation Class Initialized
DEBUG - 2021-06-30 11:31:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 11:31:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 11:31:50 --> Encryption Class Initialized
INFO - 2021-06-30 11:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 11:31:50 --> Model "vendor_model" initialized
INFO - 2021-06-30 11:31:50 --> Model "coupon_model" initialized
INFO - 2021-06-30 11:31:50 --> Model "user_model" initialized
INFO - 2021-06-30 11:31:50 --> Model "role_model" initialized
INFO - 2021-06-30 11:31:50 --> Controller Class Initialized
INFO - 2021-06-30 11:31:50 --> Helper loaded: language_helper
INFO - 2021-06-30 11:31:50 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 11:31:50 --> Model "Customer_model" initialized
INFO - 2021-06-30 11:31:50 --> Model "Product_model" initialized
INFO - 2021-06-30 11:31:50 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 11:31:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 11:31:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 11:31:50 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 11:31:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 11:31:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 11:31:50 --> Final output sent to browser
DEBUG - 2021-06-30 11:31:50 --> Total execution time: 0.1954
INFO - 2021-06-30 11:31:57 --> Config Class Initialized
INFO - 2021-06-30 11:31:57 --> Hooks Class Initialized
DEBUG - 2021-06-30 11:31:57 --> UTF-8 Support Enabled
INFO - 2021-06-30 11:31:57 --> Utf8 Class Initialized
INFO - 2021-06-30 11:31:57 --> URI Class Initialized
INFO - 2021-06-30 11:31:57 --> Router Class Initialized
INFO - 2021-06-30 11:31:57 --> Output Class Initialized
INFO - 2021-06-30 11:31:57 --> Security Class Initialized
DEBUG - 2021-06-30 11:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 11:31:57 --> Input Class Initialized
INFO - 2021-06-30 11:31:57 --> Language Class Initialized
INFO - 2021-06-30 11:31:57 --> Loader Class Initialized
INFO - 2021-06-30 11:31:57 --> Helper loaded: html_helper
INFO - 2021-06-30 11:31:57 --> Helper loaded: url_helper
INFO - 2021-06-30 11:31:57 --> Helper loaded: form_helper
INFO - 2021-06-30 11:31:57 --> Database Driver Class Initialized
INFO - 2021-06-30 11:31:57 --> Form Validation Class Initialized
DEBUG - 2021-06-30 11:31:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 11:31:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 11:31:57 --> Encryption Class Initialized
INFO - 2021-06-30 11:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 11:31:57 --> Model "vendor_model" initialized
INFO - 2021-06-30 11:31:57 --> Model "coupon_model" initialized
INFO - 2021-06-30 11:31:57 --> Model "user_model" initialized
INFO - 2021-06-30 11:31:57 --> Model "role_model" initialized
INFO - 2021-06-30 11:31:57 --> Controller Class Initialized
INFO - 2021-06-30 11:31:57 --> Helper loaded: language_helper
INFO - 2021-06-30 11:31:57 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 11:31:57 --> Model "Customer_model" initialized
INFO - 2021-06-30 11:31:57 --> Final output sent to browser
DEBUG - 2021-06-30 11:31:57 --> Total execution time: 0.0743
INFO - 2021-06-30 11:32:24 --> Config Class Initialized
INFO - 2021-06-30 11:32:24 --> Hooks Class Initialized
DEBUG - 2021-06-30 11:32:24 --> UTF-8 Support Enabled
INFO - 2021-06-30 11:32:24 --> Utf8 Class Initialized
INFO - 2021-06-30 11:32:24 --> URI Class Initialized
INFO - 2021-06-30 11:32:24 --> Router Class Initialized
INFO - 2021-06-30 11:32:24 --> Output Class Initialized
INFO - 2021-06-30 11:32:24 --> Security Class Initialized
DEBUG - 2021-06-30 11:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 11:32:24 --> Input Class Initialized
INFO - 2021-06-30 11:32:24 --> Language Class Initialized
INFO - 2021-06-30 11:32:24 --> Loader Class Initialized
INFO - 2021-06-30 11:32:24 --> Helper loaded: html_helper
INFO - 2021-06-30 11:32:24 --> Helper loaded: url_helper
INFO - 2021-06-30 11:32:24 --> Helper loaded: form_helper
INFO - 2021-06-30 11:32:24 --> Database Driver Class Initialized
INFO - 2021-06-30 11:32:24 --> Form Validation Class Initialized
DEBUG - 2021-06-30 11:32:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 11:32:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 11:32:24 --> Encryption Class Initialized
INFO - 2021-06-30 11:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 11:32:24 --> Model "vendor_model" initialized
INFO - 2021-06-30 11:32:24 --> Model "coupon_model" initialized
INFO - 2021-06-30 11:32:24 --> Model "user_model" initialized
INFO - 2021-06-30 11:32:24 --> Model "role_model" initialized
INFO - 2021-06-30 11:32:24 --> Controller Class Initialized
INFO - 2021-06-30 11:32:24 --> Helper loaded: language_helper
INFO - 2021-06-30 11:32:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 11:32:24 --> Model "Product_model" initialized
INFO - 2021-06-30 11:32:24 --> Final output sent to browser
DEBUG - 2021-06-30 11:32:24 --> Total execution time: 0.0798
INFO - 2021-06-30 11:32:33 --> Config Class Initialized
INFO - 2021-06-30 11:32:33 --> Hooks Class Initialized
DEBUG - 2021-06-30 11:32:33 --> UTF-8 Support Enabled
INFO - 2021-06-30 11:32:33 --> Utf8 Class Initialized
INFO - 2021-06-30 11:32:33 --> URI Class Initialized
INFO - 2021-06-30 11:32:33 --> Router Class Initialized
INFO - 2021-06-30 11:32:33 --> Output Class Initialized
INFO - 2021-06-30 11:32:33 --> Security Class Initialized
DEBUG - 2021-06-30 11:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 11:32:33 --> Input Class Initialized
INFO - 2021-06-30 11:32:33 --> Language Class Initialized
INFO - 2021-06-30 11:32:33 --> Loader Class Initialized
INFO - 2021-06-30 11:32:33 --> Helper loaded: html_helper
INFO - 2021-06-30 11:32:33 --> Helper loaded: url_helper
INFO - 2021-06-30 11:32:33 --> Helper loaded: form_helper
INFO - 2021-06-30 11:32:33 --> Database Driver Class Initialized
INFO - 2021-06-30 11:32:33 --> Form Validation Class Initialized
DEBUG - 2021-06-30 11:32:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 11:32:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 11:32:33 --> Encryption Class Initialized
INFO - 2021-06-30 11:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 11:32:33 --> Model "vendor_model" initialized
INFO - 2021-06-30 11:32:33 --> Model "coupon_model" initialized
INFO - 2021-06-30 11:32:33 --> Model "user_model" initialized
INFO - 2021-06-30 11:32:33 --> Model "role_model" initialized
INFO - 2021-06-30 11:32:33 --> Controller Class Initialized
INFO - 2021-06-30 11:32:33 --> Helper loaded: language_helper
INFO - 2021-06-30 11:32:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 11:32:33 --> Model "Quotation_model" initialized
INFO - 2021-06-30 11:32:33 --> Final output sent to browser
DEBUG - 2021-06-30 11:32:33 --> Total execution time: 0.0843
INFO - 2021-06-30 11:49:55 --> Config Class Initialized
INFO - 2021-06-30 11:49:55 --> Hooks Class Initialized
DEBUG - 2021-06-30 11:49:55 --> UTF-8 Support Enabled
INFO - 2021-06-30 11:49:55 --> Utf8 Class Initialized
INFO - 2021-06-30 11:49:55 --> URI Class Initialized
INFO - 2021-06-30 11:49:55 --> Router Class Initialized
INFO - 2021-06-30 11:49:55 --> Output Class Initialized
INFO - 2021-06-30 11:49:55 --> Security Class Initialized
DEBUG - 2021-06-30 11:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 11:49:55 --> Input Class Initialized
INFO - 2021-06-30 11:49:55 --> Language Class Initialized
INFO - 2021-06-30 11:49:55 --> Loader Class Initialized
INFO - 2021-06-30 11:49:55 --> Helper loaded: html_helper
INFO - 2021-06-30 11:49:55 --> Helper loaded: url_helper
INFO - 2021-06-30 11:49:55 --> Helper loaded: form_helper
INFO - 2021-06-30 11:49:55 --> Database Driver Class Initialized
INFO - 2021-06-30 11:49:55 --> Form Validation Class Initialized
DEBUG - 2021-06-30 11:49:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 11:49:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 11:49:55 --> Encryption Class Initialized
INFO - 2021-06-30 11:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 11:49:55 --> Model "vendor_model" initialized
INFO - 2021-06-30 11:49:55 --> Model "coupon_model" initialized
INFO - 2021-06-30 11:49:55 --> Model "user_model" initialized
INFO - 2021-06-30 11:49:55 --> Model "role_model" initialized
INFO - 2021-06-30 11:49:55 --> Controller Class Initialized
INFO - 2021-06-30 11:49:55 --> Helper loaded: language_helper
INFO - 2021-06-30 11:49:55 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 11:49:55 --> Model "Customer_model" initialized
INFO - 2021-06-30 11:49:55 --> Model "Product_model" initialized
INFO - 2021-06-30 11:49:55 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 11:49:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 11:49:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 11:49:55 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 11:49:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 11:49:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 11:49:55 --> Final output sent to browser
DEBUG - 2021-06-30 11:49:55 --> Total execution time: 0.1358
INFO - 2021-06-30 11:50:03 --> Config Class Initialized
INFO - 2021-06-30 11:50:03 --> Hooks Class Initialized
DEBUG - 2021-06-30 11:50:03 --> UTF-8 Support Enabled
INFO - 2021-06-30 11:50:03 --> Utf8 Class Initialized
INFO - 2021-06-30 11:50:03 --> URI Class Initialized
INFO - 2021-06-30 11:50:03 --> Router Class Initialized
INFO - 2021-06-30 11:50:03 --> Output Class Initialized
INFO - 2021-06-30 11:50:03 --> Security Class Initialized
DEBUG - 2021-06-30 11:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 11:50:03 --> Input Class Initialized
INFO - 2021-06-30 11:50:03 --> Language Class Initialized
INFO - 2021-06-30 11:50:03 --> Loader Class Initialized
INFO - 2021-06-30 11:50:03 --> Helper loaded: html_helper
INFO - 2021-06-30 11:50:03 --> Helper loaded: url_helper
INFO - 2021-06-30 11:50:03 --> Helper loaded: form_helper
INFO - 2021-06-30 11:50:03 --> Database Driver Class Initialized
INFO - 2021-06-30 11:50:03 --> Form Validation Class Initialized
DEBUG - 2021-06-30 11:50:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 11:50:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 11:50:03 --> Encryption Class Initialized
INFO - 2021-06-30 11:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 11:50:03 --> Model "vendor_model" initialized
INFO - 2021-06-30 11:50:03 --> Model "coupon_model" initialized
INFO - 2021-06-30 11:50:03 --> Model "user_model" initialized
INFO - 2021-06-30 11:50:03 --> Model "role_model" initialized
INFO - 2021-06-30 11:50:03 --> Controller Class Initialized
INFO - 2021-06-30 11:50:03 --> Helper loaded: language_helper
INFO - 2021-06-30 11:50:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 11:50:03 --> Model "Customer_model" initialized
INFO - 2021-06-30 11:50:03 --> Final output sent to browser
DEBUG - 2021-06-30 11:50:03 --> Total execution time: 0.0870
INFO - 2021-06-30 11:50:23 --> Config Class Initialized
INFO - 2021-06-30 11:50:23 --> Hooks Class Initialized
DEBUG - 2021-06-30 11:50:23 --> UTF-8 Support Enabled
INFO - 2021-06-30 11:50:23 --> Utf8 Class Initialized
INFO - 2021-06-30 11:50:23 --> URI Class Initialized
INFO - 2021-06-30 11:50:23 --> Router Class Initialized
INFO - 2021-06-30 11:50:23 --> Output Class Initialized
INFO - 2021-06-30 11:50:23 --> Security Class Initialized
DEBUG - 2021-06-30 11:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 11:50:23 --> Input Class Initialized
INFO - 2021-06-30 11:50:23 --> Language Class Initialized
INFO - 2021-06-30 11:50:23 --> Loader Class Initialized
INFO - 2021-06-30 11:50:23 --> Helper loaded: html_helper
INFO - 2021-06-30 11:50:23 --> Helper loaded: url_helper
INFO - 2021-06-30 11:50:23 --> Helper loaded: form_helper
INFO - 2021-06-30 11:50:23 --> Database Driver Class Initialized
INFO - 2021-06-30 11:50:23 --> Form Validation Class Initialized
DEBUG - 2021-06-30 11:50:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 11:50:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 11:50:23 --> Encryption Class Initialized
INFO - 2021-06-30 11:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 11:50:23 --> Model "vendor_model" initialized
INFO - 2021-06-30 11:50:23 --> Model "coupon_model" initialized
INFO - 2021-06-30 11:50:23 --> Model "user_model" initialized
INFO - 2021-06-30 11:50:23 --> Model "role_model" initialized
INFO - 2021-06-30 11:50:23 --> Controller Class Initialized
INFO - 2021-06-30 11:50:23 --> Helper loaded: language_helper
INFO - 2021-06-30 11:50:23 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 11:50:23 --> Model "Product_model" initialized
INFO - 2021-06-30 11:50:23 --> Final output sent to browser
DEBUG - 2021-06-30 11:50:23 --> Total execution time: 0.0705
INFO - 2021-06-30 11:50:34 --> Config Class Initialized
INFO - 2021-06-30 11:50:34 --> Hooks Class Initialized
DEBUG - 2021-06-30 11:50:34 --> UTF-8 Support Enabled
INFO - 2021-06-30 11:50:34 --> Utf8 Class Initialized
INFO - 2021-06-30 11:50:34 --> URI Class Initialized
INFO - 2021-06-30 11:50:34 --> Router Class Initialized
INFO - 2021-06-30 11:50:34 --> Output Class Initialized
INFO - 2021-06-30 11:50:34 --> Security Class Initialized
DEBUG - 2021-06-30 11:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 11:50:34 --> Input Class Initialized
INFO - 2021-06-30 11:50:34 --> Language Class Initialized
INFO - 2021-06-30 11:50:34 --> Loader Class Initialized
INFO - 2021-06-30 11:50:34 --> Helper loaded: html_helper
INFO - 2021-06-30 11:50:34 --> Helper loaded: url_helper
INFO - 2021-06-30 11:50:34 --> Helper loaded: form_helper
INFO - 2021-06-30 11:50:34 --> Database Driver Class Initialized
INFO - 2021-06-30 11:50:34 --> Form Validation Class Initialized
DEBUG - 2021-06-30 11:50:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 11:50:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 11:50:34 --> Encryption Class Initialized
INFO - 2021-06-30 11:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 11:50:34 --> Model "vendor_model" initialized
INFO - 2021-06-30 11:50:34 --> Model "coupon_model" initialized
INFO - 2021-06-30 11:50:34 --> Model "user_model" initialized
INFO - 2021-06-30 11:50:34 --> Model "role_model" initialized
INFO - 2021-06-30 11:50:34 --> Controller Class Initialized
INFO - 2021-06-30 11:50:34 --> Helper loaded: language_helper
INFO - 2021-06-30 11:50:34 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 11:50:34 --> Model "Quotation_model" initialized
INFO - 2021-06-30 11:50:34 --> Final output sent to browser
DEBUG - 2021-06-30 11:50:34 --> Total execution time: 0.1173
INFO - 2021-06-30 11:50:45 --> Config Class Initialized
INFO - 2021-06-30 11:50:45 --> Hooks Class Initialized
DEBUG - 2021-06-30 11:50:45 --> UTF-8 Support Enabled
INFO - 2021-06-30 11:50:45 --> Utf8 Class Initialized
INFO - 2021-06-30 11:50:45 --> URI Class Initialized
INFO - 2021-06-30 11:50:45 --> Router Class Initialized
INFO - 2021-06-30 11:50:45 --> Output Class Initialized
INFO - 2021-06-30 11:50:45 --> Security Class Initialized
DEBUG - 2021-06-30 11:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 11:50:45 --> Input Class Initialized
INFO - 2021-06-30 11:50:45 --> Language Class Initialized
INFO - 2021-06-30 11:50:45 --> Loader Class Initialized
INFO - 2021-06-30 11:50:45 --> Helper loaded: html_helper
INFO - 2021-06-30 11:50:45 --> Helper loaded: url_helper
INFO - 2021-06-30 11:50:45 --> Helper loaded: form_helper
INFO - 2021-06-30 11:50:45 --> Database Driver Class Initialized
INFO - 2021-06-30 11:50:45 --> Form Validation Class Initialized
DEBUG - 2021-06-30 11:50:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 11:50:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 11:50:45 --> Encryption Class Initialized
INFO - 2021-06-30 11:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 11:50:45 --> Model "vendor_model" initialized
INFO - 2021-06-30 11:50:45 --> Model "coupon_model" initialized
INFO - 2021-06-30 11:50:45 --> Model "user_model" initialized
INFO - 2021-06-30 11:50:45 --> Model "role_model" initialized
INFO - 2021-06-30 11:50:45 --> Controller Class Initialized
INFO - 2021-06-30 11:50:45 --> Helper loaded: language_helper
INFO - 2021-06-30 11:50:45 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 11:50:45 --> Model "Customer_model" initialized
INFO - 2021-06-30 11:50:45 --> Model "Product_model" initialized
INFO - 2021-06-30 11:50:45 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 11:50:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 11:50:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 11:50:46 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 11:50:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 11:50:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 11:50:46 --> Final output sent to browser
DEBUG - 2021-06-30 11:50:46 --> Total execution time: 0.0810
INFO - 2021-06-30 12:03:24 --> Config Class Initialized
INFO - 2021-06-30 12:03:24 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:03:24 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:03:24 --> Utf8 Class Initialized
INFO - 2021-06-30 12:03:24 --> URI Class Initialized
INFO - 2021-06-30 12:03:24 --> Router Class Initialized
INFO - 2021-06-30 12:03:24 --> Output Class Initialized
INFO - 2021-06-30 12:03:24 --> Security Class Initialized
DEBUG - 2021-06-30 12:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:03:24 --> Input Class Initialized
INFO - 2021-06-30 12:03:24 --> Language Class Initialized
INFO - 2021-06-30 12:03:24 --> Loader Class Initialized
INFO - 2021-06-30 12:03:24 --> Helper loaded: html_helper
INFO - 2021-06-30 12:03:24 --> Helper loaded: url_helper
INFO - 2021-06-30 12:03:24 --> Helper loaded: form_helper
INFO - 2021-06-30 12:03:24 --> Database Driver Class Initialized
INFO - 2021-06-30 12:03:24 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:03:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:03:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:03:24 --> Encryption Class Initialized
INFO - 2021-06-30 12:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:03:24 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:03:24 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:03:24 --> Model "user_model" initialized
INFO - 2021-06-30 12:03:24 --> Model "role_model" initialized
INFO - 2021-06-30 12:03:24 --> Controller Class Initialized
INFO - 2021-06-30 12:03:24 --> Helper loaded: language_helper
INFO - 2021-06-30 12:03:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:03:24 --> Model "Customer_model" initialized
INFO - 2021-06-30 12:03:24 --> Model "Product_model" initialized
INFO - 2021-06-30 12:03:24 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 12:03:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 12:03:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 12:03:24 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 12:03:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 12:03:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 12:03:24 --> Final output sent to browser
DEBUG - 2021-06-30 12:03:24 --> Total execution time: 0.1017
INFO - 2021-06-30 12:03:33 --> Config Class Initialized
INFO - 2021-06-30 12:03:33 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:03:33 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:03:33 --> Utf8 Class Initialized
INFO - 2021-06-30 12:03:33 --> URI Class Initialized
INFO - 2021-06-30 12:03:33 --> Router Class Initialized
INFO - 2021-06-30 12:03:33 --> Output Class Initialized
INFO - 2021-06-30 12:03:33 --> Security Class Initialized
DEBUG - 2021-06-30 12:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:03:33 --> Input Class Initialized
INFO - 2021-06-30 12:03:33 --> Language Class Initialized
INFO - 2021-06-30 12:03:33 --> Loader Class Initialized
INFO - 2021-06-30 12:03:33 --> Helper loaded: html_helper
INFO - 2021-06-30 12:03:33 --> Helper loaded: url_helper
INFO - 2021-06-30 12:03:33 --> Helper loaded: form_helper
INFO - 2021-06-30 12:03:33 --> Database Driver Class Initialized
INFO - 2021-06-30 12:03:33 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:03:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:03:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:03:33 --> Encryption Class Initialized
INFO - 2021-06-30 12:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:03:33 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:03:33 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:03:33 --> Model "user_model" initialized
INFO - 2021-06-30 12:03:33 --> Model "role_model" initialized
INFO - 2021-06-30 12:03:33 --> Controller Class Initialized
INFO - 2021-06-30 12:03:33 --> Helper loaded: language_helper
INFO - 2021-06-30 12:03:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:03:33 --> Model "Customer_model" initialized
INFO - 2021-06-30 12:03:33 --> Final output sent to browser
DEBUG - 2021-06-30 12:03:33 --> Total execution time: 0.0751
INFO - 2021-06-30 12:03:53 --> Config Class Initialized
INFO - 2021-06-30 12:03:53 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:03:53 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:03:53 --> Utf8 Class Initialized
INFO - 2021-06-30 12:03:53 --> URI Class Initialized
INFO - 2021-06-30 12:03:53 --> Router Class Initialized
INFO - 2021-06-30 12:03:53 --> Output Class Initialized
INFO - 2021-06-30 12:03:53 --> Security Class Initialized
DEBUG - 2021-06-30 12:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:03:53 --> Input Class Initialized
INFO - 2021-06-30 12:03:53 --> Language Class Initialized
INFO - 2021-06-30 12:03:53 --> Loader Class Initialized
INFO - 2021-06-30 12:03:53 --> Helper loaded: html_helper
INFO - 2021-06-30 12:03:53 --> Helper loaded: url_helper
INFO - 2021-06-30 12:03:53 --> Helper loaded: form_helper
INFO - 2021-06-30 12:03:53 --> Database Driver Class Initialized
INFO - 2021-06-30 12:03:53 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:03:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:03:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:03:53 --> Encryption Class Initialized
INFO - 2021-06-30 12:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:03:53 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:03:53 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:03:53 --> Model "user_model" initialized
INFO - 2021-06-30 12:03:53 --> Model "role_model" initialized
INFO - 2021-06-30 12:03:53 --> Controller Class Initialized
INFO - 2021-06-30 12:03:53 --> Helper loaded: language_helper
INFO - 2021-06-30 12:03:53 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:03:53 --> Model "Product_model" initialized
INFO - 2021-06-30 12:03:53 --> Final output sent to browser
DEBUG - 2021-06-30 12:03:53 --> Total execution time: 0.0765
INFO - 2021-06-30 12:04:04 --> Config Class Initialized
INFO - 2021-06-30 12:04:04 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:04:04 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:04:04 --> Utf8 Class Initialized
INFO - 2021-06-30 12:04:04 --> URI Class Initialized
INFO - 2021-06-30 12:04:04 --> Router Class Initialized
INFO - 2021-06-30 12:04:04 --> Output Class Initialized
INFO - 2021-06-30 12:04:04 --> Security Class Initialized
DEBUG - 2021-06-30 12:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:04:04 --> Input Class Initialized
INFO - 2021-06-30 12:04:04 --> Language Class Initialized
INFO - 2021-06-30 12:04:04 --> Loader Class Initialized
INFO - 2021-06-30 12:04:04 --> Helper loaded: html_helper
INFO - 2021-06-30 12:04:04 --> Helper loaded: url_helper
INFO - 2021-06-30 12:04:04 --> Helper loaded: form_helper
INFO - 2021-06-30 12:04:04 --> Database Driver Class Initialized
INFO - 2021-06-30 12:04:04 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:04:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:04:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:04:04 --> Encryption Class Initialized
INFO - 2021-06-30 12:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:04:04 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:04:04 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:04:04 --> Model "user_model" initialized
INFO - 2021-06-30 12:04:04 --> Model "role_model" initialized
INFO - 2021-06-30 12:04:04 --> Controller Class Initialized
INFO - 2021-06-30 12:04:04 --> Helper loaded: language_helper
INFO - 2021-06-30 12:04:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:04:04 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:04:04 --> Final output sent to browser
DEBUG - 2021-06-30 12:04:04 --> Total execution time: 0.1172
INFO - 2021-06-30 12:16:20 --> Config Class Initialized
INFO - 2021-06-30 12:16:20 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:16:20 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:16:20 --> Utf8 Class Initialized
INFO - 2021-06-30 12:16:20 --> URI Class Initialized
INFO - 2021-06-30 12:16:20 --> Router Class Initialized
INFO - 2021-06-30 12:16:20 --> Output Class Initialized
INFO - 2021-06-30 12:16:20 --> Security Class Initialized
DEBUG - 2021-06-30 12:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:16:20 --> Input Class Initialized
INFO - 2021-06-30 12:16:20 --> Language Class Initialized
INFO - 2021-06-30 12:16:20 --> Loader Class Initialized
INFO - 2021-06-30 12:16:20 --> Helper loaded: html_helper
INFO - 2021-06-30 12:16:20 --> Helper loaded: url_helper
INFO - 2021-06-30 12:16:20 --> Helper loaded: form_helper
INFO - 2021-06-30 12:16:20 --> Database Driver Class Initialized
INFO - 2021-06-30 12:16:20 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:16:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:16:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:16:20 --> Encryption Class Initialized
INFO - 2021-06-30 12:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:16:20 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:16:20 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:16:20 --> Model "user_model" initialized
INFO - 2021-06-30 12:16:20 --> Model "role_model" initialized
INFO - 2021-06-30 12:16:20 --> Controller Class Initialized
INFO - 2021-06-30 12:16:20 --> Helper loaded: language_helper
INFO - 2021-06-30 12:16:20 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:16:20 --> Model "Customer_model" initialized
INFO - 2021-06-30 12:16:20 --> Model "Product_model" initialized
INFO - 2021-06-30 12:16:20 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 12:16:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 12:16:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 12:16:20 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 12:16:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 12:16:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 12:16:20 --> Final output sent to browser
DEBUG - 2021-06-30 12:16:20 --> Total execution time: 0.1492
INFO - 2021-06-30 12:16:26 --> Config Class Initialized
INFO - 2021-06-30 12:16:26 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:16:26 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:16:26 --> Utf8 Class Initialized
INFO - 2021-06-30 12:16:26 --> URI Class Initialized
INFO - 2021-06-30 12:16:26 --> Router Class Initialized
INFO - 2021-06-30 12:16:26 --> Output Class Initialized
INFO - 2021-06-30 12:16:26 --> Security Class Initialized
DEBUG - 2021-06-30 12:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:16:26 --> Input Class Initialized
INFO - 2021-06-30 12:16:26 --> Language Class Initialized
INFO - 2021-06-30 12:16:26 --> Loader Class Initialized
INFO - 2021-06-30 12:16:26 --> Helper loaded: html_helper
INFO - 2021-06-30 12:16:26 --> Helper loaded: url_helper
INFO - 2021-06-30 12:16:26 --> Helper loaded: form_helper
INFO - 2021-06-30 12:16:26 --> Database Driver Class Initialized
INFO - 2021-06-30 12:16:26 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:16:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:16:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:16:26 --> Encryption Class Initialized
INFO - 2021-06-30 12:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:16:26 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:16:26 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:16:26 --> Model "user_model" initialized
INFO - 2021-06-30 12:16:26 --> Model "role_model" initialized
INFO - 2021-06-30 12:16:26 --> Controller Class Initialized
INFO - 2021-06-30 12:16:26 --> Helper loaded: language_helper
INFO - 2021-06-30 12:16:26 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:16:26 --> Model "Customer_model" initialized
INFO - 2021-06-30 12:16:26 --> Final output sent to browser
DEBUG - 2021-06-30 12:16:26 --> Total execution time: 0.0637
INFO - 2021-06-30 12:16:47 --> Config Class Initialized
INFO - 2021-06-30 12:16:47 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:16:47 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:16:47 --> Utf8 Class Initialized
INFO - 2021-06-30 12:16:47 --> URI Class Initialized
INFO - 2021-06-30 12:16:47 --> Router Class Initialized
INFO - 2021-06-30 12:16:47 --> Output Class Initialized
INFO - 2021-06-30 12:16:47 --> Security Class Initialized
DEBUG - 2021-06-30 12:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:16:47 --> Input Class Initialized
INFO - 2021-06-30 12:16:47 --> Language Class Initialized
INFO - 2021-06-30 12:16:47 --> Loader Class Initialized
INFO - 2021-06-30 12:16:47 --> Helper loaded: html_helper
INFO - 2021-06-30 12:16:47 --> Helper loaded: url_helper
INFO - 2021-06-30 12:16:47 --> Helper loaded: form_helper
INFO - 2021-06-30 12:16:47 --> Database Driver Class Initialized
INFO - 2021-06-30 12:16:47 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:16:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:16:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:16:47 --> Encryption Class Initialized
INFO - 2021-06-30 12:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:16:47 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:16:47 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:16:47 --> Model "user_model" initialized
INFO - 2021-06-30 12:16:47 --> Model "role_model" initialized
INFO - 2021-06-30 12:16:47 --> Controller Class Initialized
INFO - 2021-06-30 12:16:47 --> Helper loaded: language_helper
INFO - 2021-06-30 12:16:47 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:16:47 --> Model "Product_model" initialized
INFO - 2021-06-30 12:16:47 --> Final output sent to browser
DEBUG - 2021-06-30 12:16:47 --> Total execution time: 0.0615
INFO - 2021-06-30 12:17:00 --> Config Class Initialized
INFO - 2021-06-30 12:17:00 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:17:00 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:17:00 --> Utf8 Class Initialized
INFO - 2021-06-30 12:17:00 --> URI Class Initialized
INFO - 2021-06-30 12:17:00 --> Router Class Initialized
INFO - 2021-06-30 12:17:00 --> Output Class Initialized
INFO - 2021-06-30 12:17:00 --> Security Class Initialized
DEBUG - 2021-06-30 12:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:17:00 --> Input Class Initialized
INFO - 2021-06-30 12:17:00 --> Language Class Initialized
INFO - 2021-06-30 12:17:00 --> Loader Class Initialized
INFO - 2021-06-30 12:17:00 --> Helper loaded: html_helper
INFO - 2021-06-30 12:17:00 --> Helper loaded: url_helper
INFO - 2021-06-30 12:17:00 --> Helper loaded: form_helper
INFO - 2021-06-30 12:17:00 --> Database Driver Class Initialized
INFO - 2021-06-30 12:17:00 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:17:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:17:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:17:00 --> Encryption Class Initialized
INFO - 2021-06-30 12:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:17:00 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:17:00 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:17:00 --> Model "user_model" initialized
INFO - 2021-06-30 12:17:00 --> Model "role_model" initialized
INFO - 2021-06-30 12:17:00 --> Controller Class Initialized
INFO - 2021-06-30 12:17:00 --> Helper loaded: language_helper
INFO - 2021-06-30 12:17:00 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:17:00 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:17:00 --> Final output sent to browser
DEBUG - 2021-06-30 12:17:00 --> Total execution time: 0.0803
INFO - 2021-06-30 12:17:35 --> Config Class Initialized
INFO - 2021-06-30 12:17:35 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:17:35 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:17:35 --> Utf8 Class Initialized
INFO - 2021-06-30 12:17:35 --> URI Class Initialized
INFO - 2021-06-30 12:17:35 --> Router Class Initialized
INFO - 2021-06-30 12:17:35 --> Output Class Initialized
INFO - 2021-06-30 12:17:35 --> Security Class Initialized
DEBUG - 2021-06-30 12:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:17:35 --> Input Class Initialized
INFO - 2021-06-30 12:17:35 --> Language Class Initialized
INFO - 2021-06-30 12:17:35 --> Loader Class Initialized
INFO - 2021-06-30 12:17:35 --> Helper loaded: html_helper
INFO - 2021-06-30 12:17:35 --> Helper loaded: url_helper
INFO - 2021-06-30 12:17:35 --> Helper loaded: form_helper
INFO - 2021-06-30 12:17:35 --> Database Driver Class Initialized
INFO - 2021-06-30 12:17:35 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:17:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:17:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:17:35 --> Encryption Class Initialized
INFO - 2021-06-30 12:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:17:35 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:17:35 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:17:35 --> Model "user_model" initialized
INFO - 2021-06-30 12:17:35 --> Model "role_model" initialized
INFO - 2021-06-30 12:17:35 --> Controller Class Initialized
INFO - 2021-06-30 12:17:35 --> Helper loaded: language_helper
INFO - 2021-06-30 12:17:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:17:35 --> Model "Customer_model" initialized
INFO - 2021-06-30 12:17:35 --> Model "Product_model" initialized
INFO - 2021-06-30 12:17:35 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 12:17:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 12:17:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 12:17:35 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 12:17:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 12:17:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 12:17:35 --> Final output sent to browser
DEBUG - 2021-06-30 12:17:35 --> Total execution time: 0.1194
INFO - 2021-06-30 12:17:49 --> Config Class Initialized
INFO - 2021-06-30 12:17:49 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:17:49 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:17:49 --> Utf8 Class Initialized
INFO - 2021-06-30 12:17:49 --> URI Class Initialized
INFO - 2021-06-30 12:17:49 --> Router Class Initialized
INFO - 2021-06-30 12:17:49 --> Output Class Initialized
INFO - 2021-06-30 12:17:49 --> Security Class Initialized
DEBUG - 2021-06-30 12:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:17:49 --> Input Class Initialized
INFO - 2021-06-30 12:17:49 --> Language Class Initialized
INFO - 2021-06-30 12:17:49 --> Loader Class Initialized
INFO - 2021-06-30 12:17:49 --> Helper loaded: html_helper
INFO - 2021-06-30 12:17:49 --> Helper loaded: url_helper
INFO - 2021-06-30 12:17:49 --> Helper loaded: form_helper
INFO - 2021-06-30 12:17:49 --> Database Driver Class Initialized
INFO - 2021-06-30 12:17:49 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:17:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:17:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:17:49 --> Encryption Class Initialized
INFO - 2021-06-30 12:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:17:49 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:17:49 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:17:49 --> Model "user_model" initialized
INFO - 2021-06-30 12:17:49 --> Model "role_model" initialized
INFO - 2021-06-30 12:17:49 --> Controller Class Initialized
INFO - 2021-06-30 12:17:49 --> Helper loaded: language_helper
INFO - 2021-06-30 12:17:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:17:49 --> Model "Customer_model" initialized
INFO - 2021-06-30 12:17:49 --> Model "Product_model" initialized
INFO - 2021-06-30 12:17:49 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 12:17:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 12:17:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 12:17:49 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 12:17:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 12:17:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 12:17:49 --> Final output sent to browser
DEBUG - 2021-06-30 12:17:49 --> Total execution time: 0.0733
INFO - 2021-06-30 12:18:31 --> Config Class Initialized
INFO - 2021-06-30 12:18:31 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:18:31 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:18:31 --> Utf8 Class Initialized
INFO - 2021-06-30 12:18:31 --> URI Class Initialized
INFO - 2021-06-30 12:18:31 --> Router Class Initialized
INFO - 2021-06-30 12:18:31 --> Output Class Initialized
INFO - 2021-06-30 12:18:31 --> Security Class Initialized
DEBUG - 2021-06-30 12:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:18:31 --> Input Class Initialized
INFO - 2021-06-30 12:18:31 --> Language Class Initialized
INFO - 2021-06-30 12:18:31 --> Loader Class Initialized
INFO - 2021-06-30 12:18:31 --> Helper loaded: html_helper
INFO - 2021-06-30 12:18:31 --> Helper loaded: url_helper
INFO - 2021-06-30 12:18:31 --> Helper loaded: form_helper
INFO - 2021-06-30 12:18:31 --> Database Driver Class Initialized
INFO - 2021-06-30 12:18:31 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:18:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:18:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:18:31 --> Encryption Class Initialized
INFO - 2021-06-30 12:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:18:31 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:18:31 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:18:31 --> Model "user_model" initialized
INFO - 2021-06-30 12:18:31 --> Model "role_model" initialized
INFO - 2021-06-30 12:18:31 --> Controller Class Initialized
INFO - 2021-06-30 12:18:31 --> Helper loaded: language_helper
INFO - 2021-06-30 12:18:31 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:18:31 --> Model "Customer_model" initialized
INFO - 2021-06-30 12:18:31 --> Model "Product_model" initialized
INFO - 2021-06-30 12:18:31 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 12:18:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 12:18:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 12:18:31 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 12:18:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 12:18:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 12:18:31 --> Final output sent to browser
DEBUG - 2021-06-30 12:18:31 --> Total execution time: 0.1136
INFO - 2021-06-30 12:18:53 --> Config Class Initialized
INFO - 2021-06-30 12:18:53 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:18:53 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:18:53 --> Utf8 Class Initialized
INFO - 2021-06-30 12:18:53 --> URI Class Initialized
INFO - 2021-06-30 12:18:53 --> Router Class Initialized
INFO - 2021-06-30 12:18:53 --> Output Class Initialized
INFO - 2021-06-30 12:18:53 --> Security Class Initialized
DEBUG - 2021-06-30 12:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:18:53 --> Input Class Initialized
INFO - 2021-06-30 12:18:53 --> Language Class Initialized
INFO - 2021-06-30 12:18:53 --> Loader Class Initialized
INFO - 2021-06-30 12:18:53 --> Helper loaded: html_helper
INFO - 2021-06-30 12:18:53 --> Helper loaded: url_helper
INFO - 2021-06-30 12:18:53 --> Helper loaded: form_helper
INFO - 2021-06-30 12:18:53 --> Database Driver Class Initialized
INFO - 2021-06-30 12:18:53 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:18:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:18:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:18:53 --> Encryption Class Initialized
INFO - 2021-06-30 12:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:18:53 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:18:53 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:18:53 --> Model "user_model" initialized
INFO - 2021-06-30 12:18:53 --> Model "role_model" initialized
INFO - 2021-06-30 12:18:53 --> Controller Class Initialized
INFO - 2021-06-30 12:18:53 --> Helper loaded: language_helper
INFO - 2021-06-30 12:18:53 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:18:53 --> Model "Customer_model" initialized
INFO - 2021-06-30 12:18:53 --> Model "Product_model" initialized
INFO - 2021-06-30 12:18:53 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 12:18:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 12:18:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 12:18:53 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 12:18:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 12:18:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 12:18:53 --> Final output sent to browser
DEBUG - 2021-06-30 12:18:53 --> Total execution time: 0.1074
INFO - 2021-06-30 12:19:17 --> Config Class Initialized
INFO - 2021-06-30 12:19:17 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:19:17 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:19:17 --> Utf8 Class Initialized
INFO - 2021-06-30 12:19:17 --> URI Class Initialized
INFO - 2021-06-30 12:19:17 --> Router Class Initialized
INFO - 2021-06-30 12:19:17 --> Output Class Initialized
INFO - 2021-06-30 12:19:17 --> Security Class Initialized
DEBUG - 2021-06-30 12:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:19:17 --> Input Class Initialized
INFO - 2021-06-30 12:19:17 --> Language Class Initialized
INFO - 2021-06-30 12:19:17 --> Loader Class Initialized
INFO - 2021-06-30 12:19:17 --> Helper loaded: html_helper
INFO - 2021-06-30 12:19:17 --> Helper loaded: url_helper
INFO - 2021-06-30 12:19:17 --> Helper loaded: form_helper
INFO - 2021-06-30 12:19:17 --> Database Driver Class Initialized
INFO - 2021-06-30 12:19:17 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:19:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:19:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:19:17 --> Encryption Class Initialized
INFO - 2021-06-30 12:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:19:17 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:19:17 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:19:17 --> Model "user_model" initialized
INFO - 2021-06-30 12:19:17 --> Model "role_model" initialized
INFO - 2021-06-30 12:19:17 --> Controller Class Initialized
INFO - 2021-06-30 12:19:17 --> Helper loaded: language_helper
INFO - 2021-06-30 12:19:17 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:19:17 --> Model "Customer_model" initialized
INFO - 2021-06-30 12:19:17 --> Model "Product_model" initialized
INFO - 2021-06-30 12:19:17 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 12:19:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 12:19:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 12:19:17 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 12:19:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 12:19:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 12:19:17 --> Final output sent to browser
DEBUG - 2021-06-30 12:19:17 --> Total execution time: 0.1061
INFO - 2021-06-30 12:19:30 --> Config Class Initialized
INFO - 2021-06-30 12:19:30 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:19:30 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:19:30 --> Utf8 Class Initialized
INFO - 2021-06-30 12:19:30 --> URI Class Initialized
INFO - 2021-06-30 12:19:30 --> Router Class Initialized
INFO - 2021-06-30 12:19:30 --> Output Class Initialized
INFO - 2021-06-30 12:19:30 --> Security Class Initialized
DEBUG - 2021-06-30 12:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:19:30 --> Input Class Initialized
INFO - 2021-06-30 12:19:30 --> Language Class Initialized
INFO - 2021-06-30 12:19:30 --> Loader Class Initialized
INFO - 2021-06-30 12:19:30 --> Helper loaded: html_helper
INFO - 2021-06-30 12:19:30 --> Helper loaded: url_helper
INFO - 2021-06-30 12:19:30 --> Helper loaded: form_helper
INFO - 2021-06-30 12:19:30 --> Database Driver Class Initialized
INFO - 2021-06-30 12:19:30 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:19:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:19:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:19:30 --> Encryption Class Initialized
INFO - 2021-06-30 12:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:19:30 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:19:30 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:19:30 --> Model "user_model" initialized
INFO - 2021-06-30 12:19:30 --> Model "role_model" initialized
INFO - 2021-06-30 12:19:30 --> Controller Class Initialized
INFO - 2021-06-30 12:19:30 --> Helper loaded: language_helper
INFO - 2021-06-30 12:19:30 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:19:30 --> Model "Customer_model" initialized
INFO - 2021-06-30 12:19:30 --> Model "Product_model" initialized
INFO - 2021-06-30 12:19:30 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 12:19:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 12:19:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 12:19:30 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 12:19:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 12:19:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 12:19:30 --> Final output sent to browser
DEBUG - 2021-06-30 12:19:30 --> Total execution time: 0.1074
INFO - 2021-06-30 12:19:37 --> Config Class Initialized
INFO - 2021-06-30 12:19:37 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:19:37 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:19:37 --> Utf8 Class Initialized
INFO - 2021-06-30 12:19:37 --> URI Class Initialized
INFO - 2021-06-30 12:19:37 --> Router Class Initialized
INFO - 2021-06-30 12:19:37 --> Output Class Initialized
INFO - 2021-06-30 12:19:37 --> Security Class Initialized
DEBUG - 2021-06-30 12:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:19:37 --> Input Class Initialized
INFO - 2021-06-30 12:19:37 --> Language Class Initialized
INFO - 2021-06-30 12:19:37 --> Loader Class Initialized
INFO - 2021-06-30 12:19:37 --> Helper loaded: html_helper
INFO - 2021-06-30 12:19:37 --> Helper loaded: url_helper
INFO - 2021-06-30 12:19:37 --> Helper loaded: form_helper
INFO - 2021-06-30 12:19:37 --> Database Driver Class Initialized
INFO - 2021-06-30 12:19:37 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:19:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:19:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:19:37 --> Encryption Class Initialized
INFO - 2021-06-30 12:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:19:37 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:19:37 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:19:37 --> Model "user_model" initialized
INFO - 2021-06-30 12:19:37 --> Model "role_model" initialized
INFO - 2021-06-30 12:19:37 --> Controller Class Initialized
INFO - 2021-06-30 12:19:37 --> Helper loaded: language_helper
INFO - 2021-06-30 12:19:37 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:19:37 --> Model "Customer_model" initialized
INFO - 2021-06-30 12:19:37 --> Model "Product_model" initialized
INFO - 2021-06-30 12:19:37 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 12:19:37 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:19:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 12:19:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 12:19:37 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Invoices\create_invoice.php 33
INFO - 2021-06-30 12:19:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Invoices/create_invoice.php
INFO - 2021-06-30 12:19:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 12:19:37 --> Final output sent to browser
DEBUG - 2021-06-30 12:19:37 --> Total execution time: 0.1665
INFO - 2021-06-30 12:19:42 --> Config Class Initialized
INFO - 2021-06-30 12:19:42 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:19:42 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:19:42 --> Utf8 Class Initialized
INFO - 2021-06-30 12:19:42 --> URI Class Initialized
INFO - 2021-06-30 12:19:42 --> Router Class Initialized
INFO - 2021-06-30 12:19:42 --> Output Class Initialized
INFO - 2021-06-30 12:19:42 --> Security Class Initialized
DEBUG - 2021-06-30 12:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:19:42 --> Input Class Initialized
INFO - 2021-06-30 12:19:42 --> Language Class Initialized
INFO - 2021-06-30 12:19:42 --> Loader Class Initialized
INFO - 2021-06-30 12:19:42 --> Helper loaded: html_helper
INFO - 2021-06-30 12:19:42 --> Helper loaded: url_helper
INFO - 2021-06-30 12:19:42 --> Helper loaded: form_helper
INFO - 2021-06-30 12:19:42 --> Database Driver Class Initialized
INFO - 2021-06-30 12:19:42 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:19:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:19:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:19:42 --> Encryption Class Initialized
INFO - 2021-06-30 12:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:19:42 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:19:42 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:19:42 --> Model "user_model" initialized
INFO - 2021-06-30 12:19:42 --> Model "role_model" initialized
INFO - 2021-06-30 12:19:42 --> Controller Class Initialized
INFO - 2021-06-30 12:19:42 --> Helper loaded: language_helper
INFO - 2021-06-30 12:19:42 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:19:42 --> Model "Customer_model" initialized
INFO - 2021-06-30 12:19:42 --> Model "Product_model" initialized
INFO - 2021-06-30 12:19:42 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 12:19:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 12:19:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 12:19:42 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 12:19:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 12:19:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 12:19:42 --> Final output sent to browser
DEBUG - 2021-06-30 12:19:42 --> Total execution time: 0.0757
INFO - 2021-06-30 12:19:50 --> Config Class Initialized
INFO - 2021-06-30 12:19:50 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:19:50 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:19:50 --> Utf8 Class Initialized
INFO - 2021-06-30 12:19:50 --> URI Class Initialized
INFO - 2021-06-30 12:19:50 --> Router Class Initialized
INFO - 2021-06-30 12:19:50 --> Output Class Initialized
INFO - 2021-06-30 12:19:50 --> Security Class Initialized
DEBUG - 2021-06-30 12:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:19:50 --> Input Class Initialized
INFO - 2021-06-30 12:19:50 --> Language Class Initialized
INFO - 2021-06-30 12:19:50 --> Loader Class Initialized
INFO - 2021-06-30 12:19:50 --> Helper loaded: html_helper
INFO - 2021-06-30 12:19:50 --> Helper loaded: url_helper
INFO - 2021-06-30 12:19:50 --> Helper loaded: form_helper
INFO - 2021-06-30 12:19:50 --> Database Driver Class Initialized
INFO - 2021-06-30 12:19:50 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:19:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:19:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:19:50 --> Encryption Class Initialized
INFO - 2021-06-30 12:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:19:50 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:19:50 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:19:50 --> Model "user_model" initialized
INFO - 2021-06-30 12:19:50 --> Model "role_model" initialized
INFO - 2021-06-30 12:19:50 --> Controller Class Initialized
INFO - 2021-06-30 12:19:50 --> Helper loaded: language_helper
INFO - 2021-06-30 12:19:50 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:19:50 --> Model "Customer_model" initialized
INFO - 2021-06-30 12:19:50 --> Final output sent to browser
DEBUG - 2021-06-30 12:19:50 --> Total execution time: 0.0697
INFO - 2021-06-30 12:20:22 --> Config Class Initialized
INFO - 2021-06-30 12:20:22 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:20:22 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:20:22 --> Utf8 Class Initialized
INFO - 2021-06-30 12:20:22 --> URI Class Initialized
INFO - 2021-06-30 12:20:22 --> Router Class Initialized
INFO - 2021-06-30 12:20:22 --> Output Class Initialized
INFO - 2021-06-30 12:20:22 --> Security Class Initialized
DEBUG - 2021-06-30 12:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:20:22 --> Input Class Initialized
INFO - 2021-06-30 12:20:22 --> Language Class Initialized
INFO - 2021-06-30 12:20:22 --> Loader Class Initialized
INFO - 2021-06-30 12:20:22 --> Helper loaded: html_helper
INFO - 2021-06-30 12:20:22 --> Helper loaded: url_helper
INFO - 2021-06-30 12:20:22 --> Helper loaded: form_helper
INFO - 2021-06-30 12:20:22 --> Database Driver Class Initialized
INFO - 2021-06-30 12:20:22 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:20:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:20:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:20:22 --> Encryption Class Initialized
INFO - 2021-06-30 12:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:20:22 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:20:22 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:20:22 --> Model "user_model" initialized
INFO - 2021-06-30 12:20:22 --> Model "role_model" initialized
INFO - 2021-06-30 12:20:22 --> Controller Class Initialized
INFO - 2021-06-30 12:20:22 --> Helper loaded: language_helper
INFO - 2021-06-30 12:20:22 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:20:22 --> Model "Product_model" initialized
INFO - 2021-06-30 12:20:22 --> Final output sent to browser
DEBUG - 2021-06-30 12:20:22 --> Total execution time: 0.0562
INFO - 2021-06-30 12:20:32 --> Config Class Initialized
INFO - 2021-06-30 12:20:32 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:20:32 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:20:32 --> Utf8 Class Initialized
INFO - 2021-06-30 12:20:32 --> URI Class Initialized
INFO - 2021-06-30 12:20:32 --> Router Class Initialized
INFO - 2021-06-30 12:20:32 --> Output Class Initialized
INFO - 2021-06-30 12:20:32 --> Security Class Initialized
DEBUG - 2021-06-30 12:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:20:32 --> Input Class Initialized
INFO - 2021-06-30 12:20:32 --> Language Class Initialized
INFO - 2021-06-30 12:20:32 --> Loader Class Initialized
INFO - 2021-06-30 12:20:32 --> Helper loaded: html_helper
INFO - 2021-06-30 12:20:32 --> Helper loaded: url_helper
INFO - 2021-06-30 12:20:32 --> Helper loaded: form_helper
INFO - 2021-06-30 12:20:32 --> Database Driver Class Initialized
INFO - 2021-06-30 12:20:32 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:20:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:20:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:20:32 --> Encryption Class Initialized
INFO - 2021-06-30 12:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:20:32 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:20:32 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:20:32 --> Model "user_model" initialized
INFO - 2021-06-30 12:20:32 --> Model "role_model" initialized
INFO - 2021-06-30 12:20:32 --> Controller Class Initialized
INFO - 2021-06-30 12:20:32 --> Helper loaded: language_helper
INFO - 2021-06-30 12:20:32 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:20:32 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:20:32 --> Final output sent to browser
DEBUG - 2021-06-30 12:20:32 --> Total execution time: 0.0689
INFO - 2021-06-30 12:20:35 --> Config Class Initialized
INFO - 2021-06-30 12:20:35 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:20:35 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:20:35 --> Utf8 Class Initialized
INFO - 2021-06-30 12:20:35 --> URI Class Initialized
INFO - 2021-06-30 12:20:35 --> Router Class Initialized
INFO - 2021-06-30 12:20:35 --> Output Class Initialized
INFO - 2021-06-30 12:20:35 --> Security Class Initialized
DEBUG - 2021-06-30 12:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:20:35 --> Input Class Initialized
INFO - 2021-06-30 12:20:35 --> Language Class Initialized
INFO - 2021-06-30 12:20:35 --> Loader Class Initialized
INFO - 2021-06-30 12:20:35 --> Helper loaded: html_helper
INFO - 2021-06-30 12:20:35 --> Helper loaded: url_helper
INFO - 2021-06-30 12:20:35 --> Helper loaded: form_helper
INFO - 2021-06-30 12:20:35 --> Database Driver Class Initialized
INFO - 2021-06-30 12:20:35 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:20:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:20:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:20:35 --> Encryption Class Initialized
INFO - 2021-06-30 12:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:20:35 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:20:35 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:20:35 --> Model "user_model" initialized
INFO - 2021-06-30 12:20:35 --> Model "role_model" initialized
INFO - 2021-06-30 12:20:35 --> Controller Class Initialized
INFO - 2021-06-30 12:20:35 --> Helper loaded: language_helper
INFO - 2021-06-30 12:20:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:20:35 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:20:35 --> Final output sent to browser
DEBUG - 2021-06-30 12:20:35 --> Total execution time: 0.0663
INFO - 2021-06-30 12:20:38 --> Config Class Initialized
INFO - 2021-06-30 12:20:38 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:20:38 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:20:38 --> Utf8 Class Initialized
INFO - 2021-06-30 12:20:38 --> URI Class Initialized
INFO - 2021-06-30 12:20:38 --> Router Class Initialized
INFO - 2021-06-30 12:20:38 --> Output Class Initialized
INFO - 2021-06-30 12:20:38 --> Security Class Initialized
DEBUG - 2021-06-30 12:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:20:38 --> Input Class Initialized
INFO - 2021-06-30 12:20:38 --> Language Class Initialized
INFO - 2021-06-30 12:20:38 --> Loader Class Initialized
INFO - 2021-06-30 12:20:38 --> Helper loaded: html_helper
INFO - 2021-06-30 12:20:38 --> Helper loaded: url_helper
INFO - 2021-06-30 12:20:38 --> Helper loaded: form_helper
INFO - 2021-06-30 12:20:38 --> Database Driver Class Initialized
INFO - 2021-06-30 12:20:38 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:20:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:20:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:20:38 --> Encryption Class Initialized
INFO - 2021-06-30 12:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:20:38 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:20:38 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:20:38 --> Model "user_model" initialized
INFO - 2021-06-30 12:20:38 --> Model "role_model" initialized
INFO - 2021-06-30 12:20:38 --> Controller Class Initialized
INFO - 2021-06-30 12:20:38 --> Helper loaded: language_helper
INFO - 2021-06-30 12:20:38 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:20:38 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:20:38 --> Final output sent to browser
DEBUG - 2021-06-30 12:20:38 --> Total execution time: 0.0627
INFO - 2021-06-30 12:23:48 --> Config Class Initialized
INFO - 2021-06-30 12:23:48 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:23:48 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:23:48 --> Utf8 Class Initialized
INFO - 2021-06-30 12:23:48 --> URI Class Initialized
INFO - 2021-06-30 12:23:48 --> Router Class Initialized
INFO - 2021-06-30 12:23:48 --> Output Class Initialized
INFO - 2021-06-30 12:23:48 --> Security Class Initialized
DEBUG - 2021-06-30 12:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:23:48 --> Input Class Initialized
INFO - 2021-06-30 12:23:48 --> Language Class Initialized
INFO - 2021-06-30 12:23:48 --> Loader Class Initialized
INFO - 2021-06-30 12:23:48 --> Helper loaded: html_helper
INFO - 2021-06-30 12:23:48 --> Helper loaded: url_helper
INFO - 2021-06-30 12:23:48 --> Helper loaded: form_helper
INFO - 2021-06-30 12:23:48 --> Database Driver Class Initialized
INFO - 2021-06-30 12:23:48 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:23:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:23:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:23:48 --> Encryption Class Initialized
INFO - 2021-06-30 12:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:23:48 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:23:48 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:23:48 --> Model "user_model" initialized
INFO - 2021-06-30 12:23:48 --> Model "role_model" initialized
INFO - 2021-06-30 12:23:48 --> Controller Class Initialized
INFO - 2021-06-30 12:23:48 --> Helper loaded: language_helper
INFO - 2021-06-30 12:23:48 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:23:48 --> Model "Customer_model" initialized
INFO - 2021-06-30 12:23:48 --> Model "Product_model" initialized
INFO - 2021-06-30 12:23:48 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 12:23:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 12:23:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 12:23:48 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 12:23:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 12:23:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 12:23:48 --> Final output sent to browser
DEBUG - 2021-06-30 12:23:48 --> Total execution time: 0.1149
INFO - 2021-06-30 12:24:22 --> Config Class Initialized
INFO - 2021-06-30 12:24:22 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:24:22 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:24:22 --> Utf8 Class Initialized
INFO - 2021-06-30 12:24:22 --> URI Class Initialized
INFO - 2021-06-30 12:24:22 --> Router Class Initialized
INFO - 2021-06-30 12:24:22 --> Output Class Initialized
INFO - 2021-06-30 12:24:22 --> Security Class Initialized
DEBUG - 2021-06-30 12:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:24:22 --> Input Class Initialized
INFO - 2021-06-30 12:24:22 --> Language Class Initialized
INFO - 2021-06-30 12:24:22 --> Loader Class Initialized
INFO - 2021-06-30 12:24:22 --> Helper loaded: html_helper
INFO - 2021-06-30 12:24:22 --> Helper loaded: url_helper
INFO - 2021-06-30 12:24:22 --> Helper loaded: form_helper
INFO - 2021-06-30 12:24:22 --> Database Driver Class Initialized
INFO - 2021-06-30 12:24:22 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:24:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:24:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:24:22 --> Encryption Class Initialized
INFO - 2021-06-30 12:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:24:22 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:24:22 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:24:22 --> Model "user_model" initialized
INFO - 2021-06-30 12:24:22 --> Model "role_model" initialized
INFO - 2021-06-30 12:24:22 --> Controller Class Initialized
INFO - 2021-06-30 12:24:22 --> Helper loaded: language_helper
INFO - 2021-06-30 12:24:22 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:24:22 --> Model "Customer_model" initialized
INFO - 2021-06-30 12:24:22 --> Model "Product_model" initialized
INFO - 2021-06-30 12:24:22 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 12:24:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 12:24:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 12:24:22 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 12:24:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 12:24:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 12:24:22 --> Final output sent to browser
DEBUG - 2021-06-30 12:24:22 --> Total execution time: 0.1151
INFO - 2021-06-30 12:25:32 --> Config Class Initialized
INFO - 2021-06-30 12:25:32 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:25:32 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:25:32 --> Utf8 Class Initialized
INFO - 2021-06-30 12:25:32 --> URI Class Initialized
INFO - 2021-06-30 12:25:32 --> Router Class Initialized
INFO - 2021-06-30 12:25:32 --> Output Class Initialized
INFO - 2021-06-30 12:25:32 --> Security Class Initialized
DEBUG - 2021-06-30 12:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:25:32 --> Input Class Initialized
INFO - 2021-06-30 12:25:32 --> Language Class Initialized
INFO - 2021-06-30 12:25:32 --> Loader Class Initialized
INFO - 2021-06-30 12:25:32 --> Helper loaded: html_helper
INFO - 2021-06-30 12:25:32 --> Helper loaded: url_helper
INFO - 2021-06-30 12:25:32 --> Helper loaded: form_helper
INFO - 2021-06-30 12:25:32 --> Database Driver Class Initialized
INFO - 2021-06-30 12:25:32 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:25:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:25:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:25:32 --> Encryption Class Initialized
INFO - 2021-06-30 12:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:25:32 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:25:32 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:25:32 --> Model "user_model" initialized
INFO - 2021-06-30 12:25:32 --> Model "role_model" initialized
INFO - 2021-06-30 12:25:32 --> Controller Class Initialized
INFO - 2021-06-30 12:25:32 --> Helper loaded: language_helper
INFO - 2021-06-30 12:25:32 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:25:32 --> Model "Customer_model" initialized
INFO - 2021-06-30 12:25:32 --> Model "Product_model" initialized
INFO - 2021-06-30 12:25:32 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 12:25:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 12:25:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 12:25:32 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 12:25:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 12:25:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 12:25:32 --> Final output sent to browser
DEBUG - 2021-06-30 12:25:32 --> Total execution time: 0.1150
INFO - 2021-06-30 12:25:40 --> Config Class Initialized
INFO - 2021-06-30 12:25:40 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:25:40 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:25:40 --> Utf8 Class Initialized
INFO - 2021-06-30 12:25:40 --> URI Class Initialized
INFO - 2021-06-30 12:25:40 --> Router Class Initialized
INFO - 2021-06-30 12:25:40 --> Output Class Initialized
INFO - 2021-06-30 12:25:40 --> Security Class Initialized
DEBUG - 2021-06-30 12:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:25:40 --> Input Class Initialized
INFO - 2021-06-30 12:25:40 --> Language Class Initialized
INFO - 2021-06-30 12:25:40 --> Loader Class Initialized
INFO - 2021-06-30 12:25:40 --> Helper loaded: html_helper
INFO - 2021-06-30 12:25:40 --> Helper loaded: url_helper
INFO - 2021-06-30 12:25:40 --> Helper loaded: form_helper
INFO - 2021-06-30 12:25:40 --> Database Driver Class Initialized
INFO - 2021-06-30 12:25:40 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:25:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:25:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:25:40 --> Encryption Class Initialized
INFO - 2021-06-30 12:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:25:40 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:25:40 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:25:40 --> Model "user_model" initialized
INFO - 2021-06-30 12:25:40 --> Model "role_model" initialized
INFO - 2021-06-30 12:25:40 --> Controller Class Initialized
INFO - 2021-06-30 12:25:40 --> Helper loaded: language_helper
INFO - 2021-06-30 12:25:40 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:25:40 --> Model "Customer_model" initialized
INFO - 2021-06-30 12:25:40 --> Final output sent to browser
DEBUG - 2021-06-30 12:25:40 --> Total execution time: 0.0625
INFO - 2021-06-30 12:25:59 --> Config Class Initialized
INFO - 2021-06-30 12:25:59 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:25:59 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:25:59 --> Utf8 Class Initialized
INFO - 2021-06-30 12:25:59 --> URI Class Initialized
INFO - 2021-06-30 12:25:59 --> Router Class Initialized
INFO - 2021-06-30 12:25:59 --> Output Class Initialized
INFO - 2021-06-30 12:25:59 --> Security Class Initialized
DEBUG - 2021-06-30 12:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:25:59 --> Input Class Initialized
INFO - 2021-06-30 12:25:59 --> Language Class Initialized
INFO - 2021-06-30 12:25:59 --> Loader Class Initialized
INFO - 2021-06-30 12:25:59 --> Helper loaded: html_helper
INFO - 2021-06-30 12:25:59 --> Helper loaded: url_helper
INFO - 2021-06-30 12:25:59 --> Helper loaded: form_helper
INFO - 2021-06-30 12:25:59 --> Database Driver Class Initialized
INFO - 2021-06-30 12:25:59 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:25:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:25:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:25:59 --> Encryption Class Initialized
INFO - 2021-06-30 12:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:25:59 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:25:59 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:25:59 --> Model "user_model" initialized
INFO - 2021-06-30 12:25:59 --> Model "role_model" initialized
INFO - 2021-06-30 12:25:59 --> Controller Class Initialized
INFO - 2021-06-30 12:25:59 --> Helper loaded: language_helper
INFO - 2021-06-30 12:25:59 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:25:59 --> Model "Product_model" initialized
INFO - 2021-06-30 12:25:59 --> Final output sent to browser
DEBUG - 2021-06-30 12:25:59 --> Total execution time: 0.0616
INFO - 2021-06-30 12:26:08 --> Config Class Initialized
INFO - 2021-06-30 12:26:08 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:26:08 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:26:08 --> Utf8 Class Initialized
INFO - 2021-06-30 12:26:08 --> URI Class Initialized
INFO - 2021-06-30 12:26:08 --> Router Class Initialized
INFO - 2021-06-30 12:26:08 --> Output Class Initialized
INFO - 2021-06-30 12:26:08 --> Security Class Initialized
DEBUG - 2021-06-30 12:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:26:08 --> Input Class Initialized
INFO - 2021-06-30 12:26:08 --> Language Class Initialized
INFO - 2021-06-30 12:26:08 --> Loader Class Initialized
INFO - 2021-06-30 12:26:08 --> Helper loaded: html_helper
INFO - 2021-06-30 12:26:08 --> Helper loaded: url_helper
INFO - 2021-06-30 12:26:08 --> Helper loaded: form_helper
INFO - 2021-06-30 12:26:08 --> Database Driver Class Initialized
INFO - 2021-06-30 12:26:08 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:26:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:26:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:26:08 --> Encryption Class Initialized
INFO - 2021-06-30 12:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:26:08 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:26:08 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:26:08 --> Model "user_model" initialized
INFO - 2021-06-30 12:26:08 --> Model "role_model" initialized
INFO - 2021-06-30 12:26:08 --> Controller Class Initialized
INFO - 2021-06-30 12:26:08 --> Helper loaded: language_helper
INFO - 2021-06-30 12:26:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:26:08 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:26:08 --> Final output sent to browser
DEBUG - 2021-06-30 12:26:08 --> Total execution time: 0.0700
INFO - 2021-06-30 12:26:21 --> Config Class Initialized
INFO - 2021-06-30 12:26:21 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:26:21 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:26:21 --> Utf8 Class Initialized
INFO - 2021-06-30 12:26:21 --> URI Class Initialized
INFO - 2021-06-30 12:26:21 --> Router Class Initialized
INFO - 2021-06-30 12:26:21 --> Output Class Initialized
INFO - 2021-06-30 12:26:21 --> Security Class Initialized
DEBUG - 2021-06-30 12:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:26:21 --> Input Class Initialized
INFO - 2021-06-30 12:26:21 --> Language Class Initialized
INFO - 2021-06-30 12:26:21 --> Loader Class Initialized
INFO - 2021-06-30 12:26:21 --> Helper loaded: html_helper
INFO - 2021-06-30 12:26:21 --> Helper loaded: url_helper
INFO - 2021-06-30 12:26:21 --> Helper loaded: form_helper
INFO - 2021-06-30 12:26:21 --> Database Driver Class Initialized
INFO - 2021-06-30 12:26:21 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:26:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:26:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:26:21 --> Encryption Class Initialized
INFO - 2021-06-30 12:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:26:21 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:26:21 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:26:21 --> Model "user_model" initialized
INFO - 2021-06-30 12:26:21 --> Model "role_model" initialized
INFO - 2021-06-30 12:26:21 --> Controller Class Initialized
INFO - 2021-06-30 12:26:21 --> Helper loaded: language_helper
INFO - 2021-06-30 12:26:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:26:21 --> Model "Customer_model" initialized
INFO - 2021-06-30 12:26:21 --> Model "Product_model" initialized
INFO - 2021-06-30 12:26:21 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 12:26:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 12:26:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 12:26:21 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 12:26:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 12:26:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 12:26:21 --> Final output sent to browser
DEBUG - 2021-06-30 12:26:21 --> Total execution time: 0.0771
INFO - 2021-06-30 12:26:37 --> Config Class Initialized
INFO - 2021-06-30 12:26:37 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:26:37 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:26:37 --> Utf8 Class Initialized
INFO - 2021-06-30 12:26:37 --> URI Class Initialized
INFO - 2021-06-30 12:26:37 --> Router Class Initialized
INFO - 2021-06-30 12:26:37 --> Output Class Initialized
INFO - 2021-06-30 12:26:37 --> Security Class Initialized
DEBUG - 2021-06-30 12:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:26:37 --> Input Class Initialized
INFO - 2021-06-30 12:26:37 --> Language Class Initialized
INFO - 2021-06-30 12:26:37 --> Loader Class Initialized
INFO - 2021-06-30 12:26:37 --> Helper loaded: html_helper
INFO - 2021-06-30 12:26:37 --> Helper loaded: url_helper
INFO - 2021-06-30 12:26:37 --> Helper loaded: form_helper
INFO - 2021-06-30 12:26:37 --> Database Driver Class Initialized
INFO - 2021-06-30 12:26:37 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:26:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:26:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:26:37 --> Encryption Class Initialized
INFO - 2021-06-30 12:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:26:37 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:26:37 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:26:37 --> Model "user_model" initialized
INFO - 2021-06-30 12:26:37 --> Model "role_model" initialized
INFO - 2021-06-30 12:26:37 --> Controller Class Initialized
INFO - 2021-06-30 12:26:37 --> Helper loaded: language_helper
INFO - 2021-06-30 12:26:37 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:26:37 --> Model "Customer_model" initialized
INFO - 2021-06-30 12:26:37 --> Model "Product_model" initialized
INFO - 2021-06-30 12:26:37 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 12:26:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 12:26:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 12:26:37 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 12:26:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 12:26:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 12:26:37 --> Final output sent to browser
DEBUG - 2021-06-30 12:26:37 --> Total execution time: 0.0760
INFO - 2021-06-30 12:26:39 --> Config Class Initialized
INFO - 2021-06-30 12:26:39 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:26:39 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:26:39 --> Utf8 Class Initialized
INFO - 2021-06-30 12:26:39 --> URI Class Initialized
INFO - 2021-06-30 12:26:39 --> Router Class Initialized
INFO - 2021-06-30 12:26:39 --> Output Class Initialized
INFO - 2021-06-30 12:26:39 --> Security Class Initialized
DEBUG - 2021-06-30 12:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:26:39 --> Input Class Initialized
INFO - 2021-06-30 12:26:39 --> Language Class Initialized
INFO - 2021-06-30 12:26:39 --> Loader Class Initialized
INFO - 2021-06-30 12:26:39 --> Helper loaded: html_helper
INFO - 2021-06-30 12:26:39 --> Helper loaded: url_helper
INFO - 2021-06-30 12:26:39 --> Helper loaded: form_helper
INFO - 2021-06-30 12:26:39 --> Database Driver Class Initialized
INFO - 2021-06-30 12:26:39 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:26:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:26:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:26:39 --> Encryption Class Initialized
INFO - 2021-06-30 12:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:26:39 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:26:39 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:26:39 --> Model "user_model" initialized
INFO - 2021-06-30 12:26:39 --> Model "role_model" initialized
INFO - 2021-06-30 12:26:39 --> Controller Class Initialized
INFO - 2021-06-30 12:26:39 --> Helper loaded: language_helper
INFO - 2021-06-30 12:26:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:26:39 --> Model "Customer_model" initialized
INFO - 2021-06-30 12:26:39 --> Model "Product_model" initialized
INFO - 2021-06-30 12:26:39 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 12:26:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 12:26:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 12:26:39 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 12:26:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 12:26:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 12:26:39 --> Final output sent to browser
DEBUG - 2021-06-30 12:26:39 --> Total execution time: 0.0785
INFO - 2021-06-30 12:26:43 --> Config Class Initialized
INFO - 2021-06-30 12:26:43 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:26:43 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:26:43 --> Utf8 Class Initialized
INFO - 2021-06-30 12:26:43 --> URI Class Initialized
INFO - 2021-06-30 12:26:43 --> Router Class Initialized
INFO - 2021-06-30 12:26:43 --> Output Class Initialized
INFO - 2021-06-30 12:26:43 --> Security Class Initialized
DEBUG - 2021-06-30 12:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:26:43 --> Input Class Initialized
INFO - 2021-06-30 12:26:43 --> Language Class Initialized
INFO - 2021-06-30 12:26:43 --> Loader Class Initialized
INFO - 2021-06-30 12:26:43 --> Helper loaded: html_helper
INFO - 2021-06-30 12:26:43 --> Helper loaded: url_helper
INFO - 2021-06-30 12:26:43 --> Helper loaded: form_helper
INFO - 2021-06-30 12:26:43 --> Database Driver Class Initialized
INFO - 2021-06-30 12:26:43 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:26:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:26:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:26:43 --> Encryption Class Initialized
INFO - 2021-06-30 12:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:26:43 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:26:43 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:26:43 --> Model "user_model" initialized
INFO - 2021-06-30 12:26:43 --> Model "role_model" initialized
INFO - 2021-06-30 12:26:43 --> Controller Class Initialized
INFO - 2021-06-30 12:26:43 --> Helper loaded: language_helper
INFO - 2021-06-30 12:26:43 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:26:43 --> Model "Customer_model" initialized
INFO - 2021-06-30 12:26:43 --> Final output sent to browser
DEBUG - 2021-06-30 12:26:43 --> Total execution time: 0.0640
INFO - 2021-06-30 12:27:16 --> Config Class Initialized
INFO - 2021-06-30 12:27:16 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:27:16 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:27:16 --> Utf8 Class Initialized
INFO - 2021-06-30 12:27:16 --> URI Class Initialized
INFO - 2021-06-30 12:27:16 --> Router Class Initialized
INFO - 2021-06-30 12:27:16 --> Output Class Initialized
INFO - 2021-06-30 12:27:16 --> Security Class Initialized
DEBUG - 2021-06-30 12:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:27:16 --> Input Class Initialized
INFO - 2021-06-30 12:27:16 --> Language Class Initialized
INFO - 2021-06-30 12:27:16 --> Loader Class Initialized
INFO - 2021-06-30 12:27:16 --> Helper loaded: html_helper
INFO - 2021-06-30 12:27:16 --> Helper loaded: url_helper
INFO - 2021-06-30 12:27:16 --> Helper loaded: form_helper
INFO - 2021-06-30 12:27:16 --> Database Driver Class Initialized
INFO - 2021-06-30 12:27:16 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:27:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:27:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:27:16 --> Encryption Class Initialized
INFO - 2021-06-30 12:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:27:16 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:27:16 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:27:16 --> Model "user_model" initialized
INFO - 2021-06-30 12:27:16 --> Model "role_model" initialized
INFO - 2021-06-30 12:27:16 --> Controller Class Initialized
INFO - 2021-06-30 12:27:16 --> Helper loaded: language_helper
INFO - 2021-06-30 12:27:16 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:27:16 --> Model "Product_model" initialized
INFO - 2021-06-30 12:27:16 --> Final output sent to browser
DEBUG - 2021-06-30 12:27:16 --> Total execution time: 0.0674
INFO - 2021-06-30 12:27:28 --> Config Class Initialized
INFO - 2021-06-30 12:27:28 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:27:28 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:27:28 --> Utf8 Class Initialized
INFO - 2021-06-30 12:27:28 --> URI Class Initialized
INFO - 2021-06-30 12:27:28 --> Router Class Initialized
INFO - 2021-06-30 12:27:28 --> Output Class Initialized
INFO - 2021-06-30 12:27:28 --> Security Class Initialized
DEBUG - 2021-06-30 12:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:27:28 --> Input Class Initialized
INFO - 2021-06-30 12:27:28 --> Language Class Initialized
INFO - 2021-06-30 12:27:28 --> Loader Class Initialized
INFO - 2021-06-30 12:27:28 --> Helper loaded: html_helper
INFO - 2021-06-30 12:27:28 --> Helper loaded: url_helper
INFO - 2021-06-30 12:27:28 --> Helper loaded: form_helper
INFO - 2021-06-30 12:27:28 --> Database Driver Class Initialized
INFO - 2021-06-30 12:27:28 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:27:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:27:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:27:28 --> Encryption Class Initialized
INFO - 2021-06-30 12:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:27:28 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:27:28 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:27:28 --> Model "user_model" initialized
INFO - 2021-06-30 12:27:28 --> Model "role_model" initialized
INFO - 2021-06-30 12:27:28 --> Controller Class Initialized
INFO - 2021-06-30 12:27:28 --> Helper loaded: language_helper
INFO - 2021-06-30 12:27:28 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:27:28 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:27:28 --> Final output sent to browser
DEBUG - 2021-06-30 12:27:28 --> Total execution time: 0.0702
INFO - 2021-06-30 12:27:28 --> Config Class Initialized
INFO - 2021-06-30 12:27:28 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:27:28 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:27:28 --> Utf8 Class Initialized
INFO - 2021-06-30 12:27:28 --> URI Class Initialized
INFO - 2021-06-30 12:27:28 --> Router Class Initialized
INFO - 2021-06-30 12:27:28 --> Output Class Initialized
INFO - 2021-06-30 12:27:28 --> Security Class Initialized
DEBUG - 2021-06-30 12:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:27:28 --> Input Class Initialized
INFO - 2021-06-30 12:27:28 --> Language Class Initialized
INFO - 2021-06-30 12:27:28 --> Loader Class Initialized
INFO - 2021-06-30 12:27:28 --> Helper loaded: html_helper
INFO - 2021-06-30 12:27:28 --> Helper loaded: url_helper
INFO - 2021-06-30 12:27:28 --> Helper loaded: form_helper
INFO - 2021-06-30 12:27:28 --> Database Driver Class Initialized
INFO - 2021-06-30 12:27:28 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:27:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:27:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:27:28 --> Encryption Class Initialized
INFO - 2021-06-30 12:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:27:28 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:27:28 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:27:28 --> Model "user_model" initialized
INFO - 2021-06-30 12:27:28 --> Model "role_model" initialized
INFO - 2021-06-30 12:27:28 --> Controller Class Initialized
INFO - 2021-06-30 12:27:28 --> Helper loaded: language_helper
INFO - 2021-06-30 12:27:28 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:27:28 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:27:28 --> Final output sent to browser
DEBUG - 2021-06-30 12:27:28 --> Total execution time: 0.0724
INFO - 2021-06-30 12:27:30 --> Config Class Initialized
INFO - 2021-06-30 12:27:30 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:27:30 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:27:30 --> Utf8 Class Initialized
INFO - 2021-06-30 12:27:30 --> URI Class Initialized
INFO - 2021-06-30 12:27:30 --> Router Class Initialized
INFO - 2021-06-30 12:27:30 --> Output Class Initialized
INFO - 2021-06-30 12:27:30 --> Security Class Initialized
DEBUG - 2021-06-30 12:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:27:30 --> Input Class Initialized
INFO - 2021-06-30 12:27:30 --> Language Class Initialized
INFO - 2021-06-30 12:27:30 --> Loader Class Initialized
INFO - 2021-06-30 12:27:30 --> Helper loaded: html_helper
INFO - 2021-06-30 12:27:30 --> Helper loaded: url_helper
INFO - 2021-06-30 12:27:30 --> Helper loaded: form_helper
INFO - 2021-06-30 12:27:30 --> Database Driver Class Initialized
INFO - 2021-06-30 12:27:30 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:27:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:27:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:27:30 --> Encryption Class Initialized
INFO - 2021-06-30 12:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:27:30 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:27:30 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:27:30 --> Model "user_model" initialized
INFO - 2021-06-30 12:27:30 --> Model "role_model" initialized
INFO - 2021-06-30 12:27:30 --> Controller Class Initialized
INFO - 2021-06-30 12:27:30 --> Helper loaded: language_helper
INFO - 2021-06-30 12:27:30 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:27:30 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:27:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 12:27:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 12:27:30 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-06-30 12:27:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-06-30 12:27:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 12:27:30 --> Final output sent to browser
DEBUG - 2021-06-30 12:27:30 --> Total execution time: 0.1720
INFO - 2021-06-30 12:27:31 --> Config Class Initialized
INFO - 2021-06-30 12:27:31 --> Hooks Class Initialized
INFO - 2021-06-30 12:27:31 --> Config Class Initialized
INFO - 2021-06-30 12:27:31 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:27:31 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:27:31 --> Utf8 Class Initialized
INFO - 2021-06-30 12:27:31 --> URI Class Initialized
DEBUG - 2021-06-30 12:27:31 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:27:31 --> Utf8 Class Initialized
INFO - 2021-06-30 12:27:31 --> Router Class Initialized
INFO - 2021-06-30 12:27:31 --> URI Class Initialized
INFO - 2021-06-30 12:27:31 --> Router Class Initialized
INFO - 2021-06-30 12:27:31 --> Output Class Initialized
INFO - 2021-06-30 12:27:31 --> Security Class Initialized
INFO - 2021-06-30 12:27:31 --> Output Class Initialized
INFO - 2021-06-30 12:27:31 --> Security Class Initialized
DEBUG - 2021-06-30 12:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:27:31 --> Input Class Initialized
INFO - 2021-06-30 12:27:31 --> Language Class Initialized
DEBUG - 2021-06-30 12:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:27:31 --> Input Class Initialized
INFO - 2021-06-30 12:27:31 --> Language Class Initialized
INFO - 2021-06-30 12:27:31 --> Loader Class Initialized
INFO - 2021-06-30 12:27:31 --> Helper loaded: html_helper
INFO - 2021-06-30 12:27:31 --> Loader Class Initialized
INFO - 2021-06-30 12:27:31 --> Helper loaded: url_helper
INFO - 2021-06-30 12:27:31 --> Helper loaded: html_helper
INFO - 2021-06-30 12:27:31 --> Helper loaded: url_helper
INFO - 2021-06-30 12:27:31 --> Helper loaded: form_helper
INFO - 2021-06-30 12:27:31 --> Helper loaded: form_helper
INFO - 2021-06-30 12:27:31 --> Database Driver Class Initialized
INFO - 2021-06-30 12:27:31 --> Database Driver Class Initialized
INFO - 2021-06-30 12:27:31 --> Form Validation Class Initialized
INFO - 2021-06-30 12:27:31 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:27:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:27:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:27:31 --> Encryption Class Initialized
DEBUG - 2021-06-30 12:27:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:27:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:27:31 --> Encryption Class Initialized
INFO - 2021-06-30 12:27:31 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:27:31 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:27:31 --> Model "user_model" initialized
INFO - 2021-06-30 12:27:31 --> Model "role_model" initialized
INFO - 2021-06-30 12:27:31 --> Controller Class Initialized
INFO - 2021-06-30 12:27:31 --> Helper loaded: language_helper
INFO - 2021-06-30 12:27:31 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:27:31 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:27:31 --> Final output sent to browser
DEBUG - 2021-06-30 12:27:31 --> Total execution time: 0.1022
INFO - 2021-06-30 12:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:27:31 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:27:31 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:27:31 --> Model "user_model" initialized
INFO - 2021-06-30 12:27:31 --> Model "role_model" initialized
INFO - 2021-06-30 12:27:31 --> Controller Class Initialized
INFO - 2021-06-30 12:27:31 --> Helper loaded: language_helper
INFO - 2021-06-30 12:27:31 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:27:31 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:27:31 --> Final output sent to browser
DEBUG - 2021-06-30 12:27:31 --> Total execution time: 0.1202
INFO - 2021-06-30 12:28:17 --> Config Class Initialized
INFO - 2021-06-30 12:28:17 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:28:17 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:28:17 --> Utf8 Class Initialized
INFO - 2021-06-30 12:28:17 --> URI Class Initialized
INFO - 2021-06-30 12:28:17 --> Router Class Initialized
INFO - 2021-06-30 12:28:17 --> Output Class Initialized
INFO - 2021-06-30 12:28:17 --> Security Class Initialized
DEBUG - 2021-06-30 12:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:28:17 --> Input Class Initialized
INFO - 2021-06-30 12:28:17 --> Language Class Initialized
INFO - 2021-06-30 12:28:17 --> Loader Class Initialized
INFO - 2021-06-30 12:28:17 --> Helper loaded: html_helper
INFO - 2021-06-30 12:28:17 --> Helper loaded: url_helper
INFO - 2021-06-30 12:28:17 --> Helper loaded: form_helper
INFO - 2021-06-30 12:28:17 --> Database Driver Class Initialized
INFO - 2021-06-30 12:28:17 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:28:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:28:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:28:17 --> Encryption Class Initialized
INFO - 2021-06-30 12:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:28:17 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:28:17 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:28:17 --> Model "user_model" initialized
INFO - 2021-06-30 12:28:17 --> Model "role_model" initialized
INFO - 2021-06-30 12:28:17 --> Controller Class Initialized
INFO - 2021-06-30 12:28:17 --> Helper loaded: language_helper
INFO - 2021-06-30 12:28:17 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:28:17 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:28:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 12:28:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 12:28:17 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-06-30 12:28:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-06-30 12:28:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 12:28:17 --> Final output sent to browser
DEBUG - 2021-06-30 12:28:17 --> Total execution time: 0.0715
INFO - 2021-06-30 12:28:21 --> Config Class Initialized
INFO - 2021-06-30 12:28:21 --> Config Class Initialized
INFO - 2021-06-30 12:28:21 --> Hooks Class Initialized
INFO - 2021-06-30 12:28:21 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:28:21 --> UTF-8 Support Enabled
DEBUG - 2021-06-30 12:28:21 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:28:21 --> Utf8 Class Initialized
INFO - 2021-06-30 12:28:21 --> Utf8 Class Initialized
INFO - 2021-06-30 12:28:21 --> URI Class Initialized
INFO - 2021-06-30 12:28:21 --> URI Class Initialized
INFO - 2021-06-30 12:28:21 --> Router Class Initialized
INFO - 2021-06-30 12:28:21 --> Router Class Initialized
INFO - 2021-06-30 12:28:21 --> Output Class Initialized
INFO - 2021-06-30 12:28:21 --> Output Class Initialized
INFO - 2021-06-30 12:28:21 --> Security Class Initialized
INFO - 2021-06-30 12:28:21 --> Security Class Initialized
DEBUG - 2021-06-30 12:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:28:21 --> Input Class Initialized
DEBUG - 2021-06-30 12:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:28:21 --> Input Class Initialized
INFO - 2021-06-30 12:28:21 --> Language Class Initialized
INFO - 2021-06-30 12:28:21 --> Language Class Initialized
INFO - 2021-06-30 12:28:21 --> Loader Class Initialized
INFO - 2021-06-30 12:28:21 --> Loader Class Initialized
INFO - 2021-06-30 12:28:21 --> Helper loaded: html_helper
INFO - 2021-06-30 12:28:21 --> Helper loaded: html_helper
INFO - 2021-06-30 12:28:21 --> Helper loaded: url_helper
INFO - 2021-06-30 12:28:21 --> Helper loaded: url_helper
INFO - 2021-06-30 12:28:21 --> Helper loaded: form_helper
INFO - 2021-06-30 12:28:21 --> Helper loaded: form_helper
INFO - 2021-06-30 12:28:21 --> Database Driver Class Initialized
INFO - 2021-06-30 12:28:21 --> Database Driver Class Initialized
INFO - 2021-06-30 12:28:21 --> Form Validation Class Initialized
INFO - 2021-06-30 12:28:21 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-06-30 12:28:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:28:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:28:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:28:21 --> Encryption Class Initialized
INFO - 2021-06-30 12:28:21 --> Encryption Class Initialized
INFO - 2021-06-30 12:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:28:21 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:28:21 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:28:21 --> Model "user_model" initialized
INFO - 2021-06-30 12:28:21 --> Model "role_model" initialized
INFO - 2021-06-30 12:28:21 --> Controller Class Initialized
INFO - 2021-06-30 12:28:21 --> Helper loaded: language_helper
INFO - 2021-06-30 12:28:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:28:21 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:28:21 --> Final output sent to browser
DEBUG - 2021-06-30 12:28:21 --> Total execution time: 0.0701
INFO - 2021-06-30 12:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:28:21 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:28:21 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:28:21 --> Model "user_model" initialized
INFO - 2021-06-30 12:28:21 --> Model "role_model" initialized
INFO - 2021-06-30 12:28:21 --> Controller Class Initialized
INFO - 2021-06-30 12:28:21 --> Helper loaded: language_helper
INFO - 2021-06-30 12:28:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:28:21 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:28:21 --> Final output sent to browser
DEBUG - 2021-06-30 12:28:21 --> Total execution time: 0.0812
INFO - 2021-06-30 12:28:24 --> Config Class Initialized
INFO - 2021-06-30 12:28:24 --> Config Class Initialized
INFO - 2021-06-30 12:28:24 --> Hooks Class Initialized
INFO - 2021-06-30 12:28:24 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:28:24 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:28:24 --> Utf8 Class Initialized
DEBUG - 2021-06-30 12:28:24 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:28:24 --> Utf8 Class Initialized
INFO - 2021-06-30 12:28:24 --> URI Class Initialized
INFO - 2021-06-30 12:28:24 --> URI Class Initialized
INFO - 2021-06-30 12:28:24 --> Router Class Initialized
INFO - 2021-06-30 12:28:24 --> Router Class Initialized
INFO - 2021-06-30 12:28:24 --> Output Class Initialized
INFO - 2021-06-30 12:28:24 --> Output Class Initialized
INFO - 2021-06-30 12:28:24 --> Security Class Initialized
INFO - 2021-06-30 12:28:24 --> Security Class Initialized
DEBUG - 2021-06-30 12:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:28:24 --> Input Class Initialized
DEBUG - 2021-06-30 12:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:28:24 --> Input Class Initialized
INFO - 2021-06-30 12:28:24 --> Language Class Initialized
INFO - 2021-06-30 12:28:24 --> Language Class Initialized
INFO - 2021-06-30 12:28:24 --> Loader Class Initialized
INFO - 2021-06-30 12:28:24 --> Loader Class Initialized
INFO - 2021-06-30 12:28:24 --> Helper loaded: html_helper
INFO - 2021-06-30 12:28:24 --> Helper loaded: html_helper
INFO - 2021-06-30 12:28:24 --> Helper loaded: url_helper
INFO - 2021-06-30 12:28:24 --> Helper loaded: url_helper
INFO - 2021-06-30 12:28:24 --> Helper loaded: form_helper
INFO - 2021-06-30 12:28:24 --> Helper loaded: form_helper
INFO - 2021-06-30 12:28:24 --> Database Driver Class Initialized
INFO - 2021-06-30 12:28:24 --> Database Driver Class Initialized
INFO - 2021-06-30 12:28:24 --> Form Validation Class Initialized
INFO - 2021-06-30 12:28:24 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-06-30 12:28:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:28:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:28:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:28:24 --> Encryption Class Initialized
INFO - 2021-06-30 12:28:24 --> Encryption Class Initialized
INFO - 2021-06-30 12:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:28:24 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:28:24 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:28:24 --> Model "user_model" initialized
INFO - 2021-06-30 12:28:24 --> Model "role_model" initialized
INFO - 2021-06-30 12:28:24 --> Controller Class Initialized
INFO - 2021-06-30 12:28:24 --> Helper loaded: language_helper
INFO - 2021-06-30 12:28:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:28:24 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:28:24 --> Final output sent to browser
DEBUG - 2021-06-30 12:28:24 --> Total execution time: 0.0709
INFO - 2021-06-30 12:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:28:24 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:28:24 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:28:24 --> Model "user_model" initialized
INFO - 2021-06-30 12:28:24 --> Model "role_model" initialized
INFO - 2021-06-30 12:28:24 --> Controller Class Initialized
INFO - 2021-06-30 12:28:24 --> Helper loaded: language_helper
INFO - 2021-06-30 12:28:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:28:24 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:28:24 --> Final output sent to browser
DEBUG - 2021-06-30 12:28:24 --> Total execution time: 0.0798
INFO - 2021-06-30 12:28:26 --> Config Class Initialized
INFO - 2021-06-30 12:28:26 --> Config Class Initialized
INFO - 2021-06-30 12:28:26 --> Hooks Class Initialized
INFO - 2021-06-30 12:28:26 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:28:26 --> UTF-8 Support Enabled
DEBUG - 2021-06-30 12:28:26 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:28:26 --> Utf8 Class Initialized
INFO - 2021-06-30 12:28:26 --> Utf8 Class Initialized
INFO - 2021-06-30 12:28:26 --> URI Class Initialized
INFO - 2021-06-30 12:28:26 --> URI Class Initialized
INFO - 2021-06-30 12:28:26 --> Router Class Initialized
INFO - 2021-06-30 12:28:26 --> Router Class Initialized
INFO - 2021-06-30 12:28:26 --> Output Class Initialized
INFO - 2021-06-30 12:28:26 --> Output Class Initialized
INFO - 2021-06-30 12:28:26 --> Security Class Initialized
INFO - 2021-06-30 12:28:26 --> Security Class Initialized
DEBUG - 2021-06-30 12:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-06-30 12:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:28:26 --> Input Class Initialized
INFO - 2021-06-30 12:28:26 --> Input Class Initialized
INFO - 2021-06-30 12:28:26 --> Language Class Initialized
INFO - 2021-06-30 12:28:26 --> Language Class Initialized
INFO - 2021-06-30 12:28:26 --> Loader Class Initialized
INFO - 2021-06-30 12:28:26 --> Loader Class Initialized
INFO - 2021-06-30 12:28:26 --> Helper loaded: html_helper
INFO - 2021-06-30 12:28:26 --> Helper loaded: html_helper
INFO - 2021-06-30 12:28:26 --> Helper loaded: url_helper
INFO - 2021-06-30 12:28:26 --> Helper loaded: url_helper
INFO - 2021-06-30 12:28:26 --> Helper loaded: form_helper
INFO - 2021-06-30 12:28:26 --> Helper loaded: form_helper
INFO - 2021-06-30 12:28:26 --> Database Driver Class Initialized
INFO - 2021-06-30 12:28:26 --> Database Driver Class Initialized
INFO - 2021-06-30 12:28:26 --> Form Validation Class Initialized
INFO - 2021-06-30 12:28:26 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-06-30 12:28:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:28:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:28:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:28:26 --> Encryption Class Initialized
INFO - 2021-06-30 12:28:26 --> Encryption Class Initialized
INFO - 2021-06-30 12:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:28:26 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:28:26 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:28:26 --> Model "user_model" initialized
INFO - 2021-06-30 12:28:26 --> Model "role_model" initialized
INFO - 2021-06-30 12:28:26 --> Controller Class Initialized
INFO - 2021-06-30 12:28:26 --> Helper loaded: language_helper
INFO - 2021-06-30 12:28:26 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:28:26 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:28:26 --> Final output sent to browser
DEBUG - 2021-06-30 12:28:26 --> Total execution time: 0.0668
INFO - 2021-06-30 12:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:28:26 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:28:26 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:28:26 --> Model "user_model" initialized
INFO - 2021-06-30 12:28:27 --> Model "role_model" initialized
INFO - 2021-06-30 12:28:27 --> Controller Class Initialized
INFO - 2021-06-30 12:28:27 --> Helper loaded: language_helper
INFO - 2021-06-30 12:28:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:28:27 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:28:27 --> Final output sent to browser
DEBUG - 2021-06-30 12:28:27 --> Total execution time: 0.0764
INFO - 2021-06-30 12:28:37 --> Config Class Initialized
INFO - 2021-06-30 12:28:37 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:28:37 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:28:37 --> Utf8 Class Initialized
INFO - 2021-06-30 12:28:37 --> URI Class Initialized
INFO - 2021-06-30 12:28:37 --> Router Class Initialized
INFO - 2021-06-30 12:28:37 --> Output Class Initialized
INFO - 2021-06-30 12:28:37 --> Security Class Initialized
DEBUG - 2021-06-30 12:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:28:37 --> Input Class Initialized
INFO - 2021-06-30 12:28:37 --> Language Class Initialized
INFO - 2021-06-30 12:28:37 --> Loader Class Initialized
INFO - 2021-06-30 12:28:37 --> Helper loaded: html_helper
INFO - 2021-06-30 12:28:37 --> Helper loaded: url_helper
INFO - 2021-06-30 12:28:37 --> Helper loaded: form_helper
INFO - 2021-06-30 12:28:37 --> Database Driver Class Initialized
INFO - 2021-06-30 12:28:37 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:28:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:28:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:28:37 --> Encryption Class Initialized
INFO - 2021-06-30 12:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:28:37 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:28:37 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:28:37 --> Model "user_model" initialized
INFO - 2021-06-30 12:28:37 --> Model "role_model" initialized
INFO - 2021-06-30 12:28:37 --> Controller Class Initialized
INFO - 2021-06-30 12:28:37 --> Helper loaded: language_helper
INFO - 2021-06-30 12:28:37 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:28:37 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:28:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 12:28:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 12:28:37 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-06-30 12:28:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-06-30 12:28:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 12:28:37 --> Final output sent to browser
DEBUG - 2021-06-30 12:28:37 --> Total execution time: 0.0733
INFO - 2021-06-30 12:28:41 --> Config Class Initialized
INFO - 2021-06-30 12:28:41 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:28:41 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:28:41 --> Utf8 Class Initialized
INFO - 2021-06-30 12:28:41 --> URI Class Initialized
INFO - 2021-06-30 12:28:41 --> Router Class Initialized
INFO - 2021-06-30 12:28:41 --> Output Class Initialized
INFO - 2021-06-30 12:28:41 --> Security Class Initialized
DEBUG - 2021-06-30 12:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:28:41 --> Input Class Initialized
INFO - 2021-06-30 12:28:41 --> Language Class Initialized
INFO - 2021-06-30 12:28:41 --> Loader Class Initialized
INFO - 2021-06-30 12:28:41 --> Helper loaded: html_helper
INFO - 2021-06-30 12:28:41 --> Helper loaded: url_helper
INFO - 2021-06-30 12:28:41 --> Helper loaded: form_helper
INFO - 2021-06-30 12:28:41 --> Database Driver Class Initialized
INFO - 2021-06-30 12:28:41 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:28:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:28:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:28:41 --> Encryption Class Initialized
INFO - 2021-06-30 12:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:28:41 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:28:41 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:28:41 --> Model "user_model" initialized
INFO - 2021-06-30 12:28:41 --> Model "role_model" initialized
INFO - 2021-06-30 12:28:41 --> Controller Class Initialized
INFO - 2021-06-30 12:28:41 --> Helper loaded: language_helper
INFO - 2021-06-30 12:28:41 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:28:41 --> Model "Customer_model" initialized
INFO - 2021-06-30 12:28:41 --> Model "Product_model" initialized
INFO - 2021-06-30 12:28:41 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 12:28:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 12:28:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 12:28:41 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 12:28:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 12:28:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 12:28:41 --> Final output sent to browser
DEBUG - 2021-06-30 12:28:41 --> Total execution time: 0.0747
INFO - 2021-06-30 12:28:59 --> Config Class Initialized
INFO - 2021-06-30 12:28:59 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:28:59 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:28:59 --> Utf8 Class Initialized
INFO - 2021-06-30 12:28:59 --> URI Class Initialized
INFO - 2021-06-30 12:28:59 --> Router Class Initialized
INFO - 2021-06-30 12:28:59 --> Output Class Initialized
INFO - 2021-06-30 12:28:59 --> Security Class Initialized
DEBUG - 2021-06-30 12:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:28:59 --> Input Class Initialized
INFO - 2021-06-30 12:28:59 --> Language Class Initialized
INFO - 2021-06-30 12:28:59 --> Loader Class Initialized
INFO - 2021-06-30 12:28:59 --> Helper loaded: html_helper
INFO - 2021-06-30 12:28:59 --> Helper loaded: url_helper
INFO - 2021-06-30 12:28:59 --> Helper loaded: form_helper
INFO - 2021-06-30 12:28:59 --> Database Driver Class Initialized
INFO - 2021-06-30 12:28:59 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:28:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:28:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:28:59 --> Encryption Class Initialized
INFO - 2021-06-30 12:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:28:59 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:28:59 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:28:59 --> Model "user_model" initialized
INFO - 2021-06-30 12:28:59 --> Model "role_model" initialized
INFO - 2021-06-30 12:28:59 --> Controller Class Initialized
INFO - 2021-06-30 12:28:59 --> Helper loaded: language_helper
INFO - 2021-06-30 12:28:59 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:28:59 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:28:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 12:28:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 12:28:59 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-06-30 12:28:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-06-30 12:28:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 12:28:59 --> Final output sent to browser
DEBUG - 2021-06-30 12:28:59 --> Total execution time: 0.0751
INFO - 2021-06-30 12:29:14 --> Config Class Initialized
INFO - 2021-06-30 12:29:14 --> Config Class Initialized
INFO - 2021-06-30 12:29:14 --> Hooks Class Initialized
INFO - 2021-06-30 12:29:14 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:29:14 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:29:14 --> Utf8 Class Initialized
DEBUG - 2021-06-30 12:29:14 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:29:14 --> Utf8 Class Initialized
INFO - 2021-06-30 12:29:14 --> URI Class Initialized
INFO - 2021-06-30 12:29:14 --> URI Class Initialized
INFO - 2021-06-30 12:29:14 --> Router Class Initialized
INFO - 2021-06-30 12:29:14 --> Router Class Initialized
INFO - 2021-06-30 12:29:14 --> Output Class Initialized
INFO - 2021-06-30 12:29:14 --> Output Class Initialized
INFO - 2021-06-30 12:29:14 --> Security Class Initialized
DEBUG - 2021-06-30 12:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:29:14 --> Security Class Initialized
INFO - 2021-06-30 12:29:14 --> Input Class Initialized
INFO - 2021-06-30 12:29:14 --> Language Class Initialized
DEBUG - 2021-06-30 12:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:29:14 --> Input Class Initialized
INFO - 2021-06-30 12:29:14 --> Language Class Initialized
INFO - 2021-06-30 12:29:14 --> Loader Class Initialized
INFO - 2021-06-30 12:29:14 --> Loader Class Initialized
INFO - 2021-06-30 12:29:14 --> Helper loaded: html_helper
INFO - 2021-06-30 12:29:14 --> Helper loaded: html_helper
INFO - 2021-06-30 12:29:14 --> Helper loaded: url_helper
INFO - 2021-06-30 12:29:14 --> Helper loaded: url_helper
INFO - 2021-06-30 12:29:14 --> Helper loaded: form_helper
INFO - 2021-06-30 12:29:14 --> Helper loaded: form_helper
INFO - 2021-06-30 12:29:14 --> Database Driver Class Initialized
INFO - 2021-06-30 12:29:14 --> Database Driver Class Initialized
INFO - 2021-06-30 12:29:14 --> Form Validation Class Initialized
INFO - 2021-06-30 12:29:14 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-06-30 12:29:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:29:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:29:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:29:14 --> Encryption Class Initialized
INFO - 2021-06-30 12:29:14 --> Encryption Class Initialized
INFO - 2021-06-30 12:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:29:14 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:29:14 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:29:14 --> Model "user_model" initialized
INFO - 2021-06-30 12:29:14 --> Model "role_model" initialized
INFO - 2021-06-30 12:29:14 --> Controller Class Initialized
INFO - 2021-06-30 12:29:14 --> Helper loaded: language_helper
INFO - 2021-06-30 12:29:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:29:14 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:29:14 --> Final output sent to browser
DEBUG - 2021-06-30 12:29:14 --> Total execution time: 0.0728
INFO - 2021-06-30 12:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:29:14 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:29:14 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:29:14 --> Model "user_model" initialized
INFO - 2021-06-30 12:29:14 --> Model "role_model" initialized
INFO - 2021-06-30 12:29:14 --> Controller Class Initialized
INFO - 2021-06-30 12:29:14 --> Helper loaded: language_helper
INFO - 2021-06-30 12:29:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:29:14 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:29:14 --> Final output sent to browser
DEBUG - 2021-06-30 12:29:14 --> Total execution time: 0.0829
INFO - 2021-06-30 12:29:54 --> Config Class Initialized
INFO - 2021-06-30 12:29:54 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:29:54 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:29:54 --> Utf8 Class Initialized
INFO - 2021-06-30 12:29:54 --> URI Class Initialized
INFO - 2021-06-30 12:29:54 --> Router Class Initialized
INFO - 2021-06-30 12:29:54 --> Output Class Initialized
INFO - 2021-06-30 12:29:54 --> Security Class Initialized
DEBUG - 2021-06-30 12:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:29:54 --> Input Class Initialized
INFO - 2021-06-30 12:29:54 --> Language Class Initialized
INFO - 2021-06-30 12:29:54 --> Loader Class Initialized
INFO - 2021-06-30 12:29:54 --> Helper loaded: html_helper
INFO - 2021-06-30 12:29:54 --> Helper loaded: url_helper
INFO - 2021-06-30 12:29:54 --> Helper loaded: form_helper
INFO - 2021-06-30 12:29:54 --> Database Driver Class Initialized
INFO - 2021-06-30 12:29:54 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:29:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:29:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:29:54 --> Encryption Class Initialized
INFO - 2021-06-30 12:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:29:54 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:29:54 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:29:54 --> Model "user_model" initialized
INFO - 2021-06-30 12:29:54 --> Model "role_model" initialized
INFO - 2021-06-30 12:29:54 --> Controller Class Initialized
INFO - 2021-06-30 12:29:54 --> Helper loaded: language_helper
INFO - 2021-06-30 12:29:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:29:54 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:29:54 --> Model "Customer_model" initialized
INFO - 2021-06-30 12:29:54 --> Model "Product_model" initialized
INFO - 2021-06-30 12:29:54 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 12:29:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 12:29:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 12:29:54 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-06-30 12:29:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-06-30 12:29:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 12:29:54 --> Final output sent to browser
DEBUG - 2021-06-30 12:29:54 --> Total execution time: 0.0815
INFO - 2021-06-30 12:29:57 --> Config Class Initialized
INFO - 2021-06-30 12:29:57 --> Config Class Initialized
INFO - 2021-06-30 12:29:57 --> Hooks Class Initialized
INFO - 2021-06-30 12:29:57 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:29:57 --> UTF-8 Support Enabled
DEBUG - 2021-06-30 12:29:57 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:29:57 --> Utf8 Class Initialized
INFO - 2021-06-30 12:29:57 --> Utf8 Class Initialized
INFO - 2021-06-30 12:29:57 --> URI Class Initialized
INFO - 2021-06-30 12:29:57 --> URI Class Initialized
INFO - 2021-06-30 12:29:57 --> Router Class Initialized
INFO - 2021-06-30 12:29:57 --> Router Class Initialized
INFO - 2021-06-30 12:29:57 --> Output Class Initialized
INFO - 2021-06-30 12:29:57 --> Output Class Initialized
INFO - 2021-06-30 12:29:57 --> Security Class Initialized
INFO - 2021-06-30 12:29:57 --> Security Class Initialized
DEBUG - 2021-06-30 12:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:29:57 --> Input Class Initialized
DEBUG - 2021-06-30 12:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:29:57 --> Language Class Initialized
INFO - 2021-06-30 12:29:57 --> Input Class Initialized
INFO - 2021-06-30 12:29:57 --> Language Class Initialized
INFO - 2021-06-30 12:29:57 --> Loader Class Initialized
INFO - 2021-06-30 12:29:57 --> Loader Class Initialized
INFO - 2021-06-30 12:29:57 --> Helper loaded: html_helper
INFO - 2021-06-30 12:29:57 --> Helper loaded: html_helper
INFO - 2021-06-30 12:29:57 --> Helper loaded: url_helper
INFO - 2021-06-30 12:29:57 --> Helper loaded: url_helper
INFO - 2021-06-30 12:29:57 --> Helper loaded: form_helper
INFO - 2021-06-30 12:29:57 --> Helper loaded: form_helper
INFO - 2021-06-30 12:29:57 --> Database Driver Class Initialized
INFO - 2021-06-30 12:29:57 --> Database Driver Class Initialized
INFO - 2021-06-30 12:29:57 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:29:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:29:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:29:57 --> Form Validation Class Initialized
INFO - 2021-06-30 12:29:57 --> Encryption Class Initialized
DEBUG - 2021-06-30 12:29:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:29:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:29:57 --> Encryption Class Initialized
INFO - 2021-06-30 12:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:29:57 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:29:57 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:29:57 --> Model "user_model" initialized
INFO - 2021-06-30 12:29:57 --> Model "role_model" initialized
INFO - 2021-06-30 12:29:57 --> Controller Class Initialized
INFO - 2021-06-30 12:29:57 --> Helper loaded: language_helper
INFO - 2021-06-30 12:29:57 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:29:57 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:29:57 --> Final output sent to browser
DEBUG - 2021-06-30 12:29:57 --> Total execution time: 0.0675
INFO - 2021-06-30 12:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:29:57 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:29:57 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:29:57 --> Model "user_model" initialized
INFO - 2021-06-30 12:29:57 --> Model "role_model" initialized
INFO - 2021-06-30 12:29:57 --> Controller Class Initialized
INFO - 2021-06-30 12:29:57 --> Helper loaded: language_helper
INFO - 2021-06-30 12:29:57 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:29:57 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:29:57 --> Final output sent to browser
DEBUG - 2021-06-30 12:29:57 --> Total execution time: 0.0759
INFO - 2021-06-30 12:30:01 --> Config Class Initialized
INFO - 2021-06-30 12:30:01 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:30:01 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:30:01 --> Utf8 Class Initialized
INFO - 2021-06-30 12:30:01 --> URI Class Initialized
INFO - 2021-06-30 12:30:01 --> Router Class Initialized
INFO - 2021-06-30 12:30:01 --> Output Class Initialized
INFO - 2021-06-30 12:30:01 --> Security Class Initialized
DEBUG - 2021-06-30 12:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:30:01 --> Input Class Initialized
INFO - 2021-06-30 12:30:01 --> Language Class Initialized
INFO - 2021-06-30 12:30:01 --> Loader Class Initialized
INFO - 2021-06-30 12:30:01 --> Helper loaded: html_helper
INFO - 2021-06-30 12:30:01 --> Helper loaded: url_helper
INFO - 2021-06-30 12:30:01 --> Helper loaded: form_helper
INFO - 2021-06-30 12:30:01 --> Database Driver Class Initialized
INFO - 2021-06-30 12:30:01 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:30:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:30:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:30:01 --> Encryption Class Initialized
INFO - 2021-06-30 12:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:30:01 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:30:01 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:30:01 --> Model "user_model" initialized
INFO - 2021-06-30 12:30:01 --> Model "role_model" initialized
INFO - 2021-06-30 12:30:01 --> Controller Class Initialized
INFO - 2021-06-30 12:30:01 --> Helper loaded: language_helper
INFO - 2021-06-30 12:30:01 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:30:01 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:30:01 --> Final output sent to browser
DEBUG - 2021-06-30 12:30:01 --> Total execution time: 0.0635
INFO - 2021-06-30 12:30:13 --> Config Class Initialized
INFO - 2021-06-30 12:30:13 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:30:13 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:30:13 --> Utf8 Class Initialized
INFO - 2021-06-30 12:30:13 --> URI Class Initialized
INFO - 2021-06-30 12:30:13 --> Router Class Initialized
INFO - 2021-06-30 12:30:13 --> Output Class Initialized
INFO - 2021-06-30 12:30:13 --> Security Class Initialized
DEBUG - 2021-06-30 12:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:30:13 --> Input Class Initialized
INFO - 2021-06-30 12:30:13 --> Language Class Initialized
INFO - 2021-06-30 12:30:13 --> Loader Class Initialized
INFO - 2021-06-30 12:30:13 --> Helper loaded: html_helper
INFO - 2021-06-30 12:30:13 --> Helper loaded: url_helper
INFO - 2021-06-30 12:30:13 --> Helper loaded: form_helper
INFO - 2021-06-30 12:30:13 --> Database Driver Class Initialized
INFO - 2021-06-30 12:30:13 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:30:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:30:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:30:13 --> Encryption Class Initialized
INFO - 2021-06-30 12:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:30:13 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:30:13 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:30:13 --> Model "user_model" initialized
INFO - 2021-06-30 12:30:13 --> Model "role_model" initialized
INFO - 2021-06-30 12:30:13 --> Controller Class Initialized
INFO - 2021-06-30 12:30:13 --> Helper loaded: language_helper
INFO - 2021-06-30 12:30:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:30:13 --> Model "Customer_model" initialized
INFO - 2021-06-30 12:30:13 --> Model "Product_model" initialized
INFO - 2021-06-30 12:30:13 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 12:30:13 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:30:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 12:30:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 12:30:13 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Invoices\create_invoice.php 33
INFO - 2021-06-30 12:30:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Invoices/create_invoice.php
INFO - 2021-06-30 12:30:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 12:30:13 --> Final output sent to browser
DEBUG - 2021-06-30 12:30:13 --> Total execution time: 0.0732
INFO - 2021-06-30 12:30:17 --> Config Class Initialized
INFO - 2021-06-30 12:30:17 --> Config Class Initialized
INFO - 2021-06-30 12:30:17 --> Hooks Class Initialized
INFO - 2021-06-30 12:30:17 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:30:17 --> UTF-8 Support Enabled
DEBUG - 2021-06-30 12:30:17 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:30:17 --> Utf8 Class Initialized
INFO - 2021-06-30 12:30:17 --> Utf8 Class Initialized
INFO - 2021-06-30 12:30:17 --> URI Class Initialized
INFO - 2021-06-30 12:30:17 --> URI Class Initialized
INFO - 2021-06-30 12:30:17 --> Router Class Initialized
INFO - 2021-06-30 12:30:17 --> Router Class Initialized
INFO - 2021-06-30 12:30:17 --> Output Class Initialized
INFO - 2021-06-30 12:30:17 --> Output Class Initialized
INFO - 2021-06-30 12:30:17 --> Security Class Initialized
INFO - 2021-06-30 12:30:17 --> Security Class Initialized
DEBUG - 2021-06-30 12:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-06-30 12:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:30:17 --> Input Class Initialized
INFO - 2021-06-30 12:30:17 --> Input Class Initialized
INFO - 2021-06-30 12:30:17 --> Language Class Initialized
INFO - 2021-06-30 12:30:17 --> Language Class Initialized
INFO - 2021-06-30 12:30:17 --> Loader Class Initialized
INFO - 2021-06-30 12:30:17 --> Loader Class Initialized
INFO - 2021-06-30 12:30:17 --> Helper loaded: html_helper
INFO - 2021-06-30 12:30:17 --> Helper loaded: url_helper
INFO - 2021-06-30 12:30:17 --> Helper loaded: form_helper
INFO - 2021-06-30 12:30:17 --> Database Driver Class Initialized
INFO - 2021-06-30 12:30:17 --> Helper loaded: html_helper
INFO - 2021-06-30 12:30:17 --> Helper loaded: url_helper
INFO - 2021-06-30 12:30:17 --> Helper loaded: form_helper
INFO - 2021-06-30 12:30:17 --> Database Driver Class Initialized
INFO - 2021-06-30 12:30:17 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:30:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:30:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:30:17 --> Encryption Class Initialized
INFO - 2021-06-30 12:30:17 --> Form Validation Class Initialized
INFO - 2021-06-30 12:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:30:17 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:30:17 --> Model "coupon_model" initialized
DEBUG - 2021-06-30 12:30:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:30:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:30:17 --> Model "user_model" initialized
INFO - 2021-06-30 12:30:17 --> Encryption Class Initialized
INFO - 2021-06-30 12:30:17 --> Model "role_model" initialized
INFO - 2021-06-30 12:30:17 --> Controller Class Initialized
INFO - 2021-06-30 12:30:17 --> Helper loaded: language_helper
INFO - 2021-06-30 12:30:17 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:30:17 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:30:17 --> Final output sent to browser
DEBUG - 2021-06-30 12:30:17 --> Total execution time: 0.0690
INFO - 2021-06-30 12:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:30:17 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:30:17 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:30:17 --> Model "user_model" initialized
INFO - 2021-06-30 12:30:17 --> Model "role_model" initialized
INFO - 2021-06-30 12:30:17 --> Controller Class Initialized
INFO - 2021-06-30 12:30:17 --> Helper loaded: language_helper
INFO - 2021-06-30 12:30:17 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:30:17 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:30:17 --> Final output sent to browser
DEBUG - 2021-06-30 12:30:17 --> Total execution time: 0.0785
INFO - 2021-06-30 12:30:22 --> Config Class Initialized
INFO - 2021-06-30 12:30:22 --> Hooks Class Initialized
DEBUG - 2021-06-30 12:30:22 --> UTF-8 Support Enabled
INFO - 2021-06-30 12:30:22 --> Utf8 Class Initialized
INFO - 2021-06-30 12:30:22 --> URI Class Initialized
INFO - 2021-06-30 12:30:22 --> Router Class Initialized
INFO - 2021-06-30 12:30:22 --> Output Class Initialized
INFO - 2021-06-30 12:30:22 --> Security Class Initialized
DEBUG - 2021-06-30 12:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 12:30:22 --> Input Class Initialized
INFO - 2021-06-30 12:30:22 --> Language Class Initialized
INFO - 2021-06-30 12:30:22 --> Loader Class Initialized
INFO - 2021-06-30 12:30:22 --> Helper loaded: html_helper
INFO - 2021-06-30 12:30:22 --> Helper loaded: url_helper
INFO - 2021-06-30 12:30:22 --> Helper loaded: form_helper
INFO - 2021-06-30 12:30:22 --> Database Driver Class Initialized
INFO - 2021-06-30 12:30:22 --> Form Validation Class Initialized
DEBUG - 2021-06-30 12:30:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-06-30 12:30:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-06-30 12:30:22 --> Encryption Class Initialized
INFO - 2021-06-30 12:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-30 12:30:22 --> Model "vendor_model" initialized
INFO - 2021-06-30 12:30:22 --> Model "coupon_model" initialized
INFO - 2021-06-30 12:30:22 --> Model "user_model" initialized
INFO - 2021-06-30 12:30:22 --> Model "role_model" initialized
INFO - 2021-06-30 12:30:22 --> Controller Class Initialized
INFO - 2021-06-30 12:30:22 --> Helper loaded: language_helper
INFO - 2021-06-30 12:30:22 --> Language file loaded: language/english/content_lang.php
INFO - 2021-06-30 12:30:22 --> Model "Customer_model" initialized
INFO - 2021-06-30 12:30:22 --> Model "Product_model" initialized
INFO - 2021-06-30 12:30:22 --> Model "StateGSTCode_modal" initialized
INFO - 2021-06-30 12:30:22 --> Model "Quotation_model" initialized
INFO - 2021-06-30 12:30:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-06-30 12:30:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-06-30 12:30:22 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Invoices\create_invoice.php 33
INFO - 2021-06-30 12:30:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Invoices/create_invoice.php
INFO - 2021-06-30 12:30:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-06-30 12:30:22 --> Final output sent to browser
DEBUG - 2021-06-30 12:30:22 --> Total execution time: 0.0745
