<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-05 06:09:31 --> Config Class Initialized
INFO - 2021-07-05 06:09:31 --> Hooks Class Initialized
DEBUG - 2021-07-05 06:09:32 --> UTF-8 Support Enabled
INFO - 2021-07-05 06:09:32 --> Utf8 Class Initialized
INFO - 2021-07-05 06:09:32 --> URI Class Initialized
DEBUG - 2021-07-05 06:09:32 --> No URI present. Default controller set.
INFO - 2021-07-05 06:09:32 --> Router Class Initialized
INFO - 2021-07-05 06:09:33 --> Output Class Initialized
INFO - 2021-07-05 06:09:33 --> Security Class Initialized
DEBUG - 2021-07-05 06:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 06:09:33 --> Input Class Initialized
INFO - 2021-07-05 06:09:34 --> Language Class Initialized
INFO - 2021-07-05 06:09:34 --> Loader Class Initialized
INFO - 2021-07-05 06:09:35 --> Helper loaded: html_helper
INFO - 2021-07-05 06:09:35 --> Helper loaded: url_helper
INFO - 2021-07-05 06:09:36 --> Helper loaded: form_helper
INFO - 2021-07-05 06:09:37 --> Database Driver Class Initialized
INFO - 2021-07-05 06:09:39 --> Form Validation Class Initialized
DEBUG - 2021-07-05 06:09:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 06:09:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 06:09:39 --> Encryption Class Initialized
INFO - 2021-07-05 06:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 06:09:41 --> Model "vendor_model" initialized
INFO - 2021-07-05 06:09:41 --> Model "coupon_model" initialized
INFO - 2021-07-05 06:09:41 --> Model "user_model" initialized
INFO - 2021-07-05 06:09:41 --> Model "role_model" initialized
INFO - 2021-07-05 06:09:41 --> Controller Class Initialized
INFO - 2021-07-05 06:09:41 --> Helper loaded: language_helper
INFO - 2021-07-05 06:09:41 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 06:09:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\login.php
INFO - 2021-07-05 06:09:41 --> Final output sent to browser
DEBUG - 2021-07-05 06:09:41 --> Total execution time: 11.3728
INFO - 2021-07-05 06:09:51 --> Config Class Initialized
INFO - 2021-07-05 06:09:51 --> Hooks Class Initialized
DEBUG - 2021-07-05 06:09:51 --> UTF-8 Support Enabled
INFO - 2021-07-05 06:09:51 --> Utf8 Class Initialized
INFO - 2021-07-05 06:09:51 --> URI Class Initialized
INFO - 2021-07-05 06:09:51 --> Router Class Initialized
INFO - 2021-07-05 06:09:51 --> Output Class Initialized
INFO - 2021-07-05 06:09:51 --> Security Class Initialized
DEBUG - 2021-07-05 06:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 06:09:51 --> Input Class Initialized
INFO - 2021-07-05 06:09:51 --> Language Class Initialized
INFO - 2021-07-05 06:09:51 --> Loader Class Initialized
INFO - 2021-07-05 06:09:51 --> Helper loaded: html_helper
INFO - 2021-07-05 06:09:51 --> Helper loaded: url_helper
INFO - 2021-07-05 06:09:51 --> Helper loaded: form_helper
INFO - 2021-07-05 06:09:51 --> Database Driver Class Initialized
INFO - 2021-07-05 06:09:51 --> Form Validation Class Initialized
DEBUG - 2021-07-05 06:09:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 06:09:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 06:09:51 --> Encryption Class Initialized
INFO - 2021-07-05 06:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 06:09:51 --> Model "vendor_model" initialized
INFO - 2021-07-05 06:09:51 --> Model "coupon_model" initialized
INFO - 2021-07-05 06:09:51 --> Model "user_model" initialized
INFO - 2021-07-05 06:09:51 --> Model "role_model" initialized
INFO - 2021-07-05 06:09:51 --> Controller Class Initialized
INFO - 2021-07-05 06:09:51 --> Helper loaded: language_helper
INFO - 2021-07-05 06:09:51 --> Language file loaded: language/english/content_lang.php
DEBUG - 2021-07-05 06:09:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-05 06:09:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-07-05 06:09:51 --> Model "User" initialized
INFO - 2021-07-05 06:09:51 --> Config Class Initialized
INFO - 2021-07-05 06:09:51 --> Hooks Class Initialized
DEBUG - 2021-07-05 06:09:51 --> UTF-8 Support Enabled
INFO - 2021-07-05 06:09:51 --> Utf8 Class Initialized
INFO - 2021-07-05 06:09:51 --> URI Class Initialized
INFO - 2021-07-05 06:09:51 --> Router Class Initialized
INFO - 2021-07-05 06:09:51 --> Output Class Initialized
INFO - 2021-07-05 06:09:51 --> Security Class Initialized
DEBUG - 2021-07-05 06:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 06:09:51 --> Input Class Initialized
INFO - 2021-07-05 06:09:51 --> Language Class Initialized
INFO - 2021-07-05 06:09:51 --> Loader Class Initialized
INFO - 2021-07-05 06:09:51 --> Helper loaded: html_helper
INFO - 2021-07-05 06:09:51 --> Helper loaded: url_helper
INFO - 2021-07-05 06:09:51 --> Helper loaded: form_helper
INFO - 2021-07-05 06:09:51 --> Database Driver Class Initialized
INFO - 2021-07-05 06:09:51 --> Form Validation Class Initialized
DEBUG - 2021-07-05 06:09:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 06:09:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 06:09:51 --> Encryption Class Initialized
INFO - 2021-07-05 06:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 06:09:51 --> Model "vendor_model" initialized
INFO - 2021-07-05 06:09:51 --> Model "coupon_model" initialized
INFO - 2021-07-05 06:09:51 --> Model "user_model" initialized
INFO - 2021-07-05 06:09:51 --> Model "role_model" initialized
INFO - 2021-07-05 06:09:51 --> Controller Class Initialized
INFO - 2021-07-05 06:09:51 --> Helper loaded: language_helper
INFO - 2021-07-05 06:09:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 06:09:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 06:09:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 06:09:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 06:09:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 06:09:52 --> Final output sent to browser
DEBUG - 2021-07-05 06:09:52 --> Total execution time: 0.5080
INFO - 2021-07-05 06:10:04 --> Config Class Initialized
INFO - 2021-07-05 06:10:04 --> Hooks Class Initialized
DEBUG - 2021-07-05 06:10:04 --> UTF-8 Support Enabled
INFO - 2021-07-05 06:10:04 --> Utf8 Class Initialized
INFO - 2021-07-05 06:10:04 --> URI Class Initialized
INFO - 2021-07-05 06:10:04 --> Router Class Initialized
INFO - 2021-07-05 06:10:04 --> Output Class Initialized
INFO - 2021-07-05 06:10:04 --> Security Class Initialized
DEBUG - 2021-07-05 06:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 06:10:04 --> Input Class Initialized
INFO - 2021-07-05 06:10:04 --> Language Class Initialized
INFO - 2021-07-05 06:10:04 --> Loader Class Initialized
INFO - 2021-07-05 06:10:04 --> Helper loaded: html_helper
INFO - 2021-07-05 06:10:04 --> Helper loaded: url_helper
INFO - 2021-07-05 06:10:04 --> Helper loaded: form_helper
INFO - 2021-07-05 06:10:04 --> Database Driver Class Initialized
INFO - 2021-07-05 06:10:04 --> Form Validation Class Initialized
DEBUG - 2021-07-05 06:10:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 06:10:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 06:10:04 --> Encryption Class Initialized
INFO - 2021-07-05 06:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 06:10:04 --> Model "vendor_model" initialized
INFO - 2021-07-05 06:10:04 --> Model "coupon_model" initialized
INFO - 2021-07-05 06:10:04 --> Model "user_model" initialized
INFO - 2021-07-05 06:10:04 --> Model "role_model" initialized
INFO - 2021-07-05 06:10:04 --> Controller Class Initialized
INFO - 2021-07-05 06:10:04 --> Helper loaded: language_helper
INFO - 2021-07-05 06:10:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 06:10:05 --> Model "Customer_model" initialized
INFO - 2021-07-05 06:10:05 --> Model "Product_model" initialized
INFO - 2021-07-05 06:10:05 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 06:10:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 06:10:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 06:10:06 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 06:10:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 06:10:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 06:10:06 --> Final output sent to browser
DEBUG - 2021-07-05 06:10:06 --> Total execution time: 1.9322
INFO - 2021-07-05 06:10:55 --> Config Class Initialized
INFO - 2021-07-05 06:10:55 --> Hooks Class Initialized
DEBUG - 2021-07-05 06:10:55 --> UTF-8 Support Enabled
INFO - 2021-07-05 06:10:55 --> Utf8 Class Initialized
INFO - 2021-07-05 06:10:55 --> URI Class Initialized
INFO - 2021-07-05 06:10:55 --> Router Class Initialized
INFO - 2021-07-05 06:10:55 --> Output Class Initialized
INFO - 2021-07-05 06:10:55 --> Security Class Initialized
DEBUG - 2021-07-05 06:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 06:10:55 --> Input Class Initialized
INFO - 2021-07-05 06:10:55 --> Language Class Initialized
INFO - 2021-07-05 06:10:55 --> Loader Class Initialized
INFO - 2021-07-05 06:10:55 --> Helper loaded: html_helper
INFO - 2021-07-05 06:10:55 --> Helper loaded: url_helper
INFO - 2021-07-05 06:10:55 --> Helper loaded: form_helper
INFO - 2021-07-05 06:10:55 --> Database Driver Class Initialized
INFO - 2021-07-05 06:10:55 --> Form Validation Class Initialized
DEBUG - 2021-07-05 06:10:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 06:10:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 06:10:55 --> Encryption Class Initialized
INFO - 2021-07-05 06:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 06:10:55 --> Model "vendor_model" initialized
INFO - 2021-07-05 06:10:55 --> Model "coupon_model" initialized
INFO - 2021-07-05 06:10:55 --> Model "user_model" initialized
INFO - 2021-07-05 06:10:55 --> Model "role_model" initialized
INFO - 2021-07-05 06:10:55 --> Controller Class Initialized
INFO - 2021-07-05 06:10:55 --> Helper loaded: language_helper
INFO - 2021-07-05 06:10:55 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 06:10:55 --> Model "Customer_model" initialized
INFO - 2021-07-05 06:10:55 --> Final output sent to browser
DEBUG - 2021-07-05 06:10:55 --> Total execution time: 0.3029
INFO - 2021-07-05 06:11:02 --> Config Class Initialized
INFO - 2021-07-05 06:11:02 --> Hooks Class Initialized
DEBUG - 2021-07-05 06:11:02 --> UTF-8 Support Enabled
INFO - 2021-07-05 06:11:02 --> Utf8 Class Initialized
INFO - 2021-07-05 06:11:02 --> URI Class Initialized
INFO - 2021-07-05 06:11:02 --> Router Class Initialized
INFO - 2021-07-05 06:11:02 --> Output Class Initialized
INFO - 2021-07-05 06:11:02 --> Security Class Initialized
DEBUG - 2021-07-05 06:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 06:11:02 --> Input Class Initialized
INFO - 2021-07-05 06:11:02 --> Language Class Initialized
INFO - 2021-07-05 06:11:02 --> Loader Class Initialized
INFO - 2021-07-05 06:11:02 --> Helper loaded: html_helper
INFO - 2021-07-05 06:11:02 --> Helper loaded: url_helper
INFO - 2021-07-05 06:11:02 --> Helper loaded: form_helper
INFO - 2021-07-05 06:11:02 --> Database Driver Class Initialized
INFO - 2021-07-05 06:11:02 --> Form Validation Class Initialized
DEBUG - 2021-07-05 06:11:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 06:11:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 06:11:02 --> Encryption Class Initialized
INFO - 2021-07-05 06:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 06:11:02 --> Model "vendor_model" initialized
INFO - 2021-07-05 06:11:02 --> Model "coupon_model" initialized
INFO - 2021-07-05 06:11:02 --> Model "user_model" initialized
INFO - 2021-07-05 06:11:02 --> Model "role_model" initialized
INFO - 2021-07-05 06:11:02 --> Controller Class Initialized
INFO - 2021-07-05 06:11:02 --> Helper loaded: language_helper
INFO - 2021-07-05 06:11:02 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 06:11:02 --> Model "Customer_model" initialized
INFO - 2021-07-05 06:11:02 --> Final output sent to browser
DEBUG - 2021-07-05 06:11:02 --> Total execution time: 0.1302
INFO - 2021-07-05 06:11:44 --> Config Class Initialized
INFO - 2021-07-05 06:11:44 --> Hooks Class Initialized
DEBUG - 2021-07-05 06:11:44 --> UTF-8 Support Enabled
INFO - 2021-07-05 06:11:44 --> Utf8 Class Initialized
INFO - 2021-07-05 06:11:44 --> URI Class Initialized
INFO - 2021-07-05 06:11:44 --> Router Class Initialized
INFO - 2021-07-05 06:11:44 --> Output Class Initialized
INFO - 2021-07-05 06:11:44 --> Security Class Initialized
DEBUG - 2021-07-05 06:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 06:11:44 --> Input Class Initialized
INFO - 2021-07-05 06:11:44 --> Language Class Initialized
INFO - 2021-07-05 06:11:44 --> Loader Class Initialized
INFO - 2021-07-05 06:11:44 --> Helper loaded: html_helper
INFO - 2021-07-05 06:11:44 --> Helper loaded: url_helper
INFO - 2021-07-05 06:11:44 --> Helper loaded: form_helper
INFO - 2021-07-05 06:11:44 --> Database Driver Class Initialized
INFO - 2021-07-05 06:11:44 --> Form Validation Class Initialized
DEBUG - 2021-07-05 06:11:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 06:11:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 06:11:44 --> Encryption Class Initialized
INFO - 2021-07-05 06:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 06:11:44 --> Model "vendor_model" initialized
INFO - 2021-07-05 06:11:44 --> Model "coupon_model" initialized
INFO - 2021-07-05 06:11:44 --> Model "user_model" initialized
INFO - 2021-07-05 06:11:44 --> Model "role_model" initialized
INFO - 2021-07-05 06:11:44 --> Controller Class Initialized
INFO - 2021-07-05 06:11:44 --> Helper loaded: language_helper
INFO - 2021-07-05 06:11:44 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 06:11:44 --> Model "Product_model" initialized
INFO - 2021-07-05 06:11:44 --> Final output sent to browser
DEBUG - 2021-07-05 06:11:44 --> Total execution time: 0.1037
INFO - 2021-07-05 06:11:58 --> Config Class Initialized
INFO - 2021-07-05 06:11:58 --> Hooks Class Initialized
DEBUG - 2021-07-05 06:11:58 --> UTF-8 Support Enabled
INFO - 2021-07-05 06:11:58 --> Utf8 Class Initialized
INFO - 2021-07-05 06:11:58 --> URI Class Initialized
INFO - 2021-07-05 06:11:58 --> Router Class Initialized
INFO - 2021-07-05 06:11:58 --> Output Class Initialized
INFO - 2021-07-05 06:11:58 --> Security Class Initialized
DEBUG - 2021-07-05 06:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 06:11:58 --> Input Class Initialized
INFO - 2021-07-05 06:11:58 --> Language Class Initialized
INFO - 2021-07-05 06:11:58 --> Loader Class Initialized
INFO - 2021-07-05 06:11:58 --> Helper loaded: html_helper
INFO - 2021-07-05 06:11:58 --> Helper loaded: url_helper
INFO - 2021-07-05 06:11:58 --> Helper loaded: form_helper
INFO - 2021-07-05 06:11:58 --> Database Driver Class Initialized
INFO - 2021-07-05 06:11:58 --> Form Validation Class Initialized
DEBUG - 2021-07-05 06:11:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 06:11:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 06:11:58 --> Encryption Class Initialized
INFO - 2021-07-05 06:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 06:11:58 --> Model "vendor_model" initialized
INFO - 2021-07-05 06:11:58 --> Model "coupon_model" initialized
INFO - 2021-07-05 06:11:58 --> Model "user_model" initialized
INFO - 2021-07-05 06:11:58 --> Model "role_model" initialized
INFO - 2021-07-05 06:11:58 --> Controller Class Initialized
INFO - 2021-07-05 06:11:58 --> Helper loaded: language_helper
INFO - 2021-07-05 06:11:58 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 06:11:58 --> Model "Quotation_model" initialized
INFO - 2021-07-05 06:11:58 --> Final output sent to browser
DEBUG - 2021-07-05 06:11:58 --> Total execution time: 0.2632
INFO - 2021-07-05 06:12:00 --> Config Class Initialized
INFO - 2021-07-05 06:12:00 --> Hooks Class Initialized
DEBUG - 2021-07-05 06:12:00 --> UTF-8 Support Enabled
INFO - 2021-07-05 06:12:00 --> Utf8 Class Initialized
INFO - 2021-07-05 06:12:00 --> URI Class Initialized
INFO - 2021-07-05 06:12:00 --> Router Class Initialized
INFO - 2021-07-05 06:12:00 --> Output Class Initialized
INFO - 2021-07-05 06:12:00 --> Security Class Initialized
DEBUG - 2021-07-05 06:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 06:12:00 --> Input Class Initialized
INFO - 2021-07-05 06:12:00 --> Language Class Initialized
INFO - 2021-07-05 06:12:00 --> Loader Class Initialized
INFO - 2021-07-05 06:12:00 --> Helper loaded: html_helper
INFO - 2021-07-05 06:12:00 --> Helper loaded: url_helper
INFO - 2021-07-05 06:12:00 --> Helper loaded: form_helper
INFO - 2021-07-05 06:12:00 --> Database Driver Class Initialized
INFO - 2021-07-05 06:12:00 --> Form Validation Class Initialized
DEBUG - 2021-07-05 06:12:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 06:12:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 06:12:00 --> Encryption Class Initialized
INFO - 2021-07-05 06:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 06:12:00 --> Model "vendor_model" initialized
INFO - 2021-07-05 06:12:00 --> Model "coupon_model" initialized
INFO - 2021-07-05 06:12:00 --> Model "user_model" initialized
INFO - 2021-07-05 06:12:00 --> Model "role_model" initialized
INFO - 2021-07-05 06:12:00 --> Controller Class Initialized
INFO - 2021-07-05 06:12:00 --> Helper loaded: language_helper
INFO - 2021-07-05 06:12:00 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 06:12:00 --> Model "Quotation_model" initialized
INFO - 2021-07-05 06:12:00 --> Final output sent to browser
DEBUG - 2021-07-05 06:12:00 --> Total execution time: 0.0678
INFO - 2021-07-05 06:12:02 --> Config Class Initialized
INFO - 2021-07-05 06:12:02 --> Hooks Class Initialized
DEBUG - 2021-07-05 06:12:02 --> UTF-8 Support Enabled
INFO - 2021-07-05 06:12:02 --> Utf8 Class Initialized
INFO - 2021-07-05 06:12:02 --> URI Class Initialized
INFO - 2021-07-05 06:12:02 --> Router Class Initialized
INFO - 2021-07-05 06:12:02 --> Output Class Initialized
INFO - 2021-07-05 06:12:02 --> Security Class Initialized
DEBUG - 2021-07-05 06:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 06:12:02 --> Input Class Initialized
INFO - 2021-07-05 06:12:02 --> Language Class Initialized
INFO - 2021-07-05 06:12:02 --> Loader Class Initialized
INFO - 2021-07-05 06:12:02 --> Helper loaded: html_helper
INFO - 2021-07-05 06:12:02 --> Helper loaded: url_helper
INFO - 2021-07-05 06:12:02 --> Helper loaded: form_helper
INFO - 2021-07-05 06:12:02 --> Database Driver Class Initialized
INFO - 2021-07-05 06:12:02 --> Form Validation Class Initialized
DEBUG - 2021-07-05 06:12:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 06:12:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 06:12:02 --> Encryption Class Initialized
INFO - 2021-07-05 06:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 06:12:02 --> Model "vendor_model" initialized
INFO - 2021-07-05 06:12:02 --> Model "coupon_model" initialized
INFO - 2021-07-05 06:12:02 --> Model "user_model" initialized
INFO - 2021-07-05 06:12:02 --> Model "role_model" initialized
INFO - 2021-07-05 06:12:02 --> Controller Class Initialized
INFO - 2021-07-05 06:12:02 --> Helper loaded: language_helper
INFO - 2021-07-05 06:12:02 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 06:12:02 --> Model "Quotation_model" initialized
INFO - 2021-07-05 06:12:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 06:12:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 06:12:02 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-05 06:12:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-05 06:12:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 06:12:02 --> Final output sent to browser
DEBUG - 2021-07-05 06:12:02 --> Total execution time: 0.1467
INFO - 2021-07-05 06:12:08 --> Config Class Initialized
INFO - 2021-07-05 06:12:08 --> Hooks Class Initialized
INFO - 2021-07-05 06:12:08 --> Config Class Initialized
INFO - 2021-07-05 06:12:08 --> Hooks Class Initialized
DEBUG - 2021-07-05 06:12:08 --> UTF-8 Support Enabled
DEBUG - 2021-07-05 06:12:08 --> UTF-8 Support Enabled
INFO - 2021-07-05 06:12:08 --> Utf8 Class Initialized
INFO - 2021-07-05 06:12:08 --> Utf8 Class Initialized
INFO - 2021-07-05 06:12:08 --> URI Class Initialized
INFO - 2021-07-05 06:12:08 --> URI Class Initialized
INFO - 2021-07-05 06:12:08 --> Router Class Initialized
INFO - 2021-07-05 06:12:08 --> Router Class Initialized
INFO - 2021-07-05 06:12:08 --> Output Class Initialized
INFO - 2021-07-05 06:12:08 --> Output Class Initialized
INFO - 2021-07-05 06:12:08 --> Security Class Initialized
INFO - 2021-07-05 06:12:08 --> Security Class Initialized
DEBUG - 2021-07-05 06:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-05 06:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 06:12:08 --> Input Class Initialized
INFO - 2021-07-05 06:12:08 --> Input Class Initialized
INFO - 2021-07-05 06:12:08 --> Language Class Initialized
INFO - 2021-07-05 06:12:08 --> Language Class Initialized
INFO - 2021-07-05 06:12:08 --> Loader Class Initialized
INFO - 2021-07-05 06:12:08 --> Loader Class Initialized
INFO - 2021-07-05 06:12:08 --> Helper loaded: html_helper
INFO - 2021-07-05 06:12:08 --> Helper loaded: html_helper
INFO - 2021-07-05 06:12:08 --> Helper loaded: url_helper
INFO - 2021-07-05 06:12:08 --> Helper loaded: url_helper
INFO - 2021-07-05 06:12:08 --> Helper loaded: form_helper
INFO - 2021-07-05 06:12:08 --> Helper loaded: form_helper
INFO - 2021-07-05 06:12:08 --> Database Driver Class Initialized
INFO - 2021-07-05 06:12:08 --> Database Driver Class Initialized
INFO - 2021-07-05 06:12:09 --> Form Validation Class Initialized
DEBUG - 2021-07-05 06:12:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 06:12:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 06:12:09 --> Encryption Class Initialized
INFO - 2021-07-05 06:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 06:12:09 --> Model "vendor_model" initialized
INFO - 2021-07-05 06:12:09 --> Model "coupon_model" initialized
INFO - 2021-07-05 06:12:09 --> Model "user_model" initialized
INFO - 2021-07-05 06:12:09 --> Model "role_model" initialized
INFO - 2021-07-05 06:12:09 --> Controller Class Initialized
INFO - 2021-07-05 06:12:09 --> Helper loaded: language_helper
INFO - 2021-07-05 06:12:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 06:12:09 --> Model "Quotation_model" initialized
INFO - 2021-07-05 06:12:09 --> Form Validation Class Initialized
DEBUG - 2021-07-05 06:12:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 06:12:09 --> Final output sent to browser
INFO - 2021-07-05 06:12:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2021-07-05 06:12:09 --> Total execution time: 0.7341
INFO - 2021-07-05 06:12:09 --> Encryption Class Initialized
INFO - 2021-07-05 06:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 06:12:09 --> Model "vendor_model" initialized
INFO - 2021-07-05 06:12:09 --> Model "coupon_model" initialized
INFO - 2021-07-05 06:12:09 --> Model "user_model" initialized
INFO - 2021-07-05 06:12:09 --> Model "role_model" initialized
INFO - 2021-07-05 06:12:09 --> Controller Class Initialized
INFO - 2021-07-05 06:12:09 --> Helper loaded: language_helper
INFO - 2021-07-05 06:12:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 06:12:09 --> Model "Quotation_model" initialized
INFO - 2021-07-05 06:12:09 --> Final output sent to browser
DEBUG - 2021-07-05 06:12:09 --> Total execution time: 1.3378
INFO - 2021-07-05 06:20:42 --> Config Class Initialized
INFO - 2021-07-05 06:20:42 --> Hooks Class Initialized
DEBUG - 2021-07-05 06:20:42 --> UTF-8 Support Enabled
INFO - 2021-07-05 06:20:42 --> Utf8 Class Initialized
INFO - 2021-07-05 06:20:42 --> URI Class Initialized
INFO - 2021-07-05 06:20:42 --> Router Class Initialized
INFO - 2021-07-05 06:20:42 --> Output Class Initialized
INFO - 2021-07-05 06:20:42 --> Security Class Initialized
DEBUG - 2021-07-05 06:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 06:20:42 --> Input Class Initialized
INFO - 2021-07-05 06:20:42 --> Language Class Initialized
INFO - 2021-07-05 06:20:42 --> Loader Class Initialized
INFO - 2021-07-05 06:20:42 --> Helper loaded: html_helper
INFO - 2021-07-05 06:20:42 --> Helper loaded: url_helper
INFO - 2021-07-05 06:20:42 --> Helper loaded: form_helper
INFO - 2021-07-05 06:20:42 --> Database Driver Class Initialized
INFO - 2021-07-05 06:20:42 --> Form Validation Class Initialized
DEBUG - 2021-07-05 06:20:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 06:20:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 06:20:42 --> Encryption Class Initialized
INFO - 2021-07-05 06:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 06:20:42 --> Model "vendor_model" initialized
INFO - 2021-07-05 06:20:42 --> Model "coupon_model" initialized
INFO - 2021-07-05 06:20:42 --> Model "user_model" initialized
INFO - 2021-07-05 06:20:42 --> Model "role_model" initialized
INFO - 2021-07-05 06:20:42 --> Controller Class Initialized
INFO - 2021-07-05 06:20:42 --> Helper loaded: language_helper
INFO - 2021-07-05 06:20:43 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 06:20:43 --> Model "Quotation_model" initialized
INFO - 2021-07-05 06:20:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 06:20:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 06:20:43 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-05 06:20:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-05 06:20:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 06:20:43 --> Final output sent to browser
DEBUG - 2021-07-05 06:20:43 --> Total execution time: 0.1270
INFO - 2021-07-05 06:20:54 --> Config Class Initialized
INFO - 2021-07-05 06:20:54 --> Hooks Class Initialized
INFO - 2021-07-05 06:20:54 --> Config Class Initialized
INFO - 2021-07-05 06:20:54 --> Hooks Class Initialized
DEBUG - 2021-07-05 06:20:54 --> UTF-8 Support Enabled
INFO - 2021-07-05 06:20:54 --> Utf8 Class Initialized
INFO - 2021-07-05 06:20:54 --> URI Class Initialized
DEBUG - 2021-07-05 06:20:54 --> UTF-8 Support Enabled
INFO - 2021-07-05 06:20:54 --> Utf8 Class Initialized
INFO - 2021-07-05 06:20:54 --> URI Class Initialized
INFO - 2021-07-05 06:20:54 --> Router Class Initialized
INFO - 2021-07-05 06:20:54 --> Output Class Initialized
INFO - 2021-07-05 06:20:54 --> Security Class Initialized
DEBUG - 2021-07-05 06:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 06:20:54 --> Input Class Initialized
INFO - 2021-07-05 06:20:54 --> Language Class Initialized
INFO - 2021-07-05 06:20:54 --> Loader Class Initialized
INFO - 2021-07-05 06:20:54 --> Helper loaded: html_helper
INFO - 2021-07-05 06:20:54 --> Helper loaded: url_helper
INFO - 2021-07-05 06:20:54 --> Helper loaded: form_helper
INFO - 2021-07-05 06:20:54 --> Database Driver Class Initialized
INFO - 2021-07-05 06:20:54 --> Router Class Initialized
INFO - 2021-07-05 06:20:54 --> Output Class Initialized
INFO - 2021-07-05 06:20:54 --> Security Class Initialized
DEBUG - 2021-07-05 06:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 06:20:54 --> Input Class Initialized
INFO - 2021-07-05 06:20:54 --> Language Class Initialized
INFO - 2021-07-05 06:20:54 --> Loader Class Initialized
INFO - 2021-07-05 06:20:54 --> Helper loaded: html_helper
INFO - 2021-07-05 06:20:54 --> Helper loaded: url_helper
INFO - 2021-07-05 06:20:54 --> Helper loaded: form_helper
INFO - 2021-07-05 06:20:54 --> Database Driver Class Initialized
INFO - 2021-07-05 06:20:54 --> Form Validation Class Initialized
DEBUG - 2021-07-05 06:20:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 06:20:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 06:20:54 --> Encryption Class Initialized
INFO - 2021-07-05 06:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 06:20:54 --> Model "vendor_model" initialized
INFO - 2021-07-05 06:20:54 --> Model "coupon_model" initialized
INFO - 2021-07-05 06:20:54 --> Model "user_model" initialized
INFO - 2021-07-05 06:20:54 --> Model "role_model" initialized
INFO - 2021-07-05 06:20:54 --> Controller Class Initialized
INFO - 2021-07-05 06:20:54 --> Helper loaded: language_helper
INFO - 2021-07-05 06:20:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 06:20:54 --> Model "Quotation_model" initialized
INFO - 2021-07-05 06:20:54 --> Final output sent to browser
DEBUG - 2021-07-05 06:20:54 --> Total execution time: 0.3322
INFO - 2021-07-05 06:20:54 --> Form Validation Class Initialized
DEBUG - 2021-07-05 06:20:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 06:20:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 06:20:54 --> Encryption Class Initialized
INFO - 2021-07-05 06:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 06:20:54 --> Model "vendor_model" initialized
INFO - 2021-07-05 06:20:54 --> Model "coupon_model" initialized
INFO - 2021-07-05 06:20:54 --> Model "user_model" initialized
INFO - 2021-07-05 06:20:54 --> Model "role_model" initialized
INFO - 2021-07-05 06:20:54 --> Controller Class Initialized
INFO - 2021-07-05 06:20:54 --> Helper loaded: language_helper
INFO - 2021-07-05 06:20:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 06:20:54 --> Model "Quotation_model" initialized
INFO - 2021-07-05 06:20:54 --> Final output sent to browser
DEBUG - 2021-07-05 06:20:54 --> Total execution time: 0.3630
INFO - 2021-07-05 06:44:25 --> Config Class Initialized
INFO - 2021-07-05 06:44:25 --> Hooks Class Initialized
DEBUG - 2021-07-05 06:44:25 --> UTF-8 Support Enabled
INFO - 2021-07-05 06:44:25 --> Utf8 Class Initialized
INFO - 2021-07-05 06:44:25 --> URI Class Initialized
DEBUG - 2021-07-05 06:44:25 --> No URI present. Default controller set.
INFO - 2021-07-05 06:44:25 --> Router Class Initialized
INFO - 2021-07-05 06:44:25 --> Output Class Initialized
INFO - 2021-07-05 06:44:25 --> Security Class Initialized
DEBUG - 2021-07-05 06:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 06:44:25 --> Input Class Initialized
INFO - 2021-07-05 06:44:25 --> Language Class Initialized
INFO - 2021-07-05 06:44:25 --> Loader Class Initialized
INFO - 2021-07-05 06:44:25 --> Helper loaded: html_helper
INFO - 2021-07-05 06:44:25 --> Helper loaded: url_helper
INFO - 2021-07-05 06:44:25 --> Helper loaded: form_helper
INFO - 2021-07-05 06:44:25 --> Database Driver Class Initialized
INFO - 2021-07-05 06:44:25 --> Form Validation Class Initialized
DEBUG - 2021-07-05 06:44:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 06:44:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 06:44:25 --> Encryption Class Initialized
INFO - 2021-07-05 06:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 06:44:26 --> Model "vendor_model" initialized
INFO - 2021-07-05 06:44:26 --> Model "coupon_model" initialized
INFO - 2021-07-05 06:44:26 --> Model "user_model" initialized
INFO - 2021-07-05 06:44:26 --> Model "role_model" initialized
INFO - 2021-07-05 06:44:26 --> Controller Class Initialized
INFO - 2021-07-05 06:44:26 --> Helper loaded: language_helper
INFO - 2021-07-05 06:44:26 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 06:44:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 06:44:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 06:44:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 06:44:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 06:44:26 --> Final output sent to browser
DEBUG - 2021-07-05 06:44:26 --> Total execution time: 1.3797
INFO - 2021-07-05 06:44:33 --> Config Class Initialized
INFO - 2021-07-05 06:44:33 --> Hooks Class Initialized
DEBUG - 2021-07-05 06:44:33 --> UTF-8 Support Enabled
INFO - 2021-07-05 06:44:33 --> Utf8 Class Initialized
INFO - 2021-07-05 06:44:33 --> URI Class Initialized
INFO - 2021-07-05 06:44:33 --> Router Class Initialized
INFO - 2021-07-05 06:44:33 --> Output Class Initialized
INFO - 2021-07-05 06:44:33 --> Security Class Initialized
DEBUG - 2021-07-05 06:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 06:44:33 --> Input Class Initialized
INFO - 2021-07-05 06:44:33 --> Language Class Initialized
INFO - 2021-07-05 06:44:33 --> Loader Class Initialized
INFO - 2021-07-05 06:44:33 --> Helper loaded: html_helper
INFO - 2021-07-05 06:44:33 --> Helper loaded: url_helper
INFO - 2021-07-05 06:44:33 --> Helper loaded: form_helper
INFO - 2021-07-05 06:44:33 --> Database Driver Class Initialized
INFO - 2021-07-05 06:44:33 --> Form Validation Class Initialized
DEBUG - 2021-07-05 06:44:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 06:44:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 06:44:33 --> Encryption Class Initialized
INFO - 2021-07-05 06:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 06:44:33 --> Model "vendor_model" initialized
INFO - 2021-07-05 06:44:33 --> Model "coupon_model" initialized
INFO - 2021-07-05 06:44:33 --> Model "user_model" initialized
INFO - 2021-07-05 06:44:33 --> Model "role_model" initialized
INFO - 2021-07-05 06:44:33 --> Controller Class Initialized
INFO - 2021-07-05 06:44:33 --> Helper loaded: language_helper
INFO - 2021-07-05 06:44:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 06:44:33 --> Model "Customer_model" initialized
INFO - 2021-07-05 06:44:33 --> Model "Product_model" initialized
INFO - 2021-07-05 06:44:33 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 06:44:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 06:44:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 06:44:33 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 06:44:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 06:44:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 06:44:33 --> Final output sent to browser
DEBUG - 2021-07-05 06:44:33 --> Total execution time: 0.1692
INFO - 2021-07-05 06:44:46 --> Config Class Initialized
INFO - 2021-07-05 06:44:46 --> Hooks Class Initialized
DEBUG - 2021-07-05 06:44:46 --> UTF-8 Support Enabled
INFO - 2021-07-05 06:44:46 --> Utf8 Class Initialized
INFO - 2021-07-05 06:44:46 --> URI Class Initialized
INFO - 2021-07-05 06:44:46 --> Router Class Initialized
INFO - 2021-07-05 06:44:46 --> Output Class Initialized
INFO - 2021-07-05 06:44:46 --> Security Class Initialized
DEBUG - 2021-07-05 06:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 06:44:46 --> Input Class Initialized
INFO - 2021-07-05 06:44:46 --> Language Class Initialized
INFO - 2021-07-05 06:44:46 --> Loader Class Initialized
INFO - 2021-07-05 06:44:46 --> Helper loaded: html_helper
INFO - 2021-07-05 06:44:46 --> Helper loaded: url_helper
INFO - 2021-07-05 06:44:46 --> Helper loaded: form_helper
INFO - 2021-07-05 06:44:46 --> Database Driver Class Initialized
INFO - 2021-07-05 06:44:46 --> Form Validation Class Initialized
DEBUG - 2021-07-05 06:44:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 06:44:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 06:44:46 --> Encryption Class Initialized
INFO - 2021-07-05 06:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 06:44:46 --> Model "vendor_model" initialized
INFO - 2021-07-05 06:44:46 --> Model "coupon_model" initialized
INFO - 2021-07-05 06:44:46 --> Model "user_model" initialized
INFO - 2021-07-05 06:44:46 --> Model "role_model" initialized
INFO - 2021-07-05 06:44:46 --> Controller Class Initialized
INFO - 2021-07-05 06:44:46 --> Helper loaded: language_helper
INFO - 2021-07-05 06:44:46 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 06:44:46 --> Model "Quotation_model" initialized
INFO - 2021-07-05 06:44:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 06:44:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 06:44:46 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-05 06:44:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-05 06:44:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 06:44:46 --> Final output sent to browser
DEBUG - 2021-07-05 06:44:46 --> Total execution time: 0.0658
INFO - 2021-07-05 06:47:50 --> Config Class Initialized
INFO - 2021-07-05 06:47:50 --> Hooks Class Initialized
DEBUG - 2021-07-05 06:47:50 --> UTF-8 Support Enabled
INFO - 2021-07-05 06:47:50 --> Utf8 Class Initialized
INFO - 2021-07-05 06:47:50 --> URI Class Initialized
INFO - 2021-07-05 06:47:50 --> Router Class Initialized
INFO - 2021-07-05 06:47:50 --> Output Class Initialized
INFO - 2021-07-05 06:47:50 --> Security Class Initialized
DEBUG - 2021-07-05 06:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 06:47:50 --> Input Class Initialized
INFO - 2021-07-05 06:47:50 --> Language Class Initialized
INFO - 2021-07-05 06:47:50 --> Loader Class Initialized
INFO - 2021-07-05 06:47:50 --> Helper loaded: html_helper
INFO - 2021-07-05 06:47:50 --> Helper loaded: url_helper
INFO - 2021-07-05 06:47:50 --> Helper loaded: form_helper
INFO - 2021-07-05 06:47:50 --> Database Driver Class Initialized
INFO - 2021-07-05 06:47:50 --> Form Validation Class Initialized
DEBUG - 2021-07-05 06:47:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 06:47:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 06:47:50 --> Encryption Class Initialized
INFO - 2021-07-05 06:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 06:47:50 --> Model "vendor_model" initialized
INFO - 2021-07-05 06:47:50 --> Model "coupon_model" initialized
INFO - 2021-07-05 06:47:50 --> Model "user_model" initialized
INFO - 2021-07-05 06:47:50 --> Model "role_model" initialized
INFO - 2021-07-05 06:47:50 --> Controller Class Initialized
INFO - 2021-07-05 06:47:50 --> Helper loaded: language_helper
INFO - 2021-07-05 06:47:50 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 06:47:50 --> Model "Customer_model" initialized
INFO - 2021-07-05 06:47:50 --> Model "Product_model" initialized
INFO - 2021-07-05 06:47:50 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 06:47:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 06:47:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 06:47:50 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 06:47:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 06:47:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 06:47:50 --> Final output sent to browser
DEBUG - 2021-07-05 06:47:50 --> Total execution time: 0.0798
INFO - 2021-07-05 06:49:35 --> Config Class Initialized
INFO - 2021-07-05 06:49:35 --> Hooks Class Initialized
DEBUG - 2021-07-05 06:49:35 --> UTF-8 Support Enabled
INFO - 2021-07-05 06:49:35 --> Utf8 Class Initialized
INFO - 2021-07-05 06:49:35 --> URI Class Initialized
INFO - 2021-07-05 06:49:35 --> Router Class Initialized
INFO - 2021-07-05 06:49:35 --> Output Class Initialized
INFO - 2021-07-05 06:49:35 --> Security Class Initialized
DEBUG - 2021-07-05 06:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 06:49:35 --> Input Class Initialized
INFO - 2021-07-05 06:49:35 --> Language Class Initialized
INFO - 2021-07-05 06:49:35 --> Loader Class Initialized
INFO - 2021-07-05 06:49:35 --> Helper loaded: html_helper
INFO - 2021-07-05 06:49:35 --> Helper loaded: url_helper
INFO - 2021-07-05 06:49:35 --> Helper loaded: form_helper
INFO - 2021-07-05 06:49:35 --> Database Driver Class Initialized
INFO - 2021-07-05 06:49:35 --> Form Validation Class Initialized
DEBUG - 2021-07-05 06:49:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 06:49:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 06:49:35 --> Encryption Class Initialized
INFO - 2021-07-05 06:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 06:49:35 --> Model "vendor_model" initialized
INFO - 2021-07-05 06:49:35 --> Model "coupon_model" initialized
INFO - 2021-07-05 06:49:35 --> Model "user_model" initialized
INFO - 2021-07-05 06:49:35 --> Model "role_model" initialized
INFO - 2021-07-05 06:49:35 --> Controller Class Initialized
INFO - 2021-07-05 06:49:35 --> Helper loaded: language_helper
INFO - 2021-07-05 06:49:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 06:49:35 --> Model "Customer_model" initialized
INFO - 2021-07-05 06:49:35 --> Model "Product_model" initialized
INFO - 2021-07-05 06:49:35 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 06:49:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 06:49:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 06:49:35 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 06:49:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 06:49:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 06:49:35 --> Final output sent to browser
DEBUG - 2021-07-05 06:49:35 --> Total execution time: 0.0803
INFO - 2021-07-05 06:57:19 --> Config Class Initialized
INFO - 2021-07-05 06:57:19 --> Hooks Class Initialized
DEBUG - 2021-07-05 06:57:19 --> UTF-8 Support Enabled
INFO - 2021-07-05 06:57:19 --> Utf8 Class Initialized
INFO - 2021-07-05 06:57:19 --> URI Class Initialized
DEBUG - 2021-07-05 06:57:19 --> No URI present. Default controller set.
INFO - 2021-07-05 06:57:19 --> Router Class Initialized
INFO - 2021-07-05 06:57:19 --> Output Class Initialized
INFO - 2021-07-05 06:57:19 --> Security Class Initialized
DEBUG - 2021-07-05 06:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 06:57:19 --> Input Class Initialized
INFO - 2021-07-05 06:57:19 --> Language Class Initialized
INFO - 2021-07-05 06:57:19 --> Loader Class Initialized
INFO - 2021-07-05 06:57:19 --> Helper loaded: html_helper
INFO - 2021-07-05 06:57:19 --> Helper loaded: url_helper
INFO - 2021-07-05 06:57:19 --> Helper loaded: form_helper
INFO - 2021-07-05 06:57:19 --> Database Driver Class Initialized
INFO - 2021-07-05 06:57:19 --> Form Validation Class Initialized
DEBUG - 2021-07-05 06:57:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 06:57:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 06:57:19 --> Encryption Class Initialized
INFO - 2021-07-05 06:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 06:57:19 --> Model "vendor_model" initialized
INFO - 2021-07-05 06:57:19 --> Model "coupon_model" initialized
INFO - 2021-07-05 06:57:19 --> Model "user_model" initialized
INFO - 2021-07-05 06:57:19 --> Model "role_model" initialized
INFO - 2021-07-05 06:57:19 --> Controller Class Initialized
INFO - 2021-07-05 06:57:19 --> Helper loaded: language_helper
INFO - 2021-07-05 06:57:19 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 06:57:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 06:57:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 06:57:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 06:57:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 06:57:19 --> Final output sent to browser
DEBUG - 2021-07-05 06:57:19 --> Total execution time: 0.0811
INFO - 2021-07-05 06:57:35 --> Config Class Initialized
INFO - 2021-07-05 06:57:35 --> Hooks Class Initialized
DEBUG - 2021-07-05 06:57:35 --> UTF-8 Support Enabled
INFO - 2021-07-05 06:57:35 --> Utf8 Class Initialized
INFO - 2021-07-05 06:57:35 --> URI Class Initialized
DEBUG - 2021-07-05 06:57:35 --> No URI present. Default controller set.
INFO - 2021-07-05 06:57:35 --> Router Class Initialized
INFO - 2021-07-05 06:57:35 --> Output Class Initialized
INFO - 2021-07-05 06:57:35 --> Security Class Initialized
DEBUG - 2021-07-05 06:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 06:57:35 --> Input Class Initialized
INFO - 2021-07-05 06:57:35 --> Language Class Initialized
INFO - 2021-07-05 06:57:35 --> Loader Class Initialized
INFO - 2021-07-05 06:57:36 --> Helper loaded: html_helper
INFO - 2021-07-05 06:57:36 --> Helper loaded: url_helper
INFO - 2021-07-05 06:57:36 --> Helper loaded: form_helper
INFO - 2021-07-05 06:57:36 --> Database Driver Class Initialized
INFO - 2021-07-05 06:57:36 --> Form Validation Class Initialized
DEBUG - 2021-07-05 06:57:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 06:57:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 06:57:36 --> Encryption Class Initialized
INFO - 2021-07-05 06:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 06:57:36 --> Model "vendor_model" initialized
INFO - 2021-07-05 06:57:36 --> Model "coupon_model" initialized
INFO - 2021-07-05 06:57:36 --> Model "user_model" initialized
INFO - 2021-07-05 06:57:36 --> Model "role_model" initialized
INFO - 2021-07-05 06:57:36 --> Controller Class Initialized
INFO - 2021-07-05 06:57:36 --> Helper loaded: language_helper
INFO - 2021-07-05 06:57:36 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 06:57:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 06:57:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 06:57:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 06:57:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 06:57:36 --> Final output sent to browser
DEBUG - 2021-07-05 06:57:36 --> Total execution time: 0.0709
INFO - 2021-07-05 06:57:52 --> Config Class Initialized
INFO - 2021-07-05 06:57:52 --> Hooks Class Initialized
DEBUG - 2021-07-05 06:57:52 --> UTF-8 Support Enabled
INFO - 2021-07-05 06:57:52 --> Utf8 Class Initialized
INFO - 2021-07-05 06:57:52 --> URI Class Initialized
INFO - 2021-07-05 06:57:52 --> Router Class Initialized
INFO - 2021-07-05 06:57:52 --> Output Class Initialized
INFO - 2021-07-05 06:57:52 --> Security Class Initialized
DEBUG - 2021-07-05 06:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 06:57:52 --> Input Class Initialized
INFO - 2021-07-05 06:57:52 --> Language Class Initialized
INFO - 2021-07-05 06:57:52 --> Loader Class Initialized
INFO - 2021-07-05 06:57:52 --> Helper loaded: html_helper
INFO - 2021-07-05 06:57:52 --> Helper loaded: url_helper
INFO - 2021-07-05 06:57:52 --> Helper loaded: form_helper
INFO - 2021-07-05 06:57:52 --> Database Driver Class Initialized
INFO - 2021-07-05 06:57:52 --> Form Validation Class Initialized
DEBUG - 2021-07-05 06:57:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 06:57:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 06:57:52 --> Encryption Class Initialized
INFO - 2021-07-05 06:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 06:57:52 --> Model "vendor_model" initialized
INFO - 2021-07-05 06:57:52 --> Model "coupon_model" initialized
INFO - 2021-07-05 06:57:52 --> Model "user_model" initialized
INFO - 2021-07-05 06:57:52 --> Model "role_model" initialized
INFO - 2021-07-05 06:57:52 --> Controller Class Initialized
INFO - 2021-07-05 06:57:52 --> Helper loaded: language_helper
INFO - 2021-07-05 06:57:52 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 06:57:52 --> Model "Customer_model" initialized
INFO - 2021-07-05 06:57:52 --> Model "Product_model" initialized
INFO - 2021-07-05 06:57:52 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 06:57:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 06:57:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 06:57:52 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 06:57:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 06:57:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 06:57:52 --> Final output sent to browser
DEBUG - 2021-07-05 06:57:52 --> Total execution time: 0.0813
INFO - 2021-07-05 06:58:44 --> Config Class Initialized
INFO - 2021-07-05 06:58:44 --> Hooks Class Initialized
DEBUG - 2021-07-05 06:58:44 --> UTF-8 Support Enabled
INFO - 2021-07-05 06:58:44 --> Utf8 Class Initialized
INFO - 2021-07-05 06:58:44 --> URI Class Initialized
INFO - 2021-07-05 06:58:44 --> Router Class Initialized
INFO - 2021-07-05 06:58:44 --> Output Class Initialized
INFO - 2021-07-05 06:58:44 --> Security Class Initialized
DEBUG - 2021-07-05 06:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 06:58:44 --> Input Class Initialized
INFO - 2021-07-05 06:58:44 --> Language Class Initialized
INFO - 2021-07-05 06:58:44 --> Loader Class Initialized
INFO - 2021-07-05 06:58:44 --> Helper loaded: html_helper
INFO - 2021-07-05 06:58:44 --> Helper loaded: url_helper
INFO - 2021-07-05 06:58:44 --> Helper loaded: form_helper
INFO - 2021-07-05 06:58:44 --> Database Driver Class Initialized
INFO - 2021-07-05 06:58:44 --> Form Validation Class Initialized
DEBUG - 2021-07-05 06:58:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 06:58:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 06:58:44 --> Encryption Class Initialized
INFO - 2021-07-05 06:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 06:58:44 --> Model "vendor_model" initialized
INFO - 2021-07-05 06:58:44 --> Model "coupon_model" initialized
INFO - 2021-07-05 06:58:44 --> Model "user_model" initialized
INFO - 2021-07-05 06:58:44 --> Model "role_model" initialized
INFO - 2021-07-05 06:58:44 --> Controller Class Initialized
INFO - 2021-07-05 06:58:44 --> Helper loaded: language_helper
INFO - 2021-07-05 06:58:44 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 06:58:44 --> Model "Customer_model" initialized
INFO - 2021-07-05 06:58:44 --> Final output sent to browser
DEBUG - 2021-07-05 06:58:44 --> Total execution time: 0.0703
INFO - 2021-07-05 07:00:42 --> Config Class Initialized
INFO - 2021-07-05 07:00:42 --> Hooks Class Initialized
DEBUG - 2021-07-05 07:00:42 --> UTF-8 Support Enabled
INFO - 2021-07-05 07:00:42 --> Utf8 Class Initialized
INFO - 2021-07-05 07:00:42 --> URI Class Initialized
INFO - 2021-07-05 07:00:42 --> Router Class Initialized
INFO - 2021-07-05 07:00:42 --> Output Class Initialized
INFO - 2021-07-05 07:00:42 --> Security Class Initialized
DEBUG - 2021-07-05 07:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 07:00:42 --> Input Class Initialized
INFO - 2021-07-05 07:00:42 --> Language Class Initialized
INFO - 2021-07-05 07:00:42 --> Loader Class Initialized
INFO - 2021-07-05 07:00:42 --> Helper loaded: html_helper
INFO - 2021-07-05 07:00:42 --> Helper loaded: url_helper
INFO - 2021-07-05 07:00:42 --> Helper loaded: form_helper
INFO - 2021-07-05 07:00:43 --> Database Driver Class Initialized
INFO - 2021-07-05 07:00:43 --> Form Validation Class Initialized
DEBUG - 2021-07-05 07:00:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 07:00:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 07:00:43 --> Encryption Class Initialized
INFO - 2021-07-05 07:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 07:00:43 --> Model "vendor_model" initialized
INFO - 2021-07-05 07:00:43 --> Model "coupon_model" initialized
INFO - 2021-07-05 07:00:43 --> Model "user_model" initialized
INFO - 2021-07-05 07:00:43 --> Model "role_model" initialized
INFO - 2021-07-05 07:00:43 --> Controller Class Initialized
INFO - 2021-07-05 07:00:43 --> Helper loaded: language_helper
INFO - 2021-07-05 07:00:43 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 07:00:43 --> Model "Customer_model" initialized
INFO - 2021-07-05 07:00:43 --> Model "Product_model" initialized
INFO - 2021-07-05 07:00:43 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 07:00:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 07:00:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 07:00:43 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 07:00:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 07:00:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 07:00:43 --> Final output sent to browser
DEBUG - 2021-07-05 07:00:43 --> Total execution time: 0.0844
INFO - 2021-07-05 07:25:28 --> Config Class Initialized
INFO - 2021-07-05 07:25:28 --> Hooks Class Initialized
DEBUG - 2021-07-05 07:25:28 --> UTF-8 Support Enabled
INFO - 2021-07-05 07:25:28 --> Utf8 Class Initialized
INFO - 2021-07-05 07:25:28 --> URI Class Initialized
DEBUG - 2021-07-05 07:25:28 --> No URI present. Default controller set.
INFO - 2021-07-05 07:25:28 --> Router Class Initialized
INFO - 2021-07-05 07:25:28 --> Output Class Initialized
INFO - 2021-07-05 07:25:28 --> Security Class Initialized
DEBUG - 2021-07-05 07:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 07:25:28 --> Input Class Initialized
INFO - 2021-07-05 07:25:28 --> Language Class Initialized
INFO - 2021-07-05 07:25:28 --> Loader Class Initialized
INFO - 2021-07-05 07:25:28 --> Helper loaded: html_helper
INFO - 2021-07-05 07:25:28 --> Helper loaded: url_helper
INFO - 2021-07-05 07:25:28 --> Helper loaded: form_helper
INFO - 2021-07-05 07:25:28 --> Database Driver Class Initialized
INFO - 2021-07-05 07:25:29 --> Form Validation Class Initialized
DEBUG - 2021-07-05 07:25:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 07:25:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 07:25:29 --> Encryption Class Initialized
INFO - 2021-07-05 07:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 07:25:29 --> Model "vendor_model" initialized
INFO - 2021-07-05 07:25:29 --> Model "coupon_model" initialized
INFO - 2021-07-05 07:25:29 --> Model "user_model" initialized
INFO - 2021-07-05 07:25:29 --> Model "role_model" initialized
INFO - 2021-07-05 07:25:29 --> Controller Class Initialized
INFO - 2021-07-05 07:25:29 --> Helper loaded: language_helper
INFO - 2021-07-05 07:25:29 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 07:25:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 07:25:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 07:25:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 07:25:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 07:25:29 --> Final output sent to browser
DEBUG - 2021-07-05 07:25:29 --> Total execution time: 0.0765
INFO - 2021-07-05 07:30:06 --> Config Class Initialized
INFO - 2021-07-05 07:30:06 --> Hooks Class Initialized
DEBUG - 2021-07-05 07:30:06 --> UTF-8 Support Enabled
INFO - 2021-07-05 07:30:06 --> Utf8 Class Initialized
INFO - 2021-07-05 07:30:06 --> URI Class Initialized
INFO - 2021-07-05 07:30:06 --> Router Class Initialized
INFO - 2021-07-05 07:30:06 --> Output Class Initialized
INFO - 2021-07-05 07:30:06 --> Security Class Initialized
DEBUG - 2021-07-05 07:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 07:30:06 --> Input Class Initialized
INFO - 2021-07-05 07:30:06 --> Language Class Initialized
INFO - 2021-07-05 07:30:06 --> Loader Class Initialized
INFO - 2021-07-05 07:30:06 --> Helper loaded: html_helper
INFO - 2021-07-05 07:30:06 --> Helper loaded: url_helper
INFO - 2021-07-05 07:30:06 --> Helper loaded: form_helper
INFO - 2021-07-05 07:30:06 --> Database Driver Class Initialized
INFO - 2021-07-05 07:30:06 --> Form Validation Class Initialized
DEBUG - 2021-07-05 07:30:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 07:30:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 07:30:06 --> Encryption Class Initialized
INFO - 2021-07-05 07:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 07:30:06 --> Model "vendor_model" initialized
INFO - 2021-07-05 07:30:06 --> Model "coupon_model" initialized
INFO - 2021-07-05 07:30:06 --> Model "user_model" initialized
INFO - 2021-07-05 07:30:06 --> Model "role_model" initialized
INFO - 2021-07-05 07:30:06 --> Controller Class Initialized
INFO - 2021-07-05 07:30:06 --> Helper loaded: language_helper
INFO - 2021-07-05 07:30:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 07:30:06 --> Model "Quotation_model" initialized
INFO - 2021-07-05 07:30:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 07:30:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 07:30:06 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-05 07:30:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-05 07:30:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 07:30:06 --> Final output sent to browser
DEBUG - 2021-07-05 07:30:06 --> Total execution time: 0.1392
INFO - 2021-07-05 07:36:48 --> Config Class Initialized
INFO - 2021-07-05 07:36:48 --> Hooks Class Initialized
DEBUG - 2021-07-05 07:36:48 --> UTF-8 Support Enabled
INFO - 2021-07-05 07:36:48 --> Utf8 Class Initialized
INFO - 2021-07-05 07:36:48 --> URI Class Initialized
DEBUG - 2021-07-05 07:36:48 --> No URI present. Default controller set.
INFO - 2021-07-05 07:36:48 --> Router Class Initialized
INFO - 2021-07-05 07:36:48 --> Output Class Initialized
INFO - 2021-07-05 07:36:48 --> Security Class Initialized
DEBUG - 2021-07-05 07:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 07:36:48 --> Input Class Initialized
INFO - 2021-07-05 07:36:48 --> Language Class Initialized
INFO - 2021-07-05 07:36:48 --> Loader Class Initialized
INFO - 2021-07-05 07:36:48 --> Helper loaded: html_helper
INFO - 2021-07-05 07:36:48 --> Helper loaded: url_helper
INFO - 2021-07-05 07:36:48 --> Helper loaded: form_helper
INFO - 2021-07-05 07:36:48 --> Database Driver Class Initialized
INFO - 2021-07-05 07:36:48 --> Form Validation Class Initialized
DEBUG - 2021-07-05 07:36:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 07:36:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 07:36:48 --> Encryption Class Initialized
INFO - 2021-07-05 07:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 07:36:48 --> Model "vendor_model" initialized
INFO - 2021-07-05 07:36:48 --> Model "coupon_model" initialized
INFO - 2021-07-05 07:36:48 --> Model "user_model" initialized
INFO - 2021-07-05 07:36:48 --> Model "role_model" initialized
INFO - 2021-07-05 07:36:48 --> Controller Class Initialized
INFO - 2021-07-05 07:36:48 --> Helper loaded: language_helper
INFO - 2021-07-05 07:36:48 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 07:36:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 07:36:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 07:36:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 07:36:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 07:36:48 --> Final output sent to browser
DEBUG - 2021-07-05 07:36:48 --> Total execution time: 0.1069
INFO - 2021-07-05 07:37:03 --> Config Class Initialized
INFO - 2021-07-05 07:37:03 --> Hooks Class Initialized
DEBUG - 2021-07-05 07:37:03 --> UTF-8 Support Enabled
INFO - 2021-07-05 07:37:03 --> Utf8 Class Initialized
INFO - 2021-07-05 07:37:03 --> URI Class Initialized
DEBUG - 2021-07-05 07:37:03 --> No URI present. Default controller set.
INFO - 2021-07-05 07:37:03 --> Router Class Initialized
INFO - 2021-07-05 07:37:03 --> Output Class Initialized
INFO - 2021-07-05 07:37:03 --> Security Class Initialized
DEBUG - 2021-07-05 07:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 07:37:03 --> Input Class Initialized
INFO - 2021-07-05 07:37:03 --> Language Class Initialized
INFO - 2021-07-05 07:37:03 --> Loader Class Initialized
INFO - 2021-07-05 07:37:03 --> Helper loaded: html_helper
INFO - 2021-07-05 07:37:03 --> Helper loaded: url_helper
INFO - 2021-07-05 07:37:03 --> Helper loaded: form_helper
INFO - 2021-07-05 07:37:03 --> Database Driver Class Initialized
INFO - 2021-07-05 07:37:03 --> Form Validation Class Initialized
DEBUG - 2021-07-05 07:37:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 07:37:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 07:37:03 --> Encryption Class Initialized
INFO - 2021-07-05 07:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 07:37:03 --> Model "vendor_model" initialized
INFO - 2021-07-05 07:37:03 --> Model "coupon_model" initialized
INFO - 2021-07-05 07:37:03 --> Model "user_model" initialized
INFO - 2021-07-05 07:37:03 --> Model "role_model" initialized
INFO - 2021-07-05 07:37:03 --> Controller Class Initialized
INFO - 2021-07-05 07:37:03 --> Helper loaded: language_helper
INFO - 2021-07-05 07:37:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 07:37:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 07:37:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 07:37:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 07:37:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 07:37:03 --> Final output sent to browser
DEBUG - 2021-07-05 07:37:03 --> Total execution time: 0.0649
INFO - 2021-07-05 07:37:24 --> Config Class Initialized
INFO - 2021-07-05 07:37:24 --> Hooks Class Initialized
DEBUG - 2021-07-05 07:37:24 --> UTF-8 Support Enabled
INFO - 2021-07-05 07:37:24 --> Utf8 Class Initialized
INFO - 2021-07-05 07:37:24 --> URI Class Initialized
INFO - 2021-07-05 07:37:24 --> Router Class Initialized
INFO - 2021-07-05 07:37:24 --> Output Class Initialized
INFO - 2021-07-05 07:37:24 --> Security Class Initialized
DEBUG - 2021-07-05 07:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 07:37:24 --> Input Class Initialized
INFO - 2021-07-05 07:37:24 --> Language Class Initialized
INFO - 2021-07-05 07:37:24 --> Loader Class Initialized
INFO - 2021-07-05 07:37:24 --> Helper loaded: html_helper
INFO - 2021-07-05 07:37:24 --> Helper loaded: url_helper
INFO - 2021-07-05 07:37:24 --> Helper loaded: form_helper
INFO - 2021-07-05 07:37:24 --> Database Driver Class Initialized
INFO - 2021-07-05 07:37:24 --> Form Validation Class Initialized
DEBUG - 2021-07-05 07:37:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 07:37:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 07:37:24 --> Encryption Class Initialized
INFO - 2021-07-05 07:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 07:37:24 --> Model "vendor_model" initialized
INFO - 2021-07-05 07:37:24 --> Model "coupon_model" initialized
INFO - 2021-07-05 07:37:24 --> Model "user_model" initialized
INFO - 2021-07-05 07:37:24 --> Model "role_model" initialized
INFO - 2021-07-05 07:37:24 --> Controller Class Initialized
INFO - 2021-07-05 07:37:24 --> Helper loaded: language_helper
INFO - 2021-07-05 07:37:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 07:37:24 --> Model "Customer_model" initialized
INFO - 2021-07-05 07:37:24 --> Model "Product_model" initialized
INFO - 2021-07-05 07:37:24 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 07:37:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 07:37:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 07:37:24 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 07:37:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 07:37:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 07:37:24 --> Final output sent to browser
DEBUG - 2021-07-05 07:37:24 --> Total execution time: 0.0679
INFO - 2021-07-05 07:46:53 --> Config Class Initialized
INFO - 2021-07-05 07:46:53 --> Hooks Class Initialized
DEBUG - 2021-07-05 07:46:53 --> UTF-8 Support Enabled
INFO - 2021-07-05 07:46:53 --> Utf8 Class Initialized
INFO - 2021-07-05 07:46:53 --> URI Class Initialized
INFO - 2021-07-05 07:46:53 --> Router Class Initialized
INFO - 2021-07-05 07:46:53 --> Output Class Initialized
INFO - 2021-07-05 07:46:53 --> Security Class Initialized
DEBUG - 2021-07-05 07:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 07:46:53 --> Input Class Initialized
INFO - 2021-07-05 07:46:53 --> Language Class Initialized
INFO - 2021-07-05 07:46:53 --> Loader Class Initialized
INFO - 2021-07-05 07:46:53 --> Helper loaded: html_helper
INFO - 2021-07-05 07:46:53 --> Helper loaded: url_helper
INFO - 2021-07-05 07:46:53 --> Helper loaded: form_helper
INFO - 2021-07-05 07:46:53 --> Database Driver Class Initialized
INFO - 2021-07-05 07:46:53 --> Form Validation Class Initialized
DEBUG - 2021-07-05 07:46:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 07:46:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 07:46:53 --> Encryption Class Initialized
INFO - 2021-07-05 07:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 07:46:53 --> Model "vendor_model" initialized
INFO - 2021-07-05 07:46:53 --> Model "coupon_model" initialized
INFO - 2021-07-05 07:46:53 --> Model "user_model" initialized
INFO - 2021-07-05 07:46:53 --> Model "role_model" initialized
INFO - 2021-07-05 07:46:53 --> Controller Class Initialized
INFO - 2021-07-05 07:46:53 --> Helper loaded: language_helper
INFO - 2021-07-05 07:46:53 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 07:46:53 --> Model "Customer_model" initialized
INFO - 2021-07-05 07:46:53 --> Model "Product_model" initialized
INFO - 2021-07-05 07:46:53 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 07:46:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 07:46:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 07:46:53 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 07:46:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 07:46:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 07:46:53 --> Final output sent to browser
DEBUG - 2021-07-05 07:46:53 --> Total execution time: 0.0806
INFO - 2021-07-05 07:48:02 --> Config Class Initialized
INFO - 2021-07-05 07:48:02 --> Hooks Class Initialized
DEBUG - 2021-07-05 07:48:02 --> UTF-8 Support Enabled
INFO - 2021-07-05 07:48:02 --> Utf8 Class Initialized
INFO - 2021-07-05 07:48:02 --> URI Class Initialized
INFO - 2021-07-05 07:48:02 --> Router Class Initialized
INFO - 2021-07-05 07:48:02 --> Output Class Initialized
INFO - 2021-07-05 07:48:02 --> Security Class Initialized
DEBUG - 2021-07-05 07:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 07:48:02 --> Input Class Initialized
INFO - 2021-07-05 07:48:02 --> Language Class Initialized
INFO - 2021-07-05 07:48:02 --> Loader Class Initialized
INFO - 2021-07-05 07:48:02 --> Helper loaded: html_helper
INFO - 2021-07-05 07:48:02 --> Helper loaded: url_helper
INFO - 2021-07-05 07:48:02 --> Helper loaded: form_helper
INFO - 2021-07-05 07:48:02 --> Database Driver Class Initialized
INFO - 2021-07-05 07:48:02 --> Form Validation Class Initialized
DEBUG - 2021-07-05 07:48:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 07:48:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 07:48:02 --> Encryption Class Initialized
INFO - 2021-07-05 07:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 07:48:02 --> Model "vendor_model" initialized
INFO - 2021-07-05 07:48:02 --> Model "coupon_model" initialized
INFO - 2021-07-05 07:48:02 --> Model "user_model" initialized
INFO - 2021-07-05 07:48:02 --> Model "role_model" initialized
INFO - 2021-07-05 07:48:02 --> Controller Class Initialized
INFO - 2021-07-05 07:48:02 --> Helper loaded: language_helper
INFO - 2021-07-05 07:48:02 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 07:48:02 --> Model "Customer_model" initialized
INFO - 2021-07-05 07:48:02 --> Final output sent to browser
DEBUG - 2021-07-05 07:48:02 --> Total execution time: 0.0741
INFO - 2021-07-05 07:48:10 --> Config Class Initialized
INFO - 2021-07-05 07:48:10 --> Hooks Class Initialized
DEBUG - 2021-07-05 07:48:10 --> UTF-8 Support Enabled
INFO - 2021-07-05 07:48:10 --> Utf8 Class Initialized
INFO - 2021-07-05 07:48:10 --> URI Class Initialized
INFO - 2021-07-05 07:48:10 --> Router Class Initialized
INFO - 2021-07-05 07:48:10 --> Output Class Initialized
INFO - 2021-07-05 07:48:10 --> Security Class Initialized
DEBUG - 2021-07-05 07:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 07:48:10 --> Input Class Initialized
INFO - 2021-07-05 07:48:10 --> Language Class Initialized
INFO - 2021-07-05 07:48:10 --> Loader Class Initialized
INFO - 2021-07-05 07:48:10 --> Helper loaded: html_helper
INFO - 2021-07-05 07:48:10 --> Helper loaded: url_helper
INFO - 2021-07-05 07:48:10 --> Helper loaded: form_helper
INFO - 2021-07-05 07:48:10 --> Database Driver Class Initialized
INFO - 2021-07-05 07:48:10 --> Form Validation Class Initialized
DEBUG - 2021-07-05 07:48:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 07:48:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 07:48:10 --> Encryption Class Initialized
INFO - 2021-07-05 07:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 07:48:10 --> Model "vendor_model" initialized
INFO - 2021-07-05 07:48:10 --> Model "coupon_model" initialized
INFO - 2021-07-05 07:48:10 --> Model "user_model" initialized
INFO - 2021-07-05 07:48:10 --> Model "role_model" initialized
INFO - 2021-07-05 07:48:10 --> Controller Class Initialized
INFO - 2021-07-05 07:48:10 --> Helper loaded: language_helper
INFO - 2021-07-05 07:48:10 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 07:48:10 --> Model "Customer_model" initialized
INFO - 2021-07-05 07:48:10 --> Final output sent to browser
DEBUG - 2021-07-05 07:48:10 --> Total execution time: 0.0650
INFO - 2021-07-05 07:48:17 --> Config Class Initialized
INFO - 2021-07-05 07:48:17 --> Hooks Class Initialized
DEBUG - 2021-07-05 07:48:17 --> UTF-8 Support Enabled
INFO - 2021-07-05 07:48:17 --> Utf8 Class Initialized
INFO - 2021-07-05 07:48:17 --> URI Class Initialized
INFO - 2021-07-05 07:48:17 --> Router Class Initialized
INFO - 2021-07-05 07:48:17 --> Output Class Initialized
INFO - 2021-07-05 07:48:17 --> Security Class Initialized
DEBUG - 2021-07-05 07:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 07:48:17 --> Input Class Initialized
INFO - 2021-07-05 07:48:17 --> Language Class Initialized
INFO - 2021-07-05 07:48:17 --> Loader Class Initialized
INFO - 2021-07-05 07:48:17 --> Helper loaded: html_helper
INFO - 2021-07-05 07:48:18 --> Helper loaded: url_helper
INFO - 2021-07-05 07:48:18 --> Helper loaded: form_helper
INFO - 2021-07-05 07:48:18 --> Database Driver Class Initialized
INFO - 2021-07-05 07:48:18 --> Form Validation Class Initialized
DEBUG - 2021-07-05 07:48:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 07:48:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 07:48:18 --> Encryption Class Initialized
INFO - 2021-07-05 07:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 07:48:18 --> Model "vendor_model" initialized
INFO - 2021-07-05 07:48:18 --> Model "coupon_model" initialized
INFO - 2021-07-05 07:48:18 --> Model "user_model" initialized
INFO - 2021-07-05 07:48:18 --> Model "role_model" initialized
INFO - 2021-07-05 07:48:18 --> Controller Class Initialized
INFO - 2021-07-05 07:48:18 --> Helper loaded: language_helper
INFO - 2021-07-05 07:48:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 07:48:18 --> Model "Customer_model" initialized
INFO - 2021-07-05 07:48:18 --> Model "Product_model" initialized
INFO - 2021-07-05 07:48:18 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 07:48:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 07:48:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 07:48:18 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 07:48:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 07:48:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 07:48:18 --> Final output sent to browser
DEBUG - 2021-07-05 07:48:18 --> Total execution time: 0.0758
INFO - 2021-07-05 07:50:45 --> Config Class Initialized
INFO - 2021-07-05 07:50:45 --> Hooks Class Initialized
DEBUG - 2021-07-05 07:50:45 --> UTF-8 Support Enabled
INFO - 2021-07-05 07:50:45 --> Utf8 Class Initialized
INFO - 2021-07-05 07:50:45 --> URI Class Initialized
INFO - 2021-07-05 07:50:45 --> Router Class Initialized
INFO - 2021-07-05 07:50:45 --> Output Class Initialized
INFO - 2021-07-05 07:50:45 --> Security Class Initialized
DEBUG - 2021-07-05 07:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 07:50:45 --> Input Class Initialized
INFO - 2021-07-05 07:50:45 --> Language Class Initialized
INFO - 2021-07-05 07:50:45 --> Loader Class Initialized
INFO - 2021-07-05 07:50:45 --> Helper loaded: html_helper
INFO - 2021-07-05 07:50:45 --> Helper loaded: url_helper
INFO - 2021-07-05 07:50:45 --> Helper loaded: form_helper
INFO - 2021-07-05 07:50:45 --> Database Driver Class Initialized
INFO - 2021-07-05 07:50:45 --> Form Validation Class Initialized
DEBUG - 2021-07-05 07:50:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 07:50:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 07:50:45 --> Encryption Class Initialized
INFO - 2021-07-05 07:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 07:50:45 --> Model "vendor_model" initialized
INFO - 2021-07-05 07:50:45 --> Model "coupon_model" initialized
INFO - 2021-07-05 07:50:45 --> Model "user_model" initialized
INFO - 2021-07-05 07:50:45 --> Model "role_model" initialized
INFO - 2021-07-05 07:50:45 --> Controller Class Initialized
INFO - 2021-07-05 07:50:45 --> Helper loaded: language_helper
INFO - 2021-07-05 07:50:45 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 07:50:45 --> Model "Customer_model" initialized
INFO - 2021-07-05 07:50:45 --> Model "Product_model" initialized
INFO - 2021-07-05 07:50:45 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 07:50:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 07:50:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 07:50:45 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 07:50:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 07:50:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 07:50:45 --> Final output sent to browser
DEBUG - 2021-07-05 07:50:45 --> Total execution time: 0.0800
INFO - 2021-07-05 07:53:03 --> Config Class Initialized
INFO - 2021-07-05 07:53:03 --> Hooks Class Initialized
DEBUG - 2021-07-05 07:53:03 --> UTF-8 Support Enabled
INFO - 2021-07-05 07:53:03 --> Utf8 Class Initialized
INFO - 2021-07-05 07:53:03 --> URI Class Initialized
INFO - 2021-07-05 07:53:03 --> Router Class Initialized
INFO - 2021-07-05 07:53:03 --> Output Class Initialized
INFO - 2021-07-05 07:53:03 --> Security Class Initialized
DEBUG - 2021-07-05 07:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 07:53:03 --> Input Class Initialized
INFO - 2021-07-05 07:53:03 --> Language Class Initialized
INFO - 2021-07-05 07:53:03 --> Loader Class Initialized
INFO - 2021-07-05 07:53:03 --> Helper loaded: html_helper
INFO - 2021-07-05 07:53:03 --> Helper loaded: url_helper
INFO - 2021-07-05 07:53:03 --> Helper loaded: form_helper
INFO - 2021-07-05 07:53:03 --> Database Driver Class Initialized
INFO - 2021-07-05 07:53:03 --> Form Validation Class Initialized
DEBUG - 2021-07-05 07:53:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 07:53:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 07:53:03 --> Encryption Class Initialized
INFO - 2021-07-05 07:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 07:53:03 --> Model "vendor_model" initialized
INFO - 2021-07-05 07:53:03 --> Model "coupon_model" initialized
INFO - 2021-07-05 07:53:03 --> Model "user_model" initialized
INFO - 2021-07-05 07:53:03 --> Model "role_model" initialized
INFO - 2021-07-05 07:53:03 --> Controller Class Initialized
INFO - 2021-07-05 07:53:03 --> Helper loaded: language_helper
INFO - 2021-07-05 07:53:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 07:53:03 --> Model "Customer_model" initialized
INFO - 2021-07-05 07:53:03 --> Final output sent to browser
DEBUG - 2021-07-05 07:53:03 --> Total execution time: 0.0738
INFO - 2021-07-05 08:10:43 --> Config Class Initialized
INFO - 2021-07-05 08:10:43 --> Hooks Class Initialized
DEBUG - 2021-07-05 08:10:43 --> UTF-8 Support Enabled
INFO - 2021-07-05 08:10:43 --> Utf8 Class Initialized
INFO - 2021-07-05 08:10:43 --> URI Class Initialized
INFO - 2021-07-05 08:10:43 --> Router Class Initialized
INFO - 2021-07-05 08:10:43 --> Output Class Initialized
INFO - 2021-07-05 08:10:43 --> Security Class Initialized
DEBUG - 2021-07-05 08:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 08:10:43 --> Input Class Initialized
INFO - 2021-07-05 08:10:43 --> Language Class Initialized
INFO - 2021-07-05 08:10:43 --> Loader Class Initialized
INFO - 2021-07-05 08:10:43 --> Helper loaded: html_helper
INFO - 2021-07-05 08:10:43 --> Helper loaded: url_helper
INFO - 2021-07-05 08:10:43 --> Helper loaded: form_helper
INFO - 2021-07-05 08:10:43 --> Database Driver Class Initialized
INFO - 2021-07-05 08:10:43 --> Form Validation Class Initialized
DEBUG - 2021-07-05 08:10:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 08:10:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 08:10:43 --> Encryption Class Initialized
INFO - 2021-07-05 08:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 08:10:43 --> Model "vendor_model" initialized
INFO - 2021-07-05 08:10:43 --> Model "coupon_model" initialized
INFO - 2021-07-05 08:10:43 --> Model "user_model" initialized
INFO - 2021-07-05 08:10:43 --> Model "role_model" initialized
INFO - 2021-07-05 08:10:43 --> Controller Class Initialized
INFO - 2021-07-05 08:10:43 --> Helper loaded: language_helper
INFO - 2021-07-05 08:10:43 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 08:10:43 --> Model "Customer_model" initialized
INFO - 2021-07-05 08:10:43 --> Model "Product_model" initialized
INFO - 2021-07-05 08:10:43 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 08:10:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 08:10:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 08:10:43 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 08:10:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 08:10:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 08:10:43 --> Final output sent to browser
DEBUG - 2021-07-05 08:10:43 --> Total execution time: 0.0872
INFO - 2021-07-05 08:29:10 --> Config Class Initialized
INFO - 2021-07-05 08:29:10 --> Hooks Class Initialized
DEBUG - 2021-07-05 08:29:10 --> UTF-8 Support Enabled
INFO - 2021-07-05 08:29:10 --> Utf8 Class Initialized
INFO - 2021-07-05 08:29:10 --> URI Class Initialized
DEBUG - 2021-07-05 08:29:10 --> No URI present. Default controller set.
INFO - 2021-07-05 08:29:10 --> Router Class Initialized
INFO - 2021-07-05 08:29:10 --> Output Class Initialized
INFO - 2021-07-05 08:29:10 --> Security Class Initialized
DEBUG - 2021-07-05 08:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 08:29:10 --> Input Class Initialized
INFO - 2021-07-05 08:29:10 --> Language Class Initialized
INFO - 2021-07-05 08:29:10 --> Loader Class Initialized
INFO - 2021-07-05 08:29:10 --> Helper loaded: html_helper
INFO - 2021-07-05 08:29:10 --> Helper loaded: url_helper
INFO - 2021-07-05 08:29:10 --> Helper loaded: form_helper
INFO - 2021-07-05 08:29:10 --> Database Driver Class Initialized
INFO - 2021-07-05 08:29:10 --> Form Validation Class Initialized
DEBUG - 2021-07-05 08:29:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 08:29:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 08:29:11 --> Encryption Class Initialized
INFO - 2021-07-05 08:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 08:29:11 --> Model "vendor_model" initialized
INFO - 2021-07-05 08:29:11 --> Model "coupon_model" initialized
INFO - 2021-07-05 08:29:11 --> Model "user_model" initialized
INFO - 2021-07-05 08:29:11 --> Model "role_model" initialized
INFO - 2021-07-05 08:29:11 --> Controller Class Initialized
INFO - 2021-07-05 08:29:11 --> Helper loaded: language_helper
INFO - 2021-07-05 08:29:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 08:29:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 08:29:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 08:29:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 08:29:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 08:29:11 --> Final output sent to browser
DEBUG - 2021-07-05 08:29:11 --> Total execution time: 0.0836
INFO - 2021-07-05 08:29:45 --> Config Class Initialized
INFO - 2021-07-05 08:29:45 --> Hooks Class Initialized
DEBUG - 2021-07-05 08:29:45 --> UTF-8 Support Enabled
INFO - 2021-07-05 08:29:45 --> Utf8 Class Initialized
INFO - 2021-07-05 08:29:45 --> URI Class Initialized
DEBUG - 2021-07-05 08:29:45 --> No URI present. Default controller set.
INFO - 2021-07-05 08:29:45 --> Router Class Initialized
INFO - 2021-07-05 08:29:45 --> Output Class Initialized
INFO - 2021-07-05 08:29:45 --> Security Class Initialized
DEBUG - 2021-07-05 08:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 08:29:45 --> Input Class Initialized
INFO - 2021-07-05 08:29:45 --> Language Class Initialized
INFO - 2021-07-05 08:29:45 --> Loader Class Initialized
INFO - 2021-07-05 08:29:45 --> Helper loaded: html_helper
INFO - 2021-07-05 08:29:45 --> Helper loaded: url_helper
INFO - 2021-07-05 08:29:45 --> Helper loaded: form_helper
INFO - 2021-07-05 08:29:45 --> Database Driver Class Initialized
INFO - 2021-07-05 08:29:45 --> Form Validation Class Initialized
DEBUG - 2021-07-05 08:29:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 08:29:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 08:29:45 --> Encryption Class Initialized
INFO - 2021-07-05 08:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 08:29:45 --> Model "vendor_model" initialized
INFO - 2021-07-05 08:29:45 --> Model "coupon_model" initialized
INFO - 2021-07-05 08:29:45 --> Model "user_model" initialized
INFO - 2021-07-05 08:29:45 --> Model "role_model" initialized
INFO - 2021-07-05 08:29:45 --> Controller Class Initialized
INFO - 2021-07-05 08:29:45 --> Helper loaded: language_helper
INFO - 2021-07-05 08:29:45 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 08:29:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 08:29:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 08:29:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 08:29:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 08:29:45 --> Final output sent to browser
DEBUG - 2021-07-05 08:29:45 --> Total execution time: 0.0958
INFO - 2021-07-05 08:29:46 --> Config Class Initialized
INFO - 2021-07-05 08:29:46 --> Hooks Class Initialized
DEBUG - 2021-07-05 08:29:46 --> UTF-8 Support Enabled
INFO - 2021-07-05 08:29:46 --> Utf8 Class Initialized
INFO - 2021-07-05 08:29:46 --> URI Class Initialized
DEBUG - 2021-07-05 08:29:46 --> No URI present. Default controller set.
INFO - 2021-07-05 08:29:46 --> Router Class Initialized
INFO - 2021-07-05 08:29:46 --> Output Class Initialized
INFO - 2021-07-05 08:29:46 --> Security Class Initialized
DEBUG - 2021-07-05 08:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 08:29:46 --> Input Class Initialized
INFO - 2021-07-05 08:29:46 --> Language Class Initialized
INFO - 2021-07-05 08:29:46 --> Loader Class Initialized
INFO - 2021-07-05 08:29:46 --> Helper loaded: html_helper
INFO - 2021-07-05 08:29:46 --> Helper loaded: url_helper
INFO - 2021-07-05 08:29:46 --> Helper loaded: form_helper
INFO - 2021-07-05 08:29:46 --> Database Driver Class Initialized
INFO - 2021-07-05 08:29:46 --> Form Validation Class Initialized
DEBUG - 2021-07-05 08:29:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 08:29:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 08:29:46 --> Encryption Class Initialized
INFO - 2021-07-05 08:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 08:29:46 --> Model "vendor_model" initialized
INFO - 2021-07-05 08:29:46 --> Model "coupon_model" initialized
INFO - 2021-07-05 08:29:46 --> Model "user_model" initialized
INFO - 2021-07-05 08:29:46 --> Model "role_model" initialized
INFO - 2021-07-05 08:29:46 --> Controller Class Initialized
INFO - 2021-07-05 08:29:46 --> Helper loaded: language_helper
INFO - 2021-07-05 08:29:46 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 08:29:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 08:29:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 08:29:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 08:29:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 08:29:46 --> Final output sent to browser
DEBUG - 2021-07-05 08:29:46 --> Total execution time: 0.0738
INFO - 2021-07-05 08:29:50 --> Config Class Initialized
INFO - 2021-07-05 08:29:50 --> Hooks Class Initialized
DEBUG - 2021-07-05 08:29:50 --> UTF-8 Support Enabled
INFO - 2021-07-05 08:29:50 --> Utf8 Class Initialized
INFO - 2021-07-05 08:29:50 --> URI Class Initialized
INFO - 2021-07-05 08:29:50 --> Router Class Initialized
INFO - 2021-07-05 08:29:50 --> Output Class Initialized
INFO - 2021-07-05 08:29:50 --> Security Class Initialized
DEBUG - 2021-07-05 08:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 08:29:50 --> Input Class Initialized
INFO - 2021-07-05 08:29:50 --> Language Class Initialized
INFO - 2021-07-05 08:29:50 --> Loader Class Initialized
INFO - 2021-07-05 08:29:50 --> Helper loaded: html_helper
INFO - 2021-07-05 08:29:50 --> Helper loaded: url_helper
INFO - 2021-07-05 08:29:50 --> Helper loaded: form_helper
INFO - 2021-07-05 08:29:50 --> Database Driver Class Initialized
INFO - 2021-07-05 08:29:50 --> Form Validation Class Initialized
DEBUG - 2021-07-05 08:29:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 08:29:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 08:29:50 --> Encryption Class Initialized
INFO - 2021-07-05 08:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 08:29:50 --> Model "vendor_model" initialized
INFO - 2021-07-05 08:29:50 --> Model "coupon_model" initialized
INFO - 2021-07-05 08:29:50 --> Model "user_model" initialized
INFO - 2021-07-05 08:29:50 --> Model "role_model" initialized
INFO - 2021-07-05 08:29:50 --> Controller Class Initialized
INFO - 2021-07-05 08:29:50 --> Helper loaded: language_helper
INFO - 2021-07-05 08:29:50 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 08:29:50 --> Model "Customer_model" initialized
INFO - 2021-07-05 08:29:50 --> Model "Product_model" initialized
INFO - 2021-07-05 08:29:50 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 08:29:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 08:29:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 08:29:50 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 08:29:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 08:29:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 08:29:50 --> Final output sent to browser
DEBUG - 2021-07-05 08:29:50 --> Total execution time: 0.0768
INFO - 2021-07-05 08:30:00 --> Config Class Initialized
INFO - 2021-07-05 08:30:00 --> Hooks Class Initialized
DEBUG - 2021-07-05 08:30:00 --> UTF-8 Support Enabled
INFO - 2021-07-05 08:30:00 --> Utf8 Class Initialized
INFO - 2021-07-05 08:30:00 --> URI Class Initialized
INFO - 2021-07-05 08:30:00 --> Router Class Initialized
INFO - 2021-07-05 08:30:00 --> Output Class Initialized
INFO - 2021-07-05 08:30:00 --> Security Class Initialized
DEBUG - 2021-07-05 08:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 08:30:00 --> Input Class Initialized
INFO - 2021-07-05 08:30:00 --> Language Class Initialized
INFO - 2021-07-05 08:30:00 --> Loader Class Initialized
INFO - 2021-07-05 08:30:00 --> Helper loaded: html_helper
INFO - 2021-07-05 08:30:00 --> Helper loaded: url_helper
INFO - 2021-07-05 08:30:00 --> Helper loaded: form_helper
INFO - 2021-07-05 08:30:00 --> Database Driver Class Initialized
INFO - 2021-07-05 08:30:00 --> Form Validation Class Initialized
DEBUG - 2021-07-05 08:30:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 08:30:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 08:30:00 --> Encryption Class Initialized
INFO - 2021-07-05 08:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 08:30:00 --> Model "vendor_model" initialized
INFO - 2021-07-05 08:30:00 --> Model "coupon_model" initialized
INFO - 2021-07-05 08:30:00 --> Model "user_model" initialized
INFO - 2021-07-05 08:30:00 --> Model "role_model" initialized
INFO - 2021-07-05 08:30:00 --> Controller Class Initialized
INFO - 2021-07-05 08:30:00 --> Helper loaded: language_helper
INFO - 2021-07-05 08:30:00 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 08:30:00 --> Model "Customer_model" initialized
INFO - 2021-07-05 08:30:00 --> Model "Product_model" initialized
INFO - 2021-07-05 08:30:00 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 08:30:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 08:30:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 08:30:00 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 08:30:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 08:30:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 08:30:00 --> Final output sent to browser
DEBUG - 2021-07-05 08:30:00 --> Total execution time: 0.0719
INFO - 2021-07-05 08:30:42 --> Config Class Initialized
INFO - 2021-07-05 08:30:42 --> Hooks Class Initialized
DEBUG - 2021-07-05 08:30:42 --> UTF-8 Support Enabled
INFO - 2021-07-05 08:30:42 --> Utf8 Class Initialized
INFO - 2021-07-05 08:30:42 --> URI Class Initialized
INFO - 2021-07-05 08:30:42 --> Router Class Initialized
INFO - 2021-07-05 08:30:42 --> Output Class Initialized
INFO - 2021-07-05 08:30:42 --> Security Class Initialized
DEBUG - 2021-07-05 08:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 08:30:42 --> Input Class Initialized
INFO - 2021-07-05 08:30:42 --> Language Class Initialized
INFO - 2021-07-05 08:30:42 --> Loader Class Initialized
INFO - 2021-07-05 08:30:42 --> Helper loaded: html_helper
INFO - 2021-07-05 08:30:42 --> Helper loaded: url_helper
INFO - 2021-07-05 08:30:42 --> Helper loaded: form_helper
INFO - 2021-07-05 08:30:42 --> Database Driver Class Initialized
INFO - 2021-07-05 08:30:42 --> Form Validation Class Initialized
DEBUG - 2021-07-05 08:30:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 08:30:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 08:30:42 --> Encryption Class Initialized
INFO - 2021-07-05 08:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 08:30:42 --> Model "vendor_model" initialized
INFO - 2021-07-05 08:30:42 --> Model "coupon_model" initialized
INFO - 2021-07-05 08:30:42 --> Model "user_model" initialized
INFO - 2021-07-05 08:30:42 --> Model "role_model" initialized
INFO - 2021-07-05 08:30:42 --> Controller Class Initialized
INFO - 2021-07-05 08:30:42 --> Helper loaded: language_helper
INFO - 2021-07-05 08:30:42 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 08:30:42 --> Model "Customer_model" initialized
INFO - 2021-07-05 08:30:42 --> Model "Product_model" initialized
INFO - 2021-07-05 08:30:42 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 08:30:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 08:30:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 08:30:42 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 08:30:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 08:30:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 08:30:42 --> Final output sent to browser
DEBUG - 2021-07-05 08:30:42 --> Total execution time: 0.0799
INFO - 2021-07-05 08:33:26 --> Config Class Initialized
INFO - 2021-07-05 08:33:26 --> Hooks Class Initialized
DEBUG - 2021-07-05 08:33:26 --> UTF-8 Support Enabled
INFO - 2021-07-05 08:33:26 --> Utf8 Class Initialized
INFO - 2021-07-05 08:33:26 --> URI Class Initialized
INFO - 2021-07-05 08:33:26 --> Router Class Initialized
INFO - 2021-07-05 08:33:26 --> Output Class Initialized
INFO - 2021-07-05 08:33:26 --> Security Class Initialized
DEBUG - 2021-07-05 08:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 08:33:26 --> Input Class Initialized
INFO - 2021-07-05 08:33:26 --> Language Class Initialized
INFO - 2021-07-05 08:33:26 --> Loader Class Initialized
INFO - 2021-07-05 08:33:26 --> Helper loaded: html_helper
INFO - 2021-07-05 08:33:26 --> Helper loaded: url_helper
INFO - 2021-07-05 08:33:26 --> Helper loaded: form_helper
INFO - 2021-07-05 08:33:26 --> Database Driver Class Initialized
INFO - 2021-07-05 08:33:26 --> Form Validation Class Initialized
DEBUG - 2021-07-05 08:33:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 08:33:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 08:33:26 --> Encryption Class Initialized
INFO - 2021-07-05 08:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 08:33:26 --> Model "vendor_model" initialized
INFO - 2021-07-05 08:33:26 --> Model "coupon_model" initialized
INFO - 2021-07-05 08:33:26 --> Model "user_model" initialized
INFO - 2021-07-05 08:33:26 --> Model "role_model" initialized
INFO - 2021-07-05 08:33:26 --> Controller Class Initialized
INFO - 2021-07-05 08:33:26 --> Helper loaded: language_helper
INFO - 2021-07-05 08:33:26 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 08:33:26 --> Model "Customer_model" initialized
INFO - 2021-07-05 08:33:26 --> Model "Product_model" initialized
INFO - 2021-07-05 08:33:26 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 08:33:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 08:33:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 08:33:26 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 08:33:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 08:33:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 08:33:26 --> Final output sent to browser
DEBUG - 2021-07-05 08:33:26 --> Total execution time: 0.1351
INFO - 2021-07-05 08:33:54 --> Config Class Initialized
INFO - 2021-07-05 08:33:54 --> Hooks Class Initialized
DEBUG - 2021-07-05 08:33:54 --> UTF-8 Support Enabled
INFO - 2021-07-05 08:33:54 --> Utf8 Class Initialized
INFO - 2021-07-05 08:33:54 --> URI Class Initialized
INFO - 2021-07-05 08:33:54 --> Router Class Initialized
INFO - 2021-07-05 08:33:54 --> Output Class Initialized
INFO - 2021-07-05 08:33:54 --> Security Class Initialized
DEBUG - 2021-07-05 08:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 08:33:54 --> Input Class Initialized
INFO - 2021-07-05 08:33:54 --> Language Class Initialized
INFO - 2021-07-05 08:33:54 --> Loader Class Initialized
INFO - 2021-07-05 08:33:54 --> Helper loaded: html_helper
INFO - 2021-07-05 08:33:54 --> Helper loaded: url_helper
INFO - 2021-07-05 08:33:54 --> Helper loaded: form_helper
INFO - 2021-07-05 08:33:54 --> Database Driver Class Initialized
INFO - 2021-07-05 08:33:54 --> Form Validation Class Initialized
DEBUG - 2021-07-05 08:33:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 08:33:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 08:33:54 --> Encryption Class Initialized
INFO - 2021-07-05 08:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 08:33:54 --> Model "vendor_model" initialized
INFO - 2021-07-05 08:33:54 --> Model "coupon_model" initialized
INFO - 2021-07-05 08:33:54 --> Model "user_model" initialized
INFO - 2021-07-05 08:33:54 --> Model "role_model" initialized
INFO - 2021-07-05 08:33:54 --> Controller Class Initialized
INFO - 2021-07-05 08:33:54 --> Helper loaded: language_helper
INFO - 2021-07-05 08:33:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 08:33:54 --> Model "Customer_model" initialized
INFO - 2021-07-05 08:33:54 --> Final output sent to browser
DEBUG - 2021-07-05 08:33:54 --> Total execution time: 0.0816
INFO - 2021-07-05 08:35:15 --> Config Class Initialized
INFO - 2021-07-05 08:35:15 --> Hooks Class Initialized
DEBUG - 2021-07-05 08:35:15 --> UTF-8 Support Enabled
INFO - 2021-07-05 08:35:15 --> Utf8 Class Initialized
INFO - 2021-07-05 08:35:15 --> URI Class Initialized
INFO - 2021-07-05 08:35:15 --> Router Class Initialized
INFO - 2021-07-05 08:35:15 --> Output Class Initialized
INFO - 2021-07-05 08:35:15 --> Security Class Initialized
DEBUG - 2021-07-05 08:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 08:35:15 --> Input Class Initialized
INFO - 2021-07-05 08:35:15 --> Language Class Initialized
INFO - 2021-07-05 08:35:15 --> Loader Class Initialized
INFO - 2021-07-05 08:35:15 --> Helper loaded: html_helper
INFO - 2021-07-05 08:35:15 --> Helper loaded: url_helper
INFO - 2021-07-05 08:35:15 --> Helper loaded: form_helper
INFO - 2021-07-05 08:35:15 --> Database Driver Class Initialized
INFO - 2021-07-05 08:35:15 --> Form Validation Class Initialized
DEBUG - 2021-07-05 08:35:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 08:35:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 08:35:15 --> Encryption Class Initialized
INFO - 2021-07-05 08:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 08:35:15 --> Model "vendor_model" initialized
INFO - 2021-07-05 08:35:15 --> Model "coupon_model" initialized
INFO - 2021-07-05 08:35:15 --> Model "user_model" initialized
INFO - 2021-07-05 08:35:15 --> Model "role_model" initialized
INFO - 2021-07-05 08:35:15 --> Controller Class Initialized
INFO - 2021-07-05 08:35:15 --> Helper loaded: language_helper
INFO - 2021-07-05 08:35:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 08:35:15 --> Model "Customer_model" initialized
INFO - 2021-07-05 08:35:15 --> Model "Product_model" initialized
INFO - 2021-07-05 08:35:15 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 08:35:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 08:35:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 08:35:15 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 08:35:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 08:35:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 08:35:15 --> Final output sent to browser
DEBUG - 2021-07-05 08:35:15 --> Total execution time: 0.1274
INFO - 2021-07-05 08:36:02 --> Config Class Initialized
INFO - 2021-07-05 08:36:02 --> Hooks Class Initialized
DEBUG - 2021-07-05 08:36:02 --> UTF-8 Support Enabled
INFO - 2021-07-05 08:36:02 --> Utf8 Class Initialized
INFO - 2021-07-05 08:36:02 --> URI Class Initialized
INFO - 2021-07-05 08:36:02 --> Router Class Initialized
INFO - 2021-07-05 08:36:02 --> Output Class Initialized
INFO - 2021-07-05 08:36:02 --> Security Class Initialized
DEBUG - 2021-07-05 08:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 08:36:02 --> Input Class Initialized
INFO - 2021-07-05 08:36:02 --> Language Class Initialized
INFO - 2021-07-05 08:36:02 --> Loader Class Initialized
INFO - 2021-07-05 08:36:02 --> Helper loaded: html_helper
INFO - 2021-07-05 08:36:02 --> Helper loaded: url_helper
INFO - 2021-07-05 08:36:02 --> Helper loaded: form_helper
INFO - 2021-07-05 08:36:02 --> Database Driver Class Initialized
INFO - 2021-07-05 08:36:02 --> Form Validation Class Initialized
DEBUG - 2021-07-05 08:36:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 08:36:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 08:36:02 --> Encryption Class Initialized
INFO - 2021-07-05 08:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 08:36:02 --> Model "vendor_model" initialized
INFO - 2021-07-05 08:36:02 --> Model "coupon_model" initialized
INFO - 2021-07-05 08:36:02 --> Model "user_model" initialized
INFO - 2021-07-05 08:36:02 --> Model "role_model" initialized
INFO - 2021-07-05 08:36:02 --> Controller Class Initialized
INFO - 2021-07-05 08:36:02 --> Helper loaded: language_helper
INFO - 2021-07-05 08:36:02 --> Language file loaded: language/english/content_lang.php
ERROR - 2021-07-05 08:36:02 --> Severity: Notice --> Undefined index: customer_id D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 66
ERROR - 2021-07-05 08:36:02 --> Severity: Notice --> Undefined index: customer_name D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 67
ERROR - 2021-07-05 08:36:02 --> Severity: Notice --> Undefined index: address D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 68
ERROR - 2021-07-05 08:36:02 --> Severity: Notice --> Undefined index: city D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 69
ERROR - 2021-07-05 08:36:02 --> Severity: Notice --> Undefined index: state D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 70
ERROR - 2021-07-05 08:36:02 --> Severity: Notice --> Undefined index: country D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 71
ERROR - 2021-07-05 08:36:02 --> Severity: Notice --> Undefined index: gstin D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 72
ERROR - 2021-07-05 08:36:02 --> Severity: Notice --> Undefined index: pan D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 73
ERROR - 2021-07-05 08:36:02 --> Severity: Notice --> Undefined index: tan D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Customer_controller.php 74
INFO - 2021-07-05 08:36:02 --> Model "Customer_model" initialized
INFO - 2021-07-05 08:36:02 --> Final output sent to browser
DEBUG - 2021-07-05 08:36:02 --> Total execution time: 0.0897
INFO - 2021-07-05 08:37:20 --> Config Class Initialized
INFO - 2021-07-05 08:37:20 --> Hooks Class Initialized
DEBUG - 2021-07-05 08:37:20 --> UTF-8 Support Enabled
INFO - 2021-07-05 08:37:20 --> Utf8 Class Initialized
INFO - 2021-07-05 08:37:20 --> URI Class Initialized
INFO - 2021-07-05 08:37:20 --> Router Class Initialized
INFO - 2021-07-05 08:37:20 --> Output Class Initialized
INFO - 2021-07-05 08:37:20 --> Security Class Initialized
DEBUG - 2021-07-05 08:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 08:37:20 --> Input Class Initialized
INFO - 2021-07-05 08:37:20 --> Language Class Initialized
INFO - 2021-07-05 08:37:20 --> Loader Class Initialized
INFO - 2021-07-05 08:37:20 --> Helper loaded: html_helper
INFO - 2021-07-05 08:37:20 --> Helper loaded: url_helper
INFO - 2021-07-05 08:37:20 --> Helper loaded: form_helper
INFO - 2021-07-05 08:37:20 --> Database Driver Class Initialized
INFO - 2021-07-05 08:37:20 --> Form Validation Class Initialized
DEBUG - 2021-07-05 08:37:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 08:37:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 08:37:20 --> Encryption Class Initialized
INFO - 2021-07-05 08:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 08:37:20 --> Model "vendor_model" initialized
INFO - 2021-07-05 08:37:20 --> Model "coupon_model" initialized
INFO - 2021-07-05 08:37:20 --> Model "user_model" initialized
INFO - 2021-07-05 08:37:20 --> Model "role_model" initialized
INFO - 2021-07-05 08:37:20 --> Controller Class Initialized
INFO - 2021-07-05 08:37:20 --> Helper loaded: language_helper
INFO - 2021-07-05 08:37:20 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 08:37:20 --> Model "Customer_model" initialized
INFO - 2021-07-05 08:37:20 --> Model "Product_model" initialized
INFO - 2021-07-05 08:37:21 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 08:37:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 08:37:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 08:37:21 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 08:37:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 08:37:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 08:37:21 --> Final output sent to browser
DEBUG - 2021-07-05 08:37:21 --> Total execution time: 0.1321
INFO - 2021-07-05 08:37:51 --> Config Class Initialized
INFO - 2021-07-05 08:37:51 --> Hooks Class Initialized
DEBUG - 2021-07-05 08:37:51 --> UTF-8 Support Enabled
INFO - 2021-07-05 08:37:51 --> Utf8 Class Initialized
INFO - 2021-07-05 08:37:51 --> URI Class Initialized
INFO - 2021-07-05 08:37:51 --> Router Class Initialized
INFO - 2021-07-05 08:37:51 --> Output Class Initialized
INFO - 2021-07-05 08:37:51 --> Security Class Initialized
DEBUG - 2021-07-05 08:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 08:37:51 --> Input Class Initialized
INFO - 2021-07-05 08:37:51 --> Language Class Initialized
INFO - 2021-07-05 08:37:51 --> Loader Class Initialized
INFO - 2021-07-05 08:37:51 --> Helper loaded: html_helper
INFO - 2021-07-05 08:37:51 --> Helper loaded: url_helper
INFO - 2021-07-05 08:37:51 --> Helper loaded: form_helper
INFO - 2021-07-05 08:37:51 --> Database Driver Class Initialized
INFO - 2021-07-05 08:37:51 --> Form Validation Class Initialized
DEBUG - 2021-07-05 08:37:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 08:37:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 08:37:51 --> Encryption Class Initialized
INFO - 2021-07-05 08:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 08:37:51 --> Model "vendor_model" initialized
INFO - 2021-07-05 08:37:51 --> Model "coupon_model" initialized
INFO - 2021-07-05 08:37:51 --> Model "user_model" initialized
INFO - 2021-07-05 08:37:51 --> Model "role_model" initialized
INFO - 2021-07-05 08:37:51 --> Controller Class Initialized
INFO - 2021-07-05 08:37:51 --> Helper loaded: language_helper
INFO - 2021-07-05 08:37:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 08:37:51 --> Model "Customer_model" initialized
INFO - 2021-07-05 08:37:51 --> Final output sent to browser
DEBUG - 2021-07-05 08:37:51 --> Total execution time: 0.0816
INFO - 2021-07-05 08:39:49 --> Config Class Initialized
INFO - 2021-07-05 08:39:49 --> Hooks Class Initialized
DEBUG - 2021-07-05 08:39:49 --> UTF-8 Support Enabled
INFO - 2021-07-05 08:39:49 --> Utf8 Class Initialized
INFO - 2021-07-05 08:39:49 --> URI Class Initialized
INFO - 2021-07-05 08:39:49 --> Router Class Initialized
INFO - 2021-07-05 08:39:49 --> Output Class Initialized
INFO - 2021-07-05 08:39:49 --> Security Class Initialized
DEBUG - 2021-07-05 08:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 08:39:49 --> Input Class Initialized
INFO - 2021-07-05 08:39:49 --> Language Class Initialized
INFO - 2021-07-05 08:39:49 --> Loader Class Initialized
INFO - 2021-07-05 08:39:49 --> Helper loaded: html_helper
INFO - 2021-07-05 08:39:49 --> Helper loaded: url_helper
INFO - 2021-07-05 08:39:49 --> Helper loaded: form_helper
INFO - 2021-07-05 08:39:49 --> Database Driver Class Initialized
INFO - 2021-07-05 08:39:49 --> Form Validation Class Initialized
DEBUG - 2021-07-05 08:39:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 08:39:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 08:39:49 --> Encryption Class Initialized
INFO - 2021-07-05 08:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 08:39:49 --> Model "vendor_model" initialized
INFO - 2021-07-05 08:39:49 --> Model "coupon_model" initialized
INFO - 2021-07-05 08:39:49 --> Model "user_model" initialized
INFO - 2021-07-05 08:39:49 --> Model "role_model" initialized
INFO - 2021-07-05 08:39:49 --> Controller Class Initialized
INFO - 2021-07-05 08:39:49 --> Helper loaded: language_helper
INFO - 2021-07-05 08:39:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 08:39:49 --> Model "Customer_model" initialized
INFO - 2021-07-05 08:39:49 --> Model "Product_model" initialized
INFO - 2021-07-05 08:39:49 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 08:39:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 08:39:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 08:39:49 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 08:39:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 08:39:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 08:39:49 --> Final output sent to browser
DEBUG - 2021-07-05 08:39:49 --> Total execution time: 0.1157
INFO - 2021-07-05 08:40:18 --> Config Class Initialized
INFO - 2021-07-05 08:40:18 --> Hooks Class Initialized
DEBUG - 2021-07-05 08:40:18 --> UTF-8 Support Enabled
INFO - 2021-07-05 08:40:18 --> Utf8 Class Initialized
INFO - 2021-07-05 08:40:18 --> URI Class Initialized
INFO - 2021-07-05 08:40:18 --> Router Class Initialized
INFO - 2021-07-05 08:40:18 --> Output Class Initialized
INFO - 2021-07-05 08:40:18 --> Security Class Initialized
DEBUG - 2021-07-05 08:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 08:40:18 --> Input Class Initialized
INFO - 2021-07-05 08:40:18 --> Language Class Initialized
INFO - 2021-07-05 08:40:18 --> Loader Class Initialized
INFO - 2021-07-05 08:40:18 --> Helper loaded: html_helper
INFO - 2021-07-05 08:40:18 --> Helper loaded: url_helper
INFO - 2021-07-05 08:40:18 --> Helper loaded: form_helper
INFO - 2021-07-05 08:40:18 --> Database Driver Class Initialized
INFO - 2021-07-05 08:40:18 --> Form Validation Class Initialized
DEBUG - 2021-07-05 08:40:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 08:40:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 08:40:18 --> Encryption Class Initialized
INFO - 2021-07-05 08:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 08:40:18 --> Model "vendor_model" initialized
INFO - 2021-07-05 08:40:18 --> Model "coupon_model" initialized
INFO - 2021-07-05 08:40:18 --> Model "user_model" initialized
INFO - 2021-07-05 08:40:18 --> Model "role_model" initialized
INFO - 2021-07-05 08:40:18 --> Controller Class Initialized
INFO - 2021-07-05 08:40:18 --> Helper loaded: language_helper
INFO - 2021-07-05 08:40:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 08:40:18 --> Model "Customer_model" initialized
INFO - 2021-07-05 08:40:18 --> Final output sent to browser
DEBUG - 2021-07-05 08:40:18 --> Total execution time: 0.0771
INFO - 2021-07-05 08:40:24 --> Config Class Initialized
INFO - 2021-07-05 08:40:24 --> Hooks Class Initialized
DEBUG - 2021-07-05 08:40:24 --> UTF-8 Support Enabled
INFO - 2021-07-05 08:40:24 --> Utf8 Class Initialized
INFO - 2021-07-05 08:40:24 --> URI Class Initialized
INFO - 2021-07-05 08:40:24 --> Router Class Initialized
INFO - 2021-07-05 08:40:24 --> Output Class Initialized
INFO - 2021-07-05 08:40:24 --> Security Class Initialized
DEBUG - 2021-07-05 08:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 08:40:24 --> Input Class Initialized
INFO - 2021-07-05 08:40:24 --> Language Class Initialized
INFO - 2021-07-05 08:40:24 --> Loader Class Initialized
INFO - 2021-07-05 08:40:24 --> Helper loaded: html_helper
INFO - 2021-07-05 08:40:24 --> Helper loaded: url_helper
INFO - 2021-07-05 08:40:24 --> Helper loaded: form_helper
INFO - 2021-07-05 08:40:24 --> Database Driver Class Initialized
INFO - 2021-07-05 08:40:24 --> Form Validation Class Initialized
DEBUG - 2021-07-05 08:40:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 08:40:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 08:40:24 --> Encryption Class Initialized
INFO - 2021-07-05 08:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 08:40:24 --> Model "vendor_model" initialized
INFO - 2021-07-05 08:40:24 --> Model "coupon_model" initialized
INFO - 2021-07-05 08:40:24 --> Model "user_model" initialized
INFO - 2021-07-05 08:40:24 --> Model "role_model" initialized
INFO - 2021-07-05 08:40:24 --> Controller Class Initialized
INFO - 2021-07-05 08:40:24 --> Helper loaded: language_helper
INFO - 2021-07-05 08:40:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 08:40:24 --> Model "Customer_model" initialized
INFO - 2021-07-05 08:40:24 --> Final output sent to browser
DEBUG - 2021-07-05 08:40:24 --> Total execution time: 0.0700
INFO - 2021-07-05 08:40:26 --> Config Class Initialized
INFO - 2021-07-05 08:40:26 --> Hooks Class Initialized
DEBUG - 2021-07-05 08:40:26 --> UTF-8 Support Enabled
INFO - 2021-07-05 08:40:26 --> Utf8 Class Initialized
INFO - 2021-07-05 08:40:26 --> URI Class Initialized
INFO - 2021-07-05 08:40:26 --> Router Class Initialized
INFO - 2021-07-05 08:40:26 --> Output Class Initialized
INFO - 2021-07-05 08:40:26 --> Security Class Initialized
DEBUG - 2021-07-05 08:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 08:40:26 --> Input Class Initialized
INFO - 2021-07-05 08:40:26 --> Language Class Initialized
INFO - 2021-07-05 08:40:26 --> Loader Class Initialized
INFO - 2021-07-05 08:40:26 --> Helper loaded: html_helper
INFO - 2021-07-05 08:40:26 --> Helper loaded: url_helper
INFO - 2021-07-05 08:40:26 --> Helper loaded: form_helper
INFO - 2021-07-05 08:40:26 --> Database Driver Class Initialized
INFO - 2021-07-05 08:40:26 --> Form Validation Class Initialized
DEBUG - 2021-07-05 08:40:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 08:40:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 08:40:26 --> Encryption Class Initialized
INFO - 2021-07-05 08:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 08:40:26 --> Model "vendor_model" initialized
INFO - 2021-07-05 08:40:26 --> Model "coupon_model" initialized
INFO - 2021-07-05 08:40:26 --> Model "user_model" initialized
INFO - 2021-07-05 08:40:26 --> Model "role_model" initialized
INFO - 2021-07-05 08:40:26 --> Controller Class Initialized
INFO - 2021-07-05 08:40:26 --> Helper loaded: language_helper
INFO - 2021-07-05 08:40:26 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 08:40:26 --> Model "Customer_model" initialized
INFO - 2021-07-05 08:40:26 --> Model "Product_model" initialized
INFO - 2021-07-05 08:40:26 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 08:40:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 08:40:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 08:40:26 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 08:40:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 08:40:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 08:40:26 --> Final output sent to browser
DEBUG - 2021-07-05 08:40:26 --> Total execution time: 0.0754
INFO - 2021-07-05 08:54:20 --> Config Class Initialized
INFO - 2021-07-05 08:54:20 --> Hooks Class Initialized
DEBUG - 2021-07-05 08:54:20 --> UTF-8 Support Enabled
INFO - 2021-07-05 08:54:20 --> Utf8 Class Initialized
INFO - 2021-07-05 08:54:20 --> URI Class Initialized
INFO - 2021-07-05 08:54:20 --> Router Class Initialized
INFO - 2021-07-05 08:54:20 --> Output Class Initialized
INFO - 2021-07-05 08:54:20 --> Security Class Initialized
DEBUG - 2021-07-05 08:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 08:54:20 --> Input Class Initialized
INFO - 2021-07-05 08:54:20 --> Language Class Initialized
INFO - 2021-07-05 08:54:20 --> Loader Class Initialized
INFO - 2021-07-05 08:54:20 --> Helper loaded: html_helper
INFO - 2021-07-05 08:54:20 --> Helper loaded: url_helper
INFO - 2021-07-05 08:54:20 --> Helper loaded: form_helper
INFO - 2021-07-05 08:54:20 --> Database Driver Class Initialized
INFO - 2021-07-05 08:54:20 --> Form Validation Class Initialized
DEBUG - 2021-07-05 08:54:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 08:54:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 08:54:20 --> Encryption Class Initialized
INFO - 2021-07-05 08:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 08:54:20 --> Model "vendor_model" initialized
INFO - 2021-07-05 08:54:20 --> Model "coupon_model" initialized
INFO - 2021-07-05 08:54:20 --> Model "user_model" initialized
INFO - 2021-07-05 08:54:20 --> Model "role_model" initialized
INFO - 2021-07-05 08:54:20 --> Controller Class Initialized
INFO - 2021-07-05 08:54:20 --> Helper loaded: language_helper
INFO - 2021-07-05 08:54:20 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 08:54:20 --> Model "Customer_model" initialized
INFO - 2021-07-05 08:54:20 --> Model "Product_model" initialized
INFO - 2021-07-05 08:54:20 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 08:54:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 08:54:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 08:54:20 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 08:54:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 08:54:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 08:54:20 --> Final output sent to browser
DEBUG - 2021-07-05 08:54:20 --> Total execution time: 0.1478
INFO - 2021-07-05 08:54:35 --> Config Class Initialized
INFO - 2021-07-05 08:54:35 --> Hooks Class Initialized
DEBUG - 2021-07-05 08:54:35 --> UTF-8 Support Enabled
INFO - 2021-07-05 08:54:35 --> Utf8 Class Initialized
INFO - 2021-07-05 08:54:35 --> URI Class Initialized
INFO - 2021-07-05 08:54:35 --> Router Class Initialized
INFO - 2021-07-05 08:54:35 --> Output Class Initialized
INFO - 2021-07-05 08:54:35 --> Security Class Initialized
DEBUG - 2021-07-05 08:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 08:54:35 --> Input Class Initialized
INFO - 2021-07-05 08:54:35 --> Language Class Initialized
INFO - 2021-07-05 08:54:35 --> Loader Class Initialized
INFO - 2021-07-05 08:54:35 --> Helper loaded: html_helper
INFO - 2021-07-05 08:54:35 --> Helper loaded: url_helper
INFO - 2021-07-05 08:54:35 --> Helper loaded: form_helper
INFO - 2021-07-05 08:54:35 --> Database Driver Class Initialized
INFO - 2021-07-05 08:54:35 --> Form Validation Class Initialized
DEBUG - 2021-07-05 08:54:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 08:54:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 08:54:35 --> Encryption Class Initialized
INFO - 2021-07-05 08:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 08:54:35 --> Model "vendor_model" initialized
INFO - 2021-07-05 08:54:35 --> Model "coupon_model" initialized
INFO - 2021-07-05 08:54:35 --> Model "user_model" initialized
INFO - 2021-07-05 08:54:35 --> Model "role_model" initialized
INFO - 2021-07-05 08:54:35 --> Controller Class Initialized
INFO - 2021-07-05 08:54:35 --> Helper loaded: language_helper
INFO - 2021-07-05 08:54:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 08:54:35 --> Model "Customer_model" initialized
INFO - 2021-07-05 08:54:35 --> Model "Product_model" initialized
INFO - 2021-07-05 08:54:35 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 08:54:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 08:54:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 08:54:35 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 08:54:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 08:54:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 08:54:35 --> Final output sent to browser
DEBUG - 2021-07-05 08:54:35 --> Total execution time: 0.0705
INFO - 2021-07-05 08:55:26 --> Config Class Initialized
INFO - 2021-07-05 08:55:26 --> Hooks Class Initialized
DEBUG - 2021-07-05 08:55:26 --> UTF-8 Support Enabled
INFO - 2021-07-05 08:55:26 --> Utf8 Class Initialized
INFO - 2021-07-05 08:55:26 --> URI Class Initialized
INFO - 2021-07-05 08:55:26 --> Router Class Initialized
INFO - 2021-07-05 08:55:26 --> Output Class Initialized
INFO - 2021-07-05 08:55:26 --> Security Class Initialized
DEBUG - 2021-07-05 08:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 08:55:26 --> Input Class Initialized
INFO - 2021-07-05 08:55:26 --> Language Class Initialized
INFO - 2021-07-05 08:55:26 --> Loader Class Initialized
INFO - 2021-07-05 08:55:26 --> Helper loaded: html_helper
INFO - 2021-07-05 08:55:26 --> Helper loaded: url_helper
INFO - 2021-07-05 08:55:26 --> Helper loaded: form_helper
INFO - 2021-07-05 08:55:26 --> Database Driver Class Initialized
INFO - 2021-07-05 08:55:26 --> Form Validation Class Initialized
DEBUG - 2021-07-05 08:55:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 08:55:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 08:55:26 --> Encryption Class Initialized
INFO - 2021-07-05 08:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 08:55:26 --> Model "vendor_model" initialized
INFO - 2021-07-05 08:55:26 --> Model "coupon_model" initialized
INFO - 2021-07-05 08:55:26 --> Model "user_model" initialized
INFO - 2021-07-05 08:55:26 --> Model "role_model" initialized
INFO - 2021-07-05 08:55:26 --> Controller Class Initialized
INFO - 2021-07-05 08:55:26 --> Helper loaded: language_helper
INFO - 2021-07-05 08:55:26 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 08:55:26 --> Model "Customer_model" initialized
INFO - 2021-07-05 08:55:26 --> Final output sent to browser
DEBUG - 2021-07-05 08:55:26 --> Total execution time: 0.1054
INFO - 2021-07-05 08:55:47 --> Config Class Initialized
INFO - 2021-07-05 08:55:47 --> Hooks Class Initialized
DEBUG - 2021-07-05 08:55:47 --> UTF-8 Support Enabled
INFO - 2021-07-05 08:55:47 --> Utf8 Class Initialized
INFO - 2021-07-05 08:55:47 --> URI Class Initialized
INFO - 2021-07-05 08:55:47 --> Router Class Initialized
INFO - 2021-07-05 08:55:47 --> Output Class Initialized
INFO - 2021-07-05 08:55:47 --> Security Class Initialized
DEBUG - 2021-07-05 08:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 08:55:47 --> Input Class Initialized
INFO - 2021-07-05 08:55:47 --> Language Class Initialized
INFO - 2021-07-05 08:55:47 --> Loader Class Initialized
INFO - 2021-07-05 08:55:47 --> Helper loaded: html_helper
INFO - 2021-07-05 08:55:47 --> Helper loaded: url_helper
INFO - 2021-07-05 08:55:47 --> Helper loaded: form_helper
INFO - 2021-07-05 08:55:47 --> Database Driver Class Initialized
INFO - 2021-07-05 08:55:47 --> Form Validation Class Initialized
DEBUG - 2021-07-05 08:55:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 08:55:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 08:55:47 --> Encryption Class Initialized
INFO - 2021-07-05 08:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 08:55:47 --> Model "vendor_model" initialized
INFO - 2021-07-05 08:55:47 --> Model "coupon_model" initialized
INFO - 2021-07-05 08:55:47 --> Model "user_model" initialized
INFO - 2021-07-05 08:55:47 --> Model "role_model" initialized
INFO - 2021-07-05 08:55:47 --> Controller Class Initialized
INFO - 2021-07-05 08:55:47 --> Helper loaded: language_helper
INFO - 2021-07-05 08:55:47 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 08:55:47 --> Model "Customer_model" initialized
INFO - 2021-07-05 08:55:47 --> Final output sent to browser
DEBUG - 2021-07-05 08:55:47 --> Total execution time: 0.0717
INFO - 2021-07-05 08:56:30 --> Config Class Initialized
INFO - 2021-07-05 08:56:30 --> Hooks Class Initialized
DEBUG - 2021-07-05 08:56:30 --> UTF-8 Support Enabled
INFO - 2021-07-05 08:56:30 --> Utf8 Class Initialized
INFO - 2021-07-05 08:56:30 --> URI Class Initialized
INFO - 2021-07-05 08:56:30 --> Router Class Initialized
INFO - 2021-07-05 08:56:30 --> Output Class Initialized
INFO - 2021-07-05 08:56:30 --> Security Class Initialized
DEBUG - 2021-07-05 08:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 08:56:30 --> Input Class Initialized
INFO - 2021-07-05 08:56:30 --> Language Class Initialized
INFO - 2021-07-05 08:56:30 --> Loader Class Initialized
INFO - 2021-07-05 08:56:30 --> Helper loaded: html_helper
INFO - 2021-07-05 08:56:30 --> Helper loaded: url_helper
INFO - 2021-07-05 08:56:30 --> Helper loaded: form_helper
INFO - 2021-07-05 08:56:30 --> Database Driver Class Initialized
INFO - 2021-07-05 08:56:30 --> Form Validation Class Initialized
DEBUG - 2021-07-05 08:56:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 08:56:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 08:56:30 --> Encryption Class Initialized
INFO - 2021-07-05 08:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 08:56:30 --> Model "vendor_model" initialized
INFO - 2021-07-05 08:56:30 --> Model "coupon_model" initialized
INFO - 2021-07-05 08:56:30 --> Model "user_model" initialized
INFO - 2021-07-05 08:56:30 --> Model "role_model" initialized
INFO - 2021-07-05 08:56:30 --> Controller Class Initialized
INFO - 2021-07-05 08:56:30 --> Helper loaded: language_helper
INFO - 2021-07-05 08:56:30 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 08:56:30 --> Model "Product_model" initialized
ERROR - 2021-07-05 08:56:30 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server][SQL Server]Error converting data type varchar to float. - Invalid query: INSERT INTO "Product" ("product_id", "product_name", "product_desc", "rate", "edition") VALUES ('8f4a8de7-492d-4b83-af7c-1b494bf4a025', 'test', '', 'test', 'test')
INFO - 2021-07-05 08:56:30 --> Language file loaded: language/english/db_lang.php
INFO - 2021-07-05 08:56:58 --> Config Class Initialized
INFO - 2021-07-05 08:56:58 --> Hooks Class Initialized
DEBUG - 2021-07-05 08:56:58 --> UTF-8 Support Enabled
INFO - 2021-07-05 08:56:58 --> Utf8 Class Initialized
INFO - 2021-07-05 08:56:58 --> URI Class Initialized
INFO - 2021-07-05 08:56:58 --> Router Class Initialized
INFO - 2021-07-05 08:56:58 --> Output Class Initialized
INFO - 2021-07-05 08:56:58 --> Security Class Initialized
DEBUG - 2021-07-05 08:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 08:56:58 --> Input Class Initialized
INFO - 2021-07-05 08:56:58 --> Language Class Initialized
INFO - 2021-07-05 08:56:58 --> Loader Class Initialized
INFO - 2021-07-05 08:56:58 --> Helper loaded: html_helper
INFO - 2021-07-05 08:56:58 --> Helper loaded: url_helper
INFO - 2021-07-05 08:56:58 --> Helper loaded: form_helper
INFO - 2021-07-05 08:56:58 --> Database Driver Class Initialized
INFO - 2021-07-05 08:56:58 --> Form Validation Class Initialized
DEBUG - 2021-07-05 08:56:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 08:56:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 08:56:58 --> Encryption Class Initialized
INFO - 2021-07-05 08:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 08:56:58 --> Model "vendor_model" initialized
INFO - 2021-07-05 08:56:58 --> Model "coupon_model" initialized
INFO - 2021-07-05 08:56:58 --> Model "user_model" initialized
INFO - 2021-07-05 08:56:58 --> Model "role_model" initialized
INFO - 2021-07-05 08:56:58 --> Controller Class Initialized
INFO - 2021-07-05 08:56:58 --> Helper loaded: language_helper
INFO - 2021-07-05 08:56:58 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 08:56:58 --> Model "Customer_model" initialized
INFO - 2021-07-05 08:56:58 --> Model "Product_model" initialized
INFO - 2021-07-05 08:56:58 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 08:56:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 08:56:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 08:56:58 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 08:56:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 08:56:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 08:56:58 --> Final output sent to browser
DEBUG - 2021-07-05 08:56:58 --> Total execution time: 0.0748
INFO - 2021-07-05 08:57:39 --> Config Class Initialized
INFO - 2021-07-05 08:57:39 --> Hooks Class Initialized
DEBUG - 2021-07-05 08:57:39 --> UTF-8 Support Enabled
INFO - 2021-07-05 08:57:39 --> Utf8 Class Initialized
INFO - 2021-07-05 08:57:39 --> URI Class Initialized
INFO - 2021-07-05 08:57:39 --> Router Class Initialized
INFO - 2021-07-05 08:57:39 --> Output Class Initialized
INFO - 2021-07-05 08:57:39 --> Security Class Initialized
DEBUG - 2021-07-05 08:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 08:57:39 --> Input Class Initialized
INFO - 2021-07-05 08:57:39 --> Language Class Initialized
INFO - 2021-07-05 08:57:39 --> Loader Class Initialized
INFO - 2021-07-05 08:57:39 --> Helper loaded: html_helper
INFO - 2021-07-05 08:57:39 --> Helper loaded: url_helper
INFO - 2021-07-05 08:57:39 --> Helper loaded: form_helper
INFO - 2021-07-05 08:57:39 --> Database Driver Class Initialized
INFO - 2021-07-05 08:57:39 --> Form Validation Class Initialized
DEBUG - 2021-07-05 08:57:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 08:57:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 08:57:39 --> Encryption Class Initialized
INFO - 2021-07-05 08:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 08:57:39 --> Model "vendor_model" initialized
INFO - 2021-07-05 08:57:39 --> Model "coupon_model" initialized
INFO - 2021-07-05 08:57:39 --> Model "user_model" initialized
INFO - 2021-07-05 08:57:39 --> Model "role_model" initialized
INFO - 2021-07-05 08:57:39 --> Controller Class Initialized
INFO - 2021-07-05 08:57:39 --> Helper loaded: language_helper
INFO - 2021-07-05 08:57:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 08:57:39 --> Model "Product_model" initialized
ERROR - 2021-07-05 08:57:39 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server][SQL Server]Error converting data type varchar to float. - Invalid query: INSERT INTO "Product" ("product_id", "product_name", "product_desc", "rate", "edition") VALUES ('a38dafb8-2531-4bd6-9fee-5eaa737bb255', 'test', '', 'testing', '12000')
INFO - 2021-07-05 08:57:39 --> Language file loaded: language/english/db_lang.php
INFO - 2021-07-05 09:18:35 --> Config Class Initialized
INFO - 2021-07-05 09:18:35 --> Hooks Class Initialized
DEBUG - 2021-07-05 09:18:35 --> UTF-8 Support Enabled
INFO - 2021-07-05 09:18:35 --> Utf8 Class Initialized
INFO - 2021-07-05 09:18:35 --> URI Class Initialized
INFO - 2021-07-05 09:18:35 --> Router Class Initialized
INFO - 2021-07-05 09:18:35 --> Output Class Initialized
INFO - 2021-07-05 09:18:35 --> Security Class Initialized
DEBUG - 2021-07-05 09:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 09:18:35 --> Input Class Initialized
INFO - 2021-07-05 09:18:35 --> Language Class Initialized
INFO - 2021-07-05 09:18:35 --> Loader Class Initialized
INFO - 2021-07-05 09:18:35 --> Helper loaded: html_helper
INFO - 2021-07-05 09:18:35 --> Helper loaded: url_helper
INFO - 2021-07-05 09:18:35 --> Helper loaded: form_helper
INFO - 2021-07-05 09:18:35 --> Database Driver Class Initialized
INFO - 2021-07-05 09:18:35 --> Form Validation Class Initialized
DEBUG - 2021-07-05 09:18:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 09:18:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 09:18:35 --> Encryption Class Initialized
INFO - 2021-07-05 09:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 09:18:35 --> Model "vendor_model" initialized
INFO - 2021-07-05 09:18:35 --> Model "coupon_model" initialized
INFO - 2021-07-05 09:18:35 --> Model "user_model" initialized
INFO - 2021-07-05 09:18:35 --> Model "role_model" initialized
INFO - 2021-07-05 09:18:35 --> Controller Class Initialized
INFO - 2021-07-05 09:18:35 --> Helper loaded: language_helper
INFO - 2021-07-05 09:18:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 09:18:35 --> Model "Customer_model" initialized
INFO - 2021-07-05 09:18:35 --> Model "Product_model" initialized
INFO - 2021-07-05 09:18:35 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 09:18:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 09:18:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 09:18:35 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 09:18:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 09:18:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 09:18:35 --> Final output sent to browser
DEBUG - 2021-07-05 09:18:35 --> Total execution time: 0.1382
INFO - 2021-07-05 09:19:31 --> Config Class Initialized
INFO - 2021-07-05 09:19:31 --> Hooks Class Initialized
DEBUG - 2021-07-05 09:19:31 --> UTF-8 Support Enabled
INFO - 2021-07-05 09:19:31 --> Utf8 Class Initialized
INFO - 2021-07-05 09:19:31 --> URI Class Initialized
INFO - 2021-07-05 09:19:31 --> Router Class Initialized
INFO - 2021-07-05 09:19:31 --> Output Class Initialized
INFO - 2021-07-05 09:19:31 --> Security Class Initialized
DEBUG - 2021-07-05 09:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 09:19:31 --> Input Class Initialized
INFO - 2021-07-05 09:19:31 --> Language Class Initialized
INFO - 2021-07-05 09:19:31 --> Loader Class Initialized
INFO - 2021-07-05 09:19:31 --> Helper loaded: html_helper
INFO - 2021-07-05 09:19:31 --> Helper loaded: url_helper
INFO - 2021-07-05 09:19:31 --> Helper loaded: form_helper
INFO - 2021-07-05 09:19:31 --> Database Driver Class Initialized
INFO - 2021-07-05 09:19:31 --> Form Validation Class Initialized
DEBUG - 2021-07-05 09:19:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 09:19:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 09:19:31 --> Encryption Class Initialized
INFO - 2021-07-05 09:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 09:19:31 --> Model "vendor_model" initialized
INFO - 2021-07-05 09:19:31 --> Model "coupon_model" initialized
INFO - 2021-07-05 09:19:31 --> Model "user_model" initialized
INFO - 2021-07-05 09:19:31 --> Model "role_model" initialized
INFO - 2021-07-05 09:19:31 --> Controller Class Initialized
INFO - 2021-07-05 09:19:31 --> Helper loaded: language_helper
INFO - 2021-07-05 09:19:31 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 09:19:31 --> Model "Customer_model" initialized
INFO - 2021-07-05 09:19:31 --> Model "Product_model" initialized
INFO - 2021-07-05 09:19:31 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 09:19:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 09:19:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 09:19:31 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 09:19:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 09:19:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 09:19:31 --> Final output sent to browser
DEBUG - 2021-07-05 09:19:31 --> Total execution time: 0.1050
INFO - 2021-07-05 09:21:43 --> Config Class Initialized
INFO - 2021-07-05 09:21:43 --> Hooks Class Initialized
DEBUG - 2021-07-05 09:21:43 --> UTF-8 Support Enabled
INFO - 2021-07-05 09:21:43 --> Utf8 Class Initialized
INFO - 2021-07-05 09:21:43 --> URI Class Initialized
INFO - 2021-07-05 09:21:43 --> Router Class Initialized
INFO - 2021-07-05 09:21:43 --> Output Class Initialized
INFO - 2021-07-05 09:21:43 --> Security Class Initialized
DEBUG - 2021-07-05 09:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 09:21:43 --> Input Class Initialized
INFO - 2021-07-05 09:21:43 --> Language Class Initialized
INFO - 2021-07-05 09:21:43 --> Loader Class Initialized
INFO - 2021-07-05 09:21:43 --> Helper loaded: html_helper
INFO - 2021-07-05 09:21:43 --> Helper loaded: url_helper
INFO - 2021-07-05 09:21:43 --> Helper loaded: form_helper
INFO - 2021-07-05 09:21:43 --> Database Driver Class Initialized
INFO - 2021-07-05 09:21:43 --> Form Validation Class Initialized
DEBUG - 2021-07-05 09:21:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 09:21:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 09:21:43 --> Encryption Class Initialized
INFO - 2021-07-05 09:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 09:21:43 --> Model "vendor_model" initialized
INFO - 2021-07-05 09:21:43 --> Model "coupon_model" initialized
INFO - 2021-07-05 09:21:43 --> Model "user_model" initialized
INFO - 2021-07-05 09:21:43 --> Model "role_model" initialized
INFO - 2021-07-05 09:21:43 --> Controller Class Initialized
INFO - 2021-07-05 09:21:43 --> Helper loaded: language_helper
INFO - 2021-07-05 09:21:43 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 09:21:43 --> Model "Customer_model" initialized
INFO - 2021-07-05 09:21:43 --> Model "Product_model" initialized
INFO - 2021-07-05 09:21:43 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 09:21:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 09:21:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 09:21:43 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 09:21:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 09:21:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 09:21:43 --> Final output sent to browser
DEBUG - 2021-07-05 09:21:43 --> Total execution time: 0.1126
INFO - 2021-07-05 09:21:53 --> Config Class Initialized
INFO - 2021-07-05 09:21:53 --> Hooks Class Initialized
DEBUG - 2021-07-05 09:21:53 --> UTF-8 Support Enabled
INFO - 2021-07-05 09:21:53 --> Utf8 Class Initialized
INFO - 2021-07-05 09:21:53 --> URI Class Initialized
INFO - 2021-07-05 09:21:53 --> Router Class Initialized
INFO - 2021-07-05 09:21:53 --> Output Class Initialized
INFO - 2021-07-05 09:21:53 --> Security Class Initialized
DEBUG - 2021-07-05 09:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 09:21:53 --> Input Class Initialized
INFO - 2021-07-05 09:21:53 --> Language Class Initialized
INFO - 2021-07-05 09:21:53 --> Loader Class Initialized
INFO - 2021-07-05 09:21:53 --> Helper loaded: html_helper
INFO - 2021-07-05 09:21:53 --> Helper loaded: url_helper
INFO - 2021-07-05 09:21:53 --> Helper loaded: form_helper
INFO - 2021-07-05 09:21:53 --> Database Driver Class Initialized
INFO - 2021-07-05 09:21:53 --> Form Validation Class Initialized
DEBUG - 2021-07-05 09:21:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 09:21:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 09:21:53 --> Encryption Class Initialized
INFO - 2021-07-05 09:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 09:21:53 --> Model "vendor_model" initialized
INFO - 2021-07-05 09:21:53 --> Model "coupon_model" initialized
INFO - 2021-07-05 09:21:53 --> Model "user_model" initialized
INFO - 2021-07-05 09:21:53 --> Model "role_model" initialized
INFO - 2021-07-05 09:21:53 --> Controller Class Initialized
INFO - 2021-07-05 09:21:53 --> Helper loaded: language_helper
INFO - 2021-07-05 09:21:53 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 09:21:53 --> Model "Customer_model" initialized
INFO - 2021-07-05 09:21:53 --> Model "Product_model" initialized
INFO - 2021-07-05 09:21:53 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 09:21:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 09:21:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 09:21:53 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 09:21:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 09:21:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 09:21:53 --> Final output sent to browser
DEBUG - 2021-07-05 09:21:53 --> Total execution time: 0.0936
INFO - 2021-07-05 09:22:04 --> Config Class Initialized
INFO - 2021-07-05 09:22:04 --> Hooks Class Initialized
DEBUG - 2021-07-05 09:22:04 --> UTF-8 Support Enabled
INFO - 2021-07-05 09:22:04 --> Utf8 Class Initialized
INFO - 2021-07-05 09:22:04 --> URI Class Initialized
DEBUG - 2021-07-05 09:22:04 --> No URI present. Default controller set.
INFO - 2021-07-05 09:22:04 --> Router Class Initialized
INFO - 2021-07-05 09:22:04 --> Output Class Initialized
INFO - 2021-07-05 09:22:04 --> Security Class Initialized
DEBUG - 2021-07-05 09:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 09:22:04 --> Input Class Initialized
INFO - 2021-07-05 09:22:04 --> Language Class Initialized
INFO - 2021-07-05 09:22:04 --> Loader Class Initialized
INFO - 2021-07-05 09:22:04 --> Helper loaded: html_helper
INFO - 2021-07-05 09:22:04 --> Helper loaded: url_helper
INFO - 2021-07-05 09:22:04 --> Helper loaded: form_helper
INFO - 2021-07-05 09:22:04 --> Database Driver Class Initialized
INFO - 2021-07-05 09:22:04 --> Form Validation Class Initialized
DEBUG - 2021-07-05 09:22:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 09:22:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 09:22:04 --> Encryption Class Initialized
INFO - 2021-07-05 09:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 09:22:04 --> Model "vendor_model" initialized
INFO - 2021-07-05 09:22:04 --> Model "coupon_model" initialized
INFO - 2021-07-05 09:22:04 --> Model "user_model" initialized
INFO - 2021-07-05 09:22:04 --> Model "role_model" initialized
INFO - 2021-07-05 09:22:04 --> Controller Class Initialized
INFO - 2021-07-05 09:22:04 --> Helper loaded: language_helper
INFO - 2021-07-05 09:22:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 09:22:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 09:22:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 09:22:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 09:22:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 09:22:04 --> Final output sent to browser
DEBUG - 2021-07-05 09:22:04 --> Total execution time: 0.0936
INFO - 2021-07-05 09:22:19 --> Config Class Initialized
INFO - 2021-07-05 09:22:19 --> Hooks Class Initialized
DEBUG - 2021-07-05 09:22:20 --> UTF-8 Support Enabled
INFO - 2021-07-05 09:22:20 --> Utf8 Class Initialized
INFO - 2021-07-05 09:22:20 --> URI Class Initialized
INFO - 2021-07-05 09:22:20 --> Router Class Initialized
INFO - 2021-07-05 09:22:20 --> Output Class Initialized
INFO - 2021-07-05 09:22:20 --> Security Class Initialized
DEBUG - 2021-07-05 09:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 09:22:20 --> Input Class Initialized
INFO - 2021-07-05 09:22:20 --> Language Class Initialized
INFO - 2021-07-05 09:22:20 --> Loader Class Initialized
INFO - 2021-07-05 09:22:20 --> Helper loaded: html_helper
INFO - 2021-07-05 09:22:20 --> Helper loaded: url_helper
INFO - 2021-07-05 09:22:20 --> Helper loaded: form_helper
INFO - 2021-07-05 09:22:20 --> Database Driver Class Initialized
INFO - 2021-07-05 09:22:20 --> Form Validation Class Initialized
DEBUG - 2021-07-05 09:22:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 09:22:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 09:22:20 --> Encryption Class Initialized
INFO - 2021-07-05 09:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 09:22:20 --> Model "vendor_model" initialized
INFO - 2021-07-05 09:22:20 --> Model "coupon_model" initialized
INFO - 2021-07-05 09:22:20 --> Model "user_model" initialized
INFO - 2021-07-05 09:22:20 --> Model "role_model" initialized
INFO - 2021-07-05 09:22:20 --> Controller Class Initialized
INFO - 2021-07-05 09:22:20 --> Helper loaded: language_helper
INFO - 2021-07-05 09:22:20 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 09:22:20 --> Model "Customer_model" initialized
INFO - 2021-07-05 09:22:20 --> Model "Product_model" initialized
INFO - 2021-07-05 09:22:20 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 09:22:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 09:22:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 09:22:20 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 09:22:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 09:22:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 09:22:20 --> Final output sent to browser
DEBUG - 2021-07-05 09:22:20 --> Total execution time: 0.0972
INFO - 2021-07-05 09:22:58 --> Config Class Initialized
INFO - 2021-07-05 09:22:58 --> Hooks Class Initialized
DEBUG - 2021-07-05 09:22:58 --> UTF-8 Support Enabled
INFO - 2021-07-05 09:22:58 --> Utf8 Class Initialized
INFO - 2021-07-05 09:22:58 --> URI Class Initialized
INFO - 2021-07-05 09:22:58 --> Router Class Initialized
INFO - 2021-07-05 09:22:58 --> Output Class Initialized
INFO - 2021-07-05 09:22:58 --> Security Class Initialized
DEBUG - 2021-07-05 09:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 09:22:58 --> Input Class Initialized
INFO - 2021-07-05 09:22:58 --> Language Class Initialized
INFO - 2021-07-05 09:22:58 --> Loader Class Initialized
INFO - 2021-07-05 09:22:58 --> Helper loaded: html_helper
INFO - 2021-07-05 09:22:58 --> Helper loaded: url_helper
INFO - 2021-07-05 09:22:58 --> Helper loaded: form_helper
INFO - 2021-07-05 09:22:58 --> Database Driver Class Initialized
INFO - 2021-07-05 09:22:58 --> Form Validation Class Initialized
DEBUG - 2021-07-05 09:22:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 09:22:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 09:22:58 --> Encryption Class Initialized
INFO - 2021-07-05 09:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 09:22:58 --> Model "vendor_model" initialized
INFO - 2021-07-05 09:22:58 --> Model "coupon_model" initialized
INFO - 2021-07-05 09:22:58 --> Model "user_model" initialized
INFO - 2021-07-05 09:22:58 --> Model "role_model" initialized
INFO - 2021-07-05 09:22:58 --> Controller Class Initialized
INFO - 2021-07-05 09:22:58 --> Helper loaded: language_helper
INFO - 2021-07-05 09:22:58 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 09:22:58 --> Model "Customer_model" initialized
INFO - 2021-07-05 09:22:58 --> Model "Product_model" initialized
INFO - 2021-07-05 09:22:58 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 09:22:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 09:22:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 09:22:58 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 09:22:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 09:22:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 09:22:58 --> Final output sent to browser
DEBUG - 2021-07-05 09:22:58 --> Total execution time: 0.0789
INFO - 2021-07-05 09:23:12 --> Config Class Initialized
INFO - 2021-07-05 09:23:12 --> Hooks Class Initialized
DEBUG - 2021-07-05 09:23:12 --> UTF-8 Support Enabled
INFO - 2021-07-05 09:23:12 --> Utf8 Class Initialized
INFO - 2021-07-05 09:23:12 --> URI Class Initialized
INFO - 2021-07-05 09:23:12 --> Router Class Initialized
INFO - 2021-07-05 09:23:12 --> Output Class Initialized
INFO - 2021-07-05 09:23:12 --> Security Class Initialized
DEBUG - 2021-07-05 09:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 09:23:12 --> Input Class Initialized
INFO - 2021-07-05 09:23:12 --> Language Class Initialized
INFO - 2021-07-05 09:23:12 --> Loader Class Initialized
INFO - 2021-07-05 09:23:12 --> Helper loaded: html_helper
INFO - 2021-07-05 09:23:12 --> Helper loaded: url_helper
INFO - 2021-07-05 09:23:12 --> Helper loaded: form_helper
INFO - 2021-07-05 09:23:12 --> Database Driver Class Initialized
INFO - 2021-07-05 09:23:12 --> Form Validation Class Initialized
DEBUG - 2021-07-05 09:23:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 09:23:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 09:23:12 --> Encryption Class Initialized
INFO - 2021-07-05 09:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 09:23:12 --> Model "vendor_model" initialized
INFO - 2021-07-05 09:23:12 --> Model "coupon_model" initialized
INFO - 2021-07-05 09:23:12 --> Model "user_model" initialized
INFO - 2021-07-05 09:23:12 --> Model "role_model" initialized
INFO - 2021-07-05 09:23:12 --> Controller Class Initialized
INFO - 2021-07-05 09:23:12 --> Helper loaded: language_helper
INFO - 2021-07-05 09:23:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 09:23:12 --> Model "Customer_model" initialized
INFO - 2021-07-05 09:23:12 --> Model "Product_model" initialized
INFO - 2021-07-05 09:23:12 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 09:23:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 09:23:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 09:23:12 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 09:23:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 09:23:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 09:23:12 --> Final output sent to browser
DEBUG - 2021-07-05 09:23:12 --> Total execution time: 0.0987
INFO - 2021-07-05 09:23:37 --> Config Class Initialized
INFO - 2021-07-05 09:23:37 --> Hooks Class Initialized
DEBUG - 2021-07-05 09:23:37 --> UTF-8 Support Enabled
INFO - 2021-07-05 09:23:37 --> Utf8 Class Initialized
INFO - 2021-07-05 09:23:37 --> URI Class Initialized
INFO - 2021-07-05 09:23:37 --> Router Class Initialized
INFO - 2021-07-05 09:23:37 --> Output Class Initialized
INFO - 2021-07-05 09:23:37 --> Security Class Initialized
DEBUG - 2021-07-05 09:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 09:23:37 --> Input Class Initialized
INFO - 2021-07-05 09:23:37 --> Language Class Initialized
INFO - 2021-07-05 09:23:37 --> Loader Class Initialized
INFO - 2021-07-05 09:23:37 --> Helper loaded: html_helper
INFO - 2021-07-05 09:23:37 --> Helper loaded: url_helper
INFO - 2021-07-05 09:23:37 --> Helper loaded: form_helper
INFO - 2021-07-05 09:23:37 --> Database Driver Class Initialized
INFO - 2021-07-05 09:23:37 --> Form Validation Class Initialized
DEBUG - 2021-07-05 09:23:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 09:23:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 09:23:37 --> Encryption Class Initialized
INFO - 2021-07-05 09:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 09:23:37 --> Model "vendor_model" initialized
INFO - 2021-07-05 09:23:37 --> Model "coupon_model" initialized
INFO - 2021-07-05 09:23:37 --> Model "user_model" initialized
INFO - 2021-07-05 09:23:37 --> Model "role_model" initialized
INFO - 2021-07-05 09:23:37 --> Controller Class Initialized
INFO - 2021-07-05 09:23:37 --> Helper loaded: language_helper
INFO - 2021-07-05 09:23:37 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 09:23:37 --> Model "Customer_model" initialized
INFO - 2021-07-05 09:23:37 --> Model "Product_model" initialized
INFO - 2021-07-05 09:23:37 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 09:23:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 09:23:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 09:23:37 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 09:23:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 09:23:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 09:23:37 --> Final output sent to browser
DEBUG - 2021-07-05 09:23:37 --> Total execution time: 0.0836
INFO - 2021-07-05 09:25:16 --> Config Class Initialized
INFO - 2021-07-05 09:25:16 --> Hooks Class Initialized
DEBUG - 2021-07-05 09:25:16 --> UTF-8 Support Enabled
INFO - 2021-07-05 09:25:16 --> Utf8 Class Initialized
INFO - 2021-07-05 09:25:16 --> URI Class Initialized
INFO - 2021-07-05 09:25:16 --> Router Class Initialized
INFO - 2021-07-05 09:25:16 --> Output Class Initialized
INFO - 2021-07-05 09:25:16 --> Security Class Initialized
DEBUG - 2021-07-05 09:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 09:25:16 --> Input Class Initialized
INFO - 2021-07-05 09:25:16 --> Language Class Initialized
INFO - 2021-07-05 09:25:16 --> Loader Class Initialized
INFO - 2021-07-05 09:25:16 --> Helper loaded: html_helper
INFO - 2021-07-05 09:25:16 --> Helper loaded: url_helper
INFO - 2021-07-05 09:25:16 --> Helper loaded: form_helper
INFO - 2021-07-05 09:25:16 --> Database Driver Class Initialized
INFO - 2021-07-05 09:25:16 --> Form Validation Class Initialized
DEBUG - 2021-07-05 09:25:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 09:25:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 09:25:16 --> Encryption Class Initialized
INFO - 2021-07-05 09:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 09:25:16 --> Model "vendor_model" initialized
INFO - 2021-07-05 09:25:16 --> Model "coupon_model" initialized
INFO - 2021-07-05 09:25:16 --> Model "user_model" initialized
INFO - 2021-07-05 09:25:16 --> Model "role_model" initialized
INFO - 2021-07-05 09:25:16 --> Controller Class Initialized
INFO - 2021-07-05 09:25:16 --> Helper loaded: language_helper
INFO - 2021-07-05 09:25:16 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 09:25:16 --> Model "Customer_model" initialized
INFO - 2021-07-05 09:25:16 --> Model "Product_model" initialized
INFO - 2021-07-05 09:25:16 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 09:25:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 09:25:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 09:25:16 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 09:25:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 09:25:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 09:25:16 --> Final output sent to browser
DEBUG - 2021-07-05 09:25:16 --> Total execution time: 0.1303
INFO - 2021-07-05 09:25:54 --> Config Class Initialized
INFO - 2021-07-05 09:25:54 --> Hooks Class Initialized
DEBUG - 2021-07-05 09:25:54 --> UTF-8 Support Enabled
INFO - 2021-07-05 09:25:54 --> Utf8 Class Initialized
INFO - 2021-07-05 09:25:54 --> URI Class Initialized
INFO - 2021-07-05 09:25:54 --> Router Class Initialized
INFO - 2021-07-05 09:25:54 --> Output Class Initialized
INFO - 2021-07-05 09:25:54 --> Security Class Initialized
DEBUG - 2021-07-05 09:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 09:25:54 --> Input Class Initialized
INFO - 2021-07-05 09:25:54 --> Language Class Initialized
INFO - 2021-07-05 09:25:54 --> Loader Class Initialized
INFO - 2021-07-05 09:25:54 --> Helper loaded: html_helper
INFO - 2021-07-05 09:25:54 --> Helper loaded: url_helper
INFO - 2021-07-05 09:25:54 --> Helper loaded: form_helper
INFO - 2021-07-05 09:25:54 --> Database Driver Class Initialized
INFO - 2021-07-05 09:25:55 --> Form Validation Class Initialized
DEBUG - 2021-07-05 09:25:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 09:25:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 09:25:55 --> Encryption Class Initialized
INFO - 2021-07-05 09:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 09:25:55 --> Model "vendor_model" initialized
INFO - 2021-07-05 09:25:55 --> Model "coupon_model" initialized
INFO - 2021-07-05 09:25:55 --> Model "user_model" initialized
INFO - 2021-07-05 09:25:55 --> Model "role_model" initialized
INFO - 2021-07-05 09:25:55 --> Controller Class Initialized
INFO - 2021-07-05 09:25:55 --> Helper loaded: language_helper
INFO - 2021-07-05 09:25:55 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 09:25:55 --> Model "Customer_model" initialized
INFO - 2021-07-05 09:25:55 --> Model "Product_model" initialized
INFO - 2021-07-05 09:25:55 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 09:25:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 09:25:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 09:25:55 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 09:25:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 09:25:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 09:25:55 --> Final output sent to browser
DEBUG - 2021-07-05 09:25:55 --> Total execution time: 0.0698
INFO - 2021-07-05 09:28:15 --> Config Class Initialized
INFO - 2021-07-05 09:28:15 --> Hooks Class Initialized
DEBUG - 2021-07-05 09:28:15 --> UTF-8 Support Enabled
INFO - 2021-07-05 09:28:15 --> Utf8 Class Initialized
INFO - 2021-07-05 09:28:15 --> URI Class Initialized
DEBUG - 2021-07-05 09:28:15 --> No URI present. Default controller set.
INFO - 2021-07-05 09:28:15 --> Router Class Initialized
INFO - 2021-07-05 09:28:15 --> Output Class Initialized
INFO - 2021-07-05 09:28:15 --> Security Class Initialized
DEBUG - 2021-07-05 09:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 09:28:15 --> Input Class Initialized
INFO - 2021-07-05 09:28:15 --> Language Class Initialized
INFO - 2021-07-05 09:28:15 --> Loader Class Initialized
INFO - 2021-07-05 09:28:15 --> Helper loaded: html_helper
INFO - 2021-07-05 09:28:15 --> Helper loaded: url_helper
INFO - 2021-07-05 09:28:15 --> Helper loaded: form_helper
INFO - 2021-07-05 09:28:15 --> Database Driver Class Initialized
INFO - 2021-07-05 09:28:15 --> Form Validation Class Initialized
DEBUG - 2021-07-05 09:28:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 09:28:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 09:28:15 --> Encryption Class Initialized
INFO - 2021-07-05 09:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 09:28:15 --> Model "vendor_model" initialized
INFO - 2021-07-05 09:28:15 --> Model "coupon_model" initialized
INFO - 2021-07-05 09:28:15 --> Model "user_model" initialized
INFO - 2021-07-05 09:28:15 --> Model "role_model" initialized
INFO - 2021-07-05 09:28:15 --> Controller Class Initialized
INFO - 2021-07-05 09:28:16 --> Helper loaded: language_helper
INFO - 2021-07-05 09:28:16 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 09:28:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 09:28:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 09:28:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 09:28:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 09:28:16 --> Final output sent to browser
DEBUG - 2021-07-05 09:28:16 --> Total execution time: 0.0792
INFO - 2021-07-05 09:28:25 --> Config Class Initialized
INFO - 2021-07-05 09:28:25 --> Hooks Class Initialized
DEBUG - 2021-07-05 09:28:25 --> UTF-8 Support Enabled
INFO - 2021-07-05 09:28:25 --> Utf8 Class Initialized
INFO - 2021-07-05 09:28:25 --> URI Class Initialized
DEBUG - 2021-07-05 09:28:25 --> No URI present. Default controller set.
INFO - 2021-07-05 09:28:25 --> Router Class Initialized
INFO - 2021-07-05 09:28:25 --> Output Class Initialized
INFO - 2021-07-05 09:28:25 --> Security Class Initialized
DEBUG - 2021-07-05 09:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 09:28:25 --> Input Class Initialized
INFO - 2021-07-05 09:28:25 --> Language Class Initialized
INFO - 2021-07-05 09:28:25 --> Loader Class Initialized
INFO - 2021-07-05 09:28:25 --> Helper loaded: html_helper
INFO - 2021-07-05 09:28:25 --> Helper loaded: url_helper
INFO - 2021-07-05 09:28:25 --> Helper loaded: form_helper
INFO - 2021-07-05 09:28:25 --> Database Driver Class Initialized
INFO - 2021-07-05 09:28:25 --> Form Validation Class Initialized
DEBUG - 2021-07-05 09:28:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 09:28:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 09:28:25 --> Encryption Class Initialized
INFO - 2021-07-05 09:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 09:28:25 --> Model "vendor_model" initialized
INFO - 2021-07-05 09:28:25 --> Model "coupon_model" initialized
INFO - 2021-07-05 09:28:25 --> Model "user_model" initialized
INFO - 2021-07-05 09:28:25 --> Model "role_model" initialized
INFO - 2021-07-05 09:28:25 --> Controller Class Initialized
INFO - 2021-07-05 09:28:25 --> Helper loaded: language_helper
INFO - 2021-07-05 09:28:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 09:28:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 09:28:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 09:28:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 09:28:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 09:28:25 --> Final output sent to browser
DEBUG - 2021-07-05 09:28:25 --> Total execution time: 0.0764
INFO - 2021-07-05 09:28:47 --> Config Class Initialized
INFO - 2021-07-05 09:28:47 --> Hooks Class Initialized
DEBUG - 2021-07-05 09:28:47 --> UTF-8 Support Enabled
INFO - 2021-07-05 09:28:47 --> Utf8 Class Initialized
INFO - 2021-07-05 09:28:47 --> URI Class Initialized
INFO - 2021-07-05 09:28:47 --> Router Class Initialized
INFO - 2021-07-05 09:28:47 --> Output Class Initialized
INFO - 2021-07-05 09:28:47 --> Security Class Initialized
DEBUG - 2021-07-05 09:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 09:28:47 --> Input Class Initialized
INFO - 2021-07-05 09:28:47 --> Language Class Initialized
INFO - 2021-07-05 09:28:47 --> Loader Class Initialized
INFO - 2021-07-05 09:28:47 --> Helper loaded: html_helper
INFO - 2021-07-05 09:28:47 --> Helper loaded: url_helper
INFO - 2021-07-05 09:28:47 --> Helper loaded: form_helper
INFO - 2021-07-05 09:28:47 --> Database Driver Class Initialized
INFO - 2021-07-05 09:28:47 --> Form Validation Class Initialized
DEBUG - 2021-07-05 09:28:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 09:28:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 09:28:47 --> Encryption Class Initialized
INFO - 2021-07-05 09:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 09:28:47 --> Model "vendor_model" initialized
INFO - 2021-07-05 09:28:47 --> Model "coupon_model" initialized
INFO - 2021-07-05 09:28:47 --> Model "user_model" initialized
INFO - 2021-07-05 09:28:47 --> Model "role_model" initialized
INFO - 2021-07-05 09:28:47 --> Controller Class Initialized
INFO - 2021-07-05 09:28:47 --> Helper loaded: language_helper
INFO - 2021-07-05 09:28:47 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 09:28:47 --> Model "Customer_model" initialized
INFO - 2021-07-05 09:28:47 --> Model "Product_model" initialized
INFO - 2021-07-05 09:28:47 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 09:28:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 09:28:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 09:28:47 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 09:28:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 09:28:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 09:28:47 --> Final output sent to browser
DEBUG - 2021-07-05 09:28:47 --> Total execution time: 0.0990
INFO - 2021-07-05 09:29:13 --> Config Class Initialized
INFO - 2021-07-05 09:29:13 --> Hooks Class Initialized
DEBUG - 2021-07-05 09:29:13 --> UTF-8 Support Enabled
INFO - 2021-07-05 09:29:13 --> Utf8 Class Initialized
INFO - 2021-07-05 09:29:13 --> URI Class Initialized
INFO - 2021-07-05 09:29:13 --> Router Class Initialized
INFO - 2021-07-05 09:29:13 --> Output Class Initialized
INFO - 2021-07-05 09:29:13 --> Security Class Initialized
DEBUG - 2021-07-05 09:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 09:29:13 --> Input Class Initialized
INFO - 2021-07-05 09:29:13 --> Language Class Initialized
INFO - 2021-07-05 09:29:13 --> Loader Class Initialized
INFO - 2021-07-05 09:29:13 --> Helper loaded: html_helper
INFO - 2021-07-05 09:29:13 --> Helper loaded: url_helper
INFO - 2021-07-05 09:29:13 --> Helper loaded: form_helper
INFO - 2021-07-05 09:29:13 --> Database Driver Class Initialized
INFO - 2021-07-05 09:29:13 --> Form Validation Class Initialized
DEBUG - 2021-07-05 09:29:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 09:29:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 09:29:13 --> Encryption Class Initialized
INFO - 2021-07-05 09:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 09:29:13 --> Model "vendor_model" initialized
INFO - 2021-07-05 09:29:13 --> Model "coupon_model" initialized
INFO - 2021-07-05 09:29:13 --> Model "user_model" initialized
INFO - 2021-07-05 09:29:13 --> Model "role_model" initialized
INFO - 2021-07-05 09:29:13 --> Controller Class Initialized
INFO - 2021-07-05 09:29:13 --> Helper loaded: language_helper
INFO - 2021-07-05 09:29:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 09:29:13 --> Model "Customer_model" initialized
INFO - 2021-07-05 09:29:13 --> Model "Product_model" initialized
INFO - 2021-07-05 09:29:13 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 09:29:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 09:29:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 09:29:13 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 09:29:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 09:29:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 09:29:13 --> Final output sent to browser
DEBUG - 2021-07-05 09:29:13 --> Total execution time: 0.0804
INFO - 2021-07-05 09:31:07 --> Config Class Initialized
INFO - 2021-07-05 09:31:07 --> Hooks Class Initialized
DEBUG - 2021-07-05 09:31:07 --> UTF-8 Support Enabled
INFO - 2021-07-05 09:31:07 --> Utf8 Class Initialized
INFO - 2021-07-05 09:31:07 --> URI Class Initialized
INFO - 2021-07-05 09:31:07 --> Router Class Initialized
INFO - 2021-07-05 09:31:07 --> Output Class Initialized
INFO - 2021-07-05 09:31:07 --> Security Class Initialized
DEBUG - 2021-07-05 09:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 09:31:07 --> Input Class Initialized
INFO - 2021-07-05 09:31:07 --> Language Class Initialized
INFO - 2021-07-05 09:31:07 --> Loader Class Initialized
INFO - 2021-07-05 09:31:07 --> Helper loaded: html_helper
INFO - 2021-07-05 09:31:07 --> Helper loaded: url_helper
INFO - 2021-07-05 09:31:07 --> Helper loaded: form_helper
INFO - 2021-07-05 09:31:07 --> Database Driver Class Initialized
INFO - 2021-07-05 09:31:07 --> Form Validation Class Initialized
DEBUG - 2021-07-05 09:31:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 09:31:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 09:31:07 --> Encryption Class Initialized
INFO - 2021-07-05 09:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 09:31:07 --> Model "vendor_model" initialized
INFO - 2021-07-05 09:31:07 --> Model "coupon_model" initialized
INFO - 2021-07-05 09:31:07 --> Model "user_model" initialized
INFO - 2021-07-05 09:31:07 --> Model "role_model" initialized
INFO - 2021-07-05 09:31:07 --> Controller Class Initialized
INFO - 2021-07-05 09:31:07 --> Helper loaded: language_helper
INFO - 2021-07-05 09:31:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 09:31:07 --> Model "Customer_model" initialized
INFO - 2021-07-05 09:31:07 --> Model "Product_model" initialized
INFO - 2021-07-05 09:31:07 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 09:31:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 09:31:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 09:31:07 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 09:31:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 09:31:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 09:31:07 --> Final output sent to browser
DEBUG - 2021-07-05 09:31:07 --> Total execution time: 0.1333
INFO - 2021-07-05 09:31:54 --> Config Class Initialized
INFO - 2021-07-05 09:31:54 --> Hooks Class Initialized
DEBUG - 2021-07-05 09:31:54 --> UTF-8 Support Enabled
INFO - 2021-07-05 09:31:54 --> Utf8 Class Initialized
INFO - 2021-07-05 09:31:54 --> URI Class Initialized
INFO - 2021-07-05 09:31:54 --> Router Class Initialized
INFO - 2021-07-05 09:31:54 --> Output Class Initialized
INFO - 2021-07-05 09:31:54 --> Security Class Initialized
DEBUG - 2021-07-05 09:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 09:31:54 --> Input Class Initialized
INFO - 2021-07-05 09:31:54 --> Language Class Initialized
INFO - 2021-07-05 09:31:54 --> Loader Class Initialized
INFO - 2021-07-05 09:31:54 --> Helper loaded: html_helper
INFO - 2021-07-05 09:31:54 --> Helper loaded: url_helper
INFO - 2021-07-05 09:31:54 --> Helper loaded: form_helper
INFO - 2021-07-05 09:31:54 --> Database Driver Class Initialized
INFO - 2021-07-05 09:31:54 --> Form Validation Class Initialized
DEBUG - 2021-07-05 09:31:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 09:31:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 09:31:54 --> Encryption Class Initialized
INFO - 2021-07-05 09:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 09:31:54 --> Model "vendor_model" initialized
INFO - 2021-07-05 09:31:54 --> Model "coupon_model" initialized
INFO - 2021-07-05 09:31:54 --> Model "user_model" initialized
INFO - 2021-07-05 09:31:54 --> Model "role_model" initialized
INFO - 2021-07-05 09:31:54 --> Controller Class Initialized
INFO - 2021-07-05 09:31:54 --> Helper loaded: language_helper
INFO - 2021-07-05 09:31:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 09:31:54 --> Model "Customer_model" initialized
INFO - 2021-07-05 09:31:54 --> Model "Product_model" initialized
INFO - 2021-07-05 09:31:54 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 09:31:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 09:31:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 09:31:54 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 09:31:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 09:31:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 09:31:54 --> Final output sent to browser
DEBUG - 2021-07-05 09:31:54 --> Total execution time: 0.1182
INFO - 2021-07-05 09:32:31 --> Config Class Initialized
INFO - 2021-07-05 09:32:31 --> Hooks Class Initialized
DEBUG - 2021-07-05 09:32:31 --> UTF-8 Support Enabled
INFO - 2021-07-05 09:32:31 --> Utf8 Class Initialized
INFO - 2021-07-05 09:32:31 --> URI Class Initialized
DEBUG - 2021-07-05 09:32:31 --> No URI present. Default controller set.
INFO - 2021-07-05 09:32:31 --> Router Class Initialized
INFO - 2021-07-05 09:32:31 --> Output Class Initialized
INFO - 2021-07-05 09:32:31 --> Security Class Initialized
DEBUG - 2021-07-05 09:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 09:32:31 --> Input Class Initialized
INFO - 2021-07-05 09:32:31 --> Language Class Initialized
INFO - 2021-07-05 09:32:31 --> Loader Class Initialized
INFO - 2021-07-05 09:32:31 --> Helper loaded: html_helper
INFO - 2021-07-05 09:32:31 --> Helper loaded: url_helper
INFO - 2021-07-05 09:32:31 --> Helper loaded: form_helper
INFO - 2021-07-05 09:32:31 --> Database Driver Class Initialized
INFO - 2021-07-05 09:32:31 --> Form Validation Class Initialized
DEBUG - 2021-07-05 09:32:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 09:32:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 09:32:31 --> Encryption Class Initialized
INFO - 2021-07-05 09:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 09:32:31 --> Model "vendor_model" initialized
INFO - 2021-07-05 09:32:31 --> Model "coupon_model" initialized
INFO - 2021-07-05 09:32:31 --> Model "user_model" initialized
INFO - 2021-07-05 09:32:31 --> Model "role_model" initialized
INFO - 2021-07-05 09:32:31 --> Controller Class Initialized
INFO - 2021-07-05 09:32:31 --> Helper loaded: language_helper
INFO - 2021-07-05 09:32:31 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 09:32:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 09:32:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 09:32:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 09:32:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 09:32:31 --> Final output sent to browser
DEBUG - 2021-07-05 09:32:31 --> Total execution time: 0.0677
INFO - 2021-07-05 09:32:48 --> Config Class Initialized
INFO - 2021-07-05 09:32:48 --> Hooks Class Initialized
DEBUG - 2021-07-05 09:32:48 --> UTF-8 Support Enabled
INFO - 2021-07-05 09:32:48 --> Utf8 Class Initialized
INFO - 2021-07-05 09:32:48 --> URI Class Initialized
INFO - 2021-07-05 09:32:48 --> Router Class Initialized
INFO - 2021-07-05 09:32:48 --> Output Class Initialized
INFO - 2021-07-05 09:32:48 --> Security Class Initialized
DEBUG - 2021-07-05 09:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 09:32:48 --> Input Class Initialized
INFO - 2021-07-05 09:32:48 --> Language Class Initialized
INFO - 2021-07-05 09:32:48 --> Loader Class Initialized
INFO - 2021-07-05 09:32:48 --> Helper loaded: html_helper
INFO - 2021-07-05 09:32:48 --> Helper loaded: url_helper
INFO - 2021-07-05 09:32:48 --> Helper loaded: form_helper
INFO - 2021-07-05 09:32:48 --> Database Driver Class Initialized
INFO - 2021-07-05 09:32:48 --> Form Validation Class Initialized
DEBUG - 2021-07-05 09:32:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 09:32:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 09:32:48 --> Encryption Class Initialized
INFO - 2021-07-05 09:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 09:32:48 --> Model "vendor_model" initialized
INFO - 2021-07-05 09:32:48 --> Model "coupon_model" initialized
INFO - 2021-07-05 09:32:48 --> Model "user_model" initialized
INFO - 2021-07-05 09:32:48 --> Model "role_model" initialized
INFO - 2021-07-05 09:32:48 --> Controller Class Initialized
INFO - 2021-07-05 09:32:48 --> Helper loaded: language_helper
INFO - 2021-07-05 09:32:48 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 09:32:48 --> Model "Customer_model" initialized
INFO - 2021-07-05 09:32:48 --> Model "Product_model" initialized
INFO - 2021-07-05 09:32:48 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 09:32:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 09:32:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 09:32:48 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 09:32:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 09:32:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 09:32:48 --> Final output sent to browser
DEBUG - 2021-07-05 09:32:48 --> Total execution time: 0.0752
INFO - 2021-07-05 09:33:31 --> Config Class Initialized
INFO - 2021-07-05 09:33:31 --> Hooks Class Initialized
DEBUG - 2021-07-05 09:33:31 --> UTF-8 Support Enabled
INFO - 2021-07-05 09:33:31 --> Utf8 Class Initialized
INFO - 2021-07-05 09:33:31 --> URI Class Initialized
INFO - 2021-07-05 09:33:31 --> Router Class Initialized
INFO - 2021-07-05 09:33:31 --> Output Class Initialized
INFO - 2021-07-05 09:33:31 --> Security Class Initialized
DEBUG - 2021-07-05 09:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 09:33:31 --> Input Class Initialized
INFO - 2021-07-05 09:33:31 --> Language Class Initialized
INFO - 2021-07-05 09:33:31 --> Loader Class Initialized
INFO - 2021-07-05 09:33:31 --> Helper loaded: html_helper
INFO - 2021-07-05 09:33:31 --> Helper loaded: url_helper
INFO - 2021-07-05 09:33:31 --> Helper loaded: form_helper
INFO - 2021-07-05 09:33:31 --> Database Driver Class Initialized
INFO - 2021-07-05 09:33:31 --> Form Validation Class Initialized
DEBUG - 2021-07-05 09:33:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 09:33:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 09:33:31 --> Encryption Class Initialized
INFO - 2021-07-05 09:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 09:33:31 --> Model "vendor_model" initialized
INFO - 2021-07-05 09:33:31 --> Model "coupon_model" initialized
INFO - 2021-07-05 09:33:31 --> Model "user_model" initialized
INFO - 2021-07-05 09:33:31 --> Model "role_model" initialized
INFO - 2021-07-05 09:33:31 --> Controller Class Initialized
INFO - 2021-07-05 09:33:31 --> Helper loaded: language_helper
INFO - 2021-07-05 09:33:31 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 09:33:31 --> Model "Customer_model" initialized
INFO - 2021-07-05 09:33:31 --> Model "Product_model" initialized
INFO - 2021-07-05 09:33:31 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 09:33:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 09:33:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 09:33:31 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 09:33:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 09:33:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 09:33:31 --> Final output sent to browser
DEBUG - 2021-07-05 09:33:31 --> Total execution time: 0.0699
INFO - 2021-07-05 09:34:41 --> Config Class Initialized
INFO - 2021-07-05 09:34:41 --> Hooks Class Initialized
DEBUG - 2021-07-05 09:34:41 --> UTF-8 Support Enabled
INFO - 2021-07-05 09:34:41 --> Utf8 Class Initialized
INFO - 2021-07-05 09:34:41 --> URI Class Initialized
INFO - 2021-07-05 09:34:41 --> Router Class Initialized
INFO - 2021-07-05 09:34:41 --> Output Class Initialized
INFO - 2021-07-05 09:34:41 --> Security Class Initialized
DEBUG - 2021-07-05 09:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 09:34:41 --> Input Class Initialized
INFO - 2021-07-05 09:34:41 --> Language Class Initialized
INFO - 2021-07-05 09:34:41 --> Loader Class Initialized
INFO - 2021-07-05 09:34:41 --> Helper loaded: html_helper
INFO - 2021-07-05 09:34:41 --> Helper loaded: url_helper
INFO - 2021-07-05 09:34:41 --> Helper loaded: form_helper
INFO - 2021-07-05 09:34:41 --> Database Driver Class Initialized
INFO - 2021-07-05 09:34:41 --> Form Validation Class Initialized
DEBUG - 2021-07-05 09:34:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 09:34:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 09:34:41 --> Encryption Class Initialized
INFO - 2021-07-05 09:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 09:34:41 --> Model "vendor_model" initialized
INFO - 2021-07-05 09:34:41 --> Model "coupon_model" initialized
INFO - 2021-07-05 09:34:41 --> Model "user_model" initialized
INFO - 2021-07-05 09:34:41 --> Model "role_model" initialized
INFO - 2021-07-05 09:34:41 --> Controller Class Initialized
INFO - 2021-07-05 09:34:41 --> Helper loaded: language_helper
INFO - 2021-07-05 09:34:41 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 09:34:41 --> Model "Customer_model" initialized
INFO - 2021-07-05 09:34:41 --> Model "Product_model" initialized
INFO - 2021-07-05 09:34:41 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 09:34:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 09:34:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 09:34:41 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 09:34:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 09:34:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 09:34:41 --> Final output sent to browser
DEBUG - 2021-07-05 09:34:41 --> Total execution time: 0.1122
INFO - 2021-07-05 09:34:59 --> Config Class Initialized
INFO - 2021-07-05 09:34:59 --> Hooks Class Initialized
DEBUG - 2021-07-05 09:34:59 --> UTF-8 Support Enabled
INFO - 2021-07-05 09:34:59 --> Utf8 Class Initialized
INFO - 2021-07-05 09:34:59 --> URI Class Initialized
INFO - 2021-07-05 09:34:59 --> Router Class Initialized
INFO - 2021-07-05 09:34:59 --> Output Class Initialized
INFO - 2021-07-05 09:34:59 --> Security Class Initialized
DEBUG - 2021-07-05 09:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 09:34:59 --> Input Class Initialized
INFO - 2021-07-05 09:34:59 --> Language Class Initialized
INFO - 2021-07-05 09:34:59 --> Loader Class Initialized
INFO - 2021-07-05 09:34:59 --> Helper loaded: html_helper
INFO - 2021-07-05 09:34:59 --> Helper loaded: url_helper
INFO - 2021-07-05 09:34:59 --> Helper loaded: form_helper
INFO - 2021-07-05 09:34:59 --> Database Driver Class Initialized
INFO - 2021-07-05 09:34:59 --> Form Validation Class Initialized
DEBUG - 2021-07-05 09:34:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 09:34:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 09:34:59 --> Encryption Class Initialized
INFO - 2021-07-05 09:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 09:34:59 --> Model "vendor_model" initialized
INFO - 2021-07-05 09:34:59 --> Model "coupon_model" initialized
INFO - 2021-07-05 09:34:59 --> Model "user_model" initialized
INFO - 2021-07-05 09:34:59 --> Model "role_model" initialized
INFO - 2021-07-05 09:34:59 --> Controller Class Initialized
INFO - 2021-07-05 09:34:59 --> Helper loaded: language_helper
INFO - 2021-07-05 09:34:59 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 09:34:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 09:34:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 09:34:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\customer_care.php
INFO - 2021-07-05 09:34:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 09:34:59 --> Final output sent to browser
DEBUG - 2021-07-05 09:34:59 --> Total execution time: 0.2045
INFO - 2021-07-05 09:35:25 --> Config Class Initialized
INFO - 2021-07-05 09:35:25 --> Hooks Class Initialized
DEBUG - 2021-07-05 09:35:25 --> UTF-8 Support Enabled
INFO - 2021-07-05 09:35:25 --> Utf8 Class Initialized
INFO - 2021-07-05 09:35:25 --> URI Class Initialized
INFO - 2021-07-05 09:35:25 --> Router Class Initialized
INFO - 2021-07-05 09:35:25 --> Output Class Initialized
INFO - 2021-07-05 09:35:25 --> Security Class Initialized
DEBUG - 2021-07-05 09:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 09:35:25 --> Input Class Initialized
INFO - 2021-07-05 09:35:25 --> Language Class Initialized
INFO - 2021-07-05 09:35:25 --> Loader Class Initialized
INFO - 2021-07-05 09:35:25 --> Helper loaded: html_helper
INFO - 2021-07-05 09:35:25 --> Helper loaded: url_helper
INFO - 2021-07-05 09:35:25 --> Helper loaded: form_helper
INFO - 2021-07-05 09:35:25 --> Database Driver Class Initialized
INFO - 2021-07-05 09:35:25 --> Form Validation Class Initialized
DEBUG - 2021-07-05 09:35:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 09:35:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 09:35:25 --> Encryption Class Initialized
INFO - 2021-07-05 09:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 09:35:25 --> Model "vendor_model" initialized
INFO - 2021-07-05 09:35:25 --> Model "coupon_model" initialized
INFO - 2021-07-05 09:35:25 --> Model "user_model" initialized
INFO - 2021-07-05 09:35:25 --> Model "role_model" initialized
INFO - 2021-07-05 09:35:25 --> Controller Class Initialized
INFO - 2021-07-05 09:35:25 --> Helper loaded: language_helper
INFO - 2021-07-05 09:35:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 09:35:25 --> Model "Customer_model" initialized
INFO - 2021-07-05 09:35:25 --> Model "Product_model" initialized
INFO - 2021-07-05 09:35:25 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 09:35:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 09:35:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 09:35:25 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 09:35:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 09:35:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 09:35:25 --> Final output sent to browser
DEBUG - 2021-07-05 09:35:25 --> Total execution time: 0.0859
INFO - 2021-07-05 09:36:04 --> Config Class Initialized
INFO - 2021-07-05 09:36:04 --> Hooks Class Initialized
DEBUG - 2021-07-05 09:36:04 --> UTF-8 Support Enabled
INFO - 2021-07-05 09:36:04 --> Utf8 Class Initialized
INFO - 2021-07-05 09:36:04 --> URI Class Initialized
INFO - 2021-07-05 09:36:04 --> Router Class Initialized
INFO - 2021-07-05 09:36:04 --> Output Class Initialized
INFO - 2021-07-05 09:36:04 --> Security Class Initialized
DEBUG - 2021-07-05 09:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 09:36:04 --> Input Class Initialized
INFO - 2021-07-05 09:36:04 --> Language Class Initialized
INFO - 2021-07-05 09:36:04 --> Loader Class Initialized
INFO - 2021-07-05 09:36:04 --> Helper loaded: html_helper
INFO - 2021-07-05 09:36:04 --> Helper loaded: url_helper
INFO - 2021-07-05 09:36:04 --> Helper loaded: form_helper
INFO - 2021-07-05 09:36:04 --> Database Driver Class Initialized
INFO - 2021-07-05 09:36:04 --> Form Validation Class Initialized
DEBUG - 2021-07-05 09:36:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 09:36:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 09:36:04 --> Encryption Class Initialized
INFO - 2021-07-05 09:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 09:36:04 --> Model "vendor_model" initialized
INFO - 2021-07-05 09:36:04 --> Model "coupon_model" initialized
INFO - 2021-07-05 09:36:04 --> Model "user_model" initialized
INFO - 2021-07-05 09:36:04 --> Model "role_model" initialized
INFO - 2021-07-05 09:36:04 --> Controller Class Initialized
INFO - 2021-07-05 09:36:04 --> Helper loaded: language_helper
INFO - 2021-07-05 09:36:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 09:36:04 --> Model "Customer_model" initialized
INFO - 2021-07-05 09:36:04 --> Final output sent to browser
DEBUG - 2021-07-05 09:36:04 --> Total execution time: 0.0633
INFO - 2021-07-05 09:36:08 --> Config Class Initialized
INFO - 2021-07-05 09:36:08 --> Hooks Class Initialized
DEBUG - 2021-07-05 09:36:08 --> UTF-8 Support Enabled
INFO - 2021-07-05 09:36:08 --> Utf8 Class Initialized
INFO - 2021-07-05 09:36:08 --> URI Class Initialized
INFO - 2021-07-05 09:36:08 --> Router Class Initialized
INFO - 2021-07-05 09:36:08 --> Output Class Initialized
INFO - 2021-07-05 09:36:08 --> Security Class Initialized
DEBUG - 2021-07-05 09:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 09:36:08 --> Input Class Initialized
INFO - 2021-07-05 09:36:08 --> Language Class Initialized
INFO - 2021-07-05 09:36:08 --> Loader Class Initialized
INFO - 2021-07-05 09:36:08 --> Helper loaded: html_helper
INFO - 2021-07-05 09:36:08 --> Helper loaded: url_helper
INFO - 2021-07-05 09:36:08 --> Helper loaded: form_helper
INFO - 2021-07-05 09:36:08 --> Database Driver Class Initialized
INFO - 2021-07-05 09:36:08 --> Form Validation Class Initialized
DEBUG - 2021-07-05 09:36:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 09:36:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 09:36:08 --> Encryption Class Initialized
INFO - 2021-07-05 09:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 09:36:08 --> Model "vendor_model" initialized
INFO - 2021-07-05 09:36:08 --> Model "coupon_model" initialized
INFO - 2021-07-05 09:36:08 --> Model "user_model" initialized
INFO - 2021-07-05 09:36:08 --> Model "role_model" initialized
INFO - 2021-07-05 09:36:08 --> Controller Class Initialized
INFO - 2021-07-05 09:36:08 --> Helper loaded: language_helper
INFO - 2021-07-05 09:36:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 09:36:08 --> Model "Customer_model" initialized
INFO - 2021-07-05 09:36:08 --> Model "Product_model" initialized
INFO - 2021-07-05 09:36:08 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 09:36:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 09:36:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 09:36:08 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 09:36:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 09:36:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 09:36:08 --> Final output sent to browser
DEBUG - 2021-07-05 09:36:08 --> Total execution time: 0.0701
INFO - 2021-07-05 10:20:28 --> Config Class Initialized
INFO - 2021-07-05 10:20:28 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:20:28 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:20:28 --> Utf8 Class Initialized
INFO - 2021-07-05 10:20:28 --> URI Class Initialized
INFO - 2021-07-05 10:20:28 --> Router Class Initialized
INFO - 2021-07-05 10:20:28 --> Output Class Initialized
INFO - 2021-07-05 10:20:28 --> Security Class Initialized
DEBUG - 2021-07-05 10:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:20:28 --> Input Class Initialized
INFO - 2021-07-05 10:20:28 --> Language Class Initialized
INFO - 2021-07-05 10:20:28 --> Loader Class Initialized
INFO - 2021-07-05 10:20:28 --> Helper loaded: html_helper
INFO - 2021-07-05 10:20:28 --> Helper loaded: url_helper
INFO - 2021-07-05 10:20:28 --> Helper loaded: form_helper
INFO - 2021-07-05 10:20:28 --> Database Driver Class Initialized
INFO - 2021-07-05 10:20:29 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:20:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:20:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:20:29 --> Encryption Class Initialized
INFO - 2021-07-05 10:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:20:29 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:20:29 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:20:29 --> Model "user_model" initialized
INFO - 2021-07-05 10:20:29 --> Model "role_model" initialized
INFO - 2021-07-05 10:20:29 --> Controller Class Initialized
INFO - 2021-07-05 10:20:29 --> Helper loaded: language_helper
INFO - 2021-07-05 10:20:29 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:20:29 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:20:29 --> Model "Product_model" initialized
INFO - 2021-07-05 10:20:29 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:20:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:20:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:20:29 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:20:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:20:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:20:29 --> Final output sent to browser
DEBUG - 2021-07-05 10:20:29 --> Total execution time: 0.1817
INFO - 2021-07-05 10:20:57 --> Config Class Initialized
INFO - 2021-07-05 10:20:57 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:20:57 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:20:57 --> Utf8 Class Initialized
INFO - 2021-07-05 10:20:57 --> URI Class Initialized
INFO - 2021-07-05 10:20:57 --> Router Class Initialized
INFO - 2021-07-05 10:20:57 --> Output Class Initialized
INFO - 2021-07-05 10:20:57 --> Security Class Initialized
DEBUG - 2021-07-05 10:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:20:57 --> Input Class Initialized
INFO - 2021-07-05 10:20:57 --> Language Class Initialized
INFO - 2021-07-05 10:20:57 --> Loader Class Initialized
INFO - 2021-07-05 10:20:57 --> Helper loaded: html_helper
INFO - 2021-07-05 10:20:57 --> Helper loaded: url_helper
INFO - 2021-07-05 10:20:57 --> Helper loaded: form_helper
INFO - 2021-07-05 10:20:57 --> Database Driver Class Initialized
INFO - 2021-07-05 10:20:57 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:20:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:20:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:20:57 --> Encryption Class Initialized
INFO - 2021-07-05 10:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:20:57 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:20:57 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:20:57 --> Model "user_model" initialized
INFO - 2021-07-05 10:20:57 --> Model "role_model" initialized
INFO - 2021-07-05 10:20:57 --> Controller Class Initialized
INFO - 2021-07-05 10:20:57 --> Helper loaded: language_helper
INFO - 2021-07-05 10:20:57 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:20:57 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:20:57 --> Model "Product_model" initialized
INFO - 2021-07-05 10:20:57 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:20:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:20:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:20:57 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:20:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:20:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:20:57 --> Final output sent to browser
DEBUG - 2021-07-05 10:20:57 --> Total execution time: 0.0740
INFO - 2021-07-05 10:21:33 --> Config Class Initialized
INFO - 2021-07-05 10:21:33 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:21:33 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:21:33 --> Utf8 Class Initialized
INFO - 2021-07-05 10:21:33 --> URI Class Initialized
DEBUG - 2021-07-05 10:21:33 --> No URI present. Default controller set.
INFO - 2021-07-05 10:21:33 --> Router Class Initialized
INFO - 2021-07-05 10:21:33 --> Output Class Initialized
INFO - 2021-07-05 10:21:33 --> Security Class Initialized
DEBUG - 2021-07-05 10:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:21:33 --> Input Class Initialized
INFO - 2021-07-05 10:21:33 --> Language Class Initialized
INFO - 2021-07-05 10:21:33 --> Loader Class Initialized
INFO - 2021-07-05 10:21:33 --> Helper loaded: html_helper
INFO - 2021-07-05 10:21:33 --> Helper loaded: url_helper
INFO - 2021-07-05 10:21:33 --> Helper loaded: form_helper
INFO - 2021-07-05 10:21:33 --> Database Driver Class Initialized
INFO - 2021-07-05 10:21:33 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:21:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:21:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:21:33 --> Encryption Class Initialized
INFO - 2021-07-05 10:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:21:33 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:21:33 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:21:33 --> Model "user_model" initialized
INFO - 2021-07-05 10:21:33 --> Model "role_model" initialized
INFO - 2021-07-05 10:21:33 --> Controller Class Initialized
INFO - 2021-07-05 10:21:33 --> Helper loaded: language_helper
INFO - 2021-07-05 10:21:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:21:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 10:21:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 10:21:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 10:21:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:21:33 --> Final output sent to browser
DEBUG - 2021-07-05 10:21:33 --> Total execution time: 0.0891
INFO - 2021-07-05 10:21:34 --> Config Class Initialized
INFO - 2021-07-05 10:21:34 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:21:34 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:21:34 --> Utf8 Class Initialized
INFO - 2021-07-05 10:21:34 --> URI Class Initialized
DEBUG - 2021-07-05 10:21:34 --> No URI present. Default controller set.
INFO - 2021-07-05 10:21:34 --> Router Class Initialized
INFO - 2021-07-05 10:21:34 --> Output Class Initialized
INFO - 2021-07-05 10:21:34 --> Security Class Initialized
DEBUG - 2021-07-05 10:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:21:34 --> Input Class Initialized
INFO - 2021-07-05 10:21:34 --> Language Class Initialized
INFO - 2021-07-05 10:21:34 --> Loader Class Initialized
INFO - 2021-07-05 10:21:34 --> Helper loaded: html_helper
INFO - 2021-07-05 10:21:34 --> Helper loaded: url_helper
INFO - 2021-07-05 10:21:34 --> Helper loaded: form_helper
INFO - 2021-07-05 10:21:34 --> Database Driver Class Initialized
INFO - 2021-07-05 10:21:34 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:21:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:21:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:21:34 --> Encryption Class Initialized
INFO - 2021-07-05 10:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:21:34 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:21:34 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:21:34 --> Model "user_model" initialized
INFO - 2021-07-05 10:21:34 --> Model "role_model" initialized
INFO - 2021-07-05 10:21:34 --> Controller Class Initialized
INFO - 2021-07-05 10:21:34 --> Helper loaded: language_helper
INFO - 2021-07-05 10:21:34 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:21:34 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 10:21:34 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 10:21:34 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 10:21:34 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:21:34 --> Final output sent to browser
DEBUG - 2021-07-05 10:21:34 --> Total execution time: 0.0764
INFO - 2021-07-05 10:21:42 --> Config Class Initialized
INFO - 2021-07-05 10:21:42 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:21:42 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:21:42 --> Utf8 Class Initialized
INFO - 2021-07-05 10:21:42 --> URI Class Initialized
INFO - 2021-07-05 10:21:42 --> Router Class Initialized
INFO - 2021-07-05 10:21:42 --> Output Class Initialized
INFO - 2021-07-05 10:21:42 --> Security Class Initialized
DEBUG - 2021-07-05 10:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:21:42 --> Input Class Initialized
INFO - 2021-07-05 10:21:42 --> Language Class Initialized
INFO - 2021-07-05 10:21:42 --> Loader Class Initialized
INFO - 2021-07-05 10:21:42 --> Helper loaded: html_helper
INFO - 2021-07-05 10:21:42 --> Helper loaded: url_helper
INFO - 2021-07-05 10:21:42 --> Helper loaded: form_helper
INFO - 2021-07-05 10:21:42 --> Database Driver Class Initialized
INFO - 2021-07-05 10:21:43 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:21:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:21:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:21:43 --> Encryption Class Initialized
INFO - 2021-07-05 10:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:21:43 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:21:43 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:21:43 --> Model "user_model" initialized
INFO - 2021-07-05 10:21:43 --> Model "role_model" initialized
INFO - 2021-07-05 10:21:43 --> Controller Class Initialized
INFO - 2021-07-05 10:21:43 --> Helper loaded: language_helper
INFO - 2021-07-05 10:21:43 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:21:43 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:21:43 --> Model "Product_model" initialized
INFO - 2021-07-05 10:21:43 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:21:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:21:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:21:43 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:21:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:21:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:21:43 --> Final output sent to browser
DEBUG - 2021-07-05 10:21:43 --> Total execution time: 0.0855
INFO - 2021-07-05 10:21:49 --> Config Class Initialized
INFO - 2021-07-05 10:21:49 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:21:49 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:21:49 --> Utf8 Class Initialized
INFO - 2021-07-05 10:21:49 --> URI Class Initialized
INFO - 2021-07-05 10:21:49 --> Router Class Initialized
INFO - 2021-07-05 10:21:49 --> Output Class Initialized
INFO - 2021-07-05 10:21:49 --> Security Class Initialized
DEBUG - 2021-07-05 10:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:21:49 --> Input Class Initialized
INFO - 2021-07-05 10:21:49 --> Language Class Initialized
INFO - 2021-07-05 10:21:49 --> Loader Class Initialized
INFO - 2021-07-05 10:21:49 --> Helper loaded: html_helper
INFO - 2021-07-05 10:21:49 --> Helper loaded: url_helper
INFO - 2021-07-05 10:21:49 --> Helper loaded: form_helper
INFO - 2021-07-05 10:21:49 --> Database Driver Class Initialized
INFO - 2021-07-05 10:21:49 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:21:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:21:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:21:49 --> Encryption Class Initialized
INFO - 2021-07-05 10:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:21:49 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:21:49 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:21:49 --> Model "user_model" initialized
INFO - 2021-07-05 10:21:49 --> Model "role_model" initialized
INFO - 2021-07-05 10:21:49 --> Controller Class Initialized
INFO - 2021-07-05 10:21:49 --> Helper loaded: language_helper
INFO - 2021-07-05 10:21:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:21:49 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:21:49 --> Model "Product_model" initialized
INFO - 2021-07-05 10:21:49 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:21:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:21:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:21:49 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:21:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:21:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:21:49 --> Final output sent to browser
DEBUG - 2021-07-05 10:21:49 --> Total execution time: 0.0728
INFO - 2021-07-05 10:22:21 --> Config Class Initialized
INFO - 2021-07-05 10:22:21 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:22:21 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:22:21 --> Utf8 Class Initialized
INFO - 2021-07-05 10:22:21 --> URI Class Initialized
INFO - 2021-07-05 10:22:21 --> Router Class Initialized
INFO - 2021-07-05 10:22:21 --> Output Class Initialized
INFO - 2021-07-05 10:22:21 --> Security Class Initialized
DEBUG - 2021-07-05 10:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:22:21 --> Input Class Initialized
INFO - 2021-07-05 10:22:21 --> Language Class Initialized
INFO - 2021-07-05 10:22:21 --> Loader Class Initialized
INFO - 2021-07-05 10:22:21 --> Helper loaded: html_helper
INFO - 2021-07-05 10:22:21 --> Helper loaded: url_helper
INFO - 2021-07-05 10:22:21 --> Helper loaded: form_helper
INFO - 2021-07-05 10:22:21 --> Database Driver Class Initialized
INFO - 2021-07-05 10:22:21 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:22:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:22:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:22:21 --> Encryption Class Initialized
INFO - 2021-07-05 10:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:22:21 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:22:21 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:22:21 --> Model "user_model" initialized
INFO - 2021-07-05 10:22:21 --> Model "role_model" initialized
INFO - 2021-07-05 10:22:21 --> Controller Class Initialized
INFO - 2021-07-05 10:22:21 --> Helper loaded: language_helper
INFO - 2021-07-05 10:22:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:22:21 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:22:21 --> Model "Product_model" initialized
INFO - 2021-07-05 10:22:21 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:22:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:22:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:22:21 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:22:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:22:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:22:21 --> Final output sent to browser
DEBUG - 2021-07-05 10:22:21 --> Total execution time: 0.1121
INFO - 2021-07-05 10:22:32 --> Config Class Initialized
INFO - 2021-07-05 10:22:32 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:22:32 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:22:32 --> Utf8 Class Initialized
INFO - 2021-07-05 10:22:32 --> URI Class Initialized
INFO - 2021-07-05 10:22:32 --> Router Class Initialized
INFO - 2021-07-05 10:22:32 --> Output Class Initialized
INFO - 2021-07-05 10:22:32 --> Security Class Initialized
DEBUG - 2021-07-05 10:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:22:32 --> Input Class Initialized
INFO - 2021-07-05 10:22:32 --> Language Class Initialized
INFO - 2021-07-05 10:22:32 --> Loader Class Initialized
INFO - 2021-07-05 10:22:32 --> Helper loaded: html_helper
INFO - 2021-07-05 10:22:32 --> Helper loaded: url_helper
INFO - 2021-07-05 10:22:32 --> Helper loaded: form_helper
INFO - 2021-07-05 10:22:32 --> Database Driver Class Initialized
INFO - 2021-07-05 10:22:32 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:22:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:22:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:22:32 --> Encryption Class Initialized
INFO - 2021-07-05 10:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:22:32 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:22:32 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:22:32 --> Model "user_model" initialized
INFO - 2021-07-05 10:22:32 --> Model "role_model" initialized
INFO - 2021-07-05 10:22:32 --> Controller Class Initialized
INFO - 2021-07-05 10:22:32 --> Helper loaded: language_helper
INFO - 2021-07-05 10:22:32 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:22:32 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:22:32 --> Model "Product_model" initialized
INFO - 2021-07-05 10:22:32 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:22:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:22:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:22:32 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:22:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:22:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:22:32 --> Final output sent to browser
DEBUG - 2021-07-05 10:22:32 --> Total execution time: 0.0750
INFO - 2021-07-05 10:22:35 --> Config Class Initialized
INFO - 2021-07-05 10:22:35 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:22:35 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:22:35 --> Utf8 Class Initialized
INFO - 2021-07-05 10:22:35 --> URI Class Initialized
INFO - 2021-07-05 10:22:35 --> Router Class Initialized
INFO - 2021-07-05 10:22:35 --> Output Class Initialized
INFO - 2021-07-05 10:22:35 --> Security Class Initialized
DEBUG - 2021-07-05 10:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:22:35 --> Input Class Initialized
INFO - 2021-07-05 10:22:35 --> Language Class Initialized
INFO - 2021-07-05 10:22:35 --> Loader Class Initialized
INFO - 2021-07-05 10:22:35 --> Helper loaded: html_helper
INFO - 2021-07-05 10:22:35 --> Helper loaded: url_helper
INFO - 2021-07-05 10:22:35 --> Helper loaded: form_helper
INFO - 2021-07-05 10:22:35 --> Database Driver Class Initialized
INFO - 2021-07-05 10:22:35 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:22:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:22:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:22:35 --> Encryption Class Initialized
INFO - 2021-07-05 10:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:22:35 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:22:35 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:22:35 --> Model "user_model" initialized
INFO - 2021-07-05 10:22:35 --> Model "role_model" initialized
INFO - 2021-07-05 10:22:35 --> Controller Class Initialized
INFO - 2021-07-05 10:22:35 --> Helper loaded: language_helper
INFO - 2021-07-05 10:22:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:22:35 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:22:35 --> Model "Product_model" initialized
INFO - 2021-07-05 10:22:35 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:22:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:22:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:22:35 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:22:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:22:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:22:35 --> Final output sent to browser
DEBUG - 2021-07-05 10:22:35 --> Total execution time: 0.0999
INFO - 2021-07-05 10:22:39 --> Config Class Initialized
INFO - 2021-07-05 10:22:39 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:22:39 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:22:39 --> Utf8 Class Initialized
INFO - 2021-07-05 10:22:39 --> URI Class Initialized
DEBUG - 2021-07-05 10:22:39 --> No URI present. Default controller set.
INFO - 2021-07-05 10:22:39 --> Router Class Initialized
INFO - 2021-07-05 10:22:39 --> Output Class Initialized
INFO - 2021-07-05 10:22:39 --> Security Class Initialized
DEBUG - 2021-07-05 10:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:22:39 --> Input Class Initialized
INFO - 2021-07-05 10:22:39 --> Language Class Initialized
INFO - 2021-07-05 10:22:39 --> Loader Class Initialized
INFO - 2021-07-05 10:22:39 --> Helper loaded: html_helper
INFO - 2021-07-05 10:22:39 --> Helper loaded: url_helper
INFO - 2021-07-05 10:22:39 --> Helper loaded: form_helper
INFO - 2021-07-05 10:22:39 --> Database Driver Class Initialized
INFO - 2021-07-05 10:22:39 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:22:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:22:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:22:39 --> Encryption Class Initialized
INFO - 2021-07-05 10:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:22:39 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:22:39 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:22:39 --> Model "user_model" initialized
INFO - 2021-07-05 10:22:39 --> Model "role_model" initialized
INFO - 2021-07-05 10:22:39 --> Controller Class Initialized
INFO - 2021-07-05 10:22:39 --> Helper loaded: language_helper
INFO - 2021-07-05 10:22:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:22:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 10:22:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 10:22:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 10:22:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:22:39 --> Final output sent to browser
DEBUG - 2021-07-05 10:22:39 --> Total execution time: 0.0729
INFO - 2021-07-05 10:24:18 --> Config Class Initialized
INFO - 2021-07-05 10:24:18 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:24:18 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:24:18 --> Utf8 Class Initialized
INFO - 2021-07-05 10:24:18 --> URI Class Initialized
DEBUG - 2021-07-05 10:24:18 --> No URI present. Default controller set.
INFO - 2021-07-05 10:24:18 --> Router Class Initialized
INFO - 2021-07-05 10:24:18 --> Output Class Initialized
INFO - 2021-07-05 10:24:18 --> Security Class Initialized
DEBUG - 2021-07-05 10:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:24:18 --> Input Class Initialized
INFO - 2021-07-05 10:24:18 --> Language Class Initialized
INFO - 2021-07-05 10:24:18 --> Loader Class Initialized
INFO - 2021-07-05 10:24:18 --> Helper loaded: html_helper
INFO - 2021-07-05 10:24:18 --> Helper loaded: url_helper
INFO - 2021-07-05 10:24:18 --> Helper loaded: form_helper
INFO - 2021-07-05 10:24:18 --> Database Driver Class Initialized
INFO - 2021-07-05 10:24:18 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:24:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:24:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:24:18 --> Encryption Class Initialized
INFO - 2021-07-05 10:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:24:18 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:24:18 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:24:18 --> Model "user_model" initialized
INFO - 2021-07-05 10:24:18 --> Model "role_model" initialized
INFO - 2021-07-05 10:24:18 --> Controller Class Initialized
INFO - 2021-07-05 10:24:18 --> Helper loaded: language_helper
INFO - 2021-07-05 10:24:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:24:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 10:24:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 10:24:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 10:24:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:24:18 --> Final output sent to browser
DEBUG - 2021-07-05 10:24:18 --> Total execution time: 0.0683
INFO - 2021-07-05 10:24:31 --> Config Class Initialized
INFO - 2021-07-05 10:24:31 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:24:32 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:24:32 --> Utf8 Class Initialized
INFO - 2021-07-05 10:24:32 --> URI Class Initialized
DEBUG - 2021-07-05 10:24:32 --> No URI present. Default controller set.
INFO - 2021-07-05 10:24:32 --> Router Class Initialized
INFO - 2021-07-05 10:24:32 --> Output Class Initialized
INFO - 2021-07-05 10:24:32 --> Security Class Initialized
DEBUG - 2021-07-05 10:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:24:32 --> Input Class Initialized
INFO - 2021-07-05 10:24:32 --> Language Class Initialized
INFO - 2021-07-05 10:24:32 --> Loader Class Initialized
INFO - 2021-07-05 10:24:32 --> Helper loaded: html_helper
INFO - 2021-07-05 10:24:32 --> Helper loaded: url_helper
INFO - 2021-07-05 10:24:32 --> Helper loaded: form_helper
INFO - 2021-07-05 10:24:32 --> Database Driver Class Initialized
INFO - 2021-07-05 10:24:32 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:24:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:24:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:24:32 --> Encryption Class Initialized
INFO - 2021-07-05 10:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:24:32 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:24:32 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:24:32 --> Model "user_model" initialized
INFO - 2021-07-05 10:24:32 --> Model "role_model" initialized
INFO - 2021-07-05 10:24:32 --> Controller Class Initialized
INFO - 2021-07-05 10:24:32 --> Helper loaded: language_helper
INFO - 2021-07-05 10:24:32 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:24:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 10:24:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 10:24:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 10:24:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:24:32 --> Final output sent to browser
DEBUG - 2021-07-05 10:24:32 --> Total execution time: 0.0659
INFO - 2021-07-05 10:24:41 --> Config Class Initialized
INFO - 2021-07-05 10:24:41 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:24:41 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:24:41 --> Utf8 Class Initialized
INFO - 2021-07-05 10:24:41 --> URI Class Initialized
INFO - 2021-07-05 10:24:41 --> Router Class Initialized
INFO - 2021-07-05 10:24:41 --> Output Class Initialized
INFO - 2021-07-05 10:24:41 --> Security Class Initialized
DEBUG - 2021-07-05 10:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:24:41 --> Input Class Initialized
INFO - 2021-07-05 10:24:41 --> Language Class Initialized
INFO - 2021-07-05 10:24:41 --> Loader Class Initialized
INFO - 2021-07-05 10:24:41 --> Helper loaded: html_helper
INFO - 2021-07-05 10:24:41 --> Helper loaded: url_helper
INFO - 2021-07-05 10:24:41 --> Helper loaded: form_helper
INFO - 2021-07-05 10:24:41 --> Database Driver Class Initialized
INFO - 2021-07-05 10:24:41 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:24:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:24:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:24:41 --> Encryption Class Initialized
INFO - 2021-07-05 10:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:24:41 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:24:41 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:24:41 --> Model "user_model" initialized
INFO - 2021-07-05 10:24:41 --> Model "role_model" initialized
INFO - 2021-07-05 10:24:41 --> Controller Class Initialized
INFO - 2021-07-05 10:24:41 --> Helper loaded: language_helper
INFO - 2021-07-05 10:24:41 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:24:41 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:24:41 --> Model "Product_model" initialized
INFO - 2021-07-05 10:24:41 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:24:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:24:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:24:41 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:24:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:24:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:24:41 --> Final output sent to browser
DEBUG - 2021-07-05 10:24:41 --> Total execution time: 0.1179
INFO - 2021-07-05 10:28:09 --> Config Class Initialized
INFO - 2021-07-05 10:28:09 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:28:09 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:28:09 --> Utf8 Class Initialized
INFO - 2021-07-05 10:28:09 --> URI Class Initialized
INFO - 2021-07-05 10:28:09 --> Router Class Initialized
INFO - 2021-07-05 10:28:09 --> Output Class Initialized
INFO - 2021-07-05 10:28:09 --> Security Class Initialized
DEBUG - 2021-07-05 10:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:28:09 --> Input Class Initialized
INFO - 2021-07-05 10:28:09 --> Language Class Initialized
INFO - 2021-07-05 10:28:09 --> Loader Class Initialized
INFO - 2021-07-05 10:28:09 --> Helper loaded: html_helper
INFO - 2021-07-05 10:28:09 --> Helper loaded: url_helper
INFO - 2021-07-05 10:28:09 --> Helper loaded: form_helper
INFO - 2021-07-05 10:28:09 --> Database Driver Class Initialized
INFO - 2021-07-05 10:28:09 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:28:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:28:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:28:09 --> Encryption Class Initialized
INFO - 2021-07-05 10:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:28:09 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:28:09 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:28:09 --> Model "user_model" initialized
INFO - 2021-07-05 10:28:09 --> Model "role_model" initialized
INFO - 2021-07-05 10:28:09 --> Controller Class Initialized
INFO - 2021-07-05 10:28:09 --> Helper loaded: language_helper
INFO - 2021-07-05 10:28:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:28:09 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:28:09 --> Model "Product_model" initialized
INFO - 2021-07-05 10:28:09 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:28:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:28:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:28:09 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:28:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:28:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:28:09 --> Final output sent to browser
DEBUG - 2021-07-05 10:28:09 --> Total execution time: 0.1185
INFO - 2021-07-05 10:28:22 --> Config Class Initialized
INFO - 2021-07-05 10:28:22 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:28:22 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:28:22 --> Utf8 Class Initialized
INFO - 2021-07-05 10:28:22 --> URI Class Initialized
INFO - 2021-07-05 10:28:22 --> Router Class Initialized
INFO - 2021-07-05 10:28:22 --> Output Class Initialized
INFO - 2021-07-05 10:28:22 --> Security Class Initialized
DEBUG - 2021-07-05 10:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:28:22 --> Input Class Initialized
INFO - 2021-07-05 10:28:22 --> Language Class Initialized
INFO - 2021-07-05 10:28:23 --> Loader Class Initialized
INFO - 2021-07-05 10:28:23 --> Helper loaded: html_helper
INFO - 2021-07-05 10:28:23 --> Helper loaded: url_helper
INFO - 2021-07-05 10:28:23 --> Helper loaded: form_helper
INFO - 2021-07-05 10:28:23 --> Database Driver Class Initialized
INFO - 2021-07-05 10:28:23 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:28:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:28:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:28:23 --> Encryption Class Initialized
INFO - 2021-07-05 10:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:28:23 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:28:23 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:28:23 --> Model "user_model" initialized
INFO - 2021-07-05 10:28:23 --> Model "role_model" initialized
INFO - 2021-07-05 10:28:23 --> Controller Class Initialized
INFO - 2021-07-05 10:28:23 --> Helper loaded: language_helper
INFO - 2021-07-05 10:28:23 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:28:23 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:28:23 --> Model "Product_model" initialized
INFO - 2021-07-05 10:28:23 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:28:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:28:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:28:23 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:28:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:28:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:28:23 --> Final output sent to browser
DEBUG - 2021-07-05 10:28:23 --> Total execution time: 0.0725
INFO - 2021-07-05 10:30:49 --> Config Class Initialized
INFO - 2021-07-05 10:30:49 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:30:49 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:30:49 --> Utf8 Class Initialized
INFO - 2021-07-05 10:30:49 --> URI Class Initialized
INFO - 2021-07-05 10:30:49 --> Router Class Initialized
INFO - 2021-07-05 10:30:49 --> Output Class Initialized
INFO - 2021-07-05 10:30:49 --> Security Class Initialized
DEBUG - 2021-07-05 10:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:30:49 --> Input Class Initialized
INFO - 2021-07-05 10:30:49 --> Language Class Initialized
INFO - 2021-07-05 10:30:49 --> Loader Class Initialized
INFO - 2021-07-05 10:30:49 --> Helper loaded: html_helper
INFO - 2021-07-05 10:30:49 --> Helper loaded: url_helper
INFO - 2021-07-05 10:30:49 --> Helper loaded: form_helper
INFO - 2021-07-05 10:30:49 --> Database Driver Class Initialized
INFO - 2021-07-05 10:30:49 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:30:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:30:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:30:49 --> Encryption Class Initialized
INFO - 2021-07-05 10:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:30:49 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:30:49 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:30:49 --> Model "user_model" initialized
INFO - 2021-07-05 10:30:49 --> Model "role_model" initialized
INFO - 2021-07-05 10:30:49 --> Controller Class Initialized
INFO - 2021-07-05 10:30:49 --> Helper loaded: language_helper
INFO - 2021-07-05 10:30:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:30:49 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:30:49 --> Model "Product_model" initialized
INFO - 2021-07-05 10:30:49 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:30:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:30:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:30:49 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:30:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:30:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:30:49 --> Final output sent to browser
DEBUG - 2021-07-05 10:30:49 --> Total execution time: 0.1141
INFO - 2021-07-05 10:31:06 --> Config Class Initialized
INFO - 2021-07-05 10:31:06 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:31:06 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:31:06 --> Utf8 Class Initialized
INFO - 2021-07-05 10:31:06 --> URI Class Initialized
INFO - 2021-07-05 10:31:06 --> Router Class Initialized
INFO - 2021-07-05 10:31:06 --> Output Class Initialized
INFO - 2021-07-05 10:31:06 --> Security Class Initialized
DEBUG - 2021-07-05 10:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:31:06 --> Input Class Initialized
INFO - 2021-07-05 10:31:06 --> Language Class Initialized
INFO - 2021-07-05 10:31:06 --> Loader Class Initialized
INFO - 2021-07-05 10:31:06 --> Helper loaded: html_helper
INFO - 2021-07-05 10:31:06 --> Helper loaded: url_helper
INFO - 2021-07-05 10:31:06 --> Helper loaded: form_helper
INFO - 2021-07-05 10:31:06 --> Database Driver Class Initialized
INFO - 2021-07-05 10:31:06 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:31:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:31:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:31:06 --> Encryption Class Initialized
INFO - 2021-07-05 10:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:31:06 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:31:06 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:31:06 --> Model "user_model" initialized
INFO - 2021-07-05 10:31:06 --> Model "role_model" initialized
INFO - 2021-07-05 10:31:06 --> Controller Class Initialized
INFO - 2021-07-05 10:31:06 --> Helper loaded: language_helper
INFO - 2021-07-05 10:31:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:31:06 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:31:06 --> Model "Product_model" initialized
INFO - 2021-07-05 10:31:06 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:31:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:31:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:31:06 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:31:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:31:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:31:06 --> Final output sent to browser
DEBUG - 2021-07-05 10:31:06 --> Total execution time: 0.0747
INFO - 2021-07-05 10:33:49 --> Config Class Initialized
INFO - 2021-07-05 10:33:49 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:33:49 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:33:49 --> Utf8 Class Initialized
INFO - 2021-07-05 10:33:49 --> URI Class Initialized
INFO - 2021-07-05 10:33:49 --> Router Class Initialized
INFO - 2021-07-05 10:33:49 --> Output Class Initialized
INFO - 2021-07-05 10:33:49 --> Security Class Initialized
DEBUG - 2021-07-05 10:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:33:49 --> Input Class Initialized
INFO - 2021-07-05 10:33:49 --> Language Class Initialized
INFO - 2021-07-05 10:33:49 --> Loader Class Initialized
INFO - 2021-07-05 10:33:49 --> Helper loaded: html_helper
INFO - 2021-07-05 10:33:49 --> Helper loaded: url_helper
INFO - 2021-07-05 10:33:49 --> Helper loaded: form_helper
INFO - 2021-07-05 10:33:49 --> Database Driver Class Initialized
INFO - 2021-07-05 10:33:49 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:33:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:33:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:33:49 --> Encryption Class Initialized
INFO - 2021-07-05 10:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:33:49 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:33:49 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:33:49 --> Model "user_model" initialized
INFO - 2021-07-05 10:33:49 --> Model "role_model" initialized
INFO - 2021-07-05 10:33:49 --> Controller Class Initialized
INFO - 2021-07-05 10:33:49 --> Helper loaded: language_helper
INFO - 2021-07-05 10:33:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:33:49 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:33:49 --> Model "Product_model" initialized
INFO - 2021-07-05 10:33:49 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:33:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:33:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:33:49 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:33:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:33:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:33:49 --> Final output sent to browser
DEBUG - 2021-07-05 10:33:49 --> Total execution time: 0.1145
INFO - 2021-07-05 10:33:58 --> Config Class Initialized
INFO - 2021-07-05 10:33:58 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:33:58 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:33:58 --> Utf8 Class Initialized
INFO - 2021-07-05 10:33:58 --> URI Class Initialized
INFO - 2021-07-05 10:33:58 --> Router Class Initialized
INFO - 2021-07-05 10:33:58 --> Output Class Initialized
INFO - 2021-07-05 10:33:58 --> Security Class Initialized
DEBUG - 2021-07-05 10:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:33:58 --> Input Class Initialized
INFO - 2021-07-05 10:33:58 --> Language Class Initialized
INFO - 2021-07-05 10:33:58 --> Loader Class Initialized
INFO - 2021-07-05 10:33:58 --> Helper loaded: html_helper
INFO - 2021-07-05 10:33:58 --> Helper loaded: url_helper
INFO - 2021-07-05 10:33:58 --> Helper loaded: form_helper
INFO - 2021-07-05 10:33:58 --> Database Driver Class Initialized
INFO - 2021-07-05 10:33:58 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:33:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:33:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:33:58 --> Encryption Class Initialized
INFO - 2021-07-05 10:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:33:58 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:33:58 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:33:58 --> Model "user_model" initialized
INFO - 2021-07-05 10:33:58 --> Model "role_model" initialized
INFO - 2021-07-05 10:33:58 --> Controller Class Initialized
INFO - 2021-07-05 10:33:58 --> Helper loaded: language_helper
INFO - 2021-07-05 10:33:58 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:33:58 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:33:58 --> Model "Product_model" initialized
INFO - 2021-07-05 10:33:58 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:33:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:33:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:33:58 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:33:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:33:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:33:58 --> Final output sent to browser
DEBUG - 2021-07-05 10:33:58 --> Total execution time: 0.1244
INFO - 2021-07-05 10:34:04 --> Config Class Initialized
INFO - 2021-07-05 10:34:04 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:34:04 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:34:04 --> Utf8 Class Initialized
INFO - 2021-07-05 10:34:04 --> URI Class Initialized
DEBUG - 2021-07-05 10:34:04 --> No URI present. Default controller set.
INFO - 2021-07-05 10:34:04 --> Router Class Initialized
INFO - 2021-07-05 10:34:04 --> Output Class Initialized
INFO - 2021-07-05 10:34:04 --> Security Class Initialized
DEBUG - 2021-07-05 10:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:34:04 --> Input Class Initialized
INFO - 2021-07-05 10:34:04 --> Language Class Initialized
INFO - 2021-07-05 10:34:04 --> Loader Class Initialized
INFO - 2021-07-05 10:34:04 --> Helper loaded: html_helper
INFO - 2021-07-05 10:34:04 --> Helper loaded: url_helper
INFO - 2021-07-05 10:34:04 --> Helper loaded: form_helper
INFO - 2021-07-05 10:34:04 --> Database Driver Class Initialized
INFO - 2021-07-05 10:34:04 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:34:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:34:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:34:04 --> Encryption Class Initialized
INFO - 2021-07-05 10:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:34:04 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:34:04 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:34:04 --> Model "user_model" initialized
INFO - 2021-07-05 10:34:04 --> Model "role_model" initialized
INFO - 2021-07-05 10:34:04 --> Controller Class Initialized
INFO - 2021-07-05 10:34:04 --> Helper loaded: language_helper
INFO - 2021-07-05 10:34:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:34:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 10:34:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 10:34:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 10:34:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:34:04 --> Final output sent to browser
DEBUG - 2021-07-05 10:34:04 --> Total execution time: 0.0944
INFO - 2021-07-05 10:34:20 --> Config Class Initialized
INFO - 2021-07-05 10:34:20 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:34:20 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:34:20 --> Utf8 Class Initialized
INFO - 2021-07-05 10:34:20 --> URI Class Initialized
DEBUG - 2021-07-05 10:34:20 --> No URI present. Default controller set.
INFO - 2021-07-05 10:34:20 --> Router Class Initialized
INFO - 2021-07-05 10:34:20 --> Output Class Initialized
INFO - 2021-07-05 10:34:20 --> Security Class Initialized
DEBUG - 2021-07-05 10:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:34:20 --> Input Class Initialized
INFO - 2021-07-05 10:34:20 --> Language Class Initialized
INFO - 2021-07-05 10:34:20 --> Loader Class Initialized
INFO - 2021-07-05 10:34:20 --> Helper loaded: html_helper
INFO - 2021-07-05 10:34:20 --> Helper loaded: url_helper
INFO - 2021-07-05 10:34:20 --> Helper loaded: form_helper
INFO - 2021-07-05 10:34:20 --> Database Driver Class Initialized
INFO - 2021-07-05 10:34:20 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:34:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:34:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:34:20 --> Encryption Class Initialized
INFO - 2021-07-05 10:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:34:20 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:34:20 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:34:20 --> Model "user_model" initialized
INFO - 2021-07-05 10:34:20 --> Model "role_model" initialized
INFO - 2021-07-05 10:34:20 --> Controller Class Initialized
INFO - 2021-07-05 10:34:20 --> Helper loaded: language_helper
INFO - 2021-07-05 10:34:20 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:34:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 10:34:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 10:34:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 10:34:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:34:20 --> Final output sent to browser
DEBUG - 2021-07-05 10:34:20 --> Total execution time: 0.0690
INFO - 2021-07-05 10:34:32 --> Config Class Initialized
INFO - 2021-07-05 10:34:32 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:34:32 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:34:32 --> Utf8 Class Initialized
INFO - 2021-07-05 10:34:32 --> URI Class Initialized
INFO - 2021-07-05 10:34:32 --> Router Class Initialized
INFO - 2021-07-05 10:34:32 --> Output Class Initialized
INFO - 2021-07-05 10:34:32 --> Security Class Initialized
DEBUG - 2021-07-05 10:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:34:32 --> Input Class Initialized
INFO - 2021-07-05 10:34:32 --> Language Class Initialized
INFO - 2021-07-05 10:34:32 --> Loader Class Initialized
INFO - 2021-07-05 10:34:32 --> Helper loaded: html_helper
INFO - 2021-07-05 10:34:32 --> Helper loaded: url_helper
INFO - 2021-07-05 10:34:32 --> Helper loaded: form_helper
INFO - 2021-07-05 10:34:32 --> Database Driver Class Initialized
INFO - 2021-07-05 10:34:32 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:34:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:34:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:34:32 --> Encryption Class Initialized
INFO - 2021-07-05 10:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:34:32 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:34:32 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:34:32 --> Model "user_model" initialized
INFO - 2021-07-05 10:34:32 --> Model "role_model" initialized
INFO - 2021-07-05 10:34:32 --> Controller Class Initialized
INFO - 2021-07-05 10:34:32 --> Helper loaded: language_helper
INFO - 2021-07-05 10:34:32 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:34:32 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:34:32 --> Model "Product_model" initialized
INFO - 2021-07-05 10:34:32 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:34:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:34:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:34:32 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:34:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:34:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:34:32 --> Final output sent to browser
DEBUG - 2021-07-05 10:34:32 --> Total execution time: 0.0753
INFO - 2021-07-05 10:34:50 --> Config Class Initialized
INFO - 2021-07-05 10:34:50 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:34:50 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:34:50 --> Utf8 Class Initialized
INFO - 2021-07-05 10:34:50 --> URI Class Initialized
INFO - 2021-07-05 10:34:50 --> Router Class Initialized
INFO - 2021-07-05 10:34:50 --> Output Class Initialized
INFO - 2021-07-05 10:34:50 --> Security Class Initialized
DEBUG - 2021-07-05 10:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:34:50 --> Input Class Initialized
INFO - 2021-07-05 10:34:50 --> Language Class Initialized
INFO - 2021-07-05 10:34:50 --> Loader Class Initialized
INFO - 2021-07-05 10:34:50 --> Helper loaded: html_helper
INFO - 2021-07-05 10:34:50 --> Helper loaded: url_helper
INFO - 2021-07-05 10:34:50 --> Helper loaded: form_helper
INFO - 2021-07-05 10:34:50 --> Database Driver Class Initialized
INFO - 2021-07-05 10:34:50 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:34:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:34:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:34:50 --> Encryption Class Initialized
INFO - 2021-07-05 10:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:34:50 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:34:50 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:34:50 --> Model "user_model" initialized
INFO - 2021-07-05 10:34:50 --> Model "role_model" initialized
INFO - 2021-07-05 10:34:50 --> Controller Class Initialized
INFO - 2021-07-05 10:34:50 --> Helper loaded: language_helper
INFO - 2021-07-05 10:34:50 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:34:50 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:34:50 --> Model "Product_model" initialized
INFO - 2021-07-05 10:34:50 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:34:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:34:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:34:50 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:34:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:34:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:34:50 --> Final output sent to browser
DEBUG - 2021-07-05 10:34:50 --> Total execution time: 0.0791
INFO - 2021-07-05 10:35:16 --> Config Class Initialized
INFO - 2021-07-05 10:35:16 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:35:16 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:35:16 --> Utf8 Class Initialized
INFO - 2021-07-05 10:35:16 --> URI Class Initialized
INFO - 2021-07-05 10:35:16 --> Router Class Initialized
INFO - 2021-07-05 10:35:16 --> Output Class Initialized
INFO - 2021-07-05 10:35:16 --> Security Class Initialized
DEBUG - 2021-07-05 10:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:35:16 --> Input Class Initialized
INFO - 2021-07-05 10:35:16 --> Language Class Initialized
INFO - 2021-07-05 10:35:16 --> Loader Class Initialized
INFO - 2021-07-05 10:35:16 --> Helper loaded: html_helper
INFO - 2021-07-05 10:35:16 --> Helper loaded: url_helper
INFO - 2021-07-05 10:35:16 --> Helper loaded: form_helper
INFO - 2021-07-05 10:35:16 --> Database Driver Class Initialized
INFO - 2021-07-05 10:35:16 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:35:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:35:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:35:16 --> Encryption Class Initialized
INFO - 2021-07-05 10:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:35:16 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:35:16 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:35:16 --> Model "user_model" initialized
INFO - 2021-07-05 10:35:16 --> Model "role_model" initialized
INFO - 2021-07-05 10:35:16 --> Controller Class Initialized
INFO - 2021-07-05 10:35:16 --> Helper loaded: language_helper
INFO - 2021-07-05 10:35:16 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:35:16 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:35:16 --> Model "Product_model" initialized
INFO - 2021-07-05 10:35:16 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:35:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:35:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:35:16 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:35:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:35:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:35:16 --> Final output sent to browser
DEBUG - 2021-07-05 10:35:16 --> Total execution time: 0.0771
INFO - 2021-07-05 10:36:45 --> Config Class Initialized
INFO - 2021-07-05 10:36:45 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:36:45 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:36:45 --> Utf8 Class Initialized
INFO - 2021-07-05 10:36:45 --> URI Class Initialized
INFO - 2021-07-05 10:36:45 --> Router Class Initialized
INFO - 2021-07-05 10:36:45 --> Output Class Initialized
INFO - 2021-07-05 10:36:45 --> Security Class Initialized
DEBUG - 2021-07-05 10:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:36:45 --> Input Class Initialized
INFO - 2021-07-05 10:36:45 --> Language Class Initialized
INFO - 2021-07-05 10:36:45 --> Loader Class Initialized
INFO - 2021-07-05 10:36:45 --> Helper loaded: html_helper
INFO - 2021-07-05 10:36:45 --> Helper loaded: url_helper
INFO - 2021-07-05 10:36:45 --> Helper loaded: form_helper
INFO - 2021-07-05 10:36:45 --> Database Driver Class Initialized
INFO - 2021-07-05 10:36:45 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:36:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:36:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:36:45 --> Encryption Class Initialized
INFO - 2021-07-05 10:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:36:45 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:36:45 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:36:45 --> Model "user_model" initialized
INFO - 2021-07-05 10:36:45 --> Model "role_model" initialized
INFO - 2021-07-05 10:36:45 --> Controller Class Initialized
INFO - 2021-07-05 10:36:45 --> Helper loaded: language_helper
INFO - 2021-07-05 10:36:45 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:36:46 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:36:46 --> Model "Product_model" initialized
INFO - 2021-07-05 10:36:46 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:36:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:36:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:36:46 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:36:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:36:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:36:46 --> Final output sent to browser
DEBUG - 2021-07-05 10:36:46 --> Total execution time: 0.0754
INFO - 2021-07-05 10:38:55 --> Config Class Initialized
INFO - 2021-07-05 10:38:55 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:38:55 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:38:55 --> Utf8 Class Initialized
INFO - 2021-07-05 10:38:55 --> URI Class Initialized
INFO - 2021-07-05 10:38:55 --> Router Class Initialized
INFO - 2021-07-05 10:38:55 --> Output Class Initialized
INFO - 2021-07-05 10:38:55 --> Security Class Initialized
DEBUG - 2021-07-05 10:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:38:55 --> Input Class Initialized
INFO - 2021-07-05 10:38:55 --> Language Class Initialized
INFO - 2021-07-05 10:38:55 --> Loader Class Initialized
INFO - 2021-07-05 10:38:55 --> Helper loaded: html_helper
INFO - 2021-07-05 10:38:55 --> Helper loaded: url_helper
INFO - 2021-07-05 10:38:55 --> Helper loaded: form_helper
INFO - 2021-07-05 10:38:55 --> Database Driver Class Initialized
INFO - 2021-07-05 10:38:55 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:38:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:38:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:38:55 --> Encryption Class Initialized
INFO - 2021-07-05 10:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:38:55 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:38:55 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:38:55 --> Model "user_model" initialized
INFO - 2021-07-05 10:38:55 --> Model "role_model" initialized
INFO - 2021-07-05 10:38:55 --> Controller Class Initialized
INFO - 2021-07-05 10:38:55 --> Helper loaded: language_helper
INFO - 2021-07-05 10:38:55 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:38:55 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:38:55 --> Model "Product_model" initialized
INFO - 2021-07-05 10:38:55 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:38:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:38:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:38:55 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:38:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:38:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:38:55 --> Final output sent to browser
DEBUG - 2021-07-05 10:38:55 --> Total execution time: 0.0773
INFO - 2021-07-05 10:40:07 --> Config Class Initialized
INFO - 2021-07-05 10:40:07 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:40:07 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:40:07 --> Utf8 Class Initialized
INFO - 2021-07-05 10:40:07 --> URI Class Initialized
INFO - 2021-07-05 10:40:07 --> Router Class Initialized
INFO - 2021-07-05 10:40:07 --> Output Class Initialized
INFO - 2021-07-05 10:40:07 --> Security Class Initialized
DEBUG - 2021-07-05 10:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:40:07 --> Input Class Initialized
INFO - 2021-07-05 10:40:07 --> Language Class Initialized
INFO - 2021-07-05 10:40:07 --> Loader Class Initialized
INFO - 2021-07-05 10:40:07 --> Helper loaded: html_helper
INFO - 2021-07-05 10:40:07 --> Helper loaded: url_helper
INFO - 2021-07-05 10:40:07 --> Helper loaded: form_helper
INFO - 2021-07-05 10:40:07 --> Database Driver Class Initialized
INFO - 2021-07-05 10:40:07 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:40:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:40:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:40:07 --> Encryption Class Initialized
INFO - 2021-07-05 10:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:40:07 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:40:07 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:40:07 --> Model "user_model" initialized
INFO - 2021-07-05 10:40:07 --> Model "role_model" initialized
INFO - 2021-07-05 10:40:07 --> Controller Class Initialized
INFO - 2021-07-05 10:40:07 --> Helper loaded: language_helper
INFO - 2021-07-05 10:40:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:40:07 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:40:07 --> Model "Product_model" initialized
INFO - 2021-07-05 10:40:07 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:40:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:40:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:40:07 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:40:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:40:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:40:07 --> Final output sent to browser
DEBUG - 2021-07-05 10:40:07 --> Total execution time: 0.1111
INFO - 2021-07-05 10:40:21 --> Config Class Initialized
INFO - 2021-07-05 10:40:21 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:40:21 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:40:21 --> Utf8 Class Initialized
INFO - 2021-07-05 10:40:21 --> URI Class Initialized
INFO - 2021-07-05 10:40:21 --> Router Class Initialized
INFO - 2021-07-05 10:40:21 --> Output Class Initialized
INFO - 2021-07-05 10:40:21 --> Security Class Initialized
DEBUG - 2021-07-05 10:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:40:21 --> Input Class Initialized
INFO - 2021-07-05 10:40:21 --> Language Class Initialized
INFO - 2021-07-05 10:40:21 --> Loader Class Initialized
INFO - 2021-07-05 10:40:21 --> Helper loaded: html_helper
INFO - 2021-07-05 10:40:21 --> Helper loaded: url_helper
INFO - 2021-07-05 10:40:21 --> Helper loaded: form_helper
INFO - 2021-07-05 10:40:21 --> Database Driver Class Initialized
INFO - 2021-07-05 10:40:21 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:40:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:40:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:40:21 --> Encryption Class Initialized
INFO - 2021-07-05 10:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:40:21 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:40:21 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:40:21 --> Model "user_model" initialized
INFO - 2021-07-05 10:40:21 --> Model "role_model" initialized
INFO - 2021-07-05 10:40:21 --> Controller Class Initialized
INFO - 2021-07-05 10:40:21 --> Helper loaded: language_helper
INFO - 2021-07-05 10:40:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:40:21 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:40:21 --> Model "Product_model" initialized
INFO - 2021-07-05 10:40:21 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:40:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:40:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:40:21 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:40:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:40:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:40:21 --> Final output sent to browser
DEBUG - 2021-07-05 10:40:21 --> Total execution time: 0.1007
INFO - 2021-07-05 10:40:21 --> Config Class Initialized
INFO - 2021-07-05 10:40:21 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:40:22 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:40:22 --> Utf8 Class Initialized
INFO - 2021-07-05 10:40:22 --> URI Class Initialized
DEBUG - 2021-07-05 10:40:22 --> No URI present. Default controller set.
INFO - 2021-07-05 10:40:22 --> Router Class Initialized
INFO - 2021-07-05 10:40:22 --> Output Class Initialized
INFO - 2021-07-05 10:40:22 --> Security Class Initialized
DEBUG - 2021-07-05 10:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:40:22 --> Input Class Initialized
INFO - 2021-07-05 10:40:22 --> Language Class Initialized
INFO - 2021-07-05 10:40:22 --> Loader Class Initialized
INFO - 2021-07-05 10:40:22 --> Helper loaded: html_helper
INFO - 2021-07-05 10:40:22 --> Helper loaded: url_helper
INFO - 2021-07-05 10:40:22 --> Helper loaded: form_helper
INFO - 2021-07-05 10:40:22 --> Database Driver Class Initialized
INFO - 2021-07-05 10:40:22 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:40:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:40:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:40:22 --> Encryption Class Initialized
INFO - 2021-07-05 10:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:40:22 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:40:22 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:40:22 --> Model "user_model" initialized
INFO - 2021-07-05 10:40:22 --> Model "role_model" initialized
INFO - 2021-07-05 10:40:22 --> Controller Class Initialized
INFO - 2021-07-05 10:40:22 --> Helper loaded: language_helper
INFO - 2021-07-05 10:40:22 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:40:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 10:40:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 10:40:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 10:40:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:40:22 --> Final output sent to browser
DEBUG - 2021-07-05 10:40:22 --> Total execution time: 0.1377
INFO - 2021-07-05 10:40:42 --> Config Class Initialized
INFO - 2021-07-05 10:40:42 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:40:42 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:40:42 --> Utf8 Class Initialized
INFO - 2021-07-05 10:40:42 --> URI Class Initialized
INFO - 2021-07-05 10:40:42 --> Router Class Initialized
INFO - 2021-07-05 10:40:42 --> Output Class Initialized
INFO - 2021-07-05 10:40:42 --> Security Class Initialized
DEBUG - 2021-07-05 10:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:40:42 --> Input Class Initialized
INFO - 2021-07-05 10:40:42 --> Language Class Initialized
INFO - 2021-07-05 10:40:42 --> Loader Class Initialized
INFO - 2021-07-05 10:40:42 --> Helper loaded: html_helper
INFO - 2021-07-05 10:40:42 --> Helper loaded: url_helper
INFO - 2021-07-05 10:40:42 --> Helper loaded: form_helper
INFO - 2021-07-05 10:40:42 --> Database Driver Class Initialized
INFO - 2021-07-05 10:40:42 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:40:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:40:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:40:42 --> Encryption Class Initialized
INFO - 2021-07-05 10:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:40:42 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:40:42 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:40:42 --> Model "user_model" initialized
INFO - 2021-07-05 10:40:42 --> Model "role_model" initialized
INFO - 2021-07-05 10:40:42 --> Controller Class Initialized
INFO - 2021-07-05 10:40:42 --> Helper loaded: language_helper
INFO - 2021-07-05 10:40:42 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:40:42 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:40:42 --> Model "Product_model" initialized
INFO - 2021-07-05 10:40:42 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:40:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:40:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:40:42 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:40:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:40:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:40:42 --> Final output sent to browser
DEBUG - 2021-07-05 10:40:42 --> Total execution time: 0.0752
INFO - 2021-07-05 10:41:04 --> Config Class Initialized
INFO - 2021-07-05 10:41:04 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:41:04 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:41:04 --> Utf8 Class Initialized
INFO - 2021-07-05 10:41:04 --> URI Class Initialized
INFO - 2021-07-05 10:41:04 --> Router Class Initialized
INFO - 2021-07-05 10:41:04 --> Output Class Initialized
INFO - 2021-07-05 10:41:04 --> Security Class Initialized
DEBUG - 2021-07-05 10:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:41:04 --> Input Class Initialized
INFO - 2021-07-05 10:41:04 --> Language Class Initialized
INFO - 2021-07-05 10:41:04 --> Loader Class Initialized
INFO - 2021-07-05 10:41:04 --> Helper loaded: html_helper
INFO - 2021-07-05 10:41:04 --> Helper loaded: url_helper
INFO - 2021-07-05 10:41:04 --> Helper loaded: form_helper
INFO - 2021-07-05 10:41:04 --> Database Driver Class Initialized
INFO - 2021-07-05 10:41:04 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:41:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:41:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:41:04 --> Encryption Class Initialized
INFO - 2021-07-05 10:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:41:04 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:41:04 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:41:04 --> Model "user_model" initialized
INFO - 2021-07-05 10:41:04 --> Model "role_model" initialized
INFO - 2021-07-05 10:41:04 --> Controller Class Initialized
INFO - 2021-07-05 10:41:04 --> Helper loaded: language_helper
INFO - 2021-07-05 10:41:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:41:04 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:41:04 --> Model "Product_model" initialized
INFO - 2021-07-05 10:41:04 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:41:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:41:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:41:04 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:41:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:41:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:41:04 --> Final output sent to browser
DEBUG - 2021-07-05 10:41:04 --> Total execution time: 0.0780
INFO - 2021-07-05 10:41:32 --> Config Class Initialized
INFO - 2021-07-05 10:41:32 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:41:32 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:41:32 --> Utf8 Class Initialized
INFO - 2021-07-05 10:41:32 --> URI Class Initialized
INFO - 2021-07-05 10:41:32 --> Router Class Initialized
INFO - 2021-07-05 10:41:32 --> Output Class Initialized
INFO - 2021-07-05 10:41:32 --> Security Class Initialized
DEBUG - 2021-07-05 10:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:41:32 --> Input Class Initialized
INFO - 2021-07-05 10:41:32 --> Language Class Initialized
INFO - 2021-07-05 10:41:32 --> Loader Class Initialized
INFO - 2021-07-05 10:41:32 --> Helper loaded: html_helper
INFO - 2021-07-05 10:41:32 --> Helper loaded: url_helper
INFO - 2021-07-05 10:41:32 --> Helper loaded: form_helper
INFO - 2021-07-05 10:41:32 --> Database Driver Class Initialized
INFO - 2021-07-05 10:41:32 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:41:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:41:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:41:32 --> Encryption Class Initialized
INFO - 2021-07-05 10:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:41:32 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:41:32 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:41:32 --> Model "user_model" initialized
INFO - 2021-07-05 10:41:32 --> Model "role_model" initialized
INFO - 2021-07-05 10:41:32 --> Controller Class Initialized
INFO - 2021-07-05 10:41:32 --> Helper loaded: language_helper
INFO - 2021-07-05 10:41:32 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:41:32 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:41:32 --> Model "Product_model" initialized
INFO - 2021-07-05 10:41:32 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:41:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:41:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:41:32 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:41:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:41:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:41:32 --> Final output sent to browser
DEBUG - 2021-07-05 10:41:32 --> Total execution time: 0.0759
INFO - 2021-07-05 10:45:36 --> Config Class Initialized
INFO - 2021-07-05 10:45:36 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:45:36 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:45:36 --> Utf8 Class Initialized
INFO - 2021-07-05 10:45:36 --> URI Class Initialized
INFO - 2021-07-05 10:45:36 --> Router Class Initialized
INFO - 2021-07-05 10:45:36 --> Output Class Initialized
INFO - 2021-07-05 10:45:36 --> Security Class Initialized
DEBUG - 2021-07-05 10:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:45:36 --> Input Class Initialized
INFO - 2021-07-05 10:45:36 --> Language Class Initialized
INFO - 2021-07-05 10:45:36 --> Loader Class Initialized
INFO - 2021-07-05 10:45:36 --> Helper loaded: html_helper
INFO - 2021-07-05 10:45:36 --> Helper loaded: url_helper
INFO - 2021-07-05 10:45:36 --> Helper loaded: form_helper
INFO - 2021-07-05 10:45:36 --> Database Driver Class Initialized
INFO - 2021-07-05 10:45:36 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:45:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:45:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:45:36 --> Encryption Class Initialized
INFO - 2021-07-05 10:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:45:36 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:45:36 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:45:36 --> Model "user_model" initialized
INFO - 2021-07-05 10:45:36 --> Model "role_model" initialized
INFO - 2021-07-05 10:45:36 --> Controller Class Initialized
INFO - 2021-07-05 10:45:36 --> Helper loaded: language_helper
INFO - 2021-07-05 10:45:36 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:45:36 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:45:36 --> Model "Product_model" initialized
INFO - 2021-07-05 10:45:36 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:45:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:45:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:45:36 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:45:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:45:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:45:36 --> Final output sent to browser
DEBUG - 2021-07-05 10:45:36 --> Total execution time: 0.1147
INFO - 2021-07-05 10:46:05 --> Config Class Initialized
INFO - 2021-07-05 10:46:05 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:46:05 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:46:05 --> Utf8 Class Initialized
INFO - 2021-07-05 10:46:05 --> URI Class Initialized
INFO - 2021-07-05 10:46:05 --> Router Class Initialized
INFO - 2021-07-05 10:46:05 --> Output Class Initialized
INFO - 2021-07-05 10:46:05 --> Security Class Initialized
DEBUG - 2021-07-05 10:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:46:05 --> Input Class Initialized
INFO - 2021-07-05 10:46:05 --> Language Class Initialized
INFO - 2021-07-05 10:46:05 --> Loader Class Initialized
INFO - 2021-07-05 10:46:05 --> Helper loaded: html_helper
INFO - 2021-07-05 10:46:05 --> Helper loaded: url_helper
INFO - 2021-07-05 10:46:05 --> Helper loaded: form_helper
INFO - 2021-07-05 10:46:05 --> Database Driver Class Initialized
INFO - 2021-07-05 10:46:05 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:46:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:46:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:46:05 --> Encryption Class Initialized
INFO - 2021-07-05 10:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:46:05 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:46:05 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:46:05 --> Model "user_model" initialized
INFO - 2021-07-05 10:46:05 --> Model "role_model" initialized
INFO - 2021-07-05 10:46:05 --> Controller Class Initialized
INFO - 2021-07-05 10:46:05 --> Helper loaded: language_helper
INFO - 2021-07-05 10:46:05 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:46:05 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:46:05 --> Model "Product_model" initialized
INFO - 2021-07-05 10:46:05 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:46:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:46:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:46:05 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:46:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:46:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:46:05 --> Final output sent to browser
DEBUG - 2021-07-05 10:46:05 --> Total execution time: 0.0770
INFO - 2021-07-05 10:46:30 --> Config Class Initialized
INFO - 2021-07-05 10:46:30 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:46:30 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:46:30 --> Utf8 Class Initialized
INFO - 2021-07-05 10:46:30 --> URI Class Initialized
DEBUG - 2021-07-05 10:46:30 --> No URI present. Default controller set.
INFO - 2021-07-05 10:46:30 --> Router Class Initialized
INFO - 2021-07-05 10:46:30 --> Output Class Initialized
INFO - 2021-07-05 10:46:30 --> Security Class Initialized
DEBUG - 2021-07-05 10:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:46:30 --> Input Class Initialized
INFO - 2021-07-05 10:46:30 --> Language Class Initialized
INFO - 2021-07-05 10:46:30 --> Loader Class Initialized
INFO - 2021-07-05 10:46:30 --> Helper loaded: html_helper
INFO - 2021-07-05 10:46:30 --> Helper loaded: url_helper
INFO - 2021-07-05 10:46:30 --> Helper loaded: form_helper
INFO - 2021-07-05 10:46:30 --> Database Driver Class Initialized
INFO - 2021-07-05 10:46:30 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:46:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:46:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:46:30 --> Encryption Class Initialized
INFO - 2021-07-05 10:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:46:30 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:46:30 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:46:30 --> Model "user_model" initialized
INFO - 2021-07-05 10:46:30 --> Model "role_model" initialized
INFO - 2021-07-05 10:46:30 --> Controller Class Initialized
INFO - 2021-07-05 10:46:30 --> Helper loaded: language_helper
INFO - 2021-07-05 10:46:30 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:46:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 10:46:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 10:46:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 10:46:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:46:30 --> Final output sent to browser
DEBUG - 2021-07-05 10:46:30 --> Total execution time: 0.0701
INFO - 2021-07-05 10:46:49 --> Config Class Initialized
INFO - 2021-07-05 10:46:49 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:46:49 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:46:49 --> Utf8 Class Initialized
INFO - 2021-07-05 10:46:49 --> URI Class Initialized
INFO - 2021-07-05 10:46:49 --> Router Class Initialized
INFO - 2021-07-05 10:46:49 --> Output Class Initialized
INFO - 2021-07-05 10:46:49 --> Security Class Initialized
DEBUG - 2021-07-05 10:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:46:49 --> Input Class Initialized
INFO - 2021-07-05 10:46:49 --> Language Class Initialized
INFO - 2021-07-05 10:46:49 --> Loader Class Initialized
INFO - 2021-07-05 10:46:49 --> Helper loaded: html_helper
INFO - 2021-07-05 10:46:49 --> Helper loaded: url_helper
INFO - 2021-07-05 10:46:49 --> Helper loaded: form_helper
INFO - 2021-07-05 10:46:49 --> Database Driver Class Initialized
INFO - 2021-07-05 10:46:49 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:46:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:46:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:46:49 --> Encryption Class Initialized
INFO - 2021-07-05 10:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:46:49 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:46:49 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:46:49 --> Model "user_model" initialized
INFO - 2021-07-05 10:46:49 --> Model "role_model" initialized
INFO - 2021-07-05 10:46:49 --> Controller Class Initialized
INFO - 2021-07-05 10:46:49 --> Helper loaded: language_helper
INFO - 2021-07-05 10:46:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:46:49 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:46:49 --> Model "Product_model" initialized
INFO - 2021-07-05 10:46:49 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:46:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:46:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:46:49 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:46:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:46:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:46:49 --> Final output sent to browser
DEBUG - 2021-07-05 10:46:49 --> Total execution time: 0.0749
INFO - 2021-07-05 10:48:53 --> Config Class Initialized
INFO - 2021-07-05 10:48:53 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:48:53 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:48:53 --> Utf8 Class Initialized
INFO - 2021-07-05 10:48:53 --> URI Class Initialized
DEBUG - 2021-07-05 10:48:53 --> No URI present. Default controller set.
INFO - 2021-07-05 10:48:53 --> Router Class Initialized
INFO - 2021-07-05 10:48:53 --> Output Class Initialized
INFO - 2021-07-05 10:48:53 --> Security Class Initialized
DEBUG - 2021-07-05 10:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:48:53 --> Input Class Initialized
INFO - 2021-07-05 10:48:53 --> Language Class Initialized
INFO - 2021-07-05 10:48:53 --> Loader Class Initialized
INFO - 2021-07-05 10:48:53 --> Helper loaded: html_helper
INFO - 2021-07-05 10:48:53 --> Helper loaded: url_helper
INFO - 2021-07-05 10:48:53 --> Helper loaded: form_helper
INFO - 2021-07-05 10:48:53 --> Database Driver Class Initialized
INFO - 2021-07-05 10:48:53 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:48:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:48:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:48:53 --> Encryption Class Initialized
INFO - 2021-07-05 10:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:48:53 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:48:53 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:48:53 --> Model "user_model" initialized
INFO - 2021-07-05 10:48:53 --> Model "role_model" initialized
INFO - 2021-07-05 10:48:53 --> Controller Class Initialized
INFO - 2021-07-05 10:48:53 --> Helper loaded: language_helper
INFO - 2021-07-05 10:48:53 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:48:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 10:48:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 10:48:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 10:48:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:48:53 --> Final output sent to browser
DEBUG - 2021-07-05 10:48:53 --> Total execution time: 0.1068
INFO - 2021-07-05 10:48:54 --> Config Class Initialized
INFO - 2021-07-05 10:48:54 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:48:54 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:48:54 --> Utf8 Class Initialized
INFO - 2021-07-05 10:48:54 --> URI Class Initialized
DEBUG - 2021-07-05 10:48:54 --> No URI present. Default controller set.
INFO - 2021-07-05 10:48:54 --> Router Class Initialized
INFO - 2021-07-05 10:48:54 --> Output Class Initialized
INFO - 2021-07-05 10:48:54 --> Security Class Initialized
DEBUG - 2021-07-05 10:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:48:54 --> Input Class Initialized
INFO - 2021-07-05 10:48:54 --> Language Class Initialized
INFO - 2021-07-05 10:48:54 --> Loader Class Initialized
INFO - 2021-07-05 10:48:54 --> Helper loaded: html_helper
INFO - 2021-07-05 10:48:54 --> Helper loaded: url_helper
INFO - 2021-07-05 10:48:54 --> Helper loaded: form_helper
INFO - 2021-07-05 10:48:54 --> Database Driver Class Initialized
INFO - 2021-07-05 10:48:54 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:48:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:48:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:48:54 --> Encryption Class Initialized
INFO - 2021-07-05 10:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:48:54 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:48:54 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:48:54 --> Model "user_model" initialized
INFO - 2021-07-05 10:48:54 --> Model "role_model" initialized
INFO - 2021-07-05 10:48:54 --> Controller Class Initialized
INFO - 2021-07-05 10:48:54 --> Helper loaded: language_helper
INFO - 2021-07-05 10:48:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:48:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 10:48:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 10:48:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 10:48:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:48:54 --> Final output sent to browser
DEBUG - 2021-07-05 10:48:54 --> Total execution time: 0.0708
INFO - 2021-07-05 10:49:00 --> Config Class Initialized
INFO - 2021-07-05 10:49:00 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:49:00 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:49:00 --> Utf8 Class Initialized
INFO - 2021-07-05 10:49:00 --> URI Class Initialized
INFO - 2021-07-05 10:49:00 --> Router Class Initialized
INFO - 2021-07-05 10:49:00 --> Output Class Initialized
INFO - 2021-07-05 10:49:00 --> Security Class Initialized
DEBUG - 2021-07-05 10:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:49:00 --> Input Class Initialized
INFO - 2021-07-05 10:49:00 --> Language Class Initialized
INFO - 2021-07-05 10:49:00 --> Loader Class Initialized
INFO - 2021-07-05 10:49:00 --> Helper loaded: html_helper
INFO - 2021-07-05 10:49:00 --> Helper loaded: url_helper
INFO - 2021-07-05 10:49:00 --> Helper loaded: form_helper
INFO - 2021-07-05 10:49:00 --> Database Driver Class Initialized
INFO - 2021-07-05 10:49:00 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:49:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:49:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:49:00 --> Encryption Class Initialized
INFO - 2021-07-05 10:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:49:00 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:49:00 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:49:00 --> Model "user_model" initialized
INFO - 2021-07-05 10:49:00 --> Model "role_model" initialized
INFO - 2021-07-05 10:49:00 --> Controller Class Initialized
INFO - 2021-07-05 10:49:00 --> Helper loaded: language_helper
INFO - 2021-07-05 10:49:00 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:49:00 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:49:00 --> Model "Product_model" initialized
INFO - 2021-07-05 10:49:00 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:49:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:49:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:49:00 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:49:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:49:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:49:00 --> Final output sent to browser
DEBUG - 2021-07-05 10:49:00 --> Total execution time: 0.0862
INFO - 2021-07-05 10:52:06 --> Config Class Initialized
INFO - 2021-07-05 10:52:06 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:52:06 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:52:06 --> Utf8 Class Initialized
INFO - 2021-07-05 10:52:06 --> URI Class Initialized
INFO - 2021-07-05 10:52:06 --> Router Class Initialized
INFO - 2021-07-05 10:52:06 --> Output Class Initialized
INFO - 2021-07-05 10:52:06 --> Security Class Initialized
DEBUG - 2021-07-05 10:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:52:06 --> Input Class Initialized
INFO - 2021-07-05 10:52:06 --> Language Class Initialized
INFO - 2021-07-05 10:52:06 --> Loader Class Initialized
INFO - 2021-07-05 10:52:06 --> Helper loaded: html_helper
INFO - 2021-07-05 10:52:06 --> Helper loaded: url_helper
INFO - 2021-07-05 10:52:06 --> Helper loaded: form_helper
INFO - 2021-07-05 10:52:06 --> Database Driver Class Initialized
INFO - 2021-07-05 10:52:06 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:52:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:52:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:52:06 --> Encryption Class Initialized
INFO - 2021-07-05 10:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:52:06 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:52:06 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:52:06 --> Model "user_model" initialized
INFO - 2021-07-05 10:52:06 --> Model "role_model" initialized
INFO - 2021-07-05 10:52:06 --> Controller Class Initialized
INFO - 2021-07-05 10:52:06 --> Helper loaded: language_helper
INFO - 2021-07-05 10:52:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:52:06 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:52:06 --> Model "Product_model" initialized
INFO - 2021-07-05 10:52:06 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:52:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:52:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:52:06 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:52:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:52:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:52:06 --> Final output sent to browser
DEBUG - 2021-07-05 10:52:06 --> Total execution time: 0.1177
INFO - 2021-07-05 10:52:13 --> Config Class Initialized
INFO - 2021-07-05 10:52:13 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:52:13 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:52:13 --> Utf8 Class Initialized
INFO - 2021-07-05 10:52:13 --> URI Class Initialized
INFO - 2021-07-05 10:52:13 --> Router Class Initialized
INFO - 2021-07-05 10:52:13 --> Output Class Initialized
INFO - 2021-07-05 10:52:13 --> Security Class Initialized
DEBUG - 2021-07-05 10:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:52:13 --> Input Class Initialized
INFO - 2021-07-05 10:52:13 --> Language Class Initialized
INFO - 2021-07-05 10:52:13 --> Loader Class Initialized
INFO - 2021-07-05 10:52:13 --> Helper loaded: html_helper
INFO - 2021-07-05 10:52:13 --> Helper loaded: url_helper
INFO - 2021-07-05 10:52:13 --> Helper loaded: form_helper
INFO - 2021-07-05 10:52:13 --> Database Driver Class Initialized
INFO - 2021-07-05 10:52:13 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:52:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:52:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:52:13 --> Encryption Class Initialized
INFO - 2021-07-05 10:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:52:13 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:52:13 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:52:13 --> Model "user_model" initialized
INFO - 2021-07-05 10:52:13 --> Model "role_model" initialized
INFO - 2021-07-05 10:52:13 --> Controller Class Initialized
INFO - 2021-07-05 10:52:13 --> Helper loaded: language_helper
INFO - 2021-07-05 10:52:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:52:13 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:52:13 --> Model "Product_model" initialized
INFO - 2021-07-05 10:52:13 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:52:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:52:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:52:13 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:52:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:52:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:52:13 --> Final output sent to browser
DEBUG - 2021-07-05 10:52:13 --> Total execution time: 0.0789
INFO - 2021-07-05 10:52:22 --> Config Class Initialized
INFO - 2021-07-05 10:52:22 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:52:22 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:52:22 --> Utf8 Class Initialized
INFO - 2021-07-05 10:52:22 --> URI Class Initialized
INFO - 2021-07-05 10:52:22 --> Router Class Initialized
INFO - 2021-07-05 10:52:22 --> Output Class Initialized
INFO - 2021-07-05 10:52:22 --> Security Class Initialized
DEBUG - 2021-07-05 10:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:52:22 --> Input Class Initialized
INFO - 2021-07-05 10:52:22 --> Language Class Initialized
INFO - 2021-07-05 10:52:22 --> Loader Class Initialized
INFO - 2021-07-05 10:52:22 --> Helper loaded: html_helper
INFO - 2021-07-05 10:52:22 --> Helper loaded: url_helper
INFO - 2021-07-05 10:52:22 --> Helper loaded: form_helper
INFO - 2021-07-05 10:52:22 --> Database Driver Class Initialized
INFO - 2021-07-05 10:52:22 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:52:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:52:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:52:22 --> Encryption Class Initialized
INFO - 2021-07-05 10:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:52:22 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:52:22 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:52:22 --> Model "user_model" initialized
INFO - 2021-07-05 10:52:22 --> Model "role_model" initialized
INFO - 2021-07-05 10:52:22 --> Controller Class Initialized
INFO - 2021-07-05 10:52:22 --> Helper loaded: language_helper
INFO - 2021-07-05 10:52:22 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:52:22 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:52:22 --> Model "Product_model" initialized
INFO - 2021-07-05 10:52:22 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:52:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:52:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:52:22 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:52:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:52:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:52:22 --> Final output sent to browser
DEBUG - 2021-07-05 10:52:22 --> Total execution time: 0.0865
INFO - 2021-07-05 10:52:47 --> Config Class Initialized
INFO - 2021-07-05 10:52:47 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:52:47 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:52:47 --> Utf8 Class Initialized
INFO - 2021-07-05 10:52:47 --> URI Class Initialized
INFO - 2021-07-05 10:52:47 --> Router Class Initialized
INFO - 2021-07-05 10:52:47 --> Output Class Initialized
INFO - 2021-07-05 10:52:47 --> Security Class Initialized
DEBUG - 2021-07-05 10:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:52:47 --> Input Class Initialized
INFO - 2021-07-05 10:52:47 --> Language Class Initialized
INFO - 2021-07-05 10:52:47 --> Loader Class Initialized
INFO - 2021-07-05 10:52:47 --> Helper loaded: html_helper
INFO - 2021-07-05 10:52:47 --> Helper loaded: url_helper
INFO - 2021-07-05 10:52:47 --> Helper loaded: form_helper
INFO - 2021-07-05 10:52:47 --> Database Driver Class Initialized
INFO - 2021-07-05 10:52:47 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:52:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:52:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:52:47 --> Encryption Class Initialized
INFO - 2021-07-05 10:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:52:47 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:52:47 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:52:47 --> Model "user_model" initialized
INFO - 2021-07-05 10:52:47 --> Model "role_model" initialized
INFO - 2021-07-05 10:52:47 --> Controller Class Initialized
INFO - 2021-07-05 10:52:47 --> Helper loaded: language_helper
INFO - 2021-07-05 10:52:47 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:52:47 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:52:47 --> Model "Product_model" initialized
INFO - 2021-07-05 10:52:47 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:52:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:52:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:52:47 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:52:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:52:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:52:47 --> Final output sent to browser
DEBUG - 2021-07-05 10:52:47 --> Total execution time: 0.1154
INFO - 2021-07-05 10:52:54 --> Config Class Initialized
INFO - 2021-07-05 10:52:54 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:52:54 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:52:54 --> Utf8 Class Initialized
INFO - 2021-07-05 10:52:54 --> URI Class Initialized
INFO - 2021-07-05 10:52:54 --> Router Class Initialized
INFO - 2021-07-05 10:52:54 --> Output Class Initialized
INFO - 2021-07-05 10:52:54 --> Security Class Initialized
DEBUG - 2021-07-05 10:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:52:54 --> Input Class Initialized
INFO - 2021-07-05 10:52:54 --> Language Class Initialized
INFO - 2021-07-05 10:52:54 --> Loader Class Initialized
INFO - 2021-07-05 10:52:54 --> Helper loaded: html_helper
INFO - 2021-07-05 10:52:54 --> Helper loaded: url_helper
INFO - 2021-07-05 10:52:54 --> Helper loaded: form_helper
INFO - 2021-07-05 10:52:54 --> Database Driver Class Initialized
INFO - 2021-07-05 10:52:54 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:52:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:52:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:52:54 --> Encryption Class Initialized
INFO - 2021-07-05 10:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:52:54 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:52:54 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:52:54 --> Model "user_model" initialized
INFO - 2021-07-05 10:52:54 --> Model "role_model" initialized
INFO - 2021-07-05 10:52:54 --> Controller Class Initialized
INFO - 2021-07-05 10:52:54 --> Helper loaded: language_helper
INFO - 2021-07-05 10:52:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:52:54 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:52:54 --> Model "Product_model" initialized
INFO - 2021-07-05 10:52:54 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:52:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:52:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:52:54 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:52:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:52:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:52:54 --> Final output sent to browser
DEBUG - 2021-07-05 10:52:54 --> Total execution time: 0.0732
INFO - 2021-07-05 10:53:08 --> Config Class Initialized
INFO - 2021-07-05 10:53:08 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:53:08 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:53:08 --> Utf8 Class Initialized
INFO - 2021-07-05 10:53:08 --> URI Class Initialized
INFO - 2021-07-05 10:53:08 --> Router Class Initialized
INFO - 2021-07-05 10:53:08 --> Output Class Initialized
INFO - 2021-07-05 10:53:08 --> Security Class Initialized
DEBUG - 2021-07-05 10:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:53:08 --> Input Class Initialized
INFO - 2021-07-05 10:53:08 --> Language Class Initialized
INFO - 2021-07-05 10:53:08 --> Loader Class Initialized
INFO - 2021-07-05 10:53:08 --> Helper loaded: html_helper
INFO - 2021-07-05 10:53:08 --> Helper loaded: url_helper
INFO - 2021-07-05 10:53:08 --> Helper loaded: form_helper
INFO - 2021-07-05 10:53:08 --> Database Driver Class Initialized
INFO - 2021-07-05 10:53:08 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:53:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:53:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:53:08 --> Encryption Class Initialized
INFO - 2021-07-05 10:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:53:08 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:53:08 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:53:08 --> Model "user_model" initialized
INFO - 2021-07-05 10:53:08 --> Model "role_model" initialized
INFO - 2021-07-05 10:53:08 --> Controller Class Initialized
INFO - 2021-07-05 10:53:08 --> Helper loaded: language_helper
INFO - 2021-07-05 10:53:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:53:08 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:53:08 --> Model "Product_model" initialized
INFO - 2021-07-05 10:53:08 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:53:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:53:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:53:08 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:53:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:53:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:53:08 --> Final output sent to browser
DEBUG - 2021-07-05 10:53:08 --> Total execution time: 0.0773
INFO - 2021-07-05 10:54:14 --> Config Class Initialized
INFO - 2021-07-05 10:54:14 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:54:14 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:54:14 --> Utf8 Class Initialized
INFO - 2021-07-05 10:54:14 --> URI Class Initialized
INFO - 2021-07-05 10:54:14 --> Router Class Initialized
INFO - 2021-07-05 10:54:14 --> Output Class Initialized
INFO - 2021-07-05 10:54:14 --> Security Class Initialized
DEBUG - 2021-07-05 10:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:54:14 --> Input Class Initialized
INFO - 2021-07-05 10:54:14 --> Language Class Initialized
INFO - 2021-07-05 10:54:14 --> Loader Class Initialized
INFO - 2021-07-05 10:54:14 --> Helper loaded: html_helper
INFO - 2021-07-05 10:54:14 --> Helper loaded: url_helper
INFO - 2021-07-05 10:54:14 --> Helper loaded: form_helper
INFO - 2021-07-05 10:54:14 --> Database Driver Class Initialized
INFO - 2021-07-05 10:54:14 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:54:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:54:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:54:14 --> Encryption Class Initialized
INFO - 2021-07-05 10:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:54:14 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:54:14 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:54:14 --> Model "user_model" initialized
INFO - 2021-07-05 10:54:14 --> Model "role_model" initialized
INFO - 2021-07-05 10:54:14 --> Controller Class Initialized
INFO - 2021-07-05 10:54:14 --> Helper loaded: language_helper
INFO - 2021-07-05 10:54:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:54:14 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:54:14 --> Model "Product_model" initialized
INFO - 2021-07-05 10:54:14 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:54:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:54:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:54:14 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:54:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:54:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:54:14 --> Final output sent to browser
DEBUG - 2021-07-05 10:54:14 --> Total execution time: 0.1134
INFO - 2021-07-05 10:54:26 --> Config Class Initialized
INFO - 2021-07-05 10:54:26 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:54:26 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:54:26 --> Utf8 Class Initialized
INFO - 2021-07-05 10:54:26 --> URI Class Initialized
DEBUG - 2021-07-05 10:54:26 --> No URI present. Default controller set.
INFO - 2021-07-05 10:54:26 --> Router Class Initialized
INFO - 2021-07-05 10:54:26 --> Output Class Initialized
INFO - 2021-07-05 10:54:26 --> Security Class Initialized
DEBUG - 2021-07-05 10:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:54:26 --> Input Class Initialized
INFO - 2021-07-05 10:54:26 --> Language Class Initialized
INFO - 2021-07-05 10:54:26 --> Loader Class Initialized
INFO - 2021-07-05 10:54:26 --> Helper loaded: html_helper
INFO - 2021-07-05 10:54:26 --> Helper loaded: url_helper
INFO - 2021-07-05 10:54:26 --> Helper loaded: form_helper
INFO - 2021-07-05 10:54:26 --> Database Driver Class Initialized
INFO - 2021-07-05 10:54:26 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:54:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:54:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:54:26 --> Encryption Class Initialized
INFO - 2021-07-05 10:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:54:26 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:54:26 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:54:26 --> Model "user_model" initialized
INFO - 2021-07-05 10:54:26 --> Model "role_model" initialized
INFO - 2021-07-05 10:54:26 --> Controller Class Initialized
INFO - 2021-07-05 10:54:26 --> Helper loaded: language_helper
INFO - 2021-07-05 10:54:26 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:54:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 10:54:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 10:54:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 10:54:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:54:26 --> Final output sent to browser
DEBUG - 2021-07-05 10:54:26 --> Total execution time: 0.0651
INFO - 2021-07-05 10:54:35 --> Config Class Initialized
INFO - 2021-07-05 10:54:35 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:54:35 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:54:35 --> Utf8 Class Initialized
INFO - 2021-07-05 10:54:35 --> URI Class Initialized
INFO - 2021-07-05 10:54:35 --> Router Class Initialized
INFO - 2021-07-05 10:54:35 --> Output Class Initialized
INFO - 2021-07-05 10:54:35 --> Security Class Initialized
DEBUG - 2021-07-05 10:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:54:35 --> Input Class Initialized
INFO - 2021-07-05 10:54:35 --> Language Class Initialized
INFO - 2021-07-05 10:54:35 --> Loader Class Initialized
INFO - 2021-07-05 10:54:35 --> Helper loaded: html_helper
INFO - 2021-07-05 10:54:35 --> Helper loaded: url_helper
INFO - 2021-07-05 10:54:35 --> Helper loaded: form_helper
INFO - 2021-07-05 10:54:35 --> Database Driver Class Initialized
INFO - 2021-07-05 10:54:35 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:54:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:54:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:54:35 --> Encryption Class Initialized
INFO - 2021-07-05 10:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:54:35 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:54:35 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:54:35 --> Model "user_model" initialized
INFO - 2021-07-05 10:54:35 --> Model "role_model" initialized
INFO - 2021-07-05 10:54:35 --> Controller Class Initialized
INFO - 2021-07-05 10:54:35 --> Helper loaded: language_helper
INFO - 2021-07-05 10:54:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:54:35 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:54:35 --> Model "Product_model" initialized
INFO - 2021-07-05 10:54:35 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:54:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:54:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:54:35 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:54:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:54:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:54:35 --> Final output sent to browser
DEBUG - 2021-07-05 10:54:35 --> Total execution time: 0.0766
INFO - 2021-07-05 10:54:56 --> Config Class Initialized
INFO - 2021-07-05 10:54:56 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:54:56 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:54:56 --> Utf8 Class Initialized
INFO - 2021-07-05 10:54:56 --> URI Class Initialized
DEBUG - 2021-07-05 10:54:56 --> No URI present. Default controller set.
INFO - 2021-07-05 10:54:56 --> Router Class Initialized
INFO - 2021-07-05 10:54:56 --> Output Class Initialized
INFO - 2021-07-05 10:54:56 --> Security Class Initialized
DEBUG - 2021-07-05 10:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:54:56 --> Input Class Initialized
INFO - 2021-07-05 10:54:56 --> Language Class Initialized
INFO - 2021-07-05 10:54:56 --> Loader Class Initialized
INFO - 2021-07-05 10:54:56 --> Helper loaded: html_helper
INFO - 2021-07-05 10:54:56 --> Helper loaded: url_helper
INFO - 2021-07-05 10:54:56 --> Helper loaded: form_helper
INFO - 2021-07-05 10:54:56 --> Database Driver Class Initialized
INFO - 2021-07-05 10:54:56 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:54:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:54:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:54:56 --> Encryption Class Initialized
INFO - 2021-07-05 10:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:54:56 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:54:56 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:54:56 --> Model "user_model" initialized
INFO - 2021-07-05 10:54:56 --> Model "role_model" initialized
INFO - 2021-07-05 10:54:56 --> Controller Class Initialized
INFO - 2021-07-05 10:54:56 --> Helper loaded: language_helper
INFO - 2021-07-05 10:54:56 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:54:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 10:54:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 10:54:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 10:54:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:54:56 --> Final output sent to browser
DEBUG - 2021-07-05 10:54:56 --> Total execution time: 0.0713
INFO - 2021-07-05 10:55:04 --> Config Class Initialized
INFO - 2021-07-05 10:55:04 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:55:04 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:55:04 --> Utf8 Class Initialized
INFO - 2021-07-05 10:55:04 --> URI Class Initialized
DEBUG - 2021-07-05 10:55:04 --> No URI present. Default controller set.
INFO - 2021-07-05 10:55:04 --> Router Class Initialized
INFO - 2021-07-05 10:55:04 --> Output Class Initialized
INFO - 2021-07-05 10:55:04 --> Security Class Initialized
DEBUG - 2021-07-05 10:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:55:04 --> Input Class Initialized
INFO - 2021-07-05 10:55:04 --> Language Class Initialized
INFO - 2021-07-05 10:55:04 --> Loader Class Initialized
INFO - 2021-07-05 10:55:04 --> Helper loaded: html_helper
INFO - 2021-07-05 10:55:04 --> Helper loaded: url_helper
INFO - 2021-07-05 10:55:04 --> Helper loaded: form_helper
INFO - 2021-07-05 10:55:04 --> Database Driver Class Initialized
INFO - 2021-07-05 10:55:04 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:55:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:55:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:55:04 --> Encryption Class Initialized
INFO - 2021-07-05 10:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:55:04 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:55:04 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:55:04 --> Model "user_model" initialized
INFO - 2021-07-05 10:55:04 --> Model "role_model" initialized
INFO - 2021-07-05 10:55:04 --> Controller Class Initialized
INFO - 2021-07-05 10:55:04 --> Helper loaded: language_helper
INFO - 2021-07-05 10:55:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:55:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 10:55:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 10:55:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 10:55:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:55:04 --> Final output sent to browser
DEBUG - 2021-07-05 10:55:04 --> Total execution time: 0.0603
INFO - 2021-07-05 10:55:10 --> Config Class Initialized
INFO - 2021-07-05 10:55:10 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:55:10 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:55:10 --> Utf8 Class Initialized
INFO - 2021-07-05 10:55:10 --> URI Class Initialized
DEBUG - 2021-07-05 10:55:10 --> No URI present. Default controller set.
INFO - 2021-07-05 10:55:10 --> Router Class Initialized
INFO - 2021-07-05 10:55:10 --> Output Class Initialized
INFO - 2021-07-05 10:55:10 --> Security Class Initialized
DEBUG - 2021-07-05 10:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:55:10 --> Input Class Initialized
INFO - 2021-07-05 10:55:10 --> Language Class Initialized
INFO - 2021-07-05 10:55:10 --> Loader Class Initialized
INFO - 2021-07-05 10:55:10 --> Helper loaded: html_helper
INFO - 2021-07-05 10:55:10 --> Helper loaded: url_helper
INFO - 2021-07-05 10:55:10 --> Helper loaded: form_helper
INFO - 2021-07-05 10:55:10 --> Database Driver Class Initialized
INFO - 2021-07-05 10:55:10 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:55:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:55:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:55:10 --> Encryption Class Initialized
INFO - 2021-07-05 10:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:55:10 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:55:10 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:55:10 --> Model "user_model" initialized
INFO - 2021-07-05 10:55:10 --> Model "role_model" initialized
INFO - 2021-07-05 10:55:10 --> Controller Class Initialized
INFO - 2021-07-05 10:55:10 --> Helper loaded: language_helper
INFO - 2021-07-05 10:55:10 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:55:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 10:55:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 10:55:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 10:55:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:55:10 --> Final output sent to browser
DEBUG - 2021-07-05 10:55:10 --> Total execution time: 0.0834
INFO - 2021-07-05 10:55:26 --> Config Class Initialized
INFO - 2021-07-05 10:55:26 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:55:26 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:55:26 --> Utf8 Class Initialized
INFO - 2021-07-05 10:55:26 --> URI Class Initialized
INFO - 2021-07-05 10:55:26 --> Router Class Initialized
INFO - 2021-07-05 10:55:26 --> Output Class Initialized
INFO - 2021-07-05 10:55:26 --> Security Class Initialized
DEBUG - 2021-07-05 10:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:55:26 --> Input Class Initialized
INFO - 2021-07-05 10:55:26 --> Language Class Initialized
INFO - 2021-07-05 10:55:26 --> Loader Class Initialized
INFO - 2021-07-05 10:55:26 --> Helper loaded: html_helper
INFO - 2021-07-05 10:55:26 --> Helper loaded: url_helper
INFO - 2021-07-05 10:55:26 --> Helper loaded: form_helper
INFO - 2021-07-05 10:55:26 --> Database Driver Class Initialized
INFO - 2021-07-05 10:55:26 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:55:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:55:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:55:26 --> Encryption Class Initialized
INFO - 2021-07-05 10:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:55:26 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:55:26 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:55:26 --> Model "user_model" initialized
INFO - 2021-07-05 10:55:26 --> Model "role_model" initialized
INFO - 2021-07-05 10:55:26 --> Controller Class Initialized
INFO - 2021-07-05 10:55:26 --> Helper loaded: language_helper
INFO - 2021-07-05 10:55:26 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:55:26 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:55:26 --> Model "Product_model" initialized
INFO - 2021-07-05 10:55:26 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:55:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:55:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:55:26 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:55:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:55:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:55:26 --> Final output sent to browser
DEBUG - 2021-07-05 10:55:26 --> Total execution time: 0.0752
INFO - 2021-07-05 10:59:01 --> Config Class Initialized
INFO - 2021-07-05 10:59:01 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:59:01 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:59:01 --> Utf8 Class Initialized
INFO - 2021-07-05 10:59:01 --> URI Class Initialized
INFO - 2021-07-05 10:59:01 --> Router Class Initialized
INFO - 2021-07-05 10:59:01 --> Output Class Initialized
INFO - 2021-07-05 10:59:01 --> Security Class Initialized
DEBUG - 2021-07-05 10:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:59:01 --> Input Class Initialized
INFO - 2021-07-05 10:59:01 --> Language Class Initialized
INFO - 2021-07-05 10:59:01 --> Loader Class Initialized
INFO - 2021-07-05 10:59:01 --> Helper loaded: html_helper
INFO - 2021-07-05 10:59:01 --> Helper loaded: url_helper
INFO - 2021-07-05 10:59:01 --> Helper loaded: form_helper
INFO - 2021-07-05 10:59:01 --> Database Driver Class Initialized
INFO - 2021-07-05 10:59:01 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:59:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:59:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:59:01 --> Encryption Class Initialized
INFO - 2021-07-05 10:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:59:01 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:59:01 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:59:01 --> Model "user_model" initialized
INFO - 2021-07-05 10:59:01 --> Model "role_model" initialized
INFO - 2021-07-05 10:59:01 --> Controller Class Initialized
INFO - 2021-07-05 10:59:01 --> Helper loaded: language_helper
INFO - 2021-07-05 10:59:01 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:59:01 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:59:01 --> Model "Product_model" initialized
INFO - 2021-07-05 10:59:01 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 10:59:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 10:59:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 10:59:01 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 10:59:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 10:59:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 10:59:01 --> Final output sent to browser
DEBUG - 2021-07-05 10:59:01 --> Total execution time: 0.1330
INFO - 2021-07-05 10:59:46 --> Config Class Initialized
INFO - 2021-07-05 10:59:46 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:59:46 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:59:46 --> Utf8 Class Initialized
INFO - 2021-07-05 10:59:46 --> URI Class Initialized
INFO - 2021-07-05 10:59:46 --> Router Class Initialized
INFO - 2021-07-05 10:59:46 --> Output Class Initialized
INFO - 2021-07-05 10:59:46 --> Security Class Initialized
DEBUG - 2021-07-05 10:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:59:46 --> Input Class Initialized
INFO - 2021-07-05 10:59:46 --> Language Class Initialized
INFO - 2021-07-05 10:59:46 --> Loader Class Initialized
INFO - 2021-07-05 10:59:46 --> Helper loaded: html_helper
INFO - 2021-07-05 10:59:46 --> Helper loaded: url_helper
INFO - 2021-07-05 10:59:46 --> Helper loaded: form_helper
INFO - 2021-07-05 10:59:46 --> Database Driver Class Initialized
INFO - 2021-07-05 10:59:46 --> Form Validation Class Initialized
DEBUG - 2021-07-05 10:59:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 10:59:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 10:59:46 --> Encryption Class Initialized
INFO - 2021-07-05 10:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:59:46 --> Model "vendor_model" initialized
INFO - 2021-07-05 10:59:46 --> Model "coupon_model" initialized
INFO - 2021-07-05 10:59:46 --> Model "user_model" initialized
INFO - 2021-07-05 10:59:46 --> Model "role_model" initialized
INFO - 2021-07-05 10:59:46 --> Controller Class Initialized
INFO - 2021-07-05 10:59:46 --> Helper loaded: language_helper
INFO - 2021-07-05 10:59:46 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 10:59:46 --> Model "Customer_model" initialized
INFO - 2021-07-05 10:59:46 --> Final output sent to browser
DEBUG - 2021-07-05 10:59:46 --> Total execution time: 0.0714
INFO - 2021-07-05 11:00:38 --> Config Class Initialized
INFO - 2021-07-05 11:00:38 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:00:38 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:00:38 --> Utf8 Class Initialized
INFO - 2021-07-05 11:00:38 --> URI Class Initialized
INFO - 2021-07-05 11:00:38 --> Router Class Initialized
INFO - 2021-07-05 11:00:38 --> Output Class Initialized
INFO - 2021-07-05 11:00:38 --> Security Class Initialized
DEBUG - 2021-07-05 11:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:00:38 --> Input Class Initialized
INFO - 2021-07-05 11:00:38 --> Language Class Initialized
INFO - 2021-07-05 11:00:38 --> Loader Class Initialized
INFO - 2021-07-05 11:00:38 --> Helper loaded: html_helper
INFO - 2021-07-05 11:00:38 --> Helper loaded: url_helper
INFO - 2021-07-05 11:00:38 --> Helper loaded: form_helper
INFO - 2021-07-05 11:00:38 --> Database Driver Class Initialized
INFO - 2021-07-05 11:00:38 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:00:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:00:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:00:38 --> Encryption Class Initialized
INFO - 2021-07-05 11:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:00:38 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:00:38 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:00:38 --> Model "user_model" initialized
INFO - 2021-07-05 11:00:38 --> Model "role_model" initialized
INFO - 2021-07-05 11:00:38 --> Controller Class Initialized
INFO - 2021-07-05 11:00:38 --> Helper loaded: language_helper
INFO - 2021-07-05 11:00:38 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:00:38 --> Model "Customer_model" initialized
INFO - 2021-07-05 11:00:38 --> Final output sent to browser
DEBUG - 2021-07-05 11:00:38 --> Total execution time: 0.0770
INFO - 2021-07-05 11:04:52 --> Config Class Initialized
INFO - 2021-07-05 11:04:52 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:04:52 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:04:52 --> Utf8 Class Initialized
INFO - 2021-07-05 11:04:52 --> URI Class Initialized
INFO - 2021-07-05 11:04:52 --> Router Class Initialized
INFO - 2021-07-05 11:04:52 --> Output Class Initialized
INFO - 2021-07-05 11:04:52 --> Security Class Initialized
DEBUG - 2021-07-05 11:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:04:52 --> Input Class Initialized
INFO - 2021-07-05 11:04:52 --> Language Class Initialized
INFO - 2021-07-05 11:04:52 --> Loader Class Initialized
INFO - 2021-07-05 11:04:52 --> Helper loaded: html_helper
INFO - 2021-07-05 11:04:52 --> Helper loaded: url_helper
INFO - 2021-07-05 11:04:52 --> Helper loaded: form_helper
INFO - 2021-07-05 11:04:52 --> Database Driver Class Initialized
INFO - 2021-07-05 11:04:52 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:04:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:04:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:04:52 --> Encryption Class Initialized
INFO - 2021-07-05 11:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:04:52 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:04:52 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:04:52 --> Model "user_model" initialized
INFO - 2021-07-05 11:04:52 --> Model "role_model" initialized
INFO - 2021-07-05 11:04:52 --> Controller Class Initialized
INFO - 2021-07-05 11:04:52 --> Helper loaded: language_helper
INFO - 2021-07-05 11:04:52 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:04:52 --> Model "Customer_model" initialized
INFO - 2021-07-05 11:04:52 --> Model "Product_model" initialized
INFO - 2021-07-05 11:04:52 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 11:04:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 11:04:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 11:04:52 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 11:04:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 11:04:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:04:52 --> Final output sent to browser
DEBUG - 2021-07-05 11:04:52 --> Total execution time: 0.1184
INFO - 2021-07-05 11:06:07 --> Config Class Initialized
INFO - 2021-07-05 11:06:07 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:06:07 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:06:07 --> Utf8 Class Initialized
INFO - 2021-07-05 11:06:07 --> URI Class Initialized
INFO - 2021-07-05 11:06:07 --> Router Class Initialized
INFO - 2021-07-05 11:06:07 --> Output Class Initialized
INFO - 2021-07-05 11:06:07 --> Security Class Initialized
DEBUG - 2021-07-05 11:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:06:07 --> Input Class Initialized
INFO - 2021-07-05 11:06:07 --> Language Class Initialized
INFO - 2021-07-05 11:06:07 --> Loader Class Initialized
INFO - 2021-07-05 11:06:07 --> Helper loaded: html_helper
INFO - 2021-07-05 11:06:07 --> Helper loaded: url_helper
INFO - 2021-07-05 11:06:07 --> Helper loaded: form_helper
INFO - 2021-07-05 11:06:07 --> Database Driver Class Initialized
INFO - 2021-07-05 11:06:07 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:06:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:06:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:06:07 --> Encryption Class Initialized
INFO - 2021-07-05 11:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:06:07 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:06:07 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:06:07 --> Model "user_model" initialized
INFO - 2021-07-05 11:06:07 --> Model "role_model" initialized
INFO - 2021-07-05 11:06:07 --> Controller Class Initialized
INFO - 2021-07-05 11:06:07 --> Helper loaded: language_helper
INFO - 2021-07-05 11:06:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:06:07 --> Model "Product_model" initialized
ERROR - 2021-07-05 11:06:07 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server][SQL Server]Error converting data type varchar to float. - Invalid query: INSERT INTO "Product" ("product_id", "product_name", "product_desc", "rate", "edition") VALUES ('8d4a5a5d-0db9-4442-b487-b94bbbda3fc7', '123345', '', 'testing', '12000')
INFO - 2021-07-05 11:06:07 --> Language file loaded: language/english/db_lang.php
INFO - 2021-07-05 11:10:06 --> Config Class Initialized
INFO - 2021-07-05 11:10:06 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:10:06 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:10:06 --> Utf8 Class Initialized
INFO - 2021-07-05 11:10:06 --> URI Class Initialized
INFO - 2021-07-05 11:10:06 --> Router Class Initialized
INFO - 2021-07-05 11:10:06 --> Output Class Initialized
INFO - 2021-07-05 11:10:06 --> Security Class Initialized
DEBUG - 2021-07-05 11:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:10:06 --> Input Class Initialized
INFO - 2021-07-05 11:10:06 --> Language Class Initialized
INFO - 2021-07-05 11:10:06 --> Loader Class Initialized
INFO - 2021-07-05 11:10:06 --> Helper loaded: html_helper
INFO - 2021-07-05 11:10:06 --> Helper loaded: url_helper
INFO - 2021-07-05 11:10:06 --> Helper loaded: form_helper
INFO - 2021-07-05 11:10:06 --> Database Driver Class Initialized
INFO - 2021-07-05 11:10:07 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:10:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:10:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:10:07 --> Encryption Class Initialized
INFO - 2021-07-05 11:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:10:07 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:10:07 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:10:07 --> Model "user_model" initialized
INFO - 2021-07-05 11:10:07 --> Model "role_model" initialized
INFO - 2021-07-05 11:10:07 --> Controller Class Initialized
INFO - 2021-07-05 11:10:07 --> Helper loaded: language_helper
INFO - 2021-07-05 11:10:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:10:07 --> Model "Customer_model" initialized
INFO - 2021-07-05 11:10:07 --> Model "Product_model" initialized
INFO - 2021-07-05 11:10:07 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 11:10:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 11:10:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 11:10:07 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 11:10:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 11:10:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:10:07 --> Final output sent to browser
DEBUG - 2021-07-05 11:10:07 --> Total execution time: 0.0808
INFO - 2021-07-05 11:10:38 --> Config Class Initialized
INFO - 2021-07-05 11:10:38 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:10:38 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:10:38 --> Utf8 Class Initialized
INFO - 2021-07-05 11:10:38 --> URI Class Initialized
INFO - 2021-07-05 11:10:38 --> Router Class Initialized
INFO - 2021-07-05 11:10:38 --> Output Class Initialized
INFO - 2021-07-05 11:10:38 --> Security Class Initialized
DEBUG - 2021-07-05 11:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:10:38 --> Input Class Initialized
INFO - 2021-07-05 11:10:38 --> Language Class Initialized
INFO - 2021-07-05 11:10:38 --> Loader Class Initialized
INFO - 2021-07-05 11:10:38 --> Helper loaded: html_helper
INFO - 2021-07-05 11:10:38 --> Helper loaded: url_helper
INFO - 2021-07-05 11:10:38 --> Helper loaded: form_helper
INFO - 2021-07-05 11:10:38 --> Database Driver Class Initialized
INFO - 2021-07-05 11:10:38 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:10:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:10:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:10:38 --> Encryption Class Initialized
INFO - 2021-07-05 11:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:10:38 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:10:38 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:10:38 --> Model "user_model" initialized
INFO - 2021-07-05 11:10:38 --> Model "role_model" initialized
INFO - 2021-07-05 11:10:38 --> Controller Class Initialized
INFO - 2021-07-05 11:10:38 --> Helper loaded: language_helper
INFO - 2021-07-05 11:10:38 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:10:38 --> Model "Product_model" initialized
ERROR - 2021-07-05 11:10:38 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server][SQL Server]Error converting data type varchar to float. - Invalid query: INSERT INTO "Product" ("Product_ID", "Product_Name", "Product_Desc", "Rate", "Edition") VALUES ('d7740282-ebf6-4e06-bf45-b5cdeaf924ce', 'testing', '', 'testing', '12000')
INFO - 2021-07-05 11:10:38 --> Language file loaded: language/english/db_lang.php
INFO - 2021-07-05 11:13:00 --> Config Class Initialized
INFO - 2021-07-05 11:13:00 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:13:00 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:13:00 --> Utf8 Class Initialized
INFO - 2021-07-05 11:13:00 --> URI Class Initialized
INFO - 2021-07-05 11:13:00 --> Router Class Initialized
INFO - 2021-07-05 11:13:00 --> Output Class Initialized
INFO - 2021-07-05 11:13:00 --> Security Class Initialized
DEBUG - 2021-07-05 11:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:13:00 --> Input Class Initialized
INFO - 2021-07-05 11:13:00 --> Language Class Initialized
INFO - 2021-07-05 11:13:00 --> Loader Class Initialized
INFO - 2021-07-05 11:13:00 --> Helper loaded: html_helper
INFO - 2021-07-05 11:13:00 --> Helper loaded: url_helper
INFO - 2021-07-05 11:13:00 --> Helper loaded: form_helper
INFO - 2021-07-05 11:13:00 --> Database Driver Class Initialized
INFO - 2021-07-05 11:13:00 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:13:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:13:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:13:00 --> Encryption Class Initialized
INFO - 2021-07-05 11:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:13:00 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:13:00 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:13:00 --> Model "user_model" initialized
INFO - 2021-07-05 11:13:00 --> Model "role_model" initialized
INFO - 2021-07-05 11:13:00 --> Controller Class Initialized
INFO - 2021-07-05 11:13:00 --> Helper loaded: language_helper
INFO - 2021-07-05 11:13:00 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:13:00 --> Model "Customer_model" initialized
INFO - 2021-07-05 11:13:00 --> Model "Product_model" initialized
INFO - 2021-07-05 11:13:00 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 11:13:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 11:13:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 11:13:00 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 11:13:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 11:13:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:13:00 --> Final output sent to browser
DEBUG - 2021-07-05 11:13:00 --> Total execution time: 0.0767
INFO - 2021-07-05 11:13:45 --> Config Class Initialized
INFO - 2021-07-05 11:13:45 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:13:45 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:13:45 --> Utf8 Class Initialized
INFO - 2021-07-05 11:13:45 --> URI Class Initialized
INFO - 2021-07-05 11:13:45 --> Router Class Initialized
INFO - 2021-07-05 11:13:45 --> Output Class Initialized
INFO - 2021-07-05 11:13:45 --> Security Class Initialized
DEBUG - 2021-07-05 11:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:13:45 --> Input Class Initialized
INFO - 2021-07-05 11:13:45 --> Language Class Initialized
INFO - 2021-07-05 11:13:45 --> Loader Class Initialized
INFO - 2021-07-05 11:13:45 --> Helper loaded: html_helper
INFO - 2021-07-05 11:13:45 --> Helper loaded: url_helper
INFO - 2021-07-05 11:13:45 --> Helper loaded: form_helper
INFO - 2021-07-05 11:13:45 --> Database Driver Class Initialized
INFO - 2021-07-05 11:13:45 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:13:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:13:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:13:45 --> Encryption Class Initialized
INFO - 2021-07-05 11:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:13:45 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:13:45 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:13:45 --> Model "user_model" initialized
INFO - 2021-07-05 11:13:45 --> Model "role_model" initialized
INFO - 2021-07-05 11:13:45 --> Controller Class Initialized
INFO - 2021-07-05 11:13:45 --> Helper loaded: language_helper
INFO - 2021-07-05 11:13:45 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:13:45 --> Model "Product_model" initialized
ERROR - 2021-07-05 11:13:45 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server][SQL Server]Error converting data type varchar to float. - Invalid query: INSERT INTO "Product" ("Product_ID", "Product_Name", "Product_Desc", "Rate", "Edition") VALUES ('0456d1d6-800b-4293-b2b7-45787978d959', 'testing', '', 'testing', '12000')
INFO - 2021-07-05 11:13:45 --> Language file loaded: language/english/db_lang.php
INFO - 2021-07-05 11:17:01 --> Config Class Initialized
INFO - 2021-07-05 11:17:01 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:17:01 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:17:01 --> Utf8 Class Initialized
INFO - 2021-07-05 11:17:01 --> URI Class Initialized
INFO - 2021-07-05 11:17:01 --> Router Class Initialized
INFO - 2021-07-05 11:17:01 --> Output Class Initialized
INFO - 2021-07-05 11:17:01 --> Security Class Initialized
DEBUG - 2021-07-05 11:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:17:01 --> Input Class Initialized
INFO - 2021-07-05 11:17:01 --> Language Class Initialized
INFO - 2021-07-05 11:17:01 --> Loader Class Initialized
INFO - 2021-07-05 11:17:01 --> Helper loaded: html_helper
INFO - 2021-07-05 11:17:01 --> Helper loaded: url_helper
INFO - 2021-07-05 11:17:01 --> Helper loaded: form_helper
INFO - 2021-07-05 11:17:01 --> Database Driver Class Initialized
INFO - 2021-07-05 11:17:02 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:17:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:17:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:17:02 --> Encryption Class Initialized
INFO - 2021-07-05 11:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:17:02 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:17:02 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:17:02 --> Model "user_model" initialized
INFO - 2021-07-05 11:17:02 --> Model "role_model" initialized
INFO - 2021-07-05 11:17:02 --> Controller Class Initialized
INFO - 2021-07-05 11:17:02 --> Helper loaded: language_helper
INFO - 2021-07-05 11:17:02 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:17:02 --> Model "Customer_model" initialized
INFO - 2021-07-05 11:17:02 --> Model "Product_model" initialized
INFO - 2021-07-05 11:17:02 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 11:17:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 11:17:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 11:17:02 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 11:17:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 11:17:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:17:02 --> Final output sent to browser
DEBUG - 2021-07-05 11:17:02 --> Total execution time: 0.0855
INFO - 2021-07-05 11:17:40 --> Config Class Initialized
INFO - 2021-07-05 11:17:40 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:17:40 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:17:40 --> Utf8 Class Initialized
INFO - 2021-07-05 11:17:40 --> URI Class Initialized
INFO - 2021-07-05 11:17:40 --> Router Class Initialized
INFO - 2021-07-05 11:17:40 --> Output Class Initialized
INFO - 2021-07-05 11:17:40 --> Security Class Initialized
DEBUG - 2021-07-05 11:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:17:40 --> Input Class Initialized
INFO - 2021-07-05 11:17:40 --> Language Class Initialized
INFO - 2021-07-05 11:17:40 --> Loader Class Initialized
INFO - 2021-07-05 11:17:40 --> Helper loaded: html_helper
INFO - 2021-07-05 11:17:40 --> Helper loaded: url_helper
INFO - 2021-07-05 11:17:40 --> Helper loaded: form_helper
INFO - 2021-07-05 11:17:40 --> Database Driver Class Initialized
INFO - 2021-07-05 11:17:40 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:17:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:17:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:17:40 --> Encryption Class Initialized
INFO - 2021-07-05 11:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:17:40 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:17:40 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:17:40 --> Model "user_model" initialized
INFO - 2021-07-05 11:17:40 --> Model "role_model" initialized
INFO - 2021-07-05 11:17:40 --> Controller Class Initialized
INFO - 2021-07-05 11:17:40 --> Helper loaded: language_helper
INFO - 2021-07-05 11:17:40 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:17:40 --> Model "Product_model" initialized
INFO - 2021-07-05 11:17:40 --> Final output sent to browser
DEBUG - 2021-07-05 11:17:40 --> Total execution time: 0.0675
INFO - 2021-07-05 11:19:07 --> Config Class Initialized
INFO - 2021-07-05 11:19:07 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:19:07 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:19:07 --> Utf8 Class Initialized
INFO - 2021-07-05 11:19:07 --> URI Class Initialized
INFO - 2021-07-05 11:19:07 --> Router Class Initialized
INFO - 2021-07-05 11:19:07 --> Output Class Initialized
INFO - 2021-07-05 11:19:07 --> Security Class Initialized
DEBUG - 2021-07-05 11:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:19:07 --> Input Class Initialized
INFO - 2021-07-05 11:19:07 --> Language Class Initialized
INFO - 2021-07-05 11:19:07 --> Loader Class Initialized
INFO - 2021-07-05 11:19:07 --> Helper loaded: html_helper
INFO - 2021-07-05 11:19:07 --> Helper loaded: url_helper
INFO - 2021-07-05 11:19:07 --> Helper loaded: form_helper
INFO - 2021-07-05 11:19:07 --> Database Driver Class Initialized
INFO - 2021-07-05 11:19:07 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:19:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:19:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:19:07 --> Encryption Class Initialized
INFO - 2021-07-05 11:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:19:07 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:19:07 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:19:07 --> Model "user_model" initialized
INFO - 2021-07-05 11:19:07 --> Model "role_model" initialized
INFO - 2021-07-05 11:19:07 --> Controller Class Initialized
INFO - 2021-07-05 11:19:07 --> Helper loaded: language_helper
INFO - 2021-07-05 11:19:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:19:07 --> Model "Customer_model" initialized
INFO - 2021-07-05 11:19:07 --> Model "Product_model" initialized
INFO - 2021-07-05 11:19:07 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 11:19:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 11:19:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 11:19:07 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 11:19:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 11:19:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:19:07 --> Final output sent to browser
DEBUG - 2021-07-05 11:19:07 --> Total execution time: 0.0885
INFO - 2021-07-05 11:19:45 --> Config Class Initialized
INFO - 2021-07-05 11:19:45 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:19:45 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:19:46 --> Utf8 Class Initialized
INFO - 2021-07-05 11:19:46 --> URI Class Initialized
INFO - 2021-07-05 11:19:46 --> Router Class Initialized
INFO - 2021-07-05 11:19:46 --> Output Class Initialized
INFO - 2021-07-05 11:19:46 --> Security Class Initialized
DEBUG - 2021-07-05 11:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:19:46 --> Input Class Initialized
INFO - 2021-07-05 11:19:46 --> Language Class Initialized
INFO - 2021-07-05 11:19:46 --> Loader Class Initialized
INFO - 2021-07-05 11:19:46 --> Helper loaded: html_helper
INFO - 2021-07-05 11:19:46 --> Helper loaded: url_helper
INFO - 2021-07-05 11:19:46 --> Helper loaded: form_helper
INFO - 2021-07-05 11:19:46 --> Database Driver Class Initialized
INFO - 2021-07-05 11:19:46 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:19:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:19:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:19:46 --> Encryption Class Initialized
INFO - 2021-07-05 11:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:19:46 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:19:46 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:19:46 --> Model "user_model" initialized
INFO - 2021-07-05 11:19:46 --> Model "role_model" initialized
INFO - 2021-07-05 11:19:46 --> Controller Class Initialized
INFO - 2021-07-05 11:19:46 --> Helper loaded: language_helper
INFO - 2021-07-05 11:19:46 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:19:46 --> Model "Product_model" initialized
INFO - 2021-07-05 11:19:46 --> Final output sent to browser
DEBUG - 2021-07-05 11:19:46 --> Total execution time: 0.1002
INFO - 2021-07-05 11:20:16 --> Config Class Initialized
INFO - 2021-07-05 11:20:16 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:20:16 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:20:16 --> Utf8 Class Initialized
INFO - 2021-07-05 11:20:16 --> URI Class Initialized
INFO - 2021-07-05 11:20:16 --> Router Class Initialized
INFO - 2021-07-05 11:20:16 --> Output Class Initialized
INFO - 2021-07-05 11:20:16 --> Security Class Initialized
DEBUG - 2021-07-05 11:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:20:16 --> Input Class Initialized
INFO - 2021-07-05 11:20:16 --> Language Class Initialized
INFO - 2021-07-05 11:20:16 --> Loader Class Initialized
INFO - 2021-07-05 11:20:16 --> Helper loaded: html_helper
INFO - 2021-07-05 11:20:16 --> Helper loaded: url_helper
INFO - 2021-07-05 11:20:16 --> Helper loaded: form_helper
INFO - 2021-07-05 11:20:16 --> Database Driver Class Initialized
INFO - 2021-07-05 11:20:16 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:20:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:20:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:20:16 --> Encryption Class Initialized
INFO - 2021-07-05 11:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:20:16 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:20:16 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:20:16 --> Model "user_model" initialized
INFO - 2021-07-05 11:20:16 --> Model "role_model" initialized
INFO - 2021-07-05 11:20:16 --> Controller Class Initialized
INFO - 2021-07-05 11:20:16 --> Helper loaded: language_helper
INFO - 2021-07-05 11:20:16 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:20:16 --> Model "Customer_model" initialized
INFO - 2021-07-05 11:20:16 --> Model "Product_model" initialized
INFO - 2021-07-05 11:20:16 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 11:20:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 11:20:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 11:20:16 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 11:20:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 11:20:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:20:16 --> Final output sent to browser
DEBUG - 2021-07-05 11:20:16 --> Total execution time: 0.0744
INFO - 2021-07-05 11:20:58 --> Config Class Initialized
INFO - 2021-07-05 11:20:58 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:20:58 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:20:58 --> Utf8 Class Initialized
INFO - 2021-07-05 11:20:58 --> URI Class Initialized
INFO - 2021-07-05 11:20:58 --> Router Class Initialized
INFO - 2021-07-05 11:20:58 --> Output Class Initialized
INFO - 2021-07-05 11:20:58 --> Security Class Initialized
DEBUG - 2021-07-05 11:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:20:58 --> Input Class Initialized
INFO - 2021-07-05 11:20:58 --> Language Class Initialized
INFO - 2021-07-05 11:20:58 --> Loader Class Initialized
INFO - 2021-07-05 11:20:58 --> Helper loaded: html_helper
INFO - 2021-07-05 11:20:58 --> Helper loaded: url_helper
INFO - 2021-07-05 11:20:58 --> Helper loaded: form_helper
INFO - 2021-07-05 11:20:58 --> Database Driver Class Initialized
INFO - 2021-07-05 11:20:58 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:20:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:20:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:20:58 --> Encryption Class Initialized
INFO - 2021-07-05 11:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:20:58 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:20:58 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:20:58 --> Model "user_model" initialized
INFO - 2021-07-05 11:20:58 --> Model "role_model" initialized
INFO - 2021-07-05 11:20:58 --> Controller Class Initialized
INFO - 2021-07-05 11:20:58 --> Helper loaded: language_helper
INFO - 2021-07-05 11:20:58 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:20:58 --> Model "Customer_model" initialized
INFO - 2021-07-05 11:20:58 --> Model "Product_model" initialized
INFO - 2021-07-05 11:20:58 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 11:20:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 11:20:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 11:20:58 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 11:20:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 11:20:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:20:58 --> Final output sent to browser
DEBUG - 2021-07-05 11:20:58 --> Total execution time: 0.0739
INFO - 2021-07-05 11:21:32 --> Config Class Initialized
INFO - 2021-07-05 11:21:32 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:21:32 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:21:32 --> Utf8 Class Initialized
INFO - 2021-07-05 11:21:32 --> URI Class Initialized
INFO - 2021-07-05 11:21:32 --> Router Class Initialized
INFO - 2021-07-05 11:21:32 --> Output Class Initialized
INFO - 2021-07-05 11:21:32 --> Security Class Initialized
DEBUG - 2021-07-05 11:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:21:32 --> Input Class Initialized
INFO - 2021-07-05 11:21:32 --> Language Class Initialized
INFO - 2021-07-05 11:21:32 --> Loader Class Initialized
INFO - 2021-07-05 11:21:32 --> Helper loaded: html_helper
INFO - 2021-07-05 11:21:32 --> Helper loaded: url_helper
INFO - 2021-07-05 11:21:32 --> Helper loaded: form_helper
INFO - 2021-07-05 11:21:32 --> Database Driver Class Initialized
INFO - 2021-07-05 11:21:32 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:21:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:21:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:21:32 --> Encryption Class Initialized
INFO - 2021-07-05 11:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:21:32 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:21:32 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:21:32 --> Model "user_model" initialized
INFO - 2021-07-05 11:21:32 --> Model "role_model" initialized
INFO - 2021-07-05 11:21:32 --> Controller Class Initialized
INFO - 2021-07-05 11:21:32 --> Helper loaded: language_helper
INFO - 2021-07-05 11:21:32 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:21:32 --> Model "Product_model" initialized
INFO - 2021-07-05 11:21:32 --> Final output sent to browser
DEBUG - 2021-07-05 11:21:32 --> Total execution time: 0.0865
INFO - 2021-07-05 11:24:05 --> Config Class Initialized
INFO - 2021-07-05 11:24:05 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:24:05 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:24:05 --> Utf8 Class Initialized
INFO - 2021-07-05 11:24:05 --> URI Class Initialized
INFO - 2021-07-05 11:24:05 --> Router Class Initialized
INFO - 2021-07-05 11:24:05 --> Output Class Initialized
INFO - 2021-07-05 11:24:05 --> Security Class Initialized
DEBUG - 2021-07-05 11:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:24:05 --> Input Class Initialized
INFO - 2021-07-05 11:24:05 --> Language Class Initialized
INFO - 2021-07-05 11:24:05 --> Loader Class Initialized
INFO - 2021-07-05 11:24:05 --> Helper loaded: html_helper
INFO - 2021-07-05 11:24:05 --> Helper loaded: url_helper
INFO - 2021-07-05 11:24:05 --> Helper loaded: form_helper
INFO - 2021-07-05 11:24:05 --> Database Driver Class Initialized
INFO - 2021-07-05 11:24:05 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:24:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:24:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:24:05 --> Encryption Class Initialized
INFO - 2021-07-05 11:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:24:05 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:24:05 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:24:05 --> Model "user_model" initialized
INFO - 2021-07-05 11:24:05 --> Model "role_model" initialized
INFO - 2021-07-05 11:24:05 --> Controller Class Initialized
INFO - 2021-07-05 11:24:05 --> Helper loaded: language_helper
INFO - 2021-07-05 11:24:05 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:24:05 --> Model "Customer_model" initialized
INFO - 2021-07-05 11:24:05 --> Model "Product_model" initialized
INFO - 2021-07-05 11:24:05 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 11:24:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 11:24:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 11:24:05 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 11:24:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 11:24:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:24:05 --> Final output sent to browser
DEBUG - 2021-07-05 11:24:05 --> Total execution time: 0.1289
INFO - 2021-07-05 11:26:02 --> Config Class Initialized
INFO - 2021-07-05 11:26:02 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:26:02 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:26:02 --> Utf8 Class Initialized
INFO - 2021-07-05 11:26:02 --> URI Class Initialized
INFO - 2021-07-05 11:26:02 --> Router Class Initialized
INFO - 2021-07-05 11:26:02 --> Output Class Initialized
INFO - 2021-07-05 11:26:02 --> Security Class Initialized
DEBUG - 2021-07-05 11:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:26:02 --> Input Class Initialized
INFO - 2021-07-05 11:26:02 --> Language Class Initialized
INFO - 2021-07-05 11:26:02 --> Loader Class Initialized
INFO - 2021-07-05 11:26:02 --> Helper loaded: html_helper
INFO - 2021-07-05 11:26:02 --> Helper loaded: url_helper
INFO - 2021-07-05 11:26:02 --> Helper loaded: form_helper
INFO - 2021-07-05 11:26:02 --> Database Driver Class Initialized
INFO - 2021-07-05 11:26:02 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:26:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:26:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:26:02 --> Encryption Class Initialized
INFO - 2021-07-05 11:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:26:02 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:26:02 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:26:02 --> Model "user_model" initialized
INFO - 2021-07-05 11:26:02 --> Model "role_model" initialized
INFO - 2021-07-05 11:26:02 --> Controller Class Initialized
INFO - 2021-07-05 11:26:02 --> Helper loaded: language_helper
INFO - 2021-07-05 11:26:02 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:26:02 --> Model "Customer_model" initialized
INFO - 2021-07-05 11:26:02 --> Model "Product_model" initialized
INFO - 2021-07-05 11:26:02 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 11:26:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 11:26:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 11:26:02 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 11:26:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 11:26:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:26:02 --> Final output sent to browser
DEBUG - 2021-07-05 11:26:02 --> Total execution time: 0.1084
INFO - 2021-07-05 11:26:39 --> Config Class Initialized
INFO - 2021-07-05 11:26:39 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:26:39 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:26:39 --> Utf8 Class Initialized
INFO - 2021-07-05 11:26:39 --> URI Class Initialized
INFO - 2021-07-05 11:26:39 --> Router Class Initialized
INFO - 2021-07-05 11:26:39 --> Output Class Initialized
INFO - 2021-07-05 11:26:39 --> Security Class Initialized
DEBUG - 2021-07-05 11:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:26:39 --> Input Class Initialized
INFO - 2021-07-05 11:26:39 --> Language Class Initialized
INFO - 2021-07-05 11:26:39 --> Loader Class Initialized
INFO - 2021-07-05 11:26:39 --> Helper loaded: html_helper
INFO - 2021-07-05 11:26:39 --> Helper loaded: url_helper
INFO - 2021-07-05 11:26:39 --> Helper loaded: form_helper
INFO - 2021-07-05 11:26:39 --> Database Driver Class Initialized
INFO - 2021-07-05 11:26:39 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:26:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:26:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:26:39 --> Encryption Class Initialized
INFO - 2021-07-05 11:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:26:39 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:26:39 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:26:39 --> Model "user_model" initialized
INFO - 2021-07-05 11:26:39 --> Model "role_model" initialized
INFO - 2021-07-05 11:26:39 --> Controller Class Initialized
INFO - 2021-07-05 11:26:39 --> Helper loaded: language_helper
INFO - 2021-07-05 11:26:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:26:39 --> Final output sent to browser
DEBUG - 2021-07-05 11:26:39 --> Total execution time: 0.0756
INFO - 2021-07-05 11:27:18 --> Config Class Initialized
INFO - 2021-07-05 11:27:18 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:27:18 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:27:18 --> Utf8 Class Initialized
INFO - 2021-07-05 11:27:18 --> URI Class Initialized
INFO - 2021-07-05 11:27:18 --> Router Class Initialized
INFO - 2021-07-05 11:27:18 --> Output Class Initialized
INFO - 2021-07-05 11:27:18 --> Security Class Initialized
DEBUG - 2021-07-05 11:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:27:18 --> Input Class Initialized
INFO - 2021-07-05 11:27:18 --> Language Class Initialized
INFO - 2021-07-05 11:27:18 --> Loader Class Initialized
INFO - 2021-07-05 11:27:18 --> Helper loaded: html_helper
INFO - 2021-07-05 11:27:18 --> Helper loaded: url_helper
INFO - 2021-07-05 11:27:18 --> Helper loaded: form_helper
INFO - 2021-07-05 11:27:18 --> Database Driver Class Initialized
INFO - 2021-07-05 11:27:18 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:27:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:27:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:27:18 --> Encryption Class Initialized
INFO - 2021-07-05 11:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:27:18 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:27:18 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:27:18 --> Model "user_model" initialized
INFO - 2021-07-05 11:27:18 --> Model "role_model" initialized
INFO - 2021-07-05 11:27:18 --> Controller Class Initialized
INFO - 2021-07-05 11:27:18 --> Helper loaded: language_helper
INFO - 2021-07-05 11:27:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:27:18 --> Model "Customer_model" initialized
INFO - 2021-07-05 11:27:18 --> Model "Product_model" initialized
INFO - 2021-07-05 11:27:18 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 11:27:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 11:27:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 11:27:18 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 11:27:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 11:27:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:27:18 --> Final output sent to browser
DEBUG - 2021-07-05 11:27:18 --> Total execution time: 0.0696
INFO - 2021-07-05 11:28:00 --> Config Class Initialized
INFO - 2021-07-05 11:28:00 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:28:00 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:28:00 --> Utf8 Class Initialized
INFO - 2021-07-05 11:28:00 --> URI Class Initialized
INFO - 2021-07-05 11:28:00 --> Router Class Initialized
INFO - 2021-07-05 11:28:00 --> Output Class Initialized
INFO - 2021-07-05 11:28:00 --> Security Class Initialized
DEBUG - 2021-07-05 11:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:28:00 --> Input Class Initialized
INFO - 2021-07-05 11:28:00 --> Language Class Initialized
INFO - 2021-07-05 11:28:00 --> Loader Class Initialized
INFO - 2021-07-05 11:28:00 --> Helper loaded: html_helper
INFO - 2021-07-05 11:28:00 --> Helper loaded: url_helper
INFO - 2021-07-05 11:28:00 --> Helper loaded: form_helper
INFO - 2021-07-05 11:28:00 --> Database Driver Class Initialized
INFO - 2021-07-05 11:28:00 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:28:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:28:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:28:00 --> Encryption Class Initialized
INFO - 2021-07-05 11:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:28:00 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:28:00 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:28:00 --> Model "user_model" initialized
INFO - 2021-07-05 11:28:00 --> Model "role_model" initialized
INFO - 2021-07-05 11:28:00 --> Controller Class Initialized
INFO - 2021-07-05 11:28:00 --> Helper loaded: language_helper
INFO - 2021-07-05 11:28:00 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:28:00 --> Final output sent to browser
DEBUG - 2021-07-05 11:28:00 --> Total execution time: 0.0771
INFO - 2021-07-05 11:33:02 --> Config Class Initialized
INFO - 2021-07-05 11:33:02 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:33:02 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:33:02 --> Utf8 Class Initialized
INFO - 2021-07-05 11:33:02 --> URI Class Initialized
INFO - 2021-07-05 11:33:02 --> Router Class Initialized
INFO - 2021-07-05 11:33:02 --> Output Class Initialized
INFO - 2021-07-05 11:33:02 --> Security Class Initialized
DEBUG - 2021-07-05 11:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:33:02 --> Input Class Initialized
INFO - 2021-07-05 11:33:02 --> Language Class Initialized
INFO - 2021-07-05 11:33:02 --> Loader Class Initialized
INFO - 2021-07-05 11:33:02 --> Helper loaded: html_helper
INFO - 2021-07-05 11:33:02 --> Helper loaded: url_helper
INFO - 2021-07-05 11:33:02 --> Helper loaded: form_helper
INFO - 2021-07-05 11:33:02 --> Database Driver Class Initialized
INFO - 2021-07-05 11:33:02 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:33:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:33:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:33:02 --> Encryption Class Initialized
INFO - 2021-07-05 11:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:33:02 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:33:02 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:33:02 --> Model "user_model" initialized
INFO - 2021-07-05 11:33:02 --> Model "role_model" initialized
INFO - 2021-07-05 11:33:02 --> Controller Class Initialized
INFO - 2021-07-05 11:33:02 --> Helper loaded: language_helper
INFO - 2021-07-05 11:33:02 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:33:02 --> Model "Customer_model" initialized
INFO - 2021-07-05 11:33:02 --> Model "Product_model" initialized
INFO - 2021-07-05 11:33:02 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 11:33:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 11:33:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 11:33:02 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 11:33:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 11:33:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:33:02 --> Final output sent to browser
DEBUG - 2021-07-05 11:33:02 --> Total execution time: 0.0835
INFO - 2021-07-05 11:33:47 --> Config Class Initialized
INFO - 2021-07-05 11:33:47 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:33:47 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:33:47 --> Utf8 Class Initialized
INFO - 2021-07-05 11:33:47 --> URI Class Initialized
INFO - 2021-07-05 11:33:47 --> Router Class Initialized
INFO - 2021-07-05 11:33:47 --> Output Class Initialized
INFO - 2021-07-05 11:33:47 --> Security Class Initialized
DEBUG - 2021-07-05 11:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:33:47 --> Input Class Initialized
INFO - 2021-07-05 11:33:47 --> Language Class Initialized
INFO - 2021-07-05 11:33:47 --> Loader Class Initialized
INFO - 2021-07-05 11:33:47 --> Helper loaded: html_helper
INFO - 2021-07-05 11:33:47 --> Helper loaded: url_helper
INFO - 2021-07-05 11:33:47 --> Helper loaded: form_helper
INFO - 2021-07-05 11:33:47 --> Database Driver Class Initialized
INFO - 2021-07-05 11:33:47 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:33:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:33:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:33:47 --> Encryption Class Initialized
INFO - 2021-07-05 11:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:33:47 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:33:47 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:33:47 --> Model "user_model" initialized
INFO - 2021-07-05 11:33:47 --> Model "role_model" initialized
INFO - 2021-07-05 11:33:47 --> Controller Class Initialized
INFO - 2021-07-05 11:33:47 --> Helper loaded: language_helper
INFO - 2021-07-05 11:33:47 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:33:47 --> Model "Product_model" initialized
ERROR - 2021-07-05 11:33:47 --> Severity: error --> Exception: Too few arguments to function Product_model::save_product(), 1 passed in D:\development\web\xampp\htdocs\proadmin\proadmin\application\controllers\Product_controller.php on line 133 and exactly 5 expected D:\development\web\xampp\htdocs\proadmin\proadmin\application\models\Product_model.php 94
INFO - 2021-07-05 11:34:48 --> Config Class Initialized
INFO - 2021-07-05 11:34:48 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:34:48 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:34:48 --> Utf8 Class Initialized
INFO - 2021-07-05 11:34:48 --> URI Class Initialized
INFO - 2021-07-05 11:34:48 --> Router Class Initialized
INFO - 2021-07-05 11:34:48 --> Output Class Initialized
INFO - 2021-07-05 11:34:48 --> Security Class Initialized
DEBUG - 2021-07-05 11:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:34:48 --> Input Class Initialized
INFO - 2021-07-05 11:34:48 --> Language Class Initialized
INFO - 2021-07-05 11:34:48 --> Loader Class Initialized
INFO - 2021-07-05 11:34:48 --> Helper loaded: html_helper
INFO - 2021-07-05 11:34:48 --> Helper loaded: url_helper
INFO - 2021-07-05 11:34:48 --> Helper loaded: form_helper
INFO - 2021-07-05 11:34:48 --> Database Driver Class Initialized
INFO - 2021-07-05 11:34:48 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:34:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:34:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:34:48 --> Encryption Class Initialized
INFO - 2021-07-05 11:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:34:48 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:34:48 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:34:48 --> Model "user_model" initialized
INFO - 2021-07-05 11:34:48 --> Model "role_model" initialized
INFO - 2021-07-05 11:34:48 --> Controller Class Initialized
INFO - 2021-07-05 11:34:48 --> Helper loaded: language_helper
INFO - 2021-07-05 11:34:48 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:34:48 --> Model "Customer_model" initialized
INFO - 2021-07-05 11:34:48 --> Model "Product_model" initialized
INFO - 2021-07-05 11:34:48 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 11:34:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 11:34:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 11:34:48 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 11:34:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 11:34:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:34:48 --> Final output sent to browser
DEBUG - 2021-07-05 11:34:48 --> Total execution time: 0.0778
INFO - 2021-07-05 11:35:30 --> Config Class Initialized
INFO - 2021-07-05 11:35:30 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:35:30 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:35:30 --> Utf8 Class Initialized
INFO - 2021-07-05 11:35:30 --> URI Class Initialized
INFO - 2021-07-05 11:35:30 --> Router Class Initialized
INFO - 2021-07-05 11:35:30 --> Output Class Initialized
INFO - 2021-07-05 11:35:30 --> Security Class Initialized
DEBUG - 2021-07-05 11:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:35:30 --> Input Class Initialized
INFO - 2021-07-05 11:35:30 --> Language Class Initialized
INFO - 2021-07-05 11:35:30 --> Loader Class Initialized
INFO - 2021-07-05 11:35:30 --> Helper loaded: html_helper
INFO - 2021-07-05 11:35:30 --> Helper loaded: url_helper
INFO - 2021-07-05 11:35:30 --> Helper loaded: form_helper
INFO - 2021-07-05 11:35:30 --> Database Driver Class Initialized
INFO - 2021-07-05 11:35:30 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:35:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:35:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:35:30 --> Encryption Class Initialized
INFO - 2021-07-05 11:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:35:30 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:35:30 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:35:30 --> Model "user_model" initialized
INFO - 2021-07-05 11:35:30 --> Model "role_model" initialized
INFO - 2021-07-05 11:35:30 --> Controller Class Initialized
INFO - 2021-07-05 11:35:30 --> Helper loaded: language_helper
INFO - 2021-07-05 11:35:30 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:35:30 --> Model "Product_model" initialized
INFO - 2021-07-05 11:35:30 --> Final output sent to browser
DEBUG - 2021-07-05 11:35:30 --> Total execution time: 0.0939
INFO - 2021-07-05 11:39:21 --> Config Class Initialized
INFO - 2021-07-05 11:39:21 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:39:21 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:39:21 --> Utf8 Class Initialized
INFO - 2021-07-05 11:39:21 --> URI Class Initialized
INFO - 2021-07-05 11:39:21 --> Router Class Initialized
INFO - 2021-07-05 11:39:21 --> Output Class Initialized
INFO - 2021-07-05 11:39:21 --> Security Class Initialized
DEBUG - 2021-07-05 11:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:39:21 --> Input Class Initialized
INFO - 2021-07-05 11:39:21 --> Language Class Initialized
INFO - 2021-07-05 11:39:21 --> Loader Class Initialized
INFO - 2021-07-05 11:39:21 --> Helper loaded: html_helper
INFO - 2021-07-05 11:39:21 --> Helper loaded: url_helper
INFO - 2021-07-05 11:39:21 --> Helper loaded: form_helper
INFO - 2021-07-05 11:39:21 --> Database Driver Class Initialized
INFO - 2021-07-05 11:39:21 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:39:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:39:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:39:21 --> Encryption Class Initialized
INFO - 2021-07-05 11:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:39:21 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:39:21 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:39:21 --> Model "user_model" initialized
INFO - 2021-07-05 11:39:21 --> Model "role_model" initialized
INFO - 2021-07-05 11:39:21 --> Controller Class Initialized
INFO - 2021-07-05 11:39:21 --> Helper loaded: language_helper
INFO - 2021-07-05 11:39:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:39:21 --> Model "Customer_model" initialized
INFO - 2021-07-05 11:39:21 --> Model "Product_model" initialized
INFO - 2021-07-05 11:39:21 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 11:39:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 11:39:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 11:39:21 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 11:39:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 11:39:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:39:21 --> Final output sent to browser
DEBUG - 2021-07-05 11:39:21 --> Total execution time: 0.1762
INFO - 2021-07-05 11:40:09 --> Config Class Initialized
INFO - 2021-07-05 11:40:09 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:40:09 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:40:09 --> Utf8 Class Initialized
INFO - 2021-07-05 11:40:09 --> URI Class Initialized
INFO - 2021-07-05 11:40:09 --> Router Class Initialized
INFO - 2021-07-05 11:40:09 --> Output Class Initialized
INFO - 2021-07-05 11:40:09 --> Security Class Initialized
DEBUG - 2021-07-05 11:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:40:09 --> Input Class Initialized
INFO - 2021-07-05 11:40:09 --> Language Class Initialized
INFO - 2021-07-05 11:40:09 --> Loader Class Initialized
INFO - 2021-07-05 11:40:09 --> Helper loaded: html_helper
INFO - 2021-07-05 11:40:09 --> Helper loaded: url_helper
INFO - 2021-07-05 11:40:09 --> Helper loaded: form_helper
INFO - 2021-07-05 11:40:09 --> Database Driver Class Initialized
INFO - 2021-07-05 11:40:09 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:40:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:40:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:40:09 --> Encryption Class Initialized
INFO - 2021-07-05 11:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:40:09 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:40:09 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:40:09 --> Model "user_model" initialized
INFO - 2021-07-05 11:40:09 --> Model "role_model" initialized
INFO - 2021-07-05 11:40:09 --> Controller Class Initialized
INFO - 2021-07-05 11:40:09 --> Helper loaded: language_helper
INFO - 2021-07-05 11:40:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:40:09 --> Model "Customer_model" initialized
INFO - 2021-07-05 11:40:09 --> Model "Product_model" initialized
INFO - 2021-07-05 11:40:09 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 11:40:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 11:40:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 11:40:09 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 11:40:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 11:40:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:40:09 --> Final output sent to browser
DEBUG - 2021-07-05 11:40:09 --> Total execution time: 0.0763
INFO - 2021-07-05 11:40:35 --> Config Class Initialized
INFO - 2021-07-05 11:40:35 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:40:35 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:40:35 --> Utf8 Class Initialized
INFO - 2021-07-05 11:40:35 --> URI Class Initialized
INFO - 2021-07-05 11:40:35 --> Router Class Initialized
INFO - 2021-07-05 11:40:35 --> Output Class Initialized
INFO - 2021-07-05 11:40:35 --> Security Class Initialized
DEBUG - 2021-07-05 11:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:40:35 --> Input Class Initialized
INFO - 2021-07-05 11:40:35 --> Language Class Initialized
INFO - 2021-07-05 11:40:35 --> Loader Class Initialized
INFO - 2021-07-05 11:40:35 --> Helper loaded: html_helper
INFO - 2021-07-05 11:40:35 --> Helper loaded: url_helper
INFO - 2021-07-05 11:40:35 --> Helper loaded: form_helper
INFO - 2021-07-05 11:40:35 --> Database Driver Class Initialized
INFO - 2021-07-05 11:40:35 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:40:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:40:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:40:35 --> Encryption Class Initialized
INFO - 2021-07-05 11:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:40:35 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:40:35 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:40:35 --> Model "user_model" initialized
INFO - 2021-07-05 11:40:35 --> Model "role_model" initialized
INFO - 2021-07-05 11:40:35 --> Controller Class Initialized
INFO - 2021-07-05 11:40:35 --> Helper loaded: language_helper
INFO - 2021-07-05 11:40:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:40:35 --> Model "Customer_model" initialized
INFO - 2021-07-05 11:40:35 --> Model "Product_model" initialized
INFO - 2021-07-05 11:40:35 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 11:40:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 11:40:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 11:40:35 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 11:40:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 11:40:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:40:35 --> Final output sent to browser
DEBUG - 2021-07-05 11:40:35 --> Total execution time: 0.0713
INFO - 2021-07-05 11:41:29 --> Config Class Initialized
INFO - 2021-07-05 11:41:29 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:41:29 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:41:29 --> Utf8 Class Initialized
INFO - 2021-07-05 11:41:29 --> URI Class Initialized
INFO - 2021-07-05 11:41:29 --> Router Class Initialized
INFO - 2021-07-05 11:41:29 --> Output Class Initialized
INFO - 2021-07-05 11:41:29 --> Security Class Initialized
DEBUG - 2021-07-05 11:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:41:29 --> Input Class Initialized
INFO - 2021-07-05 11:41:29 --> Language Class Initialized
INFO - 2021-07-05 11:41:29 --> Loader Class Initialized
INFO - 2021-07-05 11:41:29 --> Helper loaded: html_helper
INFO - 2021-07-05 11:41:29 --> Helper loaded: url_helper
INFO - 2021-07-05 11:41:29 --> Helper loaded: form_helper
INFO - 2021-07-05 11:41:29 --> Database Driver Class Initialized
INFO - 2021-07-05 11:41:29 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:41:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:41:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:41:29 --> Encryption Class Initialized
INFO - 2021-07-05 11:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:41:29 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:41:29 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:41:29 --> Model "user_model" initialized
INFO - 2021-07-05 11:41:29 --> Model "role_model" initialized
INFO - 2021-07-05 11:41:29 --> Controller Class Initialized
INFO - 2021-07-05 11:41:29 --> Helper loaded: language_helper
INFO - 2021-07-05 11:41:29 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:41:29 --> Model "Customer_model" initialized
INFO - 2021-07-05 11:41:29 --> Model "Product_model" initialized
INFO - 2021-07-05 11:41:29 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 11:41:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 11:41:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 11:41:29 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 11:41:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 11:41:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:41:29 --> Final output sent to browser
DEBUG - 2021-07-05 11:41:29 --> Total execution time: 0.0743
INFO - 2021-07-05 11:42:03 --> Config Class Initialized
INFO - 2021-07-05 11:42:03 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:42:03 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:42:03 --> Utf8 Class Initialized
INFO - 2021-07-05 11:42:03 --> URI Class Initialized
DEBUG - 2021-07-05 11:42:03 --> No URI present. Default controller set.
INFO - 2021-07-05 11:42:03 --> Router Class Initialized
INFO - 2021-07-05 11:42:03 --> Output Class Initialized
INFO - 2021-07-05 11:42:03 --> Security Class Initialized
DEBUG - 2021-07-05 11:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:42:03 --> Input Class Initialized
INFO - 2021-07-05 11:42:03 --> Language Class Initialized
INFO - 2021-07-05 11:42:03 --> Loader Class Initialized
INFO - 2021-07-05 11:42:03 --> Helper loaded: html_helper
INFO - 2021-07-05 11:42:03 --> Helper loaded: url_helper
INFO - 2021-07-05 11:42:03 --> Helper loaded: form_helper
INFO - 2021-07-05 11:42:03 --> Database Driver Class Initialized
INFO - 2021-07-05 11:42:03 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:42:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:42:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:42:03 --> Encryption Class Initialized
INFO - 2021-07-05 11:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:42:03 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:42:03 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:42:03 --> Model "user_model" initialized
INFO - 2021-07-05 11:42:03 --> Model "role_model" initialized
INFO - 2021-07-05 11:42:03 --> Controller Class Initialized
INFO - 2021-07-05 11:42:03 --> Helper loaded: language_helper
INFO - 2021-07-05 11:42:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:42:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 11:42:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 11:42:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 11:42:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:42:03 --> Final output sent to browser
DEBUG - 2021-07-05 11:42:03 --> Total execution time: 0.0686
INFO - 2021-07-05 11:42:21 --> Config Class Initialized
INFO - 2021-07-05 11:42:21 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:42:21 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:42:21 --> Utf8 Class Initialized
INFO - 2021-07-05 11:42:21 --> URI Class Initialized
DEBUG - 2021-07-05 11:42:21 --> No URI present. Default controller set.
INFO - 2021-07-05 11:42:21 --> Router Class Initialized
INFO - 2021-07-05 11:42:21 --> Output Class Initialized
INFO - 2021-07-05 11:42:21 --> Security Class Initialized
DEBUG - 2021-07-05 11:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:42:21 --> Input Class Initialized
INFO - 2021-07-05 11:42:21 --> Language Class Initialized
INFO - 2021-07-05 11:42:21 --> Loader Class Initialized
INFO - 2021-07-05 11:42:21 --> Helper loaded: html_helper
INFO - 2021-07-05 11:42:21 --> Helper loaded: url_helper
INFO - 2021-07-05 11:42:21 --> Helper loaded: form_helper
INFO - 2021-07-05 11:42:21 --> Database Driver Class Initialized
INFO - 2021-07-05 11:42:21 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:42:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:42:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:42:21 --> Encryption Class Initialized
INFO - 2021-07-05 11:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:42:21 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:42:21 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:42:21 --> Model "user_model" initialized
INFO - 2021-07-05 11:42:21 --> Model "role_model" initialized
INFO - 2021-07-05 11:42:21 --> Controller Class Initialized
INFO - 2021-07-05 11:42:21 --> Helper loaded: language_helper
INFO - 2021-07-05 11:42:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:42:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 11:42:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 11:42:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 11:42:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:42:21 --> Final output sent to browser
DEBUG - 2021-07-05 11:42:21 --> Total execution time: 0.0695
INFO - 2021-07-05 11:42:42 --> Config Class Initialized
INFO - 2021-07-05 11:42:42 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:42:43 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:42:43 --> Utf8 Class Initialized
INFO - 2021-07-05 11:42:43 --> URI Class Initialized
INFO - 2021-07-05 11:42:43 --> Router Class Initialized
INFO - 2021-07-05 11:42:43 --> Output Class Initialized
INFO - 2021-07-05 11:42:43 --> Security Class Initialized
DEBUG - 2021-07-05 11:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:42:43 --> Input Class Initialized
INFO - 2021-07-05 11:42:43 --> Language Class Initialized
INFO - 2021-07-05 11:42:43 --> Loader Class Initialized
INFO - 2021-07-05 11:42:43 --> Helper loaded: html_helper
INFO - 2021-07-05 11:42:43 --> Helper loaded: url_helper
INFO - 2021-07-05 11:42:43 --> Helper loaded: form_helper
INFO - 2021-07-05 11:42:43 --> Database Driver Class Initialized
INFO - 2021-07-05 11:42:43 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:42:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:42:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:42:43 --> Encryption Class Initialized
INFO - 2021-07-05 11:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:42:43 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:42:43 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:42:43 --> Model "user_model" initialized
INFO - 2021-07-05 11:42:43 --> Model "role_model" initialized
INFO - 2021-07-05 11:42:43 --> Controller Class Initialized
INFO - 2021-07-05 11:42:43 --> Helper loaded: language_helper
INFO - 2021-07-05 11:42:43 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:42:43 --> Model "Customer_model" initialized
INFO - 2021-07-05 11:42:43 --> Model "Product_model" initialized
INFO - 2021-07-05 11:42:43 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 11:42:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 11:42:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 11:42:43 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 11:42:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 11:42:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:42:43 --> Final output sent to browser
DEBUG - 2021-07-05 11:42:43 --> Total execution time: 0.0822
INFO - 2021-07-05 11:43:27 --> Config Class Initialized
INFO - 2021-07-05 11:43:27 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:43:27 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:43:27 --> Utf8 Class Initialized
INFO - 2021-07-05 11:43:27 --> URI Class Initialized
INFO - 2021-07-05 11:43:27 --> Router Class Initialized
INFO - 2021-07-05 11:43:27 --> Output Class Initialized
INFO - 2021-07-05 11:43:27 --> Security Class Initialized
DEBUG - 2021-07-05 11:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:43:27 --> Input Class Initialized
INFO - 2021-07-05 11:43:27 --> Language Class Initialized
INFO - 2021-07-05 11:43:27 --> Loader Class Initialized
INFO - 2021-07-05 11:43:27 --> Helper loaded: html_helper
INFO - 2021-07-05 11:43:27 --> Helper loaded: url_helper
INFO - 2021-07-05 11:43:27 --> Helper loaded: form_helper
INFO - 2021-07-05 11:43:27 --> Database Driver Class Initialized
INFO - 2021-07-05 11:43:27 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:43:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:43:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:43:27 --> Encryption Class Initialized
INFO - 2021-07-05 11:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:43:27 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:43:27 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:43:27 --> Model "user_model" initialized
INFO - 2021-07-05 11:43:27 --> Model "role_model" initialized
INFO - 2021-07-05 11:43:27 --> Controller Class Initialized
INFO - 2021-07-05 11:43:27 --> Helper loaded: language_helper
INFO - 2021-07-05 11:43:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:43:27 --> Model "Customer_model" initialized
INFO - 2021-07-05 11:43:27 --> Model "Product_model" initialized
INFO - 2021-07-05 11:43:27 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 11:43:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 11:43:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 11:43:27 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 11:43:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 11:43:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:43:27 --> Final output sent to browser
DEBUG - 2021-07-05 11:43:27 --> Total execution time: 0.0768
INFO - 2021-07-05 11:44:01 --> Config Class Initialized
INFO - 2021-07-05 11:44:01 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:44:01 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:44:01 --> Utf8 Class Initialized
INFO - 2021-07-05 11:44:01 --> URI Class Initialized
INFO - 2021-07-05 11:44:01 --> Router Class Initialized
INFO - 2021-07-05 11:44:01 --> Output Class Initialized
INFO - 2021-07-05 11:44:01 --> Security Class Initialized
DEBUG - 2021-07-05 11:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:44:01 --> Input Class Initialized
INFO - 2021-07-05 11:44:01 --> Language Class Initialized
INFO - 2021-07-05 11:44:01 --> Loader Class Initialized
INFO - 2021-07-05 11:44:01 --> Helper loaded: html_helper
INFO - 2021-07-05 11:44:01 --> Helper loaded: url_helper
INFO - 2021-07-05 11:44:01 --> Helper loaded: form_helper
INFO - 2021-07-05 11:44:01 --> Database Driver Class Initialized
INFO - 2021-07-05 11:44:01 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:44:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:44:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:44:01 --> Encryption Class Initialized
INFO - 2021-07-05 11:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:44:01 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:44:01 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:44:01 --> Model "user_model" initialized
INFO - 2021-07-05 11:44:01 --> Model "role_model" initialized
INFO - 2021-07-05 11:44:01 --> Controller Class Initialized
INFO - 2021-07-05 11:44:01 --> Helper loaded: language_helper
INFO - 2021-07-05 11:44:01 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:44:01 --> Final output sent to browser
DEBUG - 2021-07-05 11:44:01 --> Total execution time: 0.0646
INFO - 2021-07-05 11:44:02 --> Config Class Initialized
INFO - 2021-07-05 11:44:02 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:44:02 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:44:02 --> Utf8 Class Initialized
INFO - 2021-07-05 11:44:02 --> URI Class Initialized
DEBUG - 2021-07-05 11:44:02 --> No URI present. Default controller set.
INFO - 2021-07-05 11:44:02 --> Router Class Initialized
INFO - 2021-07-05 11:44:02 --> Output Class Initialized
INFO - 2021-07-05 11:44:02 --> Security Class Initialized
DEBUG - 2021-07-05 11:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:44:02 --> Input Class Initialized
INFO - 2021-07-05 11:44:02 --> Language Class Initialized
INFO - 2021-07-05 11:44:02 --> Loader Class Initialized
INFO - 2021-07-05 11:44:02 --> Helper loaded: html_helper
INFO - 2021-07-05 11:44:02 --> Helper loaded: url_helper
INFO - 2021-07-05 11:44:02 --> Helper loaded: form_helper
INFO - 2021-07-05 11:44:02 --> Database Driver Class Initialized
INFO - 2021-07-05 11:44:02 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:44:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:44:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:44:02 --> Encryption Class Initialized
INFO - 2021-07-05 11:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:44:02 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:44:02 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:44:02 --> Model "user_model" initialized
INFO - 2021-07-05 11:44:02 --> Model "role_model" initialized
INFO - 2021-07-05 11:44:02 --> Controller Class Initialized
INFO - 2021-07-05 11:44:02 --> Helper loaded: language_helper
INFO - 2021-07-05 11:44:02 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:44:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\login.php
INFO - 2021-07-05 11:44:02 --> Final output sent to browser
DEBUG - 2021-07-05 11:44:02 --> Total execution time: 0.1045
INFO - 2021-07-05 11:44:19 --> Config Class Initialized
INFO - 2021-07-05 11:44:19 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:44:19 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:44:19 --> Utf8 Class Initialized
INFO - 2021-07-05 11:44:19 --> URI Class Initialized
INFO - 2021-07-05 11:44:19 --> Router Class Initialized
INFO - 2021-07-05 11:44:19 --> Output Class Initialized
INFO - 2021-07-05 11:44:19 --> Security Class Initialized
DEBUG - 2021-07-05 11:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:44:19 --> Input Class Initialized
INFO - 2021-07-05 11:44:19 --> Language Class Initialized
INFO - 2021-07-05 11:44:19 --> Loader Class Initialized
INFO - 2021-07-05 11:44:19 --> Helper loaded: html_helper
INFO - 2021-07-05 11:44:19 --> Helper loaded: url_helper
INFO - 2021-07-05 11:44:19 --> Helper loaded: form_helper
INFO - 2021-07-05 11:44:19 --> Database Driver Class Initialized
INFO - 2021-07-05 11:44:19 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:44:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:44:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:44:19 --> Encryption Class Initialized
INFO - 2021-07-05 11:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:44:19 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:44:19 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:44:19 --> Model "user_model" initialized
INFO - 2021-07-05 11:44:19 --> Model "role_model" initialized
INFO - 2021-07-05 11:44:19 --> Controller Class Initialized
INFO - 2021-07-05 11:44:19 --> Helper loaded: language_helper
INFO - 2021-07-05 11:44:19 --> Language file loaded: language/english/content_lang.php
DEBUG - 2021-07-05 11:44:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-05 11:44:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-07-05 11:44:19 --> Model "User" initialized
INFO - 2021-07-05 11:44:19 --> Config Class Initialized
INFO - 2021-07-05 11:44:19 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:44:19 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:44:19 --> Utf8 Class Initialized
INFO - 2021-07-05 11:44:19 --> URI Class Initialized
INFO - 2021-07-05 11:44:19 --> Router Class Initialized
INFO - 2021-07-05 11:44:19 --> Output Class Initialized
INFO - 2021-07-05 11:44:19 --> Security Class Initialized
DEBUG - 2021-07-05 11:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:44:19 --> Input Class Initialized
INFO - 2021-07-05 11:44:19 --> Language Class Initialized
INFO - 2021-07-05 11:44:19 --> Loader Class Initialized
INFO - 2021-07-05 11:44:19 --> Helper loaded: html_helper
INFO - 2021-07-05 11:44:19 --> Helper loaded: url_helper
INFO - 2021-07-05 11:44:19 --> Helper loaded: form_helper
INFO - 2021-07-05 11:44:19 --> Database Driver Class Initialized
INFO - 2021-07-05 11:44:19 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:44:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:44:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:44:19 --> Encryption Class Initialized
INFO - 2021-07-05 11:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:44:19 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:44:19 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:44:19 --> Model "user_model" initialized
INFO - 2021-07-05 11:44:19 --> Model "role_model" initialized
INFO - 2021-07-05 11:44:19 --> Controller Class Initialized
INFO - 2021-07-05 11:44:19 --> Helper loaded: language_helper
INFO - 2021-07-05 11:44:19 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:44:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 11:44:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 11:44:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 11:44:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:44:19 --> Final output sent to browser
DEBUG - 2021-07-05 11:44:19 --> Total execution time: 0.0619
INFO - 2021-07-05 11:44:41 --> Config Class Initialized
INFO - 2021-07-05 11:44:41 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:44:41 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:44:41 --> Utf8 Class Initialized
INFO - 2021-07-05 11:44:41 --> URI Class Initialized
INFO - 2021-07-05 11:44:41 --> Router Class Initialized
INFO - 2021-07-05 11:44:41 --> Output Class Initialized
INFO - 2021-07-05 11:44:41 --> Security Class Initialized
DEBUG - 2021-07-05 11:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:44:41 --> Input Class Initialized
INFO - 2021-07-05 11:44:41 --> Language Class Initialized
INFO - 2021-07-05 11:44:41 --> Loader Class Initialized
INFO - 2021-07-05 11:44:41 --> Helper loaded: html_helper
INFO - 2021-07-05 11:44:41 --> Helper loaded: url_helper
INFO - 2021-07-05 11:44:41 --> Helper loaded: form_helper
INFO - 2021-07-05 11:44:41 --> Database Driver Class Initialized
INFO - 2021-07-05 11:44:41 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:44:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:44:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:44:41 --> Encryption Class Initialized
INFO - 2021-07-05 11:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:44:41 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:44:41 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:44:41 --> Model "user_model" initialized
INFO - 2021-07-05 11:44:41 --> Model "role_model" initialized
INFO - 2021-07-05 11:44:41 --> Controller Class Initialized
INFO - 2021-07-05 11:44:41 --> Helper loaded: language_helper
INFO - 2021-07-05 11:44:41 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:44:41 --> Model "Customer_model" initialized
INFO - 2021-07-05 11:44:41 --> Model "Product_model" initialized
INFO - 2021-07-05 11:44:41 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 11:44:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 11:44:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 11:44:41 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 11:44:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 11:44:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:44:41 --> Final output sent to browser
DEBUG - 2021-07-05 11:44:41 --> Total execution time: 0.1247
INFO - 2021-07-05 11:45:38 --> Config Class Initialized
INFO - 2021-07-05 11:45:38 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:45:38 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:45:38 --> Utf8 Class Initialized
INFO - 2021-07-05 11:45:38 --> URI Class Initialized
INFO - 2021-07-05 11:45:38 --> Router Class Initialized
INFO - 2021-07-05 11:45:38 --> Output Class Initialized
INFO - 2021-07-05 11:45:38 --> Security Class Initialized
DEBUG - 2021-07-05 11:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:45:38 --> Input Class Initialized
INFO - 2021-07-05 11:45:38 --> Language Class Initialized
INFO - 2021-07-05 11:45:38 --> Loader Class Initialized
INFO - 2021-07-05 11:45:38 --> Helper loaded: html_helper
INFO - 2021-07-05 11:45:38 --> Helper loaded: url_helper
INFO - 2021-07-05 11:45:38 --> Helper loaded: form_helper
INFO - 2021-07-05 11:45:38 --> Database Driver Class Initialized
INFO - 2021-07-05 11:45:38 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:45:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:45:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:45:38 --> Encryption Class Initialized
INFO - 2021-07-05 11:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:45:38 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:45:38 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:45:38 --> Model "user_model" initialized
INFO - 2021-07-05 11:45:38 --> Model "role_model" initialized
INFO - 2021-07-05 11:45:38 --> Controller Class Initialized
INFO - 2021-07-05 11:45:38 --> Helper loaded: language_helper
INFO - 2021-07-05 11:45:38 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:45:38 --> Model "Customer_model" initialized
INFO - 2021-07-05 11:45:38 --> Model "Product_model" initialized
INFO - 2021-07-05 11:45:38 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 11:45:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 11:45:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 11:45:38 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 11:45:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 11:45:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:45:38 --> Final output sent to browser
DEBUG - 2021-07-05 11:45:38 --> Total execution time: 0.0747
INFO - 2021-07-05 11:46:30 --> Config Class Initialized
INFO - 2021-07-05 11:46:30 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:46:30 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:46:30 --> Utf8 Class Initialized
INFO - 2021-07-05 11:46:30 --> URI Class Initialized
DEBUG - 2021-07-05 11:46:30 --> No URI present. Default controller set.
INFO - 2021-07-05 11:46:30 --> Router Class Initialized
INFO - 2021-07-05 11:46:30 --> Output Class Initialized
INFO - 2021-07-05 11:46:30 --> Security Class Initialized
DEBUG - 2021-07-05 11:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:46:30 --> Input Class Initialized
INFO - 2021-07-05 11:46:30 --> Language Class Initialized
INFO - 2021-07-05 11:46:30 --> Loader Class Initialized
INFO - 2021-07-05 11:46:30 --> Helper loaded: html_helper
INFO - 2021-07-05 11:46:30 --> Helper loaded: url_helper
INFO - 2021-07-05 11:46:30 --> Helper loaded: form_helper
INFO - 2021-07-05 11:46:30 --> Database Driver Class Initialized
INFO - 2021-07-05 11:46:31 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:46:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:46:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:46:31 --> Encryption Class Initialized
INFO - 2021-07-05 11:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:46:31 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:46:31 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:46:31 --> Model "user_model" initialized
INFO - 2021-07-05 11:46:31 --> Model "role_model" initialized
INFO - 2021-07-05 11:46:31 --> Controller Class Initialized
INFO - 2021-07-05 11:46:31 --> Helper loaded: language_helper
INFO - 2021-07-05 11:46:31 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:46:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 11:46:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 11:46:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 11:46:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:46:31 --> Final output sent to browser
DEBUG - 2021-07-05 11:46:31 --> Total execution time: 0.1109
INFO - 2021-07-05 11:46:32 --> Config Class Initialized
INFO - 2021-07-05 11:46:32 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:46:32 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:46:32 --> Utf8 Class Initialized
INFO - 2021-07-05 11:46:32 --> URI Class Initialized
DEBUG - 2021-07-05 11:46:32 --> No URI present. Default controller set.
INFO - 2021-07-05 11:46:32 --> Router Class Initialized
INFO - 2021-07-05 11:46:32 --> Output Class Initialized
INFO - 2021-07-05 11:46:32 --> Security Class Initialized
DEBUG - 2021-07-05 11:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:46:32 --> Input Class Initialized
INFO - 2021-07-05 11:46:32 --> Language Class Initialized
INFO - 2021-07-05 11:46:32 --> Loader Class Initialized
INFO - 2021-07-05 11:46:32 --> Helper loaded: html_helper
INFO - 2021-07-05 11:46:32 --> Helper loaded: url_helper
INFO - 2021-07-05 11:46:32 --> Helper loaded: form_helper
INFO - 2021-07-05 11:46:32 --> Database Driver Class Initialized
INFO - 2021-07-05 11:46:32 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:46:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:46:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:46:32 --> Encryption Class Initialized
INFO - 2021-07-05 11:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:46:32 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:46:32 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:46:32 --> Model "user_model" initialized
INFO - 2021-07-05 11:46:32 --> Model "role_model" initialized
INFO - 2021-07-05 11:46:32 --> Controller Class Initialized
INFO - 2021-07-05 11:46:32 --> Helper loaded: language_helper
INFO - 2021-07-05 11:46:32 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:46:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-05 11:46:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-05 11:46:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-05 11:46:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:46:32 --> Final output sent to browser
DEBUG - 2021-07-05 11:46:32 --> Total execution time: 0.0747
INFO - 2021-07-05 11:46:35 --> Config Class Initialized
INFO - 2021-07-05 11:46:35 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:46:35 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:46:35 --> Utf8 Class Initialized
INFO - 2021-07-05 11:46:35 --> URI Class Initialized
INFO - 2021-07-05 11:46:35 --> Router Class Initialized
INFO - 2021-07-05 11:46:35 --> Output Class Initialized
INFO - 2021-07-05 11:46:35 --> Security Class Initialized
DEBUG - 2021-07-05 11:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:46:35 --> Input Class Initialized
INFO - 2021-07-05 11:46:35 --> Language Class Initialized
INFO - 2021-07-05 11:46:35 --> Loader Class Initialized
INFO - 2021-07-05 11:46:35 --> Helper loaded: html_helper
INFO - 2021-07-05 11:46:35 --> Helper loaded: url_helper
INFO - 2021-07-05 11:46:35 --> Helper loaded: form_helper
INFO - 2021-07-05 11:46:35 --> Database Driver Class Initialized
INFO - 2021-07-05 11:46:35 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:46:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:46:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:46:35 --> Encryption Class Initialized
INFO - 2021-07-05 11:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:46:35 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:46:35 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:46:35 --> Model "user_model" initialized
INFO - 2021-07-05 11:46:35 --> Model "role_model" initialized
INFO - 2021-07-05 11:46:35 --> Controller Class Initialized
INFO - 2021-07-05 11:46:35 --> Helper loaded: language_helper
INFO - 2021-07-05 11:46:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:46:35 --> Model "Customer_model" initialized
INFO - 2021-07-05 11:46:35 --> Model "Product_model" initialized
INFO - 2021-07-05 11:46:35 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 11:46:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 11:46:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 11:46:35 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 11:46:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 11:46:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:46:35 --> Final output sent to browser
DEBUG - 2021-07-05 11:46:35 --> Total execution time: 0.0762
INFO - 2021-07-05 11:46:48 --> Config Class Initialized
INFO - 2021-07-05 11:46:48 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:46:48 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:46:48 --> Utf8 Class Initialized
INFO - 2021-07-05 11:46:48 --> URI Class Initialized
INFO - 2021-07-05 11:46:48 --> Router Class Initialized
INFO - 2021-07-05 11:46:48 --> Output Class Initialized
INFO - 2021-07-05 11:46:48 --> Security Class Initialized
DEBUG - 2021-07-05 11:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:46:48 --> Input Class Initialized
INFO - 2021-07-05 11:46:48 --> Language Class Initialized
INFO - 2021-07-05 11:46:48 --> Loader Class Initialized
INFO - 2021-07-05 11:46:48 --> Helper loaded: html_helper
INFO - 2021-07-05 11:46:48 --> Helper loaded: url_helper
INFO - 2021-07-05 11:46:48 --> Helper loaded: form_helper
INFO - 2021-07-05 11:46:48 --> Database Driver Class Initialized
INFO - 2021-07-05 11:46:48 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:46:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:46:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:46:48 --> Encryption Class Initialized
INFO - 2021-07-05 11:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:46:48 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:46:48 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:46:48 --> Model "user_model" initialized
INFO - 2021-07-05 11:46:48 --> Model "role_model" initialized
INFO - 2021-07-05 11:46:48 --> Controller Class Initialized
INFO - 2021-07-05 11:46:48 --> Helper loaded: language_helper
INFO - 2021-07-05 11:46:48 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:46:48 --> Model "Quotation_model" initialized
INFO - 2021-07-05 11:46:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 11:46:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 11:46:48 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-05 11:46:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-05 11:46:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:46:48 --> Final output sent to browser
DEBUG - 2021-07-05 11:46:48 --> Total execution time: 0.0723
INFO - 2021-07-05 11:46:55 --> Config Class Initialized
INFO - 2021-07-05 11:46:55 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:46:55 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:46:55 --> Utf8 Class Initialized
INFO - 2021-07-05 11:46:55 --> URI Class Initialized
INFO - 2021-07-05 11:46:55 --> Router Class Initialized
INFO - 2021-07-05 11:46:55 --> Output Class Initialized
INFO - 2021-07-05 11:46:55 --> Security Class Initialized
DEBUG - 2021-07-05 11:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:46:55 --> Input Class Initialized
INFO - 2021-07-05 11:46:55 --> Language Class Initialized
INFO - 2021-07-05 11:46:55 --> Loader Class Initialized
INFO - 2021-07-05 11:46:55 --> Helper loaded: html_helper
INFO - 2021-07-05 11:46:55 --> Helper loaded: url_helper
INFO - 2021-07-05 11:46:55 --> Helper loaded: form_helper
INFO - 2021-07-05 11:46:55 --> Database Driver Class Initialized
INFO - 2021-07-05 11:46:55 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:46:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:46:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:46:55 --> Encryption Class Initialized
INFO - 2021-07-05 11:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:46:55 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:46:55 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:46:55 --> Model "user_model" initialized
INFO - 2021-07-05 11:46:55 --> Model "role_model" initialized
INFO - 2021-07-05 11:46:55 --> Controller Class Initialized
INFO - 2021-07-05 11:46:55 --> Helper loaded: language_helper
INFO - 2021-07-05 11:46:55 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:46:55 --> Model "Customer_model" initialized
INFO - 2021-07-05 11:46:55 --> Model "Product_model" initialized
INFO - 2021-07-05 11:46:55 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 11:46:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 11:46:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 11:46:55 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 11:46:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 11:46:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:46:55 --> Final output sent to browser
DEBUG - 2021-07-05 11:46:55 --> Total execution time: 0.0782
INFO - 2021-07-05 11:47:36 --> Config Class Initialized
INFO - 2021-07-05 11:47:36 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:47:36 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:47:36 --> Utf8 Class Initialized
INFO - 2021-07-05 11:47:36 --> URI Class Initialized
INFO - 2021-07-05 11:47:36 --> Router Class Initialized
INFO - 2021-07-05 11:47:36 --> Output Class Initialized
INFO - 2021-07-05 11:47:36 --> Security Class Initialized
DEBUG - 2021-07-05 11:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:47:36 --> Input Class Initialized
INFO - 2021-07-05 11:47:36 --> Language Class Initialized
INFO - 2021-07-05 11:47:36 --> Loader Class Initialized
INFO - 2021-07-05 11:47:36 --> Helper loaded: html_helper
INFO - 2021-07-05 11:47:36 --> Helper loaded: url_helper
INFO - 2021-07-05 11:47:36 --> Helper loaded: form_helper
INFO - 2021-07-05 11:47:37 --> Database Driver Class Initialized
INFO - 2021-07-05 11:47:37 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:47:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:47:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:47:37 --> Encryption Class Initialized
INFO - 2021-07-05 11:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:47:37 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:47:37 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:47:37 --> Model "user_model" initialized
INFO - 2021-07-05 11:47:37 --> Model "role_model" initialized
INFO - 2021-07-05 11:47:37 --> Controller Class Initialized
INFO - 2021-07-05 11:47:37 --> Helper loaded: language_helper
INFO - 2021-07-05 11:47:37 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:47:37 --> Model "Customer_model" initialized
INFO - 2021-07-05 11:47:37 --> Model "Product_model" initialized
INFO - 2021-07-05 11:47:37 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 11:47:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 11:47:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 11:47:37 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 11:47:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 11:47:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:47:37 --> Final output sent to browser
DEBUG - 2021-07-05 11:47:37 --> Total execution time: 0.1150
INFO - 2021-07-05 11:48:41 --> Config Class Initialized
INFO - 2021-07-05 11:48:41 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:48:41 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:48:41 --> Utf8 Class Initialized
INFO - 2021-07-05 11:48:41 --> URI Class Initialized
INFO - 2021-07-05 11:48:41 --> Router Class Initialized
INFO - 2021-07-05 11:48:41 --> Output Class Initialized
INFO - 2021-07-05 11:48:41 --> Security Class Initialized
DEBUG - 2021-07-05 11:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:48:41 --> Input Class Initialized
INFO - 2021-07-05 11:48:41 --> Language Class Initialized
INFO - 2021-07-05 11:48:41 --> Loader Class Initialized
INFO - 2021-07-05 11:48:41 --> Helper loaded: html_helper
INFO - 2021-07-05 11:48:41 --> Helper loaded: url_helper
INFO - 2021-07-05 11:48:41 --> Helper loaded: form_helper
INFO - 2021-07-05 11:48:41 --> Database Driver Class Initialized
INFO - 2021-07-05 11:48:41 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:48:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:48:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:48:41 --> Encryption Class Initialized
INFO - 2021-07-05 11:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:48:41 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:48:41 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:48:41 --> Model "user_model" initialized
INFO - 2021-07-05 11:48:41 --> Model "role_model" initialized
INFO - 2021-07-05 11:48:41 --> Controller Class Initialized
INFO - 2021-07-05 11:48:41 --> Helper loaded: language_helper
INFO - 2021-07-05 11:48:41 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:48:41 --> Model "Customer_model" initialized
INFO - 2021-07-05 11:48:41 --> Model "Product_model" initialized
INFO - 2021-07-05 11:48:41 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 11:48:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 11:48:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 11:48:41 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 11:48:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 11:48:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:48:41 --> Final output sent to browser
DEBUG - 2021-07-05 11:48:41 --> Total execution time: 0.1114
INFO - 2021-07-05 11:49:08 --> Config Class Initialized
INFO - 2021-07-05 11:49:08 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:49:08 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:49:08 --> Utf8 Class Initialized
INFO - 2021-07-05 11:49:08 --> URI Class Initialized
INFO - 2021-07-05 11:49:08 --> Router Class Initialized
INFO - 2021-07-05 11:49:08 --> Output Class Initialized
INFO - 2021-07-05 11:49:08 --> Security Class Initialized
DEBUG - 2021-07-05 11:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:49:08 --> Input Class Initialized
INFO - 2021-07-05 11:49:08 --> Language Class Initialized
INFO - 2021-07-05 11:49:08 --> Loader Class Initialized
INFO - 2021-07-05 11:49:08 --> Helper loaded: html_helper
INFO - 2021-07-05 11:49:08 --> Helper loaded: url_helper
INFO - 2021-07-05 11:49:08 --> Helper loaded: form_helper
INFO - 2021-07-05 11:49:08 --> Database Driver Class Initialized
INFO - 2021-07-05 11:49:08 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:49:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:49:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:49:08 --> Encryption Class Initialized
INFO - 2021-07-05 11:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:49:08 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:49:08 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:49:08 --> Model "user_model" initialized
INFO - 2021-07-05 11:49:08 --> Model "role_model" initialized
INFO - 2021-07-05 11:49:08 --> Controller Class Initialized
INFO - 2021-07-05 11:49:08 --> Helper loaded: language_helper
INFO - 2021-07-05 11:49:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:49:08 --> Model "Product_model" initialized
INFO - 2021-07-05 11:49:08 --> Final output sent to browser
DEBUG - 2021-07-05 11:49:08 --> Total execution time: 0.0734
INFO - 2021-07-05 11:50:35 --> Config Class Initialized
INFO - 2021-07-05 11:50:35 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:50:35 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:50:35 --> Utf8 Class Initialized
INFO - 2021-07-05 11:50:35 --> URI Class Initialized
INFO - 2021-07-05 11:50:35 --> Router Class Initialized
INFO - 2021-07-05 11:50:35 --> Output Class Initialized
INFO - 2021-07-05 11:50:35 --> Security Class Initialized
DEBUG - 2021-07-05 11:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:50:35 --> Input Class Initialized
INFO - 2021-07-05 11:50:35 --> Language Class Initialized
INFO - 2021-07-05 11:50:35 --> Loader Class Initialized
INFO - 2021-07-05 11:50:35 --> Helper loaded: html_helper
INFO - 2021-07-05 11:50:35 --> Helper loaded: url_helper
INFO - 2021-07-05 11:50:35 --> Helper loaded: form_helper
INFO - 2021-07-05 11:50:35 --> Database Driver Class Initialized
INFO - 2021-07-05 11:50:35 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:50:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:50:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:50:35 --> Encryption Class Initialized
INFO - 2021-07-05 11:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:50:35 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:50:35 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:50:35 --> Model "user_model" initialized
INFO - 2021-07-05 11:50:35 --> Model "role_model" initialized
INFO - 2021-07-05 11:50:35 --> Controller Class Initialized
INFO - 2021-07-05 11:50:35 --> Helper loaded: language_helper
INFO - 2021-07-05 11:50:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:50:35 --> Model "Customer_model" initialized
INFO - 2021-07-05 11:50:35 --> Model "Product_model" initialized
INFO - 2021-07-05 11:50:35 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 11:50:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 11:50:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 11:50:35 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 11:50:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 11:50:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:50:35 --> Final output sent to browser
DEBUG - 2021-07-05 11:50:35 --> Total execution time: 0.1236
INFO - 2021-07-05 11:51:08 --> Config Class Initialized
INFO - 2021-07-05 11:51:08 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:51:08 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:51:08 --> Utf8 Class Initialized
INFO - 2021-07-05 11:51:08 --> URI Class Initialized
INFO - 2021-07-05 11:51:08 --> Router Class Initialized
INFO - 2021-07-05 11:51:08 --> Output Class Initialized
INFO - 2021-07-05 11:51:08 --> Security Class Initialized
DEBUG - 2021-07-05 11:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:51:08 --> Input Class Initialized
INFO - 2021-07-05 11:51:08 --> Language Class Initialized
INFO - 2021-07-05 11:51:08 --> Loader Class Initialized
INFO - 2021-07-05 11:51:08 --> Helper loaded: html_helper
INFO - 2021-07-05 11:51:08 --> Helper loaded: url_helper
INFO - 2021-07-05 11:51:08 --> Helper loaded: form_helper
INFO - 2021-07-05 11:51:08 --> Database Driver Class Initialized
INFO - 2021-07-05 11:51:08 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:51:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:51:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:51:08 --> Encryption Class Initialized
INFO - 2021-07-05 11:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:51:08 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:51:08 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:51:08 --> Model "user_model" initialized
INFO - 2021-07-05 11:51:08 --> Model "role_model" initialized
INFO - 2021-07-05 11:51:08 --> Controller Class Initialized
INFO - 2021-07-05 11:51:08 --> Helper loaded: language_helper
INFO - 2021-07-05 11:51:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:51:08 --> Model "Product_model" initialized
INFO - 2021-07-05 11:51:08 --> Final output sent to browser
DEBUG - 2021-07-05 11:51:08 --> Total execution time: 0.0851
INFO - 2021-07-05 11:53:26 --> Config Class Initialized
INFO - 2021-07-05 11:53:26 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:53:26 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:53:26 --> Utf8 Class Initialized
INFO - 2021-07-05 11:53:26 --> URI Class Initialized
INFO - 2021-07-05 11:53:26 --> Router Class Initialized
INFO - 2021-07-05 11:53:26 --> Output Class Initialized
INFO - 2021-07-05 11:53:26 --> Security Class Initialized
DEBUG - 2021-07-05 11:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:53:26 --> Input Class Initialized
INFO - 2021-07-05 11:53:26 --> Language Class Initialized
INFO - 2021-07-05 11:53:26 --> Loader Class Initialized
INFO - 2021-07-05 11:53:26 --> Helper loaded: html_helper
INFO - 2021-07-05 11:53:26 --> Helper loaded: url_helper
INFO - 2021-07-05 11:53:26 --> Helper loaded: form_helper
INFO - 2021-07-05 11:53:26 --> Database Driver Class Initialized
INFO - 2021-07-05 11:53:26 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:53:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:53:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:53:26 --> Encryption Class Initialized
INFO - 2021-07-05 11:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:53:26 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:53:26 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:53:26 --> Model "user_model" initialized
INFO - 2021-07-05 11:53:26 --> Model "role_model" initialized
INFO - 2021-07-05 11:53:26 --> Controller Class Initialized
INFO - 2021-07-05 11:53:26 --> Helper loaded: language_helper
INFO - 2021-07-05 11:53:26 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:53:26 --> Model "Customer_model" initialized
INFO - 2021-07-05 11:53:26 --> Model "Product_model" initialized
INFO - 2021-07-05 11:53:26 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 11:53:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 11:53:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 11:53:26 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 11:53:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 11:53:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:53:26 --> Final output sent to browser
DEBUG - 2021-07-05 11:53:26 --> Total execution time: 0.1261
INFO - 2021-07-05 11:53:39 --> Config Class Initialized
INFO - 2021-07-05 11:53:39 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:53:39 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:53:39 --> Utf8 Class Initialized
INFO - 2021-07-05 11:53:39 --> URI Class Initialized
INFO - 2021-07-05 11:53:39 --> Router Class Initialized
INFO - 2021-07-05 11:53:39 --> Output Class Initialized
INFO - 2021-07-05 11:53:39 --> Security Class Initialized
DEBUG - 2021-07-05 11:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:53:39 --> Input Class Initialized
INFO - 2021-07-05 11:53:39 --> Language Class Initialized
INFO - 2021-07-05 11:53:39 --> Loader Class Initialized
INFO - 2021-07-05 11:53:39 --> Helper loaded: html_helper
INFO - 2021-07-05 11:53:39 --> Helper loaded: url_helper
INFO - 2021-07-05 11:53:39 --> Helper loaded: form_helper
INFO - 2021-07-05 11:53:39 --> Database Driver Class Initialized
INFO - 2021-07-05 11:53:39 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:53:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:53:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:53:39 --> Encryption Class Initialized
INFO - 2021-07-05 11:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:53:39 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:53:39 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:53:39 --> Model "user_model" initialized
INFO - 2021-07-05 11:53:39 --> Model "role_model" initialized
INFO - 2021-07-05 11:53:39 --> Controller Class Initialized
INFO - 2021-07-05 11:53:39 --> Helper loaded: language_helper
INFO - 2021-07-05 11:53:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:53:39 --> Model "Product_model" initialized
INFO - 2021-07-05 11:53:39 --> Final output sent to browser
DEBUG - 2021-07-05 11:53:39 --> Total execution time: 0.0762
INFO - 2021-07-05 11:53:57 --> Config Class Initialized
INFO - 2021-07-05 11:53:57 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:53:57 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:53:57 --> Utf8 Class Initialized
INFO - 2021-07-05 11:53:57 --> URI Class Initialized
INFO - 2021-07-05 11:53:57 --> Router Class Initialized
INFO - 2021-07-05 11:53:57 --> Output Class Initialized
INFO - 2021-07-05 11:53:57 --> Security Class Initialized
DEBUG - 2021-07-05 11:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:53:57 --> Input Class Initialized
INFO - 2021-07-05 11:53:57 --> Language Class Initialized
INFO - 2021-07-05 11:53:57 --> Loader Class Initialized
INFO - 2021-07-05 11:53:57 --> Helper loaded: html_helper
INFO - 2021-07-05 11:53:57 --> Helper loaded: url_helper
INFO - 2021-07-05 11:53:57 --> Helper loaded: form_helper
INFO - 2021-07-05 11:53:57 --> Database Driver Class Initialized
INFO - 2021-07-05 11:53:57 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:53:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:53:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:53:57 --> Encryption Class Initialized
INFO - 2021-07-05 11:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:53:57 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:53:57 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:53:57 --> Model "user_model" initialized
INFO - 2021-07-05 11:53:57 --> Model "role_model" initialized
INFO - 2021-07-05 11:53:57 --> Controller Class Initialized
INFO - 2021-07-05 11:53:57 --> Helper loaded: language_helper
INFO - 2021-07-05 11:53:57 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:53:57 --> Model "Product_model" initialized
INFO - 2021-07-05 11:53:57 --> Final output sent to browser
DEBUG - 2021-07-05 11:53:57 --> Total execution time: 0.0756
INFO - 2021-07-05 11:54:29 --> Config Class Initialized
INFO - 2021-07-05 11:54:29 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:54:29 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:54:29 --> Utf8 Class Initialized
INFO - 2021-07-05 11:54:29 --> URI Class Initialized
INFO - 2021-07-05 11:54:29 --> Router Class Initialized
INFO - 2021-07-05 11:54:29 --> Output Class Initialized
INFO - 2021-07-05 11:54:29 --> Security Class Initialized
DEBUG - 2021-07-05 11:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:54:29 --> Input Class Initialized
INFO - 2021-07-05 11:54:29 --> Language Class Initialized
INFO - 2021-07-05 11:54:29 --> Loader Class Initialized
INFO - 2021-07-05 11:54:29 --> Helper loaded: html_helper
INFO - 2021-07-05 11:54:29 --> Helper loaded: url_helper
INFO - 2021-07-05 11:54:29 --> Helper loaded: form_helper
INFO - 2021-07-05 11:54:29 --> Database Driver Class Initialized
INFO - 2021-07-05 11:54:29 --> Form Validation Class Initialized
DEBUG - 2021-07-05 11:54:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 11:54:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 11:54:29 --> Encryption Class Initialized
INFO - 2021-07-05 11:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:54:29 --> Model "vendor_model" initialized
INFO - 2021-07-05 11:54:29 --> Model "coupon_model" initialized
INFO - 2021-07-05 11:54:29 --> Model "user_model" initialized
INFO - 2021-07-05 11:54:29 --> Model "role_model" initialized
INFO - 2021-07-05 11:54:29 --> Controller Class Initialized
INFO - 2021-07-05 11:54:29 --> Helper loaded: language_helper
INFO - 2021-07-05 11:54:29 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 11:54:29 --> Model "Customer_model" initialized
INFO - 2021-07-05 11:54:29 --> Model "Product_model" initialized
INFO - 2021-07-05 11:54:29 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 11:54:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 11:54:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 11:54:29 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 11:54:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 11:54:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 11:54:29 --> Final output sent to browser
DEBUG - 2021-07-05 11:54:29 --> Total execution time: 0.0677
INFO - 2021-07-05 12:08:40 --> Config Class Initialized
INFO - 2021-07-05 12:08:40 --> Hooks Class Initialized
DEBUG - 2021-07-05 12:08:40 --> UTF-8 Support Enabled
INFO - 2021-07-05 12:08:40 --> Utf8 Class Initialized
INFO - 2021-07-05 12:08:40 --> URI Class Initialized
INFO - 2021-07-05 12:08:40 --> Router Class Initialized
INFO - 2021-07-05 12:08:40 --> Output Class Initialized
INFO - 2021-07-05 12:08:40 --> Security Class Initialized
DEBUG - 2021-07-05 12:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 12:08:40 --> Input Class Initialized
INFO - 2021-07-05 12:08:40 --> Language Class Initialized
INFO - 2021-07-05 12:08:40 --> Loader Class Initialized
INFO - 2021-07-05 12:08:40 --> Helper loaded: html_helper
INFO - 2021-07-05 12:08:40 --> Helper loaded: url_helper
INFO - 2021-07-05 12:08:40 --> Helper loaded: form_helper
INFO - 2021-07-05 12:08:40 --> Database Driver Class Initialized
INFO - 2021-07-05 12:08:40 --> Form Validation Class Initialized
DEBUG - 2021-07-05 12:08:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 12:08:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 12:08:40 --> Encryption Class Initialized
INFO - 2021-07-05 12:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 12:08:40 --> Model "vendor_model" initialized
INFO - 2021-07-05 12:08:40 --> Model "coupon_model" initialized
INFO - 2021-07-05 12:08:40 --> Model "user_model" initialized
INFO - 2021-07-05 12:08:40 --> Model "role_model" initialized
INFO - 2021-07-05 12:08:40 --> Controller Class Initialized
INFO - 2021-07-05 12:08:40 --> Helper loaded: language_helper
INFO - 2021-07-05 12:08:40 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 12:08:40 --> Model "Customer_model" initialized
INFO - 2021-07-05 12:08:40 --> Model "Product_model" initialized
INFO - 2021-07-05 12:08:40 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 12:08:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 12:08:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 12:08:40 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 12:08:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 12:08:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 12:08:40 --> Final output sent to browser
DEBUG - 2021-07-05 12:08:40 --> Total execution time: 0.1024
INFO - 2021-07-05 12:09:30 --> Config Class Initialized
INFO - 2021-07-05 12:09:30 --> Hooks Class Initialized
DEBUG - 2021-07-05 12:09:30 --> UTF-8 Support Enabled
INFO - 2021-07-05 12:09:30 --> Utf8 Class Initialized
INFO - 2021-07-05 12:09:30 --> URI Class Initialized
INFO - 2021-07-05 12:09:30 --> Router Class Initialized
INFO - 2021-07-05 12:09:30 --> Output Class Initialized
INFO - 2021-07-05 12:09:30 --> Security Class Initialized
DEBUG - 2021-07-05 12:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 12:09:30 --> Input Class Initialized
INFO - 2021-07-05 12:09:30 --> Language Class Initialized
INFO - 2021-07-05 12:09:30 --> Loader Class Initialized
INFO - 2021-07-05 12:09:30 --> Helper loaded: html_helper
INFO - 2021-07-05 12:09:30 --> Helper loaded: url_helper
INFO - 2021-07-05 12:09:30 --> Helper loaded: form_helper
INFO - 2021-07-05 12:09:30 --> Database Driver Class Initialized
INFO - 2021-07-05 12:09:30 --> Form Validation Class Initialized
DEBUG - 2021-07-05 12:09:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 12:09:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 12:09:30 --> Encryption Class Initialized
INFO - 2021-07-05 12:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 12:09:30 --> Model "vendor_model" initialized
INFO - 2021-07-05 12:09:30 --> Model "coupon_model" initialized
INFO - 2021-07-05 12:09:30 --> Model "user_model" initialized
INFO - 2021-07-05 12:09:30 --> Model "role_model" initialized
INFO - 2021-07-05 12:09:30 --> Controller Class Initialized
INFO - 2021-07-05 12:09:30 --> Helper loaded: language_helper
INFO - 2021-07-05 12:09:30 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 12:09:30 --> Model "Customer_model" initialized
INFO - 2021-07-05 12:09:30 --> Final output sent to browser
DEBUG - 2021-07-05 12:09:30 --> Total execution time: 0.0930
INFO - 2021-07-05 12:09:47 --> Config Class Initialized
INFO - 2021-07-05 12:09:47 --> Hooks Class Initialized
DEBUG - 2021-07-05 12:09:47 --> UTF-8 Support Enabled
INFO - 2021-07-05 12:09:47 --> Utf8 Class Initialized
INFO - 2021-07-05 12:09:47 --> URI Class Initialized
INFO - 2021-07-05 12:09:47 --> Router Class Initialized
INFO - 2021-07-05 12:09:47 --> Output Class Initialized
INFO - 2021-07-05 12:09:47 --> Security Class Initialized
DEBUG - 2021-07-05 12:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 12:09:47 --> Input Class Initialized
INFO - 2021-07-05 12:09:47 --> Language Class Initialized
INFO - 2021-07-05 12:09:47 --> Loader Class Initialized
INFO - 2021-07-05 12:09:47 --> Helper loaded: html_helper
INFO - 2021-07-05 12:09:47 --> Helper loaded: url_helper
INFO - 2021-07-05 12:09:47 --> Helper loaded: form_helper
INFO - 2021-07-05 12:09:47 --> Database Driver Class Initialized
INFO - 2021-07-05 12:09:47 --> Form Validation Class Initialized
DEBUG - 2021-07-05 12:09:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 12:09:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 12:09:47 --> Encryption Class Initialized
INFO - 2021-07-05 12:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 12:09:47 --> Model "vendor_model" initialized
INFO - 2021-07-05 12:09:47 --> Model "coupon_model" initialized
INFO - 2021-07-05 12:09:47 --> Model "user_model" initialized
INFO - 2021-07-05 12:09:47 --> Model "role_model" initialized
INFO - 2021-07-05 12:09:47 --> Controller Class Initialized
INFO - 2021-07-05 12:09:47 --> Helper loaded: language_helper
INFO - 2021-07-05 12:09:47 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 12:09:47 --> Model "Customer_model" initialized
INFO - 2021-07-05 12:09:47 --> Final output sent to browser
DEBUG - 2021-07-05 12:09:47 --> Total execution time: 0.0692
INFO - 2021-07-05 12:10:44 --> Config Class Initialized
INFO - 2021-07-05 12:10:44 --> Hooks Class Initialized
DEBUG - 2021-07-05 12:10:44 --> UTF-8 Support Enabled
INFO - 2021-07-05 12:10:44 --> Utf8 Class Initialized
INFO - 2021-07-05 12:10:44 --> URI Class Initialized
INFO - 2021-07-05 12:10:44 --> Router Class Initialized
INFO - 2021-07-05 12:10:44 --> Output Class Initialized
INFO - 2021-07-05 12:10:44 --> Security Class Initialized
DEBUG - 2021-07-05 12:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 12:10:44 --> Input Class Initialized
INFO - 2021-07-05 12:10:44 --> Language Class Initialized
INFO - 2021-07-05 12:10:44 --> Loader Class Initialized
INFO - 2021-07-05 12:10:44 --> Helper loaded: html_helper
INFO - 2021-07-05 12:10:44 --> Helper loaded: url_helper
INFO - 2021-07-05 12:10:44 --> Helper loaded: form_helper
INFO - 2021-07-05 12:10:44 --> Database Driver Class Initialized
INFO - 2021-07-05 12:10:44 --> Form Validation Class Initialized
DEBUG - 2021-07-05 12:10:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 12:10:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 12:10:44 --> Encryption Class Initialized
INFO - 2021-07-05 12:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 12:10:44 --> Model "vendor_model" initialized
INFO - 2021-07-05 12:10:44 --> Model "coupon_model" initialized
INFO - 2021-07-05 12:10:44 --> Model "user_model" initialized
INFO - 2021-07-05 12:10:44 --> Model "role_model" initialized
INFO - 2021-07-05 12:10:44 --> Controller Class Initialized
INFO - 2021-07-05 12:10:44 --> Helper loaded: language_helper
INFO - 2021-07-05 12:10:44 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 12:10:44 --> Model "Product_model" initialized
INFO - 2021-07-05 12:10:44 --> Final output sent to browser
DEBUG - 2021-07-05 12:10:44 --> Total execution time: 0.1126
INFO - 2021-07-05 12:10:48 --> Config Class Initialized
INFO - 2021-07-05 12:10:48 --> Hooks Class Initialized
DEBUG - 2021-07-05 12:10:48 --> UTF-8 Support Enabled
INFO - 2021-07-05 12:10:48 --> Utf8 Class Initialized
INFO - 2021-07-05 12:10:48 --> URI Class Initialized
INFO - 2021-07-05 12:10:48 --> Router Class Initialized
INFO - 2021-07-05 12:10:48 --> Output Class Initialized
INFO - 2021-07-05 12:10:48 --> Security Class Initialized
DEBUG - 2021-07-05 12:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 12:10:48 --> Input Class Initialized
INFO - 2021-07-05 12:10:48 --> Language Class Initialized
INFO - 2021-07-05 12:10:48 --> Loader Class Initialized
INFO - 2021-07-05 12:10:48 --> Helper loaded: html_helper
INFO - 2021-07-05 12:10:48 --> Helper loaded: url_helper
INFO - 2021-07-05 12:10:48 --> Helper loaded: form_helper
INFO - 2021-07-05 12:10:48 --> Database Driver Class Initialized
INFO - 2021-07-05 12:10:48 --> Form Validation Class Initialized
DEBUG - 2021-07-05 12:10:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 12:10:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 12:10:48 --> Encryption Class Initialized
INFO - 2021-07-05 12:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 12:10:48 --> Model "vendor_model" initialized
INFO - 2021-07-05 12:10:48 --> Model "coupon_model" initialized
INFO - 2021-07-05 12:10:48 --> Model "user_model" initialized
INFO - 2021-07-05 12:10:48 --> Model "role_model" initialized
INFO - 2021-07-05 12:10:48 --> Controller Class Initialized
INFO - 2021-07-05 12:10:48 --> Helper loaded: language_helper
INFO - 2021-07-05 12:10:48 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 12:10:48 --> Model "Product_model" initialized
INFO - 2021-07-05 12:10:48 --> Final output sent to browser
DEBUG - 2021-07-05 12:10:48 --> Total execution time: 0.0675
INFO - 2021-07-05 12:11:07 --> Config Class Initialized
INFO - 2021-07-05 12:11:07 --> Hooks Class Initialized
DEBUG - 2021-07-05 12:11:07 --> UTF-8 Support Enabled
INFO - 2021-07-05 12:11:07 --> Utf8 Class Initialized
INFO - 2021-07-05 12:11:07 --> URI Class Initialized
INFO - 2021-07-05 12:11:07 --> Router Class Initialized
INFO - 2021-07-05 12:11:07 --> Output Class Initialized
INFO - 2021-07-05 12:11:07 --> Security Class Initialized
DEBUG - 2021-07-05 12:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 12:11:07 --> Input Class Initialized
INFO - 2021-07-05 12:11:07 --> Language Class Initialized
INFO - 2021-07-05 12:11:07 --> Loader Class Initialized
INFO - 2021-07-05 12:11:07 --> Helper loaded: html_helper
INFO - 2021-07-05 12:11:07 --> Helper loaded: url_helper
INFO - 2021-07-05 12:11:07 --> Helper loaded: form_helper
INFO - 2021-07-05 12:11:07 --> Database Driver Class Initialized
INFO - 2021-07-05 12:11:07 --> Form Validation Class Initialized
DEBUG - 2021-07-05 12:11:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 12:11:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 12:11:07 --> Encryption Class Initialized
INFO - 2021-07-05 12:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 12:11:07 --> Model "vendor_model" initialized
INFO - 2021-07-05 12:11:07 --> Model "coupon_model" initialized
INFO - 2021-07-05 12:11:07 --> Model "user_model" initialized
INFO - 2021-07-05 12:11:07 --> Model "role_model" initialized
INFO - 2021-07-05 12:11:07 --> Controller Class Initialized
INFO - 2021-07-05 12:11:07 --> Helper loaded: language_helper
INFO - 2021-07-05 12:11:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 12:11:07 --> Model "Product_model" initialized
INFO - 2021-07-05 12:11:07 --> Final output sent to browser
DEBUG - 2021-07-05 12:11:07 --> Total execution time: 0.0908
INFO - 2021-07-05 12:11:33 --> Config Class Initialized
INFO - 2021-07-05 12:11:33 --> Hooks Class Initialized
DEBUG - 2021-07-05 12:11:33 --> UTF-8 Support Enabled
INFO - 2021-07-05 12:11:33 --> Utf8 Class Initialized
INFO - 2021-07-05 12:11:33 --> URI Class Initialized
INFO - 2021-07-05 12:11:33 --> Router Class Initialized
INFO - 2021-07-05 12:11:33 --> Output Class Initialized
INFO - 2021-07-05 12:11:33 --> Security Class Initialized
DEBUG - 2021-07-05 12:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 12:11:33 --> Input Class Initialized
INFO - 2021-07-05 12:11:33 --> Language Class Initialized
INFO - 2021-07-05 12:11:33 --> Loader Class Initialized
INFO - 2021-07-05 12:11:33 --> Helper loaded: html_helper
INFO - 2021-07-05 12:11:33 --> Helper loaded: url_helper
INFO - 2021-07-05 12:11:33 --> Helper loaded: form_helper
INFO - 2021-07-05 12:11:33 --> Database Driver Class Initialized
INFO - 2021-07-05 12:11:33 --> Form Validation Class Initialized
DEBUG - 2021-07-05 12:11:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 12:11:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 12:11:33 --> Encryption Class Initialized
INFO - 2021-07-05 12:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 12:11:33 --> Model "vendor_model" initialized
INFO - 2021-07-05 12:11:33 --> Model "coupon_model" initialized
INFO - 2021-07-05 12:11:33 --> Model "user_model" initialized
INFO - 2021-07-05 12:11:33 --> Model "role_model" initialized
INFO - 2021-07-05 12:11:33 --> Controller Class Initialized
INFO - 2021-07-05 12:11:33 --> Helper loaded: language_helper
INFO - 2021-07-05 12:11:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 12:11:33 --> Model "Customer_model" initialized
INFO - 2021-07-05 12:11:33 --> Model "Product_model" initialized
INFO - 2021-07-05 12:11:33 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 12:11:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 12:11:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 12:11:33 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 12:11:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 12:11:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 12:11:33 --> Final output sent to browser
DEBUG - 2021-07-05 12:11:33 --> Total execution time: 0.0796
INFO - 2021-07-05 12:12:38 --> Config Class Initialized
INFO - 2021-07-05 12:12:38 --> Hooks Class Initialized
DEBUG - 2021-07-05 12:12:38 --> UTF-8 Support Enabled
INFO - 2021-07-05 12:12:38 --> Utf8 Class Initialized
INFO - 2021-07-05 12:12:38 --> URI Class Initialized
INFO - 2021-07-05 12:12:38 --> Router Class Initialized
INFO - 2021-07-05 12:12:38 --> Output Class Initialized
INFO - 2021-07-05 12:12:38 --> Security Class Initialized
DEBUG - 2021-07-05 12:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 12:12:38 --> Input Class Initialized
INFO - 2021-07-05 12:12:38 --> Language Class Initialized
INFO - 2021-07-05 12:12:38 --> Loader Class Initialized
INFO - 2021-07-05 12:12:38 --> Helper loaded: html_helper
INFO - 2021-07-05 12:12:38 --> Helper loaded: url_helper
INFO - 2021-07-05 12:12:38 --> Helper loaded: form_helper
INFO - 2021-07-05 12:12:38 --> Database Driver Class Initialized
INFO - 2021-07-05 12:12:38 --> Form Validation Class Initialized
DEBUG - 2021-07-05 12:12:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 12:12:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 12:12:38 --> Encryption Class Initialized
INFO - 2021-07-05 12:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 12:12:38 --> Model "vendor_model" initialized
INFO - 2021-07-05 12:12:38 --> Model "coupon_model" initialized
INFO - 2021-07-05 12:12:38 --> Model "user_model" initialized
INFO - 2021-07-05 12:12:38 --> Model "role_model" initialized
INFO - 2021-07-05 12:12:38 --> Controller Class Initialized
INFO - 2021-07-05 12:12:38 --> Helper loaded: language_helper
INFO - 2021-07-05 12:12:38 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 12:12:38 --> Model "Customer_model" initialized
INFO - 2021-07-05 12:12:38 --> Model "Product_model" initialized
INFO - 2021-07-05 12:12:38 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 12:12:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 12:12:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 12:12:39 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 12:12:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 12:12:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 12:12:39 --> Final output sent to browser
DEBUG - 2021-07-05 12:12:39 --> Total execution time: 0.1151
INFO - 2021-07-05 12:13:05 --> Config Class Initialized
INFO - 2021-07-05 12:13:05 --> Hooks Class Initialized
DEBUG - 2021-07-05 12:13:05 --> UTF-8 Support Enabled
INFO - 2021-07-05 12:13:05 --> Utf8 Class Initialized
INFO - 2021-07-05 12:13:05 --> URI Class Initialized
INFO - 2021-07-05 12:13:05 --> Router Class Initialized
INFO - 2021-07-05 12:13:05 --> Output Class Initialized
INFO - 2021-07-05 12:13:05 --> Security Class Initialized
DEBUG - 2021-07-05 12:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 12:13:05 --> Input Class Initialized
INFO - 2021-07-05 12:13:05 --> Language Class Initialized
INFO - 2021-07-05 12:13:05 --> Loader Class Initialized
INFO - 2021-07-05 12:13:05 --> Helper loaded: html_helper
INFO - 2021-07-05 12:13:05 --> Helper loaded: url_helper
INFO - 2021-07-05 12:13:05 --> Helper loaded: form_helper
INFO - 2021-07-05 12:13:05 --> Database Driver Class Initialized
INFO - 2021-07-05 12:13:05 --> Form Validation Class Initialized
DEBUG - 2021-07-05 12:13:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 12:13:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 12:13:05 --> Encryption Class Initialized
INFO - 2021-07-05 12:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 12:13:05 --> Model "vendor_model" initialized
INFO - 2021-07-05 12:13:05 --> Model "coupon_model" initialized
INFO - 2021-07-05 12:13:05 --> Model "user_model" initialized
INFO - 2021-07-05 12:13:05 --> Model "role_model" initialized
INFO - 2021-07-05 12:13:05 --> Controller Class Initialized
INFO - 2021-07-05 12:13:05 --> Helper loaded: language_helper
INFO - 2021-07-05 12:13:05 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 12:13:05 --> Model "Product_model" initialized
INFO - 2021-07-05 12:13:05 --> Final output sent to browser
DEBUG - 2021-07-05 12:13:05 --> Total execution time: 0.0867
INFO - 2021-07-05 12:14:03 --> Config Class Initialized
INFO - 2021-07-05 12:14:03 --> Hooks Class Initialized
DEBUG - 2021-07-05 12:14:03 --> UTF-8 Support Enabled
INFO - 2021-07-05 12:14:03 --> Utf8 Class Initialized
INFO - 2021-07-05 12:14:03 --> URI Class Initialized
INFO - 2021-07-05 12:14:03 --> Router Class Initialized
INFO - 2021-07-05 12:14:03 --> Output Class Initialized
INFO - 2021-07-05 12:14:03 --> Security Class Initialized
DEBUG - 2021-07-05 12:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 12:14:03 --> Input Class Initialized
INFO - 2021-07-05 12:14:03 --> Language Class Initialized
INFO - 2021-07-05 12:14:03 --> Loader Class Initialized
INFO - 2021-07-05 12:14:03 --> Helper loaded: html_helper
INFO - 2021-07-05 12:14:03 --> Helper loaded: url_helper
INFO - 2021-07-05 12:14:03 --> Helper loaded: form_helper
INFO - 2021-07-05 12:14:03 --> Database Driver Class Initialized
INFO - 2021-07-05 12:14:03 --> Form Validation Class Initialized
DEBUG - 2021-07-05 12:14:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 12:14:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 12:14:03 --> Encryption Class Initialized
INFO - 2021-07-05 12:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 12:14:03 --> Model "vendor_model" initialized
INFO - 2021-07-05 12:14:03 --> Model "coupon_model" initialized
INFO - 2021-07-05 12:14:03 --> Model "user_model" initialized
INFO - 2021-07-05 12:14:03 --> Model "role_model" initialized
INFO - 2021-07-05 12:14:03 --> Controller Class Initialized
INFO - 2021-07-05 12:14:03 --> Helper loaded: language_helper
INFO - 2021-07-05 12:14:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 12:14:03 --> Model "Customer_model" initialized
INFO - 2021-07-05 12:14:03 --> Model "Product_model" initialized
INFO - 2021-07-05 12:14:03 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 12:14:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 12:14:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 12:14:03 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 12:14:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 12:14:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 12:14:03 --> Final output sent to browser
DEBUG - 2021-07-05 12:14:03 --> Total execution time: 0.1176
INFO - 2021-07-05 12:14:34 --> Config Class Initialized
INFO - 2021-07-05 12:14:34 --> Hooks Class Initialized
DEBUG - 2021-07-05 12:14:34 --> UTF-8 Support Enabled
INFO - 2021-07-05 12:14:34 --> Utf8 Class Initialized
INFO - 2021-07-05 12:14:34 --> URI Class Initialized
INFO - 2021-07-05 12:14:34 --> Router Class Initialized
INFO - 2021-07-05 12:14:34 --> Output Class Initialized
INFO - 2021-07-05 12:14:34 --> Security Class Initialized
DEBUG - 2021-07-05 12:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 12:14:34 --> Input Class Initialized
INFO - 2021-07-05 12:14:34 --> Language Class Initialized
INFO - 2021-07-05 12:14:34 --> Loader Class Initialized
INFO - 2021-07-05 12:14:34 --> Helper loaded: html_helper
INFO - 2021-07-05 12:14:34 --> Helper loaded: url_helper
INFO - 2021-07-05 12:14:34 --> Helper loaded: form_helper
INFO - 2021-07-05 12:14:34 --> Database Driver Class Initialized
INFO - 2021-07-05 12:14:34 --> Form Validation Class Initialized
DEBUG - 2021-07-05 12:14:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 12:14:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 12:14:34 --> Encryption Class Initialized
INFO - 2021-07-05 12:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 12:14:34 --> Model "vendor_model" initialized
INFO - 2021-07-05 12:14:34 --> Model "coupon_model" initialized
INFO - 2021-07-05 12:14:34 --> Model "user_model" initialized
INFO - 2021-07-05 12:14:34 --> Model "role_model" initialized
INFO - 2021-07-05 12:14:34 --> Controller Class Initialized
INFO - 2021-07-05 12:14:34 --> Helper loaded: language_helper
INFO - 2021-07-05 12:14:34 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 12:14:34 --> Model "Product_model" initialized
ERROR - 2021-07-05 12:14:34 --> Query error: [Microsoft][ODBC Driver 11 for SQL Server][SQL Server]Error converting data type varchar to float. - Invalid query: INSERT INTO "Product" ("Product_ID", "Product_Name", "Product_Version", "Product_Desc", "Rate", "Edition") VALUES ('7a04bf59-2081-4590-b7be-931ebb8c40a3', 'test', '', 'test', 'test', 'test')
INFO - 2021-07-05 12:14:34 --> Language file loaded: language/english/db_lang.php
INFO - 2021-07-05 12:15:28 --> Config Class Initialized
INFO - 2021-07-05 12:15:28 --> Hooks Class Initialized
DEBUG - 2021-07-05 12:15:28 --> UTF-8 Support Enabled
INFO - 2021-07-05 12:15:28 --> Utf8 Class Initialized
INFO - 2021-07-05 12:15:28 --> URI Class Initialized
INFO - 2021-07-05 12:15:28 --> Router Class Initialized
INFO - 2021-07-05 12:15:28 --> Output Class Initialized
INFO - 2021-07-05 12:15:28 --> Security Class Initialized
DEBUG - 2021-07-05 12:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 12:15:28 --> Input Class Initialized
INFO - 2021-07-05 12:15:28 --> Language Class Initialized
INFO - 2021-07-05 12:15:28 --> Loader Class Initialized
INFO - 2021-07-05 12:15:28 --> Helper loaded: html_helper
INFO - 2021-07-05 12:15:28 --> Helper loaded: url_helper
INFO - 2021-07-05 12:15:28 --> Helper loaded: form_helper
INFO - 2021-07-05 12:15:28 --> Database Driver Class Initialized
INFO - 2021-07-05 12:15:28 --> Form Validation Class Initialized
DEBUG - 2021-07-05 12:15:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 12:15:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 12:15:28 --> Encryption Class Initialized
INFO - 2021-07-05 12:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 12:15:28 --> Model "vendor_model" initialized
INFO - 2021-07-05 12:15:28 --> Model "coupon_model" initialized
INFO - 2021-07-05 12:15:28 --> Model "user_model" initialized
INFO - 2021-07-05 12:15:28 --> Model "role_model" initialized
INFO - 2021-07-05 12:15:28 --> Controller Class Initialized
INFO - 2021-07-05 12:15:28 --> Helper loaded: language_helper
INFO - 2021-07-05 12:15:28 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 12:15:28 --> Model "Product_model" initialized
INFO - 2021-07-05 12:15:28 --> Final output sent to browser
DEBUG - 2021-07-05 12:15:28 --> Total execution time: 0.0864
INFO - 2021-07-05 12:15:39 --> Config Class Initialized
INFO - 2021-07-05 12:15:39 --> Hooks Class Initialized
DEBUG - 2021-07-05 12:15:39 --> UTF-8 Support Enabled
INFO - 2021-07-05 12:15:39 --> Utf8 Class Initialized
INFO - 2021-07-05 12:15:39 --> URI Class Initialized
INFO - 2021-07-05 12:15:39 --> Router Class Initialized
INFO - 2021-07-05 12:15:39 --> Output Class Initialized
INFO - 2021-07-05 12:15:39 --> Security Class Initialized
DEBUG - 2021-07-05 12:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 12:15:39 --> Input Class Initialized
INFO - 2021-07-05 12:15:39 --> Language Class Initialized
INFO - 2021-07-05 12:15:39 --> Loader Class Initialized
INFO - 2021-07-05 12:15:39 --> Helper loaded: html_helper
INFO - 2021-07-05 12:15:39 --> Helper loaded: url_helper
INFO - 2021-07-05 12:15:39 --> Helper loaded: form_helper
INFO - 2021-07-05 12:15:39 --> Database Driver Class Initialized
INFO - 2021-07-05 12:15:39 --> Form Validation Class Initialized
DEBUG - 2021-07-05 12:15:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 12:15:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 12:15:39 --> Encryption Class Initialized
INFO - 2021-07-05 12:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 12:15:39 --> Model "vendor_model" initialized
INFO - 2021-07-05 12:15:39 --> Model "coupon_model" initialized
INFO - 2021-07-05 12:15:39 --> Model "user_model" initialized
INFO - 2021-07-05 12:15:39 --> Model "role_model" initialized
INFO - 2021-07-05 12:15:39 --> Controller Class Initialized
INFO - 2021-07-05 12:15:39 --> Helper loaded: language_helper
INFO - 2021-07-05 12:15:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 12:15:39 --> Model "Customer_model" initialized
INFO - 2021-07-05 12:15:39 --> Model "Product_model" initialized
INFO - 2021-07-05 12:15:39 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 12:15:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 12:15:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 12:15:39 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 12:15:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 12:15:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 12:15:39 --> Final output sent to browser
DEBUG - 2021-07-05 12:15:39 --> Total execution time: 0.0737
INFO - 2021-07-05 12:16:09 --> Config Class Initialized
INFO - 2021-07-05 12:16:09 --> Hooks Class Initialized
DEBUG - 2021-07-05 12:16:09 --> UTF-8 Support Enabled
INFO - 2021-07-05 12:16:09 --> Utf8 Class Initialized
INFO - 2021-07-05 12:16:09 --> URI Class Initialized
INFO - 2021-07-05 12:16:09 --> Router Class Initialized
INFO - 2021-07-05 12:16:09 --> Output Class Initialized
INFO - 2021-07-05 12:16:09 --> Security Class Initialized
DEBUG - 2021-07-05 12:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 12:16:09 --> Input Class Initialized
INFO - 2021-07-05 12:16:09 --> Language Class Initialized
INFO - 2021-07-05 12:16:09 --> Loader Class Initialized
INFO - 2021-07-05 12:16:09 --> Helper loaded: html_helper
INFO - 2021-07-05 12:16:09 --> Helper loaded: url_helper
INFO - 2021-07-05 12:16:09 --> Helper loaded: form_helper
INFO - 2021-07-05 12:16:09 --> Database Driver Class Initialized
INFO - 2021-07-05 12:16:09 --> Form Validation Class Initialized
DEBUG - 2021-07-05 12:16:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 12:16:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 12:16:09 --> Encryption Class Initialized
INFO - 2021-07-05 12:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 12:16:09 --> Model "vendor_model" initialized
INFO - 2021-07-05 12:16:09 --> Model "coupon_model" initialized
INFO - 2021-07-05 12:16:09 --> Model "user_model" initialized
INFO - 2021-07-05 12:16:09 --> Model "role_model" initialized
INFO - 2021-07-05 12:16:09 --> Controller Class Initialized
INFO - 2021-07-05 12:16:09 --> Helper loaded: language_helper
INFO - 2021-07-05 12:16:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 12:16:09 --> Model "Product_model" initialized
INFO - 2021-07-05 12:16:09 --> Final output sent to browser
DEBUG - 2021-07-05 12:16:09 --> Total execution time: 0.0752
INFO - 2021-07-05 12:16:19 --> Config Class Initialized
INFO - 2021-07-05 12:16:19 --> Hooks Class Initialized
DEBUG - 2021-07-05 12:16:19 --> UTF-8 Support Enabled
INFO - 2021-07-05 12:16:19 --> Utf8 Class Initialized
INFO - 2021-07-05 12:16:19 --> URI Class Initialized
INFO - 2021-07-05 12:16:19 --> Router Class Initialized
INFO - 2021-07-05 12:16:19 --> Output Class Initialized
INFO - 2021-07-05 12:16:19 --> Security Class Initialized
DEBUG - 2021-07-05 12:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 12:16:19 --> Input Class Initialized
INFO - 2021-07-05 12:16:19 --> Language Class Initialized
INFO - 2021-07-05 12:16:19 --> Loader Class Initialized
INFO - 2021-07-05 12:16:19 --> Helper loaded: html_helper
INFO - 2021-07-05 12:16:19 --> Helper loaded: url_helper
INFO - 2021-07-05 12:16:19 --> Helper loaded: form_helper
INFO - 2021-07-05 12:16:19 --> Database Driver Class Initialized
INFO - 2021-07-05 12:16:19 --> Form Validation Class Initialized
DEBUG - 2021-07-05 12:16:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 12:16:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 12:16:19 --> Encryption Class Initialized
INFO - 2021-07-05 12:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 12:16:19 --> Model "vendor_model" initialized
INFO - 2021-07-05 12:16:19 --> Model "coupon_model" initialized
INFO - 2021-07-05 12:16:19 --> Model "user_model" initialized
INFO - 2021-07-05 12:16:19 --> Model "role_model" initialized
INFO - 2021-07-05 12:16:19 --> Controller Class Initialized
INFO - 2021-07-05 12:16:19 --> Helper loaded: language_helper
INFO - 2021-07-05 12:16:19 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 12:16:19 --> Model "Product_model" initialized
INFO - 2021-07-05 12:16:19 --> Final output sent to browser
DEBUG - 2021-07-05 12:16:19 --> Total execution time: 0.0597
INFO - 2021-07-05 12:16:44 --> Config Class Initialized
INFO - 2021-07-05 12:16:44 --> Hooks Class Initialized
DEBUG - 2021-07-05 12:16:44 --> UTF-8 Support Enabled
INFO - 2021-07-05 12:16:44 --> Utf8 Class Initialized
INFO - 2021-07-05 12:16:44 --> URI Class Initialized
INFO - 2021-07-05 12:16:44 --> Router Class Initialized
INFO - 2021-07-05 12:16:44 --> Output Class Initialized
INFO - 2021-07-05 12:16:44 --> Security Class Initialized
DEBUG - 2021-07-05 12:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 12:16:44 --> Input Class Initialized
INFO - 2021-07-05 12:16:44 --> Language Class Initialized
INFO - 2021-07-05 12:16:44 --> Loader Class Initialized
INFO - 2021-07-05 12:16:44 --> Helper loaded: html_helper
INFO - 2021-07-05 12:16:44 --> Helper loaded: url_helper
INFO - 2021-07-05 12:16:44 --> Helper loaded: form_helper
INFO - 2021-07-05 12:16:44 --> Database Driver Class Initialized
INFO - 2021-07-05 12:16:45 --> Form Validation Class Initialized
DEBUG - 2021-07-05 12:16:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 12:16:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 12:16:45 --> Encryption Class Initialized
INFO - 2021-07-05 12:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 12:16:45 --> Model "vendor_model" initialized
INFO - 2021-07-05 12:16:45 --> Model "coupon_model" initialized
INFO - 2021-07-05 12:16:45 --> Model "user_model" initialized
INFO - 2021-07-05 12:16:45 --> Model "role_model" initialized
INFO - 2021-07-05 12:16:45 --> Controller Class Initialized
INFO - 2021-07-05 12:16:45 --> Helper loaded: language_helper
INFO - 2021-07-05 12:16:45 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 12:16:45 --> Model "Customer_model" initialized
INFO - 2021-07-05 12:16:45 --> Model "Product_model" initialized
INFO - 2021-07-05 12:16:45 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 12:16:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 12:16:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 12:16:45 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 12:16:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 12:16:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 12:16:45 --> Final output sent to browser
DEBUG - 2021-07-05 12:16:45 --> Total execution time: 0.1385
INFO - 2021-07-05 12:17:03 --> Config Class Initialized
INFO - 2021-07-05 12:17:03 --> Hooks Class Initialized
DEBUG - 2021-07-05 12:17:03 --> UTF-8 Support Enabled
INFO - 2021-07-05 12:17:03 --> Utf8 Class Initialized
INFO - 2021-07-05 12:17:03 --> URI Class Initialized
INFO - 2021-07-05 12:17:03 --> Router Class Initialized
INFO - 2021-07-05 12:17:03 --> Output Class Initialized
INFO - 2021-07-05 12:17:03 --> Security Class Initialized
DEBUG - 2021-07-05 12:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 12:17:03 --> Input Class Initialized
INFO - 2021-07-05 12:17:03 --> Language Class Initialized
INFO - 2021-07-05 12:17:03 --> Loader Class Initialized
INFO - 2021-07-05 12:17:03 --> Helper loaded: html_helper
INFO - 2021-07-05 12:17:03 --> Helper loaded: url_helper
INFO - 2021-07-05 12:17:03 --> Helper loaded: form_helper
INFO - 2021-07-05 12:17:03 --> Database Driver Class Initialized
INFO - 2021-07-05 12:17:03 --> Form Validation Class Initialized
DEBUG - 2021-07-05 12:17:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 12:17:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 12:17:03 --> Encryption Class Initialized
INFO - 2021-07-05 12:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 12:17:03 --> Model "vendor_model" initialized
INFO - 2021-07-05 12:17:03 --> Model "coupon_model" initialized
INFO - 2021-07-05 12:17:03 --> Model "user_model" initialized
INFO - 2021-07-05 12:17:03 --> Model "role_model" initialized
INFO - 2021-07-05 12:17:03 --> Controller Class Initialized
INFO - 2021-07-05 12:17:03 --> Helper loaded: language_helper
INFO - 2021-07-05 12:17:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 12:17:03 --> Model "Customer_model" initialized
INFO - 2021-07-05 12:17:03 --> Model "Product_model" initialized
INFO - 2021-07-05 12:17:03 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 12:17:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 12:17:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 12:17:03 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 12:17:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 12:17:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 12:17:03 --> Final output sent to browser
DEBUG - 2021-07-05 12:17:03 --> Total execution time: 0.0802
INFO - 2021-07-05 12:18:33 --> Config Class Initialized
INFO - 2021-07-05 12:18:33 --> Hooks Class Initialized
DEBUG - 2021-07-05 12:18:33 --> UTF-8 Support Enabled
INFO - 2021-07-05 12:18:33 --> Utf8 Class Initialized
INFO - 2021-07-05 12:18:33 --> URI Class Initialized
INFO - 2021-07-05 12:18:33 --> Router Class Initialized
INFO - 2021-07-05 12:18:33 --> Output Class Initialized
INFO - 2021-07-05 12:18:33 --> Security Class Initialized
DEBUG - 2021-07-05 12:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 12:18:33 --> Input Class Initialized
INFO - 2021-07-05 12:18:33 --> Language Class Initialized
INFO - 2021-07-05 12:18:33 --> Loader Class Initialized
INFO - 2021-07-05 12:18:33 --> Helper loaded: html_helper
INFO - 2021-07-05 12:18:33 --> Helper loaded: url_helper
INFO - 2021-07-05 12:18:33 --> Helper loaded: form_helper
INFO - 2021-07-05 12:18:33 --> Database Driver Class Initialized
INFO - 2021-07-05 12:18:33 --> Form Validation Class Initialized
DEBUG - 2021-07-05 12:18:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 12:18:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 12:18:33 --> Encryption Class Initialized
INFO - 2021-07-05 12:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 12:18:33 --> Model "vendor_model" initialized
INFO - 2021-07-05 12:18:33 --> Model "coupon_model" initialized
INFO - 2021-07-05 12:18:33 --> Model "user_model" initialized
INFO - 2021-07-05 12:18:33 --> Model "role_model" initialized
INFO - 2021-07-05 12:18:33 --> Controller Class Initialized
INFO - 2021-07-05 12:18:33 --> Helper loaded: language_helper
INFO - 2021-07-05 12:18:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 12:18:33 --> Model "Customer_model" initialized
INFO - 2021-07-05 12:18:33 --> Model "Product_model" initialized
INFO - 2021-07-05 12:18:33 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 12:18:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 12:18:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 12:18:33 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 12:18:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 12:18:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 12:18:33 --> Final output sent to browser
DEBUG - 2021-07-05 12:18:33 --> Total execution time: 0.1313
INFO - 2021-07-05 12:19:14 --> Config Class Initialized
INFO - 2021-07-05 12:19:14 --> Hooks Class Initialized
DEBUG - 2021-07-05 12:19:14 --> UTF-8 Support Enabled
INFO - 2021-07-05 12:19:14 --> Utf8 Class Initialized
INFO - 2021-07-05 12:19:14 --> URI Class Initialized
INFO - 2021-07-05 12:19:14 --> Router Class Initialized
INFO - 2021-07-05 12:19:14 --> Output Class Initialized
INFO - 2021-07-05 12:19:14 --> Security Class Initialized
DEBUG - 2021-07-05 12:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 12:19:14 --> Input Class Initialized
INFO - 2021-07-05 12:19:14 --> Language Class Initialized
INFO - 2021-07-05 12:19:14 --> Loader Class Initialized
INFO - 2021-07-05 12:19:14 --> Helper loaded: html_helper
INFO - 2021-07-05 12:19:14 --> Helper loaded: url_helper
INFO - 2021-07-05 12:19:14 --> Helper loaded: form_helper
INFO - 2021-07-05 12:19:14 --> Database Driver Class Initialized
INFO - 2021-07-05 12:19:14 --> Form Validation Class Initialized
DEBUG - 2021-07-05 12:19:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 12:19:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 12:19:14 --> Encryption Class Initialized
INFO - 2021-07-05 12:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 12:19:14 --> Model "vendor_model" initialized
INFO - 2021-07-05 12:19:14 --> Model "coupon_model" initialized
INFO - 2021-07-05 12:19:14 --> Model "user_model" initialized
INFO - 2021-07-05 12:19:14 --> Model "role_model" initialized
INFO - 2021-07-05 12:19:14 --> Controller Class Initialized
INFO - 2021-07-05 12:19:14 --> Helper loaded: language_helper
INFO - 2021-07-05 12:19:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 12:19:14 --> Model "Customer_model" initialized
INFO - 2021-07-05 12:19:14 --> Model "Product_model" initialized
INFO - 2021-07-05 12:19:14 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 12:19:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 12:19:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 12:19:14 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 12:19:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 12:19:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 12:19:14 --> Final output sent to browser
DEBUG - 2021-07-05 12:19:14 --> Total execution time: 0.0691
INFO - 2021-07-05 12:23:05 --> Config Class Initialized
INFO - 2021-07-05 12:23:05 --> Hooks Class Initialized
DEBUG - 2021-07-05 12:23:05 --> UTF-8 Support Enabled
INFO - 2021-07-05 12:23:05 --> Utf8 Class Initialized
INFO - 2021-07-05 12:23:05 --> URI Class Initialized
INFO - 2021-07-05 12:23:05 --> Router Class Initialized
INFO - 2021-07-05 12:23:05 --> Output Class Initialized
INFO - 2021-07-05 12:23:05 --> Security Class Initialized
DEBUG - 2021-07-05 12:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 12:23:05 --> Input Class Initialized
INFO - 2021-07-05 12:23:05 --> Language Class Initialized
INFO - 2021-07-05 12:23:05 --> Loader Class Initialized
INFO - 2021-07-05 12:23:05 --> Helper loaded: html_helper
INFO - 2021-07-05 12:23:05 --> Helper loaded: url_helper
INFO - 2021-07-05 12:23:05 --> Helper loaded: form_helper
INFO - 2021-07-05 12:23:05 --> Database Driver Class Initialized
INFO - 2021-07-05 12:23:05 --> Form Validation Class Initialized
DEBUG - 2021-07-05 12:23:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 12:23:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 12:23:05 --> Encryption Class Initialized
INFO - 2021-07-05 12:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 12:23:05 --> Model "vendor_model" initialized
INFO - 2021-07-05 12:23:05 --> Model "coupon_model" initialized
INFO - 2021-07-05 12:23:05 --> Model "user_model" initialized
INFO - 2021-07-05 12:23:05 --> Model "role_model" initialized
INFO - 2021-07-05 12:23:05 --> Controller Class Initialized
INFO - 2021-07-05 12:23:05 --> Helper loaded: language_helper
INFO - 2021-07-05 12:23:05 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 12:23:05 --> Model "Customer_model" initialized
INFO - 2021-07-05 12:23:05 --> Model "Product_model" initialized
INFO - 2021-07-05 12:23:05 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 12:23:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 12:23:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 12:23:05 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 12:23:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 12:23:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 12:23:05 --> Final output sent to browser
DEBUG - 2021-07-05 12:23:05 --> Total execution time: 0.1099
INFO - 2021-07-05 12:28:09 --> Config Class Initialized
INFO - 2021-07-05 12:28:09 --> Hooks Class Initialized
DEBUG - 2021-07-05 12:28:09 --> UTF-8 Support Enabled
INFO - 2021-07-05 12:28:09 --> Utf8 Class Initialized
INFO - 2021-07-05 12:28:09 --> URI Class Initialized
INFO - 2021-07-05 12:28:09 --> Router Class Initialized
INFO - 2021-07-05 12:28:09 --> Output Class Initialized
INFO - 2021-07-05 12:28:09 --> Security Class Initialized
DEBUG - 2021-07-05 12:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 12:28:09 --> Input Class Initialized
INFO - 2021-07-05 12:28:09 --> Language Class Initialized
INFO - 2021-07-05 12:28:09 --> Loader Class Initialized
INFO - 2021-07-05 12:28:09 --> Helper loaded: html_helper
INFO - 2021-07-05 12:28:09 --> Helper loaded: url_helper
INFO - 2021-07-05 12:28:09 --> Helper loaded: form_helper
INFO - 2021-07-05 12:28:09 --> Database Driver Class Initialized
INFO - 2021-07-05 12:28:09 --> Form Validation Class Initialized
DEBUG - 2021-07-05 12:28:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 12:28:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 12:28:09 --> Encryption Class Initialized
INFO - 2021-07-05 12:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 12:28:09 --> Model "vendor_model" initialized
INFO - 2021-07-05 12:28:09 --> Model "coupon_model" initialized
INFO - 2021-07-05 12:28:09 --> Model "user_model" initialized
INFO - 2021-07-05 12:28:09 --> Model "role_model" initialized
INFO - 2021-07-05 12:28:09 --> Controller Class Initialized
INFO - 2021-07-05 12:28:09 --> Helper loaded: language_helper
INFO - 2021-07-05 12:28:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 12:28:09 --> Model "Customer_model" initialized
INFO - 2021-07-05 12:28:09 --> Model "Product_model" initialized
INFO - 2021-07-05 12:28:09 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 12:28:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 12:28:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 12:28:09 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 12:28:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 12:28:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 12:28:09 --> Final output sent to browser
DEBUG - 2021-07-05 12:28:09 --> Total execution time: 0.1342
INFO - 2021-07-05 12:30:06 --> Config Class Initialized
INFO - 2021-07-05 12:30:06 --> Hooks Class Initialized
DEBUG - 2021-07-05 12:30:06 --> UTF-8 Support Enabled
INFO - 2021-07-05 12:30:06 --> Utf8 Class Initialized
INFO - 2021-07-05 12:30:06 --> URI Class Initialized
INFO - 2021-07-05 12:30:06 --> Router Class Initialized
INFO - 2021-07-05 12:30:06 --> Output Class Initialized
INFO - 2021-07-05 12:30:06 --> Security Class Initialized
DEBUG - 2021-07-05 12:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 12:30:06 --> Input Class Initialized
INFO - 2021-07-05 12:30:06 --> Language Class Initialized
INFO - 2021-07-05 12:30:06 --> Loader Class Initialized
INFO - 2021-07-05 12:30:06 --> Helper loaded: html_helper
INFO - 2021-07-05 12:30:06 --> Helper loaded: url_helper
INFO - 2021-07-05 12:30:06 --> Helper loaded: form_helper
INFO - 2021-07-05 12:30:06 --> Database Driver Class Initialized
INFO - 2021-07-05 12:30:06 --> Form Validation Class Initialized
DEBUG - 2021-07-05 12:30:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-05 12:30:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-05 12:30:06 --> Encryption Class Initialized
INFO - 2021-07-05 12:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 12:30:06 --> Model "vendor_model" initialized
INFO - 2021-07-05 12:30:06 --> Model "coupon_model" initialized
INFO - 2021-07-05 12:30:06 --> Model "user_model" initialized
INFO - 2021-07-05 12:30:06 --> Model "role_model" initialized
INFO - 2021-07-05 12:30:06 --> Controller Class Initialized
INFO - 2021-07-05 12:30:06 --> Helper loaded: language_helper
INFO - 2021-07-05 12:30:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-05 12:30:06 --> Model "Customer_model" initialized
INFO - 2021-07-05 12:30:06 --> Model "Product_model" initialized
INFO - 2021-07-05 12:30:06 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-05 12:30:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-05 12:30:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-05 12:30:06 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-05 12:30:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-05 12:30:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-05 12:30:06 --> Final output sent to browser
DEBUG - 2021-07-05 12:30:06 --> Total execution time: 0.1238
