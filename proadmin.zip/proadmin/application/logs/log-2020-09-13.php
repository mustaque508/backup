<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-13 15:02:34 --> Config Class Initialized
INFO - 2020-09-13 15:02:34 --> Hooks Class Initialized
DEBUG - 2020-09-13 15:02:35 --> UTF-8 Support Enabled
INFO - 2020-09-13 15:02:35 --> Utf8 Class Initialized
INFO - 2020-09-13 15:02:35 --> URI Class Initialized
INFO - 2020-09-13 15:02:35 --> Router Class Initialized
INFO - 2020-09-13 15:02:35 --> Output Class Initialized
INFO - 2020-09-13 15:02:35 --> Security Class Initialized
DEBUG - 2020-09-13 15:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 15:02:35 --> Input Class Initialized
INFO - 2020-09-13 15:02:35 --> Language Class Initialized
INFO - 2020-09-13 15:02:35 --> Loader Class Initialized
INFO - 2020-09-13 15:02:36 --> Helper loaded: html_helper
INFO - 2020-09-13 15:02:36 --> Helper loaded: url_helper
INFO - 2020-09-13 15:02:36 --> Helper loaded: form_helper
INFO - 2020-09-13 15:02:36 --> Database Driver Class Initialized
INFO - 2020-09-13 15:02:36 --> Form Validation Class Initialized
DEBUG - 2020-09-13 15:02:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-13 15:02:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-13 15:02:36 --> Encryption Class Initialized
INFO - 2020-09-13 15:02:37 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-13 15:02:37 --> Controller Class Initialized
INFO - 2020-09-13 15:02:37 --> Helper loaded: language_helper
INFO - 2020-09-13 15:02:37 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-13 15:02:37 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-13 15:02:37 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-13 15:02:37 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment_custom.php
INFO - 2020-09-13 15:02:37 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-13 15:02:37 --> Final output sent to browser
DEBUG - 2020-09-13 15:02:37 --> Total execution time: 3.0235
