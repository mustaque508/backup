<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-03-31 09:39:25 --> Config Class Initialized
INFO - 2021-03-31 09:39:25 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:39:25 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:39:25 --> Utf8 Class Initialized
INFO - 2021-03-31 09:39:26 --> URI Class Initialized
DEBUG - 2021-03-31 09:39:26 --> No URI present. Default controller set.
INFO - 2021-03-31 09:39:26 --> Router Class Initialized
INFO - 2021-03-31 09:39:26 --> Output Class Initialized
INFO - 2021-03-31 09:39:26 --> Security Class Initialized
DEBUG - 2021-03-31 09:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:39:26 --> Input Class Initialized
INFO - 2021-03-31 09:39:26 --> Language Class Initialized
INFO - 2021-03-31 09:39:26 --> Loader Class Initialized
INFO - 2021-03-31 09:39:26 --> Helper loaded: html_helper
INFO - 2021-03-31 09:39:26 --> Helper loaded: url_helper
INFO - 2021-03-31 09:39:26 --> Helper loaded: form_helper
INFO - 2021-03-31 09:39:27 --> Database Driver Class Initialized
INFO - 2021-03-31 09:39:27 --> Form Validation Class Initialized
DEBUG - 2021-03-31 09:39:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-03-31 09:39:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-03-31 09:39:27 --> Encryption Class Initialized
INFO - 2021-03-31 09:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:39:27 --> Model "vendor_model" initialized
INFO - 2021-03-31 09:39:28 --> Model "coupon_model" initialized
INFO - 2021-03-31 09:39:28 --> Model "user_model" initialized
INFO - 2021-03-31 09:39:28 --> Model "role_model" initialized
INFO - 2021-03-31 09:39:28 --> Controller Class Initialized
INFO - 2021-03-31 09:39:28 --> Helper loaded: language_helper
INFO - 2021-03-31 09:39:28 --> Language file loaded: language/english/content_lang.php
INFO - 2021-03-31 09:39:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\login.php
INFO - 2021-03-31 09:39:28 --> Final output sent to browser
DEBUG - 2021-03-31 09:39:28 --> Total execution time: 3.7379
INFO - 2021-03-31 09:39:40 --> Config Class Initialized
INFO - 2021-03-31 09:39:40 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:39:40 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:39:40 --> Utf8 Class Initialized
INFO - 2021-03-31 09:39:40 --> URI Class Initialized
INFO - 2021-03-31 09:39:40 --> Router Class Initialized
INFO - 2021-03-31 09:39:40 --> Output Class Initialized
INFO - 2021-03-31 09:39:40 --> Security Class Initialized
DEBUG - 2021-03-31 09:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:39:40 --> Input Class Initialized
INFO - 2021-03-31 09:39:40 --> Language Class Initialized
INFO - 2021-03-31 09:39:40 --> Loader Class Initialized
INFO - 2021-03-31 09:39:40 --> Helper loaded: html_helper
INFO - 2021-03-31 09:39:40 --> Helper loaded: url_helper
INFO - 2021-03-31 09:39:41 --> Helper loaded: form_helper
INFO - 2021-03-31 09:39:41 --> Database Driver Class Initialized
INFO - 2021-03-31 09:39:41 --> Form Validation Class Initialized
DEBUG - 2021-03-31 09:39:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-03-31 09:39:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-03-31 09:39:41 --> Encryption Class Initialized
INFO - 2021-03-31 09:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:39:41 --> Model "vendor_model" initialized
INFO - 2021-03-31 09:39:41 --> Model "coupon_model" initialized
INFO - 2021-03-31 09:39:41 --> Model "user_model" initialized
INFO - 2021-03-31 09:39:41 --> Model "role_model" initialized
INFO - 2021-03-31 09:39:41 --> Controller Class Initialized
INFO - 2021-03-31 09:39:41 --> Helper loaded: language_helper
INFO - 2021-03-31 09:39:41 --> Language file loaded: language/english/content_lang.php
DEBUG - 2021-03-31 09:39:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-03-31 09:39:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-31 09:39:41 --> Model "User" initialized
INFO - 2021-03-31 09:39:41 --> Config Class Initialized
INFO - 2021-03-31 09:39:41 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:39:41 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:39:41 --> Utf8 Class Initialized
INFO - 2021-03-31 09:39:41 --> URI Class Initialized
INFO - 2021-03-31 09:39:41 --> Router Class Initialized
INFO - 2021-03-31 09:39:41 --> Output Class Initialized
INFO - 2021-03-31 09:39:41 --> Security Class Initialized
DEBUG - 2021-03-31 09:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:39:41 --> Input Class Initialized
INFO - 2021-03-31 09:39:41 --> Language Class Initialized
INFO - 2021-03-31 09:39:41 --> Loader Class Initialized
INFO - 2021-03-31 09:39:41 --> Helper loaded: html_helper
INFO - 2021-03-31 09:39:41 --> Helper loaded: url_helper
INFO - 2021-03-31 09:39:41 --> Helper loaded: form_helper
INFO - 2021-03-31 09:39:41 --> Database Driver Class Initialized
INFO - 2021-03-31 09:39:41 --> Form Validation Class Initialized
DEBUG - 2021-03-31 09:39:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-03-31 09:39:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-03-31 09:39:41 --> Encryption Class Initialized
INFO - 2021-03-31 09:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:39:42 --> Model "vendor_model" initialized
INFO - 2021-03-31 09:39:42 --> Model "coupon_model" initialized
INFO - 2021-03-31 09:39:42 --> Model "user_model" initialized
INFO - 2021-03-31 09:39:42 --> Model "role_model" initialized
INFO - 2021-03-31 09:39:42 --> Controller Class Initialized
INFO - 2021-03-31 09:39:42 --> Helper loaded: language_helper
INFO - 2021-03-31 09:39:42 --> Language file loaded: language/english/content_lang.php
INFO - 2021-03-31 09:39:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-03-31 09:39:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-03-31 09:39:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-03-31 09:39:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-03-31 09:39:42 --> Final output sent to browser
DEBUG - 2021-03-31 09:39:42 --> Total execution time: 0.7448
INFO - 2021-03-31 09:39:53 --> Config Class Initialized
INFO - 2021-03-31 09:39:53 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:39:53 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:39:53 --> Utf8 Class Initialized
INFO - 2021-03-31 09:39:53 --> URI Class Initialized
INFO - 2021-03-31 09:39:53 --> Router Class Initialized
INFO - 2021-03-31 09:39:53 --> Output Class Initialized
INFO - 2021-03-31 09:39:53 --> Security Class Initialized
DEBUG - 2021-03-31 09:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:39:53 --> Input Class Initialized
INFO - 2021-03-31 09:39:53 --> Language Class Initialized
INFO - 2021-03-31 09:39:53 --> Loader Class Initialized
INFO - 2021-03-31 09:39:53 --> Helper loaded: html_helper
INFO - 2021-03-31 09:39:53 --> Helper loaded: url_helper
INFO - 2021-03-31 09:39:53 --> Helper loaded: form_helper
INFO - 2021-03-31 09:39:53 --> Database Driver Class Initialized
INFO - 2021-03-31 09:39:53 --> Form Validation Class Initialized
DEBUG - 2021-03-31 09:39:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-03-31 09:39:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-03-31 09:39:53 --> Encryption Class Initialized
INFO - 2021-03-31 09:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:39:53 --> Model "vendor_model" initialized
INFO - 2021-03-31 09:39:53 --> Model "coupon_model" initialized
INFO - 2021-03-31 09:39:53 --> Model "user_model" initialized
INFO - 2021-03-31 09:39:53 --> Model "role_model" initialized
INFO - 2021-03-31 09:39:53 --> Controller Class Initialized
INFO - 2021-03-31 09:39:53 --> Helper loaded: language_helper
INFO - 2021-03-31 09:39:53 --> Language file loaded: language/english/content_lang.php
INFO - 2021-03-31 09:39:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-03-31 09:39:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-03-31 09:39:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\create_role.php
INFO - 2021-03-31 09:39:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-03-31 09:39:53 --> Final output sent to browser
DEBUG - 2021-03-31 09:39:53 --> Total execution time: 0.6702
INFO - 2021-03-31 09:39:59 --> Config Class Initialized
INFO - 2021-03-31 09:39:59 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:39:59 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:39:59 --> Utf8 Class Initialized
INFO - 2021-03-31 09:39:59 --> URI Class Initialized
INFO - 2021-03-31 09:39:59 --> Router Class Initialized
INFO - 2021-03-31 09:40:00 --> Output Class Initialized
INFO - 2021-03-31 09:40:00 --> Security Class Initialized
DEBUG - 2021-03-31 09:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:40:00 --> Input Class Initialized
INFO - 2021-03-31 09:40:00 --> Language Class Initialized
INFO - 2021-03-31 09:40:00 --> Loader Class Initialized
INFO - 2021-03-31 09:40:00 --> Helper loaded: html_helper
INFO - 2021-03-31 09:40:00 --> Helper loaded: url_helper
INFO - 2021-03-31 09:40:00 --> Helper loaded: form_helper
INFO - 2021-03-31 09:40:00 --> Database Driver Class Initialized
INFO - 2021-03-31 09:40:00 --> Form Validation Class Initialized
DEBUG - 2021-03-31 09:40:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-03-31 09:40:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-03-31 09:40:00 --> Encryption Class Initialized
INFO - 2021-03-31 09:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:40:00 --> Model "vendor_model" initialized
INFO - 2021-03-31 09:40:00 --> Model "coupon_model" initialized
INFO - 2021-03-31 09:40:00 --> Model "user_model" initialized
INFO - 2021-03-31 09:40:00 --> Model "role_model" initialized
INFO - 2021-03-31 09:40:00 --> Controller Class Initialized
INFO - 2021-03-31 09:40:00 --> Helper loaded: language_helper
INFO - 2021-03-31 09:40:00 --> Language file loaded: language/english/content_lang.php
INFO - 2021-03-31 09:40:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-03-31 09:40:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-03-31 09:40:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\create_role.php
INFO - 2021-03-31 09:40:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-03-31 09:40:00 --> Final output sent to browser
DEBUG - 2021-03-31 09:40:00 --> Total execution time: 0.4114
INFO - 2021-03-31 09:40:00 --> Config Class Initialized
INFO - 2021-03-31 09:40:00 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:40:00 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:40:00 --> Utf8 Class Initialized
INFO - 2021-03-31 09:40:00 --> URI Class Initialized
INFO - 2021-03-31 09:40:00 --> Router Class Initialized
INFO - 2021-03-31 09:40:00 --> Output Class Initialized
INFO - 2021-03-31 09:40:00 --> Security Class Initialized
DEBUG - 2021-03-31 09:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:40:00 --> Input Class Initialized
INFO - 2021-03-31 09:40:00 --> Language Class Initialized
INFO - 2021-03-31 09:40:00 --> Loader Class Initialized
INFO - 2021-03-31 09:40:00 --> Helper loaded: html_helper
INFO - 2021-03-31 09:40:00 --> Helper loaded: url_helper
INFO - 2021-03-31 09:40:00 --> Helper loaded: form_helper
INFO - 2021-03-31 09:40:00 --> Database Driver Class Initialized
INFO - 2021-03-31 09:40:00 --> Form Validation Class Initialized
DEBUG - 2021-03-31 09:40:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-03-31 09:40:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-03-31 09:40:00 --> Encryption Class Initialized
INFO - 2021-03-31 09:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:40:01 --> Model "vendor_model" initialized
INFO - 2021-03-31 09:40:01 --> Model "coupon_model" initialized
INFO - 2021-03-31 09:40:01 --> Model "user_model" initialized
INFO - 2021-03-31 09:40:01 --> Model "role_model" initialized
INFO - 2021-03-31 09:40:01 --> Controller Class Initialized
INFO - 2021-03-31 09:40:01 --> Helper loaded: language_helper
INFO - 2021-03-31 09:40:01 --> Language file loaded: language/english/content_lang.php
INFO - 2021-03-31 09:40:01 --> Final output sent to browser
DEBUG - 2021-03-31 09:40:01 --> Total execution time: 0.5156
INFO - 2021-03-31 09:40:06 --> Config Class Initialized
INFO - 2021-03-31 09:40:06 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:40:06 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:40:06 --> Utf8 Class Initialized
INFO - 2021-03-31 09:40:06 --> URI Class Initialized
INFO - 2021-03-31 09:40:06 --> Router Class Initialized
INFO - 2021-03-31 09:40:06 --> Output Class Initialized
INFO - 2021-03-31 09:40:06 --> Security Class Initialized
DEBUG - 2021-03-31 09:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:40:06 --> Input Class Initialized
INFO - 2021-03-31 09:40:06 --> Language Class Initialized
INFO - 2021-03-31 09:40:06 --> Loader Class Initialized
INFO - 2021-03-31 09:40:06 --> Helper loaded: html_helper
INFO - 2021-03-31 09:40:06 --> Helper loaded: url_helper
INFO - 2021-03-31 09:40:06 --> Helper loaded: form_helper
INFO - 2021-03-31 09:40:06 --> Database Driver Class Initialized
INFO - 2021-03-31 09:40:06 --> Form Validation Class Initialized
DEBUG - 2021-03-31 09:40:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-03-31 09:40:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-03-31 09:40:06 --> Encryption Class Initialized
INFO - 2021-03-31 09:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:40:06 --> Model "vendor_model" initialized
INFO - 2021-03-31 09:40:06 --> Model "coupon_model" initialized
INFO - 2021-03-31 09:40:06 --> Model "user_model" initialized
INFO - 2021-03-31 09:40:06 --> Model "role_model" initialized
INFO - 2021-03-31 09:40:06 --> Controller Class Initialized
INFO - 2021-03-31 09:40:06 --> Helper loaded: language_helper
INFO - 2021-03-31 09:40:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-03-31 09:40:06 --> Final output sent to browser
DEBUG - 2021-03-31 09:40:06 --> Total execution time: 0.3872
INFO - 2021-03-31 09:40:11 --> Config Class Initialized
INFO - 2021-03-31 09:40:11 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:40:11 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:40:11 --> Utf8 Class Initialized
INFO - 2021-03-31 09:40:11 --> URI Class Initialized
INFO - 2021-03-31 09:40:11 --> Router Class Initialized
INFO - 2021-03-31 09:40:12 --> Output Class Initialized
INFO - 2021-03-31 09:40:12 --> Security Class Initialized
DEBUG - 2021-03-31 09:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:40:12 --> Input Class Initialized
INFO - 2021-03-31 09:40:12 --> Language Class Initialized
INFO - 2021-03-31 09:40:12 --> Loader Class Initialized
INFO - 2021-03-31 09:40:12 --> Helper loaded: html_helper
INFO - 2021-03-31 09:40:12 --> Helper loaded: url_helper
INFO - 2021-03-31 09:40:12 --> Helper loaded: form_helper
INFO - 2021-03-31 09:40:12 --> Database Driver Class Initialized
INFO - 2021-03-31 09:40:12 --> Form Validation Class Initialized
DEBUG - 2021-03-31 09:40:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-03-31 09:40:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-03-31 09:40:12 --> Encryption Class Initialized
INFO - 2021-03-31 09:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:40:12 --> Model "vendor_model" initialized
INFO - 2021-03-31 09:40:12 --> Model "coupon_model" initialized
INFO - 2021-03-31 09:40:12 --> Model "user_model" initialized
INFO - 2021-03-31 09:40:12 --> Model "role_model" initialized
INFO - 2021-03-31 09:40:12 --> Controller Class Initialized
INFO - 2021-03-31 09:40:12 --> Helper loaded: language_helper
INFO - 2021-03-31 09:40:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-03-31 09:40:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-03-31 09:40:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-03-31 09:40:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\create_role.php
INFO - 2021-03-31 09:40:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-03-31 09:40:12 --> Final output sent to browser
DEBUG - 2021-03-31 09:40:12 --> Total execution time: 0.4481
INFO - 2021-03-31 09:40:13 --> Config Class Initialized
INFO - 2021-03-31 09:40:13 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:40:13 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:40:13 --> Utf8 Class Initialized
INFO - 2021-03-31 09:40:13 --> URI Class Initialized
INFO - 2021-03-31 09:40:13 --> Router Class Initialized
INFO - 2021-03-31 09:40:13 --> Output Class Initialized
INFO - 2021-03-31 09:40:13 --> Security Class Initialized
DEBUG - 2021-03-31 09:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:40:13 --> Input Class Initialized
INFO - 2021-03-31 09:40:13 --> Language Class Initialized
INFO - 2021-03-31 09:40:13 --> Loader Class Initialized
INFO - 2021-03-31 09:40:13 --> Helper loaded: html_helper
INFO - 2021-03-31 09:40:13 --> Helper loaded: url_helper
INFO - 2021-03-31 09:40:13 --> Helper loaded: form_helper
INFO - 2021-03-31 09:40:13 --> Database Driver Class Initialized
INFO - 2021-03-31 09:40:13 --> Form Validation Class Initialized
DEBUG - 2021-03-31 09:40:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-03-31 09:40:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-03-31 09:40:13 --> Encryption Class Initialized
INFO - 2021-03-31 09:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:40:13 --> Model "vendor_model" initialized
INFO - 2021-03-31 09:40:13 --> Model "coupon_model" initialized
INFO - 2021-03-31 09:40:13 --> Model "user_model" initialized
INFO - 2021-03-31 09:40:13 --> Model "role_model" initialized
INFO - 2021-03-31 09:40:13 --> Controller Class Initialized
INFO - 2021-03-31 09:40:13 --> Helper loaded: language_helper
INFO - 2021-03-31 09:40:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-03-31 09:40:13 --> Final output sent to browser
DEBUG - 2021-03-31 09:40:13 --> Total execution time: 0.4729
