<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-17 06:06:42 --> Config Class Initialized
INFO - 2020-09-17 06:06:42 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:06:42 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:06:42 --> Utf8 Class Initialized
INFO - 2020-09-17 06:06:42 --> URI Class Initialized
DEBUG - 2020-09-17 06:06:43 --> No URI present. Default controller set.
INFO - 2020-09-17 06:06:43 --> Router Class Initialized
INFO - 2020-09-17 06:06:43 --> Output Class Initialized
INFO - 2020-09-17 06:06:43 --> Security Class Initialized
DEBUG - 2020-09-17 06:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:06:43 --> Input Class Initialized
INFO - 2020-09-17 06:06:43 --> Language Class Initialized
INFO - 2020-09-17 06:06:43 --> Loader Class Initialized
INFO - 2020-09-17 06:06:44 --> Helper loaded: html_helper
INFO - 2020-09-17 06:06:44 --> Helper loaded: url_helper
INFO - 2020-09-17 06:06:44 --> Helper loaded: form_helper
INFO - 2020-09-17 06:06:44 --> Database Driver Class Initialized
INFO - 2020-09-17 06:06:45 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:06:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:06:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:06:45 --> Encryption Class Initialized
INFO - 2020-09-17 06:06:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:06:45 --> Controller Class Initialized
INFO - 2020-09-17 06:06:45 --> Helper loaded: language_helper
INFO - 2020-09-17 06:06:46 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 06:06:46 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 06:06:46 --> Final output sent to browser
DEBUG - 2020-09-17 06:06:46 --> Total execution time: 4.2034
ERROR - 2020-09-17 06:06:46 --> Query error: [Microsoft][ODBC Driver 17 for SQL Server][SQL Server]Implicit conversion from data type varchar to varbinary(max) is not allowed. Use the CONVERT function to run this query. - Invalid query: INSERT INTO "ci_sessions" ("id", "ip_address", "timestamp", "data") VALUES ('is1lb4pntbb13rps3vj9fgjdhtekrvj7', '112.133.237.14', 1600322806, '__ci_last_regenerate|i:1600322805;site_lang|s:7:"english";')
INFO - 2020-09-17 06:06:46 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-17 06:06:46 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-09-17 06:06:46 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\Windows\Temp) Unknown 0
INFO - 2020-09-17 06:08:39 --> Config Class Initialized
INFO - 2020-09-17 06:08:39 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:08:40 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:08:40 --> Utf8 Class Initialized
INFO - 2020-09-17 06:08:40 --> URI Class Initialized
DEBUG - 2020-09-17 06:08:40 --> No URI present. Default controller set.
INFO - 2020-09-17 06:08:40 --> Router Class Initialized
INFO - 2020-09-17 06:08:40 --> Output Class Initialized
INFO - 2020-09-17 06:08:40 --> Security Class Initialized
DEBUG - 2020-09-17 06:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:08:40 --> Input Class Initialized
INFO - 2020-09-17 06:08:40 --> Language Class Initialized
INFO - 2020-09-17 06:08:40 --> Loader Class Initialized
INFO - 2020-09-17 06:08:40 --> Helper loaded: html_helper
INFO - 2020-09-17 06:08:40 --> Helper loaded: url_helper
INFO - 2020-09-17 06:08:40 --> Helper loaded: form_helper
INFO - 2020-09-17 06:08:40 --> Database Driver Class Initialized
INFO - 2020-09-17 06:08:40 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:08:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:08:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:08:40 --> Encryption Class Initialized
INFO - 2020-09-17 06:08:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:08:40 --> Controller Class Initialized
INFO - 2020-09-17 06:08:40 --> Helper loaded: language_helper
INFO - 2020-09-17 06:08:40 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 06:08:40 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 06:08:40 --> Final output sent to browser
DEBUG - 2020-09-17 06:08:40 --> Total execution time: 0.8963
INFO - 2020-09-17 06:08:48 --> Config Class Initialized
INFO - 2020-09-17 06:08:48 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:08:48 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:08:48 --> Utf8 Class Initialized
INFO - 2020-09-17 06:08:48 --> URI Class Initialized
INFO - 2020-09-17 06:08:48 --> Router Class Initialized
INFO - 2020-09-17 06:08:48 --> Output Class Initialized
INFO - 2020-09-17 06:08:48 --> Security Class Initialized
DEBUG - 2020-09-17 06:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:08:48 --> Input Class Initialized
INFO - 2020-09-17 06:08:48 --> Language Class Initialized
INFO - 2020-09-17 06:08:48 --> Loader Class Initialized
INFO - 2020-09-17 06:08:48 --> Helper loaded: html_helper
INFO - 2020-09-17 06:08:48 --> Helper loaded: url_helper
INFO - 2020-09-17 06:08:48 --> Helper loaded: form_helper
INFO - 2020-09-17 06:08:48 --> Database Driver Class Initialized
INFO - 2020-09-17 06:08:48 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:08:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:08:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:08:48 --> Encryption Class Initialized
INFO - 2020-09-17 06:08:49 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:08:49 --> Controller Class Initialized
INFO - 2020-09-17 06:08:49 --> Helper loaded: language_helper
INFO - 2020-09-17 06:08:49 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-17 06:08:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-17 06:08:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-17 06:08:49 --> Model "User" initialized
ERROR - 2020-09-17 06:08:49 --> Query error: [Microsoft][ODBC Driver 17 for SQL Server][SQL Server]Invalid object name 'tbl_users'. - Invalid query: SELECT "tbl_users"."user_id", "tbl_users"."user_name", "tbl_users"."password", "tbl_users"."contact_no", "tbl_roles"."role_id", "tbl_roles"."role_name"
FROM "tbl_users"
LEFT JOIN "tbl_roles" ON "tbl_users"."role_id" = "tbl_roles"."role_id"
WHERE "tbl_users"."user_name" = 'admin'
AND "tbl_users"."password" = 'YWRtaW4='
INFO - 2020-09-17 06:08:49 --> Language file loaded: language/english/db_lang.php
INFO - 2020-09-17 06:15:24 --> Config Class Initialized
INFO - 2020-09-17 06:15:24 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:15:24 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:15:24 --> Utf8 Class Initialized
INFO - 2020-09-17 06:15:24 --> URI Class Initialized
DEBUG - 2020-09-17 06:15:24 --> No URI present. Default controller set.
INFO - 2020-09-17 06:15:24 --> Router Class Initialized
INFO - 2020-09-17 06:15:24 --> Output Class Initialized
INFO - 2020-09-17 06:15:24 --> Security Class Initialized
DEBUG - 2020-09-17 06:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:15:24 --> Input Class Initialized
INFO - 2020-09-17 06:15:25 --> Language Class Initialized
INFO - 2020-09-17 06:15:25 --> Loader Class Initialized
INFO - 2020-09-17 06:15:25 --> Helper loaded: html_helper
INFO - 2020-09-17 06:15:25 --> Helper loaded: url_helper
INFO - 2020-09-17 06:15:25 --> Helper loaded: form_helper
INFO - 2020-09-17 06:15:25 --> Database Driver Class Initialized
INFO - 2020-09-17 06:15:25 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:15:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:15:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:15:25 --> Encryption Class Initialized
INFO - 2020-09-17 06:15:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:15:25 --> Controller Class Initialized
INFO - 2020-09-17 06:15:25 --> Helper loaded: language_helper
INFO - 2020-09-17 06:15:25 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 06:15:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 06:15:25 --> Final output sent to browser
DEBUG - 2020-09-17 06:15:25 --> Total execution time: 0.8274
INFO - 2020-09-17 06:15:27 --> Config Class Initialized
INFO - 2020-09-17 06:15:27 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:15:27 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:15:27 --> Utf8 Class Initialized
INFO - 2020-09-17 06:15:27 --> URI Class Initialized
DEBUG - 2020-09-17 06:15:27 --> No URI present. Default controller set.
INFO - 2020-09-17 06:15:27 --> Router Class Initialized
INFO - 2020-09-17 06:15:27 --> Output Class Initialized
INFO - 2020-09-17 06:15:27 --> Security Class Initialized
DEBUG - 2020-09-17 06:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:15:27 --> Input Class Initialized
INFO - 2020-09-17 06:15:27 --> Language Class Initialized
INFO - 2020-09-17 06:15:27 --> Loader Class Initialized
INFO - 2020-09-17 06:15:27 --> Helper loaded: html_helper
INFO - 2020-09-17 06:15:27 --> Helper loaded: url_helper
INFO - 2020-09-17 06:15:27 --> Helper loaded: form_helper
INFO - 2020-09-17 06:15:27 --> Database Driver Class Initialized
INFO - 2020-09-17 06:15:28 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:15:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:15:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:15:28 --> Encryption Class Initialized
INFO - 2020-09-17 06:15:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:15:28 --> Controller Class Initialized
INFO - 2020-09-17 06:15:28 --> Helper loaded: language_helper
INFO - 2020-09-17 06:15:28 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 06:15:28 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 06:15:28 --> Final output sent to browser
DEBUG - 2020-09-17 06:15:28 --> Total execution time: 0.8037
INFO - 2020-09-17 06:15:33 --> Config Class Initialized
INFO - 2020-09-17 06:15:33 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:15:33 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:15:33 --> Utf8 Class Initialized
INFO - 2020-09-17 06:15:33 --> URI Class Initialized
INFO - 2020-09-17 06:15:33 --> Router Class Initialized
INFO - 2020-09-17 06:15:33 --> Output Class Initialized
INFO - 2020-09-17 06:15:33 --> Security Class Initialized
DEBUG - 2020-09-17 06:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:15:33 --> Input Class Initialized
INFO - 2020-09-17 06:15:33 --> Language Class Initialized
INFO - 2020-09-17 06:15:33 --> Loader Class Initialized
INFO - 2020-09-17 06:15:33 --> Helper loaded: html_helper
INFO - 2020-09-17 06:15:33 --> Helper loaded: url_helper
INFO - 2020-09-17 06:15:33 --> Helper loaded: form_helper
INFO - 2020-09-17 06:15:33 --> Database Driver Class Initialized
INFO - 2020-09-17 06:15:33 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:15:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:15:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:15:34 --> Encryption Class Initialized
INFO - 2020-09-17 06:15:34 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:15:34 --> Controller Class Initialized
INFO - 2020-09-17 06:15:34 --> Helper loaded: language_helper
INFO - 2020-09-17 06:15:34 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-17 06:15:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-17 06:15:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-17 06:15:34 --> Model "User" initialized
INFO - 2020-09-17 06:15:35 --> Config Class Initialized
INFO - 2020-09-17 06:15:35 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:15:35 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:15:35 --> Utf8 Class Initialized
INFO - 2020-09-17 06:15:35 --> URI Class Initialized
INFO - 2020-09-17 06:15:35 --> Router Class Initialized
INFO - 2020-09-17 06:15:35 --> Output Class Initialized
INFO - 2020-09-17 06:15:35 --> Security Class Initialized
DEBUG - 2020-09-17 06:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:15:35 --> Input Class Initialized
INFO - 2020-09-17 06:15:35 --> Language Class Initialized
INFO - 2020-09-17 06:15:35 --> Loader Class Initialized
INFO - 2020-09-17 06:15:35 --> Helper loaded: html_helper
INFO - 2020-09-17 06:15:35 --> Helper loaded: url_helper
INFO - 2020-09-17 06:15:35 --> Helper loaded: form_helper
INFO - 2020-09-17 06:15:35 --> Database Driver Class Initialized
INFO - 2020-09-17 06:15:35 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:15:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:15:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:15:35 --> Encryption Class Initialized
INFO - 2020-09-17 06:15:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:15:35 --> Controller Class Initialized
INFO - 2020-09-17 06:15:35 --> Helper loaded: language_helper
INFO - 2020-09-17 06:15:35 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 06:15:35 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 06:15:35 --> Final output sent to browser
DEBUG - 2020-09-17 06:15:35 --> Total execution time: 0.7454
INFO - 2020-09-17 06:15:41 --> Config Class Initialized
INFO - 2020-09-17 06:15:41 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:15:41 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:15:42 --> Utf8 Class Initialized
INFO - 2020-09-17 06:15:42 --> URI Class Initialized
INFO - 2020-09-17 06:15:42 --> Router Class Initialized
INFO - 2020-09-17 06:15:42 --> Output Class Initialized
INFO - 2020-09-17 06:15:42 --> Security Class Initialized
DEBUG - 2020-09-17 06:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:15:42 --> Input Class Initialized
INFO - 2020-09-17 06:15:42 --> Language Class Initialized
INFO - 2020-09-17 06:15:42 --> Loader Class Initialized
INFO - 2020-09-17 06:15:42 --> Helper loaded: html_helper
INFO - 2020-09-17 06:15:42 --> Helper loaded: url_helper
INFO - 2020-09-17 06:15:42 --> Helper loaded: form_helper
INFO - 2020-09-17 06:15:42 --> Database Driver Class Initialized
INFO - 2020-09-17 06:15:42 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:15:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:15:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:15:42 --> Encryption Class Initialized
INFO - 2020-09-17 06:15:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:15:42 --> Controller Class Initialized
INFO - 2020-09-17 06:15:42 --> Helper loaded: language_helper
INFO - 2020-09-17 06:15:42 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-17 06:15:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-17 06:15:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-17 06:15:42 --> Model "User" initialized
INFO - 2020-09-17 06:15:43 --> Config Class Initialized
INFO - 2020-09-17 06:15:43 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:15:43 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:15:43 --> Utf8 Class Initialized
INFO - 2020-09-17 06:15:43 --> URI Class Initialized
INFO - 2020-09-17 06:15:43 --> Router Class Initialized
INFO - 2020-09-17 06:15:43 --> Output Class Initialized
INFO - 2020-09-17 06:15:43 --> Security Class Initialized
DEBUG - 2020-09-17 06:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:15:43 --> Input Class Initialized
INFO - 2020-09-17 06:15:43 --> Language Class Initialized
INFO - 2020-09-17 06:15:43 --> Loader Class Initialized
INFO - 2020-09-17 06:15:43 --> Helper loaded: html_helper
INFO - 2020-09-17 06:15:43 --> Helper loaded: url_helper
INFO - 2020-09-17 06:15:43 --> Helper loaded: form_helper
INFO - 2020-09-17 06:15:43 --> Database Driver Class Initialized
INFO - 2020-09-17 06:15:43 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:15:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:15:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:15:44 --> Encryption Class Initialized
INFO - 2020-09-17 06:15:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:15:44 --> Controller Class Initialized
INFO - 2020-09-17 06:15:44 --> Helper loaded: language_helper
INFO - 2020-09-17 06:15:44 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 06:15:44 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 06:15:44 --> Final output sent to browser
DEBUG - 2020-09-17 06:15:44 --> Total execution time: 0.8072
INFO - 2020-09-17 06:16:04 --> Config Class Initialized
INFO - 2020-09-17 06:16:04 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:16:04 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:16:04 --> Utf8 Class Initialized
INFO - 2020-09-17 06:16:04 --> URI Class Initialized
INFO - 2020-09-17 06:16:04 --> Router Class Initialized
INFO - 2020-09-17 06:16:04 --> Output Class Initialized
INFO - 2020-09-17 06:16:04 --> Security Class Initialized
DEBUG - 2020-09-17 06:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:16:04 --> Input Class Initialized
INFO - 2020-09-17 06:16:04 --> Language Class Initialized
INFO - 2020-09-17 06:16:04 --> Loader Class Initialized
INFO - 2020-09-17 06:16:04 --> Helper loaded: html_helper
INFO - 2020-09-17 06:16:04 --> Helper loaded: url_helper
INFO - 2020-09-17 06:16:04 --> Helper loaded: form_helper
INFO - 2020-09-17 06:16:04 --> Database Driver Class Initialized
INFO - 2020-09-17 06:16:04 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:16:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:16:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:16:04 --> Encryption Class Initialized
INFO - 2020-09-17 06:16:04 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:16:04 --> Controller Class Initialized
INFO - 2020-09-17 06:16:04 --> Helper loaded: language_helper
INFO - 2020-09-17 06:16:04 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 06:16:04 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 06:16:04 --> Final output sent to browser
DEBUG - 2020-09-17 06:16:04 --> Total execution time: 0.7972
INFO - 2020-09-17 06:16:10 --> Config Class Initialized
INFO - 2020-09-17 06:16:10 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:16:10 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:16:10 --> Utf8 Class Initialized
INFO - 2020-09-17 06:16:10 --> URI Class Initialized
INFO - 2020-09-17 06:16:11 --> Router Class Initialized
INFO - 2020-09-17 06:16:11 --> Output Class Initialized
INFO - 2020-09-17 06:16:11 --> Security Class Initialized
DEBUG - 2020-09-17 06:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:16:11 --> Input Class Initialized
INFO - 2020-09-17 06:16:11 --> Language Class Initialized
INFO - 2020-09-17 06:16:11 --> Loader Class Initialized
INFO - 2020-09-17 06:16:11 --> Helper loaded: html_helper
INFO - 2020-09-17 06:16:11 --> Helper loaded: url_helper
INFO - 2020-09-17 06:16:11 --> Helper loaded: form_helper
INFO - 2020-09-17 06:16:11 --> Database Driver Class Initialized
INFO - 2020-09-17 06:16:11 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:16:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:16:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:16:11 --> Encryption Class Initialized
INFO - 2020-09-17 06:16:11 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:16:11 --> Controller Class Initialized
INFO - 2020-09-17 06:16:11 --> Helper loaded: language_helper
INFO - 2020-09-17 06:16:11 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-17 06:16:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-17 06:16:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-17 06:16:11 --> Model "User" initialized
INFO - 2020-09-17 06:16:12 --> Config Class Initialized
INFO - 2020-09-17 06:16:12 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:16:12 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:16:12 --> Utf8 Class Initialized
INFO - 2020-09-17 06:16:12 --> URI Class Initialized
INFO - 2020-09-17 06:16:12 --> Router Class Initialized
INFO - 2020-09-17 06:16:12 --> Output Class Initialized
INFO - 2020-09-17 06:16:12 --> Security Class Initialized
DEBUG - 2020-09-17 06:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:16:12 --> Input Class Initialized
INFO - 2020-09-17 06:16:12 --> Language Class Initialized
INFO - 2020-09-17 06:16:12 --> Loader Class Initialized
INFO - 2020-09-17 06:16:12 --> Helper loaded: html_helper
INFO - 2020-09-17 06:16:12 --> Helper loaded: url_helper
INFO - 2020-09-17 06:16:12 --> Helper loaded: form_helper
INFO - 2020-09-17 06:16:12 --> Database Driver Class Initialized
INFO - 2020-09-17 06:16:12 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:16:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:16:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:16:13 --> Encryption Class Initialized
INFO - 2020-09-17 06:16:13 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:16:13 --> Controller Class Initialized
INFO - 2020-09-17 06:16:13 --> Helper loaded: language_helper
INFO - 2020-09-17 06:16:13 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 06:16:13 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 06:16:13 --> Final output sent to browser
DEBUG - 2020-09-17 06:16:13 --> Total execution time: 0.8684
INFO - 2020-09-17 06:17:14 --> Config Class Initialized
INFO - 2020-09-17 06:17:14 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:17:14 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:17:14 --> Utf8 Class Initialized
INFO - 2020-09-17 06:17:15 --> URI Class Initialized
INFO - 2020-09-17 06:17:15 --> Router Class Initialized
INFO - 2020-09-17 06:17:15 --> Output Class Initialized
INFO - 2020-09-17 06:17:15 --> Security Class Initialized
DEBUG - 2020-09-17 06:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:17:15 --> Input Class Initialized
INFO - 2020-09-17 06:17:15 --> Language Class Initialized
INFO - 2020-09-17 06:17:15 --> Loader Class Initialized
INFO - 2020-09-17 06:17:15 --> Helper loaded: html_helper
INFO - 2020-09-17 06:17:15 --> Helper loaded: url_helper
INFO - 2020-09-17 06:17:15 --> Helper loaded: form_helper
INFO - 2020-09-17 06:17:15 --> Database Driver Class Initialized
INFO - 2020-09-17 06:17:15 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:17:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:17:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:17:15 --> Encryption Class Initialized
INFO - 2020-09-17 06:17:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:17:15 --> Controller Class Initialized
INFO - 2020-09-17 06:17:15 --> Helper loaded: language_helper
INFO - 2020-09-17 06:17:15 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-17 06:17:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-17 06:17:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-17 06:17:15 --> Model "User" initialized
INFO - 2020-09-17 06:17:16 --> Config Class Initialized
INFO - 2020-09-17 06:17:16 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:17:16 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:17:16 --> Utf8 Class Initialized
INFO - 2020-09-17 06:17:16 --> URI Class Initialized
INFO - 2020-09-17 06:17:16 --> Router Class Initialized
INFO - 2020-09-17 06:17:16 --> Output Class Initialized
INFO - 2020-09-17 06:17:16 --> Security Class Initialized
DEBUG - 2020-09-17 06:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:17:16 --> Input Class Initialized
INFO - 2020-09-17 06:17:16 --> Language Class Initialized
INFO - 2020-09-17 06:17:16 --> Loader Class Initialized
INFO - 2020-09-17 06:17:16 --> Helper loaded: html_helper
INFO - 2020-09-17 06:17:16 --> Helper loaded: url_helper
INFO - 2020-09-17 06:17:16 --> Helper loaded: form_helper
INFO - 2020-09-17 06:17:16 --> Database Driver Class Initialized
INFO - 2020-09-17 06:17:16 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:17:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:17:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:17:16 --> Encryption Class Initialized
INFO - 2020-09-17 06:17:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:17:17 --> Controller Class Initialized
INFO - 2020-09-17 06:17:17 --> Helper loaded: language_helper
INFO - 2020-09-17 06:17:17 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 06:17:17 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 06:17:17 --> Final output sent to browser
DEBUG - 2020-09-17 06:17:17 --> Total execution time: 0.7147
INFO - 2020-09-17 06:17:22 --> Config Class Initialized
INFO - 2020-09-17 06:17:22 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:17:22 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:17:22 --> Utf8 Class Initialized
INFO - 2020-09-17 06:17:22 --> URI Class Initialized
INFO - 2020-09-17 06:17:22 --> Router Class Initialized
INFO - 2020-09-17 06:17:22 --> Output Class Initialized
INFO - 2020-09-17 06:17:23 --> Security Class Initialized
DEBUG - 2020-09-17 06:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:17:23 --> Input Class Initialized
INFO - 2020-09-17 06:17:23 --> Language Class Initialized
INFO - 2020-09-17 06:17:23 --> Loader Class Initialized
INFO - 2020-09-17 06:17:23 --> Helper loaded: html_helper
INFO - 2020-09-17 06:17:23 --> Helper loaded: url_helper
INFO - 2020-09-17 06:17:23 --> Helper loaded: form_helper
INFO - 2020-09-17 06:17:23 --> Database Driver Class Initialized
INFO - 2020-09-17 06:17:23 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:17:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:17:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:17:23 --> Encryption Class Initialized
INFO - 2020-09-17 06:17:23 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:17:23 --> Controller Class Initialized
INFO - 2020-09-17 06:17:23 --> Helper loaded: language_helper
INFO - 2020-09-17 06:17:23 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-17 06:17:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-17 06:17:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-17 06:17:23 --> Model "User" initialized
INFO - 2020-09-17 06:17:23 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 06:17:23 --> Final output sent to browser
DEBUG - 2020-09-17 06:17:23 --> Total execution time: 0.8776
INFO - 2020-09-17 06:17:29 --> Config Class Initialized
INFO - 2020-09-17 06:17:29 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:17:29 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:17:29 --> Utf8 Class Initialized
INFO - 2020-09-17 06:17:29 --> URI Class Initialized
INFO - 2020-09-17 06:17:29 --> Router Class Initialized
INFO - 2020-09-17 06:17:29 --> Output Class Initialized
INFO - 2020-09-17 06:17:29 --> Security Class Initialized
DEBUG - 2020-09-17 06:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:17:29 --> Input Class Initialized
INFO - 2020-09-17 06:17:29 --> Language Class Initialized
INFO - 2020-09-17 06:17:29 --> Loader Class Initialized
INFO - 2020-09-17 06:17:29 --> Helper loaded: html_helper
INFO - 2020-09-17 06:17:29 --> Helper loaded: url_helper
INFO - 2020-09-17 06:17:29 --> Helper loaded: form_helper
INFO - 2020-09-17 06:17:29 --> Database Driver Class Initialized
INFO - 2020-09-17 06:17:29 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:17:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:17:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:17:30 --> Encryption Class Initialized
INFO - 2020-09-17 06:17:30 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:17:30 --> Controller Class Initialized
INFO - 2020-09-17 06:17:30 --> Helper loaded: language_helper
INFO - 2020-09-17 06:17:30 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-17 06:17:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-17 06:17:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-17 06:17:30 --> Model "User" initialized
INFO - 2020-09-17 06:17:30 --> Config Class Initialized
INFO - 2020-09-17 06:17:30 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:17:30 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:17:31 --> Utf8 Class Initialized
INFO - 2020-09-17 06:17:31 --> URI Class Initialized
INFO - 2020-09-17 06:17:31 --> Router Class Initialized
INFO - 2020-09-17 06:17:31 --> Output Class Initialized
INFO - 2020-09-17 06:17:31 --> Security Class Initialized
DEBUG - 2020-09-17 06:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:17:31 --> Input Class Initialized
INFO - 2020-09-17 06:17:31 --> Language Class Initialized
INFO - 2020-09-17 06:17:31 --> Loader Class Initialized
INFO - 2020-09-17 06:17:31 --> Helper loaded: html_helper
INFO - 2020-09-17 06:17:31 --> Helper loaded: url_helper
INFO - 2020-09-17 06:17:31 --> Helper loaded: form_helper
INFO - 2020-09-17 06:17:31 --> Database Driver Class Initialized
INFO - 2020-09-17 06:17:31 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:17:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:17:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:17:31 --> Encryption Class Initialized
INFO - 2020-09-17 06:17:31 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:17:31 --> Controller Class Initialized
INFO - 2020-09-17 06:17:31 --> Helper loaded: language_helper
INFO - 2020-09-17 06:17:31 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 06:17:31 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 06:17:31 --> Final output sent to browser
DEBUG - 2020-09-17 06:17:31 --> Total execution time: 0.7895
INFO - 2020-09-17 06:27:06 --> Config Class Initialized
INFO - 2020-09-17 06:27:06 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:27:06 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:27:06 --> Utf8 Class Initialized
INFO - 2020-09-17 06:27:06 --> URI Class Initialized
INFO - 2020-09-17 06:27:06 --> Router Class Initialized
INFO - 2020-09-17 06:27:06 --> Output Class Initialized
INFO - 2020-09-17 06:27:06 --> Security Class Initialized
DEBUG - 2020-09-17 06:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:27:06 --> Input Class Initialized
INFO - 2020-09-17 06:27:06 --> Language Class Initialized
INFO - 2020-09-17 06:27:06 --> Loader Class Initialized
INFO - 2020-09-17 06:27:06 --> Helper loaded: html_helper
INFO - 2020-09-17 06:27:06 --> Helper loaded: url_helper
INFO - 2020-09-17 06:27:07 --> Helper loaded: form_helper
INFO - 2020-09-17 06:27:07 --> Database Driver Class Initialized
INFO - 2020-09-17 06:27:07 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:27:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:27:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:27:07 --> Encryption Class Initialized
INFO - 2020-09-17 06:27:07 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:27:07 --> Controller Class Initialized
INFO - 2020-09-17 06:27:07 --> Helper loaded: language_helper
INFO - 2020-09-17 06:27:07 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 06:27:07 --> Final output sent to browser
DEBUG - 2020-09-17 06:27:07 --> Total execution time: 0.8595
INFO - 2020-09-17 06:27:13 --> Config Class Initialized
INFO - 2020-09-17 06:27:13 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:27:13 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:27:13 --> Utf8 Class Initialized
INFO - 2020-09-17 06:27:13 --> URI Class Initialized
INFO - 2020-09-17 06:27:13 --> Router Class Initialized
INFO - 2020-09-17 06:27:13 --> Output Class Initialized
INFO - 2020-09-17 06:27:13 --> Security Class Initialized
DEBUG - 2020-09-17 06:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:27:13 --> Input Class Initialized
INFO - 2020-09-17 06:27:13 --> Language Class Initialized
INFO - 2020-09-17 06:27:13 --> Loader Class Initialized
INFO - 2020-09-17 06:27:13 --> Helper loaded: html_helper
INFO - 2020-09-17 06:27:13 --> Helper loaded: url_helper
INFO - 2020-09-17 06:27:13 --> Helper loaded: form_helper
INFO - 2020-09-17 06:27:13 --> Database Driver Class Initialized
INFO - 2020-09-17 06:27:13 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:27:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:27:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:27:13 --> Encryption Class Initialized
INFO - 2020-09-17 06:27:13 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:27:13 --> Controller Class Initialized
INFO - 2020-09-17 06:27:13 --> Helper loaded: language_helper
INFO - 2020-09-17 06:27:13 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 06:27:13 --> Final output sent to browser
DEBUG - 2020-09-17 06:27:13 --> Total execution time: 0.7509
INFO - 2020-09-17 06:27:15 --> Config Class Initialized
INFO - 2020-09-17 06:27:15 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:27:15 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:27:15 --> Utf8 Class Initialized
INFO - 2020-09-17 06:27:15 --> URI Class Initialized
INFO - 2020-09-17 06:27:15 --> Router Class Initialized
INFO - 2020-09-17 06:27:15 --> Output Class Initialized
INFO - 2020-09-17 06:27:15 --> Security Class Initialized
DEBUG - 2020-09-17 06:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:27:15 --> Input Class Initialized
INFO - 2020-09-17 06:27:15 --> Language Class Initialized
INFO - 2020-09-17 06:27:15 --> Loader Class Initialized
INFO - 2020-09-17 06:27:15 --> Helper loaded: html_helper
INFO - 2020-09-17 06:27:15 --> Helper loaded: url_helper
INFO - 2020-09-17 06:27:15 --> Helper loaded: form_helper
INFO - 2020-09-17 06:27:15 --> Database Driver Class Initialized
INFO - 2020-09-17 06:27:15 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:27:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:27:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:27:16 --> Encryption Class Initialized
INFO - 2020-09-17 06:27:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:27:16 --> Controller Class Initialized
INFO - 2020-09-17 06:27:16 --> Helper loaded: language_helper
INFO - 2020-09-17 06:27:16 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 06:27:16 --> Final output sent to browser
DEBUG - 2020-09-17 06:27:16 --> Total execution time: 0.7465
INFO - 2020-09-17 06:27:17 --> Config Class Initialized
INFO - 2020-09-17 06:27:17 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:27:17 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:27:17 --> Utf8 Class Initialized
INFO - 2020-09-17 06:27:17 --> URI Class Initialized
INFO - 2020-09-17 06:27:17 --> Router Class Initialized
INFO - 2020-09-17 06:27:17 --> Output Class Initialized
INFO - 2020-09-17 06:27:17 --> Security Class Initialized
DEBUG - 2020-09-17 06:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:27:17 --> Input Class Initialized
INFO - 2020-09-17 06:27:17 --> Language Class Initialized
INFO - 2020-09-17 06:27:17 --> Loader Class Initialized
INFO - 2020-09-17 06:27:17 --> Helper loaded: html_helper
INFO - 2020-09-17 06:27:17 --> Helper loaded: url_helper
INFO - 2020-09-17 06:27:17 --> Helper loaded: form_helper
INFO - 2020-09-17 06:27:17 --> Database Driver Class Initialized
INFO - 2020-09-17 06:27:18 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:27:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:27:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:27:18 --> Encryption Class Initialized
INFO - 2020-09-17 06:27:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:27:18 --> Controller Class Initialized
INFO - 2020-09-17 06:27:18 --> Helper loaded: language_helper
INFO - 2020-09-17 06:27:18 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 06:27:18 --> Final output sent to browser
DEBUG - 2020-09-17 06:27:18 --> Total execution time: 0.7257
INFO - 2020-09-17 06:27:23 --> Config Class Initialized
INFO - 2020-09-17 06:27:23 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:27:23 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:27:23 --> Utf8 Class Initialized
INFO - 2020-09-17 06:27:23 --> URI Class Initialized
DEBUG - 2020-09-17 06:27:23 --> No URI present. Default controller set.
INFO - 2020-09-17 06:27:23 --> Router Class Initialized
INFO - 2020-09-17 06:27:23 --> Output Class Initialized
INFO - 2020-09-17 06:27:23 --> Security Class Initialized
DEBUG - 2020-09-17 06:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:27:23 --> Input Class Initialized
INFO - 2020-09-17 06:27:23 --> Language Class Initialized
INFO - 2020-09-17 06:27:23 --> Loader Class Initialized
INFO - 2020-09-17 06:27:23 --> Helper loaded: html_helper
INFO - 2020-09-17 06:27:23 --> Helper loaded: url_helper
INFO - 2020-09-17 06:27:23 --> Helper loaded: form_helper
INFO - 2020-09-17 06:27:23 --> Database Driver Class Initialized
INFO - 2020-09-17 06:27:23 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:27:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:27:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:27:24 --> Encryption Class Initialized
INFO - 2020-09-17 06:27:24 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:27:24 --> Controller Class Initialized
INFO - 2020-09-17 06:27:24 --> Helper loaded: language_helper
INFO - 2020-09-17 06:27:24 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 06:27:24 --> Final output sent to browser
DEBUG - 2020-09-17 06:27:24 --> Total execution time: 0.7476
INFO - 2020-09-17 06:27:27 --> Config Class Initialized
INFO - 2020-09-17 06:27:27 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:27:27 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:27:27 --> Utf8 Class Initialized
INFO - 2020-09-17 06:27:27 --> URI Class Initialized
DEBUG - 2020-09-17 06:27:27 --> No URI present. Default controller set.
INFO - 2020-09-17 06:27:27 --> Router Class Initialized
INFO - 2020-09-17 06:27:27 --> Output Class Initialized
INFO - 2020-09-17 06:27:27 --> Security Class Initialized
DEBUG - 2020-09-17 06:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:27:27 --> Input Class Initialized
INFO - 2020-09-17 06:27:27 --> Language Class Initialized
INFO - 2020-09-17 06:27:27 --> Loader Class Initialized
INFO - 2020-09-17 06:27:27 --> Helper loaded: html_helper
INFO - 2020-09-17 06:27:27 --> Helper loaded: url_helper
INFO - 2020-09-17 06:27:27 --> Helper loaded: form_helper
INFO - 2020-09-17 06:27:27 --> Database Driver Class Initialized
INFO - 2020-09-17 06:27:27 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:27:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:27:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:27:27 --> Encryption Class Initialized
INFO - 2020-09-17 06:27:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:27:27 --> Controller Class Initialized
INFO - 2020-09-17 06:27:27 --> Helper loaded: language_helper
INFO - 2020-09-17 06:27:27 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 06:27:27 --> Final output sent to browser
DEBUG - 2020-09-17 06:27:27 --> Total execution time: 0.8119
INFO - 2020-09-17 06:28:14 --> Config Class Initialized
INFO - 2020-09-17 06:28:15 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:28:15 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:28:15 --> Utf8 Class Initialized
INFO - 2020-09-17 06:28:15 --> URI Class Initialized
DEBUG - 2020-09-17 06:28:15 --> No URI present. Default controller set.
INFO - 2020-09-17 06:28:15 --> Router Class Initialized
INFO - 2020-09-17 06:28:15 --> Output Class Initialized
INFO - 2020-09-17 06:28:15 --> Security Class Initialized
DEBUG - 2020-09-17 06:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:28:15 --> Input Class Initialized
INFO - 2020-09-17 06:28:15 --> Language Class Initialized
INFO - 2020-09-17 06:28:15 --> Loader Class Initialized
INFO - 2020-09-17 06:28:15 --> Helper loaded: html_helper
INFO - 2020-09-17 06:28:15 --> Helper loaded: url_helper
INFO - 2020-09-17 06:28:15 --> Helper loaded: form_helper
INFO - 2020-09-17 06:28:15 --> Database Driver Class Initialized
INFO - 2020-09-17 06:28:15 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:28:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:28:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:28:15 --> Encryption Class Initialized
INFO - 2020-09-17 06:28:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:28:15 --> Controller Class Initialized
INFO - 2020-09-17 06:28:15 --> Helper loaded: language_helper
INFO - 2020-09-17 06:28:15 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 06:28:15 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 06:28:15 --> Final output sent to browser
DEBUG - 2020-09-17 06:28:15 --> Total execution time: 0.8007
INFO - 2020-09-17 06:28:23 --> Config Class Initialized
INFO - 2020-09-17 06:28:23 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:28:23 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:28:24 --> Utf8 Class Initialized
INFO - 2020-09-17 06:28:24 --> URI Class Initialized
INFO - 2020-09-17 06:28:24 --> Router Class Initialized
INFO - 2020-09-17 06:28:24 --> Output Class Initialized
INFO - 2020-09-17 06:28:24 --> Security Class Initialized
DEBUG - 2020-09-17 06:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:28:24 --> Input Class Initialized
INFO - 2020-09-17 06:28:24 --> Language Class Initialized
INFO - 2020-09-17 06:28:24 --> Loader Class Initialized
INFO - 2020-09-17 06:28:24 --> Helper loaded: html_helper
INFO - 2020-09-17 06:28:24 --> Helper loaded: url_helper
INFO - 2020-09-17 06:28:24 --> Helper loaded: form_helper
INFO - 2020-09-17 06:28:24 --> Database Driver Class Initialized
INFO - 2020-09-17 06:28:24 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:28:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:28:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:28:24 --> Encryption Class Initialized
INFO - 2020-09-17 06:28:24 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:28:24 --> Controller Class Initialized
INFO - 2020-09-17 06:28:24 --> Helper loaded: language_helper
INFO - 2020-09-17 06:28:24 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-17 06:28:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-17 06:28:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-17 06:28:24 --> Model "User" initialized
INFO - 2020-09-17 06:28:25 --> Config Class Initialized
INFO - 2020-09-17 06:28:25 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:28:25 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:28:25 --> Utf8 Class Initialized
INFO - 2020-09-17 06:28:25 --> URI Class Initialized
INFO - 2020-09-17 06:28:25 --> Router Class Initialized
INFO - 2020-09-17 06:28:25 --> Output Class Initialized
INFO - 2020-09-17 06:28:25 --> Security Class Initialized
DEBUG - 2020-09-17 06:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:28:25 --> Input Class Initialized
INFO - 2020-09-17 06:28:25 --> Language Class Initialized
INFO - 2020-09-17 06:28:25 --> Loader Class Initialized
INFO - 2020-09-17 06:28:25 --> Helper loaded: html_helper
INFO - 2020-09-17 06:28:25 --> Helper loaded: url_helper
INFO - 2020-09-17 06:28:25 --> Helper loaded: form_helper
INFO - 2020-09-17 06:28:25 --> Database Driver Class Initialized
INFO - 2020-09-17 06:28:26 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:28:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:28:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:28:26 --> Encryption Class Initialized
INFO - 2020-09-17 06:28:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:28:26 --> Controller Class Initialized
INFO - 2020-09-17 06:28:26 --> Helper loaded: language_helper
INFO - 2020-09-17 06:28:26 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 06:28:26 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 06:28:26 --> Final output sent to browser
DEBUG - 2020-09-17 06:28:26 --> Total execution time: 0.7551
INFO - 2020-09-17 06:39:22 --> Config Class Initialized
INFO - 2020-09-17 06:39:22 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:39:22 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:39:23 --> Utf8 Class Initialized
INFO - 2020-09-17 06:39:23 --> URI Class Initialized
INFO - 2020-09-17 06:39:23 --> Router Class Initialized
INFO - 2020-09-17 06:39:23 --> Output Class Initialized
INFO - 2020-09-17 06:39:23 --> Security Class Initialized
DEBUG - 2020-09-17 06:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:39:23 --> Input Class Initialized
INFO - 2020-09-17 06:39:23 --> Language Class Initialized
INFO - 2020-09-17 06:39:23 --> Loader Class Initialized
INFO - 2020-09-17 06:39:23 --> Helper loaded: html_helper
INFO - 2020-09-17 06:39:23 --> Helper loaded: url_helper
INFO - 2020-09-17 06:39:23 --> Helper loaded: form_helper
INFO - 2020-09-17 06:39:23 --> Database Driver Class Initialized
INFO - 2020-09-17 06:39:23 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:39:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:39:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:39:23 --> Encryption Class Initialized
INFO - 2020-09-17 06:39:23 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:39:23 --> Controller Class Initialized
INFO - 2020-09-17 06:39:23 --> Helper loaded: language_helper
INFO - 2020-09-17 06:39:23 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 06:39:23 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 06:39:23 --> Final output sent to browser
DEBUG - 2020-09-17 06:39:23 --> Total execution time: 0.8042
INFO - 2020-09-17 06:39:31 --> Config Class Initialized
INFO - 2020-09-17 06:39:31 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:39:32 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:39:32 --> Utf8 Class Initialized
INFO - 2020-09-17 06:39:32 --> URI Class Initialized
INFO - 2020-09-17 06:39:32 --> Router Class Initialized
INFO - 2020-09-17 06:39:32 --> Output Class Initialized
INFO - 2020-09-17 06:39:32 --> Security Class Initialized
DEBUG - 2020-09-17 06:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:39:32 --> Input Class Initialized
INFO - 2020-09-17 06:39:32 --> Language Class Initialized
INFO - 2020-09-17 06:39:32 --> Loader Class Initialized
INFO - 2020-09-17 06:39:32 --> Helper loaded: html_helper
INFO - 2020-09-17 06:39:32 --> Helper loaded: url_helper
INFO - 2020-09-17 06:39:32 --> Helper loaded: form_helper
INFO - 2020-09-17 06:39:32 --> Database Driver Class Initialized
INFO - 2020-09-17 06:39:32 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:39:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:39:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:39:32 --> Encryption Class Initialized
INFO - 2020-09-17 06:39:32 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:39:32 --> Controller Class Initialized
INFO - 2020-09-17 06:39:32 --> Helper loaded: language_helper
INFO - 2020-09-17 06:39:32 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-17 06:39:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-17 06:39:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-17 06:39:32 --> Model "User" initialized
INFO - 2020-09-17 06:39:33 --> Config Class Initialized
INFO - 2020-09-17 06:39:33 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:39:33 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:39:33 --> Utf8 Class Initialized
INFO - 2020-09-17 06:39:33 --> URI Class Initialized
INFO - 2020-09-17 06:39:33 --> Router Class Initialized
INFO - 2020-09-17 06:39:33 --> Output Class Initialized
INFO - 2020-09-17 06:39:33 --> Security Class Initialized
DEBUG - 2020-09-17 06:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:39:33 --> Input Class Initialized
INFO - 2020-09-17 06:39:33 --> Language Class Initialized
INFO - 2020-09-17 06:39:33 --> Loader Class Initialized
INFO - 2020-09-17 06:39:33 --> Helper loaded: html_helper
INFO - 2020-09-17 06:39:33 --> Helper loaded: url_helper
INFO - 2020-09-17 06:39:33 --> Helper loaded: form_helper
INFO - 2020-09-17 06:39:33 --> Database Driver Class Initialized
INFO - 2020-09-17 06:39:33 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:39:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:39:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:39:34 --> Encryption Class Initialized
INFO - 2020-09-17 06:39:34 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:39:34 --> Controller Class Initialized
INFO - 2020-09-17 06:39:34 --> Helper loaded: language_helper
INFO - 2020-09-17 06:39:34 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 06:39:34 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 06:39:34 --> Final output sent to browser
DEBUG - 2020-09-17 06:39:34 --> Total execution time: 0.7617
INFO - 2020-09-17 06:45:33 --> Config Class Initialized
INFO - 2020-09-17 06:45:33 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:45:33 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:45:33 --> Utf8 Class Initialized
INFO - 2020-09-17 06:45:33 --> URI Class Initialized
DEBUG - 2020-09-17 06:45:33 --> No URI present. Default controller set.
INFO - 2020-09-17 06:45:33 --> Router Class Initialized
INFO - 2020-09-17 06:45:33 --> Output Class Initialized
INFO - 2020-09-17 06:45:33 --> Security Class Initialized
DEBUG - 2020-09-17 06:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:45:33 --> Input Class Initialized
INFO - 2020-09-17 06:45:33 --> Language Class Initialized
INFO - 2020-09-17 06:45:33 --> Loader Class Initialized
INFO - 2020-09-17 06:45:33 --> Helper loaded: html_helper
INFO - 2020-09-17 06:45:33 --> Helper loaded: url_helper
INFO - 2020-09-17 06:45:33 --> Helper loaded: form_helper
INFO - 2020-09-17 06:45:33 --> Database Driver Class Initialized
INFO - 2020-09-17 06:45:33 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:45:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:45:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:45:33 --> Encryption Class Initialized
INFO - 2020-09-17 06:45:33 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:45:34 --> Controller Class Initialized
INFO - 2020-09-17 06:45:34 --> Helper loaded: language_helper
INFO - 2020-09-17 06:45:34 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 06:45:34 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 06:45:34 --> Final output sent to browser
DEBUG - 2020-09-17 06:45:34 --> Total execution time: 0.8033
INFO - 2020-09-17 06:45:40 --> Config Class Initialized
INFO - 2020-09-17 06:45:40 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:45:40 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:45:40 --> Utf8 Class Initialized
INFO - 2020-09-17 06:45:40 --> URI Class Initialized
INFO - 2020-09-17 06:45:40 --> Router Class Initialized
INFO - 2020-09-17 06:45:40 --> Output Class Initialized
INFO - 2020-09-17 06:45:40 --> Security Class Initialized
DEBUG - 2020-09-17 06:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:45:40 --> Input Class Initialized
INFO - 2020-09-17 06:45:40 --> Language Class Initialized
INFO - 2020-09-17 06:45:40 --> Loader Class Initialized
INFO - 2020-09-17 06:45:40 --> Helper loaded: html_helper
INFO - 2020-09-17 06:45:40 --> Helper loaded: url_helper
INFO - 2020-09-17 06:45:40 --> Helper loaded: form_helper
INFO - 2020-09-17 06:45:40 --> Database Driver Class Initialized
INFO - 2020-09-17 06:45:41 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:45:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:45:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:45:41 --> Encryption Class Initialized
INFO - 2020-09-17 06:45:41 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:45:41 --> Controller Class Initialized
INFO - 2020-09-17 06:45:41 --> Helper loaded: language_helper
INFO - 2020-09-17 06:45:41 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-17 06:45:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-17 06:45:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-17 06:45:41 --> Model "User" initialized
INFO - 2020-09-17 06:45:42 --> Config Class Initialized
INFO - 2020-09-17 06:45:42 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:45:42 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:45:42 --> Utf8 Class Initialized
INFO - 2020-09-17 06:45:42 --> URI Class Initialized
INFO - 2020-09-17 06:45:42 --> Router Class Initialized
INFO - 2020-09-17 06:45:42 --> Output Class Initialized
INFO - 2020-09-17 06:45:42 --> Security Class Initialized
DEBUG - 2020-09-17 06:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:45:42 --> Input Class Initialized
INFO - 2020-09-17 06:45:42 --> Language Class Initialized
INFO - 2020-09-17 06:45:42 --> Loader Class Initialized
INFO - 2020-09-17 06:45:42 --> Helper loaded: html_helper
INFO - 2020-09-17 06:45:42 --> Helper loaded: url_helper
INFO - 2020-09-17 06:45:42 --> Helper loaded: form_helper
INFO - 2020-09-17 06:45:42 --> Database Driver Class Initialized
INFO - 2020-09-17 06:45:42 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:45:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:45:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:45:42 --> Encryption Class Initialized
INFO - 2020-09-17 06:45:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:45:42 --> Controller Class Initialized
INFO - 2020-09-17 06:45:42 --> Helper loaded: language_helper
INFO - 2020-09-17 06:45:42 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 06:45:42 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 06:45:42 --> Final output sent to browser
DEBUG - 2020-09-17 06:45:42 --> Total execution time: 0.7934
INFO - 2020-09-17 06:54:24 --> Config Class Initialized
INFO - 2020-09-17 06:54:24 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:54:24 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:54:24 --> Utf8 Class Initialized
INFO - 2020-09-17 06:54:24 --> URI Class Initialized
INFO - 2020-09-17 06:54:24 --> Router Class Initialized
INFO - 2020-09-17 06:54:24 --> Output Class Initialized
INFO - 2020-09-17 06:54:24 --> Security Class Initialized
DEBUG - 2020-09-17 06:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:54:24 --> Input Class Initialized
INFO - 2020-09-17 06:54:24 --> Language Class Initialized
INFO - 2020-09-17 06:54:24 --> Loader Class Initialized
INFO - 2020-09-17 06:54:24 --> Helper loaded: html_helper
INFO - 2020-09-17 06:54:24 --> Helper loaded: url_helper
INFO - 2020-09-17 06:54:24 --> Helper loaded: form_helper
INFO - 2020-09-17 06:54:25 --> Database Driver Class Initialized
INFO - 2020-09-17 06:54:25 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:54:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:54:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:54:25 --> Encryption Class Initialized
INFO - 2020-09-17 06:54:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:54:25 --> Controller Class Initialized
INFO - 2020-09-17 06:54:25 --> Helper loaded: language_helper
INFO - 2020-09-17 06:54:25 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 06:54:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-17 06:54:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 06:54:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment.php
INFO - 2020-09-17 06:54:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 06:54:25 --> Final output sent to browser
DEBUG - 2020-09-17 06:54:25 --> Total execution time: 1.3832
INFO - 2020-09-17 06:54:27 --> Config Class Initialized
INFO - 2020-09-17 06:54:27 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:54:27 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:54:27 --> Utf8 Class Initialized
INFO - 2020-09-17 06:54:27 --> URI Class Initialized
INFO - 2020-09-17 06:54:27 --> Router Class Initialized
INFO - 2020-09-17 06:54:27 --> Output Class Initialized
INFO - 2020-09-17 06:54:27 --> Security Class Initialized
DEBUG - 2020-09-17 06:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:54:27 --> Input Class Initialized
INFO - 2020-09-17 06:54:27 --> Language Class Initialized
INFO - 2020-09-17 06:54:27 --> Loader Class Initialized
INFO - 2020-09-17 06:54:27 --> Helper loaded: html_helper
INFO - 2020-09-17 06:54:27 --> Helper loaded: url_helper
INFO - 2020-09-17 06:54:27 --> Helper loaded: form_helper
INFO - 2020-09-17 06:54:27 --> Database Driver Class Initialized
INFO - 2020-09-17 06:54:27 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:54:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:54:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:54:27 --> Encryption Class Initialized
INFO - 2020-09-17 06:54:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:54:27 --> Controller Class Initialized
INFO - 2020-09-17 06:54:27 --> Helper loaded: language_helper
INFO - 2020-09-17 06:54:27 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 06:54:30 --> Final output sent to browser
DEBUG - 2020-09-17 06:54:30 --> Total execution time: 3.7334
INFO - 2020-09-17 06:54:36 --> Config Class Initialized
INFO - 2020-09-17 06:54:37 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:54:37 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:54:37 --> Utf8 Class Initialized
INFO - 2020-09-17 06:54:37 --> URI Class Initialized
INFO - 2020-09-17 06:54:37 --> Router Class Initialized
INFO - 2020-09-17 06:54:37 --> Output Class Initialized
INFO - 2020-09-17 06:54:37 --> Security Class Initialized
DEBUG - 2020-09-17 06:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:54:37 --> Input Class Initialized
INFO - 2020-09-17 06:54:37 --> Language Class Initialized
INFO - 2020-09-17 06:54:37 --> Loader Class Initialized
INFO - 2020-09-17 06:54:37 --> Helper loaded: html_helper
INFO - 2020-09-17 06:54:37 --> Helper loaded: url_helper
INFO - 2020-09-17 06:54:37 --> Helper loaded: form_helper
INFO - 2020-09-17 06:54:37 --> Database Driver Class Initialized
INFO - 2020-09-17 06:54:37 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:54:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:54:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:54:37 --> Encryption Class Initialized
INFO - 2020-09-17 06:54:37 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 06:54:37 --> Controller Class Initialized
INFO - 2020-09-17 06:54:37 --> Helper loaded: language_helper
INFO - 2020-09-17 06:54:37 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 06:54:37 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-17 06:54:37 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 06:54:38 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment_custom.php
INFO - 2020-09-17 06:54:38 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 06:54:38 --> Final output sent to browser
DEBUG - 2020-09-17 06:54:38 --> Total execution time: 1.1699
INFO - 2020-09-17 06:59:24 --> Config Class Initialized
INFO - 2020-09-17 06:59:24 --> Hooks Class Initialized
DEBUG - 2020-09-17 06:59:24 --> UTF-8 Support Enabled
INFO - 2020-09-17 06:59:24 --> Utf8 Class Initialized
INFO - 2020-09-17 06:59:24 --> URI Class Initialized
INFO - 2020-09-17 06:59:24 --> Router Class Initialized
INFO - 2020-09-17 06:59:24 --> Output Class Initialized
INFO - 2020-09-17 06:59:24 --> Security Class Initialized
DEBUG - 2020-09-17 06:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 06:59:24 --> Input Class Initialized
INFO - 2020-09-17 06:59:24 --> Language Class Initialized
INFO - 2020-09-17 06:59:24 --> Loader Class Initialized
INFO - 2020-09-17 06:59:24 --> Helper loaded: html_helper
INFO - 2020-09-17 06:59:24 --> Helper loaded: url_helper
INFO - 2020-09-17 06:59:24 --> Helper loaded: form_helper
INFO - 2020-09-17 06:59:25 --> Database Driver Class Initialized
INFO - 2020-09-17 06:59:25 --> Form Validation Class Initialized
DEBUG - 2020-09-17 06:59:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 06:59:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 06:59:25 --> Encryption Class Initialized
ERROR - 2020-09-17 06:59:25 --> Query error: [Microsoft][ODBC Driver 17 for SQL Server][SQL Server]Invalid column name 'id'. - Invalid query: SELECT 1
FROM "ci_sessions"
WHERE "id" = 'upj6025jaah4gpsahk8vjeidimjrhf6o'
AND "ip_address" = '112.133.237.14'
INFO - 2020-09-17 06:59:25 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-17 06:59:25 --> Severity: Warning --> session_write_close(): Cannot call session save handler in a recursive manner Unknown 0
INFO - 2020-09-17 07:05:47 --> Config Class Initialized
INFO - 2020-09-17 07:05:47 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:05:47 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:05:47 --> Utf8 Class Initialized
INFO - 2020-09-17 07:05:48 --> URI Class Initialized
DEBUG - 2020-09-17 07:05:48 --> No URI present. Default controller set.
INFO - 2020-09-17 07:05:48 --> Router Class Initialized
INFO - 2020-09-17 07:05:48 --> Output Class Initialized
INFO - 2020-09-17 07:05:48 --> Security Class Initialized
DEBUG - 2020-09-17 07:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:05:48 --> Input Class Initialized
INFO - 2020-09-17 07:05:48 --> Language Class Initialized
INFO - 2020-09-17 07:05:48 --> Loader Class Initialized
INFO - 2020-09-17 07:05:48 --> Helper loaded: html_helper
INFO - 2020-09-17 07:05:48 --> Helper loaded: url_helper
INFO - 2020-09-17 07:05:48 --> Helper loaded: form_helper
INFO - 2020-09-17 07:05:48 --> Database Driver Class Initialized
INFO - 2020-09-17 07:05:48 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:05:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:05:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:05:48 --> Encryption Class Initialized
ERROR - 2020-09-17 07:05:48 --> Query error: [Microsoft][ODBC Driver 17 for SQL Server][SQL Server]Invalid column name 'data'. - Invalid query: SELECT "data"
FROM "ci_sessions"
WHERE "id" = 'tc96iknmed2nbra34upbsop2smv4pti9'
AND "ip_address" = '112.133.237.14'
INFO - 2020-09-17 07:05:48 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-17 07:05:48 --> Severity: Warning --> session_write_close(): Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-09-17 07:05:48 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: C:\Windows\Temp) Unknown 0
INFO - 2020-09-17 07:06:04 --> Config Class Initialized
INFO - 2020-09-17 07:06:04 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:06:04 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:06:04 --> Utf8 Class Initialized
INFO - 2020-09-17 07:06:04 --> URI Class Initialized
DEBUG - 2020-09-17 07:06:04 --> No URI present. Default controller set.
INFO - 2020-09-17 07:06:04 --> Router Class Initialized
INFO - 2020-09-17 07:06:04 --> Output Class Initialized
INFO - 2020-09-17 07:06:04 --> Security Class Initialized
DEBUG - 2020-09-17 07:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:06:04 --> Input Class Initialized
INFO - 2020-09-17 07:06:04 --> Language Class Initialized
INFO - 2020-09-17 07:06:04 --> Loader Class Initialized
INFO - 2020-09-17 07:06:04 --> Helper loaded: html_helper
INFO - 2020-09-17 07:06:04 --> Helper loaded: url_helper
INFO - 2020-09-17 07:06:04 --> Helper loaded: form_helper
INFO - 2020-09-17 07:06:04 --> Database Driver Class Initialized
INFO - 2020-09-17 07:06:05 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:06:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:06:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:06:05 --> Encryption Class Initialized
ERROR - 2020-09-17 07:06:05 --> Query error: [Microsoft][ODBC Driver 17 for SQL Server][SQL Server]Invalid column name 'data'. - Invalid query: SELECT "data"
FROM "ci_sessions"
WHERE "id" = '5pc09u2evclb4oguveb9c0lf5s8op8df'
AND "ip_address" = '112.133.237.14'
INFO - 2020-09-17 07:06:05 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-17 07:06:05 --> Severity: Warning --> session_write_close(): Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-09-17 07:06:05 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: C:\Windows\Temp) Unknown 0
INFO - 2020-09-17 07:06:28 --> Config Class Initialized
INFO - 2020-09-17 07:06:28 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:06:28 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:06:28 --> Utf8 Class Initialized
INFO - 2020-09-17 07:06:28 --> URI Class Initialized
DEBUG - 2020-09-17 07:06:28 --> No URI present. Default controller set.
INFO - 2020-09-17 07:06:28 --> Router Class Initialized
INFO - 2020-09-17 07:06:28 --> Output Class Initialized
INFO - 2020-09-17 07:06:28 --> Security Class Initialized
DEBUG - 2020-09-17 07:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:06:28 --> Input Class Initialized
INFO - 2020-09-17 07:06:28 --> Language Class Initialized
INFO - 2020-09-17 07:06:28 --> Loader Class Initialized
INFO - 2020-09-17 07:06:28 --> Helper loaded: html_helper
INFO - 2020-09-17 07:06:28 --> Helper loaded: url_helper
INFO - 2020-09-17 07:06:28 --> Helper loaded: form_helper
INFO - 2020-09-17 07:06:29 --> Database Driver Class Initialized
INFO - 2020-09-17 07:06:29 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:06:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:06:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:06:29 --> Encryption Class Initialized
INFO - 2020-09-17 07:06:29 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 07:06:29 --> Controller Class Initialized
INFO - 2020-09-17 07:06:29 --> Helper loaded: language_helper
INFO - 2020-09-17 07:06:29 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:06:29 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 07:06:29 --> Final output sent to browser
DEBUG - 2020-09-17 07:06:29 --> Total execution time: 0.9814
ERROR - 2020-09-17 07:06:29 --> Query error: [Microsoft][ODBC Driver 17 for SQL Server][SQL Server]Invalid column name 'timestamp'. - Invalid query: INSERT INTO "ci_sessions" ("id", "ip_address", "timestamp", "data") VALUES ('5d8rco4kqsl6pte8n7h1vs7lbec37aq6', '112.133.237.14', 1600326389, '__ci_last_regenerate|i:1600326389;site_lang|s:7:"english";')
INFO - 2020-09-17 07:06:29 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-17 07:06:29 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-09-17 07:06:29 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\Windows\Temp) Unknown 0
INFO - 2020-09-17 07:09:41 --> Config Class Initialized
INFO - 2020-09-17 07:09:41 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:09:41 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:09:41 --> Utf8 Class Initialized
INFO - 2020-09-17 07:09:41 --> URI Class Initialized
DEBUG - 2020-09-17 07:09:41 --> No URI present. Default controller set.
INFO - 2020-09-17 07:09:41 --> Router Class Initialized
INFO - 2020-09-17 07:09:41 --> Output Class Initialized
INFO - 2020-09-17 07:09:41 --> Security Class Initialized
DEBUG - 2020-09-17 07:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:09:41 --> Input Class Initialized
INFO - 2020-09-17 07:09:41 --> Language Class Initialized
INFO - 2020-09-17 07:09:41 --> Loader Class Initialized
INFO - 2020-09-17 07:09:41 --> Helper loaded: html_helper
INFO - 2020-09-17 07:09:41 --> Helper loaded: url_helper
INFO - 2020-09-17 07:09:41 --> Helper loaded: form_helper
INFO - 2020-09-17 07:09:41 --> Database Driver Class Initialized
INFO - 2020-09-17 07:09:41 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:09:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:09:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:09:41 --> Encryption Class Initialized
INFO - 2020-09-17 07:09:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 07:09:42 --> Controller Class Initialized
INFO - 2020-09-17 07:09:42 --> Helper loaded: language_helper
INFO - 2020-09-17 07:09:42 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:09:42 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 07:09:42 --> Final output sent to browser
DEBUG - 2020-09-17 07:09:42 --> Total execution time: 0.8312
ERROR - 2020-09-17 07:09:42 --> Query error: [Microsoft][ODBC Driver 17 for SQL Server][SQL Server]Cannot insert the value NULL into column 'user_agent', table 'cdrdb.cdradmin.CI_Sessions'; column does not allow nulls. INSERT fails. - Invalid query: INSERT INTO "ci_sessions" ("id", "ip_address", "timestamp", "data") VALUES ('8dm8ic7l9raou1fcsq5i7ses518vnmfv', '112.133.237.14', 1600326582, '__ci_last_regenerate|i:1600326582;site_lang|s:7:"english";')
INFO - 2020-09-17 07:09:42 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-17 07:09:42 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-09-17 07:09:42 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\Windows\Temp) Unknown 0
INFO - 2020-09-17 07:10:45 --> Config Class Initialized
INFO - 2020-09-17 07:10:45 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:10:45 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:10:45 --> Utf8 Class Initialized
INFO - 2020-09-17 07:10:45 --> URI Class Initialized
DEBUG - 2020-09-17 07:10:45 --> No URI present. Default controller set.
INFO - 2020-09-17 07:10:45 --> Router Class Initialized
INFO - 2020-09-17 07:10:45 --> Output Class Initialized
INFO - 2020-09-17 07:10:45 --> Security Class Initialized
DEBUG - 2020-09-17 07:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:10:45 --> Input Class Initialized
INFO - 2020-09-17 07:10:45 --> Language Class Initialized
INFO - 2020-09-17 07:10:45 --> Loader Class Initialized
INFO - 2020-09-17 07:10:45 --> Helper loaded: html_helper
INFO - 2020-09-17 07:10:45 --> Helper loaded: url_helper
INFO - 2020-09-17 07:10:45 --> Helper loaded: form_helper
INFO - 2020-09-17 07:10:45 --> Database Driver Class Initialized
INFO - 2020-09-17 07:10:45 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:10:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:10:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:10:45 --> Encryption Class Initialized
INFO - 2020-09-17 07:10:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 07:10:45 --> Controller Class Initialized
INFO - 2020-09-17 07:10:45 --> Helper loaded: language_helper
INFO - 2020-09-17 07:10:45 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:10:45 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 07:10:45 --> Final output sent to browser
DEBUG - 2020-09-17 07:10:45 --> Total execution time: 0.8744
INFO - 2020-09-17 07:10:51 --> Config Class Initialized
INFO - 2020-09-17 07:10:51 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:10:51 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:10:51 --> Utf8 Class Initialized
INFO - 2020-09-17 07:10:51 --> URI Class Initialized
INFO - 2020-09-17 07:10:51 --> Router Class Initialized
INFO - 2020-09-17 07:10:51 --> Output Class Initialized
INFO - 2020-09-17 07:10:51 --> Security Class Initialized
DEBUG - 2020-09-17 07:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:10:51 --> Input Class Initialized
INFO - 2020-09-17 07:10:51 --> Language Class Initialized
INFO - 2020-09-17 07:10:51 --> Loader Class Initialized
INFO - 2020-09-17 07:10:52 --> Helper loaded: html_helper
INFO - 2020-09-17 07:10:52 --> Helper loaded: url_helper
INFO - 2020-09-17 07:10:52 --> Helper loaded: form_helper
INFO - 2020-09-17 07:10:52 --> Database Driver Class Initialized
INFO - 2020-09-17 07:10:52 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:10:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:10:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:10:52 --> Encryption Class Initialized
INFO - 2020-09-17 07:10:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 07:10:52 --> Controller Class Initialized
INFO - 2020-09-17 07:10:52 --> Helper loaded: language_helper
INFO - 2020-09-17 07:10:52 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-17 07:10:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-17 07:10:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-17 07:10:52 --> Model "User" initialized
INFO - 2020-09-17 07:10:53 --> Config Class Initialized
INFO - 2020-09-17 07:10:53 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:10:53 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:10:53 --> Utf8 Class Initialized
INFO - 2020-09-17 07:10:53 --> URI Class Initialized
INFO - 2020-09-17 07:10:53 --> Router Class Initialized
INFO - 2020-09-17 07:10:53 --> Output Class Initialized
INFO - 2020-09-17 07:10:53 --> Security Class Initialized
DEBUG - 2020-09-17 07:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:10:53 --> Input Class Initialized
INFO - 2020-09-17 07:10:53 --> Language Class Initialized
INFO - 2020-09-17 07:10:53 --> Loader Class Initialized
INFO - 2020-09-17 07:10:53 --> Helper loaded: html_helper
INFO - 2020-09-17 07:10:53 --> Helper loaded: url_helper
INFO - 2020-09-17 07:10:53 --> Helper loaded: form_helper
INFO - 2020-09-17 07:10:53 --> Database Driver Class Initialized
INFO - 2020-09-17 07:10:53 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:10:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:10:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:10:53 --> Encryption Class Initialized
INFO - 2020-09-17 07:10:53 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 07:10:53 --> Controller Class Initialized
INFO - 2020-09-17 07:10:53 --> Helper loaded: language_helper
INFO - 2020-09-17 07:10:53 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:10:53 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 07:10:53 --> Final output sent to browser
DEBUG - 2020-09-17 07:10:53 --> Total execution time: 0.8170
INFO - 2020-09-17 07:16:18 --> Config Class Initialized
INFO - 2020-09-17 07:16:18 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:16:18 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:16:18 --> Utf8 Class Initialized
INFO - 2020-09-17 07:16:18 --> URI Class Initialized
INFO - 2020-09-17 07:16:18 --> Router Class Initialized
INFO - 2020-09-17 07:16:18 --> Output Class Initialized
INFO - 2020-09-17 07:16:18 --> Security Class Initialized
DEBUG - 2020-09-17 07:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:16:18 --> Input Class Initialized
INFO - 2020-09-17 07:16:18 --> Language Class Initialized
INFO - 2020-09-17 07:16:18 --> Loader Class Initialized
INFO - 2020-09-17 07:16:18 --> Helper loaded: html_helper
INFO - 2020-09-17 07:16:18 --> Helper loaded: url_helper
INFO - 2020-09-17 07:16:18 --> Helper loaded: form_helper
INFO - 2020-09-17 07:16:18 --> Database Driver Class Initialized
INFO - 2020-09-17 07:16:19 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:16:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:16:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:16:19 --> Encryption Class Initialized
INFO - 2020-09-17 07:16:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 07:16:19 --> Controller Class Initialized
INFO - 2020-09-17 07:16:19 --> Helper loaded: language_helper
INFO - 2020-09-17 07:16:19 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:16:19 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 07:16:19 --> Final output sent to browser
DEBUG - 2020-09-17 07:16:19 --> Total execution time: 0.8529
ERROR - 2020-09-17 07:16:19 --> Query error: [Microsoft][ODBC Driver 17 for SQL Server][SQL Server]Implicit conversion from data type varchar to varbinary(max) is not allowed. Use the CONVERT function to run this query. - Invalid query: INSERT INTO "ci_sessions" ("id", "ip_address", "timestamp", "data") VALUES ('herrjisfb4dhcng28es67eu84knf6af7', '112.133.237.14', 1600326979, '__ci_last_regenerate|i:1600326979;site_lang|s:7:"english";')
INFO - 2020-09-17 07:16:19 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-17 07:16:19 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-09-17 07:16:19 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\Windows\Temp) Unknown 0
INFO - 2020-09-17 07:16:41 --> Config Class Initialized
INFO - 2020-09-17 07:16:41 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:16:41 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:16:41 --> Utf8 Class Initialized
INFO - 2020-09-17 07:16:41 --> URI Class Initialized
INFO - 2020-09-17 07:16:41 --> Router Class Initialized
INFO - 2020-09-17 07:16:41 --> Output Class Initialized
INFO - 2020-09-17 07:16:41 --> Security Class Initialized
DEBUG - 2020-09-17 07:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:16:42 --> Input Class Initialized
INFO - 2020-09-17 07:16:42 --> Language Class Initialized
INFO - 2020-09-17 07:16:42 --> Loader Class Initialized
INFO - 2020-09-17 07:16:42 --> Helper loaded: html_helper
INFO - 2020-09-17 07:16:42 --> Helper loaded: url_helper
INFO - 2020-09-17 07:16:42 --> Helper loaded: form_helper
INFO - 2020-09-17 07:16:42 --> Database Driver Class Initialized
INFO - 2020-09-17 07:16:42 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:16:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:16:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:16:42 --> Encryption Class Initialized
INFO - 2020-09-17 07:16:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 07:16:42 --> Controller Class Initialized
INFO - 2020-09-17 07:16:42 --> Helper loaded: language_helper
INFO - 2020-09-17 07:16:42 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:16:42 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 07:16:42 --> Final output sent to browser
DEBUG - 2020-09-17 07:16:42 --> Total execution time: 0.8787
INFO - 2020-09-17 07:16:48 --> Config Class Initialized
INFO - 2020-09-17 07:16:48 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:16:48 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:16:48 --> Utf8 Class Initialized
INFO - 2020-09-17 07:16:48 --> URI Class Initialized
INFO - 2020-09-17 07:16:48 --> Router Class Initialized
INFO - 2020-09-17 07:16:48 --> Output Class Initialized
INFO - 2020-09-17 07:16:48 --> Security Class Initialized
DEBUG - 2020-09-17 07:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:16:48 --> Input Class Initialized
INFO - 2020-09-17 07:16:48 --> Language Class Initialized
INFO - 2020-09-17 07:16:48 --> Loader Class Initialized
INFO - 2020-09-17 07:16:49 --> Helper loaded: html_helper
INFO - 2020-09-17 07:16:49 --> Helper loaded: url_helper
INFO - 2020-09-17 07:16:49 --> Helper loaded: form_helper
INFO - 2020-09-17 07:16:49 --> Database Driver Class Initialized
INFO - 2020-09-17 07:16:49 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:16:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:16:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:16:49 --> Encryption Class Initialized
INFO - 2020-09-17 07:16:49 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 07:16:49 --> Controller Class Initialized
INFO - 2020-09-17 07:16:49 --> Helper loaded: language_helper
INFO - 2020-09-17 07:16:49 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-17 07:16:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-17 07:16:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-17 07:16:49 --> Model "User" initialized
INFO - 2020-09-17 07:16:50 --> Config Class Initialized
INFO - 2020-09-17 07:16:50 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:16:50 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:16:50 --> Utf8 Class Initialized
INFO - 2020-09-17 07:16:50 --> URI Class Initialized
INFO - 2020-09-17 07:16:50 --> Router Class Initialized
INFO - 2020-09-17 07:16:50 --> Output Class Initialized
INFO - 2020-09-17 07:16:50 --> Security Class Initialized
DEBUG - 2020-09-17 07:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:16:50 --> Input Class Initialized
INFO - 2020-09-17 07:16:50 --> Language Class Initialized
INFO - 2020-09-17 07:16:50 --> Loader Class Initialized
INFO - 2020-09-17 07:16:50 --> Helper loaded: html_helper
INFO - 2020-09-17 07:16:50 --> Helper loaded: url_helper
INFO - 2020-09-17 07:16:50 --> Helper loaded: form_helper
INFO - 2020-09-17 07:16:50 --> Database Driver Class Initialized
INFO - 2020-09-17 07:16:50 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:16:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:16:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:16:50 --> Encryption Class Initialized
INFO - 2020-09-17 07:16:50 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 07:16:50 --> Controller Class Initialized
INFO - 2020-09-17 07:16:50 --> Helper loaded: language_helper
INFO - 2020-09-17 07:16:50 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:16:50 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 07:16:50 --> Final output sent to browser
DEBUG - 2020-09-17 07:16:50 --> Total execution time: 0.8479
INFO - 2020-09-17 07:16:57 --> Config Class Initialized
INFO - 2020-09-17 07:16:57 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:16:57 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:16:57 --> Utf8 Class Initialized
INFO - 2020-09-17 07:16:57 --> URI Class Initialized
INFO - 2020-09-17 07:16:58 --> Router Class Initialized
INFO - 2020-09-17 07:16:58 --> Output Class Initialized
INFO - 2020-09-17 07:16:58 --> Security Class Initialized
DEBUG - 2020-09-17 07:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:16:58 --> Input Class Initialized
INFO - 2020-09-17 07:16:58 --> Language Class Initialized
INFO - 2020-09-17 07:16:58 --> Loader Class Initialized
INFO - 2020-09-17 07:16:58 --> Helper loaded: html_helper
INFO - 2020-09-17 07:16:58 --> Helper loaded: url_helper
INFO - 2020-09-17 07:16:58 --> Helper loaded: form_helper
INFO - 2020-09-17 07:16:58 --> Database Driver Class Initialized
INFO - 2020-09-17 07:16:58 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:16:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:16:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:16:58 --> Encryption Class Initialized
INFO - 2020-09-17 07:16:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 07:16:58 --> Controller Class Initialized
INFO - 2020-09-17 07:16:58 --> Helper loaded: language_helper
INFO - 2020-09-17 07:16:58 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-17 07:16:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-17 07:16:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-17 07:16:58 --> Model "User" initialized
INFO - 2020-09-17 07:16:59 --> Config Class Initialized
INFO - 2020-09-17 07:16:59 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:16:59 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:16:59 --> Utf8 Class Initialized
INFO - 2020-09-17 07:16:59 --> URI Class Initialized
INFO - 2020-09-17 07:16:59 --> Router Class Initialized
INFO - 2020-09-17 07:16:59 --> Output Class Initialized
INFO - 2020-09-17 07:16:59 --> Security Class Initialized
DEBUG - 2020-09-17 07:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:16:59 --> Input Class Initialized
INFO - 2020-09-17 07:16:59 --> Language Class Initialized
INFO - 2020-09-17 07:16:59 --> Loader Class Initialized
INFO - 2020-09-17 07:16:59 --> Helper loaded: html_helper
INFO - 2020-09-17 07:16:59 --> Helper loaded: url_helper
INFO - 2020-09-17 07:16:59 --> Helper loaded: form_helper
INFO - 2020-09-17 07:16:59 --> Database Driver Class Initialized
INFO - 2020-09-17 07:16:59 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:16:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:17:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:17:00 --> Encryption Class Initialized
INFO - 2020-09-17 07:17:00 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 07:17:00 --> Controller Class Initialized
INFO - 2020-09-17 07:17:00 --> Helper loaded: language_helper
INFO - 2020-09-17 07:17:00 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:17:00 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 07:17:00 --> Final output sent to browser
DEBUG - 2020-09-17 07:17:00 --> Total execution time: 0.8580
INFO - 2020-09-17 07:19:15 --> Config Class Initialized
INFO - 2020-09-17 07:19:15 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:19:15 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:19:15 --> Utf8 Class Initialized
INFO - 2020-09-17 07:19:15 --> URI Class Initialized
INFO - 2020-09-17 07:19:15 --> Router Class Initialized
INFO - 2020-09-17 07:19:15 --> Output Class Initialized
INFO - 2020-09-17 07:19:15 --> Security Class Initialized
DEBUG - 2020-09-17 07:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:19:16 --> Input Class Initialized
INFO - 2020-09-17 07:19:16 --> Language Class Initialized
INFO - 2020-09-17 07:19:16 --> Loader Class Initialized
INFO - 2020-09-17 07:19:16 --> Helper loaded: html_helper
INFO - 2020-09-17 07:19:16 --> Helper loaded: url_helper
INFO - 2020-09-17 07:19:16 --> Helper loaded: form_helper
INFO - 2020-09-17 07:19:16 --> Database Driver Class Initialized
INFO - 2020-09-17 07:19:16 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:19:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:19:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:19:16 --> Encryption Class Initialized
INFO - 2020-09-17 07:19:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 07:19:16 --> Controller Class Initialized
INFO - 2020-09-17 07:19:16 --> Helper loaded: language_helper
INFO - 2020-09-17 07:19:16 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:19:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 07:19:16 --> Final output sent to browser
DEBUG - 2020-09-17 07:19:16 --> Total execution time: 0.8363
INFO - 2020-09-17 07:19:22 --> Config Class Initialized
INFO - 2020-09-17 07:19:22 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:19:22 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:19:22 --> Utf8 Class Initialized
INFO - 2020-09-17 07:19:22 --> URI Class Initialized
INFO - 2020-09-17 07:19:22 --> Router Class Initialized
INFO - 2020-09-17 07:19:22 --> Output Class Initialized
INFO - 2020-09-17 07:19:23 --> Security Class Initialized
DEBUG - 2020-09-17 07:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:19:23 --> Input Class Initialized
INFO - 2020-09-17 07:19:23 --> Language Class Initialized
INFO - 2020-09-17 07:19:23 --> Loader Class Initialized
INFO - 2020-09-17 07:19:23 --> Helper loaded: html_helper
INFO - 2020-09-17 07:19:23 --> Helper loaded: url_helper
INFO - 2020-09-17 07:19:23 --> Helper loaded: form_helper
INFO - 2020-09-17 07:19:23 --> Database Driver Class Initialized
INFO - 2020-09-17 07:19:23 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:19:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:19:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:19:23 --> Encryption Class Initialized
INFO - 2020-09-17 07:19:23 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 07:19:23 --> Controller Class Initialized
INFO - 2020-09-17 07:19:23 --> Helper loaded: language_helper
INFO - 2020-09-17 07:19:23 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-17 07:19:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-17 07:19:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-17 07:19:23 --> Model "User" initialized
INFO - 2020-09-17 07:19:24 --> Config Class Initialized
INFO - 2020-09-17 07:19:24 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:19:24 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:19:24 --> Utf8 Class Initialized
INFO - 2020-09-17 07:19:24 --> URI Class Initialized
INFO - 2020-09-17 07:19:24 --> Router Class Initialized
INFO - 2020-09-17 07:19:24 --> Output Class Initialized
INFO - 2020-09-17 07:19:24 --> Security Class Initialized
DEBUG - 2020-09-17 07:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:19:24 --> Input Class Initialized
INFO - 2020-09-17 07:19:24 --> Language Class Initialized
INFO - 2020-09-17 07:19:24 --> Loader Class Initialized
INFO - 2020-09-17 07:19:24 --> Helper loaded: html_helper
INFO - 2020-09-17 07:19:24 --> Helper loaded: url_helper
INFO - 2020-09-17 07:19:24 --> Helper loaded: form_helper
INFO - 2020-09-17 07:19:24 --> Database Driver Class Initialized
INFO - 2020-09-17 07:19:24 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:19:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:19:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:19:24 --> Encryption Class Initialized
INFO - 2020-09-17 07:19:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-17 07:19:25 --> Controller Class Initialized
INFO - 2020-09-17 07:19:25 --> Helper loaded: language_helper
INFO - 2020-09-17 07:19:25 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:19:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 07:19:25 --> Final output sent to browser
DEBUG - 2020-09-17 07:19:25 --> Total execution time: 0.8344
INFO - 2020-09-17 07:21:58 --> Config Class Initialized
INFO - 2020-09-17 07:21:58 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:21:58 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:21:58 --> Utf8 Class Initialized
INFO - 2020-09-17 07:21:58 --> URI Class Initialized
INFO - 2020-09-17 07:21:59 --> Router Class Initialized
INFO - 2020-09-17 07:21:59 --> Output Class Initialized
INFO - 2020-09-17 07:21:59 --> Security Class Initialized
DEBUG - 2020-09-17 07:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:21:59 --> Input Class Initialized
INFO - 2020-09-17 07:21:59 --> Language Class Initialized
INFO - 2020-09-17 07:21:59 --> Loader Class Initialized
INFO - 2020-09-17 07:21:59 --> Helper loaded: html_helper
INFO - 2020-09-17 07:21:59 --> Helper loaded: url_helper
INFO - 2020-09-17 07:21:59 --> Helper loaded: form_helper
INFO - 2020-09-17 07:21:59 --> Database Driver Class Initialized
INFO - 2020-09-17 07:21:59 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:21:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:21:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:21:59 --> Encryption Class Initialized
DEBUG - 2020-09-17 07:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-09-17 07:21:59 --> Severity: error --> Exception: Session: Configured save path 'C:\Windows\Temp' is not writable by the PHP process. C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\system\libraries\Session\drivers\Session_files_driver.php 143
INFO - 2020-09-17 07:23:35 --> Config Class Initialized
INFO - 2020-09-17 07:23:35 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:23:35 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:23:35 --> Utf8 Class Initialized
INFO - 2020-09-17 07:23:35 --> URI Class Initialized
INFO - 2020-09-17 07:23:35 --> Router Class Initialized
INFO - 2020-09-17 07:23:36 --> Output Class Initialized
INFO - 2020-09-17 07:23:36 --> Security Class Initialized
DEBUG - 2020-09-17 07:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:23:36 --> Input Class Initialized
INFO - 2020-09-17 07:23:36 --> Language Class Initialized
INFO - 2020-09-17 07:23:36 --> Loader Class Initialized
INFO - 2020-09-17 07:23:36 --> Helper loaded: html_helper
INFO - 2020-09-17 07:23:36 --> Helper loaded: url_helper
INFO - 2020-09-17 07:23:36 --> Helper loaded: form_helper
INFO - 2020-09-17 07:23:36 --> Database Driver Class Initialized
INFO - 2020-09-17 07:23:36 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:23:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:23:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:23:36 --> Encryption Class Initialized
INFO - 2020-09-17 07:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:23:36 --> Controller Class Initialized
INFO - 2020-09-17 07:23:36 --> Helper loaded: language_helper
INFO - 2020-09-17 07:23:36 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:23:36 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 07:23:36 --> Final output sent to browser
DEBUG - 2020-09-17 07:23:36 --> Total execution time: 1.0534
INFO - 2020-09-17 07:23:43 --> Config Class Initialized
INFO - 2020-09-17 07:23:43 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:23:43 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:23:43 --> Utf8 Class Initialized
INFO - 2020-09-17 07:23:43 --> URI Class Initialized
INFO - 2020-09-17 07:23:43 --> Router Class Initialized
INFO - 2020-09-17 07:23:43 --> Output Class Initialized
INFO - 2020-09-17 07:23:43 --> Security Class Initialized
DEBUG - 2020-09-17 07:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:23:43 --> Input Class Initialized
INFO - 2020-09-17 07:23:43 --> Language Class Initialized
INFO - 2020-09-17 07:23:43 --> Loader Class Initialized
INFO - 2020-09-17 07:23:44 --> Helper loaded: html_helper
INFO - 2020-09-17 07:23:44 --> Helper loaded: url_helper
INFO - 2020-09-17 07:23:44 --> Helper loaded: form_helper
INFO - 2020-09-17 07:23:44 --> Database Driver Class Initialized
INFO - 2020-09-17 07:23:44 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:23:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:23:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:23:44 --> Encryption Class Initialized
INFO - 2020-09-17 07:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:23:44 --> Controller Class Initialized
INFO - 2020-09-17 07:23:44 --> Helper loaded: language_helper
INFO - 2020-09-17 07:23:44 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-17 07:23:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-17 07:23:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-17 07:23:44 --> Model "User" initialized
INFO - 2020-09-17 07:23:45 --> Config Class Initialized
INFO - 2020-09-17 07:23:45 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:23:45 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:23:45 --> Utf8 Class Initialized
INFO - 2020-09-17 07:23:45 --> URI Class Initialized
INFO - 2020-09-17 07:23:45 --> Router Class Initialized
INFO - 2020-09-17 07:23:45 --> Output Class Initialized
INFO - 2020-09-17 07:23:45 --> Security Class Initialized
DEBUG - 2020-09-17 07:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:23:45 --> Input Class Initialized
INFO - 2020-09-17 07:23:45 --> Language Class Initialized
INFO - 2020-09-17 07:23:45 --> Loader Class Initialized
INFO - 2020-09-17 07:23:45 --> Helper loaded: html_helper
INFO - 2020-09-17 07:23:45 --> Helper loaded: url_helper
INFO - 2020-09-17 07:23:45 --> Helper loaded: form_helper
INFO - 2020-09-17 07:23:45 --> Database Driver Class Initialized
INFO - 2020-09-17 07:23:45 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:23:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:23:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:23:45 --> Encryption Class Initialized
INFO - 2020-09-17 07:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:23:45 --> Controller Class Initialized
INFO - 2020-09-17 07:23:45 --> Helper loaded: language_helper
INFO - 2020-09-17 07:23:45 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:23:46 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-17 07:23:46 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 07:23:46 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-17 07:23:46 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 07:23:46 --> Final output sent to browser
DEBUG - 2020-09-17 07:23:46 --> Total execution time: 1.0631
INFO - 2020-09-17 07:23:54 --> Config Class Initialized
INFO - 2020-09-17 07:23:54 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:23:54 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:23:54 --> Utf8 Class Initialized
INFO - 2020-09-17 07:23:54 --> URI Class Initialized
INFO - 2020-09-17 07:23:54 --> Router Class Initialized
INFO - 2020-09-17 07:23:54 --> Output Class Initialized
INFO - 2020-09-17 07:23:54 --> Security Class Initialized
DEBUG - 2020-09-17 07:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:23:54 --> Input Class Initialized
INFO - 2020-09-17 07:23:54 --> Language Class Initialized
INFO - 2020-09-17 07:23:54 --> Loader Class Initialized
INFO - 2020-09-17 07:23:54 --> Helper loaded: html_helper
INFO - 2020-09-17 07:23:54 --> Helper loaded: url_helper
INFO - 2020-09-17 07:23:54 --> Helper loaded: form_helper
INFO - 2020-09-17 07:23:54 --> Database Driver Class Initialized
INFO - 2020-09-17 07:23:54 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:23:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:23:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:23:54 --> Encryption Class Initialized
INFO - 2020-09-17 07:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:23:54 --> Controller Class Initialized
INFO - 2020-09-17 07:23:54 --> Helper loaded: language_helper
INFO - 2020-09-17 07:23:54 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:23:54 --> Final output sent to browser
DEBUG - 2020-09-17 07:23:55 --> Total execution time: 0.8428
INFO - 2020-09-17 07:23:55 --> Config Class Initialized
INFO - 2020-09-17 07:23:55 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:23:55 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:23:55 --> Utf8 Class Initialized
INFO - 2020-09-17 07:23:55 --> URI Class Initialized
DEBUG - 2020-09-17 07:23:55 --> No URI present. Default controller set.
INFO - 2020-09-17 07:23:55 --> Router Class Initialized
INFO - 2020-09-17 07:23:55 --> Output Class Initialized
INFO - 2020-09-17 07:23:55 --> Security Class Initialized
DEBUG - 2020-09-17 07:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:23:55 --> Input Class Initialized
INFO - 2020-09-17 07:23:55 --> Language Class Initialized
INFO - 2020-09-17 07:23:55 --> Loader Class Initialized
INFO - 2020-09-17 07:23:55 --> Helper loaded: html_helper
INFO - 2020-09-17 07:23:55 --> Helper loaded: url_helper
INFO - 2020-09-17 07:23:55 --> Helper loaded: form_helper
INFO - 2020-09-17 07:23:55 --> Database Driver Class Initialized
INFO - 2020-09-17 07:23:55 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:23:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:23:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:23:56 --> Encryption Class Initialized
INFO - 2020-09-17 07:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:23:56 --> Controller Class Initialized
INFO - 2020-09-17 07:23:56 --> Helper loaded: language_helper
INFO - 2020-09-17 07:23:56 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:23:56 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 07:23:56 --> Final output sent to browser
DEBUG - 2020-09-17 07:23:56 --> Total execution time: 0.8640
INFO - 2020-09-17 07:24:03 --> Config Class Initialized
INFO - 2020-09-17 07:24:03 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:24:03 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:24:03 --> Utf8 Class Initialized
INFO - 2020-09-17 07:24:03 --> URI Class Initialized
INFO - 2020-09-17 07:24:03 --> Router Class Initialized
INFO - 2020-09-17 07:24:03 --> Output Class Initialized
INFO - 2020-09-17 07:24:03 --> Security Class Initialized
DEBUG - 2020-09-17 07:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:24:03 --> Input Class Initialized
INFO - 2020-09-17 07:24:03 --> Language Class Initialized
INFO - 2020-09-17 07:24:03 --> Loader Class Initialized
INFO - 2020-09-17 07:24:03 --> Helper loaded: html_helper
INFO - 2020-09-17 07:24:03 --> Helper loaded: url_helper
INFO - 2020-09-17 07:24:03 --> Helper loaded: form_helper
INFO - 2020-09-17 07:24:03 --> Database Driver Class Initialized
INFO - 2020-09-17 07:24:03 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:24:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:24:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:24:03 --> Encryption Class Initialized
INFO - 2020-09-17 07:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:24:03 --> Controller Class Initialized
INFO - 2020-09-17 07:24:03 --> Helper loaded: language_helper
INFO - 2020-09-17 07:24:03 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-17 07:24:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-17 07:24:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-17 07:24:03 --> Model "User" initialized
INFO - 2020-09-17 07:24:03 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 07:24:03 --> Final output sent to browser
DEBUG - 2020-09-17 07:24:04 --> Total execution time: 0.9579
INFO - 2020-09-17 07:24:09 --> Config Class Initialized
INFO - 2020-09-17 07:24:09 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:24:09 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:24:09 --> Utf8 Class Initialized
INFO - 2020-09-17 07:24:09 --> URI Class Initialized
INFO - 2020-09-17 07:24:09 --> Router Class Initialized
INFO - 2020-09-17 07:24:09 --> Output Class Initialized
INFO - 2020-09-17 07:24:09 --> Security Class Initialized
DEBUG - 2020-09-17 07:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:24:09 --> Input Class Initialized
INFO - 2020-09-17 07:24:09 --> Language Class Initialized
INFO - 2020-09-17 07:24:09 --> Loader Class Initialized
INFO - 2020-09-17 07:24:09 --> Helper loaded: html_helper
INFO - 2020-09-17 07:24:09 --> Helper loaded: url_helper
INFO - 2020-09-17 07:24:09 --> Helper loaded: form_helper
INFO - 2020-09-17 07:24:09 --> Database Driver Class Initialized
INFO - 2020-09-17 07:24:09 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:24:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:24:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:24:09 --> Encryption Class Initialized
INFO - 2020-09-17 07:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:24:09 --> Controller Class Initialized
INFO - 2020-09-17 07:24:09 --> Helper loaded: language_helper
INFO - 2020-09-17 07:24:09 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-17 07:24:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-17 07:24:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-17 07:24:10 --> Model "User" initialized
INFO - 2020-09-17 07:24:10 --> Config Class Initialized
INFO - 2020-09-17 07:24:10 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:24:10 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:24:10 --> Utf8 Class Initialized
INFO - 2020-09-17 07:24:10 --> URI Class Initialized
INFO - 2020-09-17 07:24:10 --> Router Class Initialized
INFO - 2020-09-17 07:24:10 --> Output Class Initialized
INFO - 2020-09-17 07:24:10 --> Security Class Initialized
DEBUG - 2020-09-17 07:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:24:11 --> Input Class Initialized
INFO - 2020-09-17 07:24:11 --> Language Class Initialized
INFO - 2020-09-17 07:24:11 --> Loader Class Initialized
INFO - 2020-09-17 07:24:11 --> Helper loaded: html_helper
INFO - 2020-09-17 07:24:11 --> Helper loaded: url_helper
INFO - 2020-09-17 07:24:11 --> Helper loaded: form_helper
INFO - 2020-09-17 07:24:11 --> Database Driver Class Initialized
INFO - 2020-09-17 07:24:11 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:24:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:24:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:24:11 --> Encryption Class Initialized
INFO - 2020-09-17 07:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:24:11 --> Controller Class Initialized
INFO - 2020-09-17 07:24:11 --> Helper loaded: language_helper
INFO - 2020-09-17 07:24:11 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:24:11 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-17 07:24:11 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 07:24:11 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-17 07:24:11 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 07:24:11 --> Final output sent to browser
DEBUG - 2020-09-17 07:24:11 --> Total execution time: 0.9046
INFO - 2020-09-17 07:31:04 --> Config Class Initialized
INFO - 2020-09-17 07:31:04 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:31:04 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:31:04 --> Utf8 Class Initialized
INFO - 2020-09-17 07:31:04 --> URI Class Initialized
INFO - 2020-09-17 07:31:04 --> Router Class Initialized
INFO - 2020-09-17 07:31:05 --> Output Class Initialized
INFO - 2020-09-17 07:31:05 --> Security Class Initialized
DEBUG - 2020-09-17 07:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:31:05 --> Input Class Initialized
INFO - 2020-09-17 07:31:05 --> Language Class Initialized
INFO - 2020-09-17 07:31:05 --> Loader Class Initialized
INFO - 2020-09-17 07:31:05 --> Helper loaded: html_helper
INFO - 2020-09-17 07:31:05 --> Helper loaded: url_helper
INFO - 2020-09-17 07:31:05 --> Helper loaded: form_helper
INFO - 2020-09-17 07:31:05 --> Database Driver Class Initialized
INFO - 2020-09-17 07:31:05 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:31:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:31:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:31:05 --> Encryption Class Initialized
INFO - 2020-09-17 07:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:31:05 --> Controller Class Initialized
INFO - 2020-09-17 07:31:05 --> Helper loaded: language_helper
INFO - 2020-09-17 07:31:05 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:31:05 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-17 07:31:05 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 07:31:05 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-17 07:31:05 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 07:31:06 --> Final output sent to browser
DEBUG - 2020-09-17 07:31:06 --> Total execution time: 1.2275
INFO - 2020-09-17 07:31:13 --> Config Class Initialized
INFO - 2020-09-17 07:31:13 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:31:13 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:31:13 --> Utf8 Class Initialized
INFO - 2020-09-17 07:31:13 --> URI Class Initialized
INFO - 2020-09-17 07:31:13 --> Router Class Initialized
INFO - 2020-09-17 07:31:13 --> Output Class Initialized
INFO - 2020-09-17 07:31:13 --> Security Class Initialized
DEBUG - 2020-09-17 07:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:31:13 --> Input Class Initialized
INFO - 2020-09-17 07:31:13 --> Language Class Initialized
INFO - 2020-09-17 07:31:13 --> Loader Class Initialized
INFO - 2020-09-17 07:31:14 --> Helper loaded: html_helper
INFO - 2020-09-17 07:31:14 --> Helper loaded: url_helper
INFO - 2020-09-17 07:31:14 --> Helper loaded: form_helper
INFO - 2020-09-17 07:31:14 --> Database Driver Class Initialized
INFO - 2020-09-17 07:31:14 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:31:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:31:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:31:14 --> Encryption Class Initialized
INFO - 2020-09-17 07:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:31:14 --> Controller Class Initialized
INFO - 2020-09-17 07:31:14 --> Helper loaded: language_helper
INFO - 2020-09-17 07:31:14 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:31:14 --> Model "Sale_model" initialized
ERROR - 2020-09-17 07:31:14 --> Query error: [Microsoft][ODBC Driver 17 for SQL Server][SQL Server]Incorrect syntax near '`'. - Invalid query: SELECT `id`, `full_name`, `contact_no`, `dept_email_id`, `department`, `designation`, `address`, `created_dt`, `serial_key`, `installed_dt`, `status`, `razorpay_order_id`
				FROM tbl_user_info
				WHERE UNIX_TIMESTAMP(`created_dt`) BETWEEN 1598898600 AND 1603132140
				LIMIT 50
INFO - 2020-09-17 07:31:14 --> Language file loaded: language/english/db_lang.php
INFO - 2020-09-17 07:31:23 --> Config Class Initialized
INFO - 2020-09-17 07:31:23 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:31:23 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:31:23 --> Utf8 Class Initialized
INFO - 2020-09-17 07:31:23 --> URI Class Initialized
INFO - 2020-09-17 07:31:23 --> Router Class Initialized
INFO - 2020-09-17 07:31:23 --> Output Class Initialized
INFO - 2020-09-17 07:31:23 --> Security Class Initialized
DEBUG - 2020-09-17 07:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:31:23 --> Input Class Initialized
INFO - 2020-09-17 07:31:23 --> Language Class Initialized
INFO - 2020-09-17 07:31:23 --> Loader Class Initialized
INFO - 2020-09-17 07:31:23 --> Helper loaded: html_helper
INFO - 2020-09-17 07:31:23 --> Helper loaded: url_helper
INFO - 2020-09-17 07:31:23 --> Helper loaded: form_helper
INFO - 2020-09-17 07:31:23 --> Database Driver Class Initialized
INFO - 2020-09-17 07:31:23 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:31:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:31:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:31:23 --> Encryption Class Initialized
INFO - 2020-09-17 07:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:31:24 --> Controller Class Initialized
INFO - 2020-09-17 07:31:24 --> Helper loaded: language_helper
INFO - 2020-09-17 07:31:24 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:31:24 --> Model "Sale_model" initialized
ERROR - 2020-09-17 07:31:24 --> Query error: [Microsoft][ODBC Driver 17 for SQL Server][SQL Server]Incorrect syntax near '`'. - Invalid query: SELECT `id`, `full_name`, `contact_no`, `dept_email_id`, `department`, `designation`, `address`, `created_dt`, `serial_key`, `installed_dt`, `status`, `razorpay_order_id`
				FROM tbl_user_info
				WHERE UNIX_TIMESTAMP(`created_dt`) BETWEEN 1598898600 AND 1603132140
				LIMIT 50
INFO - 2020-09-17 07:31:24 --> Language file loaded: language/english/db_lang.php
INFO - 2020-09-17 07:33:20 --> Config Class Initialized
INFO - 2020-09-17 07:33:20 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:33:20 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:33:20 --> Utf8 Class Initialized
INFO - 2020-09-17 07:33:20 --> URI Class Initialized
INFO - 2020-09-17 07:33:20 --> Router Class Initialized
INFO - 2020-09-17 07:33:20 --> Output Class Initialized
INFO - 2020-09-17 07:33:20 --> Security Class Initialized
DEBUG - 2020-09-17 07:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:33:20 --> Input Class Initialized
INFO - 2020-09-17 07:33:20 --> Language Class Initialized
INFO - 2020-09-17 07:33:20 --> Loader Class Initialized
INFO - 2020-09-17 07:33:20 --> Helper loaded: html_helper
INFO - 2020-09-17 07:33:20 --> Helper loaded: url_helper
INFO - 2020-09-17 07:33:20 --> Helper loaded: form_helper
INFO - 2020-09-17 07:33:20 --> Database Driver Class Initialized
INFO - 2020-09-17 07:33:20 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:33:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:33:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:33:20 --> Encryption Class Initialized
INFO - 2020-09-17 07:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:33:21 --> Controller Class Initialized
INFO - 2020-09-17 07:33:21 --> Helper loaded: language_helper
INFO - 2020-09-17 07:33:21 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:33:21 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-17 07:33:21 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 07:33:21 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-17 07:33:21 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 07:33:21 --> Final output sent to browser
DEBUG - 2020-09-17 07:33:21 --> Total execution time: 1.1201
INFO - 2020-09-17 07:33:24 --> Config Class Initialized
INFO - 2020-09-17 07:33:24 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:33:24 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:33:24 --> Utf8 Class Initialized
INFO - 2020-09-17 07:33:24 --> URI Class Initialized
INFO - 2020-09-17 07:33:24 --> Router Class Initialized
INFO - 2020-09-17 07:33:24 --> Output Class Initialized
INFO - 2020-09-17 07:33:24 --> Security Class Initialized
DEBUG - 2020-09-17 07:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:33:24 --> Input Class Initialized
INFO - 2020-09-17 07:33:24 --> Language Class Initialized
INFO - 2020-09-17 07:33:24 --> Loader Class Initialized
INFO - 2020-09-17 07:33:24 --> Helper loaded: html_helper
INFO - 2020-09-17 07:33:24 --> Helper loaded: url_helper
INFO - 2020-09-17 07:33:24 --> Helper loaded: form_helper
INFO - 2020-09-17 07:33:25 --> Database Driver Class Initialized
INFO - 2020-09-17 07:33:25 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:33:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:33:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:33:25 --> Encryption Class Initialized
INFO - 2020-09-17 07:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:33:25 --> Controller Class Initialized
INFO - 2020-09-17 07:33:25 --> Helper loaded: language_helper
INFO - 2020-09-17 07:33:25 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:33:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-17 07:33:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 07:33:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-17 07:33:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 07:33:25 --> Final output sent to browser
DEBUG - 2020-09-17 07:33:25 --> Total execution time: 0.9934
INFO - 2020-09-17 07:33:32 --> Config Class Initialized
INFO - 2020-09-17 07:33:32 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:33:32 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:33:32 --> Utf8 Class Initialized
INFO - 2020-09-17 07:33:32 --> URI Class Initialized
INFO - 2020-09-17 07:33:32 --> Router Class Initialized
INFO - 2020-09-17 07:33:32 --> Output Class Initialized
INFO - 2020-09-17 07:33:32 --> Security Class Initialized
DEBUG - 2020-09-17 07:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:33:32 --> Input Class Initialized
INFO - 2020-09-17 07:33:32 --> Language Class Initialized
INFO - 2020-09-17 07:33:32 --> Loader Class Initialized
INFO - 2020-09-17 07:33:32 --> Helper loaded: html_helper
INFO - 2020-09-17 07:33:32 --> Helper loaded: url_helper
INFO - 2020-09-17 07:33:32 --> Helper loaded: form_helper
INFO - 2020-09-17 07:33:32 --> Database Driver Class Initialized
INFO - 2020-09-17 07:33:32 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:33:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:33:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:33:33 --> Encryption Class Initialized
INFO - 2020-09-17 07:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:33:33 --> Controller Class Initialized
INFO - 2020-09-17 07:33:33 --> Helper loaded: language_helper
INFO - 2020-09-17 07:33:33 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:33:33 --> Model "Sale_model" initialized
ERROR - 2020-09-17 07:33:33 --> Query error: [Microsoft][ODBC Driver 17 for SQL Server][SQL Server]'UNIX_TIMESTAMP' is not a recognized built-in function name. - Invalid query: SELECT id, full_name, contact_no, dept_email_id, department, designation, address, created_dt, serial_key, installed_dt, status, razorpay_order_id
				FROM tbl_user_info
				WHERE UNIX_TIMESTAMP(created_dt) BETWEEN 1598898600 AND 1603736940
				LIMIT 50
INFO - 2020-09-17 07:33:33 --> Language file loaded: language/english/db_lang.php
INFO - 2020-09-17 07:33:36 --> Config Class Initialized
INFO - 2020-09-17 07:33:36 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:33:37 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:33:37 --> Utf8 Class Initialized
INFO - 2020-09-17 07:33:37 --> URI Class Initialized
INFO - 2020-09-17 07:33:37 --> Router Class Initialized
INFO - 2020-09-17 07:33:37 --> Output Class Initialized
INFO - 2020-09-17 07:33:37 --> Security Class Initialized
DEBUG - 2020-09-17 07:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:33:37 --> Input Class Initialized
INFO - 2020-09-17 07:33:37 --> Language Class Initialized
INFO - 2020-09-17 07:33:37 --> Loader Class Initialized
INFO - 2020-09-17 07:33:37 --> Helper loaded: html_helper
INFO - 2020-09-17 07:33:37 --> Helper loaded: url_helper
INFO - 2020-09-17 07:33:37 --> Helper loaded: form_helper
INFO - 2020-09-17 07:33:37 --> Database Driver Class Initialized
INFO - 2020-09-17 07:33:37 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:33:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:33:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:33:37 --> Encryption Class Initialized
INFO - 2020-09-17 07:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:33:37 --> Controller Class Initialized
INFO - 2020-09-17 07:33:37 --> Helper loaded: language_helper
INFO - 2020-09-17 07:33:37 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:33:37 --> Model "Sale_model" initialized
ERROR - 2020-09-17 07:33:37 --> Query error: [Microsoft][ODBC Driver 17 for SQL Server][SQL Server]'UNIX_TIMESTAMP' is not a recognized built-in function name. - Invalid query: SELECT id, full_name, contact_no, dept_email_id, department, designation, address, created_dt, serial_key, installed_dt, status, razorpay_order_id
				FROM tbl_user_info
				WHERE UNIX_TIMESTAMP(created_dt) BETWEEN 1598898600 AND 1603736940
				LIMIT 50
INFO - 2020-09-17 07:33:37 --> Language file loaded: language/english/db_lang.php
INFO - 2020-09-17 07:37:12 --> Config Class Initialized
INFO - 2020-09-17 07:37:12 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:37:12 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:37:12 --> Utf8 Class Initialized
INFO - 2020-09-17 07:37:12 --> URI Class Initialized
INFO - 2020-09-17 07:37:12 --> Router Class Initialized
INFO - 2020-09-17 07:37:12 --> Output Class Initialized
INFO - 2020-09-17 07:37:12 --> Security Class Initialized
DEBUG - 2020-09-17 07:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:37:12 --> Input Class Initialized
INFO - 2020-09-17 07:37:12 --> Language Class Initialized
INFO - 2020-09-17 07:37:12 --> Loader Class Initialized
INFO - 2020-09-17 07:37:12 --> Helper loaded: html_helper
INFO - 2020-09-17 07:37:12 --> Helper loaded: url_helper
INFO - 2020-09-17 07:37:12 --> Helper loaded: form_helper
INFO - 2020-09-17 07:37:12 --> Database Driver Class Initialized
INFO - 2020-09-17 07:37:12 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:37:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:37:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:37:12 --> Encryption Class Initialized
INFO - 2020-09-17 07:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:37:13 --> Controller Class Initialized
INFO - 2020-09-17 07:37:13 --> Helper loaded: language_helper
INFO - 2020-09-17 07:37:13 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:37:13 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-17 07:37:13 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 07:37:13 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-17 07:37:13 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 07:37:13 --> Final output sent to browser
DEBUG - 2020-09-17 07:37:13 --> Total execution time: 1.1219
INFO - 2020-09-17 07:37:21 --> Config Class Initialized
INFO - 2020-09-17 07:37:21 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:37:21 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:37:21 --> Utf8 Class Initialized
INFO - 2020-09-17 07:37:21 --> URI Class Initialized
INFO - 2020-09-17 07:37:21 --> Router Class Initialized
INFO - 2020-09-17 07:37:21 --> Output Class Initialized
INFO - 2020-09-17 07:37:21 --> Security Class Initialized
DEBUG - 2020-09-17 07:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:37:21 --> Input Class Initialized
INFO - 2020-09-17 07:37:21 --> Language Class Initialized
INFO - 2020-09-17 07:37:21 --> Loader Class Initialized
INFO - 2020-09-17 07:37:21 --> Helper loaded: html_helper
INFO - 2020-09-17 07:37:21 --> Helper loaded: url_helper
INFO - 2020-09-17 07:37:21 --> Helper loaded: form_helper
INFO - 2020-09-17 07:37:21 --> Database Driver Class Initialized
INFO - 2020-09-17 07:37:21 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:37:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:37:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:37:22 --> Encryption Class Initialized
INFO - 2020-09-17 07:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:37:22 --> Controller Class Initialized
INFO - 2020-09-17 07:37:22 --> Helper loaded: language_helper
INFO - 2020-09-17 07:37:22 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:37:22 --> Model "Sale_model" initialized
ERROR - 2020-09-17 07:37:22 --> Query error: [Microsoft][ODBC Driver 17 for SQL Server][SQL Server]'DATEDIFF_BIG' is not a recognized built-in function name. - Invalid query: SELECT id, full_name, contact_no, dept_email_id, department, designation, address, created_dt, serial_key, installed_dt, status, razorpay_order_id
				FROM tbl_user_info
				WHERE DATEDIFF_BIG(millisecond, created_dt, GETUTCDATE()) BETWEEN 1598898600 AND 1601058540
				LIMIT 50
INFO - 2020-09-17 07:37:22 --> Language file loaded: language/english/db_lang.php
INFO - 2020-09-17 07:37:26 --> Config Class Initialized
INFO - 2020-09-17 07:37:26 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:37:26 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:37:26 --> Utf8 Class Initialized
INFO - 2020-09-17 07:37:26 --> URI Class Initialized
INFO - 2020-09-17 07:37:26 --> Router Class Initialized
INFO - 2020-09-17 07:37:26 --> Output Class Initialized
INFO - 2020-09-17 07:37:26 --> Security Class Initialized
DEBUG - 2020-09-17 07:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:37:26 --> Input Class Initialized
INFO - 2020-09-17 07:37:26 --> Language Class Initialized
INFO - 2020-09-17 07:37:26 --> Loader Class Initialized
INFO - 2020-09-17 07:37:26 --> Helper loaded: html_helper
INFO - 2020-09-17 07:37:26 --> Helper loaded: url_helper
INFO - 2020-09-17 07:37:26 --> Helper loaded: form_helper
INFO - 2020-09-17 07:37:26 --> Database Driver Class Initialized
INFO - 2020-09-17 07:37:26 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:37:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:37:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:37:27 --> Encryption Class Initialized
INFO - 2020-09-17 07:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:37:27 --> Controller Class Initialized
INFO - 2020-09-17 07:37:27 --> Helper loaded: language_helper
INFO - 2020-09-17 07:37:27 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:37:27 --> Model "Sale_model" initialized
ERROR - 2020-09-17 07:37:27 --> Query error: [Microsoft][ODBC Driver 17 for SQL Server][SQL Server]'DATEDIFF_BIG' is not a recognized built-in function name. - Invalid query: SELECT id, full_name, contact_no, dept_email_id, department, designation, address, created_dt, serial_key, installed_dt, status, razorpay_order_id
				FROM tbl_user_info
				WHERE DATEDIFF_BIG(millisecond, created_dt, GETUTCDATE()) BETWEEN 1598898600 AND 1601058540
				LIMIT 50
INFO - 2020-09-17 07:37:27 --> Language file loaded: language/english/db_lang.php
INFO - 2020-09-17 07:39:23 --> Config Class Initialized
INFO - 2020-09-17 07:39:24 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:39:24 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:39:24 --> Utf8 Class Initialized
INFO - 2020-09-17 07:39:24 --> URI Class Initialized
INFO - 2020-09-17 07:39:24 --> Router Class Initialized
INFO - 2020-09-17 07:39:24 --> Output Class Initialized
INFO - 2020-09-17 07:39:24 --> Security Class Initialized
DEBUG - 2020-09-17 07:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:39:24 --> Input Class Initialized
INFO - 2020-09-17 07:39:24 --> Language Class Initialized
INFO - 2020-09-17 07:39:24 --> Loader Class Initialized
INFO - 2020-09-17 07:39:24 --> Helper loaded: html_helper
INFO - 2020-09-17 07:39:24 --> Helper loaded: url_helper
INFO - 2020-09-17 07:39:24 --> Helper loaded: form_helper
INFO - 2020-09-17 07:39:24 --> Database Driver Class Initialized
INFO - 2020-09-17 07:39:24 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:39:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:39:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:39:24 --> Encryption Class Initialized
INFO - 2020-09-17 07:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:39:24 --> Controller Class Initialized
INFO - 2020-09-17 07:39:24 --> Helper loaded: language_helper
INFO - 2020-09-17 07:39:24 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:39:24 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-17 07:39:24 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 07:39:24 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-17 07:39:24 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 07:39:24 --> Final output sent to browser
DEBUG - 2020-09-17 07:39:24 --> Total execution time: 0.9604
INFO - 2020-09-17 07:39:31 --> Config Class Initialized
INFO - 2020-09-17 07:39:31 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:39:31 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:39:31 --> Utf8 Class Initialized
INFO - 2020-09-17 07:39:31 --> URI Class Initialized
INFO - 2020-09-17 07:39:31 --> Router Class Initialized
INFO - 2020-09-17 07:39:31 --> Output Class Initialized
INFO - 2020-09-17 07:39:31 --> Security Class Initialized
DEBUG - 2020-09-17 07:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:39:31 --> Input Class Initialized
INFO - 2020-09-17 07:39:31 --> Language Class Initialized
INFO - 2020-09-17 07:39:31 --> Loader Class Initialized
INFO - 2020-09-17 07:39:31 --> Helper loaded: html_helper
INFO - 2020-09-17 07:39:31 --> Helper loaded: url_helper
INFO - 2020-09-17 07:39:31 --> Helper loaded: form_helper
INFO - 2020-09-17 07:39:31 --> Database Driver Class Initialized
INFO - 2020-09-17 07:39:31 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:39:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:39:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:39:31 --> Encryption Class Initialized
INFO - 2020-09-17 07:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:39:32 --> Controller Class Initialized
INFO - 2020-09-17 07:39:32 --> Helper loaded: language_helper
INFO - 2020-09-17 07:39:32 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:39:32 --> Model "Sale_model" initialized
ERROR - 2020-09-17 07:39:32 --> Query error: [Microsoft][ODBC Driver 17 for SQL Server][SQL Server]Incorrect syntax near 'LIMIT'. - Invalid query: SELECT id, full_name, contact_no, dept_email_id, department, designation, address, created_dt, serial_key, installed_dt, status, razorpay_order_id
				FROM tbl_user_info
				WHERE DATEDIFF(SECOND,created_dt, GETUTCDATE()) BETWEEN 1598898600 AND 1600453740
				LIMIT 50
INFO - 2020-09-17 07:39:32 --> Language file loaded: language/english/db_lang.php
INFO - 2020-09-17 07:39:35 --> Config Class Initialized
INFO - 2020-09-17 07:39:35 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:39:35 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:39:35 --> Utf8 Class Initialized
INFO - 2020-09-17 07:39:35 --> URI Class Initialized
INFO - 2020-09-17 07:39:35 --> Router Class Initialized
INFO - 2020-09-17 07:39:35 --> Output Class Initialized
INFO - 2020-09-17 07:39:35 --> Security Class Initialized
DEBUG - 2020-09-17 07:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:39:35 --> Input Class Initialized
INFO - 2020-09-17 07:39:35 --> Language Class Initialized
INFO - 2020-09-17 07:39:35 --> Loader Class Initialized
INFO - 2020-09-17 07:39:35 --> Helper loaded: html_helper
INFO - 2020-09-17 07:39:35 --> Helper loaded: url_helper
INFO - 2020-09-17 07:39:35 --> Helper loaded: form_helper
INFO - 2020-09-17 07:39:35 --> Database Driver Class Initialized
INFO - 2020-09-17 07:39:35 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:39:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:39:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:39:36 --> Encryption Class Initialized
INFO - 2020-09-17 07:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:39:36 --> Controller Class Initialized
INFO - 2020-09-17 07:39:36 --> Helper loaded: language_helper
INFO - 2020-09-17 07:39:36 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:39:36 --> Model "Sale_model" initialized
ERROR - 2020-09-17 07:39:36 --> Query error: [Microsoft][ODBC Driver 17 for SQL Server][SQL Server]Incorrect syntax near 'LIMIT'. - Invalid query: SELECT id, full_name, contact_no, dept_email_id, department, designation, address, created_dt, serial_key, installed_dt, status, razorpay_order_id
				FROM tbl_user_info
				WHERE DATEDIFF(SECOND,created_dt, GETUTCDATE()) BETWEEN 1598898600 AND 1600453740
				LIMIT 50
INFO - 2020-09-17 07:39:36 --> Language file loaded: language/english/db_lang.php
INFO - 2020-09-17 07:40:35 --> Config Class Initialized
INFO - 2020-09-17 07:40:35 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:40:35 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:40:35 --> Utf8 Class Initialized
INFO - 2020-09-17 07:40:35 --> URI Class Initialized
INFO - 2020-09-17 07:40:35 --> Router Class Initialized
INFO - 2020-09-17 07:40:35 --> Output Class Initialized
INFO - 2020-09-17 07:40:35 --> Security Class Initialized
DEBUG - 2020-09-17 07:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:40:35 --> Input Class Initialized
INFO - 2020-09-17 07:40:35 --> Language Class Initialized
INFO - 2020-09-17 07:40:35 --> Loader Class Initialized
INFO - 2020-09-17 07:40:35 --> Helper loaded: html_helper
INFO - 2020-09-17 07:40:35 --> Helper loaded: url_helper
INFO - 2020-09-17 07:40:35 --> Helper loaded: form_helper
INFO - 2020-09-17 07:40:35 --> Database Driver Class Initialized
INFO - 2020-09-17 07:40:35 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:40:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:40:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:40:35 --> Encryption Class Initialized
INFO - 2020-09-17 07:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:40:35 --> Controller Class Initialized
INFO - 2020-09-17 07:40:35 --> Helper loaded: language_helper
INFO - 2020-09-17 07:40:35 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:40:35 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-17 07:40:35 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 07:40:35 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-17 07:40:35 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 07:40:35 --> Final output sent to browser
DEBUG - 2020-09-17 07:40:36 --> Total execution time: 0.9891
INFO - 2020-09-17 07:40:42 --> Config Class Initialized
INFO - 2020-09-17 07:40:42 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:40:42 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:40:42 --> Utf8 Class Initialized
INFO - 2020-09-17 07:40:42 --> URI Class Initialized
INFO - 2020-09-17 07:40:42 --> Router Class Initialized
INFO - 2020-09-17 07:40:42 --> Output Class Initialized
INFO - 2020-09-17 07:40:42 --> Security Class Initialized
DEBUG - 2020-09-17 07:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:40:42 --> Input Class Initialized
INFO - 2020-09-17 07:40:42 --> Language Class Initialized
INFO - 2020-09-17 07:40:42 --> Loader Class Initialized
INFO - 2020-09-17 07:40:42 --> Helper loaded: html_helper
INFO - 2020-09-17 07:40:42 --> Helper loaded: url_helper
INFO - 2020-09-17 07:40:42 --> Helper loaded: form_helper
INFO - 2020-09-17 07:40:42 --> Database Driver Class Initialized
INFO - 2020-09-17 07:40:42 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:40:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:40:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:40:42 --> Encryption Class Initialized
INFO - 2020-09-17 07:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:40:42 --> Controller Class Initialized
INFO - 2020-09-17 07:40:42 --> Helper loaded: language_helper
INFO - 2020-09-17 07:40:42 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:40:42 --> Model "Sale_model" initialized
INFO - 2020-09-17 07:40:42 --> Final output sent to browser
DEBUG - 2020-09-17 07:40:42 --> Total execution time: 0.9501
INFO - 2020-09-17 07:40:52 --> Config Class Initialized
INFO - 2020-09-17 07:40:52 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:40:52 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:40:52 --> Utf8 Class Initialized
INFO - 2020-09-17 07:40:52 --> URI Class Initialized
INFO - 2020-09-17 07:40:52 --> Router Class Initialized
INFO - 2020-09-17 07:40:52 --> Output Class Initialized
INFO - 2020-09-17 07:40:52 --> Security Class Initialized
DEBUG - 2020-09-17 07:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:40:52 --> Input Class Initialized
INFO - 2020-09-17 07:40:52 --> Language Class Initialized
INFO - 2020-09-17 07:40:52 --> Loader Class Initialized
INFO - 2020-09-17 07:40:52 --> Helper loaded: html_helper
INFO - 2020-09-17 07:40:52 --> Helper loaded: url_helper
INFO - 2020-09-17 07:40:52 --> Helper loaded: form_helper
INFO - 2020-09-17 07:40:52 --> Database Driver Class Initialized
INFO - 2020-09-17 07:40:52 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:40:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:40:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:40:52 --> Encryption Class Initialized
INFO - 2020-09-17 07:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:40:52 --> Controller Class Initialized
INFO - 2020-09-17 07:40:52 --> Helper loaded: language_helper
INFO - 2020-09-17 07:40:52 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:40:52 --> Model "Sale_model" initialized
INFO - 2020-09-17 07:40:52 --> Final output sent to browser
DEBUG - 2020-09-17 07:40:52 --> Total execution time: 0.9161
INFO - 2020-09-17 07:40:57 --> Config Class Initialized
INFO - 2020-09-17 07:40:57 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:40:57 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:40:57 --> Utf8 Class Initialized
INFO - 2020-09-17 07:40:57 --> URI Class Initialized
INFO - 2020-09-17 07:40:57 --> Router Class Initialized
INFO - 2020-09-17 07:40:57 --> Output Class Initialized
INFO - 2020-09-17 07:40:57 --> Security Class Initialized
DEBUG - 2020-09-17 07:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:40:57 --> Input Class Initialized
INFO - 2020-09-17 07:40:57 --> Language Class Initialized
INFO - 2020-09-17 07:40:57 --> Loader Class Initialized
INFO - 2020-09-17 07:40:57 --> Helper loaded: html_helper
INFO - 2020-09-17 07:40:57 --> Helper loaded: url_helper
INFO - 2020-09-17 07:40:57 --> Helper loaded: form_helper
INFO - 2020-09-17 07:40:57 --> Database Driver Class Initialized
INFO - 2020-09-17 07:40:57 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:40:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:40:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:40:58 --> Encryption Class Initialized
INFO - 2020-09-17 07:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:40:58 --> Controller Class Initialized
INFO - 2020-09-17 07:40:58 --> Helper loaded: language_helper
INFO - 2020-09-17 07:40:58 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:40:58 --> Model "Sale_model" initialized
INFO - 2020-09-17 07:40:58 --> Final output sent to browser
DEBUG - 2020-09-17 07:40:58 --> Total execution time: 0.9075
INFO - 2020-09-17 07:52:24 --> Config Class Initialized
INFO - 2020-09-17 07:52:25 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:52:25 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:52:25 --> Utf8 Class Initialized
INFO - 2020-09-17 07:52:25 --> URI Class Initialized
INFO - 2020-09-17 07:52:25 --> Router Class Initialized
INFO - 2020-09-17 07:52:25 --> Output Class Initialized
INFO - 2020-09-17 07:52:25 --> Security Class Initialized
DEBUG - 2020-09-17 07:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:52:25 --> Input Class Initialized
INFO - 2020-09-17 07:52:25 --> Language Class Initialized
INFO - 2020-09-17 07:52:25 --> Loader Class Initialized
INFO - 2020-09-17 07:52:25 --> Helper loaded: html_helper
INFO - 2020-09-17 07:52:25 --> Helper loaded: url_helper
INFO - 2020-09-17 07:52:25 --> Helper loaded: form_helper
INFO - 2020-09-17 07:52:25 --> Database Driver Class Initialized
INFO - 2020-09-17 07:52:25 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:52:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:52:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:52:25 --> Encryption Class Initialized
INFO - 2020-09-17 07:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:52:25 --> Controller Class Initialized
INFO - 2020-09-17 07:52:25 --> Helper loaded: language_helper
INFO - 2020-09-17 07:52:25 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:52:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-17 07:52:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 07:52:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-17 07:52:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 07:52:25 --> Final output sent to browser
DEBUG - 2020-09-17 07:52:26 --> Total execution time: 1.0121
INFO - 2020-09-17 07:52:26 --> Config Class Initialized
INFO - 2020-09-17 07:52:26 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:52:26 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:52:26 --> Utf8 Class Initialized
INFO - 2020-09-17 07:52:26 --> URI Class Initialized
INFO - 2020-09-17 07:52:26 --> Router Class Initialized
INFO - 2020-09-17 07:52:26 --> Output Class Initialized
INFO - 2020-09-17 07:52:26 --> Security Class Initialized
DEBUG - 2020-09-17 07:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:52:27 --> Input Class Initialized
INFO - 2020-09-17 07:52:27 --> Language Class Initialized
INFO - 2020-09-17 07:52:27 --> Loader Class Initialized
INFO - 2020-09-17 07:52:27 --> Helper loaded: html_helper
INFO - 2020-09-17 07:52:27 --> Helper loaded: url_helper
INFO - 2020-09-17 07:52:27 --> Helper loaded: form_helper
INFO - 2020-09-17 07:52:27 --> Database Driver Class Initialized
INFO - 2020-09-17 07:52:27 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:52:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:52:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:52:27 --> Encryption Class Initialized
INFO - 2020-09-17 07:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:52:27 --> Controller Class Initialized
INFO - 2020-09-17 07:52:27 --> Helper loaded: language_helper
INFO - 2020-09-17 07:52:27 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:52:27 --> Model "Sale_model" initialized
INFO - 2020-09-17 07:52:27 --> Final output sent to browser
DEBUG - 2020-09-17 07:52:27 --> Total execution time: 0.9516
INFO - 2020-09-17 07:52:33 --> Config Class Initialized
INFO - 2020-09-17 07:52:33 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:52:33 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:52:33 --> Utf8 Class Initialized
INFO - 2020-09-17 07:52:33 --> URI Class Initialized
INFO - 2020-09-17 07:52:34 --> Router Class Initialized
INFO - 2020-09-17 07:52:34 --> Output Class Initialized
INFO - 2020-09-17 07:52:34 --> Security Class Initialized
DEBUG - 2020-09-17 07:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:52:34 --> Input Class Initialized
INFO - 2020-09-17 07:52:34 --> Language Class Initialized
INFO - 2020-09-17 07:52:34 --> Loader Class Initialized
INFO - 2020-09-17 07:52:34 --> Helper loaded: html_helper
INFO - 2020-09-17 07:52:34 --> Helper loaded: url_helper
INFO - 2020-09-17 07:52:34 --> Helper loaded: form_helper
INFO - 2020-09-17 07:52:34 --> Database Driver Class Initialized
INFO - 2020-09-17 07:52:34 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:52:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:52:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:52:34 --> Encryption Class Initialized
INFO - 2020-09-17 07:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:52:34 --> Controller Class Initialized
INFO - 2020-09-17 07:52:34 --> Helper loaded: language_helper
INFO - 2020-09-17 07:52:34 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:52:34 --> Model "Sale_model" initialized
ERROR - 2020-09-17 07:52:34 --> Query error: [Microsoft][ODBC Driver 17 for SQL Server][SQL Server]Incorrect syntax near '12'. - Invalid query: SELECT TOP 50 id, full_name, contact_no, dept_email_id, department, designation, address, created_dt, serial_key, installed_dt, status, razorpay_order_id
				FROM tbl_user_info
				WHERE DATEDIFF(SECOND,created_dt, GETUTCDATE()) BETWEEN 2020-09-01 12:00 AM AND 2020-09-18 11:59 PM
INFO - 2020-09-17 07:52:34 --> Language file loaded: language/english/db_lang.php
INFO - 2020-09-17 07:52:40 --> Config Class Initialized
INFO - 2020-09-17 07:52:40 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:52:40 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:52:40 --> Utf8 Class Initialized
INFO - 2020-09-17 07:52:40 --> URI Class Initialized
INFO - 2020-09-17 07:52:40 --> Router Class Initialized
INFO - 2020-09-17 07:52:40 --> Output Class Initialized
INFO - 2020-09-17 07:52:40 --> Security Class Initialized
DEBUG - 2020-09-17 07:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:52:40 --> Input Class Initialized
INFO - 2020-09-17 07:52:40 --> Language Class Initialized
INFO - 2020-09-17 07:52:40 --> Loader Class Initialized
INFO - 2020-09-17 07:52:40 --> Helper loaded: html_helper
INFO - 2020-09-17 07:52:40 --> Helper loaded: url_helper
INFO - 2020-09-17 07:52:40 --> Helper loaded: form_helper
INFO - 2020-09-17 07:52:40 --> Database Driver Class Initialized
INFO - 2020-09-17 07:52:40 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:52:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:52:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:52:41 --> Encryption Class Initialized
INFO - 2020-09-17 07:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:52:41 --> Controller Class Initialized
INFO - 2020-09-17 07:52:41 --> Helper loaded: language_helper
INFO - 2020-09-17 07:52:41 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:52:41 --> Model "Sale_model" initialized
ERROR - 2020-09-17 07:52:41 --> Query error: [Microsoft][ODBC Driver 17 for SQL Server][SQL Server]Incorrect syntax near '12'. - Invalid query: SELECT TOP 50 id, full_name, contact_no, dept_email_id, department, designation, address, created_dt, serial_key, installed_dt, status, razorpay_order_id
				FROM tbl_user_info
				WHERE DATEDIFF(SECOND,created_dt, GETUTCDATE()) BETWEEN 2020-09-01 12:00 AM AND 2020-09-18 11:59 PM
INFO - 2020-09-17 07:52:41 --> Language file loaded: language/english/db_lang.php
INFO - 2020-09-17 07:53:40 --> Config Class Initialized
INFO - 2020-09-17 07:53:40 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:53:40 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:53:40 --> Utf8 Class Initialized
INFO - 2020-09-17 07:53:40 --> URI Class Initialized
INFO - 2020-09-17 07:53:40 --> Router Class Initialized
INFO - 2020-09-17 07:53:40 --> Output Class Initialized
INFO - 2020-09-17 07:53:40 --> Security Class Initialized
DEBUG - 2020-09-17 07:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:53:40 --> Input Class Initialized
INFO - 2020-09-17 07:53:40 --> Language Class Initialized
INFO - 2020-09-17 07:53:40 --> Loader Class Initialized
INFO - 2020-09-17 07:53:40 --> Helper loaded: html_helper
INFO - 2020-09-17 07:53:40 --> Helper loaded: url_helper
INFO - 2020-09-17 07:53:40 --> Helper loaded: form_helper
INFO - 2020-09-17 07:53:40 --> Database Driver Class Initialized
INFO - 2020-09-17 07:53:40 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:53:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:53:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:53:40 --> Encryption Class Initialized
INFO - 2020-09-17 07:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:53:40 --> Controller Class Initialized
INFO - 2020-09-17 07:53:41 --> Helper loaded: language_helper
INFO - 2020-09-17 07:53:41 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:53:41 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-17 07:53:41 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 07:53:41 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-17 07:53:41 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 07:53:41 --> Final output sent to browser
DEBUG - 2020-09-17 07:53:41 --> Total execution time: 0.9650
INFO - 2020-09-17 07:53:47 --> Config Class Initialized
INFO - 2020-09-17 07:53:47 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:53:47 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:53:47 --> Utf8 Class Initialized
INFO - 2020-09-17 07:53:47 --> URI Class Initialized
INFO - 2020-09-17 07:53:47 --> Router Class Initialized
INFO - 2020-09-17 07:53:47 --> Output Class Initialized
INFO - 2020-09-17 07:53:47 --> Security Class Initialized
DEBUG - 2020-09-17 07:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:53:47 --> Input Class Initialized
INFO - 2020-09-17 07:53:47 --> Language Class Initialized
INFO - 2020-09-17 07:53:47 --> Loader Class Initialized
INFO - 2020-09-17 07:53:47 --> Helper loaded: html_helper
INFO - 2020-09-17 07:53:47 --> Helper loaded: url_helper
INFO - 2020-09-17 07:53:48 --> Helper loaded: form_helper
INFO - 2020-09-17 07:53:48 --> Database Driver Class Initialized
INFO - 2020-09-17 07:53:48 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:53:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:53:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:53:48 --> Encryption Class Initialized
INFO - 2020-09-17 07:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:53:48 --> Controller Class Initialized
INFO - 2020-09-17 07:53:48 --> Helper loaded: language_helper
INFO - 2020-09-17 07:53:48 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:53:48 --> Model "Sale_model" initialized
ERROR - 2020-09-17 07:53:48 --> Query error: [Microsoft][ODBC Driver 17 for SQL Server][SQL Server]Conversion failed when converting the varchar value '2020-09-01 12:00 AM' to data type int. - Invalid query: SELECT TOP 50 id, full_name, contact_no, dept_email_id, department, designation, address, created_dt, serial_key, installed_dt, status, razorpay_order_id
				FROM tbl_user_info
				WHERE DATEDIFF(SECOND,created_dt, GETUTCDATE()) BETWEEN '2020-09-01 12:00 AM' AND '2020-09-18 11:59 PM'
INFO - 2020-09-17 07:53:48 --> Language file loaded: language/english/db_lang.php
INFO - 2020-09-17 07:53:52 --> Config Class Initialized
INFO - 2020-09-17 07:53:52 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:53:52 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:53:52 --> Utf8 Class Initialized
INFO - 2020-09-17 07:53:53 --> URI Class Initialized
INFO - 2020-09-17 07:53:53 --> Router Class Initialized
INFO - 2020-09-17 07:53:53 --> Output Class Initialized
INFO - 2020-09-17 07:53:53 --> Security Class Initialized
DEBUG - 2020-09-17 07:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:53:53 --> Input Class Initialized
INFO - 2020-09-17 07:53:53 --> Language Class Initialized
INFO - 2020-09-17 07:53:53 --> Loader Class Initialized
INFO - 2020-09-17 07:53:53 --> Helper loaded: html_helper
INFO - 2020-09-17 07:53:53 --> Helper loaded: url_helper
INFO - 2020-09-17 07:53:53 --> Helper loaded: form_helper
INFO - 2020-09-17 07:53:53 --> Database Driver Class Initialized
INFO - 2020-09-17 07:53:53 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:53:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:53:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:53:53 --> Encryption Class Initialized
INFO - 2020-09-17 07:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:53:53 --> Controller Class Initialized
INFO - 2020-09-17 07:53:53 --> Helper loaded: language_helper
INFO - 2020-09-17 07:53:53 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:53:53 --> Model "Sale_model" initialized
ERROR - 2020-09-17 07:53:53 --> Query error: [Microsoft][ODBC Driver 17 for SQL Server][SQL Server]Conversion failed when converting the varchar value '2020-09-01 12:00 AM' to data type int. - Invalid query: SELECT TOP 50 id, full_name, contact_no, dept_email_id, department, designation, address, created_dt, serial_key, installed_dt, status, razorpay_order_id
				FROM tbl_user_info
				WHERE DATEDIFF(SECOND,created_dt, GETUTCDATE()) BETWEEN '2020-09-01 12:00 AM' AND '2020-09-18 11:59 PM'
INFO - 2020-09-17 07:53:53 --> Language file loaded: language/english/db_lang.php
INFO - 2020-09-17 07:54:37 --> Config Class Initialized
INFO - 2020-09-17 07:54:37 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:54:37 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:54:37 --> Utf8 Class Initialized
INFO - 2020-09-17 07:54:37 --> URI Class Initialized
INFO - 2020-09-17 07:54:37 --> Router Class Initialized
INFO - 2020-09-17 07:54:37 --> Output Class Initialized
INFO - 2020-09-17 07:54:37 --> Security Class Initialized
DEBUG - 2020-09-17 07:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:54:37 --> Input Class Initialized
INFO - 2020-09-17 07:54:37 --> Language Class Initialized
INFO - 2020-09-17 07:54:37 --> Loader Class Initialized
INFO - 2020-09-17 07:54:37 --> Helper loaded: html_helper
INFO - 2020-09-17 07:54:38 --> Helper loaded: url_helper
INFO - 2020-09-17 07:54:38 --> Helper loaded: form_helper
INFO - 2020-09-17 07:54:38 --> Database Driver Class Initialized
INFO - 2020-09-17 07:54:38 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:54:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:54:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:54:38 --> Encryption Class Initialized
INFO - 2020-09-17 07:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:54:38 --> Controller Class Initialized
INFO - 2020-09-17 07:54:38 --> Helper loaded: language_helper
INFO - 2020-09-17 07:54:38 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:54:38 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-17 07:54:38 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 07:54:38 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-17 07:54:38 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 07:54:38 --> Final output sent to browser
DEBUG - 2020-09-17 07:54:38 --> Total execution time: 0.9271
INFO - 2020-09-17 07:54:45 --> Config Class Initialized
INFO - 2020-09-17 07:54:45 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:54:45 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:54:45 --> Utf8 Class Initialized
INFO - 2020-09-17 07:54:45 --> URI Class Initialized
INFO - 2020-09-17 07:54:45 --> Router Class Initialized
INFO - 2020-09-17 07:54:45 --> Output Class Initialized
INFO - 2020-09-17 07:54:45 --> Security Class Initialized
DEBUG - 2020-09-17 07:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:54:45 --> Input Class Initialized
INFO - 2020-09-17 07:54:45 --> Language Class Initialized
INFO - 2020-09-17 07:54:45 --> Loader Class Initialized
INFO - 2020-09-17 07:54:45 --> Helper loaded: html_helper
INFO - 2020-09-17 07:54:45 --> Helper loaded: url_helper
INFO - 2020-09-17 07:54:45 --> Helper loaded: form_helper
INFO - 2020-09-17 07:54:45 --> Database Driver Class Initialized
INFO - 2020-09-17 07:54:45 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:54:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:54:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:54:45 --> Encryption Class Initialized
INFO - 2020-09-17 07:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:54:45 --> Controller Class Initialized
INFO - 2020-09-17 07:54:45 --> Helper loaded: language_helper
INFO - 2020-09-17 07:54:45 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:54:45 --> Model "Sale_model" initialized
INFO - 2020-09-17 07:54:45 --> Final output sent to browser
DEBUG - 2020-09-17 07:54:46 --> Total execution time: 0.9425
INFO - 2020-09-17 07:55:00 --> Config Class Initialized
INFO - 2020-09-17 07:55:00 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:55:00 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:55:00 --> Utf8 Class Initialized
INFO - 2020-09-17 07:55:01 --> URI Class Initialized
INFO - 2020-09-17 07:55:01 --> Router Class Initialized
INFO - 2020-09-17 07:55:01 --> Output Class Initialized
INFO - 2020-09-17 07:55:01 --> Security Class Initialized
DEBUG - 2020-09-17 07:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:55:01 --> Input Class Initialized
INFO - 2020-09-17 07:55:01 --> Language Class Initialized
INFO - 2020-09-17 07:55:01 --> Loader Class Initialized
INFO - 2020-09-17 07:55:01 --> Helper loaded: html_helper
INFO - 2020-09-17 07:55:01 --> Helper loaded: url_helper
INFO - 2020-09-17 07:55:01 --> Helper loaded: form_helper
INFO - 2020-09-17 07:55:01 --> Database Driver Class Initialized
INFO - 2020-09-17 07:55:01 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:55:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:55:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:55:01 --> Encryption Class Initialized
INFO - 2020-09-17 07:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:55:01 --> Controller Class Initialized
INFO - 2020-09-17 07:55:01 --> Helper loaded: language_helper
INFO - 2020-09-17 07:55:01 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:55:01 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-17 07:55:01 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 07:55:01 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment.php
INFO - 2020-09-17 07:55:01 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 07:55:01 --> Final output sent to browser
DEBUG - 2020-09-17 07:55:01 --> Total execution time: 0.9668
INFO - 2020-09-17 07:55:02 --> Config Class Initialized
INFO - 2020-09-17 07:55:02 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:55:02 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:55:02 --> Utf8 Class Initialized
INFO - 2020-09-17 07:55:02 --> URI Class Initialized
INFO - 2020-09-17 07:55:02 --> Router Class Initialized
INFO - 2020-09-17 07:55:03 --> Output Class Initialized
INFO - 2020-09-17 07:55:03 --> Security Class Initialized
DEBUG - 2020-09-17 07:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:55:03 --> Input Class Initialized
INFO - 2020-09-17 07:55:03 --> Language Class Initialized
INFO - 2020-09-17 07:55:03 --> Loader Class Initialized
INFO - 2020-09-17 07:55:03 --> Helper loaded: html_helper
INFO - 2020-09-17 07:55:03 --> Helper loaded: url_helper
INFO - 2020-09-17 07:55:03 --> Helper loaded: form_helper
INFO - 2020-09-17 07:55:03 --> Database Driver Class Initialized
INFO - 2020-09-17 07:55:03 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:55:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:55:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:55:03 --> Encryption Class Initialized
INFO - 2020-09-17 07:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:55:03 --> Controller Class Initialized
INFO - 2020-09-17 07:55:03 --> Helper loaded: language_helper
INFO - 2020-09-17 07:55:03 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 07:55:04 --> Final output sent to browser
DEBUG - 2020-09-17 07:55:04 --> Total execution time: 2.1132
INFO - 2020-09-17 07:55:11 --> Config Class Initialized
INFO - 2020-09-17 07:55:11 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:55:11 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:55:11 --> Utf8 Class Initialized
INFO - 2020-09-17 07:55:12 --> URI Class Initialized
INFO - 2020-09-17 07:55:12 --> Router Class Initialized
INFO - 2020-09-17 07:55:12 --> Output Class Initialized
INFO - 2020-09-17 07:55:12 --> Security Class Initialized
DEBUG - 2020-09-17 07:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:55:12 --> Input Class Initialized
INFO - 2020-09-17 07:55:12 --> Language Class Initialized
INFO - 2020-09-17 07:55:12 --> Loader Class Initialized
INFO - 2020-09-17 07:55:12 --> Helper loaded: html_helper
INFO - 2020-09-17 07:55:12 --> Helper loaded: url_helper
INFO - 2020-09-17 07:55:12 --> Helper loaded: form_helper
INFO - 2020-09-17 07:55:12 --> Database Driver Class Initialized
INFO - 2020-09-17 07:55:12 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:55:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:55:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:55:12 --> Encryption Class Initialized
INFO - 2020-09-17 07:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:55:12 --> Controller Class Initialized
INFO - 2020-09-17 07:55:12 --> Helper loaded: language_helper
INFO - 2020-09-17 07:55:12 --> Language file loaded: language/english/content_lang.php
ERROR - 2020-09-17 07:55:12 --> Severity: Notice --> Undefined index: order_id C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\controllers\Payment.php 184
INFO - 2020-09-17 07:55:14 --> Final output sent to browser
DEBUG - 2020-09-17 07:55:14 --> Total execution time: 2.7910
INFO - 2020-09-17 07:55:34 --> Config Class Initialized
INFO - 2020-09-17 07:55:35 --> Hooks Class Initialized
DEBUG - 2020-09-17 07:55:35 --> UTF-8 Support Enabled
INFO - 2020-09-17 07:55:35 --> Utf8 Class Initialized
INFO - 2020-09-17 07:55:35 --> URI Class Initialized
INFO - 2020-09-17 07:55:35 --> Router Class Initialized
INFO - 2020-09-17 07:55:35 --> Output Class Initialized
INFO - 2020-09-17 07:55:35 --> Security Class Initialized
DEBUG - 2020-09-17 07:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 07:55:35 --> Input Class Initialized
INFO - 2020-09-17 07:55:35 --> Language Class Initialized
INFO - 2020-09-17 07:55:35 --> Loader Class Initialized
INFO - 2020-09-17 07:55:35 --> Helper loaded: html_helper
INFO - 2020-09-17 07:55:35 --> Helper loaded: url_helper
INFO - 2020-09-17 07:55:35 --> Helper loaded: form_helper
INFO - 2020-09-17 07:55:35 --> Database Driver Class Initialized
INFO - 2020-09-17 07:55:35 --> Form Validation Class Initialized
DEBUG - 2020-09-17 07:55:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 07:55:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 07:55:35 --> Encryption Class Initialized
INFO - 2020-09-17 07:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 07:55:35 --> Controller Class Initialized
INFO - 2020-09-17 07:55:35 --> Helper loaded: language_helper
INFO - 2020-09-17 07:55:35 --> Language file loaded: language/english/content_lang.php
ERROR - 2020-09-17 07:55:36 --> Severity: Notice --> Undefined index: order_id C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\controllers\Payment.php 184
INFO - 2020-09-17 07:55:37 --> Final output sent to browser
DEBUG - 2020-09-17 07:55:37 --> Total execution time: 2.9206
INFO - 2020-09-17 08:01:46 --> Config Class Initialized
INFO - 2020-09-17 08:01:46 --> Hooks Class Initialized
DEBUG - 2020-09-17 08:01:47 --> UTF-8 Support Enabled
INFO - 2020-09-17 08:01:47 --> Utf8 Class Initialized
INFO - 2020-09-17 08:01:47 --> URI Class Initialized
INFO - 2020-09-17 08:01:47 --> Router Class Initialized
INFO - 2020-09-17 08:01:47 --> Output Class Initialized
INFO - 2020-09-17 08:01:47 --> Security Class Initialized
DEBUG - 2020-09-17 08:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 08:01:47 --> Input Class Initialized
INFO - 2020-09-17 08:01:47 --> Language Class Initialized
INFO - 2020-09-17 08:01:47 --> Loader Class Initialized
INFO - 2020-09-17 08:01:47 --> Helper loaded: html_helper
INFO - 2020-09-17 08:01:47 --> Helper loaded: url_helper
INFO - 2020-09-17 08:01:47 --> Helper loaded: form_helper
INFO - 2020-09-17 08:01:47 --> Database Driver Class Initialized
INFO - 2020-09-17 08:01:47 --> Form Validation Class Initialized
DEBUG - 2020-09-17 08:01:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 08:01:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 08:01:47 --> Encryption Class Initialized
INFO - 2020-09-17 08:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 08:01:47 --> Controller Class Initialized
INFO - 2020-09-17 08:01:47 --> Helper loaded: language_helper
INFO - 2020-09-17 08:01:47 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 08:01:50 --> Final output sent to browser
DEBUG - 2020-09-17 08:01:50 --> Total execution time: 3.6309
INFO - 2020-09-17 08:02:04 --> Config Class Initialized
INFO - 2020-09-17 08:02:04 --> Hooks Class Initialized
DEBUG - 2020-09-17 08:02:04 --> UTF-8 Support Enabled
INFO - 2020-09-17 08:02:04 --> Utf8 Class Initialized
INFO - 2020-09-17 08:02:04 --> URI Class Initialized
INFO - 2020-09-17 08:02:04 --> Router Class Initialized
INFO - 2020-09-17 08:02:04 --> Output Class Initialized
INFO - 2020-09-17 08:02:04 --> Security Class Initialized
DEBUG - 2020-09-17 08:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 08:02:04 --> Input Class Initialized
INFO - 2020-09-17 08:02:04 --> Language Class Initialized
INFO - 2020-09-17 08:02:04 --> Loader Class Initialized
INFO - 2020-09-17 08:02:04 --> Helper loaded: html_helper
INFO - 2020-09-17 08:02:04 --> Helper loaded: url_helper
INFO - 2020-09-17 08:02:04 --> Helper loaded: form_helper
INFO - 2020-09-17 08:02:04 --> Database Driver Class Initialized
INFO - 2020-09-17 08:02:05 --> Form Validation Class Initialized
DEBUG - 2020-09-17 08:02:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 08:02:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 08:02:05 --> Encryption Class Initialized
INFO - 2020-09-17 08:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 08:02:05 --> Controller Class Initialized
INFO - 2020-09-17 08:02:05 --> Helper loaded: language_helper
INFO - 2020-09-17 08:02:05 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 08:02:07 --> Final output sent to browser
DEBUG - 2020-09-17 08:02:07 --> Total execution time: 3.7075
INFO - 2020-09-17 08:07:18 --> Config Class Initialized
INFO - 2020-09-17 08:07:18 --> Hooks Class Initialized
DEBUG - 2020-09-17 08:07:18 --> UTF-8 Support Enabled
INFO - 2020-09-17 08:07:18 --> Utf8 Class Initialized
INFO - 2020-09-17 08:07:18 --> URI Class Initialized
INFO - 2020-09-17 08:07:18 --> Router Class Initialized
INFO - 2020-09-17 08:07:18 --> Output Class Initialized
INFO - 2020-09-17 08:07:18 --> Security Class Initialized
DEBUG - 2020-09-17 08:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 08:07:18 --> Input Class Initialized
INFO - 2020-09-17 08:07:18 --> Language Class Initialized
INFO - 2020-09-17 08:07:18 --> Loader Class Initialized
INFO - 2020-09-17 08:07:18 --> Helper loaded: html_helper
INFO - 2020-09-17 08:07:18 --> Helper loaded: url_helper
INFO - 2020-09-17 08:07:18 --> Helper loaded: form_helper
INFO - 2020-09-17 08:07:18 --> Database Driver Class Initialized
INFO - 2020-09-17 08:07:18 --> Form Validation Class Initialized
DEBUG - 2020-09-17 08:07:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 08:07:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 08:07:18 --> Encryption Class Initialized
INFO - 2020-09-17 08:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 08:07:19 --> Controller Class Initialized
INFO - 2020-09-17 08:07:19 --> Helper loaded: language_helper
INFO - 2020-09-17 08:07:19 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 08:07:19 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-17 08:07:19 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 08:07:19 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-17 08:07:19 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 08:07:19 --> Final output sent to browser
DEBUG - 2020-09-17 08:07:19 --> Total execution time: 1.0170
INFO - 2020-09-17 08:07:21 --> Config Class Initialized
INFO - 2020-09-17 08:07:21 --> Hooks Class Initialized
DEBUG - 2020-09-17 08:07:21 --> UTF-8 Support Enabled
INFO - 2020-09-17 08:07:21 --> Utf8 Class Initialized
INFO - 2020-09-17 08:07:21 --> URI Class Initialized
INFO - 2020-09-17 08:07:21 --> Router Class Initialized
INFO - 2020-09-17 08:07:21 --> Output Class Initialized
INFO - 2020-09-17 08:07:21 --> Security Class Initialized
DEBUG - 2020-09-17 08:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 08:07:22 --> Input Class Initialized
INFO - 2020-09-17 08:07:22 --> Language Class Initialized
INFO - 2020-09-17 08:07:22 --> Loader Class Initialized
INFO - 2020-09-17 08:07:22 --> Helper loaded: html_helper
INFO - 2020-09-17 08:07:22 --> Helper loaded: url_helper
INFO - 2020-09-17 08:07:22 --> Helper loaded: form_helper
INFO - 2020-09-17 08:07:22 --> Database Driver Class Initialized
INFO - 2020-09-17 08:07:22 --> Form Validation Class Initialized
DEBUG - 2020-09-17 08:07:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 08:07:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 08:07:22 --> Encryption Class Initialized
INFO - 2020-09-17 08:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 08:07:23 --> Controller Class Initialized
INFO - 2020-09-17 08:07:23 --> Helper loaded: language_helper
INFO - 2020-09-17 08:07:23 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 08:07:23 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-17 08:07:23 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 08:07:23 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-17 08:07:23 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 08:07:23 --> Final output sent to browser
DEBUG - 2020-09-17 08:07:23 --> Total execution time: 2.0232
INFO - 2020-09-17 08:07:29 --> Config Class Initialized
INFO - 2020-09-17 08:07:29 --> Hooks Class Initialized
DEBUG - 2020-09-17 08:07:29 --> UTF-8 Support Enabled
INFO - 2020-09-17 08:07:29 --> Utf8 Class Initialized
INFO - 2020-09-17 08:07:29 --> URI Class Initialized
INFO - 2020-09-17 08:07:29 --> Router Class Initialized
INFO - 2020-09-17 08:07:29 --> Output Class Initialized
INFO - 2020-09-17 08:07:30 --> Security Class Initialized
DEBUG - 2020-09-17 08:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 08:07:30 --> Input Class Initialized
INFO - 2020-09-17 08:07:30 --> Language Class Initialized
INFO - 2020-09-17 08:07:30 --> Loader Class Initialized
INFO - 2020-09-17 08:07:30 --> Helper loaded: html_helper
INFO - 2020-09-17 08:07:30 --> Helper loaded: url_helper
INFO - 2020-09-17 08:07:30 --> Helper loaded: form_helper
INFO - 2020-09-17 08:07:30 --> Database Driver Class Initialized
INFO - 2020-09-17 08:07:30 --> Form Validation Class Initialized
DEBUG - 2020-09-17 08:07:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 08:07:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 08:07:30 --> Encryption Class Initialized
INFO - 2020-09-17 08:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 08:07:30 --> Controller Class Initialized
INFO - 2020-09-17 08:07:30 --> Helper loaded: language_helper
INFO - 2020-09-17 08:07:30 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 08:07:30 --> Model "Sale_model" initialized
INFO - 2020-09-17 08:07:30 --> Final output sent to browser
DEBUG - 2020-09-17 08:07:30 --> Total execution time: 1.0865
INFO - 2020-09-17 08:07:33 --> Config Class Initialized
INFO - 2020-09-17 08:07:33 --> Hooks Class Initialized
DEBUG - 2020-09-17 08:07:33 --> UTF-8 Support Enabled
INFO - 2020-09-17 08:07:33 --> Utf8 Class Initialized
INFO - 2020-09-17 08:07:33 --> URI Class Initialized
INFO - 2020-09-17 08:07:33 --> Router Class Initialized
INFO - 2020-09-17 08:07:33 --> Output Class Initialized
INFO - 2020-09-17 08:07:33 --> Security Class Initialized
DEBUG - 2020-09-17 08:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 08:07:33 --> Input Class Initialized
INFO - 2020-09-17 08:07:33 --> Language Class Initialized
INFO - 2020-09-17 08:07:33 --> Loader Class Initialized
INFO - 2020-09-17 08:07:33 --> Helper loaded: html_helper
INFO - 2020-09-17 08:07:33 --> Helper loaded: url_helper
INFO - 2020-09-17 08:07:33 --> Helper loaded: form_helper
INFO - 2020-09-17 08:07:33 --> Database Driver Class Initialized
INFO - 2020-09-17 08:07:33 --> Form Validation Class Initialized
DEBUG - 2020-09-17 08:07:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 08:07:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 08:07:34 --> Encryption Class Initialized
INFO - 2020-09-17 08:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 08:07:34 --> Controller Class Initialized
INFO - 2020-09-17 08:07:34 --> Helper loaded: language_helper
INFO - 2020-09-17 08:07:34 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 08:07:34 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-17 08:07:34 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 08:07:34 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment.php
INFO - 2020-09-17 08:07:34 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 08:07:34 --> Final output sent to browser
DEBUG - 2020-09-17 08:07:34 --> Total execution time: 1.0235
INFO - 2020-09-17 08:07:34 --> Config Class Initialized
INFO - 2020-09-17 08:07:34 --> Hooks Class Initialized
DEBUG - 2020-09-17 08:07:34 --> UTF-8 Support Enabled
INFO - 2020-09-17 08:07:34 --> Utf8 Class Initialized
INFO - 2020-09-17 08:07:35 --> URI Class Initialized
INFO - 2020-09-17 08:07:35 --> Router Class Initialized
INFO - 2020-09-17 08:07:35 --> Output Class Initialized
INFO - 2020-09-17 08:07:35 --> Security Class Initialized
DEBUG - 2020-09-17 08:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 08:07:35 --> Input Class Initialized
INFO - 2020-09-17 08:07:35 --> Language Class Initialized
INFO - 2020-09-17 08:07:35 --> Loader Class Initialized
INFO - 2020-09-17 08:07:35 --> Helper loaded: html_helper
INFO - 2020-09-17 08:07:35 --> Helper loaded: url_helper
INFO - 2020-09-17 08:07:35 --> Helper loaded: form_helper
INFO - 2020-09-17 08:07:35 --> Database Driver Class Initialized
INFO - 2020-09-17 08:07:35 --> Form Validation Class Initialized
DEBUG - 2020-09-17 08:07:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 08:07:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 08:07:35 --> Encryption Class Initialized
INFO - 2020-09-17 08:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 08:07:35 --> Controller Class Initialized
INFO - 2020-09-17 08:07:35 --> Helper loaded: language_helper
INFO - 2020-09-17 08:07:35 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 08:07:37 --> Final output sent to browser
DEBUG - 2020-09-17 08:07:37 --> Total execution time: 2.7318
INFO - 2020-09-17 08:07:51 --> Config Class Initialized
INFO - 2020-09-17 08:07:51 --> Hooks Class Initialized
DEBUG - 2020-09-17 08:07:51 --> UTF-8 Support Enabled
INFO - 2020-09-17 08:07:51 --> Utf8 Class Initialized
INFO - 2020-09-17 08:07:51 --> URI Class Initialized
INFO - 2020-09-17 08:07:51 --> Router Class Initialized
INFO - 2020-09-17 08:07:51 --> Output Class Initialized
INFO - 2020-09-17 08:07:51 --> Security Class Initialized
DEBUG - 2020-09-17 08:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 08:07:51 --> Input Class Initialized
INFO - 2020-09-17 08:07:51 --> Language Class Initialized
INFO - 2020-09-17 08:07:51 --> Loader Class Initialized
INFO - 2020-09-17 08:07:51 --> Helper loaded: html_helper
INFO - 2020-09-17 08:07:51 --> Helper loaded: url_helper
INFO - 2020-09-17 08:07:51 --> Helper loaded: form_helper
INFO - 2020-09-17 08:07:51 --> Database Driver Class Initialized
INFO - 2020-09-17 08:07:51 --> Form Validation Class Initialized
DEBUG - 2020-09-17 08:07:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 08:07:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 08:07:51 --> Encryption Class Initialized
INFO - 2020-09-17 08:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 08:07:51 --> Controller Class Initialized
INFO - 2020-09-17 08:07:51 --> Helper loaded: language_helper
INFO - 2020-09-17 08:07:51 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 08:07:54 --> Final output sent to browser
DEBUG - 2020-09-17 08:07:54 --> Total execution time: 3.4299
INFO - 2020-09-17 08:08:31 --> Config Class Initialized
INFO - 2020-09-17 08:08:32 --> Hooks Class Initialized
DEBUG - 2020-09-17 08:08:32 --> UTF-8 Support Enabled
INFO - 2020-09-17 08:08:32 --> Utf8 Class Initialized
INFO - 2020-09-17 08:08:32 --> URI Class Initialized
INFO - 2020-09-17 08:08:32 --> Router Class Initialized
INFO - 2020-09-17 08:08:32 --> Output Class Initialized
INFO - 2020-09-17 08:08:32 --> Security Class Initialized
DEBUG - 2020-09-17 08:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 08:08:32 --> Input Class Initialized
INFO - 2020-09-17 08:08:32 --> Language Class Initialized
INFO - 2020-09-17 08:08:32 --> Loader Class Initialized
INFO - 2020-09-17 08:08:32 --> Helper loaded: html_helper
INFO - 2020-09-17 08:08:32 --> Helper loaded: url_helper
INFO - 2020-09-17 08:08:32 --> Helper loaded: form_helper
INFO - 2020-09-17 08:08:32 --> Database Driver Class Initialized
INFO - 2020-09-17 08:08:32 --> Form Validation Class Initialized
DEBUG - 2020-09-17 08:08:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 08:08:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 08:08:32 --> Encryption Class Initialized
INFO - 2020-09-17 08:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 08:08:32 --> Controller Class Initialized
INFO - 2020-09-17 08:08:32 --> Helper loaded: language_helper
INFO - 2020-09-17 08:08:32 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 08:08:32 --> Final output sent to browser
DEBUG - 2020-09-17 08:08:32 --> Total execution time: 0.9640
INFO - 2020-09-17 08:08:33 --> Config Class Initialized
INFO - 2020-09-17 08:08:33 --> Hooks Class Initialized
DEBUG - 2020-09-17 08:08:33 --> UTF-8 Support Enabled
INFO - 2020-09-17 08:08:33 --> Utf8 Class Initialized
INFO - 2020-09-17 08:08:33 --> URI Class Initialized
DEBUG - 2020-09-17 08:08:33 --> No URI present. Default controller set.
INFO - 2020-09-17 08:08:33 --> Router Class Initialized
INFO - 2020-09-17 08:08:33 --> Output Class Initialized
INFO - 2020-09-17 08:08:33 --> Security Class Initialized
DEBUG - 2020-09-17 08:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 08:08:33 --> Input Class Initialized
INFO - 2020-09-17 08:08:33 --> Language Class Initialized
INFO - 2020-09-17 08:08:33 --> Loader Class Initialized
INFO - 2020-09-17 08:08:33 --> Helper loaded: html_helper
INFO - 2020-09-17 08:08:33 --> Helper loaded: url_helper
INFO - 2020-09-17 08:08:33 --> Helper loaded: form_helper
INFO - 2020-09-17 08:08:33 --> Database Driver Class Initialized
INFO - 2020-09-17 08:08:33 --> Form Validation Class Initialized
DEBUG - 2020-09-17 08:08:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 08:08:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 08:08:34 --> Encryption Class Initialized
INFO - 2020-09-17 08:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 08:08:34 --> Controller Class Initialized
INFO - 2020-09-17 08:08:34 --> Helper loaded: language_helper
INFO - 2020-09-17 08:08:34 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 08:08:34 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 08:08:34 --> Final output sent to browser
DEBUG - 2020-09-17 08:08:34 --> Total execution time: 0.9064
INFO - 2020-09-17 08:12:01 --> Config Class Initialized
INFO - 2020-09-17 08:12:01 --> Hooks Class Initialized
DEBUG - 2020-09-17 08:12:01 --> UTF-8 Support Enabled
INFO - 2020-09-17 08:12:01 --> Utf8 Class Initialized
INFO - 2020-09-17 08:12:01 --> URI Class Initialized
DEBUG - 2020-09-17 08:12:01 --> No URI present. Default controller set.
INFO - 2020-09-17 08:12:01 --> Router Class Initialized
INFO - 2020-09-17 08:12:01 --> Output Class Initialized
INFO - 2020-09-17 08:12:01 --> Security Class Initialized
DEBUG - 2020-09-17 08:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 08:12:01 --> Input Class Initialized
INFO - 2020-09-17 08:12:01 --> Language Class Initialized
INFO - 2020-09-17 08:12:01 --> Loader Class Initialized
INFO - 2020-09-17 08:12:01 --> Helper loaded: html_helper
INFO - 2020-09-17 08:12:01 --> Helper loaded: url_helper
INFO - 2020-09-17 08:12:01 --> Helper loaded: form_helper
INFO - 2020-09-17 08:12:01 --> Database Driver Class Initialized
INFO - 2020-09-17 08:12:01 --> Form Validation Class Initialized
DEBUG - 2020-09-17 08:12:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 08:12:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 08:12:01 --> Encryption Class Initialized
INFO - 2020-09-17 08:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 08:12:01 --> Controller Class Initialized
INFO - 2020-09-17 08:12:01 --> Helper loaded: language_helper
INFO - 2020-09-17 08:12:01 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 08:12:01 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 08:12:01 --> Final output sent to browser
DEBUG - 2020-09-17 08:12:01 --> Total execution time: 0.8797
INFO - 2020-09-17 08:12:07 --> Config Class Initialized
INFO - 2020-09-17 08:12:07 --> Hooks Class Initialized
DEBUG - 2020-09-17 08:12:07 --> UTF-8 Support Enabled
INFO - 2020-09-17 08:12:07 --> Utf8 Class Initialized
INFO - 2020-09-17 08:12:07 --> URI Class Initialized
INFO - 2020-09-17 08:12:07 --> Router Class Initialized
INFO - 2020-09-17 08:12:07 --> Output Class Initialized
INFO - 2020-09-17 08:12:07 --> Security Class Initialized
DEBUG - 2020-09-17 08:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 08:12:07 --> Input Class Initialized
INFO - 2020-09-17 08:12:07 --> Language Class Initialized
INFO - 2020-09-17 08:12:07 --> Loader Class Initialized
INFO - 2020-09-17 08:12:08 --> Helper loaded: html_helper
INFO - 2020-09-17 08:12:08 --> Helper loaded: url_helper
INFO - 2020-09-17 08:12:08 --> Helper loaded: form_helper
INFO - 2020-09-17 08:12:08 --> Database Driver Class Initialized
INFO - 2020-09-17 08:12:08 --> Form Validation Class Initialized
DEBUG - 2020-09-17 08:12:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 08:12:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 08:12:08 --> Encryption Class Initialized
INFO - 2020-09-17 08:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 08:12:08 --> Controller Class Initialized
INFO - 2020-09-17 08:12:08 --> Helper loaded: language_helper
INFO - 2020-09-17 08:12:08 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-17 08:12:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-17 08:12:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-17 08:12:08 --> Model "User" initialized
INFO - 2020-09-17 08:12:09 --> Config Class Initialized
INFO - 2020-09-17 08:12:09 --> Hooks Class Initialized
DEBUG - 2020-09-17 08:12:09 --> UTF-8 Support Enabled
INFO - 2020-09-17 08:12:09 --> Utf8 Class Initialized
INFO - 2020-09-17 08:12:09 --> URI Class Initialized
INFO - 2020-09-17 08:12:09 --> Router Class Initialized
INFO - 2020-09-17 08:12:09 --> Output Class Initialized
INFO - 2020-09-17 08:12:09 --> Security Class Initialized
DEBUG - 2020-09-17 08:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 08:12:09 --> Input Class Initialized
INFO - 2020-09-17 08:12:09 --> Language Class Initialized
INFO - 2020-09-17 08:12:09 --> Loader Class Initialized
INFO - 2020-09-17 08:12:09 --> Helper loaded: html_helper
INFO - 2020-09-17 08:12:09 --> Helper loaded: url_helper
INFO - 2020-09-17 08:12:09 --> Helper loaded: form_helper
INFO - 2020-09-17 08:12:09 --> Database Driver Class Initialized
INFO - 2020-09-17 08:12:09 --> Form Validation Class Initialized
DEBUG - 2020-09-17 08:12:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 08:12:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 08:12:09 --> Encryption Class Initialized
INFO - 2020-09-17 08:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 08:12:10 --> Controller Class Initialized
INFO - 2020-09-17 08:12:10 --> Helper loaded: language_helper
INFO - 2020-09-17 08:12:10 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 08:12:10 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-17 08:12:10 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 08:12:10 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-17 08:12:10 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 08:12:10 --> Final output sent to browser
DEBUG - 2020-09-17 08:12:10 --> Total execution time: 1.0603
INFO - 2020-09-17 08:12:32 --> Config Class Initialized
INFO - 2020-09-17 08:12:32 --> Hooks Class Initialized
DEBUG - 2020-09-17 08:12:32 --> UTF-8 Support Enabled
INFO - 2020-09-17 08:12:32 --> Utf8 Class Initialized
INFO - 2020-09-17 08:12:32 --> URI Class Initialized
INFO - 2020-09-17 08:12:32 --> Router Class Initialized
INFO - 2020-09-17 08:12:32 --> Output Class Initialized
INFO - 2020-09-17 08:12:32 --> Security Class Initialized
DEBUG - 2020-09-17 08:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 08:12:32 --> Input Class Initialized
INFO - 2020-09-17 08:12:32 --> Language Class Initialized
INFO - 2020-09-17 08:12:32 --> Loader Class Initialized
INFO - 2020-09-17 08:12:32 --> Helper loaded: html_helper
INFO - 2020-09-17 08:12:32 --> Helper loaded: url_helper
INFO - 2020-09-17 08:12:32 --> Helper loaded: form_helper
INFO - 2020-09-17 08:12:32 --> Database Driver Class Initialized
INFO - 2020-09-17 08:12:33 --> Form Validation Class Initialized
DEBUG - 2020-09-17 08:12:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 08:12:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 08:12:33 --> Encryption Class Initialized
INFO - 2020-09-17 08:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 08:12:33 --> Controller Class Initialized
INFO - 2020-09-17 08:12:33 --> Helper loaded: language_helper
INFO - 2020-09-17 08:12:33 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 08:12:33 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-17 08:12:33 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 08:12:33 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-17 08:12:33 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 08:12:33 --> Final output sent to browser
DEBUG - 2020-09-17 08:12:33 --> Total execution time: 1.1236
INFO - 2020-09-17 08:15:29 --> Config Class Initialized
INFO - 2020-09-17 08:15:29 --> Hooks Class Initialized
DEBUG - 2020-09-17 08:15:29 --> UTF-8 Support Enabled
INFO - 2020-09-17 08:15:29 --> Utf8 Class Initialized
INFO - 2020-09-17 08:15:29 --> URI Class Initialized
INFO - 2020-09-17 08:15:29 --> Router Class Initialized
INFO - 2020-09-17 08:15:29 --> Output Class Initialized
INFO - 2020-09-17 08:15:29 --> Security Class Initialized
DEBUG - 2020-09-17 08:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 08:15:29 --> Input Class Initialized
INFO - 2020-09-17 08:15:29 --> Language Class Initialized
INFO - 2020-09-17 08:15:29 --> Loader Class Initialized
INFO - 2020-09-17 08:15:29 --> Helper loaded: html_helper
INFO - 2020-09-17 08:15:29 --> Helper loaded: url_helper
INFO - 2020-09-17 08:15:29 --> Helper loaded: form_helper
INFO - 2020-09-17 08:15:29 --> Database Driver Class Initialized
INFO - 2020-09-17 08:15:29 --> Form Validation Class Initialized
DEBUG - 2020-09-17 08:15:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 08:15:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 08:15:29 --> Encryption Class Initialized
INFO - 2020-09-17 08:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 08:15:30 --> Controller Class Initialized
INFO - 2020-09-17 08:15:30 --> Helper loaded: language_helper
INFO - 2020-09-17 08:15:30 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 08:15:30 --> Final output sent to browser
DEBUG - 2020-09-17 08:15:30 --> Total execution time: 0.9943
INFO - 2020-09-17 08:15:30 --> Config Class Initialized
INFO - 2020-09-17 08:15:30 --> Hooks Class Initialized
DEBUG - 2020-09-17 08:15:30 --> UTF-8 Support Enabled
INFO - 2020-09-17 08:15:30 --> Utf8 Class Initialized
INFO - 2020-09-17 08:15:30 --> URI Class Initialized
DEBUG - 2020-09-17 08:15:30 --> No URI present. Default controller set.
INFO - 2020-09-17 08:15:30 --> Router Class Initialized
INFO - 2020-09-17 08:15:30 --> Output Class Initialized
INFO - 2020-09-17 08:15:30 --> Security Class Initialized
DEBUG - 2020-09-17 08:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 08:15:30 --> Input Class Initialized
INFO - 2020-09-17 08:15:30 --> Language Class Initialized
INFO - 2020-09-17 08:15:30 --> Loader Class Initialized
INFO - 2020-09-17 08:15:30 --> Helper loaded: html_helper
INFO - 2020-09-17 08:15:31 --> Helper loaded: url_helper
INFO - 2020-09-17 08:15:31 --> Helper loaded: form_helper
INFO - 2020-09-17 08:15:31 --> Database Driver Class Initialized
INFO - 2020-09-17 08:15:31 --> Form Validation Class Initialized
DEBUG - 2020-09-17 08:15:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 08:15:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 08:15:31 --> Encryption Class Initialized
INFO - 2020-09-17 08:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 08:15:31 --> Controller Class Initialized
INFO - 2020-09-17 08:15:31 --> Helper loaded: language_helper
INFO - 2020-09-17 08:15:31 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 08:15:31 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 08:15:31 --> Final output sent to browser
DEBUG - 2020-09-17 08:15:31 --> Total execution time: 1.2275
INFO - 2020-09-17 12:58:38 --> Config Class Initialized
INFO - 2020-09-17 12:58:38 --> Hooks Class Initialized
DEBUG - 2020-09-17 12:58:39 --> UTF-8 Support Enabled
INFO - 2020-09-17 12:58:39 --> Utf8 Class Initialized
INFO - 2020-09-17 12:58:39 --> URI Class Initialized
DEBUG - 2020-09-17 12:58:39 --> No URI present. Default controller set.
INFO - 2020-09-17 12:58:39 --> Router Class Initialized
INFO - 2020-09-17 12:58:39 --> Output Class Initialized
INFO - 2020-09-17 12:58:39 --> Security Class Initialized
DEBUG - 2020-09-17 12:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 12:58:39 --> Input Class Initialized
INFO - 2020-09-17 12:58:39 --> Language Class Initialized
INFO - 2020-09-17 12:58:40 --> Loader Class Initialized
INFO - 2020-09-17 12:58:40 --> Helper loaded: html_helper
INFO - 2020-09-17 12:58:40 --> Helper loaded: url_helper
INFO - 2020-09-17 12:58:40 --> Helper loaded: form_helper
INFO - 2020-09-17 12:58:40 --> Database Driver Class Initialized
INFO - 2020-09-17 12:58:41 --> Form Validation Class Initialized
DEBUG - 2020-09-17 12:58:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 12:58:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 12:58:41 --> Encryption Class Initialized
INFO - 2020-09-17 12:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 12:58:41 --> Controller Class Initialized
INFO - 2020-09-17 12:58:41 --> Helper loaded: language_helper
INFO - 2020-09-17 12:58:42 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 12:58:42 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-17 12:58:42 --> Final output sent to browser
DEBUG - 2020-09-17 12:58:42 --> Total execution time: 4.2182
INFO - 2020-09-17 12:58:59 --> Config Class Initialized
INFO - 2020-09-17 12:59:01 --> Hooks Class Initialized
DEBUG - 2020-09-17 12:59:01 --> UTF-8 Support Enabled
INFO - 2020-09-17 12:59:01 --> Utf8 Class Initialized
INFO - 2020-09-17 12:59:01 --> URI Class Initialized
INFO - 2020-09-17 12:59:01 --> Router Class Initialized
INFO - 2020-09-17 12:59:01 --> Output Class Initialized
INFO - 2020-09-17 12:59:01 --> Security Class Initialized
DEBUG - 2020-09-17 12:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 12:59:01 --> Input Class Initialized
INFO - 2020-09-17 12:59:01 --> Language Class Initialized
INFO - 2020-09-17 12:59:01 --> Loader Class Initialized
INFO - 2020-09-17 12:59:01 --> Helper loaded: html_helper
INFO - 2020-09-17 12:59:01 --> Helper loaded: url_helper
INFO - 2020-09-17 12:59:01 --> Helper loaded: form_helper
INFO - 2020-09-17 12:59:01 --> Database Driver Class Initialized
INFO - 2020-09-17 12:59:02 --> Form Validation Class Initialized
DEBUG - 2020-09-17 12:59:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 12:59:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 12:59:02 --> Encryption Class Initialized
INFO - 2020-09-17 12:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 12:59:02 --> Controller Class Initialized
INFO - 2020-09-17 12:59:02 --> Helper loaded: language_helper
INFO - 2020-09-17 12:59:02 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-17 12:59:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-17 12:59:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-17 12:59:02 --> Model "User" initialized
INFO - 2020-09-17 12:59:03 --> Config Class Initialized
INFO - 2020-09-17 12:59:03 --> Hooks Class Initialized
DEBUG - 2020-09-17 12:59:03 --> UTF-8 Support Enabled
INFO - 2020-09-17 12:59:03 --> Utf8 Class Initialized
INFO - 2020-09-17 12:59:03 --> URI Class Initialized
INFO - 2020-09-17 12:59:03 --> Router Class Initialized
INFO - 2020-09-17 12:59:03 --> Output Class Initialized
INFO - 2020-09-17 12:59:03 --> Security Class Initialized
DEBUG - 2020-09-17 12:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 12:59:03 --> Input Class Initialized
INFO - 2020-09-17 12:59:03 --> Language Class Initialized
INFO - 2020-09-17 12:59:03 --> Loader Class Initialized
INFO - 2020-09-17 12:59:03 --> Helper loaded: html_helper
INFO - 2020-09-17 12:59:03 --> Helper loaded: url_helper
INFO - 2020-09-17 12:59:03 --> Helper loaded: form_helper
INFO - 2020-09-17 12:59:03 --> Database Driver Class Initialized
INFO - 2020-09-17 12:59:04 --> Form Validation Class Initialized
DEBUG - 2020-09-17 12:59:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 12:59:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 12:59:04 --> Encryption Class Initialized
INFO - 2020-09-17 12:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 12:59:04 --> Controller Class Initialized
INFO - 2020-09-17 12:59:04 --> Helper loaded: language_helper
INFO - 2020-09-17 12:59:04 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 12:59:04 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-17 12:59:04 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 12:59:04 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-17 12:59:04 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 12:59:04 --> Final output sent to browser
DEBUG - 2020-09-17 12:59:04 --> Total execution time: 1.1806
INFO - 2020-09-17 12:59:15 --> Config Class Initialized
INFO - 2020-09-17 12:59:15 --> Hooks Class Initialized
DEBUG - 2020-09-17 12:59:15 --> UTF-8 Support Enabled
INFO - 2020-09-17 12:59:15 --> Utf8 Class Initialized
INFO - 2020-09-17 12:59:15 --> URI Class Initialized
INFO - 2020-09-17 12:59:15 --> Router Class Initialized
INFO - 2020-09-17 12:59:15 --> Output Class Initialized
INFO - 2020-09-17 12:59:15 --> Security Class Initialized
DEBUG - 2020-09-17 12:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 12:59:15 --> Input Class Initialized
INFO - 2020-09-17 12:59:15 --> Language Class Initialized
INFO - 2020-09-17 12:59:15 --> Loader Class Initialized
INFO - 2020-09-17 12:59:15 --> Helper loaded: html_helper
INFO - 2020-09-17 12:59:15 --> Helper loaded: url_helper
INFO - 2020-09-17 12:59:15 --> Helper loaded: form_helper
INFO - 2020-09-17 12:59:15 --> Database Driver Class Initialized
INFO - 2020-09-17 12:59:15 --> Form Validation Class Initialized
DEBUG - 2020-09-17 12:59:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 12:59:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 12:59:16 --> Encryption Class Initialized
INFO - 2020-09-17 12:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 12:59:16 --> Controller Class Initialized
INFO - 2020-09-17 12:59:16 --> Helper loaded: language_helper
INFO - 2020-09-17 12:59:16 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 12:59:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-17 12:59:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 12:59:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-17 12:59:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 12:59:16 --> Final output sent to browser
DEBUG - 2020-09-17 12:59:16 --> Total execution time: 1.3527
INFO - 2020-09-17 13:01:57 --> Config Class Initialized
INFO - 2020-09-17 13:01:57 --> Hooks Class Initialized
DEBUG - 2020-09-17 13:01:57 --> UTF-8 Support Enabled
INFO - 2020-09-17 13:01:57 --> Utf8 Class Initialized
INFO - 2020-09-17 13:01:57 --> URI Class Initialized
INFO - 2020-09-17 13:01:57 --> Router Class Initialized
INFO - 2020-09-17 13:01:57 --> Output Class Initialized
INFO - 2020-09-17 13:01:57 --> Security Class Initialized
DEBUG - 2020-09-17 13:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 13:01:57 --> Input Class Initialized
INFO - 2020-09-17 13:01:57 --> Language Class Initialized
INFO - 2020-09-17 13:01:57 --> Loader Class Initialized
INFO - 2020-09-17 13:01:57 --> Helper loaded: html_helper
INFO - 2020-09-17 13:01:57 --> Helper loaded: url_helper
INFO - 2020-09-17 13:01:57 --> Helper loaded: form_helper
INFO - 2020-09-17 13:01:57 --> Database Driver Class Initialized
INFO - 2020-09-17 13:01:57 --> Form Validation Class Initialized
DEBUG - 2020-09-17 13:01:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 13:01:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 13:01:57 --> Encryption Class Initialized
INFO - 2020-09-17 13:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 13:01:57 --> Controller Class Initialized
INFO - 2020-09-17 13:01:57 --> Helper loaded: language_helper
INFO - 2020-09-17 13:01:58 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 13:01:58 --> Model "Sale_model" initialized
INFO - 2020-09-17 13:01:58 --> Final output sent to browser
DEBUG - 2020-09-17 13:01:58 --> Total execution time: 1.0577
INFO - 2020-09-17 13:02:03 --> Config Class Initialized
INFO - 2020-09-17 13:02:03 --> Hooks Class Initialized
DEBUG - 2020-09-17 13:02:03 --> UTF-8 Support Enabled
INFO - 2020-09-17 13:02:03 --> Utf8 Class Initialized
INFO - 2020-09-17 13:02:03 --> URI Class Initialized
INFO - 2020-09-17 13:02:03 --> Router Class Initialized
INFO - 2020-09-17 13:02:03 --> Output Class Initialized
INFO - 2020-09-17 13:02:03 --> Security Class Initialized
DEBUG - 2020-09-17 13:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 13:02:03 --> Input Class Initialized
INFO - 2020-09-17 13:02:03 --> Language Class Initialized
INFO - 2020-09-17 13:02:03 --> Loader Class Initialized
INFO - 2020-09-17 13:02:03 --> Helper loaded: html_helper
INFO - 2020-09-17 13:02:04 --> Helper loaded: url_helper
INFO - 2020-09-17 13:02:04 --> Helper loaded: form_helper
INFO - 2020-09-17 13:02:04 --> Database Driver Class Initialized
INFO - 2020-09-17 13:02:04 --> Form Validation Class Initialized
DEBUG - 2020-09-17 13:02:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 13:02:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 13:02:04 --> Encryption Class Initialized
INFO - 2020-09-17 13:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 13:02:04 --> Controller Class Initialized
INFO - 2020-09-17 13:02:04 --> Helper loaded: language_helper
INFO - 2020-09-17 13:02:04 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 13:02:04 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-17 13:02:04 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 13:02:04 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment.php
INFO - 2020-09-17 13:02:04 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 13:02:04 --> Final output sent to browser
DEBUG - 2020-09-17 13:02:04 --> Total execution time: 1.2960
INFO - 2020-09-17 13:02:05 --> Config Class Initialized
INFO - 2020-09-17 13:02:05 --> Hooks Class Initialized
DEBUG - 2020-09-17 13:02:05 --> UTF-8 Support Enabled
INFO - 2020-09-17 13:02:05 --> Utf8 Class Initialized
INFO - 2020-09-17 13:02:05 --> URI Class Initialized
INFO - 2020-09-17 13:02:05 --> Router Class Initialized
INFO - 2020-09-17 13:02:05 --> Output Class Initialized
INFO - 2020-09-17 13:02:05 --> Security Class Initialized
DEBUG - 2020-09-17 13:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 13:02:05 --> Input Class Initialized
INFO - 2020-09-17 13:02:05 --> Language Class Initialized
INFO - 2020-09-17 13:02:06 --> Loader Class Initialized
INFO - 2020-09-17 13:02:06 --> Helper loaded: html_helper
INFO - 2020-09-17 13:02:06 --> Helper loaded: url_helper
INFO - 2020-09-17 13:02:06 --> Helper loaded: form_helper
INFO - 2020-09-17 13:02:06 --> Database Driver Class Initialized
INFO - 2020-09-17 13:02:06 --> Form Validation Class Initialized
DEBUG - 2020-09-17 13:02:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 13:02:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 13:02:06 --> Encryption Class Initialized
INFO - 2020-09-17 13:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 13:02:06 --> Controller Class Initialized
INFO - 2020-09-17 13:02:06 --> Helper loaded: language_helper
INFO - 2020-09-17 13:02:06 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 13:02:09 --> Final output sent to browser
DEBUG - 2020-09-17 13:02:09 --> Total execution time: 3.6305
INFO - 2020-09-17 13:02:14 --> Config Class Initialized
INFO - 2020-09-17 13:02:15 --> Hooks Class Initialized
DEBUG - 2020-09-17 13:02:15 --> UTF-8 Support Enabled
INFO - 2020-09-17 13:02:15 --> Utf8 Class Initialized
INFO - 2020-09-17 13:02:15 --> URI Class Initialized
INFO - 2020-09-17 13:02:15 --> Router Class Initialized
INFO - 2020-09-17 13:02:15 --> Output Class Initialized
INFO - 2020-09-17 13:02:15 --> Security Class Initialized
DEBUG - 2020-09-17 13:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 13:02:15 --> Input Class Initialized
INFO - 2020-09-17 13:02:15 --> Language Class Initialized
INFO - 2020-09-17 13:02:15 --> Loader Class Initialized
INFO - 2020-09-17 13:02:15 --> Helper loaded: html_helper
INFO - 2020-09-17 13:02:15 --> Helper loaded: url_helper
INFO - 2020-09-17 13:02:15 --> Helper loaded: form_helper
INFO - 2020-09-17 13:02:15 --> Database Driver Class Initialized
INFO - 2020-09-17 13:02:15 --> Form Validation Class Initialized
DEBUG - 2020-09-17 13:02:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 13:02:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 13:02:15 --> Encryption Class Initialized
INFO - 2020-09-17 13:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 13:02:15 --> Controller Class Initialized
INFO - 2020-09-17 13:02:15 --> Helper loaded: language_helper
INFO - 2020-09-17 13:02:15 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 13:02:15 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-17 13:02:15 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 13:02:15 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-17 13:02:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 13:02:16 --> Final output sent to browser
DEBUG - 2020-09-17 13:02:16 --> Total execution time: 1.1097
INFO - 2020-09-17 13:02:17 --> Config Class Initialized
INFO - 2020-09-17 13:02:17 --> Hooks Class Initialized
DEBUG - 2020-09-17 13:02:17 --> UTF-8 Support Enabled
INFO - 2020-09-17 13:02:17 --> Utf8 Class Initialized
INFO - 2020-09-17 13:02:17 --> URI Class Initialized
INFO - 2020-09-17 13:02:17 --> Router Class Initialized
INFO - 2020-09-17 13:02:17 --> Output Class Initialized
INFO - 2020-09-17 13:02:17 --> Security Class Initialized
DEBUG - 2020-09-17 13:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 13:02:17 --> Input Class Initialized
INFO - 2020-09-17 13:02:17 --> Language Class Initialized
INFO - 2020-09-17 13:02:17 --> Loader Class Initialized
INFO - 2020-09-17 13:02:17 --> Helper loaded: html_helper
INFO - 2020-09-17 13:02:17 --> Helper loaded: url_helper
INFO - 2020-09-17 13:02:17 --> Helper loaded: form_helper
INFO - 2020-09-17 13:02:18 --> Database Driver Class Initialized
INFO - 2020-09-17 13:02:18 --> Form Validation Class Initialized
DEBUG - 2020-09-17 13:02:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 13:02:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 13:02:18 --> Encryption Class Initialized
INFO - 2020-09-17 13:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 13:02:18 --> Controller Class Initialized
INFO - 2020-09-17 13:02:18 --> Helper loaded: language_helper
INFO - 2020-09-17 13:02:18 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 13:02:18 --> Model "Sale_model" initialized
INFO - 2020-09-17 13:02:18 --> Final output sent to browser
DEBUG - 2020-09-17 13:02:18 --> Total execution time: 0.9676
INFO - 2020-09-17 13:02:41 --> Config Class Initialized
INFO - 2020-09-17 13:02:41 --> Hooks Class Initialized
DEBUG - 2020-09-17 13:02:41 --> UTF-8 Support Enabled
INFO - 2020-09-17 13:02:41 --> Utf8 Class Initialized
INFO - 2020-09-17 13:02:41 --> URI Class Initialized
INFO - 2020-09-17 13:02:41 --> Router Class Initialized
INFO - 2020-09-17 13:02:41 --> Output Class Initialized
INFO - 2020-09-17 13:02:41 --> Security Class Initialized
DEBUG - 2020-09-17 13:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 13:02:41 --> Input Class Initialized
INFO - 2020-09-17 13:02:41 --> Language Class Initialized
INFO - 2020-09-17 13:02:41 --> Loader Class Initialized
INFO - 2020-09-17 13:02:41 --> Helper loaded: html_helper
INFO - 2020-09-17 13:02:41 --> Helper loaded: url_helper
INFO - 2020-09-17 13:02:41 --> Helper loaded: form_helper
INFO - 2020-09-17 13:02:41 --> Database Driver Class Initialized
INFO - 2020-09-17 13:02:41 --> Form Validation Class Initialized
DEBUG - 2020-09-17 13:02:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 13:02:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 13:02:41 --> Encryption Class Initialized
INFO - 2020-09-17 13:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 13:02:41 --> Controller Class Initialized
INFO - 2020-09-17 13:02:41 --> Helper loaded: language_helper
INFO - 2020-09-17 13:02:42 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 13:02:42 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-17 13:02:42 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 13:02:42 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment.php
INFO - 2020-09-17 13:02:42 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 13:02:42 --> Final output sent to browser
DEBUG - 2020-09-17 13:02:42 --> Total execution time: 1.0901
INFO - 2020-09-17 13:02:42 --> Config Class Initialized
INFO - 2020-09-17 13:02:42 --> Hooks Class Initialized
DEBUG - 2020-09-17 13:02:42 --> UTF-8 Support Enabled
INFO - 2020-09-17 13:02:42 --> Utf8 Class Initialized
INFO - 2020-09-17 13:02:42 --> URI Class Initialized
INFO - 2020-09-17 13:02:42 --> Router Class Initialized
INFO - 2020-09-17 13:02:42 --> Output Class Initialized
INFO - 2020-09-17 13:02:43 --> Security Class Initialized
DEBUG - 2020-09-17 13:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 13:02:43 --> Input Class Initialized
INFO - 2020-09-17 13:02:43 --> Language Class Initialized
INFO - 2020-09-17 13:02:43 --> Loader Class Initialized
INFO - 2020-09-17 13:02:43 --> Helper loaded: html_helper
INFO - 2020-09-17 13:02:43 --> Helper loaded: url_helper
INFO - 2020-09-17 13:02:43 --> Helper loaded: form_helper
INFO - 2020-09-17 13:02:43 --> Database Driver Class Initialized
INFO - 2020-09-17 13:02:43 --> Form Validation Class Initialized
DEBUG - 2020-09-17 13:02:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 13:02:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 13:02:43 --> Encryption Class Initialized
INFO - 2020-09-17 13:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 13:02:43 --> Controller Class Initialized
INFO - 2020-09-17 13:02:43 --> Helper loaded: language_helper
INFO - 2020-09-17 13:02:43 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 13:02:44 --> Final output sent to browser
DEBUG - 2020-09-17 13:02:44 --> Total execution time: 2.2085
INFO - 2020-09-17 13:03:06 --> Config Class Initialized
INFO - 2020-09-17 13:03:06 --> Hooks Class Initialized
DEBUG - 2020-09-17 13:03:06 --> UTF-8 Support Enabled
INFO - 2020-09-17 13:03:06 --> Utf8 Class Initialized
INFO - 2020-09-17 13:03:06 --> URI Class Initialized
INFO - 2020-09-17 13:03:06 --> Router Class Initialized
INFO - 2020-09-17 13:03:06 --> Output Class Initialized
INFO - 2020-09-17 13:03:06 --> Security Class Initialized
DEBUG - 2020-09-17 13:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 13:03:06 --> Input Class Initialized
INFO - 2020-09-17 13:03:06 --> Language Class Initialized
INFO - 2020-09-17 13:03:06 --> Loader Class Initialized
INFO - 2020-09-17 13:03:07 --> Helper loaded: html_helper
INFO - 2020-09-17 13:03:07 --> Helper loaded: url_helper
INFO - 2020-09-17 13:03:07 --> Helper loaded: form_helper
INFO - 2020-09-17 13:03:07 --> Database Driver Class Initialized
INFO - 2020-09-17 13:03:07 --> Form Validation Class Initialized
DEBUG - 2020-09-17 13:03:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 13:03:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 13:03:07 --> Encryption Class Initialized
INFO - 2020-09-17 13:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 13:03:07 --> Controller Class Initialized
INFO - 2020-09-17 13:03:07 --> Helper loaded: language_helper
INFO - 2020-09-17 13:03:07 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 13:03:10 --> Final output sent to browser
DEBUG - 2020-09-17 13:03:10 --> Total execution time: 3.6080
INFO - 2020-09-17 13:04:05 --> Config Class Initialized
INFO - 2020-09-17 13:04:06 --> Hooks Class Initialized
DEBUG - 2020-09-17 13:04:06 --> UTF-8 Support Enabled
INFO - 2020-09-17 13:04:06 --> Utf8 Class Initialized
INFO - 2020-09-17 13:04:06 --> URI Class Initialized
INFO - 2020-09-17 13:04:06 --> Router Class Initialized
INFO - 2020-09-17 13:04:06 --> Output Class Initialized
INFO - 2020-09-17 13:04:06 --> Security Class Initialized
DEBUG - 2020-09-17 13:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 13:04:06 --> Input Class Initialized
INFO - 2020-09-17 13:04:06 --> Language Class Initialized
INFO - 2020-09-17 13:04:06 --> Loader Class Initialized
INFO - 2020-09-17 13:04:06 --> Helper loaded: html_helper
INFO - 2020-09-17 13:04:06 --> Helper loaded: url_helper
INFO - 2020-09-17 13:04:06 --> Helper loaded: form_helper
INFO - 2020-09-17 13:04:06 --> Database Driver Class Initialized
INFO - 2020-09-17 13:04:06 --> Form Validation Class Initialized
DEBUG - 2020-09-17 13:04:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 13:04:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 13:04:06 --> Encryption Class Initialized
INFO - 2020-09-17 13:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 13:04:06 --> Controller Class Initialized
INFO - 2020-09-17 13:04:06 --> Helper loaded: language_helper
INFO - 2020-09-17 13:04:06 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 13:04:06 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-17 13:04:06 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 13:04:06 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-17 13:04:07 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 13:04:07 --> Final output sent to browser
DEBUG - 2020-09-17 13:04:07 --> Total execution time: 1.1017
INFO - 2020-09-17 13:04:35 --> Config Class Initialized
INFO - 2020-09-17 13:04:35 --> Hooks Class Initialized
DEBUG - 2020-09-17 13:04:35 --> UTF-8 Support Enabled
INFO - 2020-09-17 13:04:35 --> Utf8 Class Initialized
INFO - 2020-09-17 13:04:35 --> URI Class Initialized
INFO - 2020-09-17 13:04:35 --> Router Class Initialized
INFO - 2020-09-17 13:04:35 --> Output Class Initialized
INFO - 2020-09-17 13:04:35 --> Security Class Initialized
DEBUG - 2020-09-17 13:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 13:04:35 --> Input Class Initialized
INFO - 2020-09-17 13:04:35 --> Language Class Initialized
INFO - 2020-09-17 13:04:35 --> Loader Class Initialized
INFO - 2020-09-17 13:04:35 --> Helper loaded: html_helper
INFO - 2020-09-17 13:04:35 --> Helper loaded: url_helper
INFO - 2020-09-17 13:04:35 --> Helper loaded: form_helper
INFO - 2020-09-17 13:04:35 --> Database Driver Class Initialized
INFO - 2020-09-17 13:04:35 --> Form Validation Class Initialized
DEBUG - 2020-09-17 13:04:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 13:04:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 13:04:36 --> Encryption Class Initialized
INFO - 2020-09-17 13:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 13:04:36 --> Controller Class Initialized
INFO - 2020-09-17 13:04:36 --> Helper loaded: language_helper
INFO - 2020-09-17 13:04:36 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 13:04:36 --> Model "Sale_model" initialized
INFO - 2020-09-17 13:04:36 --> Final output sent to browser
DEBUG - 2020-09-17 13:04:36 --> Total execution time: 0.9137
INFO - 2020-09-17 13:04:43 --> Config Class Initialized
INFO - 2020-09-17 13:04:43 --> Hooks Class Initialized
DEBUG - 2020-09-17 13:04:43 --> UTF-8 Support Enabled
INFO - 2020-09-17 13:04:43 --> Utf8 Class Initialized
INFO - 2020-09-17 13:04:43 --> URI Class Initialized
INFO - 2020-09-17 13:04:43 --> Router Class Initialized
INFO - 2020-09-17 13:04:43 --> Output Class Initialized
INFO - 2020-09-17 13:04:44 --> Security Class Initialized
DEBUG - 2020-09-17 13:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 13:04:44 --> Input Class Initialized
INFO - 2020-09-17 13:04:44 --> Language Class Initialized
INFO - 2020-09-17 13:04:44 --> Loader Class Initialized
INFO - 2020-09-17 13:04:44 --> Helper loaded: html_helper
INFO - 2020-09-17 13:04:44 --> Helper loaded: url_helper
INFO - 2020-09-17 13:04:44 --> Helper loaded: form_helper
INFO - 2020-09-17 13:04:44 --> Database Driver Class Initialized
INFO - 2020-09-17 13:04:44 --> Form Validation Class Initialized
DEBUG - 2020-09-17 13:04:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 13:04:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 13:04:44 --> Encryption Class Initialized
INFO - 2020-09-17 13:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 13:04:44 --> Controller Class Initialized
INFO - 2020-09-17 13:04:44 --> Helper loaded: language_helper
INFO - 2020-09-17 13:04:45 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 13:04:45 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-17 13:04:45 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 13:04:45 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-17 13:04:45 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 13:04:45 --> Final output sent to browser
DEBUG - 2020-09-17 13:04:45 --> Total execution time: 1.4140
INFO - 2020-09-17 13:04:45 --> Config Class Initialized
INFO - 2020-09-17 13:04:45 --> Hooks Class Initialized
DEBUG - 2020-09-17 13:04:45 --> UTF-8 Support Enabled
INFO - 2020-09-17 13:04:45 --> Utf8 Class Initialized
INFO - 2020-09-17 13:04:45 --> URI Class Initialized
INFO - 2020-09-17 13:04:45 --> Router Class Initialized
INFO - 2020-09-17 13:04:45 --> Output Class Initialized
INFO - 2020-09-17 13:04:45 --> Security Class Initialized
DEBUG - 2020-09-17 13:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 13:04:45 --> Input Class Initialized
INFO - 2020-09-17 13:04:45 --> Language Class Initialized
INFO - 2020-09-17 13:04:46 --> Loader Class Initialized
INFO - 2020-09-17 13:04:46 --> Helper loaded: html_helper
INFO - 2020-09-17 13:04:46 --> Helper loaded: url_helper
INFO - 2020-09-17 13:04:46 --> Helper loaded: form_helper
INFO - 2020-09-17 13:04:46 --> Database Driver Class Initialized
INFO - 2020-09-17 13:04:46 --> Form Validation Class Initialized
DEBUG - 2020-09-17 13:04:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 13:04:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 13:04:46 --> Encryption Class Initialized
INFO - 2020-09-17 13:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 13:04:46 --> Controller Class Initialized
INFO - 2020-09-17 13:04:46 --> Helper loaded: language_helper
INFO - 2020-09-17 13:04:46 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 13:04:46 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-17 13:04:46 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 13:04:46 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-17 13:04:46 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 13:04:46 --> Final output sent to browser
DEBUG - 2020-09-17 13:04:46 --> Total execution time: 1.0944
INFO - 2020-09-17 13:04:49 --> Config Class Initialized
INFO - 2020-09-17 13:04:49 --> Hooks Class Initialized
DEBUG - 2020-09-17 13:04:49 --> UTF-8 Support Enabled
INFO - 2020-09-17 13:04:49 --> Utf8 Class Initialized
INFO - 2020-09-17 13:04:49 --> URI Class Initialized
INFO - 2020-09-17 13:04:49 --> Router Class Initialized
INFO - 2020-09-17 13:04:49 --> Output Class Initialized
INFO - 2020-09-17 13:04:49 --> Security Class Initialized
DEBUG - 2020-09-17 13:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 13:04:49 --> Input Class Initialized
INFO - 2020-09-17 13:04:49 --> Language Class Initialized
INFO - 2020-09-17 13:04:49 --> Loader Class Initialized
INFO - 2020-09-17 13:04:49 --> Helper loaded: html_helper
INFO - 2020-09-17 13:04:49 --> Helper loaded: url_helper
INFO - 2020-09-17 13:04:49 --> Helper loaded: form_helper
INFO - 2020-09-17 13:04:49 --> Database Driver Class Initialized
INFO - 2020-09-17 13:04:49 --> Form Validation Class Initialized
DEBUG - 2020-09-17 13:04:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 13:04:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 13:04:49 --> Encryption Class Initialized
INFO - 2020-09-17 13:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 13:04:49 --> Controller Class Initialized
INFO - 2020-09-17 13:04:50 --> Helper loaded: language_helper
INFO - 2020-09-17 13:04:50 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 13:04:50 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-17 13:04:50 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 13:04:50 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-17 13:04:50 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 13:04:50 --> Final output sent to browser
DEBUG - 2020-09-17 13:04:50 --> Total execution time: 1.0197
INFO - 2020-09-17 13:05:29 --> Config Class Initialized
INFO - 2020-09-17 13:05:29 --> Hooks Class Initialized
DEBUG - 2020-09-17 13:05:29 --> UTF-8 Support Enabled
INFO - 2020-09-17 13:05:29 --> Utf8 Class Initialized
INFO - 2020-09-17 13:05:29 --> URI Class Initialized
INFO - 2020-09-17 13:05:29 --> Router Class Initialized
INFO - 2020-09-17 13:05:29 --> Output Class Initialized
INFO - 2020-09-17 13:05:29 --> Security Class Initialized
DEBUG - 2020-09-17 13:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 13:05:29 --> Input Class Initialized
INFO - 2020-09-17 13:05:29 --> Language Class Initialized
INFO - 2020-09-17 13:05:29 --> Loader Class Initialized
INFO - 2020-09-17 13:05:29 --> Helper loaded: html_helper
INFO - 2020-09-17 13:05:29 --> Helper loaded: url_helper
INFO - 2020-09-17 13:05:30 --> Helper loaded: form_helper
INFO - 2020-09-17 13:05:30 --> Database Driver Class Initialized
INFO - 2020-09-17 13:05:30 --> Form Validation Class Initialized
DEBUG - 2020-09-17 13:05:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 13:05:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 13:05:30 --> Encryption Class Initialized
INFO - 2020-09-17 13:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 13:05:30 --> Controller Class Initialized
INFO - 2020-09-17 13:05:30 --> Helper loaded: language_helper
INFO - 2020-09-17 13:05:30 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 13:05:30 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-17 13:05:30 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 13:05:30 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-17 13:05:30 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 13:05:30 --> Final output sent to browser
DEBUG - 2020-09-17 13:05:30 --> Total execution time: 1.0556
INFO - 2020-09-17 13:05:35 --> Config Class Initialized
INFO - 2020-09-17 13:05:35 --> Hooks Class Initialized
DEBUG - 2020-09-17 13:05:35 --> UTF-8 Support Enabled
INFO - 2020-09-17 13:05:35 --> Utf8 Class Initialized
INFO - 2020-09-17 13:05:35 --> URI Class Initialized
INFO - 2020-09-17 13:05:35 --> Router Class Initialized
INFO - 2020-09-17 13:05:35 --> Output Class Initialized
INFO - 2020-09-17 13:05:36 --> Security Class Initialized
DEBUG - 2020-09-17 13:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 13:05:36 --> Input Class Initialized
INFO - 2020-09-17 13:05:36 --> Language Class Initialized
INFO - 2020-09-17 13:05:36 --> Loader Class Initialized
INFO - 2020-09-17 13:05:36 --> Helper loaded: html_helper
INFO - 2020-09-17 13:05:36 --> Helper loaded: url_helper
INFO - 2020-09-17 13:05:36 --> Helper loaded: form_helper
INFO - 2020-09-17 13:05:36 --> Database Driver Class Initialized
INFO - 2020-09-17 13:05:36 --> Form Validation Class Initialized
DEBUG - 2020-09-17 13:05:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-17 13:05:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-17 13:05:36 --> Encryption Class Initialized
INFO - 2020-09-17 13:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 13:05:36 --> Controller Class Initialized
INFO - 2020-09-17 13:05:36 --> Helper loaded: language_helper
INFO - 2020-09-17 13:05:36 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-17 13:05:36 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-17 13:05:36 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-17 13:05:36 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-17 13:05:36 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-17 13:05:36 --> Final output sent to browser
DEBUG - 2020-09-17 13:05:36 --> Total execution time: 1.0623
