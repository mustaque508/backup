<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-21 03:36:01 --> Config Class Initialized
INFO - 2020-09-21 03:36:01 --> Hooks Class Initialized
DEBUG - 2020-09-21 03:36:01 --> UTF-8 Support Enabled
INFO - 2020-09-21 03:36:01 --> Utf8 Class Initialized
INFO - 2020-09-21 03:36:02 --> URI Class Initialized
INFO - 2020-09-21 03:36:02 --> Router Class Initialized
INFO - 2020-09-21 03:36:02 --> Output Class Initialized
INFO - 2020-09-21 03:36:02 --> Security Class Initialized
DEBUG - 2020-09-21 03:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 03:36:02 --> Input Class Initialized
INFO - 2020-09-21 03:36:02 --> Language Class Initialized
INFO - 2020-09-21 03:36:02 --> Loader Class Initialized
INFO - 2020-09-21 03:36:02 --> Helper loaded: html_helper
INFO - 2020-09-21 03:36:02 --> Helper loaded: url_helper
INFO - 2020-09-21 03:36:02 --> Helper loaded: form_helper
INFO - 2020-09-21 03:36:03 --> Database Driver Class Initialized
INFO - 2020-09-21 03:36:03 --> Form Validation Class Initialized
DEBUG - 2020-09-21 03:36:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-21 03:36:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-21 03:36:03 --> Encryption Class Initialized
INFO - 2020-09-21 03:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 03:36:03 --> Controller Class Initialized
INFO - 2020-09-21 03:36:03 --> Helper loaded: language_helper
INFO - 2020-09-21 03:36:03 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-21 03:36:03 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-21 03:36:03 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-21 03:36:03 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\customer_care.php
INFO - 2020-09-21 03:36:04 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-21 03:36:04 --> Final output sent to browser
DEBUG - 2020-09-21 03:36:04 --> Total execution time: 2.4216
INFO - 2020-09-21 03:36:14 --> Config Class Initialized
INFO - 2020-09-21 03:36:14 --> Hooks Class Initialized
DEBUG - 2020-09-21 03:36:14 --> UTF-8 Support Enabled
INFO - 2020-09-21 03:36:14 --> Utf8 Class Initialized
INFO - 2020-09-21 03:36:14 --> URI Class Initialized
INFO - 2020-09-21 03:36:14 --> Router Class Initialized
INFO - 2020-09-21 03:36:14 --> Output Class Initialized
INFO - 2020-09-21 03:36:14 --> Security Class Initialized
DEBUG - 2020-09-21 03:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 03:36:15 --> Input Class Initialized
INFO - 2020-09-21 03:36:15 --> Language Class Initialized
INFO - 2020-09-21 03:36:15 --> Loader Class Initialized
INFO - 2020-09-21 03:36:15 --> Helper loaded: html_helper
INFO - 2020-09-21 03:36:15 --> Helper loaded: url_helper
INFO - 2020-09-21 03:36:15 --> Helper loaded: form_helper
INFO - 2020-09-21 03:36:15 --> Database Driver Class Initialized
INFO - 2020-09-21 03:36:15 --> Form Validation Class Initialized
DEBUG - 2020-09-21 03:36:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-21 03:36:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-21 03:36:15 --> Encryption Class Initialized
INFO - 2020-09-21 03:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 03:36:15 --> Controller Class Initialized
INFO - 2020-09-21 03:36:15 --> Helper loaded: language_helper
INFO - 2020-09-21 03:36:15 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-21 03:36:15 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-21 03:36:15 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-21 03:36:15 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment_custom.php
INFO - 2020-09-21 03:36:15 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-21 03:36:15 --> Final output sent to browser
DEBUG - 2020-09-21 03:36:15 --> Total execution time: 1.1105
INFO - 2020-09-21 11:29:55 --> Config Class Initialized
INFO - 2020-09-21 11:29:55 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:29:55 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:29:55 --> Utf8 Class Initialized
INFO - 2020-09-21 11:29:55 --> URI Class Initialized
INFO - 2020-09-21 11:29:55 --> Router Class Initialized
INFO - 2020-09-21 11:29:55 --> Output Class Initialized
INFO - 2020-09-21 11:29:55 --> Security Class Initialized
DEBUG - 2020-09-21 11:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:29:55 --> Input Class Initialized
INFO - 2020-09-21 11:29:55 --> Language Class Initialized
INFO - 2020-09-21 11:29:55 --> Loader Class Initialized
INFO - 2020-09-21 11:29:55 --> Helper loaded: html_helper
INFO - 2020-09-21 11:29:56 --> Helper loaded: url_helper
INFO - 2020-09-21 11:29:56 --> Helper loaded: form_helper
INFO - 2020-09-21 11:29:56 --> Database Driver Class Initialized
INFO - 2020-09-21 11:29:56 --> Form Validation Class Initialized
DEBUG - 2020-09-21 11:29:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-21 11:29:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-21 11:29:56 --> Encryption Class Initialized
INFO - 2020-09-21 11:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:29:56 --> Controller Class Initialized
INFO - 2020-09-21 11:29:56 --> Helper loaded: language_helper
INFO - 2020-09-21 11:29:56 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-21 11:29:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:29:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-21 11:29:56 --> Model "User" initialized
INFO - 2020-09-21 11:30:00 --> Config Class Initialized
INFO - 2020-09-21 11:30:00 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:30:00 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:30:01 --> Utf8 Class Initialized
INFO - 2020-09-21 11:30:01 --> URI Class Initialized
INFO - 2020-09-21 11:30:01 --> Router Class Initialized
INFO - 2020-09-21 11:30:01 --> Output Class Initialized
INFO - 2020-09-21 11:30:01 --> Security Class Initialized
DEBUG - 2020-09-21 11:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:30:01 --> Input Class Initialized
INFO - 2020-09-21 11:30:01 --> Language Class Initialized
INFO - 2020-09-21 11:30:01 --> Loader Class Initialized
INFO - 2020-09-21 11:30:01 --> Helper loaded: html_helper
INFO - 2020-09-21 11:30:01 --> Helper loaded: url_helper
INFO - 2020-09-21 11:30:01 --> Helper loaded: form_helper
INFO - 2020-09-21 11:30:01 --> Database Driver Class Initialized
INFO - 2020-09-21 11:30:01 --> Form Validation Class Initialized
DEBUG - 2020-09-21 11:30:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-21 11:30:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-21 11:30:01 --> Encryption Class Initialized
INFO - 2020-09-21 11:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:30:01 --> Controller Class Initialized
INFO - 2020-09-21 11:30:01 --> Helper loaded: language_helper
INFO - 2020-09-21 11:30:01 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-21 11:30:01 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-21 11:30:01 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-21 11:30:01 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-21 11:30:01 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-21 11:30:02 --> Final output sent to browser
DEBUG - 2020-09-21 11:30:02 --> Total execution time: 1.1591
INFO - 2020-09-21 11:30:20 --> Config Class Initialized
INFO - 2020-09-21 11:30:20 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:30:20 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:30:20 --> Utf8 Class Initialized
INFO - 2020-09-21 11:30:20 --> URI Class Initialized
INFO - 2020-09-21 11:30:20 --> Router Class Initialized
INFO - 2020-09-21 11:30:20 --> Output Class Initialized
INFO - 2020-09-21 11:30:20 --> Security Class Initialized
DEBUG - 2020-09-21 11:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:30:20 --> Input Class Initialized
INFO - 2020-09-21 11:30:20 --> Language Class Initialized
INFO - 2020-09-21 11:30:20 --> Loader Class Initialized
INFO - 2020-09-21 11:30:20 --> Helper loaded: html_helper
INFO - 2020-09-21 11:30:20 --> Helper loaded: url_helper
INFO - 2020-09-21 11:30:20 --> Helper loaded: form_helper
INFO - 2020-09-21 11:30:20 --> Database Driver Class Initialized
INFO - 2020-09-21 11:30:20 --> Form Validation Class Initialized
DEBUG - 2020-09-21 11:30:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-21 11:30:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-21 11:30:20 --> Encryption Class Initialized
INFO - 2020-09-21 11:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:30:21 --> Controller Class Initialized
INFO - 2020-09-21 11:30:21 --> Helper loaded: language_helper
INFO - 2020-09-21 11:30:21 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-21 11:30:21 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-21 11:30:21 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-21 11:30:21 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\installation.php
INFO - 2020-09-21 11:30:21 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-21 11:30:21 --> Final output sent to browser
DEBUG - 2020-09-21 11:30:21 --> Total execution time: 1.1863
INFO - 2020-09-21 11:30:32 --> Config Class Initialized
INFO - 2020-09-21 11:30:32 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:30:33 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:30:33 --> Utf8 Class Initialized
INFO - 2020-09-21 11:30:33 --> URI Class Initialized
INFO - 2020-09-21 11:30:33 --> Router Class Initialized
INFO - 2020-09-21 11:30:33 --> Output Class Initialized
INFO - 2020-09-21 11:30:33 --> Security Class Initialized
DEBUG - 2020-09-21 11:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:30:33 --> Input Class Initialized
INFO - 2020-09-21 11:30:33 --> Language Class Initialized
INFO - 2020-09-21 11:30:33 --> Loader Class Initialized
INFO - 2020-09-21 11:30:33 --> Helper loaded: html_helper
INFO - 2020-09-21 11:30:33 --> Helper loaded: url_helper
INFO - 2020-09-21 11:30:33 --> Helper loaded: form_helper
INFO - 2020-09-21 11:30:33 --> Database Driver Class Initialized
INFO - 2020-09-21 11:30:33 --> Form Validation Class Initialized
DEBUG - 2020-09-21 11:30:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-21 11:30:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-21 11:30:33 --> Encryption Class Initialized
INFO - 2020-09-21 11:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:30:33 --> Controller Class Initialized
INFO - 2020-09-21 11:30:33 --> Helper loaded: language_helper
INFO - 2020-09-21 11:30:33 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-21 11:30:33 --> Model "Installation_model" initialized
INFO - 2020-09-21 11:30:33 --> Final output sent to browser
DEBUG - 2020-09-21 11:30:33 --> Total execution time: 1.0160
INFO - 2020-09-21 12:03:14 --> Config Class Initialized
INFO - 2020-09-21 12:03:14 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:03:14 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:03:14 --> Utf8 Class Initialized
INFO - 2020-09-21 12:03:14 --> URI Class Initialized
INFO - 2020-09-21 12:03:14 --> Router Class Initialized
INFO - 2020-09-21 12:03:14 --> Output Class Initialized
INFO - 2020-09-21 12:03:14 --> Security Class Initialized
DEBUG - 2020-09-21 12:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:03:14 --> Input Class Initialized
INFO - 2020-09-21 12:03:14 --> Language Class Initialized
INFO - 2020-09-21 12:03:14 --> Loader Class Initialized
INFO - 2020-09-21 12:03:14 --> Helper loaded: html_helper
INFO - 2020-09-21 12:03:14 --> Helper loaded: url_helper
INFO - 2020-09-21 12:03:14 --> Helper loaded: form_helper
INFO - 2020-09-21 12:03:14 --> Database Driver Class Initialized
INFO - 2020-09-21 12:03:15 --> Form Validation Class Initialized
DEBUG - 2020-09-21 12:03:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-21 12:03:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-21 12:03:15 --> Encryption Class Initialized
INFO - 2020-09-21 12:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:03:15 --> Controller Class Initialized
INFO - 2020-09-21 12:03:15 --> Helper loaded: language_helper
INFO - 2020-09-21 12:03:15 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-21 12:03:15 --> Model "Installation_model" initialized
INFO - 2020-09-21 12:03:15 --> Final output sent to browser
DEBUG - 2020-09-21 12:03:15 --> Total execution time: 1.3300
INFO - 2020-09-21 12:03:23 --> Config Class Initialized
INFO - 2020-09-21 12:03:23 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:03:23 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:03:23 --> Utf8 Class Initialized
INFO - 2020-09-21 12:03:23 --> URI Class Initialized
INFO - 2020-09-21 12:03:23 --> Router Class Initialized
INFO - 2020-09-21 12:03:23 --> Output Class Initialized
INFO - 2020-09-21 12:03:23 --> Security Class Initialized
DEBUG - 2020-09-21 12:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:03:23 --> Input Class Initialized
INFO - 2020-09-21 12:03:23 --> Language Class Initialized
INFO - 2020-09-21 12:03:23 --> Loader Class Initialized
INFO - 2020-09-21 12:03:23 --> Helper loaded: html_helper
INFO - 2020-09-21 12:03:23 --> Helper loaded: url_helper
INFO - 2020-09-21 12:03:24 --> Helper loaded: form_helper
INFO - 2020-09-21 12:03:24 --> Database Driver Class Initialized
INFO - 2020-09-21 12:03:24 --> Form Validation Class Initialized
DEBUG - 2020-09-21 12:03:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-21 12:03:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-21 12:03:24 --> Encryption Class Initialized
INFO - 2020-09-21 12:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:03:24 --> Controller Class Initialized
INFO - 2020-09-21 12:03:24 --> Helper loaded: language_helper
INFO - 2020-09-21 12:03:24 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-21 12:03:24 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-21 12:03:24 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-21 12:03:24 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-21 12:03:24 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-21 12:03:24 --> Final output sent to browser
DEBUG - 2020-09-21 12:03:24 --> Total execution time: 1.2283
INFO - 2020-09-21 12:03:25 --> Config Class Initialized
INFO - 2020-09-21 12:03:25 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:03:25 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:03:25 --> Utf8 Class Initialized
INFO - 2020-09-21 12:03:25 --> URI Class Initialized
INFO - 2020-09-21 12:03:25 --> Router Class Initialized
INFO - 2020-09-21 12:03:25 --> Output Class Initialized
INFO - 2020-09-21 12:03:25 --> Security Class Initialized
DEBUG - 2020-09-21 12:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:03:25 --> Input Class Initialized
INFO - 2020-09-21 12:03:25 --> Language Class Initialized
INFO - 2020-09-21 12:03:25 --> Loader Class Initialized
INFO - 2020-09-21 12:03:25 --> Helper loaded: html_helper
INFO - 2020-09-21 12:03:25 --> Helper loaded: url_helper
INFO - 2020-09-21 12:03:25 --> Helper loaded: form_helper
INFO - 2020-09-21 12:03:25 --> Database Driver Class Initialized
INFO - 2020-09-21 12:03:25 --> Form Validation Class Initialized
DEBUG - 2020-09-21 12:03:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-21 12:03:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-21 12:03:25 --> Encryption Class Initialized
INFO - 2020-09-21 12:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:03:25 --> Controller Class Initialized
INFO - 2020-09-21 12:03:25 --> Helper loaded: language_helper
INFO - 2020-09-21 12:03:25 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-21 12:03:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-21 12:03:26 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-21 12:03:26 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment_custom.php
INFO - 2020-09-21 12:03:26 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-21 12:03:26 --> Final output sent to browser
DEBUG - 2020-09-21 12:03:26 --> Total execution time: 1.1155
INFO - 2020-09-21 12:03:33 --> Config Class Initialized
INFO - 2020-09-21 12:03:33 --> Config Class Initialized
INFO - 2020-09-21 12:03:33 --> Hooks Class Initialized
INFO - 2020-09-21 12:03:33 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:03:33 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:03:33 --> Utf8 Class Initialized
INFO - 2020-09-21 12:03:33 --> URI Class Initialized
DEBUG - 2020-09-21 12:03:33 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:03:33 --> Utf8 Class Initialized
INFO - 2020-09-21 12:03:33 --> Router Class Initialized
INFO - 2020-09-21 12:03:33 --> URI Class Initialized
INFO - 2020-09-21 12:03:33 --> Router Class Initialized
INFO - 2020-09-21 12:03:33 --> Output Class Initialized
INFO - 2020-09-21 12:03:34 --> Security Class Initialized
INFO - 2020-09-21 12:03:34 --> Output Class Initialized
INFO - 2020-09-21 12:03:34 --> Security Class Initialized
DEBUG - 2020-09-21 12:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:03:34 --> Input Class Initialized
DEBUG - 2020-09-21 12:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:03:34 --> Language Class Initialized
INFO - 2020-09-21 12:03:34 --> Input Class Initialized
INFO - 2020-09-21 12:03:34 --> Loader Class Initialized
INFO - 2020-09-21 12:03:34 --> Helper loaded: html_helper
INFO - 2020-09-21 12:03:34 --> Language Class Initialized
INFO - 2020-09-21 12:03:34 --> Loader Class Initialized
INFO - 2020-09-21 12:03:34 --> Helper loaded: url_helper
INFO - 2020-09-21 12:03:34 --> Helper loaded: form_helper
INFO - 2020-09-21 12:03:34 --> Helper loaded: html_helper
INFO - 2020-09-21 12:03:34 --> Helper loaded: url_helper
INFO - 2020-09-21 12:03:34 --> Database Driver Class Initialized
INFO - 2020-09-21 12:03:34 --> Helper loaded: form_helper
INFO - 2020-09-21 12:03:34 --> Form Validation Class Initialized
INFO - 2020-09-21 12:03:34 --> Database Driver Class Initialized
DEBUG - 2020-09-21 12:03:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-21 12:03:34 --> Form Validation Class Initialized
INFO - 2020-09-21 12:03:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-09-21 12:03:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-21 12:03:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-21 12:03:34 --> Encryption Class Initialized
INFO - 2020-09-21 12:03:34 --> Encryption Class Initialized
INFO - 2020-09-21 12:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:03:34 --> Controller Class Initialized
INFO - 2020-09-21 12:03:34 --> Helper loaded: language_helper
INFO - 2020-09-21 12:03:34 --> Language file loaded: language/english/content_lang.php
ERROR - 2020-09-21 12:03:34 --> Severity: Notice --> Undefined index: selected_order_id C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\controllers\Payment.php 184
INFO - 2020-09-21 12:03:37 --> Final output sent to browser
DEBUG - 2020-09-21 12:03:37 --> Total execution time: 3.4814
INFO - 2020-09-21 12:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:03:37 --> Controller Class Initialized
INFO - 2020-09-21 12:03:37 --> Helper loaded: language_helper
INFO - 2020-09-21 12:03:37 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-21 12:03:38 --> Final output sent to browser
DEBUG - 2020-09-21 12:03:38 --> Total execution time: 5.1054
