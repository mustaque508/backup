<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-14 06:37:18 --> Config Class Initialized
INFO - 2021-07-14 06:37:18 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:37:18 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:37:18 --> Utf8 Class Initialized
INFO - 2021-07-14 06:37:18 --> URI Class Initialized
DEBUG - 2021-07-14 06:37:18 --> No URI present. Default controller set.
INFO - 2021-07-14 06:37:18 --> Router Class Initialized
INFO - 2021-07-14 06:37:18 --> Output Class Initialized
INFO - 2021-07-14 06:37:18 --> Security Class Initialized
DEBUG - 2021-07-14 06:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:37:18 --> Input Class Initialized
INFO - 2021-07-14 06:37:18 --> Language Class Initialized
INFO - 2021-07-14 06:37:19 --> Loader Class Initialized
INFO - 2021-07-14 06:37:19 --> Helper loaded: html_helper
INFO - 2021-07-14 06:37:19 --> Helper loaded: url_helper
INFO - 2021-07-14 06:37:19 --> Helper loaded: form_helper
INFO - 2021-07-14 06:37:19 --> Database Driver Class Initialized
INFO - 2021-07-14 06:37:20 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:37:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:37:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:37:20 --> Encryption Class Initialized
INFO - 2021-07-14 06:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:37:20 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:37:20 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:37:20 --> Model "user_model" initialized
INFO - 2021-07-14 06:37:20 --> Model "role_model" initialized
INFO - 2021-07-14 06:37:20 --> Controller Class Initialized
INFO - 2021-07-14 06:37:20 --> Helper loaded: language_helper
INFO - 2021-07-14 06:37:20 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:37:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\login.php
INFO - 2021-07-14 06:37:21 --> Final output sent to browser
DEBUG - 2021-07-14 06:37:21 --> Total execution time: 3.1455
INFO - 2021-07-14 06:37:31 --> Config Class Initialized
INFO - 2021-07-14 06:37:31 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:37:31 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:37:31 --> Utf8 Class Initialized
INFO - 2021-07-14 06:37:31 --> URI Class Initialized
INFO - 2021-07-14 06:37:32 --> Router Class Initialized
INFO - 2021-07-14 06:37:32 --> Output Class Initialized
INFO - 2021-07-14 06:37:32 --> Security Class Initialized
DEBUG - 2021-07-14 06:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:37:32 --> Input Class Initialized
INFO - 2021-07-14 06:37:32 --> Language Class Initialized
INFO - 2021-07-14 06:37:32 --> Loader Class Initialized
INFO - 2021-07-14 06:37:32 --> Helper loaded: html_helper
INFO - 2021-07-14 06:37:32 --> Helper loaded: url_helper
INFO - 2021-07-14 06:37:32 --> Helper loaded: form_helper
INFO - 2021-07-14 06:37:32 --> Database Driver Class Initialized
INFO - 2021-07-14 06:37:32 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:37:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:37:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:37:32 --> Encryption Class Initialized
INFO - 2021-07-14 06:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:37:32 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:37:32 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:37:32 --> Model "user_model" initialized
INFO - 2021-07-14 06:37:32 --> Model "role_model" initialized
INFO - 2021-07-14 06:37:32 --> Controller Class Initialized
INFO - 2021-07-14 06:37:32 --> Helper loaded: language_helper
INFO - 2021-07-14 06:37:32 --> Language file loaded: language/english/content_lang.php
DEBUG - 2021-07-14 06:37:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-14 06:37:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-07-14 06:37:32 --> Model "User" initialized
INFO - 2021-07-14 06:37:33 --> Config Class Initialized
INFO - 2021-07-14 06:37:33 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:37:33 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:37:33 --> Utf8 Class Initialized
INFO - 2021-07-14 06:37:33 --> URI Class Initialized
INFO - 2021-07-14 06:37:33 --> Router Class Initialized
INFO - 2021-07-14 06:37:33 --> Output Class Initialized
INFO - 2021-07-14 06:37:33 --> Security Class Initialized
DEBUG - 2021-07-14 06:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:37:33 --> Input Class Initialized
INFO - 2021-07-14 06:37:33 --> Language Class Initialized
INFO - 2021-07-14 06:37:33 --> Loader Class Initialized
INFO - 2021-07-14 06:37:33 --> Helper loaded: html_helper
INFO - 2021-07-14 06:37:33 --> Helper loaded: url_helper
INFO - 2021-07-14 06:37:33 --> Helper loaded: form_helper
INFO - 2021-07-14 06:37:33 --> Database Driver Class Initialized
INFO - 2021-07-14 06:37:33 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:37:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:37:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:37:33 --> Encryption Class Initialized
INFO - 2021-07-14 06:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:37:33 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:37:33 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:37:33 --> Model "user_model" initialized
INFO - 2021-07-14 06:37:33 --> Model "role_model" initialized
INFO - 2021-07-14 06:37:33 --> Controller Class Initialized
INFO - 2021-07-14 06:37:33 --> Helper loaded: language_helper
INFO - 2021-07-14 06:37:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:37:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-14 06:37:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-14 06:37:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-14 06:37:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 06:37:33 --> Final output sent to browser
DEBUG - 2021-07-14 06:37:33 --> Total execution time: 0.2376
INFO - 2021-07-14 06:37:51 --> Config Class Initialized
INFO - 2021-07-14 06:37:51 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:37:51 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:37:51 --> Utf8 Class Initialized
INFO - 2021-07-14 06:37:51 --> URI Class Initialized
INFO - 2021-07-14 06:37:51 --> Router Class Initialized
INFO - 2021-07-14 06:37:51 --> Output Class Initialized
INFO - 2021-07-14 06:37:51 --> Security Class Initialized
DEBUG - 2021-07-14 06:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:37:51 --> Input Class Initialized
INFO - 2021-07-14 06:37:51 --> Language Class Initialized
INFO - 2021-07-14 06:37:51 --> Loader Class Initialized
INFO - 2021-07-14 06:37:51 --> Helper loaded: html_helper
INFO - 2021-07-14 06:37:51 --> Helper loaded: url_helper
INFO - 2021-07-14 06:37:51 --> Helper loaded: form_helper
INFO - 2021-07-14 06:37:51 --> Database Driver Class Initialized
INFO - 2021-07-14 06:37:51 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:37:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:37:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:37:51 --> Encryption Class Initialized
INFO - 2021-07-14 06:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:37:51 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:37:51 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:37:51 --> Model "user_model" initialized
INFO - 2021-07-14 06:37:51 --> Model "role_model" initialized
INFO - 2021-07-14 06:37:51 --> Controller Class Initialized
INFO - 2021-07-14 06:37:51 --> Helper loaded: language_helper
INFO - 2021-07-14 06:37:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:37:51 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:37:51 --> Model "Customer_model" initialized
INFO - 2021-07-14 06:37:51 --> Model "Product_model" initialized
INFO - 2021-07-14 06:37:51 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 06:37:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 06:37:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 06:37:51 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 06:37:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 06:37:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 06:37:51 --> Final output sent to browser
DEBUG - 2021-07-14 06:37:51 --> Total execution time: 0.3295
INFO - 2021-07-14 06:38:00 --> Config Class Initialized
INFO - 2021-07-14 06:38:00 --> Config Class Initialized
INFO - 2021-07-14 06:38:00 --> Hooks Class Initialized
INFO - 2021-07-14 06:38:00 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:38:00 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 06:38:00 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:38:00 --> Utf8 Class Initialized
INFO - 2021-07-14 06:38:00 --> Utf8 Class Initialized
INFO - 2021-07-14 06:38:00 --> URI Class Initialized
INFO - 2021-07-14 06:38:00 --> URI Class Initialized
INFO - 2021-07-14 06:38:00 --> Router Class Initialized
INFO - 2021-07-14 06:38:00 --> Router Class Initialized
INFO - 2021-07-14 06:38:00 --> Output Class Initialized
INFO - 2021-07-14 06:38:00 --> Output Class Initialized
INFO - 2021-07-14 06:38:00 --> Security Class Initialized
INFO - 2021-07-14 06:38:00 --> Security Class Initialized
DEBUG - 2021-07-14 06:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 06:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:38:00 --> Input Class Initialized
INFO - 2021-07-14 06:38:00 --> Input Class Initialized
INFO - 2021-07-14 06:38:00 --> Language Class Initialized
INFO - 2021-07-14 06:38:00 --> Language Class Initialized
INFO - 2021-07-14 06:38:00 --> Loader Class Initialized
INFO - 2021-07-14 06:38:00 --> Loader Class Initialized
INFO - 2021-07-14 06:38:00 --> Helper loaded: html_helper
INFO - 2021-07-14 06:38:00 --> Helper loaded: html_helper
INFO - 2021-07-14 06:38:00 --> Helper loaded: url_helper
INFO - 2021-07-14 06:38:00 --> Helper loaded: url_helper
INFO - 2021-07-14 06:38:00 --> Helper loaded: form_helper
INFO - 2021-07-14 06:38:00 --> Helper loaded: form_helper
INFO - 2021-07-14 06:38:00 --> Database Driver Class Initialized
INFO - 2021-07-14 06:38:00 --> Database Driver Class Initialized
INFO - 2021-07-14 06:38:00 --> Form Validation Class Initialized
INFO - 2021-07-14 06:38:00 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:38:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:38:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:38:00 --> Encryption Class Initialized
DEBUG - 2021-07-14 06:38:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:38:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:38:00 --> Encryption Class Initialized
INFO - 2021-07-14 06:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:38:00 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:38:00 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:38:00 --> Model "user_model" initialized
INFO - 2021-07-14 06:38:00 --> Model "role_model" initialized
INFO - 2021-07-14 06:38:00 --> Controller Class Initialized
INFO - 2021-07-14 06:38:00 --> Helper loaded: language_helper
INFO - 2021-07-14 06:38:00 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:38:00 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:38:00 --> Final output sent to browser
DEBUG - 2021-07-14 06:38:00 --> Total execution time: 0.0888
INFO - 2021-07-14 06:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:38:00 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:38:00 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:38:00 --> Model "user_model" initialized
INFO - 2021-07-14 06:38:00 --> Model "role_model" initialized
INFO - 2021-07-14 06:38:00 --> Controller Class Initialized
INFO - 2021-07-14 06:38:00 --> Helper loaded: language_helper
INFO - 2021-07-14 06:38:00 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:38:00 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:38:00 --> Final output sent to browser
DEBUG - 2021-07-14 06:38:00 --> Total execution time: 0.0986
INFO - 2021-07-14 06:39:27 --> Config Class Initialized
INFO - 2021-07-14 06:39:27 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:39:27 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:39:27 --> Utf8 Class Initialized
INFO - 2021-07-14 06:39:27 --> URI Class Initialized
INFO - 2021-07-14 06:39:27 --> Router Class Initialized
INFO - 2021-07-14 06:39:27 --> Output Class Initialized
INFO - 2021-07-14 06:39:27 --> Security Class Initialized
DEBUG - 2021-07-14 06:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:39:27 --> Input Class Initialized
INFO - 2021-07-14 06:39:27 --> Language Class Initialized
INFO - 2021-07-14 06:39:27 --> Loader Class Initialized
INFO - 2021-07-14 06:39:27 --> Helper loaded: html_helper
INFO - 2021-07-14 06:39:27 --> Helper loaded: url_helper
INFO - 2021-07-14 06:39:27 --> Helper loaded: form_helper
INFO - 2021-07-14 06:39:27 --> Database Driver Class Initialized
INFO - 2021-07-14 06:39:27 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:39:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:39:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:39:27 --> Encryption Class Initialized
INFO - 2021-07-14 06:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:39:27 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:39:27 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:39:27 --> Model "user_model" initialized
INFO - 2021-07-14 06:39:27 --> Model "role_model" initialized
INFO - 2021-07-14 06:39:27 --> Controller Class Initialized
INFO - 2021-07-14 06:39:27 --> Helper loaded: language_helper
INFO - 2021-07-14 06:39:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:39:27 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:39:27 --> Model "Customer_model" initialized
INFO - 2021-07-14 06:39:27 --> Model "Product_model" initialized
INFO - 2021-07-14 06:39:27 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 06:39:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 06:39:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 06:39:27 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 06:39:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 06:39:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 06:39:27 --> Final output sent to browser
DEBUG - 2021-07-14 06:39:27 --> Total execution time: 0.7816
INFO - 2021-07-14 06:39:34 --> Config Class Initialized
INFO - 2021-07-14 06:39:34 --> Config Class Initialized
INFO - 2021-07-14 06:39:34 --> Hooks Class Initialized
INFO - 2021-07-14 06:39:34 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:39:34 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 06:39:34 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:39:34 --> Utf8 Class Initialized
INFO - 2021-07-14 06:39:34 --> Utf8 Class Initialized
INFO - 2021-07-14 06:39:34 --> URI Class Initialized
INFO - 2021-07-14 06:39:34 --> URI Class Initialized
INFO - 2021-07-14 06:39:34 --> Router Class Initialized
INFO - 2021-07-14 06:39:34 --> Router Class Initialized
INFO - 2021-07-14 06:39:34 --> Output Class Initialized
INFO - 2021-07-14 06:39:34 --> Output Class Initialized
INFO - 2021-07-14 06:39:34 --> Security Class Initialized
INFO - 2021-07-14 06:39:34 --> Security Class Initialized
DEBUG - 2021-07-14 06:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:39:34 --> Input Class Initialized
DEBUG - 2021-07-14 06:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:39:34 --> Input Class Initialized
INFO - 2021-07-14 06:39:34 --> Language Class Initialized
INFO - 2021-07-14 06:39:34 --> Language Class Initialized
INFO - 2021-07-14 06:39:34 --> Loader Class Initialized
INFO - 2021-07-14 06:39:34 --> Loader Class Initialized
INFO - 2021-07-14 06:39:34 --> Helper loaded: html_helper
INFO - 2021-07-14 06:39:34 --> Helper loaded: html_helper
INFO - 2021-07-14 06:39:34 --> Helper loaded: url_helper
INFO - 2021-07-14 06:39:34 --> Helper loaded: url_helper
INFO - 2021-07-14 06:39:34 --> Helper loaded: form_helper
INFO - 2021-07-14 06:39:34 --> Helper loaded: form_helper
INFO - 2021-07-14 06:39:34 --> Database Driver Class Initialized
INFO - 2021-07-14 06:39:34 --> Database Driver Class Initialized
INFO - 2021-07-14 06:39:34 --> Form Validation Class Initialized
INFO - 2021-07-14 06:39:34 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:39:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:39:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:39:34 --> Encryption Class Initialized
DEBUG - 2021-07-14 06:39:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:39:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:39:34 --> Encryption Class Initialized
INFO - 2021-07-14 06:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:39:34 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:39:34 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:39:34 --> Model "user_model" initialized
INFO - 2021-07-14 06:39:34 --> Model "role_model" initialized
INFO - 2021-07-14 06:39:34 --> Controller Class Initialized
INFO - 2021-07-14 06:39:34 --> Helper loaded: language_helper
INFO - 2021-07-14 06:39:34 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:39:34 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:39:34 --> Final output sent to browser
DEBUG - 2021-07-14 06:39:34 --> Total execution time: 0.0615
INFO - 2021-07-14 06:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:39:34 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:39:34 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:39:34 --> Model "user_model" initialized
INFO - 2021-07-14 06:39:34 --> Model "role_model" initialized
INFO - 2021-07-14 06:39:34 --> Controller Class Initialized
INFO - 2021-07-14 06:39:34 --> Helper loaded: language_helper
INFO - 2021-07-14 06:39:34 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:39:34 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:39:34 --> Final output sent to browser
DEBUG - 2021-07-14 06:39:34 --> Total execution time: 0.0733
INFO - 2021-07-14 06:39:35 --> Config Class Initialized
INFO - 2021-07-14 06:39:35 --> Config Class Initialized
INFO - 2021-07-14 06:39:35 --> Hooks Class Initialized
INFO - 2021-07-14 06:39:35 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:39:35 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 06:39:35 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:39:35 --> Utf8 Class Initialized
INFO - 2021-07-14 06:39:35 --> Utf8 Class Initialized
INFO - 2021-07-14 06:39:35 --> URI Class Initialized
INFO - 2021-07-14 06:39:35 --> URI Class Initialized
INFO - 2021-07-14 06:39:35 --> Router Class Initialized
INFO - 2021-07-14 06:39:35 --> Router Class Initialized
INFO - 2021-07-14 06:39:35 --> Output Class Initialized
INFO - 2021-07-14 06:39:35 --> Output Class Initialized
INFO - 2021-07-14 06:39:35 --> Security Class Initialized
INFO - 2021-07-14 06:39:35 --> Security Class Initialized
DEBUG - 2021-07-14 06:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 06:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:39:35 --> Input Class Initialized
INFO - 2021-07-14 06:39:35 --> Input Class Initialized
INFO - 2021-07-14 06:39:35 --> Language Class Initialized
INFO - 2021-07-14 06:39:35 --> Language Class Initialized
INFO - 2021-07-14 06:39:35 --> Loader Class Initialized
INFO - 2021-07-14 06:39:35 --> Loader Class Initialized
INFO - 2021-07-14 06:39:35 --> Helper loaded: html_helper
INFO - 2021-07-14 06:39:35 --> Helper loaded: html_helper
INFO - 2021-07-14 06:39:35 --> Helper loaded: url_helper
INFO - 2021-07-14 06:39:35 --> Helper loaded: url_helper
INFO - 2021-07-14 06:39:35 --> Helper loaded: form_helper
INFO - 2021-07-14 06:39:35 --> Helper loaded: form_helper
INFO - 2021-07-14 06:39:35 --> Database Driver Class Initialized
INFO - 2021-07-14 06:39:35 --> Database Driver Class Initialized
INFO - 2021-07-14 06:39:35 --> Form Validation Class Initialized
INFO - 2021-07-14 06:39:35 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:39:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:39:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2021-07-14 06:39:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:39:35 --> Encryption Class Initialized
INFO - 2021-07-14 06:39:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:39:35 --> Encryption Class Initialized
INFO - 2021-07-14 06:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:39:35 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:39:35 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:39:35 --> Model "user_model" initialized
INFO - 2021-07-14 06:39:35 --> Model "role_model" initialized
INFO - 2021-07-14 06:39:35 --> Controller Class Initialized
INFO - 2021-07-14 06:39:35 --> Helper loaded: language_helper
INFO - 2021-07-14 06:39:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:39:35 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:39:35 --> Final output sent to browser
DEBUG - 2021-07-14 06:39:35 --> Total execution time: 0.0703
INFO - 2021-07-14 06:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:39:35 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:39:35 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:39:35 --> Model "user_model" initialized
INFO - 2021-07-14 06:39:35 --> Model "role_model" initialized
INFO - 2021-07-14 06:39:35 --> Controller Class Initialized
INFO - 2021-07-14 06:39:35 --> Helper loaded: language_helper
INFO - 2021-07-14 06:39:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:39:35 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:39:35 --> Final output sent to browser
DEBUG - 2021-07-14 06:39:35 --> Total execution time: 0.0815
INFO - 2021-07-14 06:39:38 --> Config Class Initialized
INFO - 2021-07-14 06:39:38 --> Hooks Class Initialized
INFO - 2021-07-14 06:39:38 --> Config Class Initialized
INFO - 2021-07-14 06:39:38 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:39:38 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:39:38 --> Utf8 Class Initialized
DEBUG - 2021-07-14 06:39:38 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:39:38 --> Utf8 Class Initialized
INFO - 2021-07-14 06:39:38 --> URI Class Initialized
INFO - 2021-07-14 06:39:38 --> URI Class Initialized
INFO - 2021-07-14 06:39:38 --> Router Class Initialized
INFO - 2021-07-14 06:39:38 --> Router Class Initialized
INFO - 2021-07-14 06:39:38 --> Output Class Initialized
INFO - 2021-07-14 06:39:38 --> Output Class Initialized
INFO - 2021-07-14 06:39:38 --> Security Class Initialized
INFO - 2021-07-14 06:39:38 --> Security Class Initialized
DEBUG - 2021-07-14 06:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 06:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:39:38 --> Input Class Initialized
INFO - 2021-07-14 06:39:38 --> Input Class Initialized
INFO - 2021-07-14 06:39:38 --> Language Class Initialized
INFO - 2021-07-14 06:39:38 --> Language Class Initialized
INFO - 2021-07-14 06:39:38 --> Loader Class Initialized
INFO - 2021-07-14 06:39:38 --> Loader Class Initialized
INFO - 2021-07-14 06:39:38 --> Helper loaded: html_helper
INFO - 2021-07-14 06:39:38 --> Helper loaded: html_helper
INFO - 2021-07-14 06:39:38 --> Helper loaded: url_helper
INFO - 2021-07-14 06:39:38 --> Helper loaded: url_helper
INFO - 2021-07-14 06:39:38 --> Helper loaded: form_helper
INFO - 2021-07-14 06:39:38 --> Helper loaded: form_helper
INFO - 2021-07-14 06:39:38 --> Database Driver Class Initialized
INFO - 2021-07-14 06:39:38 --> Database Driver Class Initialized
INFO - 2021-07-14 06:39:38 --> Form Validation Class Initialized
INFO - 2021-07-14 06:39:38 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-14 06:39:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:39:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:39:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:39:38 --> Encryption Class Initialized
INFO - 2021-07-14 06:39:38 --> Encryption Class Initialized
INFO - 2021-07-14 06:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:39:38 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:39:38 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:39:38 --> Model "user_model" initialized
INFO - 2021-07-14 06:39:38 --> Model "role_model" initialized
INFO - 2021-07-14 06:39:38 --> Controller Class Initialized
INFO - 2021-07-14 06:39:38 --> Helper loaded: language_helper
INFO - 2021-07-14 06:39:38 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:39:38 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:39:38 --> Final output sent to browser
DEBUG - 2021-07-14 06:39:38 --> Total execution time: 0.2664
INFO - 2021-07-14 06:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:39:38 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:39:38 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:39:38 --> Model "user_model" initialized
INFO - 2021-07-14 06:39:38 --> Model "role_model" initialized
INFO - 2021-07-14 06:39:38 --> Controller Class Initialized
INFO - 2021-07-14 06:39:38 --> Helper loaded: language_helper
INFO - 2021-07-14 06:39:38 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:39:38 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:39:38 --> Final output sent to browser
DEBUG - 2021-07-14 06:39:38 --> Total execution time: 0.2786
INFO - 2021-07-14 06:41:04 --> Config Class Initialized
INFO - 2021-07-14 06:41:04 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:41:04 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:41:04 --> Utf8 Class Initialized
INFO - 2021-07-14 06:41:04 --> URI Class Initialized
INFO - 2021-07-14 06:41:04 --> Router Class Initialized
INFO - 2021-07-14 06:41:04 --> Output Class Initialized
INFO - 2021-07-14 06:41:04 --> Security Class Initialized
DEBUG - 2021-07-14 06:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:41:04 --> Input Class Initialized
INFO - 2021-07-14 06:41:04 --> Language Class Initialized
INFO - 2021-07-14 06:41:04 --> Loader Class Initialized
INFO - 2021-07-14 06:41:04 --> Helper loaded: html_helper
INFO - 2021-07-14 06:41:04 --> Helper loaded: url_helper
INFO - 2021-07-14 06:41:04 --> Helper loaded: form_helper
INFO - 2021-07-14 06:41:04 --> Database Driver Class Initialized
INFO - 2021-07-14 06:41:04 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:41:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:41:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:41:04 --> Encryption Class Initialized
INFO - 2021-07-14 06:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:41:04 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:41:04 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:41:04 --> Model "user_model" initialized
INFO - 2021-07-14 06:41:04 --> Model "role_model" initialized
INFO - 2021-07-14 06:41:04 --> Controller Class Initialized
INFO - 2021-07-14 06:41:04 --> Helper loaded: language_helper
INFO - 2021-07-14 06:41:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:41:04 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:41:04 --> Model "Customer_model" initialized
INFO - 2021-07-14 06:41:04 --> Model "Product_model" initialized
INFO - 2021-07-14 06:41:04 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 06:41:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 06:41:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 06:41:04 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 06:41:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 06:41:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 06:41:04 --> Final output sent to browser
DEBUG - 2021-07-14 06:41:04 --> Total execution time: 0.1234
INFO - 2021-07-14 06:41:07 --> Config Class Initialized
INFO - 2021-07-14 06:41:07 --> Hooks Class Initialized
INFO - 2021-07-14 06:41:07 --> Config Class Initialized
INFO - 2021-07-14 06:41:07 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:41:07 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:41:07 --> Utf8 Class Initialized
INFO - 2021-07-14 06:41:07 --> URI Class Initialized
DEBUG - 2021-07-14 06:41:07 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:41:07 --> Utf8 Class Initialized
INFO - 2021-07-14 06:41:07 --> Router Class Initialized
INFO - 2021-07-14 06:41:07 --> URI Class Initialized
INFO - 2021-07-14 06:41:07 --> Output Class Initialized
INFO - 2021-07-14 06:41:07 --> Router Class Initialized
INFO - 2021-07-14 06:41:07 --> Security Class Initialized
INFO - 2021-07-14 06:41:07 --> Output Class Initialized
DEBUG - 2021-07-14 06:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:41:07 --> Input Class Initialized
INFO - 2021-07-14 06:41:07 --> Language Class Initialized
INFO - 2021-07-14 06:41:07 --> Security Class Initialized
DEBUG - 2021-07-14 06:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:41:07 --> Input Class Initialized
INFO - 2021-07-14 06:41:07 --> Language Class Initialized
INFO - 2021-07-14 06:41:07 --> Loader Class Initialized
INFO - 2021-07-14 06:41:07 --> Helper loaded: html_helper
INFO - 2021-07-14 06:41:07 --> Loader Class Initialized
INFO - 2021-07-14 06:41:07 --> Helper loaded: url_helper
INFO - 2021-07-14 06:41:07 --> Helper loaded: html_helper
INFO - 2021-07-14 06:41:07 --> Helper loaded: form_helper
INFO - 2021-07-14 06:41:07 --> Helper loaded: url_helper
INFO - 2021-07-14 06:41:07 --> Helper loaded: form_helper
INFO - 2021-07-14 06:41:07 --> Database Driver Class Initialized
INFO - 2021-07-14 06:41:07 --> Database Driver Class Initialized
INFO - 2021-07-14 06:41:07 --> Form Validation Class Initialized
INFO - 2021-07-14 06:41:07 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:41:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:41:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:41:07 --> Encryption Class Initialized
DEBUG - 2021-07-14 06:41:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:41:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:41:07 --> Encryption Class Initialized
INFO - 2021-07-14 06:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:41:07 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:41:07 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:41:07 --> Model "user_model" initialized
INFO - 2021-07-14 06:41:07 --> Model "role_model" initialized
INFO - 2021-07-14 06:41:07 --> Controller Class Initialized
INFO - 2021-07-14 06:41:07 --> Helper loaded: language_helper
INFO - 2021-07-14 06:41:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:41:07 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:41:07 --> Final output sent to browser
DEBUG - 2021-07-14 06:41:07 --> Total execution time: 0.0735
INFO - 2021-07-14 06:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:41:07 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:41:07 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:41:07 --> Model "user_model" initialized
INFO - 2021-07-14 06:41:07 --> Model "role_model" initialized
INFO - 2021-07-14 06:41:07 --> Controller Class Initialized
INFO - 2021-07-14 06:41:07 --> Helper loaded: language_helper
INFO - 2021-07-14 06:41:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:41:08 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:41:08 --> Final output sent to browser
DEBUG - 2021-07-14 06:41:08 --> Total execution time: 0.0828
INFO - 2021-07-14 06:41:59 --> Config Class Initialized
INFO - 2021-07-14 06:41:59 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:41:59 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:41:59 --> Utf8 Class Initialized
INFO - 2021-07-14 06:41:59 --> URI Class Initialized
INFO - 2021-07-14 06:41:59 --> Router Class Initialized
INFO - 2021-07-14 06:41:59 --> Output Class Initialized
INFO - 2021-07-14 06:41:59 --> Security Class Initialized
DEBUG - 2021-07-14 06:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:41:59 --> Input Class Initialized
INFO - 2021-07-14 06:41:59 --> Language Class Initialized
INFO - 2021-07-14 06:41:59 --> Loader Class Initialized
INFO - 2021-07-14 06:41:59 --> Helper loaded: html_helper
INFO - 2021-07-14 06:41:59 --> Helper loaded: url_helper
INFO - 2021-07-14 06:41:59 --> Helper loaded: form_helper
INFO - 2021-07-14 06:41:59 --> Database Driver Class Initialized
INFO - 2021-07-14 06:42:00 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:42:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:42:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:42:00 --> Encryption Class Initialized
INFO - 2021-07-14 06:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:42:00 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:42:00 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:42:00 --> Model "user_model" initialized
INFO - 2021-07-14 06:42:00 --> Model "role_model" initialized
INFO - 2021-07-14 06:42:00 --> Controller Class Initialized
INFO - 2021-07-14 06:42:00 --> Helper loaded: language_helper
INFO - 2021-07-14 06:42:00 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:42:00 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:42:00 --> Model "Customer_model" initialized
INFO - 2021-07-14 06:42:00 --> Model "Product_model" initialized
INFO - 2021-07-14 06:42:00 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 06:42:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 06:42:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 06:42:00 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 06:42:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 06:42:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 06:42:00 --> Final output sent to browser
DEBUG - 2021-07-14 06:42:00 --> Total execution time: 0.9096
INFO - 2021-07-14 06:42:04 --> Config Class Initialized
INFO - 2021-07-14 06:42:04 --> Config Class Initialized
INFO - 2021-07-14 06:42:04 --> Hooks Class Initialized
INFO - 2021-07-14 06:42:04 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:42:04 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 06:42:04 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:42:04 --> Utf8 Class Initialized
INFO - 2021-07-14 06:42:04 --> Utf8 Class Initialized
INFO - 2021-07-14 06:42:04 --> URI Class Initialized
INFO - 2021-07-14 06:42:04 --> URI Class Initialized
INFO - 2021-07-14 06:42:04 --> Router Class Initialized
INFO - 2021-07-14 06:42:04 --> Router Class Initialized
INFO - 2021-07-14 06:42:04 --> Output Class Initialized
INFO - 2021-07-14 06:42:04 --> Output Class Initialized
INFO - 2021-07-14 06:42:04 --> Security Class Initialized
INFO - 2021-07-14 06:42:04 --> Security Class Initialized
DEBUG - 2021-07-14 06:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 06:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:42:04 --> Input Class Initialized
INFO - 2021-07-14 06:42:04 --> Input Class Initialized
INFO - 2021-07-14 06:42:04 --> Language Class Initialized
INFO - 2021-07-14 06:42:04 --> Language Class Initialized
INFO - 2021-07-14 06:42:04 --> Loader Class Initialized
INFO - 2021-07-14 06:42:04 --> Loader Class Initialized
INFO - 2021-07-14 06:42:04 --> Helper loaded: html_helper
INFO - 2021-07-14 06:42:04 --> Helper loaded: html_helper
INFO - 2021-07-14 06:42:04 --> Helper loaded: url_helper
INFO - 2021-07-14 06:42:04 --> Helper loaded: url_helper
INFO - 2021-07-14 06:42:04 --> Helper loaded: form_helper
INFO - 2021-07-14 06:42:04 --> Helper loaded: form_helper
INFO - 2021-07-14 06:42:04 --> Database Driver Class Initialized
INFO - 2021-07-14 06:42:04 --> Database Driver Class Initialized
INFO - 2021-07-14 06:42:04 --> Form Validation Class Initialized
INFO - 2021-07-14 06:42:04 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-14 06:42:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:42:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:42:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:42:04 --> Encryption Class Initialized
INFO - 2021-07-14 06:42:04 --> Encryption Class Initialized
INFO - 2021-07-14 06:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:42:04 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:42:04 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:42:04 --> Model "user_model" initialized
INFO - 2021-07-14 06:42:04 --> Model "role_model" initialized
INFO - 2021-07-14 06:42:04 --> Controller Class Initialized
INFO - 2021-07-14 06:42:04 --> Helper loaded: language_helper
INFO - 2021-07-14 06:42:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:42:04 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:42:04 --> Final output sent to browser
DEBUG - 2021-07-14 06:42:04 --> Total execution time: 0.0740
INFO - 2021-07-14 06:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:42:04 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:42:04 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:42:04 --> Model "user_model" initialized
INFO - 2021-07-14 06:42:04 --> Model "role_model" initialized
INFO - 2021-07-14 06:42:04 --> Controller Class Initialized
INFO - 2021-07-14 06:42:04 --> Helper loaded: language_helper
INFO - 2021-07-14 06:42:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:42:04 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:42:04 --> Final output sent to browser
DEBUG - 2021-07-14 06:42:04 --> Total execution time: 0.0857
INFO - 2021-07-14 06:47:00 --> Config Class Initialized
INFO - 2021-07-14 06:47:00 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:47:00 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:47:00 --> Utf8 Class Initialized
INFO - 2021-07-14 06:47:00 --> URI Class Initialized
INFO - 2021-07-14 06:47:00 --> Router Class Initialized
INFO - 2021-07-14 06:47:00 --> Output Class Initialized
INFO - 2021-07-14 06:47:00 --> Security Class Initialized
DEBUG - 2021-07-14 06:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:47:00 --> Input Class Initialized
INFO - 2021-07-14 06:47:00 --> Language Class Initialized
INFO - 2021-07-14 06:47:00 --> Loader Class Initialized
INFO - 2021-07-14 06:47:00 --> Helper loaded: html_helper
INFO - 2021-07-14 06:47:00 --> Helper loaded: url_helper
INFO - 2021-07-14 06:47:00 --> Helper loaded: form_helper
INFO - 2021-07-14 06:47:01 --> Database Driver Class Initialized
INFO - 2021-07-14 06:47:01 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:47:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:47:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:47:01 --> Encryption Class Initialized
INFO - 2021-07-14 06:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:47:01 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:47:01 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:47:01 --> Model "user_model" initialized
INFO - 2021-07-14 06:47:01 --> Model "role_model" initialized
INFO - 2021-07-14 06:47:01 --> Controller Class Initialized
INFO - 2021-07-14 06:47:02 --> Helper loaded: language_helper
INFO - 2021-07-14 06:47:02 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:47:02 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:47:02 --> Model "Customer_model" initialized
INFO - 2021-07-14 06:47:02 --> Model "Product_model" initialized
INFO - 2021-07-14 06:47:02 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 06:47:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 06:47:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 06:47:02 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 06:47:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 06:47:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 06:47:02 --> Final output sent to browser
DEBUG - 2021-07-14 06:47:02 --> Total execution time: 2.4680
INFO - 2021-07-14 06:47:08 --> Config Class Initialized
INFO - 2021-07-14 06:47:08 --> Hooks Class Initialized
INFO - 2021-07-14 06:47:08 --> Config Class Initialized
INFO - 2021-07-14 06:47:08 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:47:08 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:47:08 --> Utf8 Class Initialized
DEBUG - 2021-07-14 06:47:08 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:47:08 --> Utf8 Class Initialized
INFO - 2021-07-14 06:47:08 --> URI Class Initialized
INFO - 2021-07-14 06:47:08 --> URI Class Initialized
INFO - 2021-07-14 06:47:08 --> Router Class Initialized
INFO - 2021-07-14 06:47:08 --> Router Class Initialized
INFO - 2021-07-14 06:47:08 --> Output Class Initialized
INFO - 2021-07-14 06:47:08 --> Output Class Initialized
INFO - 2021-07-14 06:47:08 --> Security Class Initialized
INFO - 2021-07-14 06:47:08 --> Security Class Initialized
DEBUG - 2021-07-14 06:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 06:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:47:08 --> Input Class Initialized
INFO - 2021-07-14 06:47:08 --> Input Class Initialized
INFO - 2021-07-14 06:47:08 --> Language Class Initialized
INFO - 2021-07-14 06:47:08 --> Language Class Initialized
INFO - 2021-07-14 06:47:08 --> Loader Class Initialized
INFO - 2021-07-14 06:47:08 --> Loader Class Initialized
INFO - 2021-07-14 06:47:08 --> Helper loaded: html_helper
INFO - 2021-07-14 06:47:08 --> Helper loaded: html_helper
INFO - 2021-07-14 06:47:08 --> Helper loaded: url_helper
INFO - 2021-07-14 06:47:08 --> Helper loaded: url_helper
INFO - 2021-07-14 06:47:08 --> Helper loaded: form_helper
INFO - 2021-07-14 06:47:08 --> Helper loaded: form_helper
INFO - 2021-07-14 06:47:08 --> Database Driver Class Initialized
INFO - 2021-07-14 06:47:08 --> Database Driver Class Initialized
INFO - 2021-07-14 06:47:08 --> Form Validation Class Initialized
INFO - 2021-07-14 06:47:08 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:47:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:47:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2021-07-14 06:47:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:47:08 --> Encryption Class Initialized
INFO - 2021-07-14 06:47:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:47:08 --> Encryption Class Initialized
INFO - 2021-07-14 06:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:47:08 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:47:08 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:47:08 --> Model "user_model" initialized
INFO - 2021-07-14 06:47:08 --> Model "role_model" initialized
INFO - 2021-07-14 06:47:08 --> Controller Class Initialized
INFO - 2021-07-14 06:47:08 --> Helper loaded: language_helper
INFO - 2021-07-14 06:47:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:47:08 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:47:08 --> Final output sent to browser
DEBUG - 2021-07-14 06:47:08 --> Total execution time: 0.0664
INFO - 2021-07-14 06:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:47:08 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:47:08 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:47:08 --> Model "user_model" initialized
INFO - 2021-07-14 06:47:08 --> Model "role_model" initialized
INFO - 2021-07-14 06:47:08 --> Controller Class Initialized
INFO - 2021-07-14 06:47:08 --> Helper loaded: language_helper
INFO - 2021-07-14 06:47:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:47:08 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:47:08 --> Final output sent to browser
DEBUG - 2021-07-14 06:47:08 --> Total execution time: 0.0772
INFO - 2021-07-14 06:48:00 --> Config Class Initialized
INFO - 2021-07-14 06:48:00 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:48:00 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:48:00 --> Utf8 Class Initialized
INFO - 2021-07-14 06:48:00 --> URI Class Initialized
INFO - 2021-07-14 06:48:00 --> Router Class Initialized
INFO - 2021-07-14 06:48:00 --> Output Class Initialized
INFO - 2021-07-14 06:48:00 --> Security Class Initialized
DEBUG - 2021-07-14 06:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:48:00 --> Input Class Initialized
INFO - 2021-07-14 06:48:00 --> Language Class Initialized
INFO - 2021-07-14 06:48:00 --> Loader Class Initialized
INFO - 2021-07-14 06:48:00 --> Helper loaded: html_helper
INFO - 2021-07-14 06:48:00 --> Helper loaded: url_helper
INFO - 2021-07-14 06:48:00 --> Helper loaded: form_helper
INFO - 2021-07-14 06:48:00 --> Database Driver Class Initialized
INFO - 2021-07-14 06:48:00 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:48:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:48:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:48:00 --> Encryption Class Initialized
INFO - 2021-07-14 06:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:48:00 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:48:00 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:48:00 --> Model "user_model" initialized
INFO - 2021-07-14 06:48:00 --> Model "role_model" initialized
INFO - 2021-07-14 06:48:00 --> Controller Class Initialized
INFO - 2021-07-14 06:48:00 --> Helper loaded: language_helper
INFO - 2021-07-14 06:48:00 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:48:00 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:48:00 --> Model "Customer_model" initialized
INFO - 2021-07-14 06:48:00 --> Model "Product_model" initialized
INFO - 2021-07-14 06:48:00 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 06:48:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 06:48:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 06:48:00 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 06:48:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 06:48:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 06:48:00 --> Final output sent to browser
DEBUG - 2021-07-14 06:48:00 --> Total execution time: 0.1401
INFO - 2021-07-14 06:48:11 --> Config Class Initialized
INFO - 2021-07-14 06:48:11 --> Hooks Class Initialized
INFO - 2021-07-14 06:48:11 --> Config Class Initialized
INFO - 2021-07-14 06:48:11 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:48:11 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:48:11 --> Utf8 Class Initialized
DEBUG - 2021-07-14 06:48:11 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:48:11 --> Utf8 Class Initialized
INFO - 2021-07-14 06:48:11 --> URI Class Initialized
INFO - 2021-07-14 06:48:11 --> URI Class Initialized
INFO - 2021-07-14 06:48:11 --> Router Class Initialized
INFO - 2021-07-14 06:48:11 --> Router Class Initialized
INFO - 2021-07-14 06:48:11 --> Output Class Initialized
INFO - 2021-07-14 06:48:11 --> Output Class Initialized
INFO - 2021-07-14 06:48:11 --> Security Class Initialized
INFO - 2021-07-14 06:48:11 --> Security Class Initialized
DEBUG - 2021-07-14 06:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 06:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:48:11 --> Input Class Initialized
INFO - 2021-07-14 06:48:11 --> Input Class Initialized
INFO - 2021-07-14 06:48:11 --> Language Class Initialized
INFO - 2021-07-14 06:48:11 --> Language Class Initialized
INFO - 2021-07-14 06:48:11 --> Loader Class Initialized
INFO - 2021-07-14 06:48:11 --> Loader Class Initialized
INFO - 2021-07-14 06:48:11 --> Helper loaded: html_helper
INFO - 2021-07-14 06:48:11 --> Helper loaded: html_helper
INFO - 2021-07-14 06:48:11 --> Helper loaded: url_helper
INFO - 2021-07-14 06:48:11 --> Helper loaded: url_helper
INFO - 2021-07-14 06:48:11 --> Helper loaded: form_helper
INFO - 2021-07-14 06:48:11 --> Helper loaded: form_helper
INFO - 2021-07-14 06:48:11 --> Database Driver Class Initialized
INFO - 2021-07-14 06:48:11 --> Database Driver Class Initialized
INFO - 2021-07-14 06:48:11 --> Form Validation Class Initialized
INFO - 2021-07-14 06:48:11 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-14 06:48:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:48:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:48:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:48:11 --> Encryption Class Initialized
INFO - 2021-07-14 06:48:11 --> Encryption Class Initialized
INFO - 2021-07-14 06:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:48:11 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:48:11 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:48:11 --> Model "user_model" initialized
INFO - 2021-07-14 06:48:11 --> Model "role_model" initialized
INFO - 2021-07-14 06:48:11 --> Controller Class Initialized
INFO - 2021-07-14 06:48:11 --> Helper loaded: language_helper
INFO - 2021-07-14 06:48:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:48:11 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:48:11 --> Final output sent to browser
DEBUG - 2021-07-14 06:48:11 --> Total execution time: 0.1055
INFO - 2021-07-14 06:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:48:11 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:48:11 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:48:11 --> Model "user_model" initialized
INFO - 2021-07-14 06:48:11 --> Model "role_model" initialized
INFO - 2021-07-14 06:48:11 --> Controller Class Initialized
INFO - 2021-07-14 06:48:11 --> Helper loaded: language_helper
INFO - 2021-07-14 06:48:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:48:11 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:48:11 --> Final output sent to browser
DEBUG - 2021-07-14 06:48:11 --> Total execution time: 0.1218
INFO - 2021-07-14 06:48:58 --> Config Class Initialized
INFO - 2021-07-14 06:48:58 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:48:58 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:48:58 --> Utf8 Class Initialized
INFO - 2021-07-14 06:48:58 --> URI Class Initialized
INFO - 2021-07-14 06:48:58 --> Router Class Initialized
INFO - 2021-07-14 06:48:58 --> Output Class Initialized
INFO - 2021-07-14 06:48:58 --> Security Class Initialized
DEBUG - 2021-07-14 06:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:48:58 --> Input Class Initialized
INFO - 2021-07-14 06:48:58 --> Language Class Initialized
INFO - 2021-07-14 06:48:58 --> Loader Class Initialized
INFO - 2021-07-14 06:48:58 --> Helper loaded: html_helper
INFO - 2021-07-14 06:48:58 --> Helper loaded: url_helper
INFO - 2021-07-14 06:48:58 --> Helper loaded: form_helper
INFO - 2021-07-14 06:48:58 --> Database Driver Class Initialized
INFO - 2021-07-14 06:48:58 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:48:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:48:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:48:58 --> Encryption Class Initialized
INFO - 2021-07-14 06:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:48:58 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:48:58 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:48:58 --> Model "user_model" initialized
INFO - 2021-07-14 06:48:58 --> Model "role_model" initialized
INFO - 2021-07-14 06:48:58 --> Controller Class Initialized
INFO - 2021-07-14 06:48:58 --> Helper loaded: language_helper
INFO - 2021-07-14 06:48:58 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:48:58 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:48:58 --> Model "Customer_model" initialized
INFO - 2021-07-14 06:48:58 --> Model "Product_model" initialized
INFO - 2021-07-14 06:48:58 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 06:48:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 06:48:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 06:48:58 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 06:48:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 06:48:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 06:48:58 --> Final output sent to browser
DEBUG - 2021-07-14 06:48:58 --> Total execution time: 0.1146
INFO - 2021-07-14 06:49:04 --> Config Class Initialized
INFO - 2021-07-14 06:49:04 --> Hooks Class Initialized
INFO - 2021-07-14 06:49:04 --> Config Class Initialized
INFO - 2021-07-14 06:49:04 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:49:04 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:49:04 --> Utf8 Class Initialized
DEBUG - 2021-07-14 06:49:04 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:49:04 --> URI Class Initialized
INFO - 2021-07-14 06:49:04 --> Utf8 Class Initialized
INFO - 2021-07-14 06:49:04 --> Router Class Initialized
INFO - 2021-07-14 06:49:04 --> URI Class Initialized
INFO - 2021-07-14 06:49:04 --> Router Class Initialized
INFO - 2021-07-14 06:49:04 --> Output Class Initialized
INFO - 2021-07-14 06:49:04 --> Security Class Initialized
INFO - 2021-07-14 06:49:04 --> Output Class Initialized
DEBUG - 2021-07-14 06:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:49:04 --> Input Class Initialized
INFO - 2021-07-14 06:49:04 --> Language Class Initialized
INFO - 2021-07-14 06:49:04 --> Security Class Initialized
DEBUG - 2021-07-14 06:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:49:04 --> Input Class Initialized
INFO - 2021-07-14 06:49:04 --> Language Class Initialized
INFO - 2021-07-14 06:49:04 --> Loader Class Initialized
INFO - 2021-07-14 06:49:04 --> Loader Class Initialized
INFO - 2021-07-14 06:49:04 --> Helper loaded: html_helper
INFO - 2021-07-14 06:49:04 --> Helper loaded: html_helper
INFO - 2021-07-14 06:49:04 --> Helper loaded: url_helper
INFO - 2021-07-14 06:49:04 --> Helper loaded: url_helper
INFO - 2021-07-14 06:49:04 --> Helper loaded: form_helper
INFO - 2021-07-14 06:49:04 --> Helper loaded: form_helper
INFO - 2021-07-14 06:49:04 --> Database Driver Class Initialized
INFO - 2021-07-14 06:49:04 --> Database Driver Class Initialized
INFO - 2021-07-14 06:49:04 --> Form Validation Class Initialized
INFO - 2021-07-14 06:49:04 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:49:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:49:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2021-07-14 06:49:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:49:04 --> Encryption Class Initialized
INFO - 2021-07-14 06:49:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:49:04 --> Encryption Class Initialized
INFO - 2021-07-14 06:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:49:04 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:49:04 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:49:04 --> Model "user_model" initialized
INFO - 2021-07-14 06:49:04 --> Model "role_model" initialized
INFO - 2021-07-14 06:49:04 --> Controller Class Initialized
INFO - 2021-07-14 06:49:04 --> Helper loaded: language_helper
INFO - 2021-07-14 06:49:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:49:04 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:49:04 --> Final output sent to browser
DEBUG - 2021-07-14 06:49:04 --> Total execution time: 0.0669
INFO - 2021-07-14 06:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:49:04 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:49:04 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:49:04 --> Model "user_model" initialized
INFO - 2021-07-14 06:49:04 --> Model "role_model" initialized
INFO - 2021-07-14 06:49:04 --> Controller Class Initialized
INFO - 2021-07-14 06:49:04 --> Helper loaded: language_helper
INFO - 2021-07-14 06:49:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:49:04 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:49:04 --> Final output sent to browser
DEBUG - 2021-07-14 06:49:04 --> Total execution time: 0.0790
INFO - 2021-07-14 06:49:18 --> Config Class Initialized
INFO - 2021-07-14 06:49:18 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:49:18 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:49:18 --> Config Class Initialized
INFO - 2021-07-14 06:49:18 --> Utf8 Class Initialized
INFO - 2021-07-14 06:49:18 --> Hooks Class Initialized
INFO - 2021-07-14 06:49:18 --> URI Class Initialized
INFO - 2021-07-14 06:49:18 --> Router Class Initialized
DEBUG - 2021-07-14 06:49:18 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:49:18 --> Utf8 Class Initialized
INFO - 2021-07-14 06:49:18 --> URI Class Initialized
INFO - 2021-07-14 06:49:18 --> Output Class Initialized
INFO - 2021-07-14 06:49:18 --> Router Class Initialized
INFO - 2021-07-14 06:49:18 --> Security Class Initialized
INFO - 2021-07-14 06:49:18 --> Output Class Initialized
DEBUG - 2021-07-14 06:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:49:18 --> Input Class Initialized
INFO - 2021-07-14 06:49:18 --> Language Class Initialized
INFO - 2021-07-14 06:49:18 --> Security Class Initialized
DEBUG - 2021-07-14 06:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:49:18 --> Input Class Initialized
INFO - 2021-07-14 06:49:18 --> Language Class Initialized
INFO - 2021-07-14 06:49:18 --> Loader Class Initialized
INFO - 2021-07-14 06:49:18 --> Helper loaded: html_helper
INFO - 2021-07-14 06:49:18 --> Helper loaded: url_helper
INFO - 2021-07-14 06:49:18 --> Loader Class Initialized
INFO - 2021-07-14 06:49:18 --> Helper loaded: html_helper
INFO - 2021-07-14 06:49:18 --> Helper loaded: form_helper
INFO - 2021-07-14 06:49:18 --> Helper loaded: url_helper
INFO - 2021-07-14 06:49:18 --> Helper loaded: form_helper
INFO - 2021-07-14 06:49:18 --> Database Driver Class Initialized
INFO - 2021-07-14 06:49:18 --> Database Driver Class Initialized
INFO - 2021-07-14 06:49:18 --> Form Validation Class Initialized
INFO - 2021-07-14 06:49:18 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-14 06:49:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:49:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:49:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:49:18 --> Encryption Class Initialized
INFO - 2021-07-14 06:49:18 --> Encryption Class Initialized
INFO - 2021-07-14 06:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:49:18 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:49:18 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:49:18 --> Model "user_model" initialized
INFO - 2021-07-14 06:49:18 --> Model "role_model" initialized
INFO - 2021-07-14 06:49:18 --> Controller Class Initialized
INFO - 2021-07-14 06:49:18 --> Helper loaded: language_helper
INFO - 2021-07-14 06:49:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:49:18 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:49:18 --> Final output sent to browser
DEBUG - 2021-07-14 06:49:18 --> Total execution time: 0.0689
INFO - 2021-07-14 06:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:49:18 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:49:18 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:49:18 --> Model "user_model" initialized
INFO - 2021-07-14 06:49:18 --> Model "role_model" initialized
INFO - 2021-07-14 06:49:18 --> Controller Class Initialized
INFO - 2021-07-14 06:49:18 --> Helper loaded: language_helper
INFO - 2021-07-14 06:49:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:49:18 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:49:18 --> Final output sent to browser
DEBUG - 2021-07-14 06:49:18 --> Total execution time: 0.0840
INFO - 2021-07-14 06:49:29 --> Config Class Initialized
INFO - 2021-07-14 06:49:29 --> Config Class Initialized
INFO - 2021-07-14 06:49:29 --> Hooks Class Initialized
INFO - 2021-07-14 06:49:29 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:49:29 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 06:49:29 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:49:29 --> Utf8 Class Initialized
INFO - 2021-07-14 06:49:29 --> Utf8 Class Initialized
INFO - 2021-07-14 06:49:29 --> URI Class Initialized
INFO - 2021-07-14 06:49:29 --> URI Class Initialized
INFO - 2021-07-14 06:49:29 --> Router Class Initialized
INFO - 2021-07-14 06:49:29 --> Router Class Initialized
INFO - 2021-07-14 06:49:29 --> Output Class Initialized
INFO - 2021-07-14 06:49:29 --> Output Class Initialized
INFO - 2021-07-14 06:49:29 --> Security Class Initialized
INFO - 2021-07-14 06:49:29 --> Security Class Initialized
DEBUG - 2021-07-14 06:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:49:29 --> Input Class Initialized
DEBUG - 2021-07-14 06:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:49:29 --> Input Class Initialized
INFO - 2021-07-14 06:49:29 --> Language Class Initialized
INFO - 2021-07-14 06:49:29 --> Language Class Initialized
INFO - 2021-07-14 06:49:29 --> Loader Class Initialized
INFO - 2021-07-14 06:49:29 --> Helper loaded: html_helper
INFO - 2021-07-14 06:49:29 --> Loader Class Initialized
INFO - 2021-07-14 06:49:29 --> Helper loaded: url_helper
INFO - 2021-07-14 06:49:29 --> Helper loaded: html_helper
INFO - 2021-07-14 06:49:29 --> Helper loaded: url_helper
INFO - 2021-07-14 06:49:29 --> Helper loaded: form_helper
INFO - 2021-07-14 06:49:29 --> Helper loaded: form_helper
INFO - 2021-07-14 06:49:30 --> Database Driver Class Initialized
INFO - 2021-07-14 06:49:30 --> Database Driver Class Initialized
INFO - 2021-07-14 06:49:30 --> Form Validation Class Initialized
INFO - 2021-07-14 06:49:30 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:49:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:49:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:49:30 --> Encryption Class Initialized
DEBUG - 2021-07-14 06:49:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:49:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:49:30 --> Encryption Class Initialized
INFO - 2021-07-14 06:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:49:30 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:49:30 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:49:30 --> Model "user_model" initialized
INFO - 2021-07-14 06:49:30 --> Model "role_model" initialized
INFO - 2021-07-14 06:49:30 --> Controller Class Initialized
INFO - 2021-07-14 06:49:30 --> Helper loaded: language_helper
INFO - 2021-07-14 06:49:30 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:49:30 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:49:30 --> Final output sent to browser
DEBUG - 2021-07-14 06:49:30 --> Total execution time: 0.0580
INFO - 2021-07-14 06:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:49:30 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:49:30 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:49:30 --> Model "user_model" initialized
INFO - 2021-07-14 06:49:30 --> Model "role_model" initialized
INFO - 2021-07-14 06:49:30 --> Controller Class Initialized
INFO - 2021-07-14 06:49:30 --> Helper loaded: language_helper
INFO - 2021-07-14 06:49:30 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:49:30 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:49:30 --> Final output sent to browser
DEBUG - 2021-07-14 06:49:30 --> Total execution time: 0.0668
INFO - 2021-07-14 06:51:59 --> Config Class Initialized
INFO - 2021-07-14 06:51:59 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:51:59 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:51:59 --> Utf8 Class Initialized
INFO - 2021-07-14 06:51:59 --> URI Class Initialized
INFO - 2021-07-14 06:51:59 --> Router Class Initialized
INFO - 2021-07-14 06:51:59 --> Output Class Initialized
INFO - 2021-07-14 06:51:59 --> Security Class Initialized
DEBUG - 2021-07-14 06:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:51:59 --> Input Class Initialized
INFO - 2021-07-14 06:51:59 --> Language Class Initialized
INFO - 2021-07-14 06:51:59 --> Loader Class Initialized
INFO - 2021-07-14 06:51:59 --> Helper loaded: html_helper
INFO - 2021-07-14 06:51:59 --> Helper loaded: url_helper
INFO - 2021-07-14 06:51:59 --> Helper loaded: form_helper
INFO - 2021-07-14 06:51:59 --> Database Driver Class Initialized
INFO - 2021-07-14 06:51:59 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:51:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:51:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:51:59 --> Encryption Class Initialized
INFO - 2021-07-14 06:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:51:59 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:51:59 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:51:59 --> Model "user_model" initialized
INFO - 2021-07-14 06:51:59 --> Model "role_model" initialized
INFO - 2021-07-14 06:51:59 --> Controller Class Initialized
INFO - 2021-07-14 06:51:59 --> Helper loaded: language_helper
INFO - 2021-07-14 06:51:59 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:51:59 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:51:59 --> Model "Customer_model" initialized
INFO - 2021-07-14 06:51:59 --> Model "Product_model" initialized
INFO - 2021-07-14 06:51:59 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 06:51:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 06:51:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 06:51:59 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 06:51:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 06:51:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 06:51:59 --> Final output sent to browser
DEBUG - 2021-07-14 06:51:59 --> Total execution time: 0.1109
INFO - 2021-07-14 06:52:13 --> Config Class Initialized
INFO - 2021-07-14 06:52:13 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:52:13 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:52:13 --> Utf8 Class Initialized
INFO - 2021-07-14 06:52:13 --> URI Class Initialized
INFO - 2021-07-14 06:52:13 --> Router Class Initialized
INFO - 2021-07-14 06:52:13 --> Output Class Initialized
INFO - 2021-07-14 06:52:13 --> Security Class Initialized
DEBUG - 2021-07-14 06:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:52:13 --> Input Class Initialized
INFO - 2021-07-14 06:52:13 --> Language Class Initialized
INFO - 2021-07-14 06:52:13 --> Loader Class Initialized
INFO - 2021-07-14 06:52:13 --> Helper loaded: html_helper
INFO - 2021-07-14 06:52:13 --> Helper loaded: url_helper
INFO - 2021-07-14 06:52:13 --> Helper loaded: form_helper
INFO - 2021-07-14 06:52:13 --> Database Driver Class Initialized
INFO - 2021-07-14 06:52:13 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:52:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:52:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:52:13 --> Encryption Class Initialized
INFO - 2021-07-14 06:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:52:13 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:52:13 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:52:13 --> Model "user_model" initialized
INFO - 2021-07-14 06:52:13 --> Model "role_model" initialized
INFO - 2021-07-14 06:52:13 --> Controller Class Initialized
INFO - 2021-07-14 06:52:13 --> Helper loaded: language_helper
INFO - 2021-07-14 06:52:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:52:13 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:52:13 --> Model "Customer_model" initialized
INFO - 2021-07-14 06:52:13 --> Model "Product_model" initialized
INFO - 2021-07-14 06:52:13 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 06:52:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 06:52:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 06:52:13 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 06:52:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 06:52:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 06:52:13 --> Final output sent to browser
DEBUG - 2021-07-14 06:52:13 --> Total execution time: 0.0829
INFO - 2021-07-14 06:53:50 --> Config Class Initialized
INFO - 2021-07-14 06:53:50 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:53:50 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:53:50 --> Utf8 Class Initialized
INFO - 2021-07-14 06:53:50 --> URI Class Initialized
INFO - 2021-07-14 06:53:50 --> Router Class Initialized
INFO - 2021-07-14 06:53:50 --> Output Class Initialized
INFO - 2021-07-14 06:53:50 --> Security Class Initialized
DEBUG - 2021-07-14 06:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:53:50 --> Input Class Initialized
INFO - 2021-07-14 06:53:50 --> Language Class Initialized
INFO - 2021-07-14 06:53:50 --> Loader Class Initialized
INFO - 2021-07-14 06:53:50 --> Helper loaded: html_helper
INFO - 2021-07-14 06:53:50 --> Helper loaded: url_helper
INFO - 2021-07-14 06:53:50 --> Helper loaded: form_helper
INFO - 2021-07-14 06:53:50 --> Database Driver Class Initialized
INFO - 2021-07-14 06:53:50 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:53:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:53:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:53:50 --> Encryption Class Initialized
INFO - 2021-07-14 06:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:53:50 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:53:50 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:53:50 --> Model "user_model" initialized
INFO - 2021-07-14 06:53:50 --> Model "role_model" initialized
INFO - 2021-07-14 06:53:50 --> Controller Class Initialized
INFO - 2021-07-14 06:53:50 --> Helper loaded: language_helper
INFO - 2021-07-14 06:53:50 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:53:50 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:53:50 --> Model "Customer_model" initialized
INFO - 2021-07-14 06:53:50 --> Model "Product_model" initialized
INFO - 2021-07-14 06:53:50 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 06:53:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 06:53:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 06:53:50 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 06:53:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 06:53:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 06:53:50 --> Final output sent to browser
DEBUG - 2021-07-14 06:53:50 --> Total execution time: 0.1072
INFO - 2021-07-14 06:54:18 --> Config Class Initialized
INFO - 2021-07-14 06:54:18 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:54:18 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:54:18 --> Utf8 Class Initialized
INFO - 2021-07-14 06:54:18 --> URI Class Initialized
INFO - 2021-07-14 06:54:18 --> Router Class Initialized
INFO - 2021-07-14 06:54:18 --> Output Class Initialized
INFO - 2021-07-14 06:54:18 --> Security Class Initialized
DEBUG - 2021-07-14 06:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:54:18 --> Input Class Initialized
INFO - 2021-07-14 06:54:18 --> Language Class Initialized
INFO - 2021-07-14 06:54:18 --> Loader Class Initialized
INFO - 2021-07-14 06:54:18 --> Helper loaded: html_helper
INFO - 2021-07-14 06:54:18 --> Helper loaded: url_helper
INFO - 2021-07-14 06:54:18 --> Helper loaded: form_helper
INFO - 2021-07-14 06:54:18 --> Database Driver Class Initialized
INFO - 2021-07-14 06:54:18 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:54:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:54:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:54:18 --> Encryption Class Initialized
INFO - 2021-07-14 06:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:54:18 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:54:18 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:54:18 --> Model "user_model" initialized
INFO - 2021-07-14 06:54:18 --> Model "role_model" initialized
INFO - 2021-07-14 06:54:18 --> Controller Class Initialized
INFO - 2021-07-14 06:54:18 --> Helper loaded: language_helper
INFO - 2021-07-14 06:54:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:54:18 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:54:18 --> Model "Customer_model" initialized
INFO - 2021-07-14 06:54:18 --> Model "Product_model" initialized
INFO - 2021-07-14 06:54:18 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 06:54:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 06:54:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 06:54:18 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 06:54:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 06:54:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 06:54:18 --> Final output sent to browser
DEBUG - 2021-07-14 06:54:18 --> Total execution time: 0.1435
INFO - 2021-07-14 06:55:33 --> Config Class Initialized
INFO - 2021-07-14 06:55:33 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:55:33 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:55:33 --> Utf8 Class Initialized
INFO - 2021-07-14 06:55:33 --> URI Class Initialized
INFO - 2021-07-14 06:55:33 --> Router Class Initialized
INFO - 2021-07-14 06:55:33 --> Output Class Initialized
INFO - 2021-07-14 06:55:33 --> Security Class Initialized
DEBUG - 2021-07-14 06:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:55:33 --> Input Class Initialized
INFO - 2021-07-14 06:55:33 --> Language Class Initialized
INFO - 2021-07-14 06:55:33 --> Loader Class Initialized
INFO - 2021-07-14 06:55:33 --> Helper loaded: html_helper
INFO - 2021-07-14 06:55:33 --> Helper loaded: url_helper
INFO - 2021-07-14 06:55:33 --> Helper loaded: form_helper
INFO - 2021-07-14 06:55:33 --> Database Driver Class Initialized
INFO - 2021-07-14 06:55:33 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:55:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:55:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:55:33 --> Encryption Class Initialized
INFO - 2021-07-14 06:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:55:33 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:55:33 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:55:33 --> Model "user_model" initialized
INFO - 2021-07-14 06:55:33 --> Model "role_model" initialized
INFO - 2021-07-14 06:55:33 --> Controller Class Initialized
INFO - 2021-07-14 06:55:33 --> Helper loaded: language_helper
INFO - 2021-07-14 06:55:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:55:33 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:55:33 --> Model "Customer_model" initialized
INFO - 2021-07-14 06:55:33 --> Model "Product_model" initialized
INFO - 2021-07-14 06:55:33 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 06:55:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 06:55:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 06:55:33 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 06:55:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 06:55:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 06:55:33 --> Final output sent to browser
DEBUG - 2021-07-14 06:55:33 --> Total execution time: 0.1188
INFO - 2021-07-14 06:55:34 --> Config Class Initialized
INFO - 2021-07-14 06:55:34 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:55:34 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:55:34 --> Utf8 Class Initialized
INFO - 2021-07-14 06:55:34 --> URI Class Initialized
INFO - 2021-07-14 06:55:34 --> Router Class Initialized
INFO - 2021-07-14 06:55:34 --> Output Class Initialized
INFO - 2021-07-14 06:55:34 --> Security Class Initialized
DEBUG - 2021-07-14 06:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:55:34 --> Input Class Initialized
INFO - 2021-07-14 06:55:34 --> Language Class Initialized
INFO - 2021-07-14 06:55:34 --> Loader Class Initialized
INFO - 2021-07-14 06:55:34 --> Helper loaded: html_helper
INFO - 2021-07-14 06:55:34 --> Helper loaded: url_helper
INFO - 2021-07-14 06:55:34 --> Helper loaded: form_helper
INFO - 2021-07-14 06:55:34 --> Database Driver Class Initialized
INFO - 2021-07-14 06:55:34 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:55:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:55:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:55:34 --> Encryption Class Initialized
INFO - 2021-07-14 06:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:55:34 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:55:34 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:55:34 --> Model "user_model" initialized
INFO - 2021-07-14 06:55:34 --> Model "role_model" initialized
INFO - 2021-07-14 06:55:34 --> Controller Class Initialized
INFO - 2021-07-14 06:55:34 --> Helper loaded: language_helper
INFO - 2021-07-14 06:55:34 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:55:34 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:55:34 --> Model "Customer_model" initialized
INFO - 2021-07-14 06:55:34 --> Model "Product_model" initialized
INFO - 2021-07-14 06:55:34 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 06:55:34 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 06:55:34 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 06:55:34 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 06:55:34 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 06:55:34 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 06:55:34 --> Final output sent to browser
DEBUG - 2021-07-14 06:55:34 --> Total execution time: 0.0695
INFO - 2021-07-14 06:55:40 --> Config Class Initialized
INFO - 2021-07-14 06:55:40 --> Hooks Class Initialized
INFO - 2021-07-14 06:55:40 --> Config Class Initialized
INFO - 2021-07-14 06:55:40 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:55:40 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:55:40 --> Utf8 Class Initialized
DEBUG - 2021-07-14 06:55:40 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:55:40 --> Utf8 Class Initialized
INFO - 2021-07-14 06:55:40 --> URI Class Initialized
INFO - 2021-07-14 06:55:40 --> URI Class Initialized
INFO - 2021-07-14 06:55:40 --> Router Class Initialized
INFO - 2021-07-14 06:55:40 --> Router Class Initialized
INFO - 2021-07-14 06:55:40 --> Output Class Initialized
INFO - 2021-07-14 06:55:40 --> Output Class Initialized
INFO - 2021-07-14 06:55:40 --> Security Class Initialized
INFO - 2021-07-14 06:55:40 --> Security Class Initialized
DEBUG - 2021-07-14 06:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 06:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:55:40 --> Input Class Initialized
INFO - 2021-07-14 06:55:40 --> Input Class Initialized
INFO - 2021-07-14 06:55:40 --> Language Class Initialized
INFO - 2021-07-14 06:55:40 --> Language Class Initialized
INFO - 2021-07-14 06:55:40 --> Loader Class Initialized
INFO - 2021-07-14 06:55:40 --> Loader Class Initialized
INFO - 2021-07-14 06:55:40 --> Helper loaded: html_helper
INFO - 2021-07-14 06:55:40 --> Helper loaded: html_helper
INFO - 2021-07-14 06:55:40 --> Helper loaded: url_helper
INFO - 2021-07-14 06:55:40 --> Helper loaded: url_helper
INFO - 2021-07-14 06:55:40 --> Helper loaded: form_helper
INFO - 2021-07-14 06:55:40 --> Helper loaded: form_helper
INFO - 2021-07-14 06:55:40 --> Database Driver Class Initialized
INFO - 2021-07-14 06:55:40 --> Database Driver Class Initialized
INFO - 2021-07-14 06:55:40 --> Form Validation Class Initialized
INFO - 2021-07-14 06:55:40 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:55:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:55:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2021-07-14 06:55:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:55:40 --> Encryption Class Initialized
INFO - 2021-07-14 06:55:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:55:40 --> Encryption Class Initialized
INFO - 2021-07-14 06:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:55:40 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:55:40 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:55:40 --> Model "user_model" initialized
INFO - 2021-07-14 06:55:40 --> Model "role_model" initialized
INFO - 2021-07-14 06:55:40 --> Controller Class Initialized
INFO - 2021-07-14 06:55:40 --> Helper loaded: language_helper
INFO - 2021-07-14 06:55:40 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:55:40 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:55:40 --> Final output sent to browser
DEBUG - 2021-07-14 06:55:40 --> Total execution time: 0.0661
INFO - 2021-07-14 06:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:55:40 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:55:40 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:55:40 --> Model "user_model" initialized
INFO - 2021-07-14 06:55:40 --> Model "role_model" initialized
INFO - 2021-07-14 06:55:40 --> Controller Class Initialized
INFO - 2021-07-14 06:55:40 --> Helper loaded: language_helper
INFO - 2021-07-14 06:55:40 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:55:40 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:55:40 --> Final output sent to browser
DEBUG - 2021-07-14 06:55:40 --> Total execution time: 0.0778
INFO - 2021-07-14 06:55:46 --> Config Class Initialized
INFO - 2021-07-14 06:55:46 --> Hooks Class Initialized
INFO - 2021-07-14 06:55:46 --> Config Class Initialized
INFO - 2021-07-14 06:55:46 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:55:46 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 06:55:46 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:55:46 --> Utf8 Class Initialized
INFO - 2021-07-14 06:55:46 --> Utf8 Class Initialized
INFO - 2021-07-14 06:55:46 --> URI Class Initialized
INFO - 2021-07-14 06:55:46 --> URI Class Initialized
INFO - 2021-07-14 06:55:46 --> Router Class Initialized
INFO - 2021-07-14 06:55:46 --> Router Class Initialized
INFO - 2021-07-14 06:55:46 --> Output Class Initialized
INFO - 2021-07-14 06:55:46 --> Output Class Initialized
INFO - 2021-07-14 06:55:46 --> Security Class Initialized
INFO - 2021-07-14 06:55:46 --> Security Class Initialized
DEBUG - 2021-07-14 06:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:55:46 --> Input Class Initialized
DEBUG - 2021-07-14 06:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:55:46 --> Input Class Initialized
INFO - 2021-07-14 06:55:46 --> Language Class Initialized
INFO - 2021-07-14 06:55:46 --> Language Class Initialized
INFO - 2021-07-14 06:55:46 --> Loader Class Initialized
INFO - 2021-07-14 06:55:46 --> Loader Class Initialized
INFO - 2021-07-14 06:55:46 --> Helper loaded: html_helper
INFO - 2021-07-14 06:55:46 --> Helper loaded: html_helper
INFO - 2021-07-14 06:55:46 --> Helper loaded: url_helper
INFO - 2021-07-14 06:55:46 --> Helper loaded: url_helper
INFO - 2021-07-14 06:55:46 --> Helper loaded: form_helper
INFO - 2021-07-14 06:55:46 --> Helper loaded: form_helper
INFO - 2021-07-14 06:55:46 --> Database Driver Class Initialized
INFO - 2021-07-14 06:55:46 --> Database Driver Class Initialized
INFO - 2021-07-14 06:55:46 --> Form Validation Class Initialized
INFO - 2021-07-14 06:55:46 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:55:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:55:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:55:46 --> Encryption Class Initialized
DEBUG - 2021-07-14 06:55:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:55:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:55:46 --> Encryption Class Initialized
INFO - 2021-07-14 06:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:55:46 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:55:46 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:55:46 --> Model "user_model" initialized
INFO - 2021-07-14 06:55:46 --> Model "role_model" initialized
INFO - 2021-07-14 06:55:46 --> Controller Class Initialized
INFO - 2021-07-14 06:55:46 --> Helper loaded: language_helper
INFO - 2021-07-14 06:55:46 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:55:46 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:55:46 --> Final output sent to browser
DEBUG - 2021-07-14 06:55:46 --> Total execution time: 0.0795
INFO - 2021-07-14 06:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:55:46 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:55:46 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:55:46 --> Model "user_model" initialized
INFO - 2021-07-14 06:55:46 --> Model "role_model" initialized
INFO - 2021-07-14 06:55:46 --> Controller Class Initialized
INFO - 2021-07-14 06:55:46 --> Helper loaded: language_helper
INFO - 2021-07-14 06:55:46 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:55:46 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:55:46 --> Final output sent to browser
DEBUG - 2021-07-14 06:55:46 --> Total execution time: 0.0903
INFO - 2021-07-14 06:56:03 --> Config Class Initialized
INFO - 2021-07-14 06:56:03 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:56:03 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:56:03 --> Utf8 Class Initialized
INFO - 2021-07-14 06:56:03 --> URI Class Initialized
INFO - 2021-07-14 06:56:03 --> Router Class Initialized
INFO - 2021-07-14 06:56:03 --> Output Class Initialized
INFO - 2021-07-14 06:56:03 --> Security Class Initialized
DEBUG - 2021-07-14 06:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:56:03 --> Input Class Initialized
INFO - 2021-07-14 06:56:03 --> Language Class Initialized
INFO - 2021-07-14 06:56:03 --> Loader Class Initialized
INFO - 2021-07-14 06:56:03 --> Helper loaded: html_helper
INFO - 2021-07-14 06:56:03 --> Helper loaded: url_helper
INFO - 2021-07-14 06:56:03 --> Helper loaded: form_helper
INFO - 2021-07-14 06:56:03 --> Database Driver Class Initialized
INFO - 2021-07-14 06:56:03 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:56:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:56:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:56:03 --> Encryption Class Initialized
INFO - 2021-07-14 06:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:56:03 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:56:03 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:56:03 --> Model "user_model" initialized
INFO - 2021-07-14 06:56:03 --> Model "role_model" initialized
INFO - 2021-07-14 06:56:03 --> Controller Class Initialized
INFO - 2021-07-14 06:56:03 --> Helper loaded: language_helper
INFO - 2021-07-14 06:56:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:56:03 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:56:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 06:56:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 06:56:03 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 06:56:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 06:56:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 06:56:03 --> Final output sent to browser
DEBUG - 2021-07-14 06:56:03 --> Total execution time: 0.2172
INFO - 2021-07-14 06:56:11 --> Config Class Initialized
INFO - 2021-07-14 06:56:11 --> Hooks Class Initialized
INFO - 2021-07-14 06:56:11 --> Config Class Initialized
INFO - 2021-07-14 06:56:11 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:56:11 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 06:56:11 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:56:11 --> Utf8 Class Initialized
INFO - 2021-07-14 06:56:11 --> Utf8 Class Initialized
INFO - 2021-07-14 06:56:11 --> URI Class Initialized
INFO - 2021-07-14 06:56:11 --> URI Class Initialized
INFO - 2021-07-14 06:56:11 --> Router Class Initialized
INFO - 2021-07-14 06:56:11 --> Router Class Initialized
INFO - 2021-07-14 06:56:11 --> Output Class Initialized
INFO - 2021-07-14 06:56:11 --> Output Class Initialized
INFO - 2021-07-14 06:56:11 --> Security Class Initialized
INFO - 2021-07-14 06:56:11 --> Security Class Initialized
DEBUG - 2021-07-14 06:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:56:11 --> Input Class Initialized
INFO - 2021-07-14 06:56:11 --> Language Class Initialized
DEBUG - 2021-07-14 06:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:56:11 --> Input Class Initialized
INFO - 2021-07-14 06:56:11 --> Language Class Initialized
INFO - 2021-07-14 06:56:11 --> Loader Class Initialized
INFO - 2021-07-14 06:56:11 --> Loader Class Initialized
INFO - 2021-07-14 06:56:11 --> Helper loaded: html_helper
INFO - 2021-07-14 06:56:11 --> Helper loaded: html_helper
INFO - 2021-07-14 06:56:11 --> Helper loaded: url_helper
INFO - 2021-07-14 06:56:11 --> Helper loaded: url_helper
INFO - 2021-07-14 06:56:11 --> Helper loaded: form_helper
INFO - 2021-07-14 06:56:11 --> Helper loaded: form_helper
INFO - 2021-07-14 06:56:11 --> Database Driver Class Initialized
INFO - 2021-07-14 06:56:11 --> Database Driver Class Initialized
INFO - 2021-07-14 06:56:11 --> Form Validation Class Initialized
INFO - 2021-07-14 06:56:11 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-14 06:56:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:56:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:56:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:56:11 --> Encryption Class Initialized
INFO - 2021-07-14 06:56:11 --> Encryption Class Initialized
INFO - 2021-07-14 06:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:56:11 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:56:11 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:56:11 --> Model "user_model" initialized
INFO - 2021-07-14 06:56:11 --> Model "role_model" initialized
INFO - 2021-07-14 06:56:11 --> Controller Class Initialized
INFO - 2021-07-14 06:56:11 --> Helper loaded: language_helper
INFO - 2021-07-14 06:56:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:56:11 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:56:11 --> Final output sent to browser
DEBUG - 2021-07-14 06:56:11 --> Total execution time: 0.0607
INFO - 2021-07-14 06:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:56:11 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:56:11 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:56:11 --> Model "user_model" initialized
INFO - 2021-07-14 06:56:11 --> Model "role_model" initialized
INFO - 2021-07-14 06:56:11 --> Controller Class Initialized
INFO - 2021-07-14 06:56:11 --> Helper loaded: language_helper
INFO - 2021-07-14 06:56:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:56:11 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:56:11 --> Final output sent to browser
DEBUG - 2021-07-14 06:56:11 --> Total execution time: 0.0717
INFO - 2021-07-14 06:57:35 --> Config Class Initialized
INFO - 2021-07-14 06:57:35 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:57:35 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:57:35 --> Utf8 Class Initialized
INFO - 2021-07-14 06:57:35 --> URI Class Initialized
INFO - 2021-07-14 06:57:35 --> Router Class Initialized
INFO - 2021-07-14 06:57:35 --> Output Class Initialized
INFO - 2021-07-14 06:57:35 --> Security Class Initialized
DEBUG - 2021-07-14 06:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:57:35 --> Input Class Initialized
INFO - 2021-07-14 06:57:35 --> Language Class Initialized
INFO - 2021-07-14 06:57:35 --> Loader Class Initialized
INFO - 2021-07-14 06:57:35 --> Helper loaded: html_helper
INFO - 2021-07-14 06:57:35 --> Helper loaded: url_helper
INFO - 2021-07-14 06:57:35 --> Helper loaded: form_helper
INFO - 2021-07-14 06:57:35 --> Database Driver Class Initialized
INFO - 2021-07-14 06:57:35 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:57:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:57:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:57:35 --> Encryption Class Initialized
INFO - 2021-07-14 06:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:57:35 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:57:35 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:57:35 --> Model "user_model" initialized
INFO - 2021-07-14 06:57:35 --> Model "role_model" initialized
INFO - 2021-07-14 06:57:35 --> Controller Class Initialized
INFO - 2021-07-14 06:57:35 --> Helper loaded: language_helper
INFO - 2021-07-14 06:57:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:57:35 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:57:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 06:57:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 06:57:35 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 06:57:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 06:57:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 06:57:35 --> Final output sent to browser
DEBUG - 2021-07-14 06:57:35 --> Total execution time: 0.1071
INFO - 2021-07-14 06:57:39 --> Config Class Initialized
INFO - 2021-07-14 06:57:39 --> Hooks Class Initialized
INFO - 2021-07-14 06:57:39 --> Config Class Initialized
INFO - 2021-07-14 06:57:39 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:57:39 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:57:39 --> Utf8 Class Initialized
INFO - 2021-07-14 06:57:39 --> URI Class Initialized
DEBUG - 2021-07-14 06:57:39 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:57:39 --> Utf8 Class Initialized
INFO - 2021-07-14 06:57:39 --> URI Class Initialized
INFO - 2021-07-14 06:57:39 --> Router Class Initialized
INFO - 2021-07-14 06:57:39 --> Router Class Initialized
INFO - 2021-07-14 06:57:39 --> Output Class Initialized
INFO - 2021-07-14 06:57:39 --> Output Class Initialized
INFO - 2021-07-14 06:57:39 --> Security Class Initialized
INFO - 2021-07-14 06:57:39 --> Security Class Initialized
DEBUG - 2021-07-14 06:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:57:39 --> Input Class Initialized
INFO - 2021-07-14 06:57:39 --> Language Class Initialized
DEBUG - 2021-07-14 06:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:57:39 --> Input Class Initialized
INFO - 2021-07-14 06:57:39 --> Language Class Initialized
INFO - 2021-07-14 06:57:39 --> Loader Class Initialized
INFO - 2021-07-14 06:57:39 --> Helper loaded: html_helper
INFO - 2021-07-14 06:57:39 --> Loader Class Initialized
INFO - 2021-07-14 06:57:39 --> Helper loaded: url_helper
INFO - 2021-07-14 06:57:39 --> Helper loaded: html_helper
INFO - 2021-07-14 06:57:39 --> Helper loaded: form_helper
INFO - 2021-07-14 06:57:39 --> Helper loaded: url_helper
INFO - 2021-07-14 06:57:39 --> Helper loaded: form_helper
INFO - 2021-07-14 06:57:39 --> Database Driver Class Initialized
INFO - 2021-07-14 06:57:39 --> Database Driver Class Initialized
INFO - 2021-07-14 06:57:39 --> Form Validation Class Initialized
INFO - 2021-07-14 06:57:39 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:57:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:57:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2021-07-14 06:57:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 06:57:39 --> Encryption Class Initialized
INFO - 2021-07-14 06:57:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 06:57:39 --> Encryption Class Initialized
INFO - 2021-07-14 06:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:57:39 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:57:39 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:57:39 --> Model "user_model" initialized
INFO - 2021-07-14 06:57:39 --> Model "role_model" initialized
INFO - 2021-07-14 06:57:39 --> Controller Class Initialized
INFO - 2021-07-14 06:57:39 --> Helper loaded: language_helper
INFO - 2021-07-14 06:57:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:57:39 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:57:39 --> Final output sent to browser
DEBUG - 2021-07-14 06:57:39 --> Total execution time: 0.0643
INFO - 2021-07-14 06:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:57:39 --> Model "vendor_model" initialized
INFO - 2021-07-14 06:57:39 --> Model "coupon_model" initialized
INFO - 2021-07-14 06:57:39 --> Model "user_model" initialized
INFO - 2021-07-14 06:57:39 --> Model "role_model" initialized
INFO - 2021-07-14 06:57:39 --> Controller Class Initialized
INFO - 2021-07-14 06:57:39 --> Helper loaded: language_helper
INFO - 2021-07-14 06:57:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 06:57:39 --> Model "Quotation_model" initialized
INFO - 2021-07-14 06:57:39 --> Final output sent to browser
DEBUG - 2021-07-14 06:57:39 --> Total execution time: 0.0747
INFO - 2021-07-14 07:00:35 --> Config Class Initialized
INFO - 2021-07-14 07:00:35 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:00:35 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:00:35 --> Utf8 Class Initialized
INFO - 2021-07-14 07:00:35 --> URI Class Initialized
INFO - 2021-07-14 07:00:35 --> Router Class Initialized
INFO - 2021-07-14 07:00:35 --> Output Class Initialized
INFO - 2021-07-14 07:00:35 --> Security Class Initialized
DEBUG - 2021-07-14 07:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:00:35 --> Input Class Initialized
INFO - 2021-07-14 07:00:35 --> Language Class Initialized
INFO - 2021-07-14 07:00:35 --> Loader Class Initialized
INFO - 2021-07-14 07:00:35 --> Helper loaded: html_helper
INFO - 2021-07-14 07:00:35 --> Helper loaded: url_helper
INFO - 2021-07-14 07:00:35 --> Helper loaded: form_helper
INFO - 2021-07-14 07:00:35 --> Database Driver Class Initialized
INFO - 2021-07-14 07:00:35 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:00:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:00:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:00:35 --> Encryption Class Initialized
INFO - 2021-07-14 07:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:00:35 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:00:35 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:00:35 --> Model "user_model" initialized
INFO - 2021-07-14 07:00:35 --> Model "role_model" initialized
INFO - 2021-07-14 07:00:35 --> Controller Class Initialized
INFO - 2021-07-14 07:00:35 --> Helper loaded: language_helper
INFO - 2021-07-14 07:00:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:00:35 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:00:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:00:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:00:35 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:00:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:00:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:00:35 --> Final output sent to browser
DEBUG - 2021-07-14 07:00:35 --> Total execution time: 0.1253
INFO - 2021-07-14 07:00:39 --> Config Class Initialized
INFO - 2021-07-14 07:00:39 --> Hooks Class Initialized
INFO - 2021-07-14 07:00:39 --> Config Class Initialized
INFO - 2021-07-14 07:00:39 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:00:39 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:00:39 --> Utf8 Class Initialized
DEBUG - 2021-07-14 07:00:39 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:00:39 --> Utf8 Class Initialized
INFO - 2021-07-14 07:00:39 --> URI Class Initialized
INFO - 2021-07-14 07:00:39 --> URI Class Initialized
INFO - 2021-07-14 07:00:39 --> Router Class Initialized
INFO - 2021-07-14 07:00:39 --> Router Class Initialized
INFO - 2021-07-14 07:00:39 --> Output Class Initialized
INFO - 2021-07-14 07:00:39 --> Output Class Initialized
INFO - 2021-07-14 07:00:39 --> Security Class Initialized
INFO - 2021-07-14 07:00:39 --> Security Class Initialized
DEBUG - 2021-07-14 07:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:00:39 --> Input Class Initialized
DEBUG - 2021-07-14 07:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:00:39 --> Input Class Initialized
INFO - 2021-07-14 07:00:39 --> Language Class Initialized
INFO - 2021-07-14 07:00:39 --> Language Class Initialized
INFO - 2021-07-14 07:00:39 --> Loader Class Initialized
INFO - 2021-07-14 07:00:39 --> Loader Class Initialized
INFO - 2021-07-14 07:00:39 --> Helper loaded: html_helper
INFO - 2021-07-14 07:00:39 --> Helper loaded: html_helper
INFO - 2021-07-14 07:00:39 --> Helper loaded: url_helper
INFO - 2021-07-14 07:00:39 --> Helper loaded: url_helper
INFO - 2021-07-14 07:00:39 --> Helper loaded: form_helper
INFO - 2021-07-14 07:00:39 --> Helper loaded: form_helper
INFO - 2021-07-14 07:00:39 --> Database Driver Class Initialized
INFO - 2021-07-14 07:00:39 --> Database Driver Class Initialized
INFO - 2021-07-14 07:00:39 --> Form Validation Class Initialized
INFO - 2021-07-14 07:00:39 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-14 07:00:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:00:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:00:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:00:39 --> Encryption Class Initialized
INFO - 2021-07-14 07:00:39 --> Encryption Class Initialized
INFO - 2021-07-14 07:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:00:39 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:00:39 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:00:39 --> Model "user_model" initialized
INFO - 2021-07-14 07:00:39 --> Model "role_model" initialized
INFO - 2021-07-14 07:00:39 --> Controller Class Initialized
INFO - 2021-07-14 07:00:39 --> Helper loaded: language_helper
INFO - 2021-07-14 07:00:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:00:39 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:00:39 --> Final output sent to browser
DEBUG - 2021-07-14 07:00:39 --> Total execution time: 0.2944
INFO - 2021-07-14 07:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:00:39 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:00:39 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:00:39 --> Model "user_model" initialized
INFO - 2021-07-14 07:00:39 --> Model "role_model" initialized
INFO - 2021-07-14 07:00:39 --> Controller Class Initialized
INFO - 2021-07-14 07:00:39 --> Helper loaded: language_helper
INFO - 2021-07-14 07:00:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:00:39 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:00:39 --> Final output sent to browser
DEBUG - 2021-07-14 07:00:39 --> Total execution time: 0.3058
INFO - 2021-07-14 07:01:11 --> Config Class Initialized
INFO - 2021-07-14 07:01:11 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:01:11 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:01:11 --> Utf8 Class Initialized
INFO - 2021-07-14 07:01:11 --> URI Class Initialized
INFO - 2021-07-14 07:01:11 --> Router Class Initialized
INFO - 2021-07-14 07:01:11 --> Output Class Initialized
INFO - 2021-07-14 07:01:11 --> Security Class Initialized
DEBUG - 2021-07-14 07:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:01:11 --> Input Class Initialized
INFO - 2021-07-14 07:01:11 --> Language Class Initialized
INFO - 2021-07-14 07:01:11 --> Loader Class Initialized
INFO - 2021-07-14 07:01:11 --> Helper loaded: html_helper
INFO - 2021-07-14 07:01:11 --> Helper loaded: url_helper
INFO - 2021-07-14 07:01:11 --> Helper loaded: form_helper
INFO - 2021-07-14 07:01:11 --> Database Driver Class Initialized
INFO - 2021-07-14 07:01:11 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:01:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:01:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:01:11 --> Encryption Class Initialized
INFO - 2021-07-14 07:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:01:11 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:01:11 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:01:11 --> Model "user_model" initialized
INFO - 2021-07-14 07:01:11 --> Model "role_model" initialized
INFO - 2021-07-14 07:01:11 --> Controller Class Initialized
INFO - 2021-07-14 07:01:11 --> Helper loaded: language_helper
INFO - 2021-07-14 07:01:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:01:11 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:01:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:01:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:01:11 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:01:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:01:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:01:11 --> Final output sent to browser
DEBUG - 2021-07-14 07:01:11 --> Total execution time: 0.1016
INFO - 2021-07-14 07:01:13 --> Config Class Initialized
INFO - 2021-07-14 07:01:13 --> Config Class Initialized
INFO - 2021-07-14 07:01:13 --> Hooks Class Initialized
INFO - 2021-07-14 07:01:13 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:01:13 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 07:01:13 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:01:13 --> Utf8 Class Initialized
INFO - 2021-07-14 07:01:13 --> Utf8 Class Initialized
INFO - 2021-07-14 07:01:13 --> URI Class Initialized
INFO - 2021-07-14 07:01:13 --> URI Class Initialized
INFO - 2021-07-14 07:01:13 --> Router Class Initialized
INFO - 2021-07-14 07:01:13 --> Router Class Initialized
INFO - 2021-07-14 07:01:13 --> Output Class Initialized
INFO - 2021-07-14 07:01:13 --> Output Class Initialized
INFO - 2021-07-14 07:01:13 --> Security Class Initialized
INFO - 2021-07-14 07:01:13 --> Security Class Initialized
DEBUG - 2021-07-14 07:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:01:13 --> Input Class Initialized
DEBUG - 2021-07-14 07:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:01:13 --> Input Class Initialized
INFO - 2021-07-14 07:01:13 --> Language Class Initialized
INFO - 2021-07-14 07:01:13 --> Language Class Initialized
INFO - 2021-07-14 07:01:13 --> Loader Class Initialized
INFO - 2021-07-14 07:01:13 --> Loader Class Initialized
INFO - 2021-07-14 07:01:13 --> Helper loaded: html_helper
INFO - 2021-07-14 07:01:13 --> Helper loaded: html_helper
INFO - 2021-07-14 07:01:13 --> Helper loaded: url_helper
INFO - 2021-07-14 07:01:13 --> Helper loaded: url_helper
INFO - 2021-07-14 07:01:13 --> Helper loaded: form_helper
INFO - 2021-07-14 07:01:13 --> Helper loaded: form_helper
INFO - 2021-07-14 07:01:13 --> Database Driver Class Initialized
INFO - 2021-07-14 07:01:13 --> Database Driver Class Initialized
INFO - 2021-07-14 07:01:13 --> Form Validation Class Initialized
INFO - 2021-07-14 07:01:13 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:01:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:01:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:01:13 --> Encryption Class Initialized
DEBUG - 2021-07-14 07:01:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:01:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:01:13 --> Encryption Class Initialized
INFO - 2021-07-14 07:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:01:13 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:01:13 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:01:13 --> Model "user_model" initialized
INFO - 2021-07-14 07:01:13 --> Model "role_model" initialized
INFO - 2021-07-14 07:01:13 --> Controller Class Initialized
INFO - 2021-07-14 07:01:13 --> Helper loaded: language_helper
INFO - 2021-07-14 07:01:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:01:13 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:01:13 --> Final output sent to browser
DEBUG - 2021-07-14 07:01:13 --> Total execution time: 0.0627
INFO - 2021-07-14 07:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:01:13 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:01:13 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:01:13 --> Model "user_model" initialized
INFO - 2021-07-14 07:01:13 --> Model "role_model" initialized
INFO - 2021-07-14 07:01:13 --> Controller Class Initialized
INFO - 2021-07-14 07:01:13 --> Helper loaded: language_helper
INFO - 2021-07-14 07:01:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:01:14 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:01:14 --> Final output sent to browser
DEBUG - 2021-07-14 07:01:14 --> Total execution time: 0.0728
INFO - 2021-07-14 07:03:07 --> Config Class Initialized
INFO - 2021-07-14 07:03:07 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:03:07 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:03:07 --> Utf8 Class Initialized
INFO - 2021-07-14 07:03:07 --> URI Class Initialized
INFO - 2021-07-14 07:03:07 --> Router Class Initialized
INFO - 2021-07-14 07:03:07 --> Output Class Initialized
INFO - 2021-07-14 07:03:07 --> Security Class Initialized
DEBUG - 2021-07-14 07:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:03:07 --> Input Class Initialized
INFO - 2021-07-14 07:03:07 --> Language Class Initialized
INFO - 2021-07-14 07:03:07 --> Loader Class Initialized
INFO - 2021-07-14 07:03:07 --> Helper loaded: html_helper
INFO - 2021-07-14 07:03:07 --> Helper loaded: url_helper
INFO - 2021-07-14 07:03:07 --> Helper loaded: form_helper
INFO - 2021-07-14 07:03:07 --> Database Driver Class Initialized
INFO - 2021-07-14 07:03:07 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:03:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:03:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:03:07 --> Encryption Class Initialized
INFO - 2021-07-14 07:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:03:07 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:03:07 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:03:07 --> Model "user_model" initialized
INFO - 2021-07-14 07:03:07 --> Model "role_model" initialized
INFO - 2021-07-14 07:03:07 --> Controller Class Initialized
INFO - 2021-07-14 07:03:07 --> Helper loaded: language_helper
INFO - 2021-07-14 07:03:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:03:07 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:03:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:03:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:03:07 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:03:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:03:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:03:07 --> Final output sent to browser
DEBUG - 2021-07-14 07:03:07 --> Total execution time: 0.1030
INFO - 2021-07-14 07:03:11 --> Config Class Initialized
INFO - 2021-07-14 07:03:11 --> Config Class Initialized
INFO - 2021-07-14 07:03:11 --> Hooks Class Initialized
INFO - 2021-07-14 07:03:11 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:03:11 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 07:03:11 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:03:11 --> Utf8 Class Initialized
INFO - 2021-07-14 07:03:11 --> Utf8 Class Initialized
INFO - 2021-07-14 07:03:11 --> URI Class Initialized
INFO - 2021-07-14 07:03:11 --> URI Class Initialized
INFO - 2021-07-14 07:03:11 --> Router Class Initialized
INFO - 2021-07-14 07:03:11 --> Router Class Initialized
INFO - 2021-07-14 07:03:11 --> Output Class Initialized
INFO - 2021-07-14 07:03:11 --> Output Class Initialized
INFO - 2021-07-14 07:03:11 --> Security Class Initialized
INFO - 2021-07-14 07:03:11 --> Security Class Initialized
DEBUG - 2021-07-14 07:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:03:11 --> Input Class Initialized
DEBUG - 2021-07-14 07:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:03:11 --> Input Class Initialized
INFO - 2021-07-14 07:03:11 --> Language Class Initialized
INFO - 2021-07-14 07:03:11 --> Language Class Initialized
INFO - 2021-07-14 07:03:11 --> Loader Class Initialized
INFO - 2021-07-14 07:03:11 --> Loader Class Initialized
INFO - 2021-07-14 07:03:11 --> Helper loaded: html_helper
INFO - 2021-07-14 07:03:11 --> Helper loaded: html_helper
INFO - 2021-07-14 07:03:11 --> Helper loaded: url_helper
INFO - 2021-07-14 07:03:11 --> Helper loaded: url_helper
INFO - 2021-07-14 07:03:11 --> Helper loaded: form_helper
INFO - 2021-07-14 07:03:11 --> Helper loaded: form_helper
INFO - 2021-07-14 07:03:11 --> Database Driver Class Initialized
INFO - 2021-07-14 07:03:11 --> Database Driver Class Initialized
INFO - 2021-07-14 07:03:11 --> Form Validation Class Initialized
INFO - 2021-07-14 07:03:11 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:03:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:03:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:03:11 --> Encryption Class Initialized
DEBUG - 2021-07-14 07:03:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:03:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:03:11 --> Encryption Class Initialized
INFO - 2021-07-14 07:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:03:11 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:03:11 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:03:11 --> Model "user_model" initialized
INFO - 2021-07-14 07:03:11 --> Model "role_model" initialized
INFO - 2021-07-14 07:03:11 --> Controller Class Initialized
INFO - 2021-07-14 07:03:11 --> Helper loaded: language_helper
INFO - 2021-07-14 07:03:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:03:11 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:03:11 --> Final output sent to browser
DEBUG - 2021-07-14 07:03:11 --> Total execution time: 0.0634
INFO - 2021-07-14 07:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:03:11 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:03:11 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:03:11 --> Model "user_model" initialized
INFO - 2021-07-14 07:03:11 --> Model "role_model" initialized
INFO - 2021-07-14 07:03:11 --> Controller Class Initialized
INFO - 2021-07-14 07:03:11 --> Helper loaded: language_helper
INFO - 2021-07-14 07:03:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:03:11 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:03:11 --> Final output sent to browser
DEBUG - 2021-07-14 07:03:11 --> Total execution time: 0.0735
INFO - 2021-07-14 07:04:22 --> Config Class Initialized
INFO - 2021-07-14 07:04:22 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:04:22 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:04:22 --> Utf8 Class Initialized
INFO - 2021-07-14 07:04:22 --> URI Class Initialized
INFO - 2021-07-14 07:04:22 --> Router Class Initialized
INFO - 2021-07-14 07:04:22 --> Output Class Initialized
INFO - 2021-07-14 07:04:22 --> Security Class Initialized
DEBUG - 2021-07-14 07:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:04:22 --> Input Class Initialized
INFO - 2021-07-14 07:04:22 --> Language Class Initialized
INFO - 2021-07-14 07:04:22 --> Loader Class Initialized
INFO - 2021-07-14 07:04:22 --> Helper loaded: html_helper
INFO - 2021-07-14 07:04:22 --> Helper loaded: url_helper
INFO - 2021-07-14 07:04:22 --> Helper loaded: form_helper
INFO - 2021-07-14 07:04:22 --> Database Driver Class Initialized
INFO - 2021-07-14 07:04:22 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:04:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:04:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:04:22 --> Encryption Class Initialized
INFO - 2021-07-14 07:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:04:22 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:04:22 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:04:22 --> Model "user_model" initialized
INFO - 2021-07-14 07:04:22 --> Model "role_model" initialized
INFO - 2021-07-14 07:04:22 --> Controller Class Initialized
INFO - 2021-07-14 07:04:22 --> Helper loaded: language_helper
INFO - 2021-07-14 07:04:22 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:04:22 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:04:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:04:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:04:22 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:04:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:04:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:04:22 --> Final output sent to browser
DEBUG - 2021-07-14 07:04:22 --> Total execution time: 0.1206
INFO - 2021-07-14 07:04:25 --> Config Class Initialized
INFO - 2021-07-14 07:04:25 --> Hooks Class Initialized
INFO - 2021-07-14 07:04:25 --> Config Class Initialized
INFO - 2021-07-14 07:04:25 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:04:25 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:04:25 --> Utf8 Class Initialized
INFO - 2021-07-14 07:04:25 --> URI Class Initialized
DEBUG - 2021-07-14 07:04:25 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:04:25 --> Utf8 Class Initialized
INFO - 2021-07-14 07:04:25 --> Router Class Initialized
INFO - 2021-07-14 07:04:25 --> URI Class Initialized
INFO - 2021-07-14 07:04:25 --> Router Class Initialized
INFO - 2021-07-14 07:04:25 --> Output Class Initialized
INFO - 2021-07-14 07:04:25 --> Output Class Initialized
INFO - 2021-07-14 07:04:25 --> Security Class Initialized
DEBUG - 2021-07-14 07:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:04:25 --> Security Class Initialized
INFO - 2021-07-14 07:04:25 --> Input Class Initialized
INFO - 2021-07-14 07:04:25 --> Language Class Initialized
DEBUG - 2021-07-14 07:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:04:25 --> Input Class Initialized
INFO - 2021-07-14 07:04:25 --> Language Class Initialized
INFO - 2021-07-14 07:04:25 --> Loader Class Initialized
INFO - 2021-07-14 07:04:25 --> Helper loaded: html_helper
INFO - 2021-07-14 07:04:25 --> Loader Class Initialized
INFO - 2021-07-14 07:04:25 --> Helper loaded: url_helper
INFO - 2021-07-14 07:04:25 --> Helper loaded: html_helper
INFO - 2021-07-14 07:04:25 --> Helper loaded: url_helper
INFO - 2021-07-14 07:04:25 --> Helper loaded: form_helper
INFO - 2021-07-14 07:04:25 --> Helper loaded: form_helper
INFO - 2021-07-14 07:04:25 --> Database Driver Class Initialized
INFO - 2021-07-14 07:04:25 --> Database Driver Class Initialized
INFO - 2021-07-14 07:04:25 --> Form Validation Class Initialized
INFO - 2021-07-14 07:04:25 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:04:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:04:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:04:25 --> Encryption Class Initialized
DEBUG - 2021-07-14 07:04:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:04:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:04:25 --> Encryption Class Initialized
INFO - 2021-07-14 07:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:04:25 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:04:25 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:04:25 --> Model "user_model" initialized
INFO - 2021-07-14 07:04:25 --> Model "role_model" initialized
INFO - 2021-07-14 07:04:25 --> Controller Class Initialized
INFO - 2021-07-14 07:04:25 --> Helper loaded: language_helper
INFO - 2021-07-14 07:04:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:04:25 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:04:25 --> Final output sent to browser
DEBUG - 2021-07-14 07:04:25 --> Total execution time: 0.0679
INFO - 2021-07-14 07:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:04:25 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:04:25 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:04:25 --> Model "user_model" initialized
INFO - 2021-07-14 07:04:25 --> Model "role_model" initialized
INFO - 2021-07-14 07:04:25 --> Controller Class Initialized
INFO - 2021-07-14 07:04:25 --> Helper loaded: language_helper
INFO - 2021-07-14 07:04:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:04:25 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:04:25 --> Final output sent to browser
DEBUG - 2021-07-14 07:04:25 --> Total execution time: 0.0754
INFO - 2021-07-14 07:05:23 --> Config Class Initialized
INFO - 2021-07-14 07:05:23 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:05:23 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:05:23 --> Utf8 Class Initialized
INFO - 2021-07-14 07:05:23 --> URI Class Initialized
INFO - 2021-07-14 07:05:23 --> Router Class Initialized
INFO - 2021-07-14 07:05:23 --> Output Class Initialized
INFO - 2021-07-14 07:05:23 --> Security Class Initialized
DEBUG - 2021-07-14 07:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:05:23 --> Input Class Initialized
INFO - 2021-07-14 07:05:23 --> Language Class Initialized
INFO - 2021-07-14 07:05:23 --> Loader Class Initialized
INFO - 2021-07-14 07:05:23 --> Helper loaded: html_helper
INFO - 2021-07-14 07:05:23 --> Helper loaded: url_helper
INFO - 2021-07-14 07:05:23 --> Helper loaded: form_helper
INFO - 2021-07-14 07:05:23 --> Database Driver Class Initialized
INFO - 2021-07-14 07:05:23 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:05:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:05:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:05:23 --> Encryption Class Initialized
INFO - 2021-07-14 07:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:05:23 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:05:23 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:05:23 --> Model "user_model" initialized
INFO - 2021-07-14 07:05:23 --> Model "role_model" initialized
INFO - 2021-07-14 07:05:23 --> Controller Class Initialized
INFO - 2021-07-14 07:05:23 --> Helper loaded: language_helper
INFO - 2021-07-14 07:05:23 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:05:23 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:05:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:05:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:05:23 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:05:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:05:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:05:23 --> Final output sent to browser
DEBUG - 2021-07-14 07:05:23 --> Total execution time: 0.1092
INFO - 2021-07-14 07:05:26 --> Config Class Initialized
INFO - 2021-07-14 07:05:26 --> Config Class Initialized
INFO - 2021-07-14 07:05:26 --> Hooks Class Initialized
INFO - 2021-07-14 07:05:26 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:05:26 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 07:05:26 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:05:26 --> Utf8 Class Initialized
INFO - 2021-07-14 07:05:26 --> Utf8 Class Initialized
INFO - 2021-07-14 07:05:26 --> URI Class Initialized
INFO - 2021-07-14 07:05:26 --> URI Class Initialized
INFO - 2021-07-14 07:05:26 --> Router Class Initialized
INFO - 2021-07-14 07:05:26 --> Router Class Initialized
INFO - 2021-07-14 07:05:26 --> Output Class Initialized
INFO - 2021-07-14 07:05:26 --> Output Class Initialized
INFO - 2021-07-14 07:05:27 --> Security Class Initialized
INFO - 2021-07-14 07:05:27 --> Security Class Initialized
DEBUG - 2021-07-14 07:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 07:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:05:27 --> Input Class Initialized
INFO - 2021-07-14 07:05:27 --> Input Class Initialized
INFO - 2021-07-14 07:05:27 --> Language Class Initialized
INFO - 2021-07-14 07:05:27 --> Language Class Initialized
INFO - 2021-07-14 07:05:27 --> Loader Class Initialized
INFO - 2021-07-14 07:05:27 --> Loader Class Initialized
INFO - 2021-07-14 07:05:27 --> Helper loaded: html_helper
INFO - 2021-07-14 07:05:27 --> Helper loaded: html_helper
INFO - 2021-07-14 07:05:27 --> Helper loaded: url_helper
INFO - 2021-07-14 07:05:27 --> Helper loaded: url_helper
INFO - 2021-07-14 07:05:27 --> Helper loaded: form_helper
INFO - 2021-07-14 07:05:27 --> Helper loaded: form_helper
INFO - 2021-07-14 07:05:27 --> Database Driver Class Initialized
INFO - 2021-07-14 07:05:27 --> Database Driver Class Initialized
INFO - 2021-07-14 07:05:27 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:05:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:05:27 --> Form Validation Class Initialized
INFO - 2021-07-14 07:05:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:05:27 --> Encryption Class Initialized
DEBUG - 2021-07-14 07:05:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:05:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:05:27 --> Encryption Class Initialized
INFO - 2021-07-14 07:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:05:27 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:05:27 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:05:27 --> Model "user_model" initialized
INFO - 2021-07-14 07:05:27 --> Model "role_model" initialized
INFO - 2021-07-14 07:05:27 --> Controller Class Initialized
INFO - 2021-07-14 07:05:27 --> Helper loaded: language_helper
INFO - 2021-07-14 07:05:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:05:27 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:05:27 --> Final output sent to browser
DEBUG - 2021-07-14 07:05:27 --> Total execution time: 0.0664
INFO - 2021-07-14 07:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:05:27 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:05:27 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:05:27 --> Model "user_model" initialized
INFO - 2021-07-14 07:05:27 --> Model "role_model" initialized
INFO - 2021-07-14 07:05:27 --> Controller Class Initialized
INFO - 2021-07-14 07:05:27 --> Helper loaded: language_helper
INFO - 2021-07-14 07:05:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:05:27 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:05:27 --> Final output sent to browser
DEBUG - 2021-07-14 07:05:27 --> Total execution time: 0.0775
INFO - 2021-07-14 07:05:37 --> Config Class Initialized
INFO - 2021-07-14 07:05:37 --> Config Class Initialized
INFO - 2021-07-14 07:05:37 --> Hooks Class Initialized
INFO - 2021-07-14 07:05:37 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:05:37 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:05:37 --> Utf8 Class Initialized
DEBUG - 2021-07-14 07:05:37 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:05:37 --> Utf8 Class Initialized
INFO - 2021-07-14 07:05:37 --> URI Class Initialized
INFO - 2021-07-14 07:05:37 --> URI Class Initialized
INFO - 2021-07-14 07:05:37 --> Router Class Initialized
INFO - 2021-07-14 07:05:37 --> Router Class Initialized
INFO - 2021-07-14 07:05:37 --> Output Class Initialized
INFO - 2021-07-14 07:05:37 --> Output Class Initialized
INFO - 2021-07-14 07:05:37 --> Security Class Initialized
INFO - 2021-07-14 07:05:37 --> Security Class Initialized
DEBUG - 2021-07-14 07:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 07:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:05:37 --> Input Class Initialized
INFO - 2021-07-14 07:05:37 --> Input Class Initialized
INFO - 2021-07-14 07:05:37 --> Language Class Initialized
INFO - 2021-07-14 07:05:37 --> Language Class Initialized
INFO - 2021-07-14 07:05:37 --> Loader Class Initialized
INFO - 2021-07-14 07:05:37 --> Helper loaded: html_helper
INFO - 2021-07-14 07:05:37 --> Loader Class Initialized
INFO - 2021-07-14 07:05:37 --> Helper loaded: url_helper
INFO - 2021-07-14 07:05:37 --> Helper loaded: html_helper
INFO - 2021-07-14 07:05:37 --> Helper loaded: form_helper
INFO - 2021-07-14 07:05:37 --> Helper loaded: url_helper
INFO - 2021-07-14 07:05:37 --> Helper loaded: form_helper
INFO - 2021-07-14 07:05:37 --> Database Driver Class Initialized
INFO - 2021-07-14 07:05:37 --> Database Driver Class Initialized
INFO - 2021-07-14 07:05:37 --> Form Validation Class Initialized
INFO - 2021-07-14 07:05:37 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-14 07:05:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:05:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:05:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:05:37 --> Encryption Class Initialized
INFO - 2021-07-14 07:05:37 --> Encryption Class Initialized
INFO - 2021-07-14 07:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:05:37 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:05:37 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:05:37 --> Model "user_model" initialized
INFO - 2021-07-14 07:05:37 --> Model "role_model" initialized
INFO - 2021-07-14 07:05:37 --> Controller Class Initialized
INFO - 2021-07-14 07:05:37 --> Helper loaded: language_helper
INFO - 2021-07-14 07:05:37 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:05:37 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:05:37 --> Final output sent to browser
DEBUG - 2021-07-14 07:05:37 --> Total execution time: 0.0635
INFO - 2021-07-14 07:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:05:37 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:05:37 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:05:37 --> Model "user_model" initialized
INFO - 2021-07-14 07:05:37 --> Model "role_model" initialized
INFO - 2021-07-14 07:05:37 --> Controller Class Initialized
INFO - 2021-07-14 07:05:37 --> Helper loaded: language_helper
INFO - 2021-07-14 07:05:37 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:05:37 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:05:37 --> Final output sent to browser
DEBUG - 2021-07-14 07:05:37 --> Total execution time: 0.0737
INFO - 2021-07-14 07:06:13 --> Config Class Initialized
INFO - 2021-07-14 07:06:13 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:06:13 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:06:13 --> Utf8 Class Initialized
INFO - 2021-07-14 07:06:13 --> URI Class Initialized
INFO - 2021-07-14 07:06:13 --> Router Class Initialized
INFO - 2021-07-14 07:06:13 --> Output Class Initialized
INFO - 2021-07-14 07:06:13 --> Security Class Initialized
DEBUG - 2021-07-14 07:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:06:13 --> Input Class Initialized
INFO - 2021-07-14 07:06:13 --> Language Class Initialized
INFO - 2021-07-14 07:06:13 --> Loader Class Initialized
INFO - 2021-07-14 07:06:13 --> Helper loaded: html_helper
INFO - 2021-07-14 07:06:13 --> Helper loaded: url_helper
INFO - 2021-07-14 07:06:13 --> Helper loaded: form_helper
INFO - 2021-07-14 07:06:13 --> Database Driver Class Initialized
INFO - 2021-07-14 07:06:13 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:06:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:06:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:06:13 --> Encryption Class Initialized
INFO - 2021-07-14 07:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:06:13 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:06:13 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:06:13 --> Model "user_model" initialized
INFO - 2021-07-14 07:06:13 --> Model "role_model" initialized
INFO - 2021-07-14 07:06:13 --> Controller Class Initialized
INFO - 2021-07-14 07:06:13 --> Helper loaded: language_helper
INFO - 2021-07-14 07:06:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:06:13 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:06:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:06:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:06:13 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:06:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:06:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:06:13 --> Final output sent to browser
DEBUG - 2021-07-14 07:06:13 --> Total execution time: 0.1009
INFO - 2021-07-14 07:06:18 --> Config Class Initialized
INFO - 2021-07-14 07:06:18 --> Hooks Class Initialized
INFO - 2021-07-14 07:06:18 --> Config Class Initialized
INFO - 2021-07-14 07:06:18 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:06:18 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:06:18 --> Utf8 Class Initialized
DEBUG - 2021-07-14 07:06:18 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:06:18 --> Utf8 Class Initialized
INFO - 2021-07-14 07:06:18 --> URI Class Initialized
INFO - 2021-07-14 07:06:18 --> URI Class Initialized
INFO - 2021-07-14 07:06:18 --> Router Class Initialized
INFO - 2021-07-14 07:06:18 --> Router Class Initialized
INFO - 2021-07-14 07:06:18 --> Output Class Initialized
INFO - 2021-07-14 07:06:18 --> Output Class Initialized
INFO - 2021-07-14 07:06:18 --> Security Class Initialized
INFO - 2021-07-14 07:06:18 --> Security Class Initialized
DEBUG - 2021-07-14 07:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:06:18 --> Input Class Initialized
DEBUG - 2021-07-14 07:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:06:18 --> Language Class Initialized
INFO - 2021-07-14 07:06:18 --> Input Class Initialized
INFO - 2021-07-14 07:06:18 --> Language Class Initialized
INFO - 2021-07-14 07:06:18 --> Loader Class Initialized
INFO - 2021-07-14 07:06:18 --> Loader Class Initialized
INFO - 2021-07-14 07:06:18 --> Helper loaded: html_helper
INFO - 2021-07-14 07:06:18 --> Helper loaded: html_helper
INFO - 2021-07-14 07:06:18 --> Helper loaded: url_helper
INFO - 2021-07-14 07:06:18 --> Helper loaded: url_helper
INFO - 2021-07-14 07:06:18 --> Helper loaded: form_helper
INFO - 2021-07-14 07:06:18 --> Helper loaded: form_helper
INFO - 2021-07-14 07:06:18 --> Database Driver Class Initialized
INFO - 2021-07-14 07:06:18 --> Database Driver Class Initialized
INFO - 2021-07-14 07:06:18 --> Form Validation Class Initialized
INFO - 2021-07-14 07:06:18 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:06:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:06:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:06:18 --> Encryption Class Initialized
DEBUG - 2021-07-14 07:06:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:06:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:06:18 --> Encryption Class Initialized
INFO - 2021-07-14 07:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:06:18 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:06:18 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:06:18 --> Model "user_model" initialized
INFO - 2021-07-14 07:06:18 --> Model "role_model" initialized
INFO - 2021-07-14 07:06:18 --> Controller Class Initialized
INFO - 2021-07-14 07:06:18 --> Helper loaded: language_helper
INFO - 2021-07-14 07:06:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:06:18 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:06:18 --> Final output sent to browser
DEBUG - 2021-07-14 07:06:18 --> Total execution time: 0.0683
INFO - 2021-07-14 07:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:06:18 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:06:18 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:06:18 --> Model "user_model" initialized
INFO - 2021-07-14 07:06:18 --> Model "role_model" initialized
INFO - 2021-07-14 07:06:18 --> Controller Class Initialized
INFO - 2021-07-14 07:06:18 --> Helper loaded: language_helper
INFO - 2021-07-14 07:06:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:06:18 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:06:18 --> Final output sent to browser
DEBUG - 2021-07-14 07:06:18 --> Total execution time: 0.0806
INFO - 2021-07-14 07:08:18 --> Config Class Initialized
INFO - 2021-07-14 07:08:18 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:08:18 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:08:18 --> Utf8 Class Initialized
INFO - 2021-07-14 07:08:18 --> URI Class Initialized
INFO - 2021-07-14 07:08:18 --> Router Class Initialized
INFO - 2021-07-14 07:08:18 --> Output Class Initialized
INFO - 2021-07-14 07:08:18 --> Security Class Initialized
DEBUG - 2021-07-14 07:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:08:18 --> Input Class Initialized
INFO - 2021-07-14 07:08:18 --> Language Class Initialized
INFO - 2021-07-14 07:08:18 --> Loader Class Initialized
INFO - 2021-07-14 07:08:18 --> Helper loaded: html_helper
INFO - 2021-07-14 07:08:18 --> Helper loaded: url_helper
INFO - 2021-07-14 07:08:18 --> Helper loaded: form_helper
INFO - 2021-07-14 07:08:18 --> Database Driver Class Initialized
INFO - 2021-07-14 07:08:18 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:08:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:08:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:08:18 --> Encryption Class Initialized
INFO - 2021-07-14 07:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:08:18 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:08:18 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:08:18 --> Model "user_model" initialized
INFO - 2021-07-14 07:08:18 --> Model "role_model" initialized
INFO - 2021-07-14 07:08:18 --> Controller Class Initialized
INFO - 2021-07-14 07:08:18 --> Helper loaded: language_helper
INFO - 2021-07-14 07:08:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:08:18 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:08:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:08:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:08:19 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:08:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:08:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:08:19 --> Final output sent to browser
DEBUG - 2021-07-14 07:08:19 --> Total execution time: 0.1134
INFO - 2021-07-14 07:08:23 --> Config Class Initialized
INFO - 2021-07-14 07:08:23 --> Hooks Class Initialized
INFO - 2021-07-14 07:08:23 --> Config Class Initialized
INFO - 2021-07-14 07:08:23 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:08:23 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:08:23 --> Utf8 Class Initialized
INFO - 2021-07-14 07:08:23 --> URI Class Initialized
DEBUG - 2021-07-14 07:08:23 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:08:23 --> Utf8 Class Initialized
INFO - 2021-07-14 07:08:23 --> URI Class Initialized
INFO - 2021-07-14 07:08:23 --> Router Class Initialized
INFO - 2021-07-14 07:08:23 --> Router Class Initialized
INFO - 2021-07-14 07:08:23 --> Output Class Initialized
INFO - 2021-07-14 07:08:23 --> Output Class Initialized
INFO - 2021-07-14 07:08:23 --> Security Class Initialized
INFO - 2021-07-14 07:08:23 --> Security Class Initialized
DEBUG - 2021-07-14 07:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:08:23 --> Input Class Initialized
INFO - 2021-07-14 07:08:23 --> Language Class Initialized
DEBUG - 2021-07-14 07:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:08:23 --> Input Class Initialized
INFO - 2021-07-14 07:08:23 --> Language Class Initialized
INFO - 2021-07-14 07:08:23 --> Loader Class Initialized
INFO - 2021-07-14 07:08:23 --> Helper loaded: html_helper
INFO - 2021-07-14 07:08:23 --> Loader Class Initialized
INFO - 2021-07-14 07:08:23 --> Helper loaded: url_helper
INFO - 2021-07-14 07:08:23 --> Helper loaded: html_helper
INFO - 2021-07-14 07:08:23 --> Helper loaded: form_helper
INFO - 2021-07-14 07:08:23 --> Helper loaded: url_helper
INFO - 2021-07-14 07:08:23 --> Helper loaded: form_helper
INFO - 2021-07-14 07:08:23 --> Database Driver Class Initialized
INFO - 2021-07-14 07:08:23 --> Database Driver Class Initialized
INFO - 2021-07-14 07:08:23 --> Form Validation Class Initialized
INFO - 2021-07-14 07:08:23 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:08:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:08:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:08:23 --> Encryption Class Initialized
DEBUG - 2021-07-14 07:08:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:08:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:08:23 --> Encryption Class Initialized
INFO - 2021-07-14 07:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:08:23 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:08:23 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:08:23 --> Model "user_model" initialized
INFO - 2021-07-14 07:08:23 --> Model "role_model" initialized
INFO - 2021-07-14 07:08:23 --> Controller Class Initialized
INFO - 2021-07-14 07:08:23 --> Helper loaded: language_helper
INFO - 2021-07-14 07:08:23 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:08:23 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:08:23 --> Final output sent to browser
DEBUG - 2021-07-14 07:08:23 --> Total execution time: 0.0690
INFO - 2021-07-14 07:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:08:23 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:08:23 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:08:23 --> Model "user_model" initialized
INFO - 2021-07-14 07:08:23 --> Model "role_model" initialized
INFO - 2021-07-14 07:08:23 --> Controller Class Initialized
INFO - 2021-07-14 07:08:23 --> Helper loaded: language_helper
INFO - 2021-07-14 07:08:23 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:08:23 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:08:23 --> Final output sent to browser
DEBUG - 2021-07-14 07:08:23 --> Total execution time: 0.0819
INFO - 2021-07-14 07:09:02 --> Config Class Initialized
INFO - 2021-07-14 07:09:02 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:09:02 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:09:02 --> Utf8 Class Initialized
INFO - 2021-07-14 07:09:02 --> URI Class Initialized
INFO - 2021-07-14 07:09:02 --> Router Class Initialized
INFO - 2021-07-14 07:09:02 --> Output Class Initialized
INFO - 2021-07-14 07:09:02 --> Security Class Initialized
DEBUG - 2021-07-14 07:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:09:02 --> Input Class Initialized
INFO - 2021-07-14 07:09:02 --> Language Class Initialized
INFO - 2021-07-14 07:09:02 --> Loader Class Initialized
INFO - 2021-07-14 07:09:02 --> Helper loaded: html_helper
INFO - 2021-07-14 07:09:02 --> Helper loaded: url_helper
INFO - 2021-07-14 07:09:02 --> Helper loaded: form_helper
INFO - 2021-07-14 07:09:02 --> Database Driver Class Initialized
INFO - 2021-07-14 07:09:02 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:09:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:09:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:09:02 --> Encryption Class Initialized
INFO - 2021-07-14 07:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:09:02 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:09:02 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:09:02 --> Model "user_model" initialized
INFO - 2021-07-14 07:09:02 --> Model "role_model" initialized
INFO - 2021-07-14 07:09:02 --> Controller Class Initialized
INFO - 2021-07-14 07:09:02 --> Helper loaded: language_helper
INFO - 2021-07-14 07:09:02 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:09:02 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:09:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:09:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:09:02 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:09:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:09:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:09:02 --> Final output sent to browser
DEBUG - 2021-07-14 07:09:02 --> Total execution time: 0.1077
INFO - 2021-07-14 07:09:06 --> Config Class Initialized
INFO - 2021-07-14 07:09:06 --> Hooks Class Initialized
INFO - 2021-07-14 07:09:06 --> Config Class Initialized
INFO - 2021-07-14 07:09:06 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:09:06 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:09:06 --> Utf8 Class Initialized
DEBUG - 2021-07-14 07:09:06 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:09:06 --> Utf8 Class Initialized
INFO - 2021-07-14 07:09:06 --> URI Class Initialized
INFO - 2021-07-14 07:09:06 --> URI Class Initialized
INFO - 2021-07-14 07:09:06 --> Router Class Initialized
INFO - 2021-07-14 07:09:06 --> Router Class Initialized
INFO - 2021-07-14 07:09:06 --> Output Class Initialized
INFO - 2021-07-14 07:09:06 --> Output Class Initialized
INFO - 2021-07-14 07:09:06 --> Security Class Initialized
INFO - 2021-07-14 07:09:06 --> Security Class Initialized
DEBUG - 2021-07-14 07:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:09:06 --> Input Class Initialized
INFO - 2021-07-14 07:09:06 --> Language Class Initialized
DEBUG - 2021-07-14 07:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:09:06 --> Input Class Initialized
INFO - 2021-07-14 07:09:06 --> Language Class Initialized
INFO - 2021-07-14 07:09:06 --> Loader Class Initialized
INFO - 2021-07-14 07:09:06 --> Loader Class Initialized
INFO - 2021-07-14 07:09:06 --> Helper loaded: html_helper
INFO - 2021-07-14 07:09:06 --> Helper loaded: html_helper
INFO - 2021-07-14 07:09:06 --> Helper loaded: url_helper
INFO - 2021-07-14 07:09:06 --> Helper loaded: url_helper
INFO - 2021-07-14 07:09:06 --> Helper loaded: form_helper
INFO - 2021-07-14 07:09:06 --> Helper loaded: form_helper
INFO - 2021-07-14 07:09:06 --> Database Driver Class Initialized
INFO - 2021-07-14 07:09:06 --> Database Driver Class Initialized
INFO - 2021-07-14 07:09:06 --> Form Validation Class Initialized
INFO - 2021-07-14 07:09:06 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-14 07:09:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:09:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:09:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:09:06 --> Encryption Class Initialized
INFO - 2021-07-14 07:09:06 --> Encryption Class Initialized
INFO - 2021-07-14 07:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:09:06 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:09:06 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:09:06 --> Model "user_model" initialized
INFO - 2021-07-14 07:09:06 --> Model "role_model" initialized
INFO - 2021-07-14 07:09:06 --> Controller Class Initialized
INFO - 2021-07-14 07:09:06 --> Helper loaded: language_helper
INFO - 2021-07-14 07:09:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:09:06 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:09:06 --> Final output sent to browser
DEBUG - 2021-07-14 07:09:06 --> Total execution time: 0.0559
INFO - 2021-07-14 07:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:09:06 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:09:06 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:09:06 --> Model "user_model" initialized
INFO - 2021-07-14 07:09:06 --> Model "role_model" initialized
INFO - 2021-07-14 07:09:06 --> Controller Class Initialized
INFO - 2021-07-14 07:09:06 --> Helper loaded: language_helper
INFO - 2021-07-14 07:09:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:09:06 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:09:06 --> Final output sent to browser
DEBUG - 2021-07-14 07:09:06 --> Total execution time: 0.0660
INFO - 2021-07-14 07:09:39 --> Config Class Initialized
INFO - 2021-07-14 07:09:39 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:09:39 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:09:39 --> Utf8 Class Initialized
INFO - 2021-07-14 07:09:39 --> URI Class Initialized
INFO - 2021-07-14 07:09:39 --> Router Class Initialized
INFO - 2021-07-14 07:09:39 --> Output Class Initialized
INFO - 2021-07-14 07:09:39 --> Security Class Initialized
DEBUG - 2021-07-14 07:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:09:39 --> Input Class Initialized
INFO - 2021-07-14 07:09:39 --> Language Class Initialized
INFO - 2021-07-14 07:09:39 --> Loader Class Initialized
INFO - 2021-07-14 07:09:39 --> Helper loaded: html_helper
INFO - 2021-07-14 07:09:39 --> Helper loaded: url_helper
INFO - 2021-07-14 07:09:39 --> Helper loaded: form_helper
INFO - 2021-07-14 07:09:39 --> Database Driver Class Initialized
INFO - 2021-07-14 07:09:39 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:09:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:09:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:09:39 --> Encryption Class Initialized
INFO - 2021-07-14 07:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:09:39 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:09:39 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:09:39 --> Model "user_model" initialized
INFO - 2021-07-14 07:09:39 --> Model "role_model" initialized
INFO - 2021-07-14 07:09:39 --> Controller Class Initialized
INFO - 2021-07-14 07:09:39 --> Helper loaded: language_helper
INFO - 2021-07-14 07:09:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:09:39 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:09:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:09:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:09:39 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:09:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:09:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:09:39 --> Final output sent to browser
DEBUG - 2021-07-14 07:09:39 --> Total execution time: 0.1017
INFO - 2021-07-14 07:09:43 --> Config Class Initialized
INFO - 2021-07-14 07:09:43 --> Config Class Initialized
INFO - 2021-07-14 07:09:43 --> Hooks Class Initialized
INFO - 2021-07-14 07:09:43 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:09:43 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 07:09:43 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:09:43 --> Utf8 Class Initialized
INFO - 2021-07-14 07:09:43 --> Utf8 Class Initialized
INFO - 2021-07-14 07:09:43 --> URI Class Initialized
INFO - 2021-07-14 07:09:43 --> URI Class Initialized
INFO - 2021-07-14 07:09:44 --> Router Class Initialized
INFO - 2021-07-14 07:09:44 --> Router Class Initialized
INFO - 2021-07-14 07:09:44 --> Output Class Initialized
INFO - 2021-07-14 07:09:44 --> Output Class Initialized
INFO - 2021-07-14 07:09:44 --> Security Class Initialized
INFO - 2021-07-14 07:09:44 --> Security Class Initialized
DEBUG - 2021-07-14 07:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 07:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:09:44 --> Input Class Initialized
INFO - 2021-07-14 07:09:44 --> Input Class Initialized
INFO - 2021-07-14 07:09:44 --> Language Class Initialized
INFO - 2021-07-14 07:09:44 --> Language Class Initialized
INFO - 2021-07-14 07:09:44 --> Loader Class Initialized
INFO - 2021-07-14 07:09:44 --> Loader Class Initialized
INFO - 2021-07-14 07:09:44 --> Helper loaded: html_helper
INFO - 2021-07-14 07:09:44 --> Helper loaded: html_helper
INFO - 2021-07-14 07:09:44 --> Helper loaded: url_helper
INFO - 2021-07-14 07:09:44 --> Helper loaded: url_helper
INFO - 2021-07-14 07:09:44 --> Helper loaded: form_helper
INFO - 2021-07-14 07:09:44 --> Helper loaded: form_helper
INFO - 2021-07-14 07:09:44 --> Database Driver Class Initialized
INFO - 2021-07-14 07:09:44 --> Database Driver Class Initialized
INFO - 2021-07-14 07:09:44 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:09:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:09:44 --> Form Validation Class Initialized
INFO - 2021-07-14 07:09:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:09:44 --> Encryption Class Initialized
DEBUG - 2021-07-14 07:09:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:09:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:09:44 --> Encryption Class Initialized
INFO - 2021-07-14 07:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:09:44 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:09:44 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:09:44 --> Model "user_model" initialized
INFO - 2021-07-14 07:09:44 --> Model "role_model" initialized
INFO - 2021-07-14 07:09:44 --> Controller Class Initialized
INFO - 2021-07-14 07:09:44 --> Helper loaded: language_helper
INFO - 2021-07-14 07:09:44 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:09:44 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:09:44 --> Final output sent to browser
DEBUG - 2021-07-14 07:09:44 --> Total execution time: 0.0622
INFO - 2021-07-14 07:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:09:44 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:09:44 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:09:44 --> Model "user_model" initialized
INFO - 2021-07-14 07:09:44 --> Model "role_model" initialized
INFO - 2021-07-14 07:09:44 --> Controller Class Initialized
INFO - 2021-07-14 07:09:44 --> Helper loaded: language_helper
INFO - 2021-07-14 07:09:44 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:09:44 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:09:44 --> Final output sent to browser
DEBUG - 2021-07-14 07:09:44 --> Total execution time: 0.0725
INFO - 2021-07-14 07:09:59 --> Config Class Initialized
INFO - 2021-07-14 07:09:59 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:09:59 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:09:59 --> Utf8 Class Initialized
INFO - 2021-07-14 07:09:59 --> URI Class Initialized
INFO - 2021-07-14 07:09:59 --> Router Class Initialized
INFO - 2021-07-14 07:09:59 --> Output Class Initialized
INFO - 2021-07-14 07:09:59 --> Security Class Initialized
DEBUG - 2021-07-14 07:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:09:59 --> Input Class Initialized
INFO - 2021-07-14 07:09:59 --> Language Class Initialized
INFO - 2021-07-14 07:09:59 --> Loader Class Initialized
INFO - 2021-07-14 07:09:59 --> Helper loaded: html_helper
INFO - 2021-07-14 07:09:59 --> Helper loaded: url_helper
INFO - 2021-07-14 07:09:59 --> Helper loaded: form_helper
INFO - 2021-07-14 07:09:59 --> Database Driver Class Initialized
INFO - 2021-07-14 07:09:59 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:09:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:09:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:09:59 --> Encryption Class Initialized
INFO - 2021-07-14 07:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:09:59 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:09:59 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:09:59 --> Model "user_model" initialized
INFO - 2021-07-14 07:09:59 --> Model "role_model" initialized
INFO - 2021-07-14 07:09:59 --> Controller Class Initialized
INFO - 2021-07-14 07:09:59 --> Helper loaded: language_helper
INFO - 2021-07-14 07:09:59 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:09:59 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:09:59 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:09:59 --> Model "Product_model" initialized
INFO - 2021-07-14 07:09:59 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:09:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:09:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:09:59 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 07:09:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 07:09:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:09:59 --> Final output sent to browser
DEBUG - 2021-07-14 07:09:59 --> Total execution time: 0.1231
INFO - 2021-07-14 07:10:06 --> Config Class Initialized
INFO - 2021-07-14 07:10:06 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:10:06 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:10:06 --> Utf8 Class Initialized
INFO - 2021-07-14 07:10:06 --> URI Class Initialized
INFO - 2021-07-14 07:10:06 --> Router Class Initialized
INFO - 2021-07-14 07:10:06 --> Output Class Initialized
INFO - 2021-07-14 07:10:06 --> Security Class Initialized
DEBUG - 2021-07-14 07:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:10:06 --> Input Class Initialized
INFO - 2021-07-14 07:10:06 --> Language Class Initialized
INFO - 2021-07-14 07:10:06 --> Loader Class Initialized
INFO - 2021-07-14 07:10:06 --> Helper loaded: html_helper
INFO - 2021-07-14 07:10:06 --> Helper loaded: url_helper
INFO - 2021-07-14 07:10:06 --> Helper loaded: form_helper
INFO - 2021-07-14 07:10:06 --> Database Driver Class Initialized
INFO - 2021-07-14 07:10:06 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:10:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:10:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:10:06 --> Encryption Class Initialized
INFO - 2021-07-14 07:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:10:06 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:10:06 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:10:06 --> Model "user_model" initialized
INFO - 2021-07-14 07:10:06 --> Model "role_model" initialized
INFO - 2021-07-14 07:10:06 --> Controller Class Initialized
INFO - 2021-07-14 07:10:06 --> Helper loaded: language_helper
INFO - 2021-07-14 07:10:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:10:06 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:10:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:10:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:10:07 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:10:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:10:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:10:07 --> Final output sent to browser
DEBUG - 2021-07-14 07:10:07 --> Total execution time: 0.0733
INFO - 2021-07-14 07:10:09 --> Config Class Initialized
INFO - 2021-07-14 07:10:09 --> Hooks Class Initialized
INFO - 2021-07-14 07:10:09 --> Config Class Initialized
INFO - 2021-07-14 07:10:09 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:10:09 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:10:09 --> Utf8 Class Initialized
DEBUG - 2021-07-14 07:10:09 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:10:09 --> Utf8 Class Initialized
INFO - 2021-07-14 07:10:09 --> URI Class Initialized
INFO - 2021-07-14 07:10:09 --> URI Class Initialized
INFO - 2021-07-14 07:10:09 --> Router Class Initialized
INFO - 2021-07-14 07:10:09 --> Router Class Initialized
INFO - 2021-07-14 07:10:09 --> Output Class Initialized
INFO - 2021-07-14 07:10:09 --> Output Class Initialized
INFO - 2021-07-14 07:10:09 --> Security Class Initialized
INFO - 2021-07-14 07:10:09 --> Security Class Initialized
DEBUG - 2021-07-14 07:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 07:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:10:09 --> Input Class Initialized
INFO - 2021-07-14 07:10:09 --> Input Class Initialized
INFO - 2021-07-14 07:10:09 --> Language Class Initialized
INFO - 2021-07-14 07:10:09 --> Language Class Initialized
INFO - 2021-07-14 07:10:09 --> Loader Class Initialized
INFO - 2021-07-14 07:10:09 --> Loader Class Initialized
INFO - 2021-07-14 07:10:09 --> Helper loaded: html_helper
INFO - 2021-07-14 07:10:09 --> Helper loaded: html_helper
INFO - 2021-07-14 07:10:09 --> Helper loaded: url_helper
INFO - 2021-07-14 07:10:09 --> Helper loaded: url_helper
INFO - 2021-07-14 07:10:09 --> Helper loaded: form_helper
INFO - 2021-07-14 07:10:09 --> Helper loaded: form_helper
INFO - 2021-07-14 07:10:09 --> Database Driver Class Initialized
INFO - 2021-07-14 07:10:09 --> Database Driver Class Initialized
INFO - 2021-07-14 07:10:09 --> Form Validation Class Initialized
INFO - 2021-07-14 07:10:09 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:10:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:10:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:10:09 --> Encryption Class Initialized
DEBUG - 2021-07-14 07:10:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:10:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:10:09 --> Encryption Class Initialized
INFO - 2021-07-14 07:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:10:09 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:10:09 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:10:09 --> Model "user_model" initialized
INFO - 2021-07-14 07:10:09 --> Model "role_model" initialized
INFO - 2021-07-14 07:10:09 --> Controller Class Initialized
INFO - 2021-07-14 07:10:09 --> Helper loaded: language_helper
INFO - 2021-07-14 07:10:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:10:09 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:10:09 --> Final output sent to browser
DEBUG - 2021-07-14 07:10:09 --> Total execution time: 0.0677
INFO - 2021-07-14 07:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:10:09 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:10:09 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:10:09 --> Model "user_model" initialized
INFO - 2021-07-14 07:10:09 --> Model "role_model" initialized
INFO - 2021-07-14 07:10:09 --> Controller Class Initialized
INFO - 2021-07-14 07:10:09 --> Helper loaded: language_helper
INFO - 2021-07-14 07:10:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:10:09 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:10:09 --> Final output sent to browser
DEBUG - 2021-07-14 07:10:09 --> Total execution time: 0.0791
INFO - 2021-07-14 07:10:15 --> Config Class Initialized
INFO - 2021-07-14 07:10:15 --> Hooks Class Initialized
INFO - 2021-07-14 07:10:15 --> Config Class Initialized
INFO - 2021-07-14 07:10:15 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:10:15 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:10:15 --> Utf8 Class Initialized
INFO - 2021-07-14 07:10:15 --> URI Class Initialized
DEBUG - 2021-07-14 07:10:15 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:10:15 --> Utf8 Class Initialized
INFO - 2021-07-14 07:10:15 --> Router Class Initialized
INFO - 2021-07-14 07:10:15 --> URI Class Initialized
INFO - 2021-07-14 07:10:15 --> Router Class Initialized
INFO - 2021-07-14 07:10:15 --> Output Class Initialized
INFO - 2021-07-14 07:10:15 --> Security Class Initialized
INFO - 2021-07-14 07:10:15 --> Output Class Initialized
DEBUG - 2021-07-14 07:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:10:15 --> Input Class Initialized
INFO - 2021-07-14 07:10:15 --> Security Class Initialized
INFO - 2021-07-14 07:10:15 --> Language Class Initialized
DEBUG - 2021-07-14 07:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:10:15 --> Input Class Initialized
INFO - 2021-07-14 07:10:15 --> Language Class Initialized
INFO - 2021-07-14 07:10:15 --> Loader Class Initialized
INFO - 2021-07-14 07:10:15 --> Helper loaded: html_helper
INFO - 2021-07-14 07:10:15 --> Loader Class Initialized
INFO - 2021-07-14 07:10:15 --> Helper loaded: url_helper
INFO - 2021-07-14 07:10:15 --> Helper loaded: html_helper
INFO - 2021-07-14 07:10:15 --> Helper loaded: url_helper
INFO - 2021-07-14 07:10:15 --> Helper loaded: form_helper
INFO - 2021-07-14 07:10:15 --> Helper loaded: form_helper
INFO - 2021-07-14 07:10:15 --> Database Driver Class Initialized
INFO - 2021-07-14 07:10:15 --> Database Driver Class Initialized
INFO - 2021-07-14 07:10:15 --> Form Validation Class Initialized
INFO - 2021-07-14 07:10:15 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-14 07:10:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:10:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:10:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:10:15 --> Encryption Class Initialized
INFO - 2021-07-14 07:10:15 --> Encryption Class Initialized
INFO - 2021-07-14 07:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:10:15 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:10:15 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:10:15 --> Model "user_model" initialized
INFO - 2021-07-14 07:10:15 --> Model "role_model" initialized
INFO - 2021-07-14 07:10:15 --> Controller Class Initialized
INFO - 2021-07-14 07:10:15 --> Helper loaded: language_helper
INFO - 2021-07-14 07:10:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:10:15 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:10:15 --> Final output sent to browser
DEBUG - 2021-07-14 07:10:15 --> Total execution time: 0.0603
INFO - 2021-07-14 07:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:10:15 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:10:15 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:10:15 --> Model "user_model" initialized
INFO - 2021-07-14 07:10:15 --> Model "role_model" initialized
INFO - 2021-07-14 07:10:15 --> Controller Class Initialized
INFO - 2021-07-14 07:10:15 --> Helper loaded: language_helper
INFO - 2021-07-14 07:10:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:10:15 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:10:15 --> Final output sent to browser
DEBUG - 2021-07-14 07:10:15 --> Total execution time: 0.0675
INFO - 2021-07-14 07:10:50 --> Config Class Initialized
INFO - 2021-07-14 07:10:50 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:10:50 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:10:50 --> Utf8 Class Initialized
INFO - 2021-07-14 07:10:50 --> URI Class Initialized
INFO - 2021-07-14 07:10:50 --> Router Class Initialized
INFO - 2021-07-14 07:10:50 --> Output Class Initialized
INFO - 2021-07-14 07:10:50 --> Security Class Initialized
DEBUG - 2021-07-14 07:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:10:50 --> Input Class Initialized
INFO - 2021-07-14 07:10:50 --> Language Class Initialized
INFO - 2021-07-14 07:10:50 --> Loader Class Initialized
INFO - 2021-07-14 07:10:50 --> Helper loaded: html_helper
INFO - 2021-07-14 07:10:50 --> Helper loaded: url_helper
INFO - 2021-07-14 07:10:50 --> Helper loaded: form_helper
INFO - 2021-07-14 07:10:50 --> Database Driver Class Initialized
INFO - 2021-07-14 07:10:50 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:10:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:10:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:10:50 --> Encryption Class Initialized
INFO - 2021-07-14 07:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:10:50 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:10:50 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:10:50 --> Model "user_model" initialized
INFO - 2021-07-14 07:10:50 --> Model "role_model" initialized
INFO - 2021-07-14 07:10:50 --> Controller Class Initialized
INFO - 2021-07-14 07:10:50 --> Helper loaded: language_helper
INFO - 2021-07-14 07:10:50 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:10:50 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:10:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:10:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:10:50 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:10:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:10:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:10:50 --> Final output sent to browser
DEBUG - 2021-07-14 07:10:50 --> Total execution time: 0.1103
INFO - 2021-07-14 07:10:53 --> Config Class Initialized
INFO - 2021-07-14 07:10:53 --> Hooks Class Initialized
INFO - 2021-07-14 07:10:53 --> Config Class Initialized
INFO - 2021-07-14 07:10:53 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:10:53 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:10:53 --> Utf8 Class Initialized
DEBUG - 2021-07-14 07:10:53 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:10:53 --> Utf8 Class Initialized
INFO - 2021-07-14 07:10:53 --> URI Class Initialized
INFO - 2021-07-14 07:10:53 --> URI Class Initialized
INFO - 2021-07-14 07:10:53 --> Router Class Initialized
INFO - 2021-07-14 07:10:53 --> Router Class Initialized
INFO - 2021-07-14 07:10:53 --> Output Class Initialized
INFO - 2021-07-14 07:10:53 --> Output Class Initialized
INFO - 2021-07-14 07:10:53 --> Security Class Initialized
INFO - 2021-07-14 07:10:53 --> Security Class Initialized
DEBUG - 2021-07-14 07:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:10:53 --> Input Class Initialized
INFO - 2021-07-14 07:10:53 --> Language Class Initialized
DEBUG - 2021-07-14 07:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:10:53 --> Input Class Initialized
INFO - 2021-07-14 07:10:53 --> Language Class Initialized
INFO - 2021-07-14 07:10:53 --> Loader Class Initialized
INFO - 2021-07-14 07:10:53 --> Helper loaded: html_helper
INFO - 2021-07-14 07:10:53 --> Loader Class Initialized
INFO - 2021-07-14 07:10:53 --> Helper loaded: url_helper
INFO - 2021-07-14 07:10:53 --> Helper loaded: html_helper
INFO - 2021-07-14 07:10:53 --> Helper loaded: form_helper
INFO - 2021-07-14 07:10:53 --> Helper loaded: url_helper
INFO - 2021-07-14 07:10:53 --> Helper loaded: form_helper
INFO - 2021-07-14 07:10:53 --> Database Driver Class Initialized
INFO - 2021-07-14 07:10:53 --> Database Driver Class Initialized
INFO - 2021-07-14 07:10:53 --> Form Validation Class Initialized
INFO - 2021-07-14 07:10:53 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:10:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:10:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:10:53 --> Encryption Class Initialized
DEBUG - 2021-07-14 07:10:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:10:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:10:53 --> Encryption Class Initialized
INFO - 2021-07-14 07:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:10:53 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:10:53 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:10:53 --> Model "user_model" initialized
INFO - 2021-07-14 07:10:53 --> Model "role_model" initialized
INFO - 2021-07-14 07:10:53 --> Controller Class Initialized
INFO - 2021-07-14 07:10:53 --> Helper loaded: language_helper
INFO - 2021-07-14 07:10:53 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:10:53 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:10:53 --> Final output sent to browser
DEBUG - 2021-07-14 07:10:53 --> Total execution time: 0.0657
INFO - 2021-07-14 07:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:10:53 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:10:53 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:10:53 --> Model "user_model" initialized
INFO - 2021-07-14 07:10:53 --> Model "role_model" initialized
INFO - 2021-07-14 07:10:53 --> Controller Class Initialized
INFO - 2021-07-14 07:10:53 --> Helper loaded: language_helper
INFO - 2021-07-14 07:10:53 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:10:53 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:10:53 --> Final output sent to browser
DEBUG - 2021-07-14 07:10:53 --> Total execution time: 0.0753
INFO - 2021-07-14 07:13:15 --> Config Class Initialized
INFO - 2021-07-14 07:13:15 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:13:15 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:13:15 --> Utf8 Class Initialized
INFO - 2021-07-14 07:13:15 --> URI Class Initialized
INFO - 2021-07-14 07:13:15 --> Router Class Initialized
INFO - 2021-07-14 07:13:15 --> Output Class Initialized
INFO - 2021-07-14 07:13:15 --> Security Class Initialized
DEBUG - 2021-07-14 07:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:13:15 --> Input Class Initialized
INFO - 2021-07-14 07:13:15 --> Language Class Initialized
INFO - 2021-07-14 07:13:15 --> Loader Class Initialized
INFO - 2021-07-14 07:13:15 --> Helper loaded: html_helper
INFO - 2021-07-14 07:13:15 --> Helper loaded: url_helper
INFO - 2021-07-14 07:13:15 --> Helper loaded: form_helper
INFO - 2021-07-14 07:13:15 --> Database Driver Class Initialized
INFO - 2021-07-14 07:13:15 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:13:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:13:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:13:15 --> Encryption Class Initialized
INFO - 2021-07-14 07:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:13:15 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:13:15 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:13:15 --> Model "user_model" initialized
INFO - 2021-07-14 07:13:15 --> Model "role_model" initialized
INFO - 2021-07-14 07:13:15 --> Controller Class Initialized
INFO - 2021-07-14 07:13:15 --> Helper loaded: language_helper
INFO - 2021-07-14 07:13:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:13:15 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:13:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:13:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:13:15 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:13:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:13:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:13:15 --> Final output sent to browser
DEBUG - 2021-07-14 07:13:15 --> Total execution time: 0.1099
INFO - 2021-07-14 07:13:18 --> Config Class Initialized
INFO - 2021-07-14 07:13:18 --> Config Class Initialized
INFO - 2021-07-14 07:13:18 --> Hooks Class Initialized
INFO - 2021-07-14 07:13:18 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:13:18 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:13:18 --> Utf8 Class Initialized
DEBUG - 2021-07-14 07:13:18 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:13:18 --> Utf8 Class Initialized
INFO - 2021-07-14 07:13:18 --> URI Class Initialized
INFO - 2021-07-14 07:13:18 --> URI Class Initialized
INFO - 2021-07-14 07:13:18 --> Router Class Initialized
INFO - 2021-07-14 07:13:18 --> Router Class Initialized
INFO - 2021-07-14 07:13:18 --> Output Class Initialized
INFO - 2021-07-14 07:13:18 --> Security Class Initialized
INFO - 2021-07-14 07:13:18 --> Output Class Initialized
DEBUG - 2021-07-14 07:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:13:18 --> Input Class Initialized
INFO - 2021-07-14 07:13:18 --> Language Class Initialized
INFO - 2021-07-14 07:13:18 --> Security Class Initialized
DEBUG - 2021-07-14 07:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:13:18 --> Input Class Initialized
INFO - 2021-07-14 07:13:18 --> Language Class Initialized
INFO - 2021-07-14 07:13:18 --> Loader Class Initialized
INFO - 2021-07-14 07:13:18 --> Helper loaded: html_helper
INFO - 2021-07-14 07:13:18 --> Helper loaded: url_helper
INFO - 2021-07-14 07:13:18 --> Loader Class Initialized
INFO - 2021-07-14 07:13:18 --> Helper loaded: form_helper
INFO - 2021-07-14 07:13:18 --> Helper loaded: html_helper
INFO - 2021-07-14 07:13:18 --> Helper loaded: url_helper
INFO - 2021-07-14 07:13:18 --> Helper loaded: form_helper
INFO - 2021-07-14 07:13:18 --> Database Driver Class Initialized
INFO - 2021-07-14 07:13:18 --> Database Driver Class Initialized
INFO - 2021-07-14 07:13:18 --> Form Validation Class Initialized
INFO - 2021-07-14 07:13:18 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:13:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:13:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:13:18 --> Encryption Class Initialized
DEBUG - 2021-07-14 07:13:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:13:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:13:18 --> Encryption Class Initialized
INFO - 2021-07-14 07:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:13:18 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:13:18 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:13:18 --> Model "user_model" initialized
INFO - 2021-07-14 07:13:18 --> Model "role_model" initialized
INFO - 2021-07-14 07:13:18 --> Controller Class Initialized
INFO - 2021-07-14 07:13:18 --> Helper loaded: language_helper
INFO - 2021-07-14 07:13:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:13:18 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:13:18 --> Final output sent to browser
DEBUG - 2021-07-14 07:13:18 --> Total execution time: 0.0634
INFO - 2021-07-14 07:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:13:18 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:13:18 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:13:18 --> Model "user_model" initialized
INFO - 2021-07-14 07:13:18 --> Model "role_model" initialized
INFO - 2021-07-14 07:13:18 --> Controller Class Initialized
INFO - 2021-07-14 07:13:18 --> Helper loaded: language_helper
INFO - 2021-07-14 07:13:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:13:18 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:13:18 --> Final output sent to browser
DEBUG - 2021-07-14 07:13:18 --> Total execution time: 0.0744
INFO - 2021-07-14 07:14:29 --> Config Class Initialized
INFO - 2021-07-14 07:14:29 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:14:29 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:14:29 --> Utf8 Class Initialized
INFO - 2021-07-14 07:14:29 --> URI Class Initialized
INFO - 2021-07-14 07:14:29 --> Router Class Initialized
INFO - 2021-07-14 07:14:29 --> Output Class Initialized
INFO - 2021-07-14 07:14:29 --> Security Class Initialized
DEBUG - 2021-07-14 07:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:14:29 --> Input Class Initialized
INFO - 2021-07-14 07:14:29 --> Language Class Initialized
INFO - 2021-07-14 07:14:29 --> Loader Class Initialized
INFO - 2021-07-14 07:14:29 --> Helper loaded: html_helper
INFO - 2021-07-14 07:14:29 --> Helper loaded: url_helper
INFO - 2021-07-14 07:14:29 --> Helper loaded: form_helper
INFO - 2021-07-14 07:14:29 --> Database Driver Class Initialized
INFO - 2021-07-14 07:14:29 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:14:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:14:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:14:29 --> Encryption Class Initialized
INFO - 2021-07-14 07:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:14:29 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:14:29 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:14:29 --> Model "user_model" initialized
INFO - 2021-07-14 07:14:29 --> Model "role_model" initialized
INFO - 2021-07-14 07:14:29 --> Controller Class Initialized
INFO - 2021-07-14 07:14:29 --> Helper loaded: language_helper
INFO - 2021-07-14 07:14:29 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:14:29 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:14:29 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:14:29 --> Model "Product_model" initialized
INFO - 2021-07-14 07:14:29 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:14:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:14:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:14:29 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 07:14:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 07:14:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:14:29 --> Final output sent to browser
DEBUG - 2021-07-14 07:14:29 --> Total execution time: 0.0773
INFO - 2021-07-14 07:14:34 --> Config Class Initialized
INFO - 2021-07-14 07:14:34 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:14:34 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:14:34 --> Utf8 Class Initialized
INFO - 2021-07-14 07:14:34 --> URI Class Initialized
INFO - 2021-07-14 07:14:34 --> Router Class Initialized
INFO - 2021-07-14 07:14:34 --> Output Class Initialized
INFO - 2021-07-14 07:14:34 --> Security Class Initialized
DEBUG - 2021-07-14 07:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:14:34 --> Input Class Initialized
INFO - 2021-07-14 07:14:34 --> Language Class Initialized
INFO - 2021-07-14 07:14:34 --> Loader Class Initialized
INFO - 2021-07-14 07:14:34 --> Helper loaded: html_helper
INFO - 2021-07-14 07:14:34 --> Helper loaded: url_helper
INFO - 2021-07-14 07:14:34 --> Helper loaded: form_helper
INFO - 2021-07-14 07:14:34 --> Database Driver Class Initialized
INFO - 2021-07-14 07:14:34 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:14:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:14:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:14:34 --> Encryption Class Initialized
INFO - 2021-07-14 07:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:14:34 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:14:34 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:14:34 --> Model "user_model" initialized
INFO - 2021-07-14 07:14:34 --> Model "role_model" initialized
INFO - 2021-07-14 07:14:34 --> Controller Class Initialized
INFO - 2021-07-14 07:14:34 --> Helper loaded: language_helper
INFO - 2021-07-14 07:14:34 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:14:34 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:14:34 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:14:34 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:14:34 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:14:34 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:14:34 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:14:34 --> Final output sent to browser
DEBUG - 2021-07-14 07:14:34 --> Total execution time: 0.1226
INFO - 2021-07-14 07:14:41 --> Config Class Initialized
INFO - 2021-07-14 07:14:41 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:14:41 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:14:41 --> Utf8 Class Initialized
INFO - 2021-07-14 07:14:41 --> URI Class Initialized
INFO - 2021-07-14 07:14:41 --> Router Class Initialized
INFO - 2021-07-14 07:14:41 --> Output Class Initialized
INFO - 2021-07-14 07:14:41 --> Security Class Initialized
DEBUG - 2021-07-14 07:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:14:41 --> Input Class Initialized
INFO - 2021-07-14 07:14:41 --> Language Class Initialized
INFO - 2021-07-14 07:14:41 --> Loader Class Initialized
INFO - 2021-07-14 07:14:41 --> Helper loaded: html_helper
INFO - 2021-07-14 07:14:41 --> Helper loaded: url_helper
INFO - 2021-07-14 07:14:41 --> Helper loaded: form_helper
INFO - 2021-07-14 07:14:41 --> Database Driver Class Initialized
INFO - 2021-07-14 07:14:41 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:14:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:14:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:14:41 --> Encryption Class Initialized
INFO - 2021-07-14 07:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:14:41 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:14:41 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:14:41 --> Model "user_model" initialized
INFO - 2021-07-14 07:14:41 --> Model "role_model" initialized
INFO - 2021-07-14 07:14:41 --> Controller Class Initialized
INFO - 2021-07-14 07:14:41 --> Helper loaded: language_helper
INFO - 2021-07-14 07:14:41 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:14:41 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:14:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:14:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:14:41 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:14:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:14:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:14:41 --> Final output sent to browser
DEBUG - 2021-07-14 07:14:41 --> Total execution time: 0.0976
INFO - 2021-07-14 07:14:44 --> Config Class Initialized
INFO - 2021-07-14 07:14:44 --> Hooks Class Initialized
INFO - 2021-07-14 07:14:44 --> Config Class Initialized
INFO - 2021-07-14 07:14:44 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:14:44 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:14:44 --> Utf8 Class Initialized
DEBUG - 2021-07-14 07:14:44 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:14:44 --> Utf8 Class Initialized
INFO - 2021-07-14 07:14:44 --> URI Class Initialized
INFO - 2021-07-14 07:14:44 --> URI Class Initialized
INFO - 2021-07-14 07:14:44 --> Router Class Initialized
INFO - 2021-07-14 07:14:44 --> Router Class Initialized
INFO - 2021-07-14 07:14:44 --> Output Class Initialized
INFO - 2021-07-14 07:14:44 --> Output Class Initialized
INFO - 2021-07-14 07:14:44 --> Security Class Initialized
INFO - 2021-07-14 07:14:44 --> Security Class Initialized
DEBUG - 2021-07-14 07:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 07:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:14:44 --> Input Class Initialized
INFO - 2021-07-14 07:14:44 --> Input Class Initialized
INFO - 2021-07-14 07:14:44 --> Language Class Initialized
INFO - 2021-07-14 07:14:44 --> Language Class Initialized
INFO - 2021-07-14 07:14:44 --> Loader Class Initialized
INFO - 2021-07-14 07:14:44 --> Loader Class Initialized
INFO - 2021-07-14 07:14:44 --> Helper loaded: html_helper
INFO - 2021-07-14 07:14:44 --> Helper loaded: html_helper
INFO - 2021-07-14 07:14:44 --> Helper loaded: url_helper
INFO - 2021-07-14 07:14:44 --> Helper loaded: url_helper
INFO - 2021-07-14 07:14:44 --> Helper loaded: form_helper
INFO - 2021-07-14 07:14:44 --> Helper loaded: form_helper
INFO - 2021-07-14 07:14:44 --> Database Driver Class Initialized
INFO - 2021-07-14 07:14:44 --> Database Driver Class Initialized
INFO - 2021-07-14 07:14:44 --> Form Validation Class Initialized
INFO - 2021-07-14 07:14:44 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:14:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:14:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:14:44 --> Encryption Class Initialized
DEBUG - 2021-07-14 07:14:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:14:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:14:44 --> Encryption Class Initialized
INFO - 2021-07-14 07:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:14:44 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:14:44 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:14:44 --> Model "user_model" initialized
INFO - 2021-07-14 07:14:44 --> Model "role_model" initialized
INFO - 2021-07-14 07:14:44 --> Controller Class Initialized
INFO - 2021-07-14 07:14:44 --> Helper loaded: language_helper
INFO - 2021-07-14 07:14:44 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:14:44 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:14:44 --> Final output sent to browser
DEBUG - 2021-07-14 07:14:44 --> Total execution time: 0.0599
INFO - 2021-07-14 07:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:14:44 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:14:44 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:14:44 --> Model "user_model" initialized
INFO - 2021-07-14 07:14:44 --> Model "role_model" initialized
INFO - 2021-07-14 07:14:44 --> Controller Class Initialized
INFO - 2021-07-14 07:14:44 --> Helper loaded: language_helper
INFO - 2021-07-14 07:14:44 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:14:44 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:14:44 --> Final output sent to browser
DEBUG - 2021-07-14 07:14:44 --> Total execution time: 0.0704
INFO - 2021-07-14 07:15:18 --> Config Class Initialized
INFO - 2021-07-14 07:15:18 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:15:18 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:15:18 --> Utf8 Class Initialized
INFO - 2021-07-14 07:15:18 --> URI Class Initialized
INFO - 2021-07-14 07:15:18 --> Router Class Initialized
INFO - 2021-07-14 07:15:18 --> Output Class Initialized
INFO - 2021-07-14 07:15:18 --> Security Class Initialized
DEBUG - 2021-07-14 07:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:15:18 --> Input Class Initialized
INFO - 2021-07-14 07:15:18 --> Language Class Initialized
INFO - 2021-07-14 07:15:18 --> Loader Class Initialized
INFO - 2021-07-14 07:15:18 --> Helper loaded: html_helper
INFO - 2021-07-14 07:15:18 --> Helper loaded: url_helper
INFO - 2021-07-14 07:15:18 --> Helper loaded: form_helper
INFO - 2021-07-14 07:15:19 --> Database Driver Class Initialized
INFO - 2021-07-14 07:15:19 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:15:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:15:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:15:19 --> Encryption Class Initialized
INFO - 2021-07-14 07:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:15:19 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:15:19 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:15:19 --> Model "user_model" initialized
INFO - 2021-07-14 07:15:19 --> Model "role_model" initialized
INFO - 2021-07-14 07:15:19 --> Controller Class Initialized
INFO - 2021-07-14 07:15:19 --> Helper loaded: language_helper
INFO - 2021-07-14 07:15:19 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:15:19 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:15:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:15:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:15:19 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:15:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:15:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:15:19 --> Final output sent to browser
DEBUG - 2021-07-14 07:15:19 --> Total execution time: 0.1058
INFO - 2021-07-14 07:15:33 --> Config Class Initialized
INFO - 2021-07-14 07:15:33 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:15:33 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:15:33 --> Utf8 Class Initialized
INFO - 2021-07-14 07:15:33 --> URI Class Initialized
INFO - 2021-07-14 07:15:33 --> Router Class Initialized
INFO - 2021-07-14 07:15:33 --> Output Class Initialized
INFO - 2021-07-14 07:15:33 --> Security Class Initialized
DEBUG - 2021-07-14 07:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:15:33 --> Input Class Initialized
INFO - 2021-07-14 07:15:33 --> Language Class Initialized
INFO - 2021-07-14 07:15:33 --> Loader Class Initialized
INFO - 2021-07-14 07:15:33 --> Helper loaded: html_helper
INFO - 2021-07-14 07:15:33 --> Helper loaded: url_helper
INFO - 2021-07-14 07:15:33 --> Helper loaded: form_helper
INFO - 2021-07-14 07:15:33 --> Database Driver Class Initialized
INFO - 2021-07-14 07:15:33 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:15:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:15:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:15:33 --> Encryption Class Initialized
INFO - 2021-07-14 07:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:15:33 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:15:33 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:15:33 --> Model "user_model" initialized
INFO - 2021-07-14 07:15:33 --> Model "role_model" initialized
INFO - 2021-07-14 07:15:33 --> Controller Class Initialized
INFO - 2021-07-14 07:15:33 --> Helper loaded: language_helper
INFO - 2021-07-14 07:15:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:15:33 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:15:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:15:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:15:33 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:15:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:15:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:15:33 --> Final output sent to browser
DEBUG - 2021-07-14 07:15:33 --> Total execution time: 0.0983
INFO - 2021-07-14 07:15:35 --> Config Class Initialized
INFO - 2021-07-14 07:15:35 --> Config Class Initialized
INFO - 2021-07-14 07:15:35 --> Hooks Class Initialized
INFO - 2021-07-14 07:15:35 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:15:35 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 07:15:35 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:15:35 --> Utf8 Class Initialized
INFO - 2021-07-14 07:15:35 --> Utf8 Class Initialized
INFO - 2021-07-14 07:15:35 --> URI Class Initialized
INFO - 2021-07-14 07:15:35 --> URI Class Initialized
INFO - 2021-07-14 07:15:35 --> Router Class Initialized
INFO - 2021-07-14 07:15:35 --> Router Class Initialized
INFO - 2021-07-14 07:15:35 --> Output Class Initialized
INFO - 2021-07-14 07:15:35 --> Output Class Initialized
INFO - 2021-07-14 07:15:35 --> Security Class Initialized
INFO - 2021-07-14 07:15:35 --> Security Class Initialized
DEBUG - 2021-07-14 07:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:15:35 --> Input Class Initialized
DEBUG - 2021-07-14 07:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:15:35 --> Language Class Initialized
INFO - 2021-07-14 07:15:35 --> Input Class Initialized
INFO - 2021-07-14 07:15:35 --> Language Class Initialized
INFO - 2021-07-14 07:15:35 --> Loader Class Initialized
INFO - 2021-07-14 07:15:35 --> Helper loaded: html_helper
INFO - 2021-07-14 07:15:35 --> Loader Class Initialized
INFO - 2021-07-14 07:15:35 --> Helper loaded: url_helper
INFO - 2021-07-14 07:15:35 --> Helper loaded: html_helper
INFO - 2021-07-14 07:15:35 --> Helper loaded: form_helper
INFO - 2021-07-14 07:15:35 --> Helper loaded: url_helper
INFO - 2021-07-14 07:15:35 --> Helper loaded: form_helper
INFO - 2021-07-14 07:15:35 --> Database Driver Class Initialized
INFO - 2021-07-14 07:15:35 --> Database Driver Class Initialized
INFO - 2021-07-14 07:15:35 --> Form Validation Class Initialized
INFO - 2021-07-14 07:15:35 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:15:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:15:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2021-07-14 07:15:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:15:35 --> Encryption Class Initialized
INFO - 2021-07-14 07:15:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:15:35 --> Encryption Class Initialized
INFO - 2021-07-14 07:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:15:35 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:15:35 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:15:35 --> Model "user_model" initialized
INFO - 2021-07-14 07:15:35 --> Model "role_model" initialized
INFO - 2021-07-14 07:15:35 --> Controller Class Initialized
INFO - 2021-07-14 07:15:35 --> Helper loaded: language_helper
INFO - 2021-07-14 07:15:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:15:35 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:15:35 --> Final output sent to browser
DEBUG - 2021-07-14 07:15:35 --> Total execution time: 0.0933
INFO - 2021-07-14 07:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:15:35 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:15:35 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:15:35 --> Model "user_model" initialized
INFO - 2021-07-14 07:15:35 --> Model "role_model" initialized
INFO - 2021-07-14 07:15:35 --> Controller Class Initialized
INFO - 2021-07-14 07:15:35 --> Helper loaded: language_helper
INFO - 2021-07-14 07:15:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:15:35 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:15:35 --> Final output sent to browser
DEBUG - 2021-07-14 07:15:35 --> Total execution time: 0.1052
INFO - 2021-07-14 07:15:46 --> Config Class Initialized
INFO - 2021-07-14 07:15:46 --> Config Class Initialized
INFO - 2021-07-14 07:15:46 --> Hooks Class Initialized
INFO - 2021-07-14 07:15:46 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:15:46 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 07:15:46 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:15:46 --> Utf8 Class Initialized
INFO - 2021-07-14 07:15:46 --> Utf8 Class Initialized
INFO - 2021-07-14 07:15:46 --> URI Class Initialized
INFO - 2021-07-14 07:15:46 --> URI Class Initialized
INFO - 2021-07-14 07:15:46 --> Router Class Initialized
INFO - 2021-07-14 07:15:46 --> Router Class Initialized
INFO - 2021-07-14 07:15:46 --> Output Class Initialized
INFO - 2021-07-14 07:15:46 --> Output Class Initialized
INFO - 2021-07-14 07:15:46 --> Security Class Initialized
INFO - 2021-07-14 07:15:46 --> Security Class Initialized
DEBUG - 2021-07-14 07:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 07:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:15:46 --> Input Class Initialized
INFO - 2021-07-14 07:15:46 --> Input Class Initialized
INFO - 2021-07-14 07:15:46 --> Language Class Initialized
INFO - 2021-07-14 07:15:46 --> Language Class Initialized
INFO - 2021-07-14 07:15:46 --> Loader Class Initialized
INFO - 2021-07-14 07:15:46 --> Loader Class Initialized
INFO - 2021-07-14 07:15:46 --> Helper loaded: html_helper
INFO - 2021-07-14 07:15:46 --> Helper loaded: html_helper
INFO - 2021-07-14 07:15:46 --> Helper loaded: url_helper
INFO - 2021-07-14 07:15:46 --> Helper loaded: url_helper
INFO - 2021-07-14 07:15:46 --> Helper loaded: form_helper
INFO - 2021-07-14 07:15:46 --> Helper loaded: form_helper
INFO - 2021-07-14 07:15:46 --> Database Driver Class Initialized
INFO - 2021-07-14 07:15:46 --> Database Driver Class Initialized
INFO - 2021-07-14 07:15:46 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:15:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:15:46 --> Form Validation Class Initialized
INFO - 2021-07-14 07:15:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:15:46 --> Encryption Class Initialized
DEBUG - 2021-07-14 07:15:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:15:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:15:46 --> Encryption Class Initialized
INFO - 2021-07-14 07:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:15:46 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:15:46 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:15:46 --> Model "user_model" initialized
INFO - 2021-07-14 07:15:46 --> Model "role_model" initialized
INFO - 2021-07-14 07:15:46 --> Controller Class Initialized
INFO - 2021-07-14 07:15:46 --> Helper loaded: language_helper
INFO - 2021-07-14 07:15:46 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:15:46 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:15:46 --> Final output sent to browser
DEBUG - 2021-07-14 07:15:46 --> Total execution time: 0.0641
INFO - 2021-07-14 07:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:15:46 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:15:46 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:15:46 --> Model "user_model" initialized
INFO - 2021-07-14 07:15:46 --> Model "role_model" initialized
INFO - 2021-07-14 07:15:46 --> Controller Class Initialized
INFO - 2021-07-14 07:15:46 --> Helper loaded: language_helper
INFO - 2021-07-14 07:15:46 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:15:46 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:15:46 --> Final output sent to browser
DEBUG - 2021-07-14 07:15:46 --> Total execution time: 0.0750
INFO - 2021-07-14 07:16:06 --> Config Class Initialized
INFO - 2021-07-14 07:16:06 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:16:06 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:16:06 --> Utf8 Class Initialized
INFO - 2021-07-14 07:16:06 --> URI Class Initialized
INFO - 2021-07-14 07:16:06 --> Router Class Initialized
INFO - 2021-07-14 07:16:06 --> Output Class Initialized
INFO - 2021-07-14 07:16:06 --> Security Class Initialized
DEBUG - 2021-07-14 07:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:16:06 --> Input Class Initialized
INFO - 2021-07-14 07:16:06 --> Language Class Initialized
INFO - 2021-07-14 07:16:06 --> Loader Class Initialized
INFO - 2021-07-14 07:16:06 --> Helper loaded: html_helper
INFO - 2021-07-14 07:16:06 --> Helper loaded: url_helper
INFO - 2021-07-14 07:16:06 --> Helper loaded: form_helper
INFO - 2021-07-14 07:16:06 --> Database Driver Class Initialized
INFO - 2021-07-14 07:16:06 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:16:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:16:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:16:06 --> Encryption Class Initialized
INFO - 2021-07-14 07:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:16:06 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:16:06 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:16:06 --> Model "user_model" initialized
INFO - 2021-07-14 07:16:06 --> Model "role_model" initialized
INFO - 2021-07-14 07:16:06 --> Controller Class Initialized
INFO - 2021-07-14 07:16:06 --> Helper loaded: language_helper
INFO - 2021-07-14 07:16:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:16:06 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:16:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:16:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:16:06 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:16:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:16:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:16:06 --> Final output sent to browser
DEBUG - 2021-07-14 07:16:06 --> Total execution time: 0.1116
INFO - 2021-07-14 07:16:07 --> Config Class Initialized
INFO - 2021-07-14 07:16:07 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:16:07 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:16:07 --> Utf8 Class Initialized
INFO - 2021-07-14 07:16:07 --> URI Class Initialized
INFO - 2021-07-14 07:16:07 --> Router Class Initialized
INFO - 2021-07-14 07:16:07 --> Output Class Initialized
INFO - 2021-07-14 07:16:07 --> Security Class Initialized
DEBUG - 2021-07-14 07:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:16:07 --> Input Class Initialized
INFO - 2021-07-14 07:16:07 --> Language Class Initialized
INFO - 2021-07-14 07:16:07 --> Loader Class Initialized
INFO - 2021-07-14 07:16:07 --> Helper loaded: html_helper
INFO - 2021-07-14 07:16:07 --> Helper loaded: url_helper
INFO - 2021-07-14 07:16:07 --> Helper loaded: form_helper
INFO - 2021-07-14 07:16:07 --> Database Driver Class Initialized
INFO - 2021-07-14 07:16:07 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:16:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:16:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:16:07 --> Encryption Class Initialized
INFO - 2021-07-14 07:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:16:07 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:16:07 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:16:07 --> Model "user_model" initialized
INFO - 2021-07-14 07:16:07 --> Model "role_model" initialized
INFO - 2021-07-14 07:16:07 --> Controller Class Initialized
INFO - 2021-07-14 07:16:07 --> Helper loaded: language_helper
INFO - 2021-07-14 07:16:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:16:07 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:16:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:16:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:16:07 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:16:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:16:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:16:07 --> Final output sent to browser
DEBUG - 2021-07-14 07:16:07 --> Total execution time: 0.0707
INFO - 2021-07-14 07:16:09 --> Config Class Initialized
INFO - 2021-07-14 07:16:09 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:16:09 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:16:09 --> Utf8 Class Initialized
INFO - 2021-07-14 07:16:09 --> URI Class Initialized
INFO - 2021-07-14 07:16:09 --> Router Class Initialized
INFO - 2021-07-14 07:16:09 --> Output Class Initialized
INFO - 2021-07-14 07:16:09 --> Security Class Initialized
DEBUG - 2021-07-14 07:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:16:09 --> Input Class Initialized
INFO - 2021-07-14 07:16:09 --> Language Class Initialized
INFO - 2021-07-14 07:16:09 --> Loader Class Initialized
INFO - 2021-07-14 07:16:09 --> Helper loaded: html_helper
INFO - 2021-07-14 07:16:09 --> Helper loaded: url_helper
INFO - 2021-07-14 07:16:09 --> Helper loaded: form_helper
INFO - 2021-07-14 07:16:09 --> Database Driver Class Initialized
INFO - 2021-07-14 07:16:09 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:16:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:16:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:16:09 --> Encryption Class Initialized
INFO - 2021-07-14 07:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:16:09 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:16:09 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:16:09 --> Model "user_model" initialized
INFO - 2021-07-14 07:16:09 --> Model "role_model" initialized
INFO - 2021-07-14 07:16:09 --> Controller Class Initialized
INFO - 2021-07-14 07:16:09 --> Helper loaded: language_helper
INFO - 2021-07-14 07:16:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:16:09 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:16:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:16:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:16:09 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:16:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:16:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:16:09 --> Final output sent to browser
DEBUG - 2021-07-14 07:16:09 --> Total execution time: 0.0692
INFO - 2021-07-14 07:16:10 --> Config Class Initialized
INFO - 2021-07-14 07:16:10 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:16:10 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:16:10 --> Utf8 Class Initialized
INFO - 2021-07-14 07:16:10 --> URI Class Initialized
INFO - 2021-07-14 07:16:10 --> Router Class Initialized
INFO - 2021-07-14 07:16:10 --> Output Class Initialized
INFO - 2021-07-14 07:16:10 --> Security Class Initialized
DEBUG - 2021-07-14 07:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:16:10 --> Input Class Initialized
INFO - 2021-07-14 07:16:10 --> Language Class Initialized
INFO - 2021-07-14 07:16:10 --> Loader Class Initialized
INFO - 2021-07-14 07:16:10 --> Helper loaded: html_helper
INFO - 2021-07-14 07:16:10 --> Helper loaded: url_helper
INFO - 2021-07-14 07:16:10 --> Helper loaded: form_helper
INFO - 2021-07-14 07:16:10 --> Database Driver Class Initialized
INFO - 2021-07-14 07:16:10 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:16:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:16:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:16:10 --> Encryption Class Initialized
INFO - 2021-07-14 07:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:16:10 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:16:10 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:16:10 --> Model "user_model" initialized
INFO - 2021-07-14 07:16:10 --> Model "role_model" initialized
INFO - 2021-07-14 07:16:10 --> Controller Class Initialized
INFO - 2021-07-14 07:16:10 --> Helper loaded: language_helper
INFO - 2021-07-14 07:16:10 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:16:10 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:16:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:16:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:16:10 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:16:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:16:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:16:10 --> Final output sent to browser
DEBUG - 2021-07-14 07:16:10 --> Total execution time: 0.0741
INFO - 2021-07-14 07:16:11 --> Config Class Initialized
INFO - 2021-07-14 07:16:11 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:16:11 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:16:11 --> Utf8 Class Initialized
INFO - 2021-07-14 07:16:11 --> URI Class Initialized
INFO - 2021-07-14 07:16:11 --> Router Class Initialized
INFO - 2021-07-14 07:16:11 --> Output Class Initialized
INFO - 2021-07-14 07:16:11 --> Security Class Initialized
DEBUG - 2021-07-14 07:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:16:11 --> Input Class Initialized
INFO - 2021-07-14 07:16:11 --> Language Class Initialized
INFO - 2021-07-14 07:16:11 --> Loader Class Initialized
INFO - 2021-07-14 07:16:11 --> Helper loaded: html_helper
INFO - 2021-07-14 07:16:11 --> Helper loaded: url_helper
INFO - 2021-07-14 07:16:11 --> Helper loaded: form_helper
INFO - 2021-07-14 07:16:11 --> Database Driver Class Initialized
INFO - 2021-07-14 07:16:11 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:16:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:16:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:16:11 --> Encryption Class Initialized
INFO - 2021-07-14 07:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:16:11 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:16:11 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:16:11 --> Model "user_model" initialized
INFO - 2021-07-14 07:16:11 --> Model "role_model" initialized
INFO - 2021-07-14 07:16:11 --> Controller Class Initialized
INFO - 2021-07-14 07:16:11 --> Helper loaded: language_helper
INFO - 2021-07-14 07:16:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:16:11 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:16:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:16:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:16:11 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:16:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:16:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:16:11 --> Final output sent to browser
DEBUG - 2021-07-14 07:16:11 --> Total execution time: 0.0695
INFO - 2021-07-14 07:16:12 --> Config Class Initialized
INFO - 2021-07-14 07:16:12 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:16:12 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:16:12 --> Utf8 Class Initialized
INFO - 2021-07-14 07:16:12 --> URI Class Initialized
INFO - 2021-07-14 07:16:12 --> Router Class Initialized
INFO - 2021-07-14 07:16:12 --> Output Class Initialized
INFO - 2021-07-14 07:16:12 --> Security Class Initialized
DEBUG - 2021-07-14 07:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:16:12 --> Input Class Initialized
INFO - 2021-07-14 07:16:12 --> Language Class Initialized
INFO - 2021-07-14 07:16:12 --> Loader Class Initialized
INFO - 2021-07-14 07:16:12 --> Helper loaded: html_helper
INFO - 2021-07-14 07:16:12 --> Helper loaded: url_helper
INFO - 2021-07-14 07:16:12 --> Helper loaded: form_helper
INFO - 2021-07-14 07:16:12 --> Database Driver Class Initialized
INFO - 2021-07-14 07:16:12 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:16:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:16:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:16:12 --> Encryption Class Initialized
INFO - 2021-07-14 07:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:16:12 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:16:12 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:16:12 --> Model "user_model" initialized
INFO - 2021-07-14 07:16:12 --> Model "role_model" initialized
INFO - 2021-07-14 07:16:12 --> Controller Class Initialized
INFO - 2021-07-14 07:16:12 --> Helper loaded: language_helper
INFO - 2021-07-14 07:16:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:16:12 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:16:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:16:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:16:12 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:16:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:16:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:16:12 --> Final output sent to browser
DEBUG - 2021-07-14 07:16:12 --> Total execution time: 0.1418
INFO - 2021-07-14 07:16:18 --> Config Class Initialized
INFO - 2021-07-14 07:16:18 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:16:18 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:16:18 --> Utf8 Class Initialized
INFO - 2021-07-14 07:16:18 --> URI Class Initialized
INFO - 2021-07-14 07:16:18 --> Router Class Initialized
INFO - 2021-07-14 07:16:18 --> Output Class Initialized
INFO - 2021-07-14 07:16:18 --> Security Class Initialized
DEBUG - 2021-07-14 07:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:16:18 --> Input Class Initialized
INFO - 2021-07-14 07:16:18 --> Language Class Initialized
INFO - 2021-07-14 07:16:18 --> Loader Class Initialized
INFO - 2021-07-14 07:16:18 --> Helper loaded: html_helper
INFO - 2021-07-14 07:16:18 --> Helper loaded: url_helper
INFO - 2021-07-14 07:16:18 --> Helper loaded: form_helper
INFO - 2021-07-14 07:16:18 --> Database Driver Class Initialized
INFO - 2021-07-14 07:16:18 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:16:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:16:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:16:18 --> Encryption Class Initialized
INFO - 2021-07-14 07:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:16:18 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:16:18 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:16:18 --> Model "user_model" initialized
INFO - 2021-07-14 07:16:18 --> Model "role_model" initialized
INFO - 2021-07-14 07:16:18 --> Controller Class Initialized
INFO - 2021-07-14 07:16:18 --> Helper loaded: language_helper
INFO - 2021-07-14 07:16:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:16:18 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:16:18 --> Model "Product_model" initialized
INFO - 2021-07-14 07:16:18 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:16:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:16:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:16:18 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 07:16:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 07:16:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:16:18 --> Final output sent to browser
DEBUG - 2021-07-14 07:16:18 --> Total execution time: 0.0771
INFO - 2021-07-14 07:16:23 --> Config Class Initialized
INFO - 2021-07-14 07:16:23 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:16:23 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:16:23 --> Utf8 Class Initialized
INFO - 2021-07-14 07:16:23 --> URI Class Initialized
INFO - 2021-07-14 07:16:23 --> Router Class Initialized
INFO - 2021-07-14 07:16:23 --> Output Class Initialized
INFO - 2021-07-14 07:16:23 --> Security Class Initialized
DEBUG - 2021-07-14 07:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:16:23 --> Input Class Initialized
INFO - 2021-07-14 07:16:23 --> Language Class Initialized
INFO - 2021-07-14 07:16:23 --> Loader Class Initialized
INFO - 2021-07-14 07:16:23 --> Helper loaded: html_helper
INFO - 2021-07-14 07:16:23 --> Helper loaded: url_helper
INFO - 2021-07-14 07:16:23 --> Helper loaded: form_helper
INFO - 2021-07-14 07:16:23 --> Database Driver Class Initialized
INFO - 2021-07-14 07:16:23 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:16:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:16:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:16:23 --> Encryption Class Initialized
INFO - 2021-07-14 07:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:16:23 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:16:23 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:16:23 --> Model "user_model" initialized
INFO - 2021-07-14 07:16:23 --> Model "role_model" initialized
INFO - 2021-07-14 07:16:23 --> Controller Class Initialized
INFO - 2021-07-14 07:16:23 --> Helper loaded: language_helper
INFO - 2021-07-14 07:16:23 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:16:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:16:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-14 07:16:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\payment_custom.php
INFO - 2021-07-14 07:16:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:16:24 --> Final output sent to browser
DEBUG - 2021-07-14 07:16:24 --> Total execution time: 0.2401
INFO - 2021-07-14 07:16:28 --> Config Class Initialized
INFO - 2021-07-14 07:16:28 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:16:28 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:16:28 --> Utf8 Class Initialized
INFO - 2021-07-14 07:16:28 --> URI Class Initialized
INFO - 2021-07-14 07:16:28 --> Router Class Initialized
INFO - 2021-07-14 07:16:28 --> Output Class Initialized
INFO - 2021-07-14 07:16:28 --> Security Class Initialized
DEBUG - 2021-07-14 07:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:16:28 --> Input Class Initialized
INFO - 2021-07-14 07:16:28 --> Language Class Initialized
INFO - 2021-07-14 07:16:28 --> Loader Class Initialized
INFO - 2021-07-14 07:16:28 --> Helper loaded: html_helper
INFO - 2021-07-14 07:16:28 --> Helper loaded: url_helper
INFO - 2021-07-14 07:16:28 --> Helper loaded: form_helper
INFO - 2021-07-14 07:16:28 --> Database Driver Class Initialized
INFO - 2021-07-14 07:16:28 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:16:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:16:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:16:28 --> Encryption Class Initialized
INFO - 2021-07-14 07:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:16:28 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:16:28 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:16:28 --> Model "user_model" initialized
INFO - 2021-07-14 07:16:28 --> Model "role_model" initialized
INFO - 2021-07-14 07:16:28 --> Controller Class Initialized
INFO - 2021-07-14 07:16:28 --> Helper loaded: language_helper
INFO - 2021-07-14 07:16:28 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:16:28 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:16:28 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:16:28 --> Model "Product_model" initialized
INFO - 2021-07-14 07:16:28 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:16:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:16:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:16:28 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 07:16:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 07:16:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:16:28 --> Final output sent to browser
DEBUG - 2021-07-14 07:16:28 --> Total execution time: 0.0764
INFO - 2021-07-14 07:16:32 --> Config Class Initialized
INFO - 2021-07-14 07:16:32 --> Config Class Initialized
INFO - 2021-07-14 07:16:32 --> Hooks Class Initialized
INFO - 2021-07-14 07:16:32 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:16:32 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 07:16:32 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:16:32 --> Utf8 Class Initialized
INFO - 2021-07-14 07:16:32 --> Utf8 Class Initialized
INFO - 2021-07-14 07:16:32 --> URI Class Initialized
INFO - 2021-07-14 07:16:32 --> URI Class Initialized
INFO - 2021-07-14 07:16:32 --> Router Class Initialized
INFO - 2021-07-14 07:16:32 --> Router Class Initialized
INFO - 2021-07-14 07:16:32 --> Output Class Initialized
INFO - 2021-07-14 07:16:32 --> Output Class Initialized
INFO - 2021-07-14 07:16:32 --> Security Class Initialized
INFO - 2021-07-14 07:16:32 --> Security Class Initialized
DEBUG - 2021-07-14 07:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 07:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:16:32 --> Input Class Initialized
INFO - 2021-07-14 07:16:32 --> Input Class Initialized
INFO - 2021-07-14 07:16:32 --> Language Class Initialized
INFO - 2021-07-14 07:16:32 --> Language Class Initialized
INFO - 2021-07-14 07:16:32 --> Loader Class Initialized
INFO - 2021-07-14 07:16:32 --> Loader Class Initialized
INFO - 2021-07-14 07:16:32 --> Helper loaded: html_helper
INFO - 2021-07-14 07:16:32 --> Helper loaded: html_helper
INFO - 2021-07-14 07:16:32 --> Helper loaded: url_helper
INFO - 2021-07-14 07:16:32 --> Helper loaded: url_helper
INFO - 2021-07-14 07:16:32 --> Helper loaded: form_helper
INFO - 2021-07-14 07:16:32 --> Helper loaded: form_helper
INFO - 2021-07-14 07:16:32 --> Database Driver Class Initialized
INFO - 2021-07-14 07:16:32 --> Database Driver Class Initialized
INFO - 2021-07-14 07:16:32 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:16:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:16:32 --> Form Validation Class Initialized
INFO - 2021-07-14 07:16:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:16:32 --> Encryption Class Initialized
DEBUG - 2021-07-14 07:16:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:16:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:16:32 --> Encryption Class Initialized
INFO - 2021-07-14 07:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:16:32 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:16:32 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:16:32 --> Model "user_model" initialized
INFO - 2021-07-14 07:16:32 --> Model "role_model" initialized
INFO - 2021-07-14 07:16:32 --> Controller Class Initialized
INFO - 2021-07-14 07:16:32 --> Helper loaded: language_helper
INFO - 2021-07-14 07:16:32 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:16:32 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:16:32 --> Final output sent to browser
DEBUG - 2021-07-14 07:16:32 --> Total execution time: 0.0622
INFO - 2021-07-14 07:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:16:32 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:16:32 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:16:32 --> Model "user_model" initialized
INFO - 2021-07-14 07:16:32 --> Model "role_model" initialized
INFO - 2021-07-14 07:16:32 --> Controller Class Initialized
INFO - 2021-07-14 07:16:32 --> Helper loaded: language_helper
INFO - 2021-07-14 07:16:32 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:16:32 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:16:32 --> Final output sent to browser
DEBUG - 2021-07-14 07:16:32 --> Total execution time: 0.0727
INFO - 2021-07-14 07:16:35 --> Config Class Initialized
INFO - 2021-07-14 07:16:35 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:16:35 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:16:35 --> Utf8 Class Initialized
INFO - 2021-07-14 07:16:35 --> URI Class Initialized
INFO - 2021-07-14 07:16:35 --> Router Class Initialized
INFO - 2021-07-14 07:16:35 --> Output Class Initialized
INFO - 2021-07-14 07:16:35 --> Security Class Initialized
DEBUG - 2021-07-14 07:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:16:35 --> Input Class Initialized
INFO - 2021-07-14 07:16:35 --> Language Class Initialized
INFO - 2021-07-14 07:16:35 --> Loader Class Initialized
INFO - 2021-07-14 07:16:35 --> Helper loaded: html_helper
INFO - 2021-07-14 07:16:35 --> Helper loaded: url_helper
INFO - 2021-07-14 07:16:35 --> Helper loaded: form_helper
INFO - 2021-07-14 07:16:35 --> Database Driver Class Initialized
INFO - 2021-07-14 07:16:35 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:16:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:16:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:16:35 --> Encryption Class Initialized
INFO - 2021-07-14 07:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:16:35 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:16:35 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:16:35 --> Model "user_model" initialized
INFO - 2021-07-14 07:16:35 --> Model "role_model" initialized
INFO - 2021-07-14 07:16:35 --> Controller Class Initialized
INFO - 2021-07-14 07:16:35 --> Helper loaded: language_helper
INFO - 2021-07-14 07:16:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:16:35 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:16:35 --> Final output sent to browser
DEBUG - 2021-07-14 07:16:35 --> Total execution time: 0.0726
INFO - 2021-07-14 07:16:44 --> Config Class Initialized
INFO - 2021-07-14 07:16:44 --> Hooks Class Initialized
INFO - 2021-07-14 07:16:44 --> Config Class Initialized
INFO - 2021-07-14 07:16:44 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:16:44 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:16:44 --> Utf8 Class Initialized
DEBUG - 2021-07-14 07:16:44 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:16:44 --> Utf8 Class Initialized
INFO - 2021-07-14 07:16:44 --> URI Class Initialized
INFO - 2021-07-14 07:16:44 --> URI Class Initialized
INFO - 2021-07-14 07:16:44 --> Router Class Initialized
INFO - 2021-07-14 07:16:44 --> Router Class Initialized
INFO - 2021-07-14 07:16:44 --> Output Class Initialized
INFO - 2021-07-14 07:16:44 --> Security Class Initialized
INFO - 2021-07-14 07:16:44 --> Output Class Initialized
DEBUG - 2021-07-14 07:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:16:44 --> Input Class Initialized
INFO - 2021-07-14 07:16:44 --> Security Class Initialized
INFO - 2021-07-14 07:16:44 --> Language Class Initialized
DEBUG - 2021-07-14 07:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:16:44 --> Input Class Initialized
INFO - 2021-07-14 07:16:44 --> Language Class Initialized
INFO - 2021-07-14 07:16:44 --> Loader Class Initialized
INFO - 2021-07-14 07:16:44 --> Loader Class Initialized
INFO - 2021-07-14 07:16:44 --> Helper loaded: html_helper
INFO - 2021-07-14 07:16:44 --> Helper loaded: html_helper
INFO - 2021-07-14 07:16:44 --> Helper loaded: url_helper
INFO - 2021-07-14 07:16:44 --> Helper loaded: url_helper
INFO - 2021-07-14 07:16:44 --> Helper loaded: form_helper
INFO - 2021-07-14 07:16:44 --> Helper loaded: form_helper
INFO - 2021-07-14 07:16:44 --> Database Driver Class Initialized
INFO - 2021-07-14 07:16:44 --> Database Driver Class Initialized
INFO - 2021-07-14 07:16:44 --> Form Validation Class Initialized
INFO - 2021-07-14 07:16:44 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:16:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:16:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:16:44 --> Encryption Class Initialized
DEBUG - 2021-07-14 07:16:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:16:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:16:44 --> Encryption Class Initialized
INFO - 2021-07-14 07:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:16:44 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:16:44 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:16:44 --> Model "user_model" initialized
INFO - 2021-07-14 07:16:44 --> Model "role_model" initialized
INFO - 2021-07-14 07:16:44 --> Controller Class Initialized
INFO - 2021-07-14 07:16:44 --> Helper loaded: language_helper
INFO - 2021-07-14 07:16:44 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:16:44 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:16:44 --> Final output sent to browser
DEBUG - 2021-07-14 07:16:44 --> Total execution time: 0.0568
INFO - 2021-07-14 07:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:16:44 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:16:44 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:16:44 --> Model "user_model" initialized
INFO - 2021-07-14 07:16:44 --> Model "role_model" initialized
INFO - 2021-07-14 07:16:44 --> Controller Class Initialized
INFO - 2021-07-14 07:16:44 --> Helper loaded: language_helper
INFO - 2021-07-14 07:16:44 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:16:44 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:16:44 --> Final output sent to browser
DEBUG - 2021-07-14 07:16:44 --> Total execution time: 0.0638
INFO - 2021-07-14 07:16:49 --> Config Class Initialized
INFO - 2021-07-14 07:16:49 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:16:49 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:16:49 --> Utf8 Class Initialized
INFO - 2021-07-14 07:16:49 --> URI Class Initialized
INFO - 2021-07-14 07:16:49 --> Router Class Initialized
INFO - 2021-07-14 07:16:49 --> Output Class Initialized
INFO - 2021-07-14 07:16:49 --> Security Class Initialized
DEBUG - 2021-07-14 07:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:16:49 --> Input Class Initialized
INFO - 2021-07-14 07:16:49 --> Language Class Initialized
INFO - 2021-07-14 07:16:49 --> Loader Class Initialized
INFO - 2021-07-14 07:16:49 --> Helper loaded: html_helper
INFO - 2021-07-14 07:16:49 --> Helper loaded: url_helper
INFO - 2021-07-14 07:16:49 --> Helper loaded: form_helper
INFO - 2021-07-14 07:16:49 --> Database Driver Class Initialized
INFO - 2021-07-14 07:16:49 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:16:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:16:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:16:49 --> Encryption Class Initialized
INFO - 2021-07-14 07:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:16:49 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:16:49 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:16:49 --> Model "user_model" initialized
INFO - 2021-07-14 07:16:49 --> Model "role_model" initialized
INFO - 2021-07-14 07:16:49 --> Controller Class Initialized
INFO - 2021-07-14 07:16:49 --> Helper loaded: language_helper
INFO - 2021-07-14 07:16:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:16:49 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:16:49 --> Final output sent to browser
DEBUG - 2021-07-14 07:16:49 --> Total execution time: 0.0667
INFO - 2021-07-14 07:16:54 --> Config Class Initialized
INFO - 2021-07-14 07:16:54 --> Config Class Initialized
INFO - 2021-07-14 07:16:54 --> Hooks Class Initialized
INFO - 2021-07-14 07:16:54 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:16:54 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 07:16:54 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:16:54 --> Utf8 Class Initialized
INFO - 2021-07-14 07:16:54 --> Utf8 Class Initialized
INFO - 2021-07-14 07:16:54 --> URI Class Initialized
INFO - 2021-07-14 07:16:54 --> URI Class Initialized
INFO - 2021-07-14 07:16:54 --> Router Class Initialized
INFO - 2021-07-14 07:16:54 --> Router Class Initialized
INFO - 2021-07-14 07:16:54 --> Output Class Initialized
INFO - 2021-07-14 07:16:54 --> Output Class Initialized
INFO - 2021-07-14 07:16:54 --> Security Class Initialized
INFO - 2021-07-14 07:16:54 --> Security Class Initialized
DEBUG - 2021-07-14 07:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:16:54 --> Input Class Initialized
INFO - 2021-07-14 07:16:54 --> Language Class Initialized
DEBUG - 2021-07-14 07:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:16:54 --> Input Class Initialized
INFO - 2021-07-14 07:16:54 --> Language Class Initialized
INFO - 2021-07-14 07:16:54 --> Loader Class Initialized
INFO - 2021-07-14 07:16:54 --> Loader Class Initialized
INFO - 2021-07-14 07:16:54 --> Helper loaded: html_helper
INFO - 2021-07-14 07:16:54 --> Helper loaded: html_helper
INFO - 2021-07-14 07:16:54 --> Helper loaded: url_helper
INFO - 2021-07-14 07:16:54 --> Helper loaded: url_helper
INFO - 2021-07-14 07:16:54 --> Helper loaded: form_helper
INFO - 2021-07-14 07:16:54 --> Helper loaded: form_helper
INFO - 2021-07-14 07:16:54 --> Database Driver Class Initialized
INFO - 2021-07-14 07:16:54 --> Database Driver Class Initialized
INFO - 2021-07-14 07:16:54 --> Form Validation Class Initialized
INFO - 2021-07-14 07:16:54 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:16:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:16:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:16:54 --> Encryption Class Initialized
DEBUG - 2021-07-14 07:16:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:16:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:16:54 --> Encryption Class Initialized
INFO - 2021-07-14 07:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:16:54 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:16:54 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:16:54 --> Model "user_model" initialized
INFO - 2021-07-14 07:16:54 --> Model "role_model" initialized
INFO - 2021-07-14 07:16:54 --> Controller Class Initialized
INFO - 2021-07-14 07:16:54 --> Helper loaded: language_helper
INFO - 2021-07-14 07:16:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:16:54 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:16:54 --> Final output sent to browser
DEBUG - 2021-07-14 07:16:54 --> Total execution time: 0.0633
INFO - 2021-07-14 07:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:16:54 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:16:54 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:16:54 --> Model "user_model" initialized
INFO - 2021-07-14 07:16:54 --> Model "role_model" initialized
INFO - 2021-07-14 07:16:54 --> Controller Class Initialized
INFO - 2021-07-14 07:16:54 --> Helper loaded: language_helper
INFO - 2021-07-14 07:16:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:16:54 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:16:54 --> Final output sent to browser
DEBUG - 2021-07-14 07:16:54 --> Total execution time: 0.0727
INFO - 2021-07-14 07:16:57 --> Config Class Initialized
INFO - 2021-07-14 07:16:57 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:16:57 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:16:57 --> Utf8 Class Initialized
INFO - 2021-07-14 07:16:57 --> URI Class Initialized
INFO - 2021-07-14 07:16:57 --> Router Class Initialized
INFO - 2021-07-14 07:16:57 --> Output Class Initialized
INFO - 2021-07-14 07:16:57 --> Security Class Initialized
DEBUG - 2021-07-14 07:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:16:57 --> Input Class Initialized
INFO - 2021-07-14 07:16:57 --> Language Class Initialized
INFO - 2021-07-14 07:16:57 --> Loader Class Initialized
INFO - 2021-07-14 07:16:57 --> Helper loaded: html_helper
INFO - 2021-07-14 07:16:57 --> Helper loaded: url_helper
INFO - 2021-07-14 07:16:57 --> Helper loaded: form_helper
INFO - 2021-07-14 07:16:57 --> Database Driver Class Initialized
INFO - 2021-07-14 07:16:57 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:16:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:16:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:16:57 --> Encryption Class Initialized
INFO - 2021-07-14 07:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:16:57 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:16:57 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:16:57 --> Model "user_model" initialized
INFO - 2021-07-14 07:16:57 --> Model "role_model" initialized
INFO - 2021-07-14 07:16:57 --> Controller Class Initialized
INFO - 2021-07-14 07:16:57 --> Helper loaded: language_helper
INFO - 2021-07-14 07:16:57 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:16:57 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:16:57 --> Final output sent to browser
DEBUG - 2021-07-14 07:16:57 --> Total execution time: 0.0667
INFO - 2021-07-14 07:17:01 --> Config Class Initialized
INFO - 2021-07-14 07:17:01 --> Hooks Class Initialized
INFO - 2021-07-14 07:17:01 --> Config Class Initialized
INFO - 2021-07-14 07:17:01 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:17:01 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:17:01 --> Utf8 Class Initialized
DEBUG - 2021-07-14 07:17:01 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:17:01 --> URI Class Initialized
INFO - 2021-07-14 07:17:01 --> Utf8 Class Initialized
INFO - 2021-07-14 07:17:01 --> URI Class Initialized
INFO - 2021-07-14 07:17:01 --> Router Class Initialized
INFO - 2021-07-14 07:17:01 --> Router Class Initialized
INFO - 2021-07-14 07:17:01 --> Output Class Initialized
INFO - 2021-07-14 07:17:01 --> Output Class Initialized
INFO - 2021-07-14 07:17:01 --> Security Class Initialized
DEBUG - 2021-07-14 07:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:17:01 --> Security Class Initialized
INFO - 2021-07-14 07:17:01 --> Input Class Initialized
INFO - 2021-07-14 07:17:01 --> Language Class Initialized
DEBUG - 2021-07-14 07:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:17:01 --> Input Class Initialized
INFO - 2021-07-14 07:17:01 --> Language Class Initialized
INFO - 2021-07-14 07:17:01 --> Loader Class Initialized
INFO - 2021-07-14 07:17:01 --> Helper loaded: html_helper
INFO - 2021-07-14 07:17:01 --> Loader Class Initialized
INFO - 2021-07-14 07:17:01 --> Helper loaded: url_helper
INFO - 2021-07-14 07:17:01 --> Helper loaded: html_helper
INFO - 2021-07-14 07:17:01 --> Helper loaded: url_helper
INFO - 2021-07-14 07:17:01 --> Helper loaded: form_helper
INFO - 2021-07-14 07:17:01 --> Helper loaded: form_helper
INFO - 2021-07-14 07:17:01 --> Database Driver Class Initialized
INFO - 2021-07-14 07:17:01 --> Database Driver Class Initialized
INFO - 2021-07-14 07:17:01 --> Form Validation Class Initialized
INFO - 2021-07-14 07:17:01 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-14 07:17:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:17:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:17:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:17:01 --> Encryption Class Initialized
INFO - 2021-07-14 07:17:01 --> Encryption Class Initialized
INFO - 2021-07-14 07:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:17:01 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:17:01 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:17:01 --> Model "user_model" initialized
INFO - 2021-07-14 07:17:01 --> Model "role_model" initialized
INFO - 2021-07-14 07:17:01 --> Controller Class Initialized
INFO - 2021-07-14 07:17:01 --> Helper loaded: language_helper
INFO - 2021-07-14 07:17:01 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:17:01 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:17:01 --> Final output sent to browser
DEBUG - 2021-07-14 07:17:01 --> Total execution time: 0.0704
INFO - 2021-07-14 07:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:17:01 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:17:01 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:17:01 --> Model "user_model" initialized
INFO - 2021-07-14 07:17:01 --> Model "role_model" initialized
INFO - 2021-07-14 07:17:01 --> Controller Class Initialized
INFO - 2021-07-14 07:17:01 --> Helper loaded: language_helper
INFO - 2021-07-14 07:17:01 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:17:01 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:17:01 --> Final output sent to browser
DEBUG - 2021-07-14 07:17:01 --> Total execution time: 0.0793
INFO - 2021-07-14 07:17:03 --> Config Class Initialized
INFO - 2021-07-14 07:17:03 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:17:03 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:17:03 --> Utf8 Class Initialized
INFO - 2021-07-14 07:17:03 --> URI Class Initialized
INFO - 2021-07-14 07:17:03 --> Router Class Initialized
INFO - 2021-07-14 07:17:03 --> Output Class Initialized
INFO - 2021-07-14 07:17:03 --> Security Class Initialized
DEBUG - 2021-07-14 07:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:17:03 --> Input Class Initialized
INFO - 2021-07-14 07:17:03 --> Language Class Initialized
INFO - 2021-07-14 07:17:03 --> Loader Class Initialized
INFO - 2021-07-14 07:17:03 --> Helper loaded: html_helper
INFO - 2021-07-14 07:17:03 --> Helper loaded: url_helper
INFO - 2021-07-14 07:17:03 --> Helper loaded: form_helper
INFO - 2021-07-14 07:17:03 --> Database Driver Class Initialized
INFO - 2021-07-14 07:17:03 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:17:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:17:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:17:03 --> Encryption Class Initialized
INFO - 2021-07-14 07:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:17:03 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:17:03 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:17:03 --> Model "user_model" initialized
INFO - 2021-07-14 07:17:03 --> Model "role_model" initialized
INFO - 2021-07-14 07:17:03 --> Controller Class Initialized
INFO - 2021-07-14 07:17:03 --> Helper loaded: language_helper
INFO - 2021-07-14 07:17:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:17:03 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:17:03 --> Final output sent to browser
DEBUG - 2021-07-14 07:17:03 --> Total execution time: 0.0708
INFO - 2021-07-14 07:17:15 --> Config Class Initialized
INFO - 2021-07-14 07:17:15 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:17:15 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:17:15 --> Utf8 Class Initialized
INFO - 2021-07-14 07:17:15 --> URI Class Initialized
INFO - 2021-07-14 07:17:15 --> Router Class Initialized
INFO - 2021-07-14 07:17:15 --> Output Class Initialized
INFO - 2021-07-14 07:17:15 --> Security Class Initialized
DEBUG - 2021-07-14 07:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:17:15 --> Input Class Initialized
INFO - 2021-07-14 07:17:15 --> Language Class Initialized
INFO - 2021-07-14 07:17:15 --> Loader Class Initialized
INFO - 2021-07-14 07:17:15 --> Helper loaded: html_helper
INFO - 2021-07-14 07:17:15 --> Helper loaded: url_helper
INFO - 2021-07-14 07:17:16 --> Helper loaded: form_helper
INFO - 2021-07-14 07:17:16 --> Database Driver Class Initialized
INFO - 2021-07-14 07:17:16 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:17:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:17:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:17:16 --> Encryption Class Initialized
INFO - 2021-07-14 07:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:17:16 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:17:16 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:17:16 --> Model "user_model" initialized
INFO - 2021-07-14 07:17:16 --> Model "role_model" initialized
INFO - 2021-07-14 07:17:16 --> Controller Class Initialized
INFO - 2021-07-14 07:17:16 --> Helper loaded: language_helper
INFO - 2021-07-14 07:17:16 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:17:16 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:17:16 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:17:16 --> Model "Product_model" initialized
INFO - 2021-07-14 07:17:16 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:17:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:17:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:17:16 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 07:17:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 07:17:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:17:16 --> Final output sent to browser
DEBUG - 2021-07-14 07:17:16 --> Total execution time: 0.0839
INFO - 2021-07-14 07:17:18 --> Config Class Initialized
INFO - 2021-07-14 07:17:18 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:17:18 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:17:18 --> Utf8 Class Initialized
INFO - 2021-07-14 07:17:18 --> URI Class Initialized
INFO - 2021-07-14 07:17:18 --> Router Class Initialized
INFO - 2021-07-14 07:17:18 --> Output Class Initialized
INFO - 2021-07-14 07:17:18 --> Security Class Initialized
DEBUG - 2021-07-14 07:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:17:18 --> Input Class Initialized
INFO - 2021-07-14 07:17:18 --> Language Class Initialized
INFO - 2021-07-14 07:17:18 --> Loader Class Initialized
INFO - 2021-07-14 07:17:18 --> Helper loaded: html_helper
INFO - 2021-07-14 07:17:19 --> Helper loaded: url_helper
INFO - 2021-07-14 07:17:19 --> Helper loaded: form_helper
INFO - 2021-07-14 07:17:19 --> Database Driver Class Initialized
INFO - 2021-07-14 07:17:19 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:17:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:17:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:17:19 --> Encryption Class Initialized
INFO - 2021-07-14 07:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:17:19 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:17:19 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:17:19 --> Model "user_model" initialized
INFO - 2021-07-14 07:17:19 --> Model "role_model" initialized
INFO - 2021-07-14 07:17:19 --> Controller Class Initialized
INFO - 2021-07-14 07:17:19 --> Helper loaded: language_helper
INFO - 2021-07-14 07:17:19 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:17:19 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:17:19 --> Model "Product_model" initialized
INFO - 2021-07-14 07:17:19 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:17:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:17:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:17:19 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 07:17:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 07:17:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:17:19 --> Final output sent to browser
DEBUG - 2021-07-14 07:17:19 --> Total execution time: 0.0711
INFO - 2021-07-14 07:17:20 --> Config Class Initialized
INFO - 2021-07-14 07:17:20 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:17:20 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:17:20 --> Utf8 Class Initialized
INFO - 2021-07-14 07:17:20 --> URI Class Initialized
INFO - 2021-07-14 07:17:20 --> Router Class Initialized
INFO - 2021-07-14 07:17:20 --> Output Class Initialized
INFO - 2021-07-14 07:17:20 --> Security Class Initialized
DEBUG - 2021-07-14 07:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:17:20 --> Input Class Initialized
INFO - 2021-07-14 07:17:20 --> Language Class Initialized
INFO - 2021-07-14 07:17:20 --> Loader Class Initialized
INFO - 2021-07-14 07:17:20 --> Helper loaded: html_helper
INFO - 2021-07-14 07:17:20 --> Helper loaded: url_helper
INFO - 2021-07-14 07:17:20 --> Helper loaded: form_helper
INFO - 2021-07-14 07:17:20 --> Database Driver Class Initialized
INFO - 2021-07-14 07:17:20 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:17:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:17:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:17:20 --> Encryption Class Initialized
INFO - 2021-07-14 07:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:17:20 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:17:20 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:17:20 --> Model "user_model" initialized
INFO - 2021-07-14 07:17:20 --> Model "role_model" initialized
INFO - 2021-07-14 07:17:20 --> Controller Class Initialized
INFO - 2021-07-14 07:17:20 --> Helper loaded: language_helper
INFO - 2021-07-14 07:17:20 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:17:20 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:17:20 --> Model "Product_model" initialized
INFO - 2021-07-14 07:17:20 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:17:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:17:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:17:20 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 07:17:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 07:17:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:17:20 --> Final output sent to browser
DEBUG - 2021-07-14 07:17:20 --> Total execution time: 0.0666
INFO - 2021-07-14 07:22:29 --> Config Class Initialized
INFO - 2021-07-14 07:22:29 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:22:29 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:22:29 --> Utf8 Class Initialized
INFO - 2021-07-14 07:22:29 --> URI Class Initialized
INFO - 2021-07-14 07:22:29 --> Router Class Initialized
INFO - 2021-07-14 07:22:29 --> Output Class Initialized
INFO - 2021-07-14 07:22:29 --> Security Class Initialized
DEBUG - 2021-07-14 07:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:22:29 --> Input Class Initialized
INFO - 2021-07-14 07:22:29 --> Language Class Initialized
INFO - 2021-07-14 07:22:29 --> Loader Class Initialized
INFO - 2021-07-14 07:22:29 --> Helper loaded: html_helper
INFO - 2021-07-14 07:22:29 --> Helper loaded: url_helper
INFO - 2021-07-14 07:22:29 --> Helper loaded: form_helper
INFO - 2021-07-14 07:22:29 --> Database Driver Class Initialized
INFO - 2021-07-14 07:22:29 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:22:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:22:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:22:29 --> Encryption Class Initialized
INFO - 2021-07-14 07:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:22:29 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:22:29 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:22:29 --> Model "user_model" initialized
INFO - 2021-07-14 07:22:29 --> Model "role_model" initialized
INFO - 2021-07-14 07:22:29 --> Controller Class Initialized
INFO - 2021-07-14 07:22:29 --> Helper loaded: language_helper
INFO - 2021-07-14 07:22:29 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:22:29 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:22:29 --> Model "Product_model" initialized
INFO - 2021-07-14 07:22:29 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:22:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:22:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:22:29 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 07:22:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 07:22:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:22:29 --> Final output sent to browser
DEBUG - 2021-07-14 07:22:29 --> Total execution time: 0.0763
INFO - 2021-07-14 07:24:12 --> Config Class Initialized
INFO - 2021-07-14 07:24:12 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:24:12 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:24:12 --> Utf8 Class Initialized
INFO - 2021-07-14 07:24:12 --> URI Class Initialized
INFO - 2021-07-14 07:24:12 --> Router Class Initialized
INFO - 2021-07-14 07:24:12 --> Output Class Initialized
INFO - 2021-07-14 07:24:12 --> Security Class Initialized
DEBUG - 2021-07-14 07:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:24:12 --> Input Class Initialized
INFO - 2021-07-14 07:24:12 --> Language Class Initialized
INFO - 2021-07-14 07:24:12 --> Loader Class Initialized
INFO - 2021-07-14 07:24:12 --> Helper loaded: html_helper
INFO - 2021-07-14 07:24:12 --> Helper loaded: url_helper
INFO - 2021-07-14 07:24:12 --> Helper loaded: form_helper
INFO - 2021-07-14 07:24:12 --> Database Driver Class Initialized
INFO - 2021-07-14 07:24:12 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:24:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:24:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:24:12 --> Encryption Class Initialized
INFO - 2021-07-14 07:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:24:12 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:24:12 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:24:12 --> Model "user_model" initialized
INFO - 2021-07-14 07:24:12 --> Model "role_model" initialized
INFO - 2021-07-14 07:24:12 --> Controller Class Initialized
INFO - 2021-07-14 07:24:12 --> Helper loaded: language_helper
INFO - 2021-07-14 07:24:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:24:12 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:24:12 --> Model "Product_model" initialized
INFO - 2021-07-14 07:24:12 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:24:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:24:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:24:12 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 07:24:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 07:24:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:24:12 --> Final output sent to browser
DEBUG - 2021-07-14 07:24:12 --> Total execution time: 0.0784
INFO - 2021-07-14 07:24:25 --> Config Class Initialized
INFO - 2021-07-14 07:24:25 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:24:25 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:24:25 --> Utf8 Class Initialized
INFO - 2021-07-14 07:24:25 --> URI Class Initialized
INFO - 2021-07-14 07:24:25 --> Router Class Initialized
INFO - 2021-07-14 07:24:25 --> Output Class Initialized
INFO - 2021-07-14 07:24:25 --> Security Class Initialized
DEBUG - 2021-07-14 07:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:24:25 --> Input Class Initialized
INFO - 2021-07-14 07:24:25 --> Language Class Initialized
INFO - 2021-07-14 07:24:25 --> Loader Class Initialized
INFO - 2021-07-14 07:24:25 --> Helper loaded: html_helper
INFO - 2021-07-14 07:24:25 --> Helper loaded: url_helper
INFO - 2021-07-14 07:24:25 --> Helper loaded: form_helper
INFO - 2021-07-14 07:24:25 --> Database Driver Class Initialized
INFO - 2021-07-14 07:24:25 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:24:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:24:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:24:25 --> Encryption Class Initialized
INFO - 2021-07-14 07:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:24:25 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:24:25 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:24:25 --> Model "user_model" initialized
INFO - 2021-07-14 07:24:25 --> Model "role_model" initialized
INFO - 2021-07-14 07:24:25 --> Controller Class Initialized
INFO - 2021-07-14 07:24:25 --> Helper loaded: language_helper
INFO - 2021-07-14 07:24:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:24:25 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:24:25 --> Model "Product_model" initialized
INFO - 2021-07-14 07:24:25 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:24:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:24:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:24:25 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 07:24:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 07:24:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:24:25 --> Final output sent to browser
DEBUG - 2021-07-14 07:24:25 --> Total execution time: 0.0667
INFO - 2021-07-14 07:24:35 --> Config Class Initialized
INFO - 2021-07-14 07:24:35 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:24:35 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:24:35 --> Utf8 Class Initialized
INFO - 2021-07-14 07:24:35 --> URI Class Initialized
INFO - 2021-07-14 07:24:35 --> Router Class Initialized
INFO - 2021-07-14 07:24:35 --> Output Class Initialized
INFO - 2021-07-14 07:24:35 --> Security Class Initialized
DEBUG - 2021-07-14 07:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:24:35 --> Input Class Initialized
INFO - 2021-07-14 07:24:35 --> Language Class Initialized
INFO - 2021-07-14 07:24:35 --> Loader Class Initialized
INFO - 2021-07-14 07:24:35 --> Helper loaded: html_helper
INFO - 2021-07-14 07:24:35 --> Helper loaded: url_helper
INFO - 2021-07-14 07:24:35 --> Helper loaded: form_helper
INFO - 2021-07-14 07:24:35 --> Database Driver Class Initialized
INFO - 2021-07-14 07:24:35 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:24:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:24:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:24:35 --> Encryption Class Initialized
INFO - 2021-07-14 07:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:24:35 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:24:35 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:24:35 --> Model "user_model" initialized
INFO - 2021-07-14 07:24:35 --> Model "role_model" initialized
INFO - 2021-07-14 07:24:35 --> Controller Class Initialized
INFO - 2021-07-14 07:24:35 --> Helper loaded: language_helper
INFO - 2021-07-14 07:24:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:24:35 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:24:35 --> Model "Product_model" initialized
INFO - 2021-07-14 07:24:35 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:24:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:24:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:24:35 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 07:24:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 07:24:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:24:35 --> Final output sent to browser
DEBUG - 2021-07-14 07:24:35 --> Total execution time: 0.0717
INFO - 2021-07-14 07:24:36 --> Config Class Initialized
INFO - 2021-07-14 07:24:36 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:24:36 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:24:36 --> Utf8 Class Initialized
INFO - 2021-07-14 07:24:36 --> URI Class Initialized
INFO - 2021-07-14 07:24:36 --> Router Class Initialized
INFO - 2021-07-14 07:24:36 --> Output Class Initialized
INFO - 2021-07-14 07:24:36 --> Security Class Initialized
DEBUG - 2021-07-14 07:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:24:36 --> Input Class Initialized
INFO - 2021-07-14 07:24:36 --> Language Class Initialized
INFO - 2021-07-14 07:24:36 --> Loader Class Initialized
INFO - 2021-07-14 07:24:36 --> Helper loaded: html_helper
INFO - 2021-07-14 07:24:36 --> Helper loaded: url_helper
INFO - 2021-07-14 07:24:36 --> Helper loaded: form_helper
INFO - 2021-07-14 07:24:36 --> Database Driver Class Initialized
INFO - 2021-07-14 07:24:36 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:24:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:24:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:24:36 --> Encryption Class Initialized
INFO - 2021-07-14 07:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:24:36 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:24:36 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:24:36 --> Model "user_model" initialized
INFO - 2021-07-14 07:24:36 --> Model "role_model" initialized
INFO - 2021-07-14 07:24:36 --> Controller Class Initialized
INFO - 2021-07-14 07:24:36 --> Helper loaded: language_helper
INFO - 2021-07-14 07:24:36 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:24:36 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:24:36 --> Model "Product_model" initialized
INFO - 2021-07-14 07:24:36 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:24:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:24:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:24:36 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 07:24:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 07:24:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:24:36 --> Final output sent to browser
DEBUG - 2021-07-14 07:24:36 --> Total execution time: 0.0790
INFO - 2021-07-14 07:25:30 --> Config Class Initialized
INFO - 2021-07-14 07:25:30 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:25:30 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:25:30 --> Utf8 Class Initialized
INFO - 2021-07-14 07:25:30 --> URI Class Initialized
INFO - 2021-07-14 07:25:30 --> Router Class Initialized
INFO - 2021-07-14 07:25:30 --> Output Class Initialized
INFO - 2021-07-14 07:25:30 --> Security Class Initialized
DEBUG - 2021-07-14 07:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:25:30 --> Input Class Initialized
INFO - 2021-07-14 07:25:30 --> Language Class Initialized
INFO - 2021-07-14 07:25:30 --> Loader Class Initialized
INFO - 2021-07-14 07:25:30 --> Helper loaded: html_helper
INFO - 2021-07-14 07:25:30 --> Helper loaded: url_helper
INFO - 2021-07-14 07:25:30 --> Helper loaded: form_helper
INFO - 2021-07-14 07:25:30 --> Database Driver Class Initialized
INFO - 2021-07-14 07:25:30 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:25:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:25:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:25:30 --> Encryption Class Initialized
INFO - 2021-07-14 07:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:25:30 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:25:30 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:25:30 --> Model "user_model" initialized
INFO - 2021-07-14 07:25:30 --> Model "role_model" initialized
INFO - 2021-07-14 07:25:30 --> Controller Class Initialized
INFO - 2021-07-14 07:25:30 --> Helper loaded: language_helper
INFO - 2021-07-14 07:25:30 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:25:30 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:25:30 --> Final output sent to browser
DEBUG - 2021-07-14 07:25:30 --> Total execution time: 0.1464
INFO - 2021-07-14 07:25:42 --> Config Class Initialized
INFO - 2021-07-14 07:25:42 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:25:42 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:25:42 --> Utf8 Class Initialized
INFO - 2021-07-14 07:25:42 --> URI Class Initialized
INFO - 2021-07-14 07:25:42 --> Router Class Initialized
INFO - 2021-07-14 07:25:42 --> Output Class Initialized
INFO - 2021-07-14 07:25:42 --> Security Class Initialized
DEBUG - 2021-07-14 07:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:25:42 --> Input Class Initialized
INFO - 2021-07-14 07:25:42 --> Language Class Initialized
INFO - 2021-07-14 07:25:42 --> Loader Class Initialized
INFO - 2021-07-14 07:25:42 --> Helper loaded: html_helper
INFO - 2021-07-14 07:25:42 --> Helper loaded: url_helper
INFO - 2021-07-14 07:25:42 --> Helper loaded: form_helper
INFO - 2021-07-14 07:25:42 --> Database Driver Class Initialized
INFO - 2021-07-14 07:25:42 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:25:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:25:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:25:42 --> Encryption Class Initialized
INFO - 2021-07-14 07:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:25:42 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:25:42 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:25:42 --> Model "user_model" initialized
INFO - 2021-07-14 07:25:42 --> Model "role_model" initialized
INFO - 2021-07-14 07:25:42 --> Controller Class Initialized
INFO - 2021-07-14 07:25:42 --> Helper loaded: language_helper
INFO - 2021-07-14 07:25:42 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:25:42 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:25:42 --> Final output sent to browser
DEBUG - 2021-07-14 07:25:42 --> Total execution time: 0.0561
INFO - 2021-07-14 07:25:42 --> Config Class Initialized
INFO - 2021-07-14 07:25:42 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:25:42 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:25:42 --> Utf8 Class Initialized
INFO - 2021-07-14 07:25:42 --> URI Class Initialized
INFO - 2021-07-14 07:25:42 --> Router Class Initialized
INFO - 2021-07-14 07:25:42 --> Output Class Initialized
INFO - 2021-07-14 07:25:42 --> Security Class Initialized
DEBUG - 2021-07-14 07:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:25:42 --> Input Class Initialized
INFO - 2021-07-14 07:25:42 --> Language Class Initialized
INFO - 2021-07-14 07:25:42 --> Loader Class Initialized
INFO - 2021-07-14 07:25:42 --> Helper loaded: html_helper
INFO - 2021-07-14 07:25:42 --> Helper loaded: url_helper
INFO - 2021-07-14 07:25:42 --> Helper loaded: form_helper
INFO - 2021-07-14 07:25:42 --> Database Driver Class Initialized
INFO - 2021-07-14 07:25:42 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:25:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:25:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:25:42 --> Encryption Class Initialized
INFO - 2021-07-14 07:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:25:42 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:25:42 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:25:42 --> Model "user_model" initialized
INFO - 2021-07-14 07:25:42 --> Model "role_model" initialized
INFO - 2021-07-14 07:25:42 --> Controller Class Initialized
INFO - 2021-07-14 07:25:42 --> Helper loaded: language_helper
INFO - 2021-07-14 07:25:42 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:25:42 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:25:42 --> Final output sent to browser
DEBUG - 2021-07-14 07:25:42 --> Total execution time: 0.0527
INFO - 2021-07-14 07:26:50 --> Config Class Initialized
INFO - 2021-07-14 07:26:50 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:26:50 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:26:50 --> Utf8 Class Initialized
INFO - 2021-07-14 07:26:50 --> URI Class Initialized
INFO - 2021-07-14 07:26:50 --> Router Class Initialized
INFO - 2021-07-14 07:26:50 --> Output Class Initialized
INFO - 2021-07-14 07:26:50 --> Security Class Initialized
DEBUG - 2021-07-14 07:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:26:50 --> Input Class Initialized
INFO - 2021-07-14 07:26:50 --> Language Class Initialized
INFO - 2021-07-14 07:26:50 --> Loader Class Initialized
INFO - 2021-07-14 07:26:50 --> Helper loaded: html_helper
INFO - 2021-07-14 07:26:50 --> Helper loaded: url_helper
INFO - 2021-07-14 07:26:50 --> Helper loaded: form_helper
INFO - 2021-07-14 07:26:50 --> Database Driver Class Initialized
INFO - 2021-07-14 07:26:50 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:26:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:26:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:26:50 --> Encryption Class Initialized
INFO - 2021-07-14 07:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:26:50 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:26:50 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:26:50 --> Model "user_model" initialized
INFO - 2021-07-14 07:26:50 --> Model "role_model" initialized
INFO - 2021-07-14 07:26:50 --> Controller Class Initialized
INFO - 2021-07-14 07:26:50 --> Helper loaded: language_helper
INFO - 2021-07-14 07:26:50 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:26:50 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:26:50 --> Model "Product_model" initialized
INFO - 2021-07-14 07:26:50 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:26:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:26:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:26:50 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 07:26:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 07:26:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:26:50 --> Final output sent to browser
DEBUG - 2021-07-14 07:26:50 --> Total execution time: 0.0723
INFO - 2021-07-14 07:26:54 --> Config Class Initialized
INFO - 2021-07-14 07:26:54 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:26:54 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:26:54 --> Utf8 Class Initialized
INFO - 2021-07-14 07:26:54 --> URI Class Initialized
INFO - 2021-07-14 07:26:54 --> Router Class Initialized
INFO - 2021-07-14 07:26:54 --> Output Class Initialized
INFO - 2021-07-14 07:26:54 --> Security Class Initialized
DEBUG - 2021-07-14 07:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:26:54 --> Input Class Initialized
INFO - 2021-07-14 07:26:54 --> Language Class Initialized
INFO - 2021-07-14 07:26:54 --> Loader Class Initialized
INFO - 2021-07-14 07:26:54 --> Helper loaded: html_helper
INFO - 2021-07-14 07:26:54 --> Helper loaded: url_helper
INFO - 2021-07-14 07:26:54 --> Helper loaded: form_helper
INFO - 2021-07-14 07:26:54 --> Database Driver Class Initialized
INFO - 2021-07-14 07:26:54 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:26:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:26:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:26:54 --> Encryption Class Initialized
INFO - 2021-07-14 07:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:26:54 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:26:54 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:26:54 --> Model "user_model" initialized
INFO - 2021-07-14 07:26:54 --> Model "role_model" initialized
INFO - 2021-07-14 07:26:54 --> Controller Class Initialized
INFO - 2021-07-14 07:26:54 --> Helper loaded: language_helper
INFO - 2021-07-14 07:26:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:26:54 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:26:54 --> Final output sent to browser
DEBUG - 2021-07-14 07:26:54 --> Total execution time: 0.0552
INFO - 2021-07-14 07:26:55 --> Config Class Initialized
INFO - 2021-07-14 07:26:55 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:26:55 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:26:55 --> Utf8 Class Initialized
INFO - 2021-07-14 07:26:55 --> URI Class Initialized
INFO - 2021-07-14 07:26:55 --> Router Class Initialized
INFO - 2021-07-14 07:26:55 --> Output Class Initialized
INFO - 2021-07-14 07:26:55 --> Security Class Initialized
DEBUG - 2021-07-14 07:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:26:55 --> Input Class Initialized
INFO - 2021-07-14 07:26:55 --> Language Class Initialized
INFO - 2021-07-14 07:26:55 --> Loader Class Initialized
INFO - 2021-07-14 07:26:55 --> Helper loaded: html_helper
INFO - 2021-07-14 07:26:55 --> Helper loaded: url_helper
INFO - 2021-07-14 07:26:55 --> Helper loaded: form_helper
INFO - 2021-07-14 07:26:55 --> Database Driver Class Initialized
INFO - 2021-07-14 07:26:55 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:26:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:26:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:26:55 --> Encryption Class Initialized
INFO - 2021-07-14 07:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:26:55 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:26:55 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:26:55 --> Model "user_model" initialized
INFO - 2021-07-14 07:26:55 --> Model "role_model" initialized
INFO - 2021-07-14 07:26:55 --> Controller Class Initialized
INFO - 2021-07-14 07:26:55 --> Helper loaded: language_helper
INFO - 2021-07-14 07:26:55 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:26:55 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:26:55 --> Final output sent to browser
DEBUG - 2021-07-14 07:26:55 --> Total execution time: 0.0554
INFO - 2021-07-14 07:28:05 --> Config Class Initialized
INFO - 2021-07-14 07:28:05 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:28:05 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:28:05 --> Utf8 Class Initialized
INFO - 2021-07-14 07:28:05 --> URI Class Initialized
INFO - 2021-07-14 07:28:05 --> Router Class Initialized
INFO - 2021-07-14 07:28:05 --> Output Class Initialized
INFO - 2021-07-14 07:28:05 --> Security Class Initialized
DEBUG - 2021-07-14 07:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:28:05 --> Input Class Initialized
INFO - 2021-07-14 07:28:05 --> Language Class Initialized
INFO - 2021-07-14 07:28:05 --> Loader Class Initialized
INFO - 2021-07-14 07:28:05 --> Helper loaded: html_helper
INFO - 2021-07-14 07:28:05 --> Helper loaded: url_helper
INFO - 2021-07-14 07:28:05 --> Helper loaded: form_helper
INFO - 2021-07-14 07:28:05 --> Database Driver Class Initialized
INFO - 2021-07-14 07:28:05 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:28:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:28:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:28:05 --> Encryption Class Initialized
INFO - 2021-07-14 07:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:28:05 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:28:05 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:28:05 --> Model "user_model" initialized
INFO - 2021-07-14 07:28:05 --> Model "role_model" initialized
INFO - 2021-07-14 07:28:05 --> Controller Class Initialized
INFO - 2021-07-14 07:28:05 --> Helper loaded: language_helper
INFO - 2021-07-14 07:28:05 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:28:05 --> Model "Product_model" initialized
INFO - 2021-07-14 07:28:05 --> Final output sent to browser
DEBUG - 2021-07-14 07:28:05 --> Total execution time: 0.1597
INFO - 2021-07-14 07:28:12 --> Config Class Initialized
INFO - 2021-07-14 07:28:12 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:28:12 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:28:12 --> Utf8 Class Initialized
INFO - 2021-07-14 07:28:12 --> URI Class Initialized
INFO - 2021-07-14 07:28:12 --> Router Class Initialized
INFO - 2021-07-14 07:28:12 --> Output Class Initialized
INFO - 2021-07-14 07:28:12 --> Security Class Initialized
DEBUG - 2021-07-14 07:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:28:12 --> Input Class Initialized
INFO - 2021-07-14 07:28:12 --> Language Class Initialized
INFO - 2021-07-14 07:28:12 --> Loader Class Initialized
INFO - 2021-07-14 07:28:12 --> Helper loaded: html_helper
INFO - 2021-07-14 07:28:12 --> Helper loaded: url_helper
INFO - 2021-07-14 07:28:12 --> Helper loaded: form_helper
INFO - 2021-07-14 07:28:12 --> Database Driver Class Initialized
INFO - 2021-07-14 07:28:12 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:28:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:28:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:28:12 --> Encryption Class Initialized
INFO - 2021-07-14 07:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:28:12 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:28:12 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:28:12 --> Model "user_model" initialized
INFO - 2021-07-14 07:28:12 --> Model "role_model" initialized
INFO - 2021-07-14 07:28:12 --> Controller Class Initialized
INFO - 2021-07-14 07:28:12 --> Helper loaded: language_helper
INFO - 2021-07-14 07:28:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:28:12 --> Model "Product_model" initialized
INFO - 2021-07-14 07:28:12 --> Final output sent to browser
DEBUG - 2021-07-14 07:28:12 --> Total execution time: 0.0620
INFO - 2021-07-14 07:28:42 --> Config Class Initialized
INFO - 2021-07-14 07:28:42 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:28:42 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:28:42 --> Utf8 Class Initialized
INFO - 2021-07-14 07:28:42 --> URI Class Initialized
INFO - 2021-07-14 07:28:42 --> Router Class Initialized
INFO - 2021-07-14 07:28:42 --> Output Class Initialized
INFO - 2021-07-14 07:28:42 --> Security Class Initialized
DEBUG - 2021-07-14 07:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:28:42 --> Input Class Initialized
INFO - 2021-07-14 07:28:42 --> Language Class Initialized
INFO - 2021-07-14 07:28:42 --> Loader Class Initialized
INFO - 2021-07-14 07:28:42 --> Helper loaded: html_helper
INFO - 2021-07-14 07:28:42 --> Helper loaded: url_helper
INFO - 2021-07-14 07:28:42 --> Helper loaded: form_helper
INFO - 2021-07-14 07:28:42 --> Database Driver Class Initialized
INFO - 2021-07-14 07:28:42 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:28:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:28:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:28:42 --> Encryption Class Initialized
INFO - 2021-07-14 07:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:28:42 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:28:42 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:28:42 --> Model "user_model" initialized
INFO - 2021-07-14 07:28:42 --> Model "role_model" initialized
INFO - 2021-07-14 07:28:42 --> Controller Class Initialized
INFO - 2021-07-14 07:28:42 --> Helper loaded: language_helper
INFO - 2021-07-14 07:28:42 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:28:42 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:28:42 --> Final output sent to browser
DEBUG - 2021-07-14 07:28:42 --> Total execution time: 0.0732
INFO - 2021-07-14 07:28:43 --> Config Class Initialized
INFO - 2021-07-14 07:28:43 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:28:43 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:28:43 --> Utf8 Class Initialized
INFO - 2021-07-14 07:28:43 --> URI Class Initialized
INFO - 2021-07-14 07:28:43 --> Router Class Initialized
INFO - 2021-07-14 07:28:43 --> Output Class Initialized
INFO - 2021-07-14 07:28:43 --> Security Class Initialized
DEBUG - 2021-07-14 07:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:28:43 --> Input Class Initialized
INFO - 2021-07-14 07:28:43 --> Language Class Initialized
INFO - 2021-07-14 07:28:43 --> Loader Class Initialized
INFO - 2021-07-14 07:28:43 --> Helper loaded: html_helper
INFO - 2021-07-14 07:28:43 --> Helper loaded: url_helper
INFO - 2021-07-14 07:28:43 --> Helper loaded: form_helper
INFO - 2021-07-14 07:28:43 --> Database Driver Class Initialized
INFO - 2021-07-14 07:28:43 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:28:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:28:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:28:43 --> Encryption Class Initialized
INFO - 2021-07-14 07:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:28:43 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:28:43 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:28:43 --> Model "user_model" initialized
INFO - 2021-07-14 07:28:43 --> Model "role_model" initialized
INFO - 2021-07-14 07:28:43 --> Controller Class Initialized
INFO - 2021-07-14 07:28:43 --> Helper loaded: language_helper
INFO - 2021-07-14 07:28:43 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:28:43 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:28:43 --> Final output sent to browser
DEBUG - 2021-07-14 07:28:43 --> Total execution time: 0.0735
INFO - 2021-07-14 07:28:44 --> Config Class Initialized
INFO - 2021-07-14 07:28:44 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:28:44 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:28:44 --> Utf8 Class Initialized
INFO - 2021-07-14 07:28:44 --> URI Class Initialized
INFO - 2021-07-14 07:28:44 --> Router Class Initialized
INFO - 2021-07-14 07:28:44 --> Output Class Initialized
INFO - 2021-07-14 07:28:44 --> Security Class Initialized
DEBUG - 2021-07-14 07:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:28:44 --> Input Class Initialized
INFO - 2021-07-14 07:28:44 --> Language Class Initialized
INFO - 2021-07-14 07:28:44 --> Loader Class Initialized
INFO - 2021-07-14 07:28:44 --> Helper loaded: html_helper
INFO - 2021-07-14 07:28:44 --> Helper loaded: url_helper
INFO - 2021-07-14 07:28:44 --> Helper loaded: form_helper
INFO - 2021-07-14 07:28:44 --> Database Driver Class Initialized
INFO - 2021-07-14 07:28:44 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:28:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:28:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:28:44 --> Encryption Class Initialized
INFO - 2021-07-14 07:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:28:44 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:28:44 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:28:44 --> Model "user_model" initialized
INFO - 2021-07-14 07:28:44 --> Model "role_model" initialized
INFO - 2021-07-14 07:28:44 --> Controller Class Initialized
INFO - 2021-07-14 07:28:44 --> Helper loaded: language_helper
INFO - 2021-07-14 07:28:44 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:28:44 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:28:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:28:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:28:45 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:28:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:28:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:28:45 --> Final output sent to browser
DEBUG - 2021-07-14 07:28:45 --> Total execution time: 0.1094
INFO - 2021-07-14 07:28:45 --> Config Class Initialized
INFO - 2021-07-14 07:28:45 --> Hooks Class Initialized
INFO - 2021-07-14 07:28:45 --> Config Class Initialized
INFO - 2021-07-14 07:28:45 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:28:45 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:28:45 --> Utf8 Class Initialized
INFO - 2021-07-14 07:28:45 --> URI Class Initialized
DEBUG - 2021-07-14 07:28:45 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:28:45 --> Utf8 Class Initialized
INFO - 2021-07-14 07:28:45 --> URI Class Initialized
INFO - 2021-07-14 07:28:45 --> Router Class Initialized
INFO - 2021-07-14 07:28:45 --> Router Class Initialized
INFO - 2021-07-14 07:28:45 --> Output Class Initialized
INFO - 2021-07-14 07:28:45 --> Security Class Initialized
INFO - 2021-07-14 07:28:45 --> Output Class Initialized
DEBUG - 2021-07-14 07:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:28:45 --> Input Class Initialized
INFO - 2021-07-14 07:28:45 --> Security Class Initialized
INFO - 2021-07-14 07:28:45 --> Language Class Initialized
DEBUG - 2021-07-14 07:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:28:45 --> Input Class Initialized
INFO - 2021-07-14 07:28:45 --> Language Class Initialized
INFO - 2021-07-14 07:28:45 --> Loader Class Initialized
INFO - 2021-07-14 07:28:45 --> Helper loaded: html_helper
INFO - 2021-07-14 07:28:45 --> Loader Class Initialized
INFO - 2021-07-14 07:28:45 --> Helper loaded: url_helper
INFO - 2021-07-14 07:28:45 --> Helper loaded: html_helper
INFO - 2021-07-14 07:28:45 --> Helper loaded: url_helper
INFO - 2021-07-14 07:28:45 --> Helper loaded: form_helper
INFO - 2021-07-14 07:28:45 --> Helper loaded: form_helper
INFO - 2021-07-14 07:28:45 --> Database Driver Class Initialized
INFO - 2021-07-14 07:28:45 --> Database Driver Class Initialized
INFO - 2021-07-14 07:28:45 --> Form Validation Class Initialized
INFO - 2021-07-14 07:28:45 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:28:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:28:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:28:45 --> Encryption Class Initialized
DEBUG - 2021-07-14 07:28:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:28:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:28:45 --> Encryption Class Initialized
INFO - 2021-07-14 07:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:28:45 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:28:45 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:28:45 --> Model "user_model" initialized
INFO - 2021-07-14 07:28:45 --> Model "role_model" initialized
INFO - 2021-07-14 07:28:45 --> Controller Class Initialized
INFO - 2021-07-14 07:28:45 --> Helper loaded: language_helper
INFO - 2021-07-14 07:28:45 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:28:45 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:28:45 --> Final output sent to browser
DEBUG - 2021-07-14 07:28:45 --> Total execution time: 0.0737
INFO - 2021-07-14 07:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:28:45 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:28:45 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:28:45 --> Model "user_model" initialized
INFO - 2021-07-14 07:28:45 --> Model "role_model" initialized
INFO - 2021-07-14 07:28:45 --> Controller Class Initialized
INFO - 2021-07-14 07:28:45 --> Helper loaded: language_helper
INFO - 2021-07-14 07:28:45 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:28:45 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:28:45 --> Final output sent to browser
DEBUG - 2021-07-14 07:28:45 --> Total execution time: 0.0875
INFO - 2021-07-14 07:28:54 --> Config Class Initialized
INFO - 2021-07-14 07:28:54 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:28:54 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:28:54 --> Utf8 Class Initialized
INFO - 2021-07-14 07:28:54 --> URI Class Initialized
INFO - 2021-07-14 07:28:54 --> Router Class Initialized
INFO - 2021-07-14 07:28:54 --> Output Class Initialized
INFO - 2021-07-14 07:28:54 --> Security Class Initialized
DEBUG - 2021-07-14 07:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:28:54 --> Input Class Initialized
INFO - 2021-07-14 07:28:54 --> Language Class Initialized
INFO - 2021-07-14 07:28:54 --> Loader Class Initialized
INFO - 2021-07-14 07:28:54 --> Helper loaded: html_helper
INFO - 2021-07-14 07:28:54 --> Helper loaded: url_helper
INFO - 2021-07-14 07:28:54 --> Helper loaded: form_helper
INFO - 2021-07-14 07:28:54 --> Database Driver Class Initialized
INFO - 2021-07-14 07:28:54 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:28:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:28:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:28:54 --> Encryption Class Initialized
INFO - 2021-07-14 07:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:28:54 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:28:54 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:28:54 --> Model "user_model" initialized
INFO - 2021-07-14 07:28:54 --> Model "role_model" initialized
INFO - 2021-07-14 07:28:54 --> Controller Class Initialized
INFO - 2021-07-14 07:28:54 --> Helper loaded: language_helper
INFO - 2021-07-14 07:28:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:28:54 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:28:54 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:28:54 --> Model "Product_model" initialized
INFO - 2021-07-14 07:28:54 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:28:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:28:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:28:54 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 07:28:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 07:28:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:28:54 --> Final output sent to browser
DEBUG - 2021-07-14 07:28:54 --> Total execution time: 0.0722
INFO - 2021-07-14 07:28:57 --> Config Class Initialized
INFO - 2021-07-14 07:28:57 --> Config Class Initialized
INFO - 2021-07-14 07:28:57 --> Hooks Class Initialized
INFO - 2021-07-14 07:28:57 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:28:57 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 07:28:57 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:28:57 --> Utf8 Class Initialized
INFO - 2021-07-14 07:28:57 --> Utf8 Class Initialized
INFO - 2021-07-14 07:28:57 --> URI Class Initialized
INFO - 2021-07-14 07:28:57 --> URI Class Initialized
INFO - 2021-07-14 07:28:57 --> Router Class Initialized
INFO - 2021-07-14 07:28:57 --> Router Class Initialized
INFO - 2021-07-14 07:28:57 --> Output Class Initialized
INFO - 2021-07-14 07:28:57 --> Output Class Initialized
INFO - 2021-07-14 07:28:57 --> Security Class Initialized
INFO - 2021-07-14 07:28:57 --> Security Class Initialized
DEBUG - 2021-07-14 07:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 07:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:28:57 --> Input Class Initialized
INFO - 2021-07-14 07:28:57 --> Input Class Initialized
INFO - 2021-07-14 07:28:57 --> Language Class Initialized
INFO - 2021-07-14 07:28:57 --> Language Class Initialized
INFO - 2021-07-14 07:28:57 --> Loader Class Initialized
INFO - 2021-07-14 07:28:57 --> Loader Class Initialized
INFO - 2021-07-14 07:28:57 --> Helper loaded: html_helper
INFO - 2021-07-14 07:28:57 --> Helper loaded: url_helper
INFO - 2021-07-14 07:28:57 --> Helper loaded: html_helper
INFO - 2021-07-14 07:28:57 --> Helper loaded: form_helper
INFO - 2021-07-14 07:28:57 --> Helper loaded: url_helper
INFO - 2021-07-14 07:28:57 --> Helper loaded: form_helper
INFO - 2021-07-14 07:28:57 --> Database Driver Class Initialized
INFO - 2021-07-14 07:28:57 --> Database Driver Class Initialized
INFO - 2021-07-14 07:28:57 --> Form Validation Class Initialized
INFO - 2021-07-14 07:28:57 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-14 07:28:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:28:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:28:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:28:57 --> Encryption Class Initialized
INFO - 2021-07-14 07:28:57 --> Encryption Class Initialized
INFO - 2021-07-14 07:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:28:57 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:28:57 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:28:57 --> Model "user_model" initialized
INFO - 2021-07-14 07:28:57 --> Model "role_model" initialized
INFO - 2021-07-14 07:28:57 --> Controller Class Initialized
INFO - 2021-07-14 07:28:57 --> Helper loaded: language_helper
INFO - 2021-07-14 07:28:57 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:28:57 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:28:57 --> Final output sent to browser
DEBUG - 2021-07-14 07:28:57 --> Total execution time: 0.0699
INFO - 2021-07-14 07:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:28:57 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:28:57 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:28:57 --> Model "user_model" initialized
INFO - 2021-07-14 07:28:57 --> Model "role_model" initialized
INFO - 2021-07-14 07:28:57 --> Controller Class Initialized
INFO - 2021-07-14 07:28:57 --> Helper loaded: language_helper
INFO - 2021-07-14 07:28:57 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:28:57 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:28:57 --> Final output sent to browser
DEBUG - 2021-07-14 07:28:57 --> Total execution time: 0.0796
INFO - 2021-07-14 07:29:10 --> Config Class Initialized
INFO - 2021-07-14 07:29:10 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:29:10 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:29:10 --> Utf8 Class Initialized
INFO - 2021-07-14 07:29:10 --> URI Class Initialized
INFO - 2021-07-14 07:29:10 --> Router Class Initialized
INFO - 2021-07-14 07:29:10 --> Output Class Initialized
INFO - 2021-07-14 07:29:10 --> Security Class Initialized
DEBUG - 2021-07-14 07:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:29:10 --> Input Class Initialized
INFO - 2021-07-14 07:29:10 --> Language Class Initialized
INFO - 2021-07-14 07:29:10 --> Loader Class Initialized
INFO - 2021-07-14 07:29:10 --> Helper loaded: html_helper
INFO - 2021-07-14 07:29:10 --> Helper loaded: url_helper
INFO - 2021-07-14 07:29:10 --> Helper loaded: form_helper
INFO - 2021-07-14 07:29:10 --> Database Driver Class Initialized
INFO - 2021-07-14 07:29:10 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:29:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:29:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:29:10 --> Encryption Class Initialized
INFO - 2021-07-14 07:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:29:10 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:29:10 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:29:10 --> Model "user_model" initialized
INFO - 2021-07-14 07:29:10 --> Model "role_model" initialized
INFO - 2021-07-14 07:29:10 --> Controller Class Initialized
INFO - 2021-07-14 07:29:10 --> Helper loaded: language_helper
INFO - 2021-07-14 07:29:10 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:29:10 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:29:10 --> Model "Product_model" initialized
INFO - 2021-07-14 07:29:10 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:29:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:29:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:29:10 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 07:29:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 07:29:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:29:10 --> Final output sent to browser
DEBUG - 2021-07-14 07:29:10 --> Total execution time: 0.0671
INFO - 2021-07-14 07:30:11 --> Config Class Initialized
INFO - 2021-07-14 07:30:11 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:30:11 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:30:11 --> Utf8 Class Initialized
INFO - 2021-07-14 07:30:11 --> URI Class Initialized
INFO - 2021-07-14 07:30:11 --> Router Class Initialized
INFO - 2021-07-14 07:30:11 --> Output Class Initialized
INFO - 2021-07-14 07:30:11 --> Security Class Initialized
DEBUG - 2021-07-14 07:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:30:11 --> Input Class Initialized
INFO - 2021-07-14 07:30:11 --> Language Class Initialized
INFO - 2021-07-14 07:30:11 --> Loader Class Initialized
INFO - 2021-07-14 07:30:11 --> Helper loaded: html_helper
INFO - 2021-07-14 07:30:11 --> Helper loaded: url_helper
INFO - 2021-07-14 07:30:11 --> Helper loaded: form_helper
INFO - 2021-07-14 07:30:11 --> Database Driver Class Initialized
INFO - 2021-07-14 07:30:11 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:30:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:30:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:30:11 --> Encryption Class Initialized
INFO - 2021-07-14 07:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:30:11 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:30:11 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:30:11 --> Model "user_model" initialized
INFO - 2021-07-14 07:30:11 --> Model "role_model" initialized
INFO - 2021-07-14 07:30:11 --> Controller Class Initialized
INFO - 2021-07-14 07:30:11 --> Helper loaded: language_helper
INFO - 2021-07-14 07:30:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:30:11 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:30:11 --> Model "Product_model" initialized
INFO - 2021-07-14 07:30:11 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:30:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:30:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:30:11 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 07:30:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 07:30:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:30:11 --> Final output sent to browser
DEBUG - 2021-07-14 07:30:11 --> Total execution time: 0.0793
INFO - 2021-07-14 07:30:16 --> Config Class Initialized
INFO - 2021-07-14 07:30:16 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:30:16 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:30:16 --> Utf8 Class Initialized
INFO - 2021-07-14 07:30:16 --> URI Class Initialized
INFO - 2021-07-14 07:30:16 --> Router Class Initialized
INFO - 2021-07-14 07:30:16 --> Output Class Initialized
INFO - 2021-07-14 07:30:16 --> Security Class Initialized
DEBUG - 2021-07-14 07:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:30:16 --> Input Class Initialized
INFO - 2021-07-14 07:30:16 --> Language Class Initialized
INFO - 2021-07-14 07:30:16 --> Loader Class Initialized
INFO - 2021-07-14 07:30:16 --> Helper loaded: html_helper
INFO - 2021-07-14 07:30:16 --> Helper loaded: url_helper
INFO - 2021-07-14 07:30:16 --> Helper loaded: form_helper
INFO - 2021-07-14 07:30:16 --> Database Driver Class Initialized
INFO - 2021-07-14 07:30:16 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:30:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:30:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:30:16 --> Encryption Class Initialized
INFO - 2021-07-14 07:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:30:16 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:30:16 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:30:16 --> Model "user_model" initialized
INFO - 2021-07-14 07:30:16 --> Model "role_model" initialized
INFO - 2021-07-14 07:30:16 --> Controller Class Initialized
INFO - 2021-07-14 07:30:16 --> Helper loaded: language_helper
INFO - 2021-07-14 07:30:16 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:30:16 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:30:16 --> Final output sent to browser
DEBUG - 2021-07-14 07:30:16 --> Total execution time: 0.0604
INFO - 2021-07-14 07:30:16 --> Config Class Initialized
INFO - 2021-07-14 07:30:16 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:30:16 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:30:16 --> Utf8 Class Initialized
INFO - 2021-07-14 07:30:16 --> URI Class Initialized
INFO - 2021-07-14 07:30:16 --> Router Class Initialized
INFO - 2021-07-14 07:30:16 --> Output Class Initialized
INFO - 2021-07-14 07:30:16 --> Security Class Initialized
DEBUG - 2021-07-14 07:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:30:16 --> Input Class Initialized
INFO - 2021-07-14 07:30:16 --> Language Class Initialized
INFO - 2021-07-14 07:30:16 --> Loader Class Initialized
INFO - 2021-07-14 07:30:16 --> Helper loaded: html_helper
INFO - 2021-07-14 07:30:16 --> Helper loaded: url_helper
INFO - 2021-07-14 07:30:16 --> Helper loaded: form_helper
INFO - 2021-07-14 07:30:16 --> Database Driver Class Initialized
INFO - 2021-07-14 07:30:16 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:30:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:30:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:30:16 --> Encryption Class Initialized
INFO - 2021-07-14 07:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:30:16 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:30:16 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:30:16 --> Model "user_model" initialized
INFO - 2021-07-14 07:30:16 --> Model "role_model" initialized
INFO - 2021-07-14 07:30:16 --> Controller Class Initialized
INFO - 2021-07-14 07:30:16 --> Helper loaded: language_helper
INFO - 2021-07-14 07:30:16 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:30:16 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:30:16 --> Final output sent to browser
DEBUG - 2021-07-14 07:30:16 --> Total execution time: 0.0610
INFO - 2021-07-14 07:30:23 --> Config Class Initialized
INFO - 2021-07-14 07:30:23 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:30:23 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:30:23 --> Utf8 Class Initialized
INFO - 2021-07-14 07:30:23 --> URI Class Initialized
INFO - 2021-07-14 07:30:23 --> Router Class Initialized
INFO - 2021-07-14 07:30:23 --> Output Class Initialized
INFO - 2021-07-14 07:30:23 --> Security Class Initialized
DEBUG - 2021-07-14 07:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:30:23 --> Input Class Initialized
INFO - 2021-07-14 07:30:23 --> Language Class Initialized
INFO - 2021-07-14 07:30:23 --> Loader Class Initialized
INFO - 2021-07-14 07:30:23 --> Helper loaded: html_helper
INFO - 2021-07-14 07:30:23 --> Helper loaded: url_helper
INFO - 2021-07-14 07:30:23 --> Helper loaded: form_helper
INFO - 2021-07-14 07:30:23 --> Database Driver Class Initialized
INFO - 2021-07-14 07:30:23 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:30:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:30:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:30:23 --> Encryption Class Initialized
INFO - 2021-07-14 07:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:30:23 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:30:23 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:30:23 --> Model "user_model" initialized
INFO - 2021-07-14 07:30:23 --> Model "role_model" initialized
INFO - 2021-07-14 07:30:23 --> Controller Class Initialized
INFO - 2021-07-14 07:30:23 --> Helper loaded: language_helper
INFO - 2021-07-14 07:30:23 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:30:23 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:30:23 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:30:23 --> Model "Product_model" initialized
INFO - 2021-07-14 07:30:23 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:30:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:30:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:30:23 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 07:30:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 07:30:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:30:23 --> Final output sent to browser
DEBUG - 2021-07-14 07:30:23 --> Total execution time: 0.0783
INFO - 2021-07-14 07:30:26 --> Config Class Initialized
INFO - 2021-07-14 07:30:26 --> Config Class Initialized
INFO - 2021-07-14 07:30:26 --> Hooks Class Initialized
INFO - 2021-07-14 07:30:26 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:30:26 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 07:30:26 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:30:26 --> Utf8 Class Initialized
INFO - 2021-07-14 07:30:26 --> Utf8 Class Initialized
INFO - 2021-07-14 07:30:26 --> URI Class Initialized
INFO - 2021-07-14 07:30:26 --> URI Class Initialized
INFO - 2021-07-14 07:30:26 --> Router Class Initialized
INFO - 2021-07-14 07:30:26 --> Router Class Initialized
INFO - 2021-07-14 07:30:26 --> Output Class Initialized
INFO - 2021-07-14 07:30:26 --> Output Class Initialized
INFO - 2021-07-14 07:30:26 --> Security Class Initialized
INFO - 2021-07-14 07:30:26 --> Security Class Initialized
DEBUG - 2021-07-14 07:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 07:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:30:26 --> Input Class Initialized
INFO - 2021-07-14 07:30:26 --> Input Class Initialized
INFO - 2021-07-14 07:30:26 --> Language Class Initialized
INFO - 2021-07-14 07:30:26 --> Language Class Initialized
INFO - 2021-07-14 07:30:26 --> Loader Class Initialized
INFO - 2021-07-14 07:30:26 --> Loader Class Initialized
INFO - 2021-07-14 07:30:26 --> Helper loaded: html_helper
INFO - 2021-07-14 07:30:26 --> Helper loaded: html_helper
INFO - 2021-07-14 07:30:26 --> Helper loaded: url_helper
INFO - 2021-07-14 07:30:26 --> Helper loaded: url_helper
INFO - 2021-07-14 07:30:26 --> Helper loaded: form_helper
INFO - 2021-07-14 07:30:26 --> Helper loaded: form_helper
INFO - 2021-07-14 07:30:26 --> Database Driver Class Initialized
INFO - 2021-07-14 07:30:26 --> Database Driver Class Initialized
INFO - 2021-07-14 07:30:26 --> Form Validation Class Initialized
INFO - 2021-07-14 07:30:26 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-14 07:30:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:30:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:30:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:30:26 --> Encryption Class Initialized
INFO - 2021-07-14 07:30:26 --> Encryption Class Initialized
INFO - 2021-07-14 07:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:30:26 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:30:26 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:30:26 --> Model "user_model" initialized
INFO - 2021-07-14 07:30:26 --> Model "role_model" initialized
INFO - 2021-07-14 07:30:26 --> Controller Class Initialized
INFO - 2021-07-14 07:30:26 --> Helper loaded: language_helper
INFO - 2021-07-14 07:30:26 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:30:26 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:30:26 --> Final output sent to browser
DEBUG - 2021-07-14 07:30:26 --> Total execution time: 0.0724
INFO - 2021-07-14 07:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:30:26 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:30:26 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:30:26 --> Model "user_model" initialized
INFO - 2021-07-14 07:30:26 --> Model "role_model" initialized
INFO - 2021-07-14 07:30:26 --> Controller Class Initialized
INFO - 2021-07-14 07:30:26 --> Helper loaded: language_helper
INFO - 2021-07-14 07:30:26 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:30:26 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:30:26 --> Final output sent to browser
DEBUG - 2021-07-14 07:30:26 --> Total execution time: 0.0817
INFO - 2021-07-14 07:30:39 --> Config Class Initialized
INFO - 2021-07-14 07:30:39 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:30:39 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:30:39 --> Utf8 Class Initialized
INFO - 2021-07-14 07:30:39 --> URI Class Initialized
INFO - 2021-07-14 07:30:39 --> Router Class Initialized
INFO - 2021-07-14 07:30:39 --> Output Class Initialized
INFO - 2021-07-14 07:30:39 --> Security Class Initialized
DEBUG - 2021-07-14 07:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:30:39 --> Input Class Initialized
INFO - 2021-07-14 07:30:39 --> Language Class Initialized
INFO - 2021-07-14 07:30:39 --> Loader Class Initialized
INFO - 2021-07-14 07:30:39 --> Helper loaded: html_helper
INFO - 2021-07-14 07:30:39 --> Helper loaded: url_helper
INFO - 2021-07-14 07:30:39 --> Helper loaded: form_helper
INFO - 2021-07-14 07:30:39 --> Database Driver Class Initialized
INFO - 2021-07-14 07:30:39 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:30:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:30:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:30:39 --> Encryption Class Initialized
INFO - 2021-07-14 07:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:30:39 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:30:39 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:30:39 --> Model "user_model" initialized
INFO - 2021-07-14 07:30:39 --> Model "role_model" initialized
INFO - 2021-07-14 07:30:39 --> Controller Class Initialized
INFO - 2021-07-14 07:30:39 --> Helper loaded: language_helper
INFO - 2021-07-14 07:30:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:30:39 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:30:39 --> Final output sent to browser
DEBUG - 2021-07-14 07:30:39 --> Total execution time: 0.0637
INFO - 2021-07-14 07:30:46 --> Config Class Initialized
INFO - 2021-07-14 07:30:46 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:30:46 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:30:46 --> Utf8 Class Initialized
INFO - 2021-07-14 07:30:46 --> URI Class Initialized
INFO - 2021-07-14 07:30:46 --> Router Class Initialized
INFO - 2021-07-14 07:30:46 --> Output Class Initialized
INFO - 2021-07-14 07:30:46 --> Security Class Initialized
DEBUG - 2021-07-14 07:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:30:46 --> Input Class Initialized
INFO - 2021-07-14 07:30:46 --> Language Class Initialized
INFO - 2021-07-14 07:30:46 --> Loader Class Initialized
INFO - 2021-07-14 07:30:46 --> Helper loaded: html_helper
INFO - 2021-07-14 07:30:46 --> Helper loaded: url_helper
INFO - 2021-07-14 07:30:46 --> Helper loaded: form_helper
INFO - 2021-07-14 07:30:46 --> Database Driver Class Initialized
INFO - 2021-07-14 07:30:46 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:30:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:30:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:30:46 --> Encryption Class Initialized
INFO - 2021-07-14 07:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:30:46 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:30:46 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:30:46 --> Model "user_model" initialized
INFO - 2021-07-14 07:30:46 --> Model "role_model" initialized
INFO - 2021-07-14 07:30:46 --> Controller Class Initialized
INFO - 2021-07-14 07:30:46 --> Helper loaded: language_helper
INFO - 2021-07-14 07:30:46 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:30:46 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:30:46 --> Model "Product_model" initialized
INFO - 2021-07-14 07:30:46 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:30:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:30:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:30:46 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 07:30:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 07:30:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:30:46 --> Final output sent to browser
DEBUG - 2021-07-14 07:30:46 --> Total execution time: 0.0703
INFO - 2021-07-14 07:30:50 --> Config Class Initialized
INFO - 2021-07-14 07:30:50 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:30:50 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:30:50 --> Utf8 Class Initialized
INFO - 2021-07-14 07:30:50 --> URI Class Initialized
INFO - 2021-07-14 07:30:50 --> Router Class Initialized
INFO - 2021-07-14 07:30:50 --> Output Class Initialized
INFO - 2021-07-14 07:30:50 --> Security Class Initialized
DEBUG - 2021-07-14 07:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:30:50 --> Input Class Initialized
INFO - 2021-07-14 07:30:50 --> Language Class Initialized
INFO - 2021-07-14 07:30:50 --> Loader Class Initialized
INFO - 2021-07-14 07:30:50 --> Helper loaded: html_helper
INFO - 2021-07-14 07:30:50 --> Helper loaded: url_helper
INFO - 2021-07-14 07:30:50 --> Helper loaded: form_helper
INFO - 2021-07-14 07:30:50 --> Database Driver Class Initialized
INFO - 2021-07-14 07:30:50 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:30:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:30:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:30:50 --> Encryption Class Initialized
INFO - 2021-07-14 07:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:30:50 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:30:50 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:30:50 --> Model "user_model" initialized
INFO - 2021-07-14 07:30:50 --> Model "role_model" initialized
INFO - 2021-07-14 07:30:50 --> Controller Class Initialized
INFO - 2021-07-14 07:30:50 --> Helper loaded: language_helper
INFO - 2021-07-14 07:30:50 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:30:50 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:30:50 --> Final output sent to browser
DEBUG - 2021-07-14 07:30:50 --> Total execution time: 0.0554
INFO - 2021-07-14 07:30:50 --> Config Class Initialized
INFO - 2021-07-14 07:30:50 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:30:50 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:30:50 --> Utf8 Class Initialized
INFO - 2021-07-14 07:30:50 --> URI Class Initialized
INFO - 2021-07-14 07:30:50 --> Router Class Initialized
INFO - 2021-07-14 07:30:50 --> Output Class Initialized
INFO - 2021-07-14 07:30:50 --> Security Class Initialized
DEBUG - 2021-07-14 07:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:30:50 --> Input Class Initialized
INFO - 2021-07-14 07:30:50 --> Language Class Initialized
INFO - 2021-07-14 07:30:50 --> Loader Class Initialized
INFO - 2021-07-14 07:30:50 --> Helper loaded: html_helper
INFO - 2021-07-14 07:30:50 --> Helper loaded: url_helper
INFO - 2021-07-14 07:30:50 --> Helper loaded: form_helper
INFO - 2021-07-14 07:30:50 --> Database Driver Class Initialized
INFO - 2021-07-14 07:30:50 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:30:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:30:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:30:50 --> Encryption Class Initialized
INFO - 2021-07-14 07:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:30:50 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:30:50 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:30:50 --> Model "user_model" initialized
INFO - 2021-07-14 07:30:50 --> Model "role_model" initialized
INFO - 2021-07-14 07:30:50 --> Controller Class Initialized
INFO - 2021-07-14 07:30:50 --> Helper loaded: language_helper
INFO - 2021-07-14 07:30:50 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:30:50 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:30:50 --> Final output sent to browser
DEBUG - 2021-07-14 07:30:50 --> Total execution time: 0.0612
INFO - 2021-07-14 07:31:25 --> Config Class Initialized
INFO - 2021-07-14 07:31:25 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:31:25 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:31:25 --> Utf8 Class Initialized
INFO - 2021-07-14 07:31:25 --> URI Class Initialized
INFO - 2021-07-14 07:31:25 --> Router Class Initialized
INFO - 2021-07-14 07:31:25 --> Output Class Initialized
INFO - 2021-07-14 07:31:25 --> Security Class Initialized
DEBUG - 2021-07-14 07:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:31:25 --> Input Class Initialized
INFO - 2021-07-14 07:31:25 --> Language Class Initialized
INFO - 2021-07-14 07:31:25 --> Loader Class Initialized
INFO - 2021-07-14 07:31:25 --> Helper loaded: html_helper
INFO - 2021-07-14 07:31:25 --> Helper loaded: url_helper
INFO - 2021-07-14 07:31:25 --> Helper loaded: form_helper
INFO - 2021-07-14 07:31:25 --> Database Driver Class Initialized
INFO - 2021-07-14 07:31:26 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:31:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:31:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:31:26 --> Encryption Class Initialized
INFO - 2021-07-14 07:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:31:26 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:31:26 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:31:26 --> Model "user_model" initialized
INFO - 2021-07-14 07:31:26 --> Model "role_model" initialized
INFO - 2021-07-14 07:31:26 --> Controller Class Initialized
INFO - 2021-07-14 07:31:26 --> Helper loaded: language_helper
INFO - 2021-07-14 07:31:26 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:31:26 --> Model "Product_model" initialized
INFO - 2021-07-14 07:31:26 --> Final output sent to browser
DEBUG - 2021-07-14 07:31:26 --> Total execution time: 0.0630
INFO - 2021-07-14 07:31:54 --> Config Class Initialized
INFO - 2021-07-14 07:31:54 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:31:54 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:31:54 --> Utf8 Class Initialized
INFO - 2021-07-14 07:31:54 --> URI Class Initialized
INFO - 2021-07-14 07:31:54 --> Router Class Initialized
INFO - 2021-07-14 07:31:54 --> Output Class Initialized
INFO - 2021-07-14 07:31:54 --> Security Class Initialized
DEBUG - 2021-07-14 07:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:31:54 --> Input Class Initialized
INFO - 2021-07-14 07:31:54 --> Language Class Initialized
INFO - 2021-07-14 07:31:54 --> Loader Class Initialized
INFO - 2021-07-14 07:31:54 --> Helper loaded: html_helper
INFO - 2021-07-14 07:31:54 --> Helper loaded: url_helper
INFO - 2021-07-14 07:31:54 --> Helper loaded: form_helper
INFO - 2021-07-14 07:31:54 --> Database Driver Class Initialized
INFO - 2021-07-14 07:31:54 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:31:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:31:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:31:54 --> Encryption Class Initialized
INFO - 2021-07-14 07:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:31:54 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:31:54 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:31:54 --> Model "user_model" initialized
INFO - 2021-07-14 07:31:54 --> Model "role_model" initialized
INFO - 2021-07-14 07:31:54 --> Controller Class Initialized
INFO - 2021-07-14 07:31:54 --> Helper loaded: language_helper
INFO - 2021-07-14 07:31:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:31:54 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:31:54 --> Final output sent to browser
DEBUG - 2021-07-14 07:31:54 --> Total execution time: 0.0691
INFO - 2021-07-14 07:31:54 --> Config Class Initialized
INFO - 2021-07-14 07:31:54 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:31:54 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:31:54 --> Utf8 Class Initialized
INFO - 2021-07-14 07:31:54 --> URI Class Initialized
INFO - 2021-07-14 07:31:54 --> Router Class Initialized
INFO - 2021-07-14 07:31:54 --> Output Class Initialized
INFO - 2021-07-14 07:31:54 --> Security Class Initialized
DEBUG - 2021-07-14 07:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:31:54 --> Input Class Initialized
INFO - 2021-07-14 07:31:54 --> Language Class Initialized
INFO - 2021-07-14 07:31:54 --> Loader Class Initialized
INFO - 2021-07-14 07:31:54 --> Helper loaded: html_helper
INFO - 2021-07-14 07:31:54 --> Helper loaded: url_helper
INFO - 2021-07-14 07:31:54 --> Helper loaded: form_helper
INFO - 2021-07-14 07:31:54 --> Database Driver Class Initialized
INFO - 2021-07-14 07:31:54 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:31:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:31:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:31:54 --> Encryption Class Initialized
INFO - 2021-07-14 07:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:31:54 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:31:54 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:31:54 --> Model "user_model" initialized
INFO - 2021-07-14 07:31:54 --> Model "role_model" initialized
INFO - 2021-07-14 07:31:54 --> Controller Class Initialized
INFO - 2021-07-14 07:31:54 --> Helper loaded: language_helper
INFO - 2021-07-14 07:31:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:31:54 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:31:54 --> Final output sent to browser
DEBUG - 2021-07-14 07:31:54 --> Total execution time: 0.0611
INFO - 2021-07-14 07:31:56 --> Config Class Initialized
INFO - 2021-07-14 07:31:56 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:31:56 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:31:56 --> Utf8 Class Initialized
INFO - 2021-07-14 07:31:56 --> URI Class Initialized
INFO - 2021-07-14 07:31:56 --> Router Class Initialized
INFO - 2021-07-14 07:31:56 --> Output Class Initialized
INFO - 2021-07-14 07:31:56 --> Security Class Initialized
DEBUG - 2021-07-14 07:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:31:56 --> Input Class Initialized
INFO - 2021-07-14 07:31:56 --> Language Class Initialized
INFO - 2021-07-14 07:31:56 --> Loader Class Initialized
INFO - 2021-07-14 07:31:56 --> Helper loaded: html_helper
INFO - 2021-07-14 07:31:56 --> Helper loaded: url_helper
INFO - 2021-07-14 07:31:56 --> Helper loaded: form_helper
INFO - 2021-07-14 07:31:56 --> Database Driver Class Initialized
INFO - 2021-07-14 07:31:56 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:31:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:31:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:31:56 --> Encryption Class Initialized
INFO - 2021-07-14 07:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:31:56 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:31:56 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:31:56 --> Model "user_model" initialized
INFO - 2021-07-14 07:31:56 --> Model "role_model" initialized
INFO - 2021-07-14 07:31:56 --> Controller Class Initialized
INFO - 2021-07-14 07:31:56 --> Helper loaded: language_helper
INFO - 2021-07-14 07:31:56 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:31:56 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:31:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:31:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:31:56 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:31:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:31:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:31:56 --> Final output sent to browser
DEBUG - 2021-07-14 07:31:56 --> Total execution time: 0.0684
INFO - 2021-07-14 07:31:56 --> Config Class Initialized
INFO - 2021-07-14 07:31:56 --> Hooks Class Initialized
INFO - 2021-07-14 07:31:56 --> Config Class Initialized
INFO - 2021-07-14 07:31:56 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:31:56 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 07:31:56 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:31:56 --> Utf8 Class Initialized
INFO - 2021-07-14 07:31:56 --> Utf8 Class Initialized
INFO - 2021-07-14 07:31:56 --> URI Class Initialized
INFO - 2021-07-14 07:31:56 --> URI Class Initialized
INFO - 2021-07-14 07:31:56 --> Router Class Initialized
INFO - 2021-07-14 07:31:56 --> Router Class Initialized
INFO - 2021-07-14 07:31:56 --> Output Class Initialized
INFO - 2021-07-14 07:31:56 --> Output Class Initialized
INFO - 2021-07-14 07:31:56 --> Security Class Initialized
INFO - 2021-07-14 07:31:56 --> Security Class Initialized
DEBUG - 2021-07-14 07:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 07:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:31:56 --> Input Class Initialized
INFO - 2021-07-14 07:31:56 --> Input Class Initialized
INFO - 2021-07-14 07:31:56 --> Language Class Initialized
INFO - 2021-07-14 07:31:56 --> Language Class Initialized
INFO - 2021-07-14 07:31:56 --> Loader Class Initialized
INFO - 2021-07-14 07:31:56 --> Loader Class Initialized
INFO - 2021-07-14 07:31:56 --> Helper loaded: html_helper
INFO - 2021-07-14 07:31:56 --> Helper loaded: html_helper
INFO - 2021-07-14 07:31:56 --> Helper loaded: url_helper
INFO - 2021-07-14 07:31:56 --> Helper loaded: url_helper
INFO - 2021-07-14 07:31:56 --> Helper loaded: form_helper
INFO - 2021-07-14 07:31:56 --> Helper loaded: form_helper
INFO - 2021-07-14 07:31:56 --> Database Driver Class Initialized
INFO - 2021-07-14 07:31:56 --> Database Driver Class Initialized
INFO - 2021-07-14 07:31:56 --> Form Validation Class Initialized
INFO - 2021-07-14 07:31:56 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:31:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:31:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2021-07-14 07:31:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:31:56 --> Encryption Class Initialized
INFO - 2021-07-14 07:31:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:31:56 --> Encryption Class Initialized
INFO - 2021-07-14 07:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:31:56 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:31:56 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:31:56 --> Model "user_model" initialized
INFO - 2021-07-14 07:31:56 --> Model "role_model" initialized
INFO - 2021-07-14 07:31:56 --> Controller Class Initialized
INFO - 2021-07-14 07:31:56 --> Helper loaded: language_helper
INFO - 2021-07-14 07:31:56 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:31:56 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:31:56 --> Final output sent to browser
DEBUG - 2021-07-14 07:31:56 --> Total execution time: 0.0772
INFO - 2021-07-14 07:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:31:56 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:31:56 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:31:56 --> Model "user_model" initialized
INFO - 2021-07-14 07:31:56 --> Model "role_model" initialized
INFO - 2021-07-14 07:31:56 --> Controller Class Initialized
INFO - 2021-07-14 07:31:56 --> Helper loaded: language_helper
INFO - 2021-07-14 07:31:56 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:31:56 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:31:56 --> Final output sent to browser
DEBUG - 2021-07-14 07:31:56 --> Total execution time: 0.0881
INFO - 2021-07-14 07:32:58 --> Config Class Initialized
INFO - 2021-07-14 07:32:58 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:32:58 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:32:58 --> Utf8 Class Initialized
INFO - 2021-07-14 07:32:58 --> URI Class Initialized
INFO - 2021-07-14 07:32:58 --> Router Class Initialized
INFO - 2021-07-14 07:32:58 --> Output Class Initialized
INFO - 2021-07-14 07:32:58 --> Security Class Initialized
DEBUG - 2021-07-14 07:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:32:58 --> Input Class Initialized
INFO - 2021-07-14 07:32:58 --> Language Class Initialized
INFO - 2021-07-14 07:32:58 --> Loader Class Initialized
INFO - 2021-07-14 07:32:58 --> Helper loaded: html_helper
INFO - 2021-07-14 07:32:58 --> Helper loaded: url_helper
INFO - 2021-07-14 07:32:58 --> Helper loaded: form_helper
INFO - 2021-07-14 07:32:58 --> Database Driver Class Initialized
INFO - 2021-07-14 07:32:58 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:32:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:32:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:32:58 --> Encryption Class Initialized
INFO - 2021-07-14 07:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:32:58 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:32:58 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:32:58 --> Model "user_model" initialized
INFO - 2021-07-14 07:32:58 --> Model "role_model" initialized
INFO - 2021-07-14 07:32:58 --> Controller Class Initialized
INFO - 2021-07-14 07:32:58 --> Helper loaded: language_helper
INFO - 2021-07-14 07:32:58 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:32:58 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:32:58 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:32:58 --> Model "Product_model" initialized
INFO - 2021-07-14 07:32:58 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:32:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:32:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:32:58 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 07:32:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 07:32:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:32:58 --> Final output sent to browser
DEBUG - 2021-07-14 07:32:58 --> Total execution time: 0.0814
INFO - 2021-07-14 07:33:04 --> Config Class Initialized
INFO - 2021-07-14 07:33:04 --> Config Class Initialized
INFO - 2021-07-14 07:33:04 --> Hooks Class Initialized
INFO - 2021-07-14 07:33:04 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:33:04 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 07:33:04 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:33:04 --> Utf8 Class Initialized
INFO - 2021-07-14 07:33:04 --> Utf8 Class Initialized
INFO - 2021-07-14 07:33:04 --> URI Class Initialized
INFO - 2021-07-14 07:33:04 --> URI Class Initialized
INFO - 2021-07-14 07:33:04 --> Router Class Initialized
INFO - 2021-07-14 07:33:04 --> Router Class Initialized
INFO - 2021-07-14 07:33:04 --> Output Class Initialized
INFO - 2021-07-14 07:33:04 --> Output Class Initialized
INFO - 2021-07-14 07:33:04 --> Security Class Initialized
INFO - 2021-07-14 07:33:04 --> Security Class Initialized
DEBUG - 2021-07-14 07:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:33:04 --> Input Class Initialized
DEBUG - 2021-07-14 07:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:33:04 --> Input Class Initialized
INFO - 2021-07-14 07:33:04 --> Language Class Initialized
INFO - 2021-07-14 07:33:04 --> Language Class Initialized
INFO - 2021-07-14 07:33:04 --> Loader Class Initialized
INFO - 2021-07-14 07:33:04 --> Loader Class Initialized
INFO - 2021-07-14 07:33:04 --> Helper loaded: html_helper
INFO - 2021-07-14 07:33:04 --> Helper loaded: html_helper
INFO - 2021-07-14 07:33:04 --> Helper loaded: url_helper
INFO - 2021-07-14 07:33:04 --> Helper loaded: url_helper
INFO - 2021-07-14 07:33:04 --> Helper loaded: form_helper
INFO - 2021-07-14 07:33:04 --> Helper loaded: form_helper
INFO - 2021-07-14 07:33:04 --> Database Driver Class Initialized
INFO - 2021-07-14 07:33:04 --> Database Driver Class Initialized
INFO - 2021-07-14 07:33:04 --> Form Validation Class Initialized
INFO - 2021-07-14 07:33:04 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:33:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:33:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:33:04 --> Encryption Class Initialized
DEBUG - 2021-07-14 07:33:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:33:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:33:04 --> Encryption Class Initialized
INFO - 2021-07-14 07:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:33:04 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:33:04 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:33:04 --> Model "user_model" initialized
INFO - 2021-07-14 07:33:04 --> Model "role_model" initialized
INFO - 2021-07-14 07:33:04 --> Controller Class Initialized
INFO - 2021-07-14 07:33:04 --> Helper loaded: language_helper
INFO - 2021-07-14 07:33:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:33:04 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:33:04 --> Final output sent to browser
DEBUG - 2021-07-14 07:33:04 --> Total execution time: 0.0672
INFO - 2021-07-14 07:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:33:04 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:33:04 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:33:04 --> Model "user_model" initialized
INFO - 2021-07-14 07:33:04 --> Model "role_model" initialized
INFO - 2021-07-14 07:33:04 --> Controller Class Initialized
INFO - 2021-07-14 07:33:04 --> Helper loaded: language_helper
INFO - 2021-07-14 07:33:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:33:04 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:33:04 --> Final output sent to browser
DEBUG - 2021-07-14 07:33:04 --> Total execution time: 0.0766
INFO - 2021-07-14 07:33:17 --> Config Class Initialized
INFO - 2021-07-14 07:33:17 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:33:17 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:33:17 --> Utf8 Class Initialized
INFO - 2021-07-14 07:33:17 --> URI Class Initialized
INFO - 2021-07-14 07:33:17 --> Router Class Initialized
INFO - 2021-07-14 07:33:17 --> Output Class Initialized
INFO - 2021-07-14 07:33:17 --> Security Class Initialized
DEBUG - 2021-07-14 07:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:33:17 --> Input Class Initialized
INFO - 2021-07-14 07:33:17 --> Language Class Initialized
INFO - 2021-07-14 07:33:17 --> Loader Class Initialized
INFO - 2021-07-14 07:33:17 --> Helper loaded: html_helper
INFO - 2021-07-14 07:33:17 --> Helper loaded: url_helper
INFO - 2021-07-14 07:33:17 --> Helper loaded: form_helper
INFO - 2021-07-14 07:33:17 --> Database Driver Class Initialized
INFO - 2021-07-14 07:33:17 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:33:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:33:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:33:17 --> Encryption Class Initialized
INFO - 2021-07-14 07:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:33:17 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:33:17 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:33:17 --> Model "user_model" initialized
INFO - 2021-07-14 07:33:17 --> Model "role_model" initialized
INFO - 2021-07-14 07:33:17 --> Controller Class Initialized
INFO - 2021-07-14 07:33:17 --> Helper loaded: language_helper
INFO - 2021-07-14 07:33:17 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:33:17 --> Model "Product_model" initialized
INFO - 2021-07-14 07:33:17 --> Final output sent to browser
DEBUG - 2021-07-14 07:33:17 --> Total execution time: 0.0599
INFO - 2021-07-14 07:34:13 --> Config Class Initialized
INFO - 2021-07-14 07:34:13 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:34:13 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:34:13 --> Utf8 Class Initialized
INFO - 2021-07-14 07:34:13 --> URI Class Initialized
INFO - 2021-07-14 07:34:13 --> Router Class Initialized
INFO - 2021-07-14 07:34:13 --> Output Class Initialized
INFO - 2021-07-14 07:34:13 --> Security Class Initialized
DEBUG - 2021-07-14 07:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:34:13 --> Input Class Initialized
INFO - 2021-07-14 07:34:13 --> Language Class Initialized
INFO - 2021-07-14 07:34:13 --> Loader Class Initialized
INFO - 2021-07-14 07:34:13 --> Helper loaded: html_helper
INFO - 2021-07-14 07:34:13 --> Helper loaded: url_helper
INFO - 2021-07-14 07:34:13 --> Helper loaded: form_helper
INFO - 2021-07-14 07:34:13 --> Database Driver Class Initialized
INFO - 2021-07-14 07:34:13 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:34:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:34:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:34:13 --> Encryption Class Initialized
INFO - 2021-07-14 07:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:34:13 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:34:13 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:34:13 --> Model "user_model" initialized
INFO - 2021-07-14 07:34:13 --> Model "role_model" initialized
INFO - 2021-07-14 07:34:13 --> Controller Class Initialized
INFO - 2021-07-14 07:34:13 --> Helper loaded: language_helper
INFO - 2021-07-14 07:34:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:34:13 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:34:13 --> Final output sent to browser
DEBUG - 2021-07-14 07:34:13 --> Total execution time: 0.0604
INFO - 2021-07-14 07:34:21 --> Config Class Initialized
INFO - 2021-07-14 07:34:21 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:34:21 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:34:21 --> Utf8 Class Initialized
INFO - 2021-07-14 07:34:21 --> URI Class Initialized
INFO - 2021-07-14 07:34:21 --> Router Class Initialized
INFO - 2021-07-14 07:34:21 --> Output Class Initialized
INFO - 2021-07-14 07:34:21 --> Security Class Initialized
DEBUG - 2021-07-14 07:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:34:21 --> Input Class Initialized
INFO - 2021-07-14 07:34:21 --> Language Class Initialized
INFO - 2021-07-14 07:34:21 --> Loader Class Initialized
INFO - 2021-07-14 07:34:21 --> Helper loaded: html_helper
INFO - 2021-07-14 07:34:21 --> Helper loaded: url_helper
INFO - 2021-07-14 07:34:21 --> Helper loaded: form_helper
INFO - 2021-07-14 07:34:21 --> Database Driver Class Initialized
INFO - 2021-07-14 07:34:21 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:34:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:34:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:34:21 --> Encryption Class Initialized
INFO - 2021-07-14 07:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:34:21 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:34:21 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:34:21 --> Model "user_model" initialized
INFO - 2021-07-14 07:34:21 --> Model "role_model" initialized
INFO - 2021-07-14 07:34:21 --> Controller Class Initialized
INFO - 2021-07-14 07:34:21 --> Helper loaded: language_helper
INFO - 2021-07-14 07:34:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:34:21 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:34:21 --> Final output sent to browser
DEBUG - 2021-07-14 07:34:21 --> Total execution time: 0.0729
INFO - 2021-07-14 07:34:21 --> Config Class Initialized
INFO - 2021-07-14 07:34:21 --> Hooks Class Initialized
INFO - 2021-07-14 07:34:21 --> Config Class Initialized
DEBUG - 2021-07-14 07:34:21 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:34:21 --> Hooks Class Initialized
INFO - 2021-07-14 07:34:21 --> Utf8 Class Initialized
DEBUG - 2021-07-14 07:34:21 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:34:21 --> Utf8 Class Initialized
INFO - 2021-07-14 07:34:21 --> URI Class Initialized
INFO - 2021-07-14 07:34:21 --> URI Class Initialized
INFO - 2021-07-14 07:34:21 --> Router Class Initialized
INFO - 2021-07-14 07:34:21 --> Output Class Initialized
INFO - 2021-07-14 07:34:21 --> Security Class Initialized
DEBUG - 2021-07-14 07:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:34:21 --> Input Class Initialized
INFO - 2021-07-14 07:34:21 --> Language Class Initialized
INFO - 2021-07-14 07:34:21 --> Router Class Initialized
INFO - 2021-07-14 07:34:21 --> Loader Class Initialized
INFO - 2021-07-14 07:34:21 --> Output Class Initialized
INFO - 2021-07-14 07:34:21 --> Helper loaded: html_helper
INFO - 2021-07-14 07:34:21 --> Security Class Initialized
INFO - 2021-07-14 07:34:21 --> Helper loaded: url_helper
DEBUG - 2021-07-14 07:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:34:22 --> Input Class Initialized
INFO - 2021-07-14 07:34:22 --> Language Class Initialized
INFO - 2021-07-14 07:34:22 --> Helper loaded: form_helper
INFO - 2021-07-14 07:34:22 --> Loader Class Initialized
INFO - 2021-07-14 07:34:22 --> Helper loaded: html_helper
INFO - 2021-07-14 07:34:22 --> Helper loaded: url_helper
INFO - 2021-07-14 07:34:22 --> Database Driver Class Initialized
INFO - 2021-07-14 07:34:22 --> Helper loaded: form_helper
INFO - 2021-07-14 07:34:22 --> Database Driver Class Initialized
INFO - 2021-07-14 07:34:22 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:34:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:34:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:34:22 --> Encryption Class Initialized
INFO - 2021-07-14 07:34:22 --> Form Validation Class Initialized
INFO - 2021-07-14 07:34:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-07-14 07:34:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:34:22 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:34:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:34:22 --> Encryption Class Initialized
INFO - 2021-07-14 07:34:22 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:34:22 --> Model "user_model" initialized
INFO - 2021-07-14 07:34:22 --> Model "role_model" initialized
INFO - 2021-07-14 07:34:22 --> Controller Class Initialized
INFO - 2021-07-14 07:34:22 --> Helper loaded: language_helper
INFO - 2021-07-14 07:34:22 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:34:22 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:34:22 --> Final output sent to browser
DEBUG - 2021-07-14 07:34:22 --> Total execution time: 0.0752
INFO - 2021-07-14 07:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:34:22 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:34:22 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:34:22 --> Model "user_model" initialized
INFO - 2021-07-14 07:34:22 --> Model "role_model" initialized
INFO - 2021-07-14 07:34:22 --> Controller Class Initialized
INFO - 2021-07-14 07:34:22 --> Helper loaded: language_helper
INFO - 2021-07-14 07:34:22 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:34:22 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:34:22 --> Final output sent to browser
DEBUG - 2021-07-14 07:34:22 --> Total execution time: 0.0893
INFO - 2021-07-14 07:34:23 --> Config Class Initialized
INFO - 2021-07-14 07:34:23 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:34:23 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:34:23 --> Utf8 Class Initialized
INFO - 2021-07-14 07:34:23 --> URI Class Initialized
INFO - 2021-07-14 07:34:23 --> Router Class Initialized
INFO - 2021-07-14 07:34:23 --> Output Class Initialized
INFO - 2021-07-14 07:34:23 --> Security Class Initialized
DEBUG - 2021-07-14 07:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:34:23 --> Input Class Initialized
INFO - 2021-07-14 07:34:23 --> Language Class Initialized
INFO - 2021-07-14 07:34:23 --> Loader Class Initialized
INFO - 2021-07-14 07:34:23 --> Helper loaded: html_helper
INFO - 2021-07-14 07:34:23 --> Helper loaded: url_helper
INFO - 2021-07-14 07:34:23 --> Helper loaded: form_helper
INFO - 2021-07-14 07:34:23 --> Database Driver Class Initialized
INFO - 2021-07-14 07:34:23 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:34:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:34:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:34:23 --> Encryption Class Initialized
INFO - 2021-07-14 07:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:34:23 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:34:23 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:34:23 --> Model "user_model" initialized
INFO - 2021-07-14 07:34:23 --> Model "role_model" initialized
INFO - 2021-07-14 07:34:23 --> Controller Class Initialized
INFO - 2021-07-14 07:34:23 --> Helper loaded: language_helper
INFO - 2021-07-14 07:34:23 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:34:23 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:34:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:34:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:34:23 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:34:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:34:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:34:23 --> Final output sent to browser
DEBUG - 2021-07-14 07:34:23 --> Total execution time: 0.0799
INFO - 2021-07-14 07:34:24 --> Config Class Initialized
INFO - 2021-07-14 07:34:24 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:34:24 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:34:24 --> Utf8 Class Initialized
INFO - 2021-07-14 07:34:24 --> URI Class Initialized
INFO - 2021-07-14 07:34:24 --> Router Class Initialized
INFO - 2021-07-14 07:34:24 --> Output Class Initialized
INFO - 2021-07-14 07:34:24 --> Security Class Initialized
DEBUG - 2021-07-14 07:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:34:24 --> Input Class Initialized
INFO - 2021-07-14 07:34:24 --> Language Class Initialized
INFO - 2021-07-14 07:34:24 --> Config Class Initialized
INFO - 2021-07-14 07:34:24 --> Hooks Class Initialized
INFO - 2021-07-14 07:34:24 --> Loader Class Initialized
INFO - 2021-07-14 07:34:24 --> Helper loaded: html_helper
INFO - 2021-07-14 07:34:24 --> Helper loaded: url_helper
INFO - 2021-07-14 07:34:24 --> Helper loaded: form_helper
INFO - 2021-07-14 07:34:24 --> Database Driver Class Initialized
DEBUG - 2021-07-14 07:34:24 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:34:24 --> Utf8 Class Initialized
INFO - 2021-07-14 07:34:24 --> URI Class Initialized
INFO - 2021-07-14 07:34:24 --> Router Class Initialized
INFO - 2021-07-14 07:34:24 --> Output Class Initialized
INFO - 2021-07-14 07:34:24 --> Security Class Initialized
DEBUG - 2021-07-14 07:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:34:24 --> Input Class Initialized
INFO - 2021-07-14 07:34:24 --> Language Class Initialized
INFO - 2021-07-14 07:34:24 --> Loader Class Initialized
INFO - 2021-07-14 07:34:24 --> Helper loaded: html_helper
INFO - 2021-07-14 07:34:24 --> Helper loaded: url_helper
INFO - 2021-07-14 07:34:24 --> Helper loaded: form_helper
INFO - 2021-07-14 07:34:24 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:34:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:34:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:34:24 --> Encryption Class Initialized
INFO - 2021-07-14 07:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:34:24 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:34:24 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:34:24 --> Model "user_model" initialized
INFO - 2021-07-14 07:34:24 --> Model "role_model" initialized
INFO - 2021-07-14 07:34:24 --> Controller Class Initialized
INFO - 2021-07-14 07:34:24 --> Helper loaded: language_helper
INFO - 2021-07-14 07:34:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:34:24 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:34:24 --> Database Driver Class Initialized
INFO - 2021-07-14 07:34:24 --> Final output sent to browser
DEBUG - 2021-07-14 07:34:24 --> Total execution time: 0.0840
INFO - 2021-07-14 07:34:24 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:34:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:34:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:34:24 --> Encryption Class Initialized
INFO - 2021-07-14 07:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:34:24 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:34:24 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:34:24 --> Model "user_model" initialized
INFO - 2021-07-14 07:34:24 --> Model "role_model" initialized
INFO - 2021-07-14 07:34:24 --> Controller Class Initialized
INFO - 2021-07-14 07:34:24 --> Helper loaded: language_helper
INFO - 2021-07-14 07:34:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:34:24 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:34:24 --> Final output sent to browser
DEBUG - 2021-07-14 07:34:24 --> Total execution time: 0.0936
INFO - 2021-07-14 07:34:30 --> Config Class Initialized
INFO - 2021-07-14 07:34:30 --> Config Class Initialized
INFO - 2021-07-14 07:34:30 --> Hooks Class Initialized
INFO - 2021-07-14 07:34:30 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:34:30 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 07:34:30 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:34:30 --> Utf8 Class Initialized
INFO - 2021-07-14 07:34:30 --> Utf8 Class Initialized
INFO - 2021-07-14 07:34:30 --> URI Class Initialized
INFO - 2021-07-14 07:34:30 --> URI Class Initialized
INFO - 2021-07-14 07:34:30 --> Router Class Initialized
INFO - 2021-07-14 07:34:30 --> Router Class Initialized
INFO - 2021-07-14 07:34:30 --> Output Class Initialized
INFO - 2021-07-14 07:34:30 --> Output Class Initialized
INFO - 2021-07-14 07:34:30 --> Security Class Initialized
INFO - 2021-07-14 07:34:30 --> Security Class Initialized
DEBUG - 2021-07-14 07:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 07:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:34:30 --> Input Class Initialized
INFO - 2021-07-14 07:34:30 --> Input Class Initialized
INFO - 2021-07-14 07:34:30 --> Language Class Initialized
INFO - 2021-07-14 07:34:30 --> Language Class Initialized
INFO - 2021-07-14 07:34:30 --> Loader Class Initialized
INFO - 2021-07-14 07:34:30 --> Loader Class Initialized
INFO - 2021-07-14 07:34:30 --> Helper loaded: html_helper
INFO - 2021-07-14 07:34:30 --> Helper loaded: html_helper
INFO - 2021-07-14 07:34:30 --> Helper loaded: url_helper
INFO - 2021-07-14 07:34:30 --> Helper loaded: url_helper
INFO - 2021-07-14 07:34:30 --> Helper loaded: form_helper
INFO - 2021-07-14 07:34:30 --> Helper loaded: form_helper
INFO - 2021-07-14 07:34:30 --> Database Driver Class Initialized
INFO - 2021-07-14 07:34:30 --> Database Driver Class Initialized
INFO - 2021-07-14 07:34:30 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:34:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:34:30 --> Form Validation Class Initialized
INFO - 2021-07-14 07:34:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:34:30 --> Encryption Class Initialized
DEBUG - 2021-07-14 07:34:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:34:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:34:30 --> Encryption Class Initialized
INFO - 2021-07-14 07:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:34:30 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:34:30 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:34:30 --> Model "user_model" initialized
INFO - 2021-07-14 07:34:30 --> Model "role_model" initialized
INFO - 2021-07-14 07:34:30 --> Controller Class Initialized
INFO - 2021-07-14 07:34:30 --> Helper loaded: language_helper
INFO - 2021-07-14 07:34:30 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:34:30 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:34:30 --> Final output sent to browser
DEBUG - 2021-07-14 07:34:30 --> Total execution time: 0.0641
INFO - 2021-07-14 07:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:34:30 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:34:30 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:34:30 --> Model "user_model" initialized
INFO - 2021-07-14 07:34:30 --> Model "role_model" initialized
INFO - 2021-07-14 07:34:30 --> Controller Class Initialized
INFO - 2021-07-14 07:34:30 --> Helper loaded: language_helper
INFO - 2021-07-14 07:34:30 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:34:30 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:34:30 --> Final output sent to browser
DEBUG - 2021-07-14 07:34:30 --> Total execution time: 0.0736
INFO - 2021-07-14 07:34:32 --> Config Class Initialized
INFO - 2021-07-14 07:34:32 --> Hooks Class Initialized
INFO - 2021-07-14 07:34:32 --> Config Class Initialized
INFO - 2021-07-14 07:34:32 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:34:32 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 07:34:32 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:34:32 --> Utf8 Class Initialized
INFO - 2021-07-14 07:34:32 --> Utf8 Class Initialized
INFO - 2021-07-14 07:34:32 --> URI Class Initialized
INFO - 2021-07-14 07:34:32 --> URI Class Initialized
INFO - 2021-07-14 07:34:32 --> Router Class Initialized
INFO - 2021-07-14 07:34:32 --> Router Class Initialized
INFO - 2021-07-14 07:34:32 --> Output Class Initialized
INFO - 2021-07-14 07:34:32 --> Output Class Initialized
INFO - 2021-07-14 07:34:32 --> Security Class Initialized
INFO - 2021-07-14 07:34:32 --> Security Class Initialized
DEBUG - 2021-07-14 07:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:34:32 --> Input Class Initialized
DEBUG - 2021-07-14 07:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:34:32 --> Input Class Initialized
INFO - 2021-07-14 07:34:32 --> Language Class Initialized
INFO - 2021-07-14 07:34:32 --> Language Class Initialized
INFO - 2021-07-14 07:34:32 --> Loader Class Initialized
INFO - 2021-07-14 07:34:32 --> Loader Class Initialized
INFO - 2021-07-14 07:34:32 --> Helper loaded: html_helper
INFO - 2021-07-14 07:34:32 --> Helper loaded: html_helper
INFO - 2021-07-14 07:34:32 --> Helper loaded: url_helper
INFO - 2021-07-14 07:34:32 --> Helper loaded: url_helper
INFO - 2021-07-14 07:34:32 --> Helper loaded: form_helper
INFO - 2021-07-14 07:34:32 --> Helper loaded: form_helper
INFO - 2021-07-14 07:34:32 --> Database Driver Class Initialized
INFO - 2021-07-14 07:34:32 --> Database Driver Class Initialized
INFO - 2021-07-14 07:34:32 --> Form Validation Class Initialized
INFO - 2021-07-14 07:34:32 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:34:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:34:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:34:32 --> Encryption Class Initialized
DEBUG - 2021-07-14 07:34:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:34:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:34:32 --> Encryption Class Initialized
INFO - 2021-07-14 07:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:34:32 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:34:32 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:34:32 --> Model "user_model" initialized
INFO - 2021-07-14 07:34:32 --> Model "role_model" initialized
INFO - 2021-07-14 07:34:32 --> Controller Class Initialized
INFO - 2021-07-14 07:34:32 --> Helper loaded: language_helper
INFO - 2021-07-14 07:34:32 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:34:32 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:34:32 --> Final output sent to browser
DEBUG - 2021-07-14 07:34:32 --> Total execution time: 0.0724
INFO - 2021-07-14 07:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:34:32 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:34:32 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:34:32 --> Model "user_model" initialized
INFO - 2021-07-14 07:34:32 --> Model "role_model" initialized
INFO - 2021-07-14 07:34:32 --> Controller Class Initialized
INFO - 2021-07-14 07:34:32 --> Helper loaded: language_helper
INFO - 2021-07-14 07:34:32 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:34:32 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:34:32 --> Final output sent to browser
DEBUG - 2021-07-14 07:34:32 --> Total execution time: 0.0827
INFO - 2021-07-14 07:34:37 --> Config Class Initialized
INFO - 2021-07-14 07:34:37 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:34:37 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:34:37 --> Utf8 Class Initialized
INFO - 2021-07-14 07:34:37 --> URI Class Initialized
INFO - 2021-07-14 07:34:37 --> Router Class Initialized
INFO - 2021-07-14 07:34:37 --> Output Class Initialized
INFO - 2021-07-14 07:34:37 --> Security Class Initialized
DEBUG - 2021-07-14 07:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:34:37 --> Input Class Initialized
INFO - 2021-07-14 07:34:37 --> Language Class Initialized
INFO - 2021-07-14 07:34:37 --> Loader Class Initialized
INFO - 2021-07-14 07:34:37 --> Helper loaded: html_helper
INFO - 2021-07-14 07:34:37 --> Helper loaded: url_helper
INFO - 2021-07-14 07:34:37 --> Helper loaded: form_helper
INFO - 2021-07-14 07:34:37 --> Database Driver Class Initialized
INFO - 2021-07-14 07:34:37 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:34:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:34:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:34:37 --> Encryption Class Initialized
INFO - 2021-07-14 07:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:34:37 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:34:37 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:34:37 --> Model "user_model" initialized
INFO - 2021-07-14 07:34:37 --> Model "role_model" initialized
INFO - 2021-07-14 07:34:37 --> Controller Class Initialized
INFO - 2021-07-14 07:34:37 --> Helper loaded: language_helper
INFO - 2021-07-14 07:34:37 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:34:37 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:34:37 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:34:37 --> Model "Product_model" initialized
INFO - 2021-07-14 07:34:37 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:34:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:34:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:34:37 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 07:34:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 07:34:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:34:37 --> Final output sent to browser
DEBUG - 2021-07-14 07:34:37 --> Total execution time: 0.0726
INFO - 2021-07-14 07:34:42 --> Config Class Initialized
INFO - 2021-07-14 07:34:42 --> Config Class Initialized
INFO - 2021-07-14 07:34:42 --> Hooks Class Initialized
INFO - 2021-07-14 07:34:42 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:34:42 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 07:34:42 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:34:42 --> Utf8 Class Initialized
INFO - 2021-07-14 07:34:42 --> Utf8 Class Initialized
INFO - 2021-07-14 07:34:42 --> URI Class Initialized
INFO - 2021-07-14 07:34:42 --> URI Class Initialized
INFO - 2021-07-14 07:34:42 --> Router Class Initialized
INFO - 2021-07-14 07:34:42 --> Router Class Initialized
INFO - 2021-07-14 07:34:42 --> Output Class Initialized
INFO - 2021-07-14 07:34:42 --> Output Class Initialized
INFO - 2021-07-14 07:34:42 --> Security Class Initialized
INFO - 2021-07-14 07:34:42 --> Security Class Initialized
DEBUG - 2021-07-14 07:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 07:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:34:42 --> Input Class Initialized
INFO - 2021-07-14 07:34:42 --> Input Class Initialized
INFO - 2021-07-14 07:34:42 --> Language Class Initialized
INFO - 2021-07-14 07:34:42 --> Language Class Initialized
INFO - 2021-07-14 07:34:42 --> Loader Class Initialized
INFO - 2021-07-14 07:34:42 --> Loader Class Initialized
INFO - 2021-07-14 07:34:42 --> Helper loaded: html_helper
INFO - 2021-07-14 07:34:42 --> Helper loaded: url_helper
INFO - 2021-07-14 07:34:42 --> Helper loaded: html_helper
INFO - 2021-07-14 07:34:42 --> Helper loaded: url_helper
INFO - 2021-07-14 07:34:42 --> Helper loaded: form_helper
INFO - 2021-07-14 07:34:42 --> Helper loaded: form_helper
INFO - 2021-07-14 07:34:42 --> Database Driver Class Initialized
INFO - 2021-07-14 07:34:42 --> Database Driver Class Initialized
INFO - 2021-07-14 07:34:42 --> Form Validation Class Initialized
INFO - 2021-07-14 07:34:42 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:34:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:34:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:34:42 --> Encryption Class Initialized
DEBUG - 2021-07-14 07:34:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:34:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:34:42 --> Encryption Class Initialized
INFO - 2021-07-14 07:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:34:42 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:34:42 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:34:42 --> Model "user_model" initialized
INFO - 2021-07-14 07:34:42 --> Model "role_model" initialized
INFO - 2021-07-14 07:34:42 --> Controller Class Initialized
INFO - 2021-07-14 07:34:42 --> Helper loaded: language_helper
INFO - 2021-07-14 07:34:42 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:34:42 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:34:42 --> Final output sent to browser
DEBUG - 2021-07-14 07:34:42 --> Total execution time: 0.0652
INFO - 2021-07-14 07:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:34:42 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:34:42 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:34:42 --> Model "user_model" initialized
INFO - 2021-07-14 07:34:42 --> Model "role_model" initialized
INFO - 2021-07-14 07:34:42 --> Controller Class Initialized
INFO - 2021-07-14 07:34:42 --> Helper loaded: language_helper
INFO - 2021-07-14 07:34:42 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:34:42 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:34:42 --> Final output sent to browser
DEBUG - 2021-07-14 07:34:42 --> Total execution time: 0.0760
INFO - 2021-07-14 07:34:46 --> Config Class Initialized
INFO - 2021-07-14 07:34:46 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:34:46 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:34:46 --> Utf8 Class Initialized
INFO - 2021-07-14 07:34:46 --> URI Class Initialized
INFO - 2021-07-14 07:34:46 --> Router Class Initialized
INFO - 2021-07-14 07:34:46 --> Output Class Initialized
INFO - 2021-07-14 07:34:46 --> Security Class Initialized
DEBUG - 2021-07-14 07:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:34:46 --> Input Class Initialized
INFO - 2021-07-14 07:34:46 --> Language Class Initialized
INFO - 2021-07-14 07:34:46 --> Loader Class Initialized
INFO - 2021-07-14 07:34:46 --> Helper loaded: html_helper
INFO - 2021-07-14 07:34:46 --> Helper loaded: url_helper
INFO - 2021-07-14 07:34:46 --> Helper loaded: form_helper
INFO - 2021-07-14 07:34:46 --> Database Driver Class Initialized
INFO - 2021-07-14 07:34:46 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:34:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:34:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:34:46 --> Encryption Class Initialized
INFO - 2021-07-14 07:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:34:46 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:34:46 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:34:46 --> Model "user_model" initialized
INFO - 2021-07-14 07:34:46 --> Model "role_model" initialized
INFO - 2021-07-14 07:34:46 --> Controller Class Initialized
INFO - 2021-07-14 07:34:46 --> Helper loaded: language_helper
INFO - 2021-07-14 07:34:46 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:34:46 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:34:46 --> Final output sent to browser
DEBUG - 2021-07-14 07:34:46 --> Total execution time: 0.0666
INFO - 2021-07-14 07:34:51 --> Config Class Initialized
INFO - 2021-07-14 07:34:51 --> Config Class Initialized
INFO - 2021-07-14 07:34:51 --> Hooks Class Initialized
INFO - 2021-07-14 07:34:51 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:34:51 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 07:34:51 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:34:51 --> Utf8 Class Initialized
INFO - 2021-07-14 07:34:51 --> Utf8 Class Initialized
INFO - 2021-07-14 07:34:51 --> URI Class Initialized
INFO - 2021-07-14 07:34:51 --> URI Class Initialized
INFO - 2021-07-14 07:34:51 --> Router Class Initialized
INFO - 2021-07-14 07:34:51 --> Router Class Initialized
INFO - 2021-07-14 07:34:51 --> Output Class Initialized
INFO - 2021-07-14 07:34:51 --> Output Class Initialized
INFO - 2021-07-14 07:34:51 --> Security Class Initialized
INFO - 2021-07-14 07:34:51 --> Security Class Initialized
DEBUG - 2021-07-14 07:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 07:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:34:51 --> Input Class Initialized
INFO - 2021-07-14 07:34:51 --> Input Class Initialized
INFO - 2021-07-14 07:34:51 --> Language Class Initialized
INFO - 2021-07-14 07:34:51 --> Language Class Initialized
INFO - 2021-07-14 07:34:51 --> Loader Class Initialized
INFO - 2021-07-14 07:34:51 --> Loader Class Initialized
INFO - 2021-07-14 07:34:51 --> Helper loaded: html_helper
INFO - 2021-07-14 07:34:51 --> Helper loaded: html_helper
INFO - 2021-07-14 07:34:51 --> Helper loaded: url_helper
INFO - 2021-07-14 07:34:51 --> Helper loaded: url_helper
INFO - 2021-07-14 07:34:51 --> Helper loaded: form_helper
INFO - 2021-07-14 07:34:51 --> Helper loaded: form_helper
INFO - 2021-07-14 07:34:51 --> Database Driver Class Initialized
INFO - 2021-07-14 07:34:51 --> Database Driver Class Initialized
INFO - 2021-07-14 07:34:51 --> Form Validation Class Initialized
INFO - 2021-07-14 07:34:51 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-14 07:34:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:34:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:34:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:34:51 --> Encryption Class Initialized
INFO - 2021-07-14 07:34:51 --> Encryption Class Initialized
INFO - 2021-07-14 07:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:34:51 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:34:51 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:34:51 --> Model "user_model" initialized
INFO - 2021-07-14 07:34:51 --> Model "role_model" initialized
INFO - 2021-07-14 07:34:51 --> Controller Class Initialized
INFO - 2021-07-14 07:34:51 --> Helper loaded: language_helper
INFO - 2021-07-14 07:34:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:34:51 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:34:51 --> Final output sent to browser
DEBUG - 2021-07-14 07:34:51 --> Total execution time: 0.0671
INFO - 2021-07-14 07:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:34:51 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:34:51 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:34:51 --> Model "user_model" initialized
INFO - 2021-07-14 07:34:51 --> Model "role_model" initialized
INFO - 2021-07-14 07:34:51 --> Controller Class Initialized
INFO - 2021-07-14 07:34:51 --> Helper loaded: language_helper
INFO - 2021-07-14 07:34:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:34:51 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:34:51 --> Final output sent to browser
DEBUG - 2021-07-14 07:34:51 --> Total execution time: 0.0775
INFO - 2021-07-14 07:34:53 --> Config Class Initialized
INFO - 2021-07-14 07:34:53 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:34:53 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:34:53 --> Utf8 Class Initialized
INFO - 2021-07-14 07:34:53 --> URI Class Initialized
INFO - 2021-07-14 07:34:53 --> Router Class Initialized
INFO - 2021-07-14 07:34:53 --> Output Class Initialized
INFO - 2021-07-14 07:34:53 --> Security Class Initialized
DEBUG - 2021-07-14 07:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:34:53 --> Input Class Initialized
INFO - 2021-07-14 07:34:53 --> Language Class Initialized
INFO - 2021-07-14 07:34:53 --> Loader Class Initialized
INFO - 2021-07-14 07:34:53 --> Helper loaded: html_helper
INFO - 2021-07-14 07:34:53 --> Helper loaded: url_helper
INFO - 2021-07-14 07:34:53 --> Helper loaded: form_helper
INFO - 2021-07-14 07:34:53 --> Database Driver Class Initialized
INFO - 2021-07-14 07:34:53 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:34:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:34:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:34:53 --> Encryption Class Initialized
INFO - 2021-07-14 07:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:34:53 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:34:53 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:34:53 --> Model "user_model" initialized
INFO - 2021-07-14 07:34:53 --> Model "role_model" initialized
INFO - 2021-07-14 07:34:53 --> Controller Class Initialized
INFO - 2021-07-14 07:34:54 --> Helper loaded: language_helper
INFO - 2021-07-14 07:34:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:34:54 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:34:54 --> Final output sent to browser
DEBUG - 2021-07-14 07:34:54 --> Total execution time: 0.0691
INFO - 2021-07-14 07:35:01 --> Config Class Initialized
INFO - 2021-07-14 07:35:01 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:35:01 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:35:01 --> Utf8 Class Initialized
INFO - 2021-07-14 07:35:01 --> URI Class Initialized
INFO - 2021-07-14 07:35:01 --> Router Class Initialized
INFO - 2021-07-14 07:35:01 --> Output Class Initialized
INFO - 2021-07-14 07:35:01 --> Security Class Initialized
DEBUG - 2021-07-14 07:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:35:01 --> Input Class Initialized
INFO - 2021-07-14 07:35:01 --> Language Class Initialized
INFO - 2021-07-14 07:35:01 --> Loader Class Initialized
INFO - 2021-07-14 07:35:01 --> Helper loaded: html_helper
INFO - 2021-07-14 07:35:01 --> Helper loaded: url_helper
INFO - 2021-07-14 07:35:01 --> Helper loaded: form_helper
INFO - 2021-07-14 07:35:01 --> Database Driver Class Initialized
INFO - 2021-07-14 07:35:01 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:35:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:35:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:35:01 --> Encryption Class Initialized
INFO - 2021-07-14 07:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:35:01 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:35:01 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:35:01 --> Model "user_model" initialized
INFO - 2021-07-14 07:35:01 --> Model "role_model" initialized
INFO - 2021-07-14 07:35:01 --> Controller Class Initialized
INFO - 2021-07-14 07:35:01 --> Helper loaded: language_helper
INFO - 2021-07-14 07:35:01 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:35:01 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:35:01 --> Model "Product_model" initialized
INFO - 2021-07-14 07:35:01 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:35:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:35:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:35:01 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 07:35:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 07:35:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:35:01 --> Final output sent to browser
DEBUG - 2021-07-14 07:35:01 --> Total execution time: 0.0714
INFO - 2021-07-14 07:35:05 --> Config Class Initialized
INFO - 2021-07-14 07:35:05 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:35:05 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:35:05 --> Utf8 Class Initialized
INFO - 2021-07-14 07:35:05 --> URI Class Initialized
INFO - 2021-07-14 07:35:05 --> Router Class Initialized
INFO - 2021-07-14 07:35:05 --> Output Class Initialized
INFO - 2021-07-14 07:35:05 --> Security Class Initialized
DEBUG - 2021-07-14 07:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:35:05 --> Input Class Initialized
INFO - 2021-07-14 07:35:05 --> Language Class Initialized
INFO - 2021-07-14 07:35:05 --> Loader Class Initialized
INFO - 2021-07-14 07:35:05 --> Helper loaded: html_helper
INFO - 2021-07-14 07:35:05 --> Helper loaded: url_helper
INFO - 2021-07-14 07:35:05 --> Helper loaded: form_helper
INFO - 2021-07-14 07:35:05 --> Database Driver Class Initialized
INFO - 2021-07-14 07:35:05 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:35:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:35:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:35:05 --> Encryption Class Initialized
INFO - 2021-07-14 07:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:35:05 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:35:05 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:35:05 --> Model "user_model" initialized
INFO - 2021-07-14 07:35:05 --> Model "role_model" initialized
INFO - 2021-07-14 07:35:05 --> Controller Class Initialized
INFO - 2021-07-14 07:35:05 --> Helper loaded: language_helper
INFO - 2021-07-14 07:35:05 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:35:05 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:35:05 --> Final output sent to browser
DEBUG - 2021-07-14 07:35:05 --> Total execution time: 0.0552
INFO - 2021-07-14 07:35:05 --> Config Class Initialized
INFO - 2021-07-14 07:35:05 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:35:05 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:35:05 --> Utf8 Class Initialized
INFO - 2021-07-14 07:35:05 --> URI Class Initialized
INFO - 2021-07-14 07:35:05 --> Router Class Initialized
INFO - 2021-07-14 07:35:05 --> Output Class Initialized
INFO - 2021-07-14 07:35:05 --> Security Class Initialized
DEBUG - 2021-07-14 07:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:35:05 --> Input Class Initialized
INFO - 2021-07-14 07:35:05 --> Language Class Initialized
INFO - 2021-07-14 07:35:05 --> Loader Class Initialized
INFO - 2021-07-14 07:35:05 --> Helper loaded: html_helper
INFO - 2021-07-14 07:35:05 --> Helper loaded: url_helper
INFO - 2021-07-14 07:35:05 --> Helper loaded: form_helper
INFO - 2021-07-14 07:35:05 --> Database Driver Class Initialized
INFO - 2021-07-14 07:35:05 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:35:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:35:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:35:05 --> Encryption Class Initialized
INFO - 2021-07-14 07:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:35:05 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:35:05 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:35:05 --> Model "user_model" initialized
INFO - 2021-07-14 07:35:05 --> Model "role_model" initialized
INFO - 2021-07-14 07:35:05 --> Controller Class Initialized
INFO - 2021-07-14 07:35:05 --> Helper loaded: language_helper
INFO - 2021-07-14 07:35:05 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:35:05 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:35:05 --> Final output sent to browser
DEBUG - 2021-07-14 07:35:05 --> Total execution time: 0.0559
INFO - 2021-07-14 07:35:35 --> Config Class Initialized
INFO - 2021-07-14 07:35:35 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:35:35 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:35:35 --> Utf8 Class Initialized
INFO - 2021-07-14 07:35:35 --> URI Class Initialized
INFO - 2021-07-14 07:35:35 --> Router Class Initialized
INFO - 2021-07-14 07:35:35 --> Output Class Initialized
INFO - 2021-07-14 07:35:35 --> Security Class Initialized
DEBUG - 2021-07-14 07:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:35:35 --> Input Class Initialized
INFO - 2021-07-14 07:35:35 --> Language Class Initialized
INFO - 2021-07-14 07:35:35 --> Loader Class Initialized
INFO - 2021-07-14 07:35:35 --> Helper loaded: html_helper
INFO - 2021-07-14 07:35:35 --> Helper loaded: url_helper
INFO - 2021-07-14 07:35:35 --> Helper loaded: form_helper
INFO - 2021-07-14 07:35:35 --> Database Driver Class Initialized
INFO - 2021-07-14 07:35:35 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:35:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:35:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:35:35 --> Encryption Class Initialized
INFO - 2021-07-14 07:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:35:35 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:35:35 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:35:35 --> Model "user_model" initialized
INFO - 2021-07-14 07:35:35 --> Model "role_model" initialized
INFO - 2021-07-14 07:35:35 --> Controller Class Initialized
INFO - 2021-07-14 07:35:35 --> Helper loaded: language_helper
INFO - 2021-07-14 07:35:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:35:35 --> Model "Product_model" initialized
INFO - 2021-07-14 07:35:35 --> Final output sent to browser
DEBUG - 2021-07-14 07:35:35 --> Total execution time: 0.0600
INFO - 2021-07-14 07:36:31 --> Config Class Initialized
INFO - 2021-07-14 07:36:31 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:36:31 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:36:31 --> Utf8 Class Initialized
INFO - 2021-07-14 07:36:31 --> URI Class Initialized
INFO - 2021-07-14 07:36:31 --> Router Class Initialized
INFO - 2021-07-14 07:36:31 --> Output Class Initialized
INFO - 2021-07-14 07:36:31 --> Security Class Initialized
DEBUG - 2021-07-14 07:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:36:31 --> Input Class Initialized
INFO - 2021-07-14 07:36:31 --> Language Class Initialized
INFO - 2021-07-14 07:36:31 --> Loader Class Initialized
INFO - 2021-07-14 07:36:31 --> Helper loaded: html_helper
INFO - 2021-07-14 07:36:31 --> Helper loaded: url_helper
INFO - 2021-07-14 07:36:31 --> Helper loaded: form_helper
INFO - 2021-07-14 07:36:31 --> Database Driver Class Initialized
INFO - 2021-07-14 07:36:31 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:36:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:36:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:36:31 --> Encryption Class Initialized
INFO - 2021-07-14 07:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:36:31 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:36:31 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:36:31 --> Model "user_model" initialized
INFO - 2021-07-14 07:36:31 --> Model "role_model" initialized
INFO - 2021-07-14 07:36:31 --> Controller Class Initialized
INFO - 2021-07-14 07:36:31 --> Helper loaded: language_helper
INFO - 2021-07-14 07:36:31 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:36:31 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:36:31 --> Model "Product_model" initialized
INFO - 2021-07-14 07:36:31 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:36:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:36:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:36:31 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 07:36:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 07:36:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:36:31 --> Final output sent to browser
DEBUG - 2021-07-14 07:36:31 --> Total execution time: 0.0746
INFO - 2021-07-14 07:37:09 --> Config Class Initialized
INFO - 2021-07-14 07:37:09 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:37:09 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:37:09 --> Utf8 Class Initialized
INFO - 2021-07-14 07:37:09 --> URI Class Initialized
INFO - 2021-07-14 07:37:09 --> Router Class Initialized
INFO - 2021-07-14 07:37:09 --> Output Class Initialized
INFO - 2021-07-14 07:37:09 --> Security Class Initialized
DEBUG - 2021-07-14 07:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:37:09 --> Input Class Initialized
INFO - 2021-07-14 07:37:09 --> Language Class Initialized
INFO - 2021-07-14 07:37:09 --> Loader Class Initialized
INFO - 2021-07-14 07:37:09 --> Helper loaded: html_helper
INFO - 2021-07-14 07:37:09 --> Helper loaded: url_helper
INFO - 2021-07-14 07:37:09 --> Helper loaded: form_helper
INFO - 2021-07-14 07:37:09 --> Database Driver Class Initialized
INFO - 2021-07-14 07:37:09 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:37:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:37:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:37:09 --> Encryption Class Initialized
INFO - 2021-07-14 07:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:37:09 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:37:09 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:37:09 --> Model "user_model" initialized
INFO - 2021-07-14 07:37:09 --> Model "role_model" initialized
INFO - 2021-07-14 07:37:09 --> Controller Class Initialized
INFO - 2021-07-14 07:37:09 --> Helper loaded: language_helper
INFO - 2021-07-14 07:37:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:37:09 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:37:09 --> Model "Product_model" initialized
INFO - 2021-07-14 07:37:09 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:37:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:37:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:37:09 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 07:37:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 07:37:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:37:09 --> Final output sent to browser
DEBUG - 2021-07-14 07:37:09 --> Total execution time: 0.0784
INFO - 2021-07-14 07:37:16 --> Config Class Initialized
INFO - 2021-07-14 07:37:16 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:37:16 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:37:16 --> Utf8 Class Initialized
INFO - 2021-07-14 07:37:16 --> URI Class Initialized
INFO - 2021-07-14 07:37:16 --> Router Class Initialized
INFO - 2021-07-14 07:37:16 --> Output Class Initialized
INFO - 2021-07-14 07:37:16 --> Security Class Initialized
DEBUG - 2021-07-14 07:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:37:16 --> Input Class Initialized
INFO - 2021-07-14 07:37:16 --> Language Class Initialized
INFO - 2021-07-14 07:37:16 --> Loader Class Initialized
INFO - 2021-07-14 07:37:16 --> Helper loaded: html_helper
INFO - 2021-07-14 07:37:16 --> Helper loaded: url_helper
INFO - 2021-07-14 07:37:16 --> Helper loaded: form_helper
INFO - 2021-07-14 07:37:16 --> Database Driver Class Initialized
INFO - 2021-07-14 07:37:16 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:37:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:37:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:37:16 --> Encryption Class Initialized
INFO - 2021-07-14 07:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:37:16 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:37:16 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:37:16 --> Model "user_model" initialized
INFO - 2021-07-14 07:37:16 --> Model "role_model" initialized
INFO - 2021-07-14 07:37:16 --> Controller Class Initialized
INFO - 2021-07-14 07:37:16 --> Helper loaded: language_helper
INFO - 2021-07-14 07:37:16 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:37:16 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:37:16 --> Final output sent to browser
DEBUG - 2021-07-14 07:37:16 --> Total execution time: 0.0604
INFO - 2021-07-14 07:37:16 --> Config Class Initialized
INFO - 2021-07-14 07:37:16 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:37:16 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:37:16 --> Utf8 Class Initialized
INFO - 2021-07-14 07:37:16 --> URI Class Initialized
INFO - 2021-07-14 07:37:16 --> Router Class Initialized
INFO - 2021-07-14 07:37:16 --> Output Class Initialized
INFO - 2021-07-14 07:37:16 --> Security Class Initialized
DEBUG - 2021-07-14 07:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:37:16 --> Input Class Initialized
INFO - 2021-07-14 07:37:16 --> Language Class Initialized
INFO - 2021-07-14 07:37:16 --> Loader Class Initialized
INFO - 2021-07-14 07:37:16 --> Helper loaded: html_helper
INFO - 2021-07-14 07:37:16 --> Helper loaded: url_helper
INFO - 2021-07-14 07:37:16 --> Helper loaded: form_helper
INFO - 2021-07-14 07:37:16 --> Database Driver Class Initialized
INFO - 2021-07-14 07:37:16 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:37:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:37:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:37:16 --> Encryption Class Initialized
INFO - 2021-07-14 07:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:37:16 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:37:16 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:37:16 --> Model "user_model" initialized
INFO - 2021-07-14 07:37:16 --> Model "role_model" initialized
INFO - 2021-07-14 07:37:16 --> Controller Class Initialized
INFO - 2021-07-14 07:37:16 --> Helper loaded: language_helper
INFO - 2021-07-14 07:37:16 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:37:16 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:37:16 --> Final output sent to browser
DEBUG - 2021-07-14 07:37:16 --> Total execution time: 0.0568
INFO - 2021-07-14 07:37:19 --> Config Class Initialized
INFO - 2021-07-14 07:37:19 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:37:19 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:37:19 --> Utf8 Class Initialized
INFO - 2021-07-14 07:37:19 --> URI Class Initialized
INFO - 2021-07-14 07:37:19 --> Router Class Initialized
INFO - 2021-07-14 07:37:19 --> Output Class Initialized
INFO - 2021-07-14 07:37:19 --> Security Class Initialized
DEBUG - 2021-07-14 07:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:37:19 --> Input Class Initialized
INFO - 2021-07-14 07:37:19 --> Language Class Initialized
INFO - 2021-07-14 07:37:19 --> Loader Class Initialized
INFO - 2021-07-14 07:37:19 --> Helper loaded: html_helper
INFO - 2021-07-14 07:37:19 --> Helper loaded: url_helper
INFO - 2021-07-14 07:37:19 --> Helper loaded: form_helper
INFO - 2021-07-14 07:37:19 --> Database Driver Class Initialized
INFO - 2021-07-14 07:37:19 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:37:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:37:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:37:19 --> Encryption Class Initialized
INFO - 2021-07-14 07:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:37:19 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:37:19 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:37:19 --> Model "user_model" initialized
INFO - 2021-07-14 07:37:19 --> Model "role_model" initialized
INFO - 2021-07-14 07:37:19 --> Controller Class Initialized
INFO - 2021-07-14 07:37:19 --> Helper loaded: language_helper
INFO - 2021-07-14 07:37:19 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:37:19 --> Model "Product_model" initialized
INFO - 2021-07-14 07:37:19 --> Final output sent to browser
DEBUG - 2021-07-14 07:37:19 --> Total execution time: 0.0586
INFO - 2021-07-14 07:37:49 --> Config Class Initialized
INFO - 2021-07-14 07:37:49 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:37:49 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:37:49 --> Utf8 Class Initialized
INFO - 2021-07-14 07:37:49 --> URI Class Initialized
INFO - 2021-07-14 07:37:49 --> Router Class Initialized
INFO - 2021-07-14 07:37:49 --> Output Class Initialized
INFO - 2021-07-14 07:37:49 --> Security Class Initialized
DEBUG - 2021-07-14 07:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:37:49 --> Input Class Initialized
INFO - 2021-07-14 07:37:49 --> Language Class Initialized
INFO - 2021-07-14 07:37:49 --> Loader Class Initialized
INFO - 2021-07-14 07:37:49 --> Helper loaded: html_helper
INFO - 2021-07-14 07:37:49 --> Helper loaded: url_helper
INFO - 2021-07-14 07:37:49 --> Helper loaded: form_helper
INFO - 2021-07-14 07:37:49 --> Database Driver Class Initialized
INFO - 2021-07-14 07:37:49 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:37:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:37:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:37:49 --> Encryption Class Initialized
INFO - 2021-07-14 07:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:37:49 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:37:49 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:37:49 --> Model "user_model" initialized
INFO - 2021-07-14 07:37:49 --> Model "role_model" initialized
INFO - 2021-07-14 07:37:49 --> Controller Class Initialized
INFO - 2021-07-14 07:37:49 --> Helper loaded: language_helper
INFO - 2021-07-14 07:37:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:37:49 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:37:49 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:37:49 --> Model "Product_model" initialized
INFO - 2021-07-14 07:37:49 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:37:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:37:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:37:49 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 07:37:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 07:37:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:37:49 --> Final output sent to browser
DEBUG - 2021-07-14 07:37:49 --> Total execution time: 0.0780
INFO - 2021-07-14 07:37:52 --> Config Class Initialized
INFO - 2021-07-14 07:37:52 --> Hooks Class Initialized
INFO - 2021-07-14 07:37:52 --> Config Class Initialized
INFO - 2021-07-14 07:37:52 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:37:52 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 07:37:52 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:37:52 --> Utf8 Class Initialized
INFO - 2021-07-14 07:37:52 --> Utf8 Class Initialized
INFO - 2021-07-14 07:37:52 --> URI Class Initialized
INFO - 2021-07-14 07:37:52 --> URI Class Initialized
INFO - 2021-07-14 07:37:52 --> Router Class Initialized
INFO - 2021-07-14 07:37:52 --> Router Class Initialized
INFO - 2021-07-14 07:37:52 --> Output Class Initialized
INFO - 2021-07-14 07:37:52 --> Output Class Initialized
INFO - 2021-07-14 07:37:52 --> Security Class Initialized
INFO - 2021-07-14 07:37:52 --> Security Class Initialized
DEBUG - 2021-07-14 07:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 07:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:37:52 --> Input Class Initialized
INFO - 2021-07-14 07:37:52 --> Input Class Initialized
INFO - 2021-07-14 07:37:52 --> Language Class Initialized
INFO - 2021-07-14 07:37:52 --> Language Class Initialized
INFO - 2021-07-14 07:37:52 --> Loader Class Initialized
INFO - 2021-07-14 07:37:52 --> Loader Class Initialized
INFO - 2021-07-14 07:37:52 --> Helper loaded: html_helper
INFO - 2021-07-14 07:37:52 --> Helper loaded: html_helper
INFO - 2021-07-14 07:37:52 --> Helper loaded: url_helper
INFO - 2021-07-14 07:37:52 --> Helper loaded: url_helper
INFO - 2021-07-14 07:37:52 --> Helper loaded: form_helper
INFO - 2021-07-14 07:37:52 --> Helper loaded: form_helper
INFO - 2021-07-14 07:37:52 --> Database Driver Class Initialized
INFO - 2021-07-14 07:37:52 --> Database Driver Class Initialized
INFO - 2021-07-14 07:37:52 --> Form Validation Class Initialized
INFO - 2021-07-14 07:37:52 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:37:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:37:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:37:52 --> Encryption Class Initialized
DEBUG - 2021-07-14 07:37:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:37:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:37:52 --> Encryption Class Initialized
INFO - 2021-07-14 07:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:37:52 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:37:52 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:37:52 --> Model "user_model" initialized
INFO - 2021-07-14 07:37:52 --> Model "role_model" initialized
INFO - 2021-07-14 07:37:52 --> Controller Class Initialized
INFO - 2021-07-14 07:37:52 --> Helper loaded: language_helper
INFO - 2021-07-14 07:37:52 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:37:52 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:37:52 --> Final output sent to browser
DEBUG - 2021-07-14 07:37:52 --> Total execution time: 0.0617
INFO - 2021-07-14 07:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:37:52 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:37:52 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:37:52 --> Model "user_model" initialized
INFO - 2021-07-14 07:37:52 --> Model "role_model" initialized
INFO - 2021-07-14 07:37:52 --> Controller Class Initialized
INFO - 2021-07-14 07:37:52 --> Helper loaded: language_helper
INFO - 2021-07-14 07:37:52 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:37:52 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:37:52 --> Final output sent to browser
DEBUG - 2021-07-14 07:37:52 --> Total execution time: 0.0748
INFO - 2021-07-14 07:37:54 --> Config Class Initialized
INFO - 2021-07-14 07:37:54 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:37:54 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:37:54 --> Utf8 Class Initialized
INFO - 2021-07-14 07:37:54 --> URI Class Initialized
INFO - 2021-07-14 07:37:54 --> Router Class Initialized
INFO - 2021-07-14 07:37:54 --> Output Class Initialized
INFO - 2021-07-14 07:37:54 --> Security Class Initialized
DEBUG - 2021-07-14 07:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:37:54 --> Input Class Initialized
INFO - 2021-07-14 07:37:54 --> Language Class Initialized
INFO - 2021-07-14 07:37:54 --> Loader Class Initialized
INFO - 2021-07-14 07:37:54 --> Helper loaded: html_helper
INFO - 2021-07-14 07:37:54 --> Helper loaded: url_helper
INFO - 2021-07-14 07:37:54 --> Config Class Initialized
INFO - 2021-07-14 07:37:54 --> Hooks Class Initialized
INFO - 2021-07-14 07:37:54 --> Helper loaded: form_helper
DEBUG - 2021-07-14 07:37:54 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:37:54 --> Utf8 Class Initialized
INFO - 2021-07-14 07:37:54 --> URI Class Initialized
INFO - 2021-07-14 07:37:54 --> Router Class Initialized
INFO - 2021-07-14 07:37:54 --> Output Class Initialized
INFO - 2021-07-14 07:37:54 --> Database Driver Class Initialized
INFO - 2021-07-14 07:37:54 --> Security Class Initialized
DEBUG - 2021-07-14 07:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:37:54 --> Input Class Initialized
INFO - 2021-07-14 07:37:54 --> Language Class Initialized
INFO - 2021-07-14 07:37:54 --> Loader Class Initialized
INFO - 2021-07-14 07:37:54 --> Helper loaded: html_helper
INFO - 2021-07-14 07:37:54 --> Helper loaded: url_helper
INFO - 2021-07-14 07:37:54 --> Helper loaded: form_helper
INFO - 2021-07-14 07:37:54 --> Database Driver Class Initialized
INFO - 2021-07-14 07:37:54 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:37:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:37:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:37:54 --> Encryption Class Initialized
INFO - 2021-07-14 07:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:37:54 --> Form Validation Class Initialized
INFO - 2021-07-14 07:37:54 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:37:54 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:37:54 --> Model "user_model" initialized
INFO - 2021-07-14 07:37:54 --> Model "role_model" initialized
DEBUG - 2021-07-14 07:37:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:37:54 --> Controller Class Initialized
INFO - 2021-07-14 07:37:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:37:54 --> Encryption Class Initialized
INFO - 2021-07-14 07:37:54 --> Helper loaded: language_helper
INFO - 2021-07-14 07:37:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:37:54 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:37:54 --> Final output sent to browser
DEBUG - 2021-07-14 07:37:54 --> Total execution time: 0.0664
INFO - 2021-07-14 07:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:37:54 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:37:54 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:37:54 --> Model "user_model" initialized
INFO - 2021-07-14 07:37:54 --> Model "role_model" initialized
INFO - 2021-07-14 07:37:54 --> Controller Class Initialized
INFO - 2021-07-14 07:37:54 --> Helper loaded: language_helper
INFO - 2021-07-14 07:37:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:37:54 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:37:54 --> Final output sent to browser
DEBUG - 2021-07-14 07:37:54 --> Total execution time: 0.0580
INFO - 2021-07-14 07:38:12 --> Config Class Initialized
INFO - 2021-07-14 07:38:12 --> Hooks Class Initialized
INFO - 2021-07-14 07:38:12 --> Config Class Initialized
INFO - 2021-07-14 07:38:12 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:38:12 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:38:12 --> Utf8 Class Initialized
DEBUG - 2021-07-14 07:38:12 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:38:12 --> Utf8 Class Initialized
INFO - 2021-07-14 07:38:12 --> URI Class Initialized
INFO - 2021-07-14 07:38:12 --> URI Class Initialized
INFO - 2021-07-14 07:38:12 --> Router Class Initialized
INFO - 2021-07-14 07:38:12 --> Router Class Initialized
INFO - 2021-07-14 07:38:12 --> Output Class Initialized
INFO - 2021-07-14 07:38:12 --> Output Class Initialized
INFO - 2021-07-14 07:38:12 --> Security Class Initialized
INFO - 2021-07-14 07:38:12 --> Security Class Initialized
DEBUG - 2021-07-14 07:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 07:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:38:12 --> Input Class Initialized
INFO - 2021-07-14 07:38:12 --> Input Class Initialized
INFO - 2021-07-14 07:38:12 --> Language Class Initialized
INFO - 2021-07-14 07:38:12 --> Language Class Initialized
INFO - 2021-07-14 07:38:12 --> Loader Class Initialized
INFO - 2021-07-14 07:38:12 --> Loader Class Initialized
INFO - 2021-07-14 07:38:12 --> Helper loaded: html_helper
INFO - 2021-07-14 07:38:12 --> Helper loaded: html_helper
INFO - 2021-07-14 07:38:12 --> Helper loaded: url_helper
INFO - 2021-07-14 07:38:12 --> Helper loaded: url_helper
INFO - 2021-07-14 07:38:12 --> Helper loaded: form_helper
INFO - 2021-07-14 07:38:12 --> Helper loaded: form_helper
INFO - 2021-07-14 07:38:12 --> Database Driver Class Initialized
INFO - 2021-07-14 07:38:12 --> Database Driver Class Initialized
INFO - 2021-07-14 07:38:12 --> Form Validation Class Initialized
INFO - 2021-07-14 07:38:12 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:38:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:38:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:38:12 --> Encryption Class Initialized
DEBUG - 2021-07-14 07:38:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:38:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:38:12 --> Encryption Class Initialized
INFO - 2021-07-14 07:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:38:12 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:38:12 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:38:12 --> Model "user_model" initialized
INFO - 2021-07-14 07:38:12 --> Model "role_model" initialized
INFO - 2021-07-14 07:38:12 --> Controller Class Initialized
INFO - 2021-07-14 07:38:12 --> Helper loaded: language_helper
INFO - 2021-07-14 07:38:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:38:12 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:38:12 --> Final output sent to browser
DEBUG - 2021-07-14 07:38:12 --> Total execution time: 0.0677
INFO - 2021-07-14 07:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:38:12 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:38:12 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:38:12 --> Model "user_model" initialized
INFO - 2021-07-14 07:38:12 --> Model "role_model" initialized
INFO - 2021-07-14 07:38:12 --> Controller Class Initialized
INFO - 2021-07-14 07:38:12 --> Helper loaded: language_helper
INFO - 2021-07-14 07:38:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:38:12 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:38:12 --> Final output sent to browser
DEBUG - 2021-07-14 07:38:12 --> Total execution time: 0.0758
INFO - 2021-07-14 07:38:18 --> Config Class Initialized
INFO - 2021-07-14 07:38:18 --> Hooks Class Initialized
INFO - 2021-07-14 07:38:18 --> Config Class Initialized
INFO - 2021-07-14 07:38:18 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:38:18 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:38:18 --> Utf8 Class Initialized
DEBUG - 2021-07-14 07:38:18 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:38:18 --> Utf8 Class Initialized
INFO - 2021-07-14 07:38:18 --> URI Class Initialized
INFO - 2021-07-14 07:38:18 --> URI Class Initialized
INFO - 2021-07-14 07:38:18 --> Router Class Initialized
INFO - 2021-07-14 07:38:18 --> Router Class Initialized
INFO - 2021-07-14 07:38:18 --> Output Class Initialized
INFO - 2021-07-14 07:38:18 --> Output Class Initialized
INFO - 2021-07-14 07:38:18 --> Security Class Initialized
INFO - 2021-07-14 07:38:18 --> Security Class Initialized
DEBUG - 2021-07-14 07:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:38:18 --> Input Class Initialized
DEBUG - 2021-07-14 07:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:38:18 --> Input Class Initialized
INFO - 2021-07-14 07:38:18 --> Language Class Initialized
INFO - 2021-07-14 07:38:18 --> Language Class Initialized
INFO - 2021-07-14 07:38:18 --> Loader Class Initialized
INFO - 2021-07-14 07:38:18 --> Loader Class Initialized
INFO - 2021-07-14 07:38:18 --> Helper loaded: html_helper
INFO - 2021-07-14 07:38:18 --> Helper loaded: html_helper
INFO - 2021-07-14 07:38:18 --> Helper loaded: url_helper
INFO - 2021-07-14 07:38:18 --> Helper loaded: url_helper
INFO - 2021-07-14 07:38:18 --> Helper loaded: form_helper
INFO - 2021-07-14 07:38:18 --> Helper loaded: form_helper
INFO - 2021-07-14 07:38:18 --> Database Driver Class Initialized
INFO - 2021-07-14 07:38:18 --> Database Driver Class Initialized
INFO - 2021-07-14 07:38:18 --> Form Validation Class Initialized
INFO - 2021-07-14 07:38:18 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-14 07:38:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:38:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:38:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:38:18 --> Encryption Class Initialized
INFO - 2021-07-14 07:38:18 --> Encryption Class Initialized
INFO - 2021-07-14 07:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:38:18 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:38:18 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:38:18 --> Model "user_model" initialized
INFO - 2021-07-14 07:38:18 --> Model "role_model" initialized
INFO - 2021-07-14 07:38:18 --> Controller Class Initialized
INFO - 2021-07-14 07:38:18 --> Helper loaded: language_helper
INFO - 2021-07-14 07:38:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:38:18 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:38:18 --> Final output sent to browser
DEBUG - 2021-07-14 07:38:18 --> Total execution time: 0.0666
INFO - 2021-07-14 07:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:38:18 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:38:18 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:38:18 --> Model "user_model" initialized
INFO - 2021-07-14 07:38:18 --> Model "role_model" initialized
INFO - 2021-07-14 07:38:18 --> Controller Class Initialized
INFO - 2021-07-14 07:38:18 --> Helper loaded: language_helper
INFO - 2021-07-14 07:38:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:38:18 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:38:18 --> Final output sent to browser
DEBUG - 2021-07-14 07:38:18 --> Total execution time: 0.0779
INFO - 2021-07-14 07:38:24 --> Config Class Initialized
INFO - 2021-07-14 07:38:24 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:38:24 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:38:24 --> Utf8 Class Initialized
INFO - 2021-07-14 07:38:24 --> URI Class Initialized
INFO - 2021-07-14 07:38:24 --> Router Class Initialized
INFO - 2021-07-14 07:38:24 --> Output Class Initialized
INFO - 2021-07-14 07:38:24 --> Security Class Initialized
DEBUG - 2021-07-14 07:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:38:24 --> Input Class Initialized
INFO - 2021-07-14 07:38:24 --> Language Class Initialized
INFO - 2021-07-14 07:38:24 --> Loader Class Initialized
INFO - 2021-07-14 07:38:24 --> Helper loaded: html_helper
INFO - 2021-07-14 07:38:24 --> Helper loaded: url_helper
INFO - 2021-07-14 07:38:24 --> Helper loaded: form_helper
INFO - 2021-07-14 07:38:24 --> Database Driver Class Initialized
INFO - 2021-07-14 07:38:24 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:38:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:38:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:38:24 --> Encryption Class Initialized
INFO - 2021-07-14 07:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:38:24 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:38:24 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:38:24 --> Model "user_model" initialized
INFO - 2021-07-14 07:38:24 --> Model "role_model" initialized
INFO - 2021-07-14 07:38:24 --> Controller Class Initialized
INFO - 2021-07-14 07:38:24 --> Helper loaded: language_helper
INFO - 2021-07-14 07:38:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:38:24 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:38:24 --> Model "Product_model" initialized
INFO - 2021-07-14 07:38:24 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:38:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:38:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:38:24 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 07:38:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 07:38:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:38:24 --> Final output sent to browser
DEBUG - 2021-07-14 07:38:24 --> Total execution time: 0.0795
INFO - 2021-07-14 07:38:34 --> Config Class Initialized
INFO - 2021-07-14 07:38:34 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:38:34 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:38:34 --> Utf8 Class Initialized
INFO - 2021-07-14 07:38:34 --> URI Class Initialized
INFO - 2021-07-14 07:38:34 --> Router Class Initialized
INFO - 2021-07-14 07:38:34 --> Output Class Initialized
INFO - 2021-07-14 07:38:34 --> Security Class Initialized
DEBUG - 2021-07-14 07:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:38:34 --> Input Class Initialized
INFO - 2021-07-14 07:38:34 --> Language Class Initialized
INFO - 2021-07-14 07:38:34 --> Loader Class Initialized
INFO - 2021-07-14 07:38:34 --> Helper loaded: html_helper
INFO - 2021-07-14 07:38:34 --> Helper loaded: url_helper
INFO - 2021-07-14 07:38:34 --> Helper loaded: form_helper
INFO - 2021-07-14 07:38:34 --> Database Driver Class Initialized
INFO - 2021-07-14 07:38:34 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:38:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:38:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:38:34 --> Encryption Class Initialized
INFO - 2021-07-14 07:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:38:34 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:38:34 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:38:34 --> Model "user_model" initialized
INFO - 2021-07-14 07:38:34 --> Model "role_model" initialized
INFO - 2021-07-14 07:38:34 --> Controller Class Initialized
INFO - 2021-07-14 07:38:34 --> Helper loaded: language_helper
INFO - 2021-07-14 07:38:34 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:38:34 --> Model "Product_model" initialized
INFO - 2021-07-14 07:38:34 --> Final output sent to browser
DEBUG - 2021-07-14 07:38:34 --> Total execution time: 0.0490
INFO - 2021-07-14 07:39:54 --> Config Class Initialized
INFO - 2021-07-14 07:39:54 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:39:54 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:39:54 --> Utf8 Class Initialized
INFO - 2021-07-14 07:39:54 --> URI Class Initialized
INFO - 2021-07-14 07:39:54 --> Router Class Initialized
INFO - 2021-07-14 07:39:54 --> Output Class Initialized
INFO - 2021-07-14 07:39:54 --> Security Class Initialized
DEBUG - 2021-07-14 07:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:39:54 --> Input Class Initialized
INFO - 2021-07-14 07:39:54 --> Language Class Initialized
INFO - 2021-07-14 07:39:54 --> Loader Class Initialized
INFO - 2021-07-14 07:39:54 --> Helper loaded: html_helper
INFO - 2021-07-14 07:39:54 --> Helper loaded: url_helper
INFO - 2021-07-14 07:39:54 --> Helper loaded: form_helper
INFO - 2021-07-14 07:39:54 --> Database Driver Class Initialized
INFO - 2021-07-14 07:39:54 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:39:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:39:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:39:54 --> Encryption Class Initialized
INFO - 2021-07-14 07:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:39:54 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:39:54 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:39:54 --> Model "user_model" initialized
INFO - 2021-07-14 07:39:54 --> Model "role_model" initialized
INFO - 2021-07-14 07:39:54 --> Controller Class Initialized
INFO - 2021-07-14 07:39:54 --> Helper loaded: language_helper
INFO - 2021-07-14 07:39:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:39:54 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:39:54 --> Model "Product_model" initialized
INFO - 2021-07-14 07:39:54 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:39:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:39:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:39:54 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 07:39:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 07:39:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:39:54 --> Final output sent to browser
DEBUG - 2021-07-14 07:39:54 --> Total execution time: 0.1132
INFO - 2021-07-14 07:40:15 --> Config Class Initialized
INFO - 2021-07-14 07:40:15 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:40:15 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:40:15 --> Utf8 Class Initialized
INFO - 2021-07-14 07:40:15 --> URI Class Initialized
INFO - 2021-07-14 07:40:15 --> Router Class Initialized
INFO - 2021-07-14 07:40:15 --> Output Class Initialized
INFO - 2021-07-14 07:40:15 --> Security Class Initialized
DEBUG - 2021-07-14 07:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:40:15 --> Input Class Initialized
INFO - 2021-07-14 07:40:15 --> Language Class Initialized
INFO - 2021-07-14 07:40:15 --> Loader Class Initialized
INFO - 2021-07-14 07:40:15 --> Helper loaded: html_helper
INFO - 2021-07-14 07:40:15 --> Helper loaded: url_helper
INFO - 2021-07-14 07:40:15 --> Helper loaded: form_helper
INFO - 2021-07-14 07:40:15 --> Database Driver Class Initialized
INFO - 2021-07-14 07:40:15 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:40:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:40:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:40:15 --> Encryption Class Initialized
INFO - 2021-07-14 07:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:40:15 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:40:15 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:40:15 --> Model "user_model" initialized
INFO - 2021-07-14 07:40:15 --> Model "role_model" initialized
INFO - 2021-07-14 07:40:15 --> Controller Class Initialized
INFO - 2021-07-14 07:40:15 --> Helper loaded: language_helper
INFO - 2021-07-14 07:40:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:40:15 --> Model "Product_model" initialized
INFO - 2021-07-14 07:40:15 --> Final output sent to browser
DEBUG - 2021-07-14 07:40:15 --> Total execution time: 0.0676
INFO - 2021-07-14 07:40:25 --> Config Class Initialized
INFO - 2021-07-14 07:40:25 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:40:25 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:40:25 --> Utf8 Class Initialized
INFO - 2021-07-14 07:40:25 --> URI Class Initialized
INFO - 2021-07-14 07:40:25 --> Router Class Initialized
INFO - 2021-07-14 07:40:25 --> Output Class Initialized
INFO - 2021-07-14 07:40:25 --> Security Class Initialized
DEBUG - 2021-07-14 07:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:40:25 --> Input Class Initialized
INFO - 2021-07-14 07:40:25 --> Language Class Initialized
INFO - 2021-07-14 07:40:25 --> Loader Class Initialized
INFO - 2021-07-14 07:40:25 --> Helper loaded: html_helper
INFO - 2021-07-14 07:40:25 --> Helper loaded: url_helper
INFO - 2021-07-14 07:40:25 --> Helper loaded: form_helper
INFO - 2021-07-14 07:40:25 --> Database Driver Class Initialized
INFO - 2021-07-14 07:40:25 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:40:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:40:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:40:25 --> Encryption Class Initialized
INFO - 2021-07-14 07:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:40:25 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:40:25 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:40:25 --> Model "user_model" initialized
INFO - 2021-07-14 07:40:25 --> Model "role_model" initialized
INFO - 2021-07-14 07:40:25 --> Controller Class Initialized
INFO - 2021-07-14 07:40:25 --> Helper loaded: language_helper
INFO - 2021-07-14 07:40:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:40:25 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:40:25 --> Model "Product_model" initialized
INFO - 2021-07-14 07:40:25 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:40:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:40:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:40:25 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 07:40:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 07:40:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:40:25 --> Final output sent to browser
DEBUG - 2021-07-14 07:40:25 --> Total execution time: 0.0788
INFO - 2021-07-14 07:40:37 --> Config Class Initialized
INFO - 2021-07-14 07:40:37 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:40:37 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:40:37 --> Utf8 Class Initialized
INFO - 2021-07-14 07:40:37 --> URI Class Initialized
INFO - 2021-07-14 07:40:37 --> Router Class Initialized
INFO - 2021-07-14 07:40:37 --> Output Class Initialized
INFO - 2021-07-14 07:40:37 --> Security Class Initialized
DEBUG - 2021-07-14 07:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:40:37 --> Input Class Initialized
INFO - 2021-07-14 07:40:37 --> Language Class Initialized
INFO - 2021-07-14 07:40:37 --> Loader Class Initialized
INFO - 2021-07-14 07:40:37 --> Helper loaded: html_helper
INFO - 2021-07-14 07:40:37 --> Helper loaded: url_helper
INFO - 2021-07-14 07:40:37 --> Helper loaded: form_helper
INFO - 2021-07-14 07:40:37 --> Database Driver Class Initialized
INFO - 2021-07-14 07:40:37 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:40:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:40:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:40:37 --> Encryption Class Initialized
INFO - 2021-07-14 07:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:40:37 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:40:37 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:40:37 --> Model "user_model" initialized
INFO - 2021-07-14 07:40:37 --> Model "role_model" initialized
INFO - 2021-07-14 07:40:37 --> Controller Class Initialized
INFO - 2021-07-14 07:40:37 --> Helper loaded: language_helper
INFO - 2021-07-14 07:40:37 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:40:37 --> Model "Customer_model" initialized
INFO - 2021-07-14 07:40:37 --> Final output sent to browser
DEBUG - 2021-07-14 07:40:37 --> Total execution time: 0.0534
INFO - 2021-07-14 07:40:37 --> Config Class Initialized
INFO - 2021-07-14 07:40:37 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:40:37 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:40:37 --> Utf8 Class Initialized
INFO - 2021-07-14 07:40:37 --> URI Class Initialized
INFO - 2021-07-14 07:40:37 --> Router Class Initialized
INFO - 2021-07-14 07:40:37 --> Output Class Initialized
INFO - 2021-07-14 07:40:37 --> Security Class Initialized
DEBUG - 2021-07-14 07:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:40:37 --> Input Class Initialized
INFO - 2021-07-14 07:40:37 --> Language Class Initialized
INFO - 2021-07-14 07:40:37 --> Loader Class Initialized
INFO - 2021-07-14 07:40:37 --> Helper loaded: html_helper
INFO - 2021-07-14 07:40:37 --> Helper loaded: url_helper
INFO - 2021-07-14 07:40:37 --> Helper loaded: form_helper
INFO - 2021-07-14 07:40:37 --> Database Driver Class Initialized
INFO - 2021-07-14 07:40:38 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:40:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:40:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:40:38 --> Encryption Class Initialized
INFO - 2021-07-14 07:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:40:38 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:40:38 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:40:38 --> Model "user_model" initialized
INFO - 2021-07-14 07:40:38 --> Model "role_model" initialized
INFO - 2021-07-14 07:40:38 --> Controller Class Initialized
INFO - 2021-07-14 07:40:38 --> Helper loaded: language_helper
INFO - 2021-07-14 07:40:38 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:40:38 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 07:40:38 --> Final output sent to browser
DEBUG - 2021-07-14 07:40:38 --> Total execution time: 0.0606
INFO - 2021-07-14 07:41:01 --> Config Class Initialized
INFO - 2021-07-14 07:41:01 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:41:01 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:41:01 --> Utf8 Class Initialized
INFO - 2021-07-14 07:41:01 --> URI Class Initialized
INFO - 2021-07-14 07:41:01 --> Router Class Initialized
INFO - 2021-07-14 07:41:01 --> Output Class Initialized
INFO - 2021-07-14 07:41:01 --> Security Class Initialized
DEBUG - 2021-07-14 07:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:41:01 --> Input Class Initialized
INFO - 2021-07-14 07:41:01 --> Language Class Initialized
INFO - 2021-07-14 07:41:01 --> Loader Class Initialized
INFO - 2021-07-14 07:41:01 --> Helper loaded: html_helper
INFO - 2021-07-14 07:41:01 --> Helper loaded: url_helper
INFO - 2021-07-14 07:41:01 --> Helper loaded: form_helper
INFO - 2021-07-14 07:41:01 --> Database Driver Class Initialized
INFO - 2021-07-14 07:41:01 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:41:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:41:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:41:01 --> Encryption Class Initialized
INFO - 2021-07-14 07:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:41:01 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:41:01 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:41:01 --> Model "user_model" initialized
INFO - 2021-07-14 07:41:01 --> Model "role_model" initialized
INFO - 2021-07-14 07:41:01 --> Controller Class Initialized
INFO - 2021-07-14 07:41:01 --> Helper loaded: language_helper
INFO - 2021-07-14 07:41:01 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:41:01 --> Model "Product_model" initialized
INFO - 2021-07-14 07:41:01 --> Final output sent to browser
DEBUG - 2021-07-14 07:41:01 --> Total execution time: 0.0603
INFO - 2021-07-14 07:41:13 --> Config Class Initialized
INFO - 2021-07-14 07:41:13 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:41:13 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:41:13 --> Utf8 Class Initialized
INFO - 2021-07-14 07:41:13 --> URI Class Initialized
INFO - 2021-07-14 07:41:13 --> Router Class Initialized
INFO - 2021-07-14 07:41:13 --> Output Class Initialized
INFO - 2021-07-14 07:41:13 --> Security Class Initialized
DEBUG - 2021-07-14 07:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:41:13 --> Input Class Initialized
INFO - 2021-07-14 07:41:13 --> Language Class Initialized
INFO - 2021-07-14 07:41:13 --> Loader Class Initialized
INFO - 2021-07-14 07:41:14 --> Helper loaded: html_helper
INFO - 2021-07-14 07:41:14 --> Helper loaded: url_helper
INFO - 2021-07-14 07:41:14 --> Helper loaded: form_helper
INFO - 2021-07-14 07:41:14 --> Database Driver Class Initialized
INFO - 2021-07-14 07:41:14 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:41:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:41:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:41:14 --> Encryption Class Initialized
INFO - 2021-07-14 07:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:41:14 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:41:14 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:41:14 --> Model "user_model" initialized
INFO - 2021-07-14 07:41:14 --> Model "role_model" initialized
INFO - 2021-07-14 07:41:14 --> Controller Class Initialized
INFO - 2021-07-14 07:41:14 --> Helper loaded: language_helper
INFO - 2021-07-14 07:41:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:41:14 --> Model "Product_model" initialized
INFO - 2021-07-14 07:41:14 --> Final output sent to browser
DEBUG - 2021-07-14 07:41:14 --> Total execution time: 0.0572
INFO - 2021-07-14 07:45:14 --> Config Class Initialized
INFO - 2021-07-14 07:45:14 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:45:14 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:45:14 --> Utf8 Class Initialized
INFO - 2021-07-14 07:45:14 --> URI Class Initialized
INFO - 2021-07-14 07:45:14 --> Router Class Initialized
INFO - 2021-07-14 07:45:14 --> Output Class Initialized
INFO - 2021-07-14 07:45:14 --> Security Class Initialized
DEBUG - 2021-07-14 07:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:45:14 --> Input Class Initialized
INFO - 2021-07-14 07:45:14 --> Language Class Initialized
INFO - 2021-07-14 07:45:14 --> Loader Class Initialized
INFO - 2021-07-14 07:45:14 --> Helper loaded: html_helper
INFO - 2021-07-14 07:45:14 --> Helper loaded: url_helper
INFO - 2021-07-14 07:45:14 --> Helper loaded: form_helper
INFO - 2021-07-14 07:45:14 --> Database Driver Class Initialized
INFO - 2021-07-14 07:45:14 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:45:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:45:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:45:14 --> Encryption Class Initialized
INFO - 2021-07-14 07:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:45:14 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:45:14 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:45:14 --> Model "user_model" initialized
INFO - 2021-07-14 07:45:14 --> Model "role_model" initialized
INFO - 2021-07-14 07:45:14 --> Controller Class Initialized
INFO - 2021-07-14 07:45:14 --> Helper loaded: language_helper
INFO - 2021-07-14 07:45:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:45:14 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:45:14 --> Final output sent to browser
DEBUG - 2021-07-14 07:45:14 --> Total execution time: 0.0701
INFO - 2021-07-14 07:45:15 --> Config Class Initialized
INFO - 2021-07-14 07:45:15 --> Hooks Class Initialized
INFO - 2021-07-14 07:45:15 --> Config Class Initialized
INFO - 2021-07-14 07:45:15 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:45:15 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:45:15 --> Utf8 Class Initialized
DEBUG - 2021-07-14 07:45:15 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:45:15 --> Utf8 Class Initialized
INFO - 2021-07-14 07:45:15 --> URI Class Initialized
INFO - 2021-07-14 07:45:15 --> URI Class Initialized
INFO - 2021-07-14 07:45:15 --> Router Class Initialized
INFO - 2021-07-14 07:45:15 --> Router Class Initialized
INFO - 2021-07-14 07:45:15 --> Output Class Initialized
INFO - 2021-07-14 07:45:15 --> Security Class Initialized
INFO - 2021-07-14 07:45:15 --> Output Class Initialized
DEBUG - 2021-07-14 07:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:45:15 --> Input Class Initialized
INFO - 2021-07-14 07:45:15 --> Security Class Initialized
INFO - 2021-07-14 07:45:15 --> Language Class Initialized
DEBUG - 2021-07-14 07:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:45:15 --> Input Class Initialized
INFO - 2021-07-14 07:45:15 --> Language Class Initialized
INFO - 2021-07-14 07:45:15 --> Loader Class Initialized
INFO - 2021-07-14 07:45:15 --> Loader Class Initialized
INFO - 2021-07-14 07:45:15 --> Helper loaded: html_helper
INFO - 2021-07-14 07:45:15 --> Helper loaded: url_helper
INFO - 2021-07-14 07:45:15 --> Helper loaded: html_helper
INFO - 2021-07-14 07:45:15 --> Helper loaded: url_helper
INFO - 2021-07-14 07:45:15 --> Helper loaded: form_helper
INFO - 2021-07-14 07:45:15 --> Helper loaded: form_helper
INFO - 2021-07-14 07:45:15 --> Database Driver Class Initialized
INFO - 2021-07-14 07:45:15 --> Database Driver Class Initialized
INFO - 2021-07-14 07:45:15 --> Form Validation Class Initialized
INFO - 2021-07-14 07:45:15 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:45:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:45:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:45:15 --> Encryption Class Initialized
DEBUG - 2021-07-14 07:45:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:45:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:45:15 --> Encryption Class Initialized
INFO - 2021-07-14 07:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:45:15 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:45:15 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:45:15 --> Model "user_model" initialized
INFO - 2021-07-14 07:45:15 --> Model "role_model" initialized
INFO - 2021-07-14 07:45:15 --> Controller Class Initialized
INFO - 2021-07-14 07:45:15 --> Helper loaded: language_helper
INFO - 2021-07-14 07:45:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:45:15 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:45:15 --> Final output sent to browser
DEBUG - 2021-07-14 07:45:15 --> Total execution time: 0.0692
INFO - 2021-07-14 07:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:45:15 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:45:15 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:45:15 --> Model "user_model" initialized
INFO - 2021-07-14 07:45:15 --> Model "role_model" initialized
INFO - 2021-07-14 07:45:15 --> Controller Class Initialized
INFO - 2021-07-14 07:45:15 --> Helper loaded: language_helper
INFO - 2021-07-14 07:45:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:45:15 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:45:15 --> Final output sent to browser
DEBUG - 2021-07-14 07:45:15 --> Total execution time: 0.0810
INFO - 2021-07-14 07:45:17 --> Config Class Initialized
INFO - 2021-07-14 07:45:17 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:45:17 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:45:17 --> Utf8 Class Initialized
INFO - 2021-07-14 07:45:17 --> URI Class Initialized
INFO - 2021-07-14 07:45:17 --> Router Class Initialized
INFO - 2021-07-14 07:45:17 --> Output Class Initialized
INFO - 2021-07-14 07:45:17 --> Security Class Initialized
DEBUG - 2021-07-14 07:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:45:17 --> Input Class Initialized
INFO - 2021-07-14 07:45:17 --> Language Class Initialized
INFO - 2021-07-14 07:45:17 --> Loader Class Initialized
INFO - 2021-07-14 07:45:17 --> Helper loaded: html_helper
INFO - 2021-07-14 07:45:17 --> Helper loaded: url_helper
INFO - 2021-07-14 07:45:17 --> Helper loaded: form_helper
INFO - 2021-07-14 07:45:17 --> Database Driver Class Initialized
INFO - 2021-07-14 07:45:17 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:45:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:45:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:45:17 --> Encryption Class Initialized
INFO - 2021-07-14 07:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:45:17 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:45:17 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:45:17 --> Model "user_model" initialized
INFO - 2021-07-14 07:45:17 --> Model "role_model" initialized
INFO - 2021-07-14 07:45:17 --> Controller Class Initialized
INFO - 2021-07-14 07:45:17 --> Helper loaded: language_helper
INFO - 2021-07-14 07:45:17 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:45:17 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:45:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:45:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:45:17 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:45:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:45:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:45:17 --> Final output sent to browser
DEBUG - 2021-07-14 07:45:17 --> Total execution time: 0.0720
INFO - 2021-07-14 07:45:17 --> Config Class Initialized
INFO - 2021-07-14 07:45:17 --> Config Class Initialized
INFO - 2021-07-14 07:45:17 --> Hooks Class Initialized
INFO - 2021-07-14 07:45:17 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:45:17 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 07:45:17 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:45:17 --> Utf8 Class Initialized
INFO - 2021-07-14 07:45:17 --> Utf8 Class Initialized
INFO - 2021-07-14 07:45:17 --> URI Class Initialized
INFO - 2021-07-14 07:45:17 --> URI Class Initialized
INFO - 2021-07-14 07:45:17 --> Router Class Initialized
INFO - 2021-07-14 07:45:17 --> Router Class Initialized
INFO - 2021-07-14 07:45:17 --> Output Class Initialized
INFO - 2021-07-14 07:45:17 --> Output Class Initialized
INFO - 2021-07-14 07:45:17 --> Security Class Initialized
DEBUG - 2021-07-14 07:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:45:17 --> Security Class Initialized
INFO - 2021-07-14 07:45:17 --> Input Class Initialized
INFO - 2021-07-14 07:45:17 --> Language Class Initialized
DEBUG - 2021-07-14 07:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:45:17 --> Input Class Initialized
INFO - 2021-07-14 07:45:17 --> Language Class Initialized
INFO - 2021-07-14 07:45:17 --> Loader Class Initialized
INFO - 2021-07-14 07:45:17 --> Helper loaded: html_helper
INFO - 2021-07-14 07:45:17 --> Loader Class Initialized
INFO - 2021-07-14 07:45:17 --> Helper loaded: url_helper
INFO - 2021-07-14 07:45:17 --> Helper loaded: html_helper
INFO - 2021-07-14 07:45:17 --> Helper loaded: form_helper
INFO - 2021-07-14 07:45:17 --> Helper loaded: url_helper
INFO - 2021-07-14 07:45:17 --> Helper loaded: form_helper
INFO - 2021-07-14 07:45:17 --> Database Driver Class Initialized
INFO - 2021-07-14 07:45:17 --> Database Driver Class Initialized
INFO - 2021-07-14 07:45:17 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:45:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:45:17 --> Form Validation Class Initialized
INFO - 2021-07-14 07:45:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:45:17 --> Encryption Class Initialized
DEBUG - 2021-07-14 07:45:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:45:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:45:17 --> Encryption Class Initialized
INFO - 2021-07-14 07:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:45:17 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:45:17 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:45:17 --> Model "user_model" initialized
INFO - 2021-07-14 07:45:17 --> Model "role_model" initialized
INFO - 2021-07-14 07:45:17 --> Controller Class Initialized
INFO - 2021-07-14 07:45:17 --> Helper loaded: language_helper
INFO - 2021-07-14 07:45:17 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:45:17 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:45:17 --> Final output sent to browser
DEBUG - 2021-07-14 07:45:17 --> Total execution time: 0.1062
INFO - 2021-07-14 07:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:45:17 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:45:17 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:45:17 --> Model "user_model" initialized
INFO - 2021-07-14 07:45:17 --> Model "role_model" initialized
INFO - 2021-07-14 07:45:17 --> Controller Class Initialized
INFO - 2021-07-14 07:45:17 --> Helper loaded: language_helper
INFO - 2021-07-14 07:45:17 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:45:17 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:45:17 --> Final output sent to browser
DEBUG - 2021-07-14 07:45:17 --> Total execution time: 0.1166
INFO - 2021-07-14 07:48:10 --> Config Class Initialized
INFO - 2021-07-14 07:48:10 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:48:10 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:48:10 --> Utf8 Class Initialized
INFO - 2021-07-14 07:48:10 --> URI Class Initialized
INFO - 2021-07-14 07:48:10 --> Router Class Initialized
INFO - 2021-07-14 07:48:10 --> Output Class Initialized
INFO - 2021-07-14 07:48:10 --> Security Class Initialized
DEBUG - 2021-07-14 07:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:48:10 --> Input Class Initialized
INFO - 2021-07-14 07:48:10 --> Language Class Initialized
INFO - 2021-07-14 07:48:10 --> Loader Class Initialized
INFO - 2021-07-14 07:48:10 --> Helper loaded: html_helper
INFO - 2021-07-14 07:48:10 --> Helper loaded: url_helper
INFO - 2021-07-14 07:48:10 --> Helper loaded: form_helper
INFO - 2021-07-14 07:48:10 --> Database Driver Class Initialized
INFO - 2021-07-14 07:48:10 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:48:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:48:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:48:10 --> Encryption Class Initialized
INFO - 2021-07-14 07:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:48:10 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:48:10 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:48:10 --> Model "user_model" initialized
INFO - 2021-07-14 07:48:10 --> Model "role_model" initialized
INFO - 2021-07-14 07:48:10 --> Controller Class Initialized
INFO - 2021-07-14 07:48:10 --> Helper loaded: language_helper
INFO - 2021-07-14 07:48:10 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:48:10 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:48:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:48:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:48:10 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:48:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:48:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:48:10 --> Final output sent to browser
DEBUG - 2021-07-14 07:48:10 --> Total execution time: 0.1329
INFO - 2021-07-14 07:48:11 --> Config Class Initialized
INFO - 2021-07-14 07:48:11 --> Hooks Class Initialized
INFO - 2021-07-14 07:48:11 --> Config Class Initialized
INFO - 2021-07-14 07:48:11 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:48:11 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:48:11 --> Utf8 Class Initialized
INFO - 2021-07-14 07:48:11 --> URI Class Initialized
INFO - 2021-07-14 07:48:11 --> Router Class Initialized
INFO - 2021-07-14 07:48:11 --> Output Class Initialized
INFO - 2021-07-14 07:48:11 --> Security Class Initialized
DEBUG - 2021-07-14 07:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:48:11 --> Input Class Initialized
INFO - 2021-07-14 07:48:11 --> Language Class Initialized
DEBUG - 2021-07-14 07:48:11 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:48:11 --> Loader Class Initialized
INFO - 2021-07-14 07:48:11 --> Helper loaded: html_helper
INFO - 2021-07-14 07:48:11 --> Helper loaded: url_helper
INFO - 2021-07-14 07:48:11 --> Helper loaded: form_helper
INFO - 2021-07-14 07:48:11 --> Utf8 Class Initialized
INFO - 2021-07-14 07:48:11 --> URI Class Initialized
INFO - 2021-07-14 07:48:11 --> Database Driver Class Initialized
INFO - 2021-07-14 07:48:11 --> Router Class Initialized
INFO - 2021-07-14 07:48:11 --> Output Class Initialized
INFO - 2021-07-14 07:48:11 --> Security Class Initialized
DEBUG - 2021-07-14 07:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:48:11 --> Input Class Initialized
INFO - 2021-07-14 07:48:11 --> Language Class Initialized
INFO - 2021-07-14 07:48:11 --> Loader Class Initialized
INFO - 2021-07-14 07:48:11 --> Helper loaded: html_helper
INFO - 2021-07-14 07:48:11 --> Helper loaded: url_helper
INFO - 2021-07-14 07:48:11 --> Helper loaded: form_helper
INFO - 2021-07-14 07:48:11 --> Database Driver Class Initialized
INFO - 2021-07-14 07:48:11 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:48:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:48:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:48:11 --> Encryption Class Initialized
INFO - 2021-07-14 07:48:11 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:48:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:48:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:48:11 --> Encryption Class Initialized
INFO - 2021-07-14 07:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:48:11 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:48:11 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:48:11 --> Model "user_model" initialized
INFO - 2021-07-14 07:48:11 --> Model "role_model" initialized
INFO - 2021-07-14 07:48:11 --> Controller Class Initialized
INFO - 2021-07-14 07:48:11 --> Helper loaded: language_helper
INFO - 2021-07-14 07:48:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:48:11 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:48:11 --> Final output sent to browser
DEBUG - 2021-07-14 07:48:11 --> Total execution time: 0.0862
INFO - 2021-07-14 07:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:48:11 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:48:11 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:48:11 --> Model "user_model" initialized
INFO - 2021-07-14 07:48:11 --> Model "role_model" initialized
INFO - 2021-07-14 07:48:11 --> Controller Class Initialized
INFO - 2021-07-14 07:48:11 --> Helper loaded: language_helper
INFO - 2021-07-14 07:48:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:48:11 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:48:11 --> Final output sent to browser
DEBUG - 2021-07-14 07:48:11 --> Total execution time: 0.0981
INFO - 2021-07-14 07:48:59 --> Config Class Initialized
INFO - 2021-07-14 07:48:59 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:48:59 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:48:59 --> Utf8 Class Initialized
INFO - 2021-07-14 07:48:59 --> URI Class Initialized
INFO - 2021-07-14 07:48:59 --> Router Class Initialized
INFO - 2021-07-14 07:48:59 --> Output Class Initialized
INFO - 2021-07-14 07:48:59 --> Security Class Initialized
DEBUG - 2021-07-14 07:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:48:59 --> Input Class Initialized
INFO - 2021-07-14 07:48:59 --> Language Class Initialized
INFO - 2021-07-14 07:48:59 --> Loader Class Initialized
INFO - 2021-07-14 07:48:59 --> Helper loaded: html_helper
INFO - 2021-07-14 07:48:59 --> Helper loaded: url_helper
INFO - 2021-07-14 07:48:59 --> Helper loaded: form_helper
INFO - 2021-07-14 07:48:59 --> Database Driver Class Initialized
INFO - 2021-07-14 07:48:59 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:48:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:48:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:48:59 --> Encryption Class Initialized
INFO - 2021-07-14 07:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:48:59 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:48:59 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:48:59 --> Model "user_model" initialized
INFO - 2021-07-14 07:48:59 --> Model "role_model" initialized
INFO - 2021-07-14 07:48:59 --> Controller Class Initialized
INFO - 2021-07-14 07:48:59 --> Helper loaded: language_helper
INFO - 2021-07-14 07:48:59 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:48:59 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:48:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:48:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:48:59 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:48:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:48:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:48:59 --> Final output sent to browser
DEBUG - 2021-07-14 07:48:59 --> Total execution time: 0.1121
INFO - 2021-07-14 07:49:00 --> Config Class Initialized
INFO - 2021-07-14 07:49:00 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:49:00 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:49:00 --> Utf8 Class Initialized
INFO - 2021-07-14 07:49:00 --> URI Class Initialized
INFO - 2021-07-14 07:49:00 --> Router Class Initialized
INFO - 2021-07-14 07:49:00 --> Output Class Initialized
INFO - 2021-07-14 07:49:00 --> Security Class Initialized
DEBUG - 2021-07-14 07:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:49:00 --> Input Class Initialized
INFO - 2021-07-14 07:49:00 --> Language Class Initialized
INFO - 2021-07-14 07:49:00 --> Loader Class Initialized
INFO - 2021-07-14 07:49:00 --> Helper loaded: html_helper
INFO - 2021-07-14 07:49:00 --> Config Class Initialized
INFO - 2021-07-14 07:49:00 --> Hooks Class Initialized
INFO - 2021-07-14 07:49:00 --> Helper loaded: url_helper
INFO - 2021-07-14 07:49:00 --> Helper loaded: form_helper
DEBUG - 2021-07-14 07:49:00 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:49:00 --> Utf8 Class Initialized
INFO - 2021-07-14 07:49:00 --> URI Class Initialized
INFO - 2021-07-14 07:49:00 --> Router Class Initialized
INFO - 2021-07-14 07:49:00 --> Output Class Initialized
INFO - 2021-07-14 07:49:00 --> Security Class Initialized
DEBUG - 2021-07-14 07:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:49:00 --> Input Class Initialized
INFO - 2021-07-14 07:49:00 --> Language Class Initialized
INFO - 2021-07-14 07:49:00 --> Database Driver Class Initialized
INFO - 2021-07-14 07:49:00 --> Loader Class Initialized
INFO - 2021-07-14 07:49:00 --> Helper loaded: html_helper
INFO - 2021-07-14 07:49:00 --> Helper loaded: url_helper
INFO - 2021-07-14 07:49:00 --> Helper loaded: form_helper
INFO - 2021-07-14 07:49:00 --> Database Driver Class Initialized
INFO - 2021-07-14 07:49:00 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:49:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:49:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:49:00 --> Encryption Class Initialized
INFO - 2021-07-14 07:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:49:00 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:49:00 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:49:00 --> Model "user_model" initialized
INFO - 2021-07-14 07:49:00 --> Model "role_model" initialized
INFO - 2021-07-14 07:49:00 --> Controller Class Initialized
INFO - 2021-07-14 07:49:00 --> Helper loaded: language_helper
INFO - 2021-07-14 07:49:00 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:49:00 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:49:00 --> Final output sent to browser
DEBUG - 2021-07-14 07:49:00 --> Total execution time: 0.1004
INFO - 2021-07-14 07:49:00 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:49:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:49:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:49:00 --> Encryption Class Initialized
INFO - 2021-07-14 07:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:49:00 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:49:00 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:49:00 --> Model "user_model" initialized
INFO - 2021-07-14 07:49:00 --> Model "role_model" initialized
INFO - 2021-07-14 07:49:00 --> Controller Class Initialized
INFO - 2021-07-14 07:49:00 --> Helper loaded: language_helper
INFO - 2021-07-14 07:49:00 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:49:00 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:49:00 --> Final output sent to browser
DEBUG - 2021-07-14 07:49:00 --> Total execution time: 0.1219
INFO - 2021-07-14 07:49:37 --> Config Class Initialized
INFO - 2021-07-14 07:49:37 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:49:37 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:49:37 --> Utf8 Class Initialized
INFO - 2021-07-14 07:49:37 --> URI Class Initialized
INFO - 2021-07-14 07:49:37 --> Router Class Initialized
INFO - 2021-07-14 07:49:37 --> Output Class Initialized
INFO - 2021-07-14 07:49:37 --> Security Class Initialized
DEBUG - 2021-07-14 07:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:49:37 --> Input Class Initialized
INFO - 2021-07-14 07:49:37 --> Language Class Initialized
INFO - 2021-07-14 07:49:37 --> Loader Class Initialized
INFO - 2021-07-14 07:49:37 --> Helper loaded: html_helper
INFO - 2021-07-14 07:49:37 --> Helper loaded: url_helper
INFO - 2021-07-14 07:49:37 --> Helper loaded: form_helper
INFO - 2021-07-14 07:49:37 --> Database Driver Class Initialized
INFO - 2021-07-14 07:49:37 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:49:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:49:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:49:37 --> Encryption Class Initialized
INFO - 2021-07-14 07:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:49:37 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:49:37 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:49:37 --> Model "user_model" initialized
INFO - 2021-07-14 07:49:37 --> Model "role_model" initialized
INFO - 2021-07-14 07:49:37 --> Controller Class Initialized
INFO - 2021-07-14 07:49:37 --> Helper loaded: language_helper
INFO - 2021-07-14 07:49:37 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:49:37 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:49:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:49:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:49:37 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:49:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:49:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:49:37 --> Final output sent to browser
DEBUG - 2021-07-14 07:49:37 --> Total execution time: 0.1125
INFO - 2021-07-14 07:49:51 --> Config Class Initialized
INFO - 2021-07-14 07:49:51 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:49:51 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:49:51 --> Utf8 Class Initialized
INFO - 2021-07-14 07:49:51 --> URI Class Initialized
INFO - 2021-07-14 07:49:51 --> Router Class Initialized
INFO - 2021-07-14 07:49:51 --> Output Class Initialized
INFO - 2021-07-14 07:49:51 --> Security Class Initialized
DEBUG - 2021-07-14 07:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:49:51 --> Input Class Initialized
INFO - 2021-07-14 07:49:51 --> Language Class Initialized
INFO - 2021-07-14 07:49:51 --> Loader Class Initialized
INFO - 2021-07-14 07:49:51 --> Helper loaded: html_helper
INFO - 2021-07-14 07:49:51 --> Helper loaded: url_helper
INFO - 2021-07-14 07:49:51 --> Helper loaded: form_helper
INFO - 2021-07-14 07:49:51 --> Database Driver Class Initialized
INFO - 2021-07-14 07:49:51 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:49:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:49:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:49:51 --> Encryption Class Initialized
INFO - 2021-07-14 07:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:49:51 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:49:51 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:49:51 --> Model "user_model" initialized
INFO - 2021-07-14 07:49:51 --> Model "role_model" initialized
INFO - 2021-07-14 07:49:51 --> Controller Class Initialized
INFO - 2021-07-14 07:49:51 --> Helper loaded: language_helper
INFO - 2021-07-14 07:49:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:49:51 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:49:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:49:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:49:51 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:49:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:49:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:49:51 --> Final output sent to browser
DEBUG - 2021-07-14 07:49:51 --> Total execution time: 0.1113
INFO - 2021-07-14 07:49:52 --> Config Class Initialized
INFO - 2021-07-14 07:49:52 --> Hooks Class Initialized
INFO - 2021-07-14 07:49:52 --> Config Class Initialized
INFO - 2021-07-14 07:49:52 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:49:52 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 07:49:52 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:49:52 --> Utf8 Class Initialized
INFO - 2021-07-14 07:49:52 --> Utf8 Class Initialized
INFO - 2021-07-14 07:49:52 --> URI Class Initialized
INFO - 2021-07-14 07:49:52 --> URI Class Initialized
INFO - 2021-07-14 07:49:52 --> Router Class Initialized
INFO - 2021-07-14 07:49:52 --> Router Class Initialized
INFO - 2021-07-14 07:49:52 --> Output Class Initialized
INFO - 2021-07-14 07:49:52 --> Output Class Initialized
INFO - 2021-07-14 07:49:52 --> Security Class Initialized
INFO - 2021-07-14 07:49:52 --> Security Class Initialized
DEBUG - 2021-07-14 07:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 07:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:49:52 --> Input Class Initialized
INFO - 2021-07-14 07:49:52 --> Input Class Initialized
INFO - 2021-07-14 07:49:52 --> Language Class Initialized
INFO - 2021-07-14 07:49:52 --> Language Class Initialized
INFO - 2021-07-14 07:49:52 --> Loader Class Initialized
INFO - 2021-07-14 07:49:52 --> Helper loaded: html_helper
INFO - 2021-07-14 07:49:52 --> Loader Class Initialized
INFO - 2021-07-14 07:49:52 --> Helper loaded: url_helper
INFO - 2021-07-14 07:49:52 --> Helper loaded: html_helper
INFO - 2021-07-14 07:49:52 --> Helper loaded: form_helper
INFO - 2021-07-14 07:49:52 --> Helper loaded: url_helper
INFO - 2021-07-14 07:49:52 --> Helper loaded: form_helper
INFO - 2021-07-14 07:49:52 --> Database Driver Class Initialized
INFO - 2021-07-14 07:49:52 --> Database Driver Class Initialized
INFO - 2021-07-14 07:49:52 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:49:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:49:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:49:52 --> Encryption Class Initialized
INFO - 2021-07-14 07:49:52 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:49:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:49:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:49:52 --> Encryption Class Initialized
INFO - 2021-07-14 07:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:49:52 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:49:52 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:49:52 --> Model "user_model" initialized
INFO - 2021-07-14 07:49:52 --> Model "role_model" initialized
INFO - 2021-07-14 07:49:52 --> Controller Class Initialized
INFO - 2021-07-14 07:49:52 --> Helper loaded: language_helper
INFO - 2021-07-14 07:49:52 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:49:52 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:49:52 --> Final output sent to browser
DEBUG - 2021-07-14 07:49:52 --> Total execution time: 0.0732
INFO - 2021-07-14 07:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:49:52 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:49:52 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:49:52 --> Model "user_model" initialized
INFO - 2021-07-14 07:49:52 --> Model "role_model" initialized
INFO - 2021-07-14 07:49:52 --> Controller Class Initialized
INFO - 2021-07-14 07:49:52 --> Helper loaded: language_helper
INFO - 2021-07-14 07:49:52 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:49:52 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:49:52 --> Final output sent to browser
DEBUG - 2021-07-14 07:49:52 --> Total execution time: 0.0845
INFO - 2021-07-14 07:51:08 --> Config Class Initialized
INFO - 2021-07-14 07:51:08 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:51:08 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:51:08 --> Utf8 Class Initialized
INFO - 2021-07-14 07:51:08 --> URI Class Initialized
INFO - 2021-07-14 07:51:08 --> Router Class Initialized
INFO - 2021-07-14 07:51:08 --> Output Class Initialized
INFO - 2021-07-14 07:51:08 --> Security Class Initialized
DEBUG - 2021-07-14 07:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:51:08 --> Input Class Initialized
INFO - 2021-07-14 07:51:08 --> Language Class Initialized
INFO - 2021-07-14 07:51:08 --> Loader Class Initialized
INFO - 2021-07-14 07:51:08 --> Helper loaded: html_helper
INFO - 2021-07-14 07:51:08 --> Helper loaded: url_helper
INFO - 2021-07-14 07:51:08 --> Helper loaded: form_helper
INFO - 2021-07-14 07:51:08 --> Database Driver Class Initialized
INFO - 2021-07-14 07:51:08 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:51:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:51:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:51:08 --> Encryption Class Initialized
INFO - 2021-07-14 07:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:51:08 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:51:08 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:51:08 --> Model "user_model" initialized
INFO - 2021-07-14 07:51:08 --> Model "role_model" initialized
INFO - 2021-07-14 07:51:08 --> Controller Class Initialized
INFO - 2021-07-14 07:51:08 --> Helper loaded: language_helper
INFO - 2021-07-14 07:51:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:51:08 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:51:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:51:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:51:08 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:51:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:51:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:51:08 --> Final output sent to browser
DEBUG - 2021-07-14 07:51:08 --> Total execution time: 0.1143
INFO - 2021-07-14 07:51:09 --> Config Class Initialized
INFO - 2021-07-14 07:51:09 --> Hooks Class Initialized
INFO - 2021-07-14 07:51:09 --> Config Class Initialized
INFO - 2021-07-14 07:51:09 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:51:09 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:51:09 --> Utf8 Class Initialized
INFO - 2021-07-14 07:51:09 --> URI Class Initialized
DEBUG - 2021-07-14 07:51:09 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:51:09 --> Utf8 Class Initialized
INFO - 2021-07-14 07:51:09 --> Router Class Initialized
INFO - 2021-07-14 07:51:09 --> URI Class Initialized
INFO - 2021-07-14 07:51:09 --> Output Class Initialized
INFO - 2021-07-14 07:51:09 --> Router Class Initialized
INFO - 2021-07-14 07:51:09 --> Security Class Initialized
INFO - 2021-07-14 07:51:09 --> Output Class Initialized
DEBUG - 2021-07-14 07:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:51:09 --> Input Class Initialized
INFO - 2021-07-14 07:51:09 --> Security Class Initialized
INFO - 2021-07-14 07:51:09 --> Language Class Initialized
DEBUG - 2021-07-14 07:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:51:09 --> Input Class Initialized
INFO - 2021-07-14 07:51:09 --> Language Class Initialized
INFO - 2021-07-14 07:51:09 --> Loader Class Initialized
INFO - 2021-07-14 07:51:09 --> Helper loaded: html_helper
INFO - 2021-07-14 07:51:09 --> Loader Class Initialized
INFO - 2021-07-14 07:51:09 --> Helper loaded: url_helper
INFO - 2021-07-14 07:51:09 --> Helper loaded: html_helper
INFO - 2021-07-14 07:51:09 --> Helper loaded: form_helper
INFO - 2021-07-14 07:51:09 --> Helper loaded: url_helper
INFO - 2021-07-14 07:51:09 --> Helper loaded: form_helper
INFO - 2021-07-14 07:51:09 --> Database Driver Class Initialized
INFO - 2021-07-14 07:51:09 --> Database Driver Class Initialized
INFO - 2021-07-14 07:51:09 --> Form Validation Class Initialized
INFO - 2021-07-14 07:51:09 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:51:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:51:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:51:09 --> Encryption Class Initialized
DEBUG - 2021-07-14 07:51:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:51:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:51:09 --> Encryption Class Initialized
INFO - 2021-07-14 07:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:51:09 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:51:09 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:51:09 --> Model "user_model" initialized
INFO - 2021-07-14 07:51:09 --> Model "role_model" initialized
INFO - 2021-07-14 07:51:09 --> Controller Class Initialized
INFO - 2021-07-14 07:51:09 --> Helper loaded: language_helper
INFO - 2021-07-14 07:51:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:51:09 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:51:09 --> Final output sent to browser
DEBUG - 2021-07-14 07:51:09 --> Total execution time: 0.0681
INFO - 2021-07-14 07:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:51:09 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:51:09 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:51:09 --> Model "user_model" initialized
INFO - 2021-07-14 07:51:09 --> Model "role_model" initialized
INFO - 2021-07-14 07:51:09 --> Controller Class Initialized
INFO - 2021-07-14 07:51:09 --> Helper loaded: language_helper
INFO - 2021-07-14 07:51:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:51:09 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:51:09 --> Final output sent to browser
DEBUG - 2021-07-14 07:51:09 --> Total execution time: 0.0805
INFO - 2021-07-14 07:55:47 --> Config Class Initialized
INFO - 2021-07-14 07:55:47 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:55:47 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:55:47 --> Utf8 Class Initialized
INFO - 2021-07-14 07:55:47 --> URI Class Initialized
INFO - 2021-07-14 07:55:47 --> Router Class Initialized
INFO - 2021-07-14 07:55:47 --> Output Class Initialized
INFO - 2021-07-14 07:55:47 --> Security Class Initialized
DEBUG - 2021-07-14 07:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:55:47 --> Input Class Initialized
INFO - 2021-07-14 07:55:47 --> Language Class Initialized
INFO - 2021-07-14 07:55:47 --> Loader Class Initialized
INFO - 2021-07-14 07:55:47 --> Helper loaded: html_helper
INFO - 2021-07-14 07:55:47 --> Helper loaded: url_helper
INFO - 2021-07-14 07:55:47 --> Helper loaded: form_helper
INFO - 2021-07-14 07:55:47 --> Database Driver Class Initialized
INFO - 2021-07-14 07:55:47 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:55:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:55:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:55:47 --> Encryption Class Initialized
INFO - 2021-07-14 07:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:55:47 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:55:47 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:55:47 --> Model "user_model" initialized
INFO - 2021-07-14 07:55:47 --> Model "role_model" initialized
INFO - 2021-07-14 07:55:47 --> Controller Class Initialized
INFO - 2021-07-14 07:55:47 --> Helper loaded: language_helper
INFO - 2021-07-14 07:55:47 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:55:47 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:55:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:55:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:55:47 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:55:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:55:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:55:47 --> Final output sent to browser
DEBUG - 2021-07-14 07:55:47 --> Total execution time: 0.1072
INFO - 2021-07-14 07:55:47 --> Config Class Initialized
INFO - 2021-07-14 07:55:47 --> Config Class Initialized
INFO - 2021-07-14 07:55:47 --> Hooks Class Initialized
INFO - 2021-07-14 07:55:47 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:55:47 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:55:47 --> Utf8 Class Initialized
INFO - 2021-07-14 07:55:47 --> URI Class Initialized
INFO - 2021-07-14 07:55:47 --> Router Class Initialized
INFO - 2021-07-14 07:55:47 --> Output Class Initialized
INFO - 2021-07-14 07:55:47 --> Security Class Initialized
DEBUG - 2021-07-14 07:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:55:47 --> Input Class Initialized
INFO - 2021-07-14 07:55:47 --> Language Class Initialized
INFO - 2021-07-14 07:55:47 --> Loader Class Initialized
INFO - 2021-07-14 07:55:47 --> Helper loaded: html_helper
INFO - 2021-07-14 07:55:47 --> Helper loaded: url_helper
DEBUG - 2021-07-14 07:55:47 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:55:47 --> Utf8 Class Initialized
INFO - 2021-07-14 07:55:47 --> Helper loaded: form_helper
INFO - 2021-07-14 07:55:47 --> URI Class Initialized
INFO - 2021-07-14 07:55:47 --> Router Class Initialized
INFO - 2021-07-14 07:55:47 --> Output Class Initialized
INFO - 2021-07-14 07:55:47 --> Security Class Initialized
DEBUG - 2021-07-14 07:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:55:47 --> Input Class Initialized
INFO - 2021-07-14 07:55:47 --> Language Class Initialized
INFO - 2021-07-14 07:55:47 --> Database Driver Class Initialized
INFO - 2021-07-14 07:55:47 --> Loader Class Initialized
INFO - 2021-07-14 07:55:47 --> Helper loaded: html_helper
INFO - 2021-07-14 07:55:47 --> Helper loaded: url_helper
INFO - 2021-07-14 07:55:47 --> Helper loaded: form_helper
INFO - 2021-07-14 07:55:47 --> Database Driver Class Initialized
INFO - 2021-07-14 07:55:47 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:55:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:55:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:55:47 --> Encryption Class Initialized
INFO - 2021-07-14 07:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:55:48 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:55:48 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:55:48 --> Model "user_model" initialized
INFO - 2021-07-14 07:55:48 --> Model "role_model" initialized
INFO - 2021-07-14 07:55:48 --> Controller Class Initialized
INFO - 2021-07-14 07:55:48 --> Helper loaded: language_helper
INFO - 2021-07-14 07:55:48 --> Form Validation Class Initialized
INFO - 2021-07-14 07:55:48 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:55:48 --> Model "Quotation_model" initialized
DEBUG - 2021-07-14 07:55:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:55:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:55:48 --> Encryption Class Initialized
INFO - 2021-07-14 07:55:48 --> Final output sent to browser
DEBUG - 2021-07-14 07:55:48 --> Total execution time: 0.0906
INFO - 2021-07-14 07:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:55:48 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:55:48 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:55:48 --> Model "user_model" initialized
INFO - 2021-07-14 07:55:48 --> Model "role_model" initialized
INFO - 2021-07-14 07:55:48 --> Controller Class Initialized
INFO - 2021-07-14 07:55:48 --> Helper loaded: language_helper
INFO - 2021-07-14 07:55:48 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:55:48 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:55:48 --> Final output sent to browser
DEBUG - 2021-07-14 07:55:48 --> Total execution time: 0.1048
INFO - 2021-07-14 07:56:25 --> Config Class Initialized
INFO - 2021-07-14 07:56:25 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:56:25 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:56:25 --> Utf8 Class Initialized
INFO - 2021-07-14 07:56:25 --> URI Class Initialized
INFO - 2021-07-14 07:56:25 --> Router Class Initialized
INFO - 2021-07-14 07:56:25 --> Output Class Initialized
INFO - 2021-07-14 07:56:25 --> Security Class Initialized
DEBUG - 2021-07-14 07:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:56:25 --> Input Class Initialized
INFO - 2021-07-14 07:56:25 --> Language Class Initialized
INFO - 2021-07-14 07:56:25 --> Loader Class Initialized
INFO - 2021-07-14 07:56:25 --> Helper loaded: html_helper
INFO - 2021-07-14 07:56:25 --> Helper loaded: url_helper
INFO - 2021-07-14 07:56:25 --> Helper loaded: form_helper
INFO - 2021-07-14 07:56:25 --> Database Driver Class Initialized
INFO - 2021-07-14 07:56:25 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:56:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:56:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:56:25 --> Encryption Class Initialized
INFO - 2021-07-14 07:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:56:25 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:56:25 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:56:25 --> Model "user_model" initialized
INFO - 2021-07-14 07:56:25 --> Model "role_model" initialized
INFO - 2021-07-14 07:56:25 --> Controller Class Initialized
INFO - 2021-07-14 07:56:25 --> Helper loaded: language_helper
INFO - 2021-07-14 07:56:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:56:25 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:56:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:56:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:56:25 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:56:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:56:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:56:25 --> Final output sent to browser
DEBUG - 2021-07-14 07:56:25 --> Total execution time: 0.1171
INFO - 2021-07-14 07:56:26 --> Config Class Initialized
INFO - 2021-07-14 07:56:26 --> Hooks Class Initialized
INFO - 2021-07-14 07:56:26 --> Config Class Initialized
INFO - 2021-07-14 07:56:26 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:56:26 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:56:26 --> Utf8 Class Initialized
DEBUG - 2021-07-14 07:56:26 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:56:26 --> Utf8 Class Initialized
INFO - 2021-07-14 07:56:26 --> URI Class Initialized
INFO - 2021-07-14 07:56:26 --> URI Class Initialized
INFO - 2021-07-14 07:56:26 --> Router Class Initialized
INFO - 2021-07-14 07:56:26 --> Router Class Initialized
INFO - 2021-07-14 07:56:26 --> Output Class Initialized
INFO - 2021-07-14 07:56:26 --> Output Class Initialized
INFO - 2021-07-14 07:56:26 --> Security Class Initialized
DEBUG - 2021-07-14 07:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:56:26 --> Security Class Initialized
INFO - 2021-07-14 07:56:26 --> Input Class Initialized
INFO - 2021-07-14 07:56:26 --> Language Class Initialized
DEBUG - 2021-07-14 07:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:56:26 --> Input Class Initialized
INFO - 2021-07-14 07:56:26 --> Language Class Initialized
INFO - 2021-07-14 07:56:26 --> Loader Class Initialized
INFO - 2021-07-14 07:56:26 --> Helper loaded: html_helper
INFO - 2021-07-14 07:56:26 --> Loader Class Initialized
INFO - 2021-07-14 07:56:26 --> Helper loaded: url_helper
INFO - 2021-07-14 07:56:26 --> Helper loaded: html_helper
INFO - 2021-07-14 07:56:26 --> Helper loaded: url_helper
INFO - 2021-07-14 07:56:26 --> Helper loaded: form_helper
INFO - 2021-07-14 07:56:26 --> Helper loaded: form_helper
INFO - 2021-07-14 07:56:26 --> Database Driver Class Initialized
INFO - 2021-07-14 07:56:26 --> Database Driver Class Initialized
INFO - 2021-07-14 07:56:26 --> Form Validation Class Initialized
INFO - 2021-07-14 07:56:26 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:56:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:56:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2021-07-14 07:56:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:56:26 --> Encryption Class Initialized
INFO - 2021-07-14 07:56:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:56:26 --> Encryption Class Initialized
INFO - 2021-07-14 07:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:56:26 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:56:26 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:56:26 --> Model "user_model" initialized
INFO - 2021-07-14 07:56:26 --> Model "role_model" initialized
INFO - 2021-07-14 07:56:26 --> Controller Class Initialized
INFO - 2021-07-14 07:56:26 --> Helper loaded: language_helper
INFO - 2021-07-14 07:56:26 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:56:26 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:56:26 --> Final output sent to browser
DEBUG - 2021-07-14 07:56:26 --> Total execution time: 0.0855
INFO - 2021-07-14 07:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:56:26 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:56:26 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:56:26 --> Model "user_model" initialized
INFO - 2021-07-14 07:56:26 --> Model "role_model" initialized
INFO - 2021-07-14 07:56:26 --> Controller Class Initialized
INFO - 2021-07-14 07:56:26 --> Helper loaded: language_helper
INFO - 2021-07-14 07:56:26 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:56:26 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:56:26 --> Final output sent to browser
DEBUG - 2021-07-14 07:56:26 --> Total execution time: 0.1001
INFO - 2021-07-14 07:57:08 --> Config Class Initialized
INFO - 2021-07-14 07:57:08 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:57:08 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:57:08 --> Utf8 Class Initialized
INFO - 2021-07-14 07:57:08 --> URI Class Initialized
INFO - 2021-07-14 07:57:08 --> Router Class Initialized
INFO - 2021-07-14 07:57:08 --> Output Class Initialized
INFO - 2021-07-14 07:57:08 --> Security Class Initialized
DEBUG - 2021-07-14 07:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:57:08 --> Input Class Initialized
INFO - 2021-07-14 07:57:08 --> Language Class Initialized
INFO - 2021-07-14 07:57:08 --> Loader Class Initialized
INFO - 2021-07-14 07:57:08 --> Helper loaded: html_helper
INFO - 2021-07-14 07:57:08 --> Helper loaded: url_helper
INFO - 2021-07-14 07:57:08 --> Helper loaded: form_helper
INFO - 2021-07-14 07:57:08 --> Database Driver Class Initialized
INFO - 2021-07-14 07:57:08 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:57:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:57:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:57:08 --> Encryption Class Initialized
INFO - 2021-07-14 07:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:57:08 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:57:08 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:57:08 --> Model "user_model" initialized
INFO - 2021-07-14 07:57:08 --> Model "role_model" initialized
INFO - 2021-07-14 07:57:08 --> Controller Class Initialized
INFO - 2021-07-14 07:57:08 --> Helper loaded: language_helper
INFO - 2021-07-14 07:57:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:57:08 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:57:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:57:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:57:08 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:57:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:57:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:57:08 --> Final output sent to browser
DEBUG - 2021-07-14 07:57:08 --> Total execution time: 0.1002
INFO - 2021-07-14 07:57:09 --> Config Class Initialized
INFO - 2021-07-14 07:57:09 --> Hooks Class Initialized
INFO - 2021-07-14 07:57:09 --> Config Class Initialized
INFO - 2021-07-14 07:57:09 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:57:09 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 07:57:09 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:57:09 --> Utf8 Class Initialized
INFO - 2021-07-14 07:57:09 --> Utf8 Class Initialized
INFO - 2021-07-14 07:57:09 --> URI Class Initialized
INFO - 2021-07-14 07:57:09 --> URI Class Initialized
INFO - 2021-07-14 07:57:09 --> Router Class Initialized
INFO - 2021-07-14 07:57:09 --> Router Class Initialized
INFO - 2021-07-14 07:57:09 --> Output Class Initialized
INFO - 2021-07-14 07:57:09 --> Output Class Initialized
INFO - 2021-07-14 07:57:09 --> Security Class Initialized
INFO - 2021-07-14 07:57:09 --> Security Class Initialized
DEBUG - 2021-07-14 07:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 07:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:57:09 --> Input Class Initialized
INFO - 2021-07-14 07:57:09 --> Input Class Initialized
INFO - 2021-07-14 07:57:09 --> Language Class Initialized
INFO - 2021-07-14 07:57:09 --> Language Class Initialized
INFO - 2021-07-14 07:57:09 --> Loader Class Initialized
INFO - 2021-07-14 07:57:09 --> Loader Class Initialized
INFO - 2021-07-14 07:57:09 --> Helper loaded: html_helper
INFO - 2021-07-14 07:57:09 --> Helper loaded: url_helper
INFO - 2021-07-14 07:57:09 --> Helper loaded: html_helper
INFO - 2021-07-14 07:57:09 --> Helper loaded: form_helper
INFO - 2021-07-14 07:57:09 --> Helper loaded: url_helper
INFO - 2021-07-14 07:57:09 --> Helper loaded: form_helper
INFO - 2021-07-14 07:57:09 --> Database Driver Class Initialized
INFO - 2021-07-14 07:57:09 --> Database Driver Class Initialized
INFO - 2021-07-14 07:57:09 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:57:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:57:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:57:09 --> Encryption Class Initialized
INFO - 2021-07-14 07:57:09 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:57:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:57:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:57:09 --> Encryption Class Initialized
INFO - 2021-07-14 07:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:57:09 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:57:09 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:57:09 --> Model "user_model" initialized
INFO - 2021-07-14 07:57:09 --> Model "role_model" initialized
INFO - 2021-07-14 07:57:09 --> Controller Class Initialized
INFO - 2021-07-14 07:57:09 --> Helper loaded: language_helper
INFO - 2021-07-14 07:57:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:57:09 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:57:09 --> Final output sent to browser
DEBUG - 2021-07-14 07:57:09 --> Total execution time: 0.0742
INFO - 2021-07-14 07:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:57:09 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:57:09 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:57:09 --> Model "user_model" initialized
INFO - 2021-07-14 07:57:09 --> Model "role_model" initialized
INFO - 2021-07-14 07:57:09 --> Controller Class Initialized
INFO - 2021-07-14 07:57:09 --> Helper loaded: language_helper
INFO - 2021-07-14 07:57:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:57:09 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:57:09 --> Final output sent to browser
DEBUG - 2021-07-14 07:57:09 --> Total execution time: 0.0851
INFO - 2021-07-14 07:58:07 --> Config Class Initialized
INFO - 2021-07-14 07:58:07 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:58:07 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:58:07 --> Utf8 Class Initialized
INFO - 2021-07-14 07:58:07 --> URI Class Initialized
INFO - 2021-07-14 07:58:07 --> Router Class Initialized
INFO - 2021-07-14 07:58:07 --> Output Class Initialized
INFO - 2021-07-14 07:58:07 --> Security Class Initialized
DEBUG - 2021-07-14 07:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:58:07 --> Input Class Initialized
INFO - 2021-07-14 07:58:07 --> Language Class Initialized
INFO - 2021-07-14 07:58:07 --> Loader Class Initialized
INFO - 2021-07-14 07:58:07 --> Helper loaded: html_helper
INFO - 2021-07-14 07:58:07 --> Helper loaded: url_helper
INFO - 2021-07-14 07:58:07 --> Helper loaded: form_helper
INFO - 2021-07-14 07:58:07 --> Database Driver Class Initialized
INFO - 2021-07-14 07:58:07 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:58:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:58:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:58:07 --> Encryption Class Initialized
INFO - 2021-07-14 07:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:58:07 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:58:07 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:58:07 --> Model "user_model" initialized
INFO - 2021-07-14 07:58:07 --> Model "role_model" initialized
INFO - 2021-07-14 07:58:07 --> Controller Class Initialized
INFO - 2021-07-14 07:58:07 --> Helper loaded: language_helper
INFO - 2021-07-14 07:58:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:58:07 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:58:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:58:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:58:07 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:58:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:58:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:58:07 --> Final output sent to browser
DEBUG - 2021-07-14 07:58:07 --> Total execution time: 0.1145
INFO - 2021-07-14 07:58:08 --> Config Class Initialized
INFO - 2021-07-14 07:58:08 --> Config Class Initialized
INFO - 2021-07-14 07:58:08 --> Hooks Class Initialized
INFO - 2021-07-14 07:58:08 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:58:08 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 07:58:08 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:58:08 --> Utf8 Class Initialized
INFO - 2021-07-14 07:58:08 --> Utf8 Class Initialized
INFO - 2021-07-14 07:58:08 --> URI Class Initialized
INFO - 2021-07-14 07:58:08 --> URI Class Initialized
INFO - 2021-07-14 07:58:08 --> Router Class Initialized
INFO - 2021-07-14 07:58:08 --> Router Class Initialized
INFO - 2021-07-14 07:58:08 --> Output Class Initialized
INFO - 2021-07-14 07:58:08 --> Output Class Initialized
INFO - 2021-07-14 07:58:08 --> Security Class Initialized
INFO - 2021-07-14 07:58:08 --> Security Class Initialized
DEBUG - 2021-07-14 07:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 07:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:58:08 --> Input Class Initialized
INFO - 2021-07-14 07:58:08 --> Input Class Initialized
INFO - 2021-07-14 07:58:08 --> Language Class Initialized
INFO - 2021-07-14 07:58:08 --> Language Class Initialized
INFO - 2021-07-14 07:58:08 --> Loader Class Initialized
INFO - 2021-07-14 07:58:08 --> Loader Class Initialized
INFO - 2021-07-14 07:58:08 --> Helper loaded: html_helper
INFO - 2021-07-14 07:58:08 --> Helper loaded: html_helper
INFO - 2021-07-14 07:58:08 --> Helper loaded: url_helper
INFO - 2021-07-14 07:58:08 --> Helper loaded: url_helper
INFO - 2021-07-14 07:58:08 --> Helper loaded: form_helper
INFO - 2021-07-14 07:58:08 --> Helper loaded: form_helper
INFO - 2021-07-14 07:58:08 --> Database Driver Class Initialized
INFO - 2021-07-14 07:58:08 --> Database Driver Class Initialized
INFO - 2021-07-14 07:58:08 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:58:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:58:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:58:08 --> Encryption Class Initialized
INFO - 2021-07-14 07:58:08 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:58:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:58:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:58:08 --> Encryption Class Initialized
INFO - 2021-07-14 07:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:58:08 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:58:08 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:58:08 --> Model "user_model" initialized
INFO - 2021-07-14 07:58:08 --> Model "role_model" initialized
INFO - 2021-07-14 07:58:08 --> Controller Class Initialized
INFO - 2021-07-14 07:58:08 --> Helper loaded: language_helper
INFO - 2021-07-14 07:58:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:58:08 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:58:08 --> Final output sent to browser
DEBUG - 2021-07-14 07:58:08 --> Total execution time: 0.0843
INFO - 2021-07-14 07:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:58:08 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:58:08 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:58:08 --> Model "user_model" initialized
INFO - 2021-07-14 07:58:08 --> Model "role_model" initialized
INFO - 2021-07-14 07:58:08 --> Controller Class Initialized
INFO - 2021-07-14 07:58:08 --> Helper loaded: language_helper
INFO - 2021-07-14 07:58:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:58:08 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:58:08 --> Final output sent to browser
DEBUG - 2021-07-14 07:58:08 --> Total execution time: 0.1003
INFO - 2021-07-14 07:58:56 --> Config Class Initialized
INFO - 2021-07-14 07:58:56 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:58:56 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:58:56 --> Utf8 Class Initialized
INFO - 2021-07-14 07:58:56 --> URI Class Initialized
INFO - 2021-07-14 07:58:56 --> Router Class Initialized
INFO - 2021-07-14 07:58:56 --> Output Class Initialized
INFO - 2021-07-14 07:58:56 --> Security Class Initialized
DEBUG - 2021-07-14 07:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:58:56 --> Input Class Initialized
INFO - 2021-07-14 07:58:56 --> Language Class Initialized
INFO - 2021-07-14 07:58:56 --> Loader Class Initialized
INFO - 2021-07-14 07:58:56 --> Helper loaded: html_helper
INFO - 2021-07-14 07:58:56 --> Helper loaded: url_helper
INFO - 2021-07-14 07:58:56 --> Helper loaded: form_helper
INFO - 2021-07-14 07:58:56 --> Database Driver Class Initialized
INFO - 2021-07-14 07:58:56 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:58:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:58:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:58:56 --> Encryption Class Initialized
INFO - 2021-07-14 07:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:58:56 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:58:56 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:58:56 --> Model "user_model" initialized
INFO - 2021-07-14 07:58:56 --> Model "role_model" initialized
INFO - 2021-07-14 07:58:56 --> Controller Class Initialized
INFO - 2021-07-14 07:58:56 --> Helper loaded: language_helper
INFO - 2021-07-14 07:58:56 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:58:56 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:58:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 07:58:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 07:58:56 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 07:58:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 07:58:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 07:58:56 --> Final output sent to browser
DEBUG - 2021-07-14 07:58:56 --> Total execution time: 0.1236
INFO - 2021-07-14 07:58:57 --> Config Class Initialized
INFO - 2021-07-14 07:58:57 --> Hooks Class Initialized
DEBUG - 2021-07-14 07:58:57 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:58:57 --> Utf8 Class Initialized
INFO - 2021-07-14 07:58:57 --> Config Class Initialized
INFO - 2021-07-14 07:58:57 --> Hooks Class Initialized
INFO - 2021-07-14 07:58:57 --> URI Class Initialized
INFO - 2021-07-14 07:58:57 --> Router Class Initialized
DEBUG - 2021-07-14 07:58:57 --> UTF-8 Support Enabled
INFO - 2021-07-14 07:58:57 --> Utf8 Class Initialized
INFO - 2021-07-14 07:58:57 --> Output Class Initialized
INFO - 2021-07-14 07:58:57 --> URI Class Initialized
INFO - 2021-07-14 07:58:57 --> Security Class Initialized
INFO - 2021-07-14 07:58:57 --> Router Class Initialized
DEBUG - 2021-07-14 07:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:58:57 --> Input Class Initialized
INFO - 2021-07-14 07:58:57 --> Language Class Initialized
INFO - 2021-07-14 07:58:57 --> Output Class Initialized
INFO - 2021-07-14 07:58:57 --> Security Class Initialized
DEBUG - 2021-07-14 07:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 07:58:57 --> Loader Class Initialized
INFO - 2021-07-14 07:58:57 --> Input Class Initialized
INFO - 2021-07-14 07:58:57 --> Language Class Initialized
INFO - 2021-07-14 07:58:57 --> Helper loaded: html_helper
INFO - 2021-07-14 07:58:57 --> Helper loaded: url_helper
INFO - 2021-07-14 07:58:57 --> Loader Class Initialized
INFO - 2021-07-14 07:58:57 --> Helper loaded: form_helper
INFO - 2021-07-14 07:58:57 --> Helper loaded: html_helper
INFO - 2021-07-14 07:58:57 --> Helper loaded: url_helper
INFO - 2021-07-14 07:58:57 --> Helper loaded: form_helper
INFO - 2021-07-14 07:58:57 --> Database Driver Class Initialized
INFO - 2021-07-14 07:58:57 --> Database Driver Class Initialized
INFO - 2021-07-14 07:58:57 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:58:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:58:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:58:57 --> Encryption Class Initialized
INFO - 2021-07-14 07:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:58:57 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:58:57 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:58:57 --> Model "user_model" initialized
INFO - 2021-07-14 07:58:57 --> Model "role_model" initialized
INFO - 2021-07-14 07:58:57 --> Controller Class Initialized
INFO - 2021-07-14 07:58:57 --> Helper loaded: language_helper
INFO - 2021-07-14 07:58:57 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:58:57 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:58:57 --> Final output sent to browser
DEBUG - 2021-07-14 07:58:57 --> Total execution time: 0.0885
INFO - 2021-07-14 07:58:57 --> Form Validation Class Initialized
DEBUG - 2021-07-14 07:58:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 07:58:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 07:58:57 --> Encryption Class Initialized
INFO - 2021-07-14 07:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 07:58:57 --> Model "vendor_model" initialized
INFO - 2021-07-14 07:58:57 --> Model "coupon_model" initialized
INFO - 2021-07-14 07:58:57 --> Model "user_model" initialized
INFO - 2021-07-14 07:58:57 --> Model "role_model" initialized
INFO - 2021-07-14 07:58:57 --> Controller Class Initialized
INFO - 2021-07-14 07:58:57 --> Helper loaded: language_helper
INFO - 2021-07-14 07:58:57 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 07:58:57 --> Model "Quotation_model" initialized
INFO - 2021-07-14 07:58:57 --> Final output sent to browser
DEBUG - 2021-07-14 07:58:57 --> Total execution time: 0.1023
INFO - 2021-07-14 08:01:16 --> Config Class Initialized
INFO - 2021-07-14 08:01:16 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:01:16 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:01:16 --> Utf8 Class Initialized
INFO - 2021-07-14 08:01:16 --> URI Class Initialized
INFO - 2021-07-14 08:01:16 --> Router Class Initialized
INFO - 2021-07-14 08:01:16 --> Output Class Initialized
INFO - 2021-07-14 08:01:16 --> Security Class Initialized
DEBUG - 2021-07-14 08:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:01:16 --> Input Class Initialized
INFO - 2021-07-14 08:01:16 --> Language Class Initialized
INFO - 2021-07-14 08:01:16 --> Loader Class Initialized
INFO - 2021-07-14 08:01:16 --> Helper loaded: html_helper
INFO - 2021-07-14 08:01:16 --> Helper loaded: url_helper
INFO - 2021-07-14 08:01:16 --> Helper loaded: form_helper
INFO - 2021-07-14 08:01:16 --> Database Driver Class Initialized
INFO - 2021-07-14 08:01:16 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:01:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:01:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:01:16 --> Encryption Class Initialized
INFO - 2021-07-14 08:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:01:16 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:01:16 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:01:16 --> Model "user_model" initialized
INFO - 2021-07-14 08:01:16 --> Model "role_model" initialized
INFO - 2021-07-14 08:01:16 --> Controller Class Initialized
INFO - 2021-07-14 08:01:16 --> Helper loaded: language_helper
INFO - 2021-07-14 08:01:16 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:01:16 --> Model "Quotation_model" initialized
INFO - 2021-07-14 08:01:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 08:01:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 08:01:16 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 08:01:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 08:01:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 08:01:16 --> Final output sent to browser
DEBUG - 2021-07-14 08:01:16 --> Total execution time: 0.1096
INFO - 2021-07-14 08:01:17 --> Config Class Initialized
INFO - 2021-07-14 08:01:17 --> Config Class Initialized
INFO - 2021-07-14 08:01:17 --> Hooks Class Initialized
INFO - 2021-07-14 08:01:17 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:01:17 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 08:01:17 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:01:17 --> Utf8 Class Initialized
INFO - 2021-07-14 08:01:17 --> Utf8 Class Initialized
INFO - 2021-07-14 08:01:17 --> URI Class Initialized
INFO - 2021-07-14 08:01:17 --> URI Class Initialized
INFO - 2021-07-14 08:01:17 --> Router Class Initialized
INFO - 2021-07-14 08:01:17 --> Router Class Initialized
INFO - 2021-07-14 08:01:17 --> Output Class Initialized
INFO - 2021-07-14 08:01:17 --> Output Class Initialized
INFO - 2021-07-14 08:01:17 --> Security Class Initialized
INFO - 2021-07-14 08:01:17 --> Security Class Initialized
DEBUG - 2021-07-14 08:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 08:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:01:17 --> Input Class Initialized
INFO - 2021-07-14 08:01:17 --> Input Class Initialized
INFO - 2021-07-14 08:01:17 --> Language Class Initialized
INFO - 2021-07-14 08:01:17 --> Language Class Initialized
INFO - 2021-07-14 08:01:17 --> Loader Class Initialized
INFO - 2021-07-14 08:01:17 --> Loader Class Initialized
INFO - 2021-07-14 08:01:17 --> Helper loaded: html_helper
INFO - 2021-07-14 08:01:17 --> Helper loaded: html_helper
INFO - 2021-07-14 08:01:17 --> Helper loaded: url_helper
INFO - 2021-07-14 08:01:17 --> Helper loaded: url_helper
INFO - 2021-07-14 08:01:17 --> Helper loaded: form_helper
INFO - 2021-07-14 08:01:17 --> Helper loaded: form_helper
INFO - 2021-07-14 08:01:17 --> Database Driver Class Initialized
INFO - 2021-07-14 08:01:17 --> Database Driver Class Initialized
INFO - 2021-07-14 08:01:17 --> Form Validation Class Initialized
INFO - 2021-07-14 08:01:17 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:01:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:01:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:01:17 --> Encryption Class Initialized
DEBUG - 2021-07-14 08:01:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:01:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:01:17 --> Encryption Class Initialized
INFO - 2021-07-14 08:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:01:17 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:01:17 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:01:17 --> Model "user_model" initialized
INFO - 2021-07-14 08:01:17 --> Model "role_model" initialized
INFO - 2021-07-14 08:01:17 --> Controller Class Initialized
INFO - 2021-07-14 08:01:17 --> Helper loaded: language_helper
INFO - 2021-07-14 08:01:17 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:01:17 --> Model "Quotation_model" initialized
INFO - 2021-07-14 08:01:17 --> Final output sent to browser
DEBUG - 2021-07-14 08:01:17 --> Total execution time: 0.0696
INFO - 2021-07-14 08:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:01:17 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:01:17 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:01:17 --> Model "user_model" initialized
INFO - 2021-07-14 08:01:17 --> Model "role_model" initialized
INFO - 2021-07-14 08:01:17 --> Controller Class Initialized
INFO - 2021-07-14 08:01:17 --> Helper loaded: language_helper
INFO - 2021-07-14 08:01:17 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:01:17 --> Model "Quotation_model" initialized
INFO - 2021-07-14 08:01:17 --> Final output sent to browser
DEBUG - 2021-07-14 08:01:17 --> Total execution time: 0.0893
INFO - 2021-07-14 08:02:21 --> Config Class Initialized
INFO - 2021-07-14 08:02:21 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:02:21 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:02:21 --> Utf8 Class Initialized
INFO - 2021-07-14 08:02:21 --> URI Class Initialized
INFO - 2021-07-14 08:02:21 --> Router Class Initialized
INFO - 2021-07-14 08:02:21 --> Output Class Initialized
INFO - 2021-07-14 08:02:21 --> Security Class Initialized
DEBUG - 2021-07-14 08:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:02:21 --> Input Class Initialized
INFO - 2021-07-14 08:02:21 --> Language Class Initialized
INFO - 2021-07-14 08:02:21 --> Loader Class Initialized
INFO - 2021-07-14 08:02:21 --> Helper loaded: html_helper
INFO - 2021-07-14 08:02:21 --> Helper loaded: url_helper
INFO - 2021-07-14 08:02:21 --> Helper loaded: form_helper
INFO - 2021-07-14 08:02:21 --> Database Driver Class Initialized
INFO - 2021-07-14 08:02:21 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:02:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:02:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:02:21 --> Encryption Class Initialized
INFO - 2021-07-14 08:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:02:21 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:02:21 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:02:21 --> Model "user_model" initialized
INFO - 2021-07-14 08:02:21 --> Model "role_model" initialized
INFO - 2021-07-14 08:02:21 --> Controller Class Initialized
INFO - 2021-07-14 08:02:21 --> Helper loaded: language_helper
INFO - 2021-07-14 08:02:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:02:21 --> Model "Quotation_model" initialized
INFO - 2021-07-14 08:02:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 08:02:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 08:02:21 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 08:02:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 08:02:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 08:02:21 --> Final output sent to browser
DEBUG - 2021-07-14 08:02:21 --> Total execution time: 0.1177
INFO - 2021-07-14 08:02:22 --> Config Class Initialized
INFO - 2021-07-14 08:02:22 --> Config Class Initialized
INFO - 2021-07-14 08:02:22 --> Hooks Class Initialized
INFO - 2021-07-14 08:02:22 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:02:22 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 08:02:22 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:02:22 --> Utf8 Class Initialized
INFO - 2021-07-14 08:02:22 --> Utf8 Class Initialized
INFO - 2021-07-14 08:02:22 --> URI Class Initialized
INFO - 2021-07-14 08:02:22 --> URI Class Initialized
INFO - 2021-07-14 08:02:22 --> Router Class Initialized
INFO - 2021-07-14 08:02:22 --> Router Class Initialized
INFO - 2021-07-14 08:02:22 --> Output Class Initialized
INFO - 2021-07-14 08:02:22 --> Output Class Initialized
INFO - 2021-07-14 08:02:22 --> Security Class Initialized
INFO - 2021-07-14 08:02:22 --> Security Class Initialized
DEBUG - 2021-07-14 08:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 08:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:02:22 --> Input Class Initialized
INFO - 2021-07-14 08:02:22 --> Input Class Initialized
INFO - 2021-07-14 08:02:22 --> Language Class Initialized
INFO - 2021-07-14 08:02:22 --> Language Class Initialized
INFO - 2021-07-14 08:02:22 --> Loader Class Initialized
INFO - 2021-07-14 08:02:22 --> Loader Class Initialized
INFO - 2021-07-14 08:02:22 --> Helper loaded: html_helper
INFO - 2021-07-14 08:02:22 --> Helper loaded: html_helper
INFO - 2021-07-14 08:02:22 --> Helper loaded: url_helper
INFO - 2021-07-14 08:02:22 --> Helper loaded: url_helper
INFO - 2021-07-14 08:02:22 --> Helper loaded: form_helper
INFO - 2021-07-14 08:02:22 --> Helper loaded: form_helper
INFO - 2021-07-14 08:02:22 --> Database Driver Class Initialized
INFO - 2021-07-14 08:02:22 --> Database Driver Class Initialized
INFO - 2021-07-14 08:02:22 --> Form Validation Class Initialized
INFO - 2021-07-14 08:02:22 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-14 08:02:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:02:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:02:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:02:22 --> Encryption Class Initialized
INFO - 2021-07-14 08:02:22 --> Encryption Class Initialized
INFO - 2021-07-14 08:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:02:22 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:02:22 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:02:22 --> Model "user_model" initialized
INFO - 2021-07-14 08:02:22 --> Model "role_model" initialized
INFO - 2021-07-14 08:02:22 --> Controller Class Initialized
INFO - 2021-07-14 08:02:22 --> Helper loaded: language_helper
INFO - 2021-07-14 08:02:22 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:02:22 --> Model "Quotation_model" initialized
INFO - 2021-07-14 08:02:22 --> Final output sent to browser
DEBUG - 2021-07-14 08:02:22 --> Total execution time: 0.0977
INFO - 2021-07-14 08:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:02:22 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:02:22 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:02:22 --> Model "user_model" initialized
INFO - 2021-07-14 08:02:22 --> Model "role_model" initialized
INFO - 2021-07-14 08:02:22 --> Controller Class Initialized
INFO - 2021-07-14 08:02:22 --> Helper loaded: language_helper
INFO - 2021-07-14 08:02:22 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:02:22 --> Model "Quotation_model" initialized
INFO - 2021-07-14 08:02:22 --> Final output sent to browser
DEBUG - 2021-07-14 08:02:22 --> Total execution time: 0.1086
INFO - 2021-07-14 08:03:10 --> Config Class Initialized
INFO - 2021-07-14 08:03:10 --> Config Class Initialized
INFO - 2021-07-14 08:03:10 --> Hooks Class Initialized
INFO - 2021-07-14 08:03:10 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:03:10 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:03:10 --> Utf8 Class Initialized
DEBUG - 2021-07-14 08:03:10 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:03:10 --> Utf8 Class Initialized
INFO - 2021-07-14 08:03:10 --> URI Class Initialized
INFO - 2021-07-14 08:03:10 --> URI Class Initialized
INFO - 2021-07-14 08:03:10 --> Router Class Initialized
INFO - 2021-07-14 08:03:10 --> Router Class Initialized
INFO - 2021-07-14 08:03:10 --> Output Class Initialized
INFO - 2021-07-14 08:03:10 --> Output Class Initialized
INFO - 2021-07-14 08:03:10 --> Security Class Initialized
DEBUG - 2021-07-14 08:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:03:10 --> Input Class Initialized
INFO - 2021-07-14 08:03:10 --> Language Class Initialized
INFO - 2021-07-14 08:03:10 --> Loader Class Initialized
INFO - 2021-07-14 08:03:10 --> Security Class Initialized
INFO - 2021-07-14 08:03:10 --> Helper loaded: html_helper
INFO - 2021-07-14 08:03:10 --> Helper loaded: url_helper
DEBUG - 2021-07-14 08:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:03:10 --> Input Class Initialized
INFO - 2021-07-14 08:03:10 --> Language Class Initialized
INFO - 2021-07-14 08:03:10 --> Helper loaded: form_helper
INFO - 2021-07-14 08:03:10 --> Loader Class Initialized
INFO - 2021-07-14 08:03:10 --> Helper loaded: html_helper
INFO - 2021-07-14 08:03:10 --> Helper loaded: url_helper
INFO - 2021-07-14 08:03:10 --> Database Driver Class Initialized
INFO - 2021-07-14 08:03:10 --> Helper loaded: form_helper
INFO - 2021-07-14 08:03:10 --> Database Driver Class Initialized
INFO - 2021-07-14 08:03:10 --> Form Validation Class Initialized
INFO - 2021-07-14 08:03:10 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:03:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:03:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:03:10 --> Encryption Class Initialized
DEBUG - 2021-07-14 08:03:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:03:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:03:10 --> Encryption Class Initialized
INFO - 2021-07-14 08:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:03:10 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:03:10 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:03:10 --> Model "user_model" initialized
INFO - 2021-07-14 08:03:10 --> Model "role_model" initialized
INFO - 2021-07-14 08:03:10 --> Controller Class Initialized
INFO - 2021-07-14 08:03:10 --> Helper loaded: language_helper
INFO - 2021-07-14 08:03:10 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:03:10 --> Model "Quotation_model" initialized
INFO - 2021-07-14 08:03:10 --> Final output sent to browser
DEBUG - 2021-07-14 08:03:10 --> Total execution time: 0.0761
INFO - 2021-07-14 08:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:03:10 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:03:10 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:03:10 --> Model "user_model" initialized
INFO - 2021-07-14 08:03:10 --> Model "role_model" initialized
INFO - 2021-07-14 08:03:10 --> Controller Class Initialized
INFO - 2021-07-14 08:03:10 --> Helper loaded: language_helper
INFO - 2021-07-14 08:03:10 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:03:10 --> Model "Quotation_model" initialized
INFO - 2021-07-14 08:03:10 --> Final output sent to browser
DEBUG - 2021-07-14 08:03:10 --> Total execution time: 0.0893
INFO - 2021-07-14 08:03:39 --> Config Class Initialized
INFO - 2021-07-14 08:03:39 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:03:39 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:03:39 --> Utf8 Class Initialized
INFO - 2021-07-14 08:03:39 --> URI Class Initialized
INFO - 2021-07-14 08:03:39 --> Router Class Initialized
INFO - 2021-07-14 08:03:39 --> Output Class Initialized
INFO - 2021-07-14 08:03:39 --> Security Class Initialized
DEBUG - 2021-07-14 08:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:03:39 --> Input Class Initialized
INFO - 2021-07-14 08:03:39 --> Language Class Initialized
INFO - 2021-07-14 08:03:39 --> Loader Class Initialized
INFO - 2021-07-14 08:03:39 --> Helper loaded: html_helper
INFO - 2021-07-14 08:03:39 --> Helper loaded: url_helper
INFO - 2021-07-14 08:03:39 --> Helper loaded: form_helper
INFO - 2021-07-14 08:03:39 --> Database Driver Class Initialized
INFO - 2021-07-14 08:03:39 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:03:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:03:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:03:39 --> Encryption Class Initialized
INFO - 2021-07-14 08:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:03:39 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:03:39 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:03:39 --> Model "user_model" initialized
INFO - 2021-07-14 08:03:39 --> Model "role_model" initialized
INFO - 2021-07-14 08:03:39 --> Controller Class Initialized
INFO - 2021-07-14 08:03:39 --> Helper loaded: language_helper
INFO - 2021-07-14 08:03:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:03:39 --> Model "Customer_model" initialized
INFO - 2021-07-14 08:03:39 --> Model "Product_model" initialized
INFO - 2021-07-14 08:03:39 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 08:03:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 08:03:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 08:03:39 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 08:03:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 08:03:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 08:03:39 --> Final output sent to browser
DEBUG - 2021-07-14 08:03:39 --> Total execution time: 0.1093
INFO - 2021-07-14 08:03:43 --> Config Class Initialized
INFO - 2021-07-14 08:03:43 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:03:43 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:03:43 --> Utf8 Class Initialized
INFO - 2021-07-14 08:03:43 --> URI Class Initialized
INFO - 2021-07-14 08:03:43 --> Router Class Initialized
INFO - 2021-07-14 08:03:43 --> Output Class Initialized
INFO - 2021-07-14 08:03:43 --> Security Class Initialized
DEBUG - 2021-07-14 08:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:03:43 --> Input Class Initialized
INFO - 2021-07-14 08:03:43 --> Language Class Initialized
INFO - 2021-07-14 08:03:43 --> Loader Class Initialized
INFO - 2021-07-14 08:03:43 --> Helper loaded: html_helper
INFO - 2021-07-14 08:03:43 --> Helper loaded: url_helper
INFO - 2021-07-14 08:03:43 --> Helper loaded: form_helper
INFO - 2021-07-14 08:03:43 --> Database Driver Class Initialized
INFO - 2021-07-14 08:03:43 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:03:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:03:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:03:43 --> Encryption Class Initialized
INFO - 2021-07-14 08:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:03:43 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:03:43 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:03:43 --> Model "user_model" initialized
INFO - 2021-07-14 08:03:43 --> Model "role_model" initialized
INFO - 2021-07-14 08:03:43 --> Controller Class Initialized
INFO - 2021-07-14 08:03:43 --> Helper loaded: language_helper
INFO - 2021-07-14 08:03:43 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:03:43 --> Model "Customer_model" initialized
INFO - 2021-07-14 08:03:43 --> Final output sent to browser
DEBUG - 2021-07-14 08:03:43 --> Total execution time: 0.0520
INFO - 2021-07-14 08:03:43 --> Config Class Initialized
INFO - 2021-07-14 08:03:43 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:03:43 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:03:43 --> Utf8 Class Initialized
INFO - 2021-07-14 08:03:43 --> URI Class Initialized
INFO - 2021-07-14 08:03:43 --> Router Class Initialized
INFO - 2021-07-14 08:03:43 --> Output Class Initialized
INFO - 2021-07-14 08:03:43 --> Security Class Initialized
DEBUG - 2021-07-14 08:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:03:43 --> Input Class Initialized
INFO - 2021-07-14 08:03:43 --> Language Class Initialized
INFO - 2021-07-14 08:03:43 --> Loader Class Initialized
INFO - 2021-07-14 08:03:43 --> Helper loaded: html_helper
INFO - 2021-07-14 08:03:43 --> Helper loaded: url_helper
INFO - 2021-07-14 08:03:43 --> Helper loaded: form_helper
INFO - 2021-07-14 08:03:43 --> Database Driver Class Initialized
INFO - 2021-07-14 08:03:43 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:03:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:03:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:03:43 --> Encryption Class Initialized
INFO - 2021-07-14 08:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:03:43 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:03:43 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:03:43 --> Model "user_model" initialized
INFO - 2021-07-14 08:03:43 --> Model "role_model" initialized
INFO - 2021-07-14 08:03:43 --> Controller Class Initialized
INFO - 2021-07-14 08:03:43 --> Helper loaded: language_helper
INFO - 2021-07-14 08:03:43 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:03:43 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 08:03:43 --> Final output sent to browser
DEBUG - 2021-07-14 08:03:43 --> Total execution time: 0.0546
INFO - 2021-07-14 08:04:10 --> Config Class Initialized
INFO - 2021-07-14 08:04:10 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:04:10 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:04:10 --> Utf8 Class Initialized
INFO - 2021-07-14 08:04:10 --> URI Class Initialized
INFO - 2021-07-14 08:04:10 --> Router Class Initialized
INFO - 2021-07-14 08:04:10 --> Output Class Initialized
INFO - 2021-07-14 08:04:10 --> Security Class Initialized
DEBUG - 2021-07-14 08:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:04:10 --> Input Class Initialized
INFO - 2021-07-14 08:04:10 --> Language Class Initialized
INFO - 2021-07-14 08:04:10 --> Loader Class Initialized
INFO - 2021-07-14 08:04:10 --> Helper loaded: html_helper
INFO - 2021-07-14 08:04:10 --> Helper loaded: url_helper
INFO - 2021-07-14 08:04:10 --> Helper loaded: form_helper
INFO - 2021-07-14 08:04:10 --> Database Driver Class Initialized
INFO - 2021-07-14 08:04:10 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:04:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:04:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:04:10 --> Encryption Class Initialized
INFO - 2021-07-14 08:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:04:10 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:04:10 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:04:10 --> Model "user_model" initialized
INFO - 2021-07-14 08:04:10 --> Model "role_model" initialized
INFO - 2021-07-14 08:04:10 --> Controller Class Initialized
INFO - 2021-07-14 08:04:10 --> Helper loaded: language_helper
INFO - 2021-07-14 08:04:10 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:04:10 --> Model "Product_model" initialized
INFO - 2021-07-14 08:04:10 --> Final output sent to browser
DEBUG - 2021-07-14 08:04:10 --> Total execution time: 0.0683
INFO - 2021-07-14 08:04:12 --> Config Class Initialized
INFO - 2021-07-14 08:04:12 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:04:12 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:04:12 --> Utf8 Class Initialized
INFO - 2021-07-14 08:04:12 --> URI Class Initialized
INFO - 2021-07-14 08:04:12 --> Router Class Initialized
INFO - 2021-07-14 08:04:12 --> Output Class Initialized
INFO - 2021-07-14 08:04:12 --> Security Class Initialized
DEBUG - 2021-07-14 08:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:04:12 --> Input Class Initialized
INFO - 2021-07-14 08:04:12 --> Language Class Initialized
INFO - 2021-07-14 08:04:12 --> Loader Class Initialized
INFO - 2021-07-14 08:04:12 --> Helper loaded: html_helper
INFO - 2021-07-14 08:04:12 --> Helper loaded: url_helper
INFO - 2021-07-14 08:04:12 --> Helper loaded: form_helper
INFO - 2021-07-14 08:04:12 --> Database Driver Class Initialized
INFO - 2021-07-14 08:04:12 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:04:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:04:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:04:12 --> Encryption Class Initialized
INFO - 2021-07-14 08:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:04:12 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:04:12 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:04:12 --> Model "user_model" initialized
INFO - 2021-07-14 08:04:12 --> Model "role_model" initialized
INFO - 2021-07-14 08:04:12 --> Controller Class Initialized
INFO - 2021-07-14 08:04:12 --> Helper loaded: language_helper
INFO - 2021-07-14 08:04:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:04:12 --> Model "Product_model" initialized
INFO - 2021-07-14 08:04:12 --> Final output sent to browser
DEBUG - 2021-07-14 08:04:12 --> Total execution time: 0.0626
INFO - 2021-07-14 08:04:14 --> Config Class Initialized
INFO - 2021-07-14 08:04:14 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:04:14 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:04:14 --> Utf8 Class Initialized
INFO - 2021-07-14 08:04:14 --> URI Class Initialized
INFO - 2021-07-14 08:04:14 --> Router Class Initialized
INFO - 2021-07-14 08:04:14 --> Output Class Initialized
INFO - 2021-07-14 08:04:14 --> Security Class Initialized
DEBUG - 2021-07-14 08:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:04:14 --> Input Class Initialized
INFO - 2021-07-14 08:04:14 --> Language Class Initialized
INFO - 2021-07-14 08:04:14 --> Loader Class Initialized
INFO - 2021-07-14 08:04:14 --> Helper loaded: html_helper
INFO - 2021-07-14 08:04:14 --> Helper loaded: url_helper
INFO - 2021-07-14 08:04:14 --> Helper loaded: form_helper
INFO - 2021-07-14 08:04:14 --> Database Driver Class Initialized
INFO - 2021-07-14 08:04:14 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:04:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:04:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:04:14 --> Encryption Class Initialized
INFO - 2021-07-14 08:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:04:14 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:04:14 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:04:14 --> Model "user_model" initialized
INFO - 2021-07-14 08:04:14 --> Model "role_model" initialized
INFO - 2021-07-14 08:04:14 --> Controller Class Initialized
INFO - 2021-07-14 08:04:14 --> Helper loaded: language_helper
INFO - 2021-07-14 08:04:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:04:14 --> Model "Product_model" initialized
INFO - 2021-07-14 08:04:14 --> Final output sent to browser
DEBUG - 2021-07-14 08:04:14 --> Total execution time: 0.0672
INFO - 2021-07-14 08:04:16 --> Config Class Initialized
INFO - 2021-07-14 08:04:16 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:04:16 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:04:16 --> Utf8 Class Initialized
INFO - 2021-07-14 08:04:16 --> URI Class Initialized
INFO - 2021-07-14 08:04:16 --> Router Class Initialized
INFO - 2021-07-14 08:04:16 --> Output Class Initialized
INFO - 2021-07-14 08:04:16 --> Security Class Initialized
DEBUG - 2021-07-14 08:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:04:16 --> Input Class Initialized
INFO - 2021-07-14 08:04:16 --> Language Class Initialized
INFO - 2021-07-14 08:04:16 --> Loader Class Initialized
INFO - 2021-07-14 08:04:16 --> Helper loaded: html_helper
INFO - 2021-07-14 08:04:16 --> Helper loaded: url_helper
INFO - 2021-07-14 08:04:16 --> Helper loaded: form_helper
INFO - 2021-07-14 08:04:16 --> Database Driver Class Initialized
INFO - 2021-07-14 08:04:16 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:04:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:04:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:04:16 --> Encryption Class Initialized
INFO - 2021-07-14 08:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:04:16 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:04:16 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:04:16 --> Model "user_model" initialized
INFO - 2021-07-14 08:04:16 --> Model "role_model" initialized
INFO - 2021-07-14 08:04:16 --> Controller Class Initialized
INFO - 2021-07-14 08:04:16 --> Helper loaded: language_helper
INFO - 2021-07-14 08:04:16 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:04:16 --> Model "Product_model" initialized
INFO - 2021-07-14 08:04:16 --> Final output sent to browser
DEBUG - 2021-07-14 08:04:16 --> Total execution time: 0.0628
INFO - 2021-07-14 08:04:18 --> Config Class Initialized
INFO - 2021-07-14 08:04:18 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:04:18 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:04:18 --> Utf8 Class Initialized
INFO - 2021-07-14 08:04:18 --> URI Class Initialized
INFO - 2021-07-14 08:04:18 --> Router Class Initialized
INFO - 2021-07-14 08:04:18 --> Output Class Initialized
INFO - 2021-07-14 08:04:18 --> Security Class Initialized
DEBUG - 2021-07-14 08:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:04:18 --> Input Class Initialized
INFO - 2021-07-14 08:04:18 --> Language Class Initialized
INFO - 2021-07-14 08:04:18 --> Loader Class Initialized
INFO - 2021-07-14 08:04:18 --> Helper loaded: html_helper
INFO - 2021-07-14 08:04:18 --> Helper loaded: url_helper
INFO - 2021-07-14 08:04:18 --> Helper loaded: form_helper
INFO - 2021-07-14 08:04:18 --> Database Driver Class Initialized
INFO - 2021-07-14 08:04:18 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:04:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:04:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:04:18 --> Encryption Class Initialized
INFO - 2021-07-14 08:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:04:18 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:04:18 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:04:18 --> Model "user_model" initialized
INFO - 2021-07-14 08:04:18 --> Model "role_model" initialized
INFO - 2021-07-14 08:04:18 --> Controller Class Initialized
INFO - 2021-07-14 08:04:18 --> Helper loaded: language_helper
INFO - 2021-07-14 08:04:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:04:18 --> Model "Product_model" initialized
INFO - 2021-07-14 08:04:18 --> Final output sent to browser
DEBUG - 2021-07-14 08:04:18 --> Total execution time: 0.0625
INFO - 2021-07-14 08:04:21 --> Config Class Initialized
INFO - 2021-07-14 08:04:21 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:04:21 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:04:21 --> Utf8 Class Initialized
INFO - 2021-07-14 08:04:21 --> URI Class Initialized
INFO - 2021-07-14 08:04:21 --> Router Class Initialized
INFO - 2021-07-14 08:04:21 --> Output Class Initialized
INFO - 2021-07-14 08:04:21 --> Security Class Initialized
DEBUG - 2021-07-14 08:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:04:21 --> Input Class Initialized
INFO - 2021-07-14 08:04:21 --> Language Class Initialized
INFO - 2021-07-14 08:04:21 --> Loader Class Initialized
INFO - 2021-07-14 08:04:21 --> Helper loaded: html_helper
INFO - 2021-07-14 08:04:21 --> Helper loaded: url_helper
INFO - 2021-07-14 08:04:21 --> Helper loaded: form_helper
INFO - 2021-07-14 08:04:21 --> Database Driver Class Initialized
INFO - 2021-07-14 08:04:21 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:04:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:04:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:04:21 --> Encryption Class Initialized
INFO - 2021-07-14 08:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:04:21 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:04:21 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:04:21 --> Model "user_model" initialized
INFO - 2021-07-14 08:04:21 --> Model "role_model" initialized
INFO - 2021-07-14 08:04:21 --> Controller Class Initialized
INFO - 2021-07-14 08:04:21 --> Helper loaded: language_helper
INFO - 2021-07-14 08:04:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:04:21 --> Model "Product_model" initialized
INFO - 2021-07-14 08:04:21 --> Final output sent to browser
DEBUG - 2021-07-14 08:04:21 --> Total execution time: 0.0670
INFO - 2021-07-14 08:04:35 --> Config Class Initialized
INFO - 2021-07-14 08:04:35 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:04:35 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:04:35 --> Utf8 Class Initialized
INFO - 2021-07-14 08:04:35 --> URI Class Initialized
INFO - 2021-07-14 08:04:35 --> Router Class Initialized
INFO - 2021-07-14 08:04:35 --> Output Class Initialized
INFO - 2021-07-14 08:04:35 --> Security Class Initialized
DEBUG - 2021-07-14 08:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:04:35 --> Input Class Initialized
INFO - 2021-07-14 08:04:35 --> Language Class Initialized
INFO - 2021-07-14 08:04:35 --> Loader Class Initialized
INFO - 2021-07-14 08:04:35 --> Helper loaded: html_helper
INFO - 2021-07-14 08:04:35 --> Helper loaded: url_helper
INFO - 2021-07-14 08:04:35 --> Helper loaded: form_helper
INFO - 2021-07-14 08:04:35 --> Database Driver Class Initialized
INFO - 2021-07-14 08:04:35 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:04:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:04:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:04:35 --> Encryption Class Initialized
INFO - 2021-07-14 08:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:04:35 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:04:35 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:04:35 --> Model "user_model" initialized
INFO - 2021-07-14 08:04:35 --> Model "role_model" initialized
INFO - 2021-07-14 08:04:35 --> Controller Class Initialized
INFO - 2021-07-14 08:04:35 --> Helper loaded: language_helper
INFO - 2021-07-14 08:04:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:04:35 --> Model "Product_model" initialized
INFO - 2021-07-14 08:04:35 --> Final output sent to browser
DEBUG - 2021-07-14 08:04:35 --> Total execution time: 0.0599
INFO - 2021-07-14 08:05:23 --> Config Class Initialized
INFO - 2021-07-14 08:05:23 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:05:23 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:05:23 --> Utf8 Class Initialized
INFO - 2021-07-14 08:05:23 --> URI Class Initialized
INFO - 2021-07-14 08:05:23 --> Router Class Initialized
INFO - 2021-07-14 08:05:23 --> Output Class Initialized
INFO - 2021-07-14 08:05:23 --> Security Class Initialized
DEBUG - 2021-07-14 08:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:05:23 --> Input Class Initialized
INFO - 2021-07-14 08:05:23 --> Language Class Initialized
INFO - 2021-07-14 08:05:23 --> Loader Class Initialized
INFO - 2021-07-14 08:05:23 --> Helper loaded: html_helper
INFO - 2021-07-14 08:05:23 --> Helper loaded: url_helper
INFO - 2021-07-14 08:05:23 --> Helper loaded: form_helper
INFO - 2021-07-14 08:05:23 --> Database Driver Class Initialized
INFO - 2021-07-14 08:05:23 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:05:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:05:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:05:23 --> Encryption Class Initialized
INFO - 2021-07-14 08:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:05:23 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:05:23 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:05:23 --> Model "user_model" initialized
INFO - 2021-07-14 08:05:23 --> Model "role_model" initialized
INFO - 2021-07-14 08:05:23 --> Controller Class Initialized
INFO - 2021-07-14 08:05:23 --> Helper loaded: language_helper
INFO - 2021-07-14 08:05:23 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:05:23 --> Model "Product_model" initialized
INFO - 2021-07-14 08:05:23 --> Final output sent to browser
DEBUG - 2021-07-14 08:05:23 --> Total execution time: 0.0664
INFO - 2021-07-14 08:05:52 --> Config Class Initialized
INFO - 2021-07-14 08:05:52 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:05:52 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:05:52 --> Utf8 Class Initialized
INFO - 2021-07-14 08:05:52 --> URI Class Initialized
INFO - 2021-07-14 08:05:52 --> Router Class Initialized
INFO - 2021-07-14 08:05:52 --> Output Class Initialized
INFO - 2021-07-14 08:05:52 --> Security Class Initialized
DEBUG - 2021-07-14 08:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:05:52 --> Input Class Initialized
INFO - 2021-07-14 08:05:52 --> Language Class Initialized
INFO - 2021-07-14 08:05:52 --> Loader Class Initialized
INFO - 2021-07-14 08:05:52 --> Helper loaded: html_helper
INFO - 2021-07-14 08:05:52 --> Helper loaded: url_helper
INFO - 2021-07-14 08:05:52 --> Helper loaded: form_helper
INFO - 2021-07-14 08:05:52 --> Database Driver Class Initialized
INFO - 2021-07-14 08:05:52 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:05:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:05:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:05:52 --> Encryption Class Initialized
INFO - 2021-07-14 08:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:05:52 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:05:52 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:05:52 --> Model "user_model" initialized
INFO - 2021-07-14 08:05:52 --> Model "role_model" initialized
INFO - 2021-07-14 08:05:52 --> Controller Class Initialized
INFO - 2021-07-14 08:05:52 --> Helper loaded: language_helper
INFO - 2021-07-14 08:05:52 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:05:52 --> Model "Quotation_model" initialized
INFO - 2021-07-14 08:05:52 --> Final output sent to browser
DEBUG - 2021-07-14 08:05:52 --> Total execution time: 0.0709
INFO - 2021-07-14 08:05:52 --> Config Class Initialized
INFO - 2021-07-14 08:05:52 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:05:52 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:05:52 --> Utf8 Class Initialized
INFO - 2021-07-14 08:05:52 --> URI Class Initialized
INFO - 2021-07-14 08:05:52 --> Router Class Initialized
INFO - 2021-07-14 08:05:52 --> Output Class Initialized
INFO - 2021-07-14 08:05:52 --> Security Class Initialized
DEBUG - 2021-07-14 08:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:05:52 --> Input Class Initialized
INFO - 2021-07-14 08:05:52 --> Language Class Initialized
INFO - 2021-07-14 08:05:52 --> Loader Class Initialized
INFO - 2021-07-14 08:05:52 --> Helper loaded: html_helper
INFO - 2021-07-14 08:05:52 --> Helper loaded: url_helper
INFO - 2021-07-14 08:05:52 --> Helper loaded: form_helper
INFO - 2021-07-14 08:05:52 --> Database Driver Class Initialized
INFO - 2021-07-14 08:05:52 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:05:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:05:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:05:52 --> Encryption Class Initialized
INFO - 2021-07-14 08:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:05:52 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:05:52 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:05:52 --> Model "user_model" initialized
INFO - 2021-07-14 08:05:52 --> Model "role_model" initialized
INFO - 2021-07-14 08:05:52 --> Controller Class Initialized
INFO - 2021-07-14 08:05:52 --> Helper loaded: language_helper
INFO - 2021-07-14 08:05:52 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:05:52 --> Model "Quotation_model" initialized
INFO - 2021-07-14 08:05:52 --> Final output sent to browser
DEBUG - 2021-07-14 08:05:52 --> Total execution time: 0.0704
INFO - 2021-07-14 08:05:54 --> Config Class Initialized
INFO - 2021-07-14 08:05:54 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:05:54 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:05:54 --> Utf8 Class Initialized
INFO - 2021-07-14 08:05:54 --> URI Class Initialized
INFO - 2021-07-14 08:05:54 --> Router Class Initialized
INFO - 2021-07-14 08:05:54 --> Output Class Initialized
INFO - 2021-07-14 08:05:54 --> Security Class Initialized
DEBUG - 2021-07-14 08:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:05:54 --> Input Class Initialized
INFO - 2021-07-14 08:05:54 --> Language Class Initialized
INFO - 2021-07-14 08:05:54 --> Loader Class Initialized
INFO - 2021-07-14 08:05:54 --> Helper loaded: html_helper
INFO - 2021-07-14 08:05:54 --> Helper loaded: url_helper
INFO - 2021-07-14 08:05:54 --> Helper loaded: form_helper
INFO - 2021-07-14 08:05:54 --> Database Driver Class Initialized
INFO - 2021-07-14 08:05:54 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:05:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:05:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:05:54 --> Encryption Class Initialized
INFO - 2021-07-14 08:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:05:54 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:05:54 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:05:54 --> Model "user_model" initialized
INFO - 2021-07-14 08:05:54 --> Model "role_model" initialized
INFO - 2021-07-14 08:05:54 --> Controller Class Initialized
INFO - 2021-07-14 08:05:54 --> Helper loaded: language_helper
INFO - 2021-07-14 08:05:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:05:54 --> Model "Quotation_model" initialized
INFO - 2021-07-14 08:05:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 08:05:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 08:05:54 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 08:05:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 08:05:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 08:05:54 --> Final output sent to browser
DEBUG - 2021-07-14 08:05:54 --> Total execution time: 0.0742
INFO - 2021-07-14 08:05:54 --> Config Class Initialized
INFO - 2021-07-14 08:05:54 --> Hooks Class Initialized
INFO - 2021-07-14 08:05:54 --> Config Class Initialized
INFO - 2021-07-14 08:05:54 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:05:54 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:05:54 --> Utf8 Class Initialized
INFO - 2021-07-14 08:05:54 --> URI Class Initialized
DEBUG - 2021-07-14 08:05:54 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:05:54 --> Utf8 Class Initialized
INFO - 2021-07-14 08:05:54 --> Router Class Initialized
INFO - 2021-07-14 08:05:54 --> URI Class Initialized
INFO - 2021-07-14 08:05:54 --> Router Class Initialized
INFO - 2021-07-14 08:05:54 --> Output Class Initialized
INFO - 2021-07-14 08:05:54 --> Security Class Initialized
INFO - 2021-07-14 08:05:54 --> Output Class Initialized
DEBUG - 2021-07-14 08:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:05:54 --> Input Class Initialized
INFO - 2021-07-14 08:05:54 --> Security Class Initialized
INFO - 2021-07-14 08:05:54 --> Language Class Initialized
DEBUG - 2021-07-14 08:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:05:54 --> Input Class Initialized
INFO - 2021-07-14 08:05:54 --> Language Class Initialized
INFO - 2021-07-14 08:05:54 --> Loader Class Initialized
INFO - 2021-07-14 08:05:54 --> Helper loaded: html_helper
INFO - 2021-07-14 08:05:54 --> Helper loaded: url_helper
INFO - 2021-07-14 08:05:54 --> Loader Class Initialized
INFO - 2021-07-14 08:05:54 --> Helper loaded: form_helper
INFO - 2021-07-14 08:05:54 --> Helper loaded: html_helper
INFO - 2021-07-14 08:05:54 --> Helper loaded: url_helper
INFO - 2021-07-14 08:05:54 --> Helper loaded: form_helper
INFO - 2021-07-14 08:05:54 --> Database Driver Class Initialized
INFO - 2021-07-14 08:05:54 --> Database Driver Class Initialized
INFO - 2021-07-14 08:05:54 --> Form Validation Class Initialized
INFO - 2021-07-14 08:05:54 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:05:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:05:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:05:54 --> Encryption Class Initialized
DEBUG - 2021-07-14 08:05:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:05:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:05:54 --> Encryption Class Initialized
INFO - 2021-07-14 08:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:05:54 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:05:54 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:05:54 --> Model "user_model" initialized
INFO - 2021-07-14 08:05:54 --> Model "role_model" initialized
INFO - 2021-07-14 08:05:54 --> Controller Class Initialized
INFO - 2021-07-14 08:05:54 --> Helper loaded: language_helper
INFO - 2021-07-14 08:05:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:05:54 --> Model "Quotation_model" initialized
INFO - 2021-07-14 08:05:54 --> Final output sent to browser
DEBUG - 2021-07-14 08:05:54 --> Total execution time: 0.0691
INFO - 2021-07-14 08:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:05:54 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:05:54 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:05:54 --> Model "user_model" initialized
INFO - 2021-07-14 08:05:54 --> Model "role_model" initialized
INFO - 2021-07-14 08:05:54 --> Controller Class Initialized
INFO - 2021-07-14 08:05:54 --> Helper loaded: language_helper
INFO - 2021-07-14 08:05:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:05:54 --> Model "Quotation_model" initialized
INFO - 2021-07-14 08:05:54 --> Final output sent to browser
DEBUG - 2021-07-14 08:05:54 --> Total execution time: 0.0772
INFO - 2021-07-14 08:07:44 --> Config Class Initialized
INFO - 2021-07-14 08:07:44 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:07:44 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:07:44 --> Utf8 Class Initialized
INFO - 2021-07-14 08:07:44 --> URI Class Initialized
INFO - 2021-07-14 08:07:44 --> Router Class Initialized
INFO - 2021-07-14 08:07:44 --> Output Class Initialized
INFO - 2021-07-14 08:07:44 --> Security Class Initialized
DEBUG - 2021-07-14 08:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:07:44 --> Input Class Initialized
INFO - 2021-07-14 08:07:44 --> Language Class Initialized
INFO - 2021-07-14 08:07:44 --> Loader Class Initialized
INFO - 2021-07-14 08:07:44 --> Helper loaded: html_helper
INFO - 2021-07-14 08:07:44 --> Helper loaded: url_helper
INFO - 2021-07-14 08:07:44 --> Helper loaded: form_helper
INFO - 2021-07-14 08:07:44 --> Database Driver Class Initialized
INFO - 2021-07-14 08:07:44 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:07:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:07:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:07:44 --> Encryption Class Initialized
INFO - 2021-07-14 08:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:07:44 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:07:44 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:07:44 --> Model "user_model" initialized
INFO - 2021-07-14 08:07:44 --> Model "role_model" initialized
INFO - 2021-07-14 08:07:44 --> Controller Class Initialized
INFO - 2021-07-14 08:07:44 --> Helper loaded: language_helper
INFO - 2021-07-14 08:07:44 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:07:44 --> Model "Quotation_model" initialized
INFO - 2021-07-14 08:07:44 --> Model "Customer_model" initialized
INFO - 2021-07-14 08:07:44 --> Model "Product_model" initialized
INFO - 2021-07-14 08:07:44 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 08:07:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 08:07:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 08:07:44 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 08:07:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 08:07:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 08:07:44 --> Final output sent to browser
DEBUG - 2021-07-14 08:07:44 --> Total execution time: 0.0811
INFO - 2021-07-14 08:07:53 --> Config Class Initialized
INFO - 2021-07-14 08:07:53 --> Hooks Class Initialized
INFO - 2021-07-14 08:07:53 --> Config Class Initialized
INFO - 2021-07-14 08:07:53 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:07:53 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:07:53 --> Utf8 Class Initialized
DEBUG - 2021-07-14 08:07:53 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:07:53 --> Utf8 Class Initialized
INFO - 2021-07-14 08:07:53 --> URI Class Initialized
INFO - 2021-07-14 08:07:53 --> URI Class Initialized
INFO - 2021-07-14 08:07:53 --> Router Class Initialized
INFO - 2021-07-14 08:07:53 --> Router Class Initialized
INFO - 2021-07-14 08:07:53 --> Output Class Initialized
INFO - 2021-07-14 08:07:53 --> Output Class Initialized
INFO - 2021-07-14 08:07:53 --> Security Class Initialized
INFO - 2021-07-14 08:07:53 --> Security Class Initialized
DEBUG - 2021-07-14 08:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:07:53 --> Input Class Initialized
DEBUG - 2021-07-14 08:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:07:53 --> Input Class Initialized
INFO - 2021-07-14 08:07:53 --> Language Class Initialized
INFO - 2021-07-14 08:07:53 --> Language Class Initialized
INFO - 2021-07-14 08:07:53 --> Loader Class Initialized
INFO - 2021-07-14 08:07:53 --> Loader Class Initialized
INFO - 2021-07-14 08:07:53 --> Helper loaded: html_helper
INFO - 2021-07-14 08:07:53 --> Helper loaded: html_helper
INFO - 2021-07-14 08:07:53 --> Helper loaded: url_helper
INFO - 2021-07-14 08:07:53 --> Helper loaded: url_helper
INFO - 2021-07-14 08:07:53 --> Helper loaded: form_helper
INFO - 2021-07-14 08:07:53 --> Helper loaded: form_helper
INFO - 2021-07-14 08:07:53 --> Database Driver Class Initialized
INFO - 2021-07-14 08:07:53 --> Database Driver Class Initialized
INFO - 2021-07-14 08:07:53 --> Form Validation Class Initialized
INFO - 2021-07-14 08:07:53 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-14 08:07:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:07:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:07:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:07:53 --> Encryption Class Initialized
INFO - 2021-07-14 08:07:53 --> Encryption Class Initialized
INFO - 2021-07-14 08:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:07:53 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:07:53 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:07:53 --> Model "user_model" initialized
INFO - 2021-07-14 08:07:53 --> Model "role_model" initialized
INFO - 2021-07-14 08:07:53 --> Controller Class Initialized
INFO - 2021-07-14 08:07:53 --> Helper loaded: language_helper
INFO - 2021-07-14 08:07:53 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:07:53 --> Model "Quotation_model" initialized
INFO - 2021-07-14 08:07:53 --> Final output sent to browser
DEBUG - 2021-07-14 08:07:53 --> Total execution time: 0.0702
INFO - 2021-07-14 08:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:07:53 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:07:53 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:07:53 --> Model "user_model" initialized
INFO - 2021-07-14 08:07:53 --> Model "role_model" initialized
INFO - 2021-07-14 08:07:53 --> Controller Class Initialized
INFO - 2021-07-14 08:07:53 --> Helper loaded: language_helper
INFO - 2021-07-14 08:07:53 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:07:53 --> Model "Quotation_model" initialized
INFO - 2021-07-14 08:07:53 --> Final output sent to browser
DEBUG - 2021-07-14 08:07:53 --> Total execution time: 0.0801
INFO - 2021-07-14 08:08:01 --> Config Class Initialized
INFO - 2021-07-14 08:08:01 --> Hooks Class Initialized
INFO - 2021-07-14 08:08:01 --> Config Class Initialized
INFO - 2021-07-14 08:08:01 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:08:01 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:08:01 --> Utf8 Class Initialized
DEBUG - 2021-07-14 08:08:01 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:08:01 --> Utf8 Class Initialized
INFO - 2021-07-14 08:08:01 --> URI Class Initialized
INFO - 2021-07-14 08:08:01 --> URI Class Initialized
INFO - 2021-07-14 08:08:01 --> Router Class Initialized
INFO - 2021-07-14 08:08:01 --> Router Class Initialized
INFO - 2021-07-14 08:08:01 --> Output Class Initialized
INFO - 2021-07-14 08:08:01 --> Output Class Initialized
INFO - 2021-07-14 08:08:01 --> Security Class Initialized
INFO - 2021-07-14 08:08:01 --> Security Class Initialized
DEBUG - 2021-07-14 08:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:08:01 --> Input Class Initialized
DEBUG - 2021-07-14 08:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:08:01 --> Input Class Initialized
INFO - 2021-07-14 08:08:01 --> Language Class Initialized
INFO - 2021-07-14 08:08:01 --> Language Class Initialized
INFO - 2021-07-14 08:08:01 --> Loader Class Initialized
INFO - 2021-07-14 08:08:01 --> Loader Class Initialized
INFO - 2021-07-14 08:08:01 --> Helper loaded: html_helper
INFO - 2021-07-14 08:08:01 --> Helper loaded: html_helper
INFO - 2021-07-14 08:08:01 --> Helper loaded: url_helper
INFO - 2021-07-14 08:08:01 --> Helper loaded: url_helper
INFO - 2021-07-14 08:08:01 --> Helper loaded: form_helper
INFO - 2021-07-14 08:08:01 --> Helper loaded: form_helper
INFO - 2021-07-14 08:08:01 --> Database Driver Class Initialized
INFO - 2021-07-14 08:08:01 --> Database Driver Class Initialized
INFO - 2021-07-14 08:08:01 --> Form Validation Class Initialized
INFO - 2021-07-14 08:08:01 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-14 08:08:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:08:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:08:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:08:01 --> Encryption Class Initialized
INFO - 2021-07-14 08:08:01 --> Encryption Class Initialized
INFO - 2021-07-14 08:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:08:01 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:08:01 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:08:01 --> Model "user_model" initialized
INFO - 2021-07-14 08:08:01 --> Model "role_model" initialized
INFO - 2021-07-14 08:08:01 --> Controller Class Initialized
INFO - 2021-07-14 08:08:01 --> Helper loaded: language_helper
INFO - 2021-07-14 08:08:01 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:08:01 --> Model "Quotation_model" initialized
INFO - 2021-07-14 08:08:01 --> Final output sent to browser
DEBUG - 2021-07-14 08:08:01 --> Total execution time: 0.0715
INFO - 2021-07-14 08:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:08:01 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:08:01 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:08:01 --> Model "user_model" initialized
INFO - 2021-07-14 08:08:01 --> Model "role_model" initialized
INFO - 2021-07-14 08:08:01 --> Controller Class Initialized
INFO - 2021-07-14 08:08:01 --> Helper loaded: language_helper
INFO - 2021-07-14 08:08:01 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:08:01 --> Model "Quotation_model" initialized
INFO - 2021-07-14 08:08:01 --> Final output sent to browser
DEBUG - 2021-07-14 08:08:01 --> Total execution time: 0.0817
INFO - 2021-07-14 08:08:38 --> Config Class Initialized
INFO - 2021-07-14 08:08:38 --> Config Class Initialized
INFO - 2021-07-14 08:08:38 --> Hooks Class Initialized
INFO - 2021-07-14 08:08:38 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:08:38 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 08:08:38 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:08:38 --> Utf8 Class Initialized
INFO - 2021-07-14 08:08:38 --> Utf8 Class Initialized
INFO - 2021-07-14 08:08:38 --> URI Class Initialized
INFO - 2021-07-14 08:08:38 --> URI Class Initialized
INFO - 2021-07-14 08:08:38 --> Router Class Initialized
INFO - 2021-07-14 08:08:38 --> Router Class Initialized
INFO - 2021-07-14 08:08:38 --> Output Class Initialized
INFO - 2021-07-14 08:08:38 --> Output Class Initialized
INFO - 2021-07-14 08:08:38 --> Security Class Initialized
INFO - 2021-07-14 08:08:38 --> Security Class Initialized
DEBUG - 2021-07-14 08:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 08:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:08:38 --> Input Class Initialized
INFO - 2021-07-14 08:08:38 --> Input Class Initialized
INFO - 2021-07-14 08:08:38 --> Language Class Initialized
INFO - 2021-07-14 08:08:38 --> Language Class Initialized
INFO - 2021-07-14 08:08:38 --> Loader Class Initialized
INFO - 2021-07-14 08:08:38 --> Loader Class Initialized
INFO - 2021-07-14 08:08:38 --> Helper loaded: html_helper
INFO - 2021-07-14 08:08:38 --> Helper loaded: html_helper
INFO - 2021-07-14 08:08:38 --> Helper loaded: url_helper
INFO - 2021-07-14 08:08:38 --> Helper loaded: url_helper
INFO - 2021-07-14 08:08:38 --> Helper loaded: form_helper
INFO - 2021-07-14 08:08:38 --> Helper loaded: form_helper
INFO - 2021-07-14 08:08:38 --> Database Driver Class Initialized
INFO - 2021-07-14 08:08:38 --> Database Driver Class Initialized
INFO - 2021-07-14 08:08:38 --> Form Validation Class Initialized
INFO - 2021-07-14 08:08:38 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-14 08:08:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:08:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:08:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:08:38 --> Encryption Class Initialized
INFO - 2021-07-14 08:08:38 --> Encryption Class Initialized
INFO - 2021-07-14 08:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:08:38 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:08:38 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:08:38 --> Model "user_model" initialized
INFO - 2021-07-14 08:08:38 --> Model "role_model" initialized
INFO - 2021-07-14 08:08:38 --> Controller Class Initialized
INFO - 2021-07-14 08:08:38 --> Helper loaded: language_helper
INFO - 2021-07-14 08:08:38 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:08:38 --> Model "Quotation_model" initialized
INFO - 2021-07-14 08:08:38 --> Final output sent to browser
DEBUG - 2021-07-14 08:08:38 --> Total execution time: 0.0718
INFO - 2021-07-14 08:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:08:38 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:08:38 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:08:38 --> Model "user_model" initialized
INFO - 2021-07-14 08:08:38 --> Model "role_model" initialized
INFO - 2021-07-14 08:08:38 --> Controller Class Initialized
INFO - 2021-07-14 08:08:38 --> Helper loaded: language_helper
INFO - 2021-07-14 08:08:38 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:08:38 --> Model "Quotation_model" initialized
INFO - 2021-07-14 08:08:38 --> Final output sent to browser
DEBUG - 2021-07-14 08:08:38 --> Total execution time: 0.0821
INFO - 2021-07-14 08:09:01 --> Config Class Initialized
INFO - 2021-07-14 08:09:01 --> Config Class Initialized
INFO - 2021-07-14 08:09:01 --> Hooks Class Initialized
INFO - 2021-07-14 08:09:01 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:09:01 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:09:01 --> Utf8 Class Initialized
INFO - 2021-07-14 08:09:01 --> URI Class Initialized
INFO - 2021-07-14 08:09:01 --> Router Class Initialized
INFO - 2021-07-14 08:09:01 --> Output Class Initialized
DEBUG - 2021-07-14 08:09:01 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:09:01 --> Utf8 Class Initialized
INFO - 2021-07-14 08:09:01 --> URI Class Initialized
INFO - 2021-07-14 08:09:01 --> Security Class Initialized
INFO - 2021-07-14 08:09:01 --> Router Class Initialized
DEBUG - 2021-07-14 08:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:09:01 --> Input Class Initialized
INFO - 2021-07-14 08:09:01 --> Language Class Initialized
INFO - 2021-07-14 08:09:01 --> Output Class Initialized
INFO - 2021-07-14 08:09:01 --> Security Class Initialized
INFO - 2021-07-14 08:09:01 --> Loader Class Initialized
DEBUG - 2021-07-14 08:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:09:01 --> Input Class Initialized
INFO - 2021-07-14 08:09:01 --> Language Class Initialized
INFO - 2021-07-14 08:09:01 --> Helper loaded: html_helper
INFO - 2021-07-14 08:09:01 --> Helper loaded: url_helper
INFO - 2021-07-14 08:09:01 --> Helper loaded: form_helper
INFO - 2021-07-14 08:09:01 --> Loader Class Initialized
INFO - 2021-07-14 08:09:01 --> Helper loaded: html_helper
INFO - 2021-07-14 08:09:01 --> Helper loaded: url_helper
INFO - 2021-07-14 08:09:01 --> Helper loaded: form_helper
INFO - 2021-07-14 08:09:01 --> Database Driver Class Initialized
INFO - 2021-07-14 08:09:01 --> Database Driver Class Initialized
INFO - 2021-07-14 08:09:01 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:09:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:09:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:09:01 --> Form Validation Class Initialized
INFO - 2021-07-14 08:09:01 --> Encryption Class Initialized
DEBUG - 2021-07-14 08:09:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:09:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:09:01 --> Encryption Class Initialized
INFO - 2021-07-14 08:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:09:01 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:09:01 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:09:01 --> Model "user_model" initialized
INFO - 2021-07-14 08:09:01 --> Model "role_model" initialized
INFO - 2021-07-14 08:09:01 --> Controller Class Initialized
INFO - 2021-07-14 08:09:01 --> Helper loaded: language_helper
INFO - 2021-07-14 08:09:01 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:09:01 --> Model "Quotation_model" initialized
INFO - 2021-07-14 08:09:01 --> Final output sent to browser
DEBUG - 2021-07-14 08:09:01 --> Total execution time: 0.0695
INFO - 2021-07-14 08:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:09:01 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:09:01 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:09:01 --> Model "user_model" initialized
INFO - 2021-07-14 08:09:01 --> Model "role_model" initialized
INFO - 2021-07-14 08:09:01 --> Controller Class Initialized
INFO - 2021-07-14 08:09:01 --> Helper loaded: language_helper
INFO - 2021-07-14 08:09:01 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:09:01 --> Model "Quotation_model" initialized
INFO - 2021-07-14 08:09:01 --> Final output sent to browser
DEBUG - 2021-07-14 08:09:01 --> Total execution time: 0.0796
INFO - 2021-07-14 08:09:05 --> Config Class Initialized
INFO - 2021-07-14 08:09:05 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:09:05 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:09:05 --> Utf8 Class Initialized
INFO - 2021-07-14 08:09:05 --> URI Class Initialized
INFO - 2021-07-14 08:09:05 --> Router Class Initialized
INFO - 2021-07-14 08:09:05 --> Output Class Initialized
INFO - 2021-07-14 08:09:05 --> Security Class Initialized
DEBUG - 2021-07-14 08:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:09:05 --> Input Class Initialized
INFO - 2021-07-14 08:09:05 --> Language Class Initialized
INFO - 2021-07-14 08:09:05 --> Loader Class Initialized
INFO - 2021-07-14 08:09:05 --> Helper loaded: html_helper
INFO - 2021-07-14 08:09:05 --> Helper loaded: url_helper
INFO - 2021-07-14 08:09:05 --> Helper loaded: form_helper
INFO - 2021-07-14 08:09:05 --> Database Driver Class Initialized
INFO - 2021-07-14 08:09:06 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:09:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:09:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:09:06 --> Encryption Class Initialized
INFO - 2021-07-14 08:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:09:06 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:09:06 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:09:06 --> Model "user_model" initialized
INFO - 2021-07-14 08:09:06 --> Model "role_model" initialized
INFO - 2021-07-14 08:09:06 --> Controller Class Initialized
INFO - 2021-07-14 08:09:06 --> Helper loaded: language_helper
INFO - 2021-07-14 08:09:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:09:06 --> Model "Quotation_model" initialized
INFO - 2021-07-14 08:09:06 --> Final output sent to browser
DEBUG - 2021-07-14 08:09:06 --> Total execution time: 0.0724
INFO - 2021-07-14 08:09:10 --> Config Class Initialized
INFO - 2021-07-14 08:09:10 --> Config Class Initialized
INFO - 2021-07-14 08:09:10 --> Hooks Class Initialized
INFO - 2021-07-14 08:09:10 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:09:10 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 08:09:10 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:09:10 --> Utf8 Class Initialized
INFO - 2021-07-14 08:09:10 --> Utf8 Class Initialized
INFO - 2021-07-14 08:09:10 --> URI Class Initialized
INFO - 2021-07-14 08:09:10 --> URI Class Initialized
INFO - 2021-07-14 08:09:10 --> Router Class Initialized
INFO - 2021-07-14 08:09:10 --> Router Class Initialized
INFO - 2021-07-14 08:09:10 --> Output Class Initialized
INFO - 2021-07-14 08:09:10 --> Output Class Initialized
INFO - 2021-07-14 08:09:10 --> Security Class Initialized
INFO - 2021-07-14 08:09:10 --> Security Class Initialized
DEBUG - 2021-07-14 08:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:09:10 --> Input Class Initialized
DEBUG - 2021-07-14 08:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:09:10 --> Input Class Initialized
INFO - 2021-07-14 08:09:10 --> Language Class Initialized
INFO - 2021-07-14 08:09:10 --> Language Class Initialized
INFO - 2021-07-14 08:09:10 --> Loader Class Initialized
INFO - 2021-07-14 08:09:10 --> Loader Class Initialized
INFO - 2021-07-14 08:09:10 --> Helper loaded: html_helper
INFO - 2021-07-14 08:09:10 --> Helper loaded: html_helper
INFO - 2021-07-14 08:09:10 --> Helper loaded: url_helper
INFO - 2021-07-14 08:09:10 --> Helper loaded: url_helper
INFO - 2021-07-14 08:09:10 --> Helper loaded: form_helper
INFO - 2021-07-14 08:09:10 --> Helper loaded: form_helper
INFO - 2021-07-14 08:09:10 --> Database Driver Class Initialized
INFO - 2021-07-14 08:09:10 --> Database Driver Class Initialized
INFO - 2021-07-14 08:09:10 --> Form Validation Class Initialized
INFO - 2021-07-14 08:09:10 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-14 08:09:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:09:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:09:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:09:10 --> Encryption Class Initialized
INFO - 2021-07-14 08:09:10 --> Encryption Class Initialized
INFO - 2021-07-14 08:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:09:10 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:09:10 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:09:10 --> Model "user_model" initialized
INFO - 2021-07-14 08:09:10 --> Model "role_model" initialized
INFO - 2021-07-14 08:09:10 --> Controller Class Initialized
INFO - 2021-07-14 08:09:10 --> Helper loaded: language_helper
INFO - 2021-07-14 08:09:10 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:09:10 --> Model "Quotation_model" initialized
INFO - 2021-07-14 08:09:10 --> Final output sent to browser
DEBUG - 2021-07-14 08:09:10 --> Total execution time: 0.0638
INFO - 2021-07-14 08:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:09:10 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:09:10 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:09:10 --> Model "user_model" initialized
INFO - 2021-07-14 08:09:10 --> Model "role_model" initialized
INFO - 2021-07-14 08:09:10 --> Controller Class Initialized
INFO - 2021-07-14 08:09:10 --> Helper loaded: language_helper
INFO - 2021-07-14 08:09:10 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:09:10 --> Model "Quotation_model" initialized
INFO - 2021-07-14 08:09:10 --> Final output sent to browser
DEBUG - 2021-07-14 08:09:10 --> Total execution time: 0.0723
INFO - 2021-07-14 08:09:13 --> Config Class Initialized
INFO - 2021-07-14 08:09:13 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:09:13 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:09:13 --> Utf8 Class Initialized
INFO - 2021-07-14 08:09:13 --> URI Class Initialized
INFO - 2021-07-14 08:09:13 --> Router Class Initialized
INFO - 2021-07-14 08:09:13 --> Output Class Initialized
INFO - 2021-07-14 08:09:13 --> Security Class Initialized
DEBUG - 2021-07-14 08:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:09:13 --> Input Class Initialized
INFO - 2021-07-14 08:09:13 --> Language Class Initialized
INFO - 2021-07-14 08:09:13 --> Loader Class Initialized
INFO - 2021-07-14 08:09:13 --> Helper loaded: html_helper
INFO - 2021-07-14 08:09:13 --> Helper loaded: url_helper
INFO - 2021-07-14 08:09:13 --> Helper loaded: form_helper
INFO - 2021-07-14 08:09:13 --> Database Driver Class Initialized
INFO - 2021-07-14 08:09:13 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:09:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:09:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:09:13 --> Encryption Class Initialized
INFO - 2021-07-14 08:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:09:13 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:09:13 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:09:13 --> Model "user_model" initialized
INFO - 2021-07-14 08:09:13 --> Model "role_model" initialized
INFO - 2021-07-14 08:09:13 --> Controller Class Initialized
INFO - 2021-07-14 08:09:13 --> Helper loaded: language_helper
INFO - 2021-07-14 08:09:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:09:13 --> Model "Quotation_model" initialized
INFO - 2021-07-14 08:09:13 --> Final output sent to browser
DEBUG - 2021-07-14 08:09:13 --> Total execution time: 0.0622
INFO - 2021-07-14 08:10:24 --> Config Class Initialized
INFO - 2021-07-14 08:10:24 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:10:24 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:10:24 --> Utf8 Class Initialized
INFO - 2021-07-14 08:10:24 --> URI Class Initialized
INFO - 2021-07-14 08:10:24 --> Router Class Initialized
INFO - 2021-07-14 08:10:24 --> Output Class Initialized
INFO - 2021-07-14 08:10:24 --> Security Class Initialized
DEBUG - 2021-07-14 08:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:10:24 --> Input Class Initialized
INFO - 2021-07-14 08:10:24 --> Language Class Initialized
INFO - 2021-07-14 08:10:24 --> Loader Class Initialized
INFO - 2021-07-14 08:10:24 --> Helper loaded: html_helper
INFO - 2021-07-14 08:10:24 --> Helper loaded: url_helper
INFO - 2021-07-14 08:10:24 --> Helper loaded: form_helper
INFO - 2021-07-14 08:10:24 --> Database Driver Class Initialized
INFO - 2021-07-14 08:10:24 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:10:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:10:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:10:24 --> Encryption Class Initialized
INFO - 2021-07-14 08:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:10:24 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:10:24 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:10:24 --> Model "user_model" initialized
INFO - 2021-07-14 08:10:24 --> Model "role_model" initialized
INFO - 2021-07-14 08:10:24 --> Controller Class Initialized
INFO - 2021-07-14 08:10:24 --> Helper loaded: language_helper
INFO - 2021-07-14 08:10:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:10:24 --> Model "Quotation_model" initialized
INFO - 2021-07-14 08:10:24 --> Model "Customer_model" initialized
INFO - 2021-07-14 08:10:24 --> Model "Product_model" initialized
INFO - 2021-07-14 08:10:24 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 08:10:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 08:10:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 08:10:24 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 08:10:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 08:10:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 08:10:24 --> Final output sent to browser
DEBUG - 2021-07-14 08:10:24 --> Total execution time: 0.0840
INFO - 2021-07-14 08:29:01 --> Config Class Initialized
INFO - 2021-07-14 08:29:01 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:29:01 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:29:01 --> Utf8 Class Initialized
INFO - 2021-07-14 08:29:01 --> URI Class Initialized
INFO - 2021-07-14 08:29:01 --> Router Class Initialized
INFO - 2021-07-14 08:29:01 --> Output Class Initialized
INFO - 2021-07-14 08:29:01 --> Security Class Initialized
DEBUG - 2021-07-14 08:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:29:01 --> Input Class Initialized
INFO - 2021-07-14 08:29:01 --> Language Class Initialized
INFO - 2021-07-14 08:29:01 --> Loader Class Initialized
INFO - 2021-07-14 08:29:01 --> Helper loaded: html_helper
INFO - 2021-07-14 08:29:01 --> Helper loaded: url_helper
INFO - 2021-07-14 08:29:01 --> Helper loaded: form_helper
INFO - 2021-07-14 08:29:01 --> Database Driver Class Initialized
INFO - 2021-07-14 08:29:01 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:29:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:29:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:29:01 --> Encryption Class Initialized
INFO - 2021-07-14 08:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:29:01 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:29:01 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:29:01 --> Model "user_model" initialized
INFO - 2021-07-14 08:29:01 --> Model "role_model" initialized
INFO - 2021-07-14 08:29:01 --> Controller Class Initialized
INFO - 2021-07-14 08:29:01 --> Helper loaded: language_helper
INFO - 2021-07-14 08:29:01 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:29:01 --> Model "Quotation_model" initialized
INFO - 2021-07-14 08:29:01 --> Model "Customer_model" initialized
INFO - 2021-07-14 08:29:01 --> Model "Product_model" initialized
INFO - 2021-07-14 08:29:01 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 08:29:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 08:29:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 08:29:01 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 08:29:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 08:29:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 08:29:01 --> Final output sent to browser
DEBUG - 2021-07-14 08:29:01 --> Total execution time: 0.1189
INFO - 2021-07-14 08:31:53 --> Config Class Initialized
INFO - 2021-07-14 08:31:53 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:31:53 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:31:53 --> Utf8 Class Initialized
INFO - 2021-07-14 08:31:53 --> URI Class Initialized
INFO - 2021-07-14 08:31:53 --> Router Class Initialized
INFO - 2021-07-14 08:31:53 --> Output Class Initialized
INFO - 2021-07-14 08:31:53 --> Security Class Initialized
DEBUG - 2021-07-14 08:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:31:53 --> Input Class Initialized
INFO - 2021-07-14 08:31:53 --> Language Class Initialized
INFO - 2021-07-14 08:31:53 --> Loader Class Initialized
INFO - 2021-07-14 08:31:53 --> Helper loaded: html_helper
INFO - 2021-07-14 08:31:53 --> Helper loaded: url_helper
INFO - 2021-07-14 08:31:53 --> Helper loaded: form_helper
INFO - 2021-07-14 08:31:53 --> Database Driver Class Initialized
INFO - 2021-07-14 08:31:53 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:31:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:31:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:31:53 --> Encryption Class Initialized
INFO - 2021-07-14 08:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:31:53 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:31:53 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:31:53 --> Model "user_model" initialized
INFO - 2021-07-14 08:31:53 --> Model "role_model" initialized
INFO - 2021-07-14 08:31:53 --> Controller Class Initialized
INFO - 2021-07-14 08:31:53 --> Helper loaded: language_helper
INFO - 2021-07-14 08:31:53 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:31:53 --> Model "Customer_model" initialized
INFO - 2021-07-14 08:31:53 --> Model "Product_model" initialized
INFO - 2021-07-14 08:31:53 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 08:31:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 08:31:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 08:31:53 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 08:31:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 08:31:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 08:31:53 --> Final output sent to browser
DEBUG - 2021-07-14 08:31:53 --> Total execution time: 0.0790
INFO - 2021-07-14 08:31:57 --> Config Class Initialized
INFO - 2021-07-14 08:31:57 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:31:57 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:31:57 --> Utf8 Class Initialized
INFO - 2021-07-14 08:31:57 --> URI Class Initialized
INFO - 2021-07-14 08:31:57 --> Router Class Initialized
INFO - 2021-07-14 08:31:57 --> Output Class Initialized
INFO - 2021-07-14 08:31:57 --> Security Class Initialized
DEBUG - 2021-07-14 08:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:31:57 --> Input Class Initialized
INFO - 2021-07-14 08:31:57 --> Language Class Initialized
INFO - 2021-07-14 08:31:57 --> Loader Class Initialized
INFO - 2021-07-14 08:31:57 --> Helper loaded: html_helper
INFO - 2021-07-14 08:31:57 --> Helper loaded: url_helper
INFO - 2021-07-14 08:31:57 --> Helper loaded: form_helper
INFO - 2021-07-14 08:31:57 --> Database Driver Class Initialized
INFO - 2021-07-14 08:31:57 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:31:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:31:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:31:57 --> Encryption Class Initialized
INFO - 2021-07-14 08:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:31:57 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:31:57 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:31:57 --> Model "user_model" initialized
INFO - 2021-07-14 08:31:57 --> Model "role_model" initialized
INFO - 2021-07-14 08:31:57 --> Controller Class Initialized
INFO - 2021-07-14 08:31:57 --> Helper loaded: language_helper
INFO - 2021-07-14 08:31:57 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:31:57 --> Model "Product_model" initialized
INFO - 2021-07-14 08:31:57 --> Final output sent to browser
DEBUG - 2021-07-14 08:31:57 --> Total execution time: 0.0634
INFO - 2021-07-14 08:36:13 --> Config Class Initialized
INFO - 2021-07-14 08:36:13 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:36:13 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:36:13 --> Utf8 Class Initialized
INFO - 2021-07-14 08:36:13 --> URI Class Initialized
INFO - 2021-07-14 08:36:13 --> Router Class Initialized
INFO - 2021-07-14 08:36:13 --> Output Class Initialized
INFO - 2021-07-14 08:36:13 --> Security Class Initialized
DEBUG - 2021-07-14 08:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:36:13 --> Input Class Initialized
INFO - 2021-07-14 08:36:13 --> Language Class Initialized
INFO - 2021-07-14 08:36:13 --> Loader Class Initialized
INFO - 2021-07-14 08:36:13 --> Helper loaded: html_helper
INFO - 2021-07-14 08:36:13 --> Helper loaded: url_helper
INFO - 2021-07-14 08:36:13 --> Helper loaded: form_helper
INFO - 2021-07-14 08:36:13 --> Database Driver Class Initialized
INFO - 2021-07-14 08:36:13 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:36:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:36:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:36:13 --> Encryption Class Initialized
INFO - 2021-07-14 08:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:36:13 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:36:13 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:36:13 --> Model "user_model" initialized
INFO - 2021-07-14 08:36:13 --> Model "role_model" initialized
INFO - 2021-07-14 08:36:13 --> Controller Class Initialized
INFO - 2021-07-14 08:36:13 --> Helper loaded: language_helper
INFO - 2021-07-14 08:36:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:36:13 --> Model "Product_model" initialized
INFO - 2021-07-14 08:36:13 --> Final output sent to browser
DEBUG - 2021-07-14 08:36:13 --> Total execution time: 0.0697
INFO - 2021-07-14 08:36:15 --> Config Class Initialized
INFO - 2021-07-14 08:36:15 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:36:15 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:36:15 --> Utf8 Class Initialized
INFO - 2021-07-14 08:36:15 --> URI Class Initialized
INFO - 2021-07-14 08:36:15 --> Router Class Initialized
INFO - 2021-07-14 08:36:15 --> Output Class Initialized
INFO - 2021-07-14 08:36:15 --> Security Class Initialized
DEBUG - 2021-07-14 08:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:36:15 --> Input Class Initialized
INFO - 2021-07-14 08:36:15 --> Language Class Initialized
INFO - 2021-07-14 08:36:15 --> Loader Class Initialized
INFO - 2021-07-14 08:36:15 --> Helper loaded: html_helper
INFO - 2021-07-14 08:36:15 --> Helper loaded: url_helper
INFO - 2021-07-14 08:36:15 --> Helper loaded: form_helper
INFO - 2021-07-14 08:36:15 --> Database Driver Class Initialized
INFO - 2021-07-14 08:36:15 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:36:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:36:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:36:15 --> Encryption Class Initialized
INFO - 2021-07-14 08:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:36:15 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:36:15 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:36:15 --> Model "user_model" initialized
INFO - 2021-07-14 08:36:15 --> Model "role_model" initialized
INFO - 2021-07-14 08:36:15 --> Controller Class Initialized
INFO - 2021-07-14 08:36:15 --> Helper loaded: language_helper
INFO - 2021-07-14 08:36:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:36:15 --> Model "Product_model" initialized
INFO - 2021-07-14 08:36:15 --> Final output sent to browser
DEBUG - 2021-07-14 08:36:15 --> Total execution time: 0.0629
INFO - 2021-07-14 08:36:30 --> Config Class Initialized
INFO - 2021-07-14 08:36:30 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:36:30 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:36:30 --> Utf8 Class Initialized
INFO - 2021-07-14 08:36:30 --> URI Class Initialized
INFO - 2021-07-14 08:36:30 --> Router Class Initialized
INFO - 2021-07-14 08:36:30 --> Output Class Initialized
INFO - 2021-07-14 08:36:30 --> Security Class Initialized
DEBUG - 2021-07-14 08:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:36:30 --> Input Class Initialized
INFO - 2021-07-14 08:36:30 --> Language Class Initialized
INFO - 2021-07-14 08:36:30 --> Loader Class Initialized
INFO - 2021-07-14 08:36:30 --> Helper loaded: html_helper
INFO - 2021-07-14 08:36:30 --> Helper loaded: url_helper
INFO - 2021-07-14 08:36:30 --> Helper loaded: form_helper
INFO - 2021-07-14 08:36:30 --> Database Driver Class Initialized
INFO - 2021-07-14 08:36:30 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:36:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:36:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:36:30 --> Encryption Class Initialized
INFO - 2021-07-14 08:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:36:30 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:36:30 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:36:30 --> Model "user_model" initialized
INFO - 2021-07-14 08:36:30 --> Model "role_model" initialized
INFO - 2021-07-14 08:36:30 --> Controller Class Initialized
INFO - 2021-07-14 08:36:30 --> Helper loaded: language_helper
INFO - 2021-07-14 08:36:30 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:36:30 --> Model "Customer_model" initialized
INFO - 2021-07-14 08:36:30 --> Model "Product_model" initialized
INFO - 2021-07-14 08:36:30 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 08:36:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 08:36:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 08:36:30 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 08:36:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 08:36:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 08:36:30 --> Final output sent to browser
DEBUG - 2021-07-14 08:36:30 --> Total execution time: 0.0713
INFO - 2021-07-14 08:36:40 --> Config Class Initialized
INFO - 2021-07-14 08:36:40 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:36:40 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:36:40 --> Utf8 Class Initialized
INFO - 2021-07-14 08:36:40 --> URI Class Initialized
INFO - 2021-07-14 08:36:40 --> Router Class Initialized
INFO - 2021-07-14 08:36:40 --> Output Class Initialized
INFO - 2021-07-14 08:36:40 --> Security Class Initialized
DEBUG - 2021-07-14 08:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:36:40 --> Input Class Initialized
INFO - 2021-07-14 08:36:40 --> Language Class Initialized
INFO - 2021-07-14 08:36:40 --> Loader Class Initialized
INFO - 2021-07-14 08:36:40 --> Helper loaded: html_helper
INFO - 2021-07-14 08:36:40 --> Helper loaded: url_helper
INFO - 2021-07-14 08:36:40 --> Helper loaded: form_helper
INFO - 2021-07-14 08:36:40 --> Database Driver Class Initialized
INFO - 2021-07-14 08:36:40 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:36:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:36:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:36:40 --> Encryption Class Initialized
INFO - 2021-07-14 08:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:36:40 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:36:40 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:36:40 --> Model "user_model" initialized
INFO - 2021-07-14 08:36:40 --> Model "role_model" initialized
INFO - 2021-07-14 08:36:40 --> Controller Class Initialized
INFO - 2021-07-14 08:36:40 --> Helper loaded: language_helper
INFO - 2021-07-14 08:36:40 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:36:40 --> Model "Product_model" initialized
INFO - 2021-07-14 08:36:40 --> Final output sent to browser
DEBUG - 2021-07-14 08:36:40 --> Total execution time: 0.0615
INFO - 2021-07-14 08:38:30 --> Config Class Initialized
INFO - 2021-07-14 08:38:30 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:38:30 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:38:30 --> Utf8 Class Initialized
INFO - 2021-07-14 08:38:30 --> URI Class Initialized
INFO - 2021-07-14 08:38:30 --> Router Class Initialized
INFO - 2021-07-14 08:38:30 --> Output Class Initialized
INFO - 2021-07-14 08:38:30 --> Security Class Initialized
DEBUG - 2021-07-14 08:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:38:30 --> Input Class Initialized
INFO - 2021-07-14 08:38:30 --> Language Class Initialized
INFO - 2021-07-14 08:38:30 --> Loader Class Initialized
INFO - 2021-07-14 08:38:30 --> Helper loaded: html_helper
INFO - 2021-07-14 08:38:30 --> Helper loaded: url_helper
INFO - 2021-07-14 08:38:30 --> Helper loaded: form_helper
INFO - 2021-07-14 08:38:30 --> Database Driver Class Initialized
INFO - 2021-07-14 08:38:30 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:38:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:38:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:38:30 --> Encryption Class Initialized
INFO - 2021-07-14 08:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:38:30 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:38:30 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:38:30 --> Model "user_model" initialized
INFO - 2021-07-14 08:38:30 --> Model "role_model" initialized
INFO - 2021-07-14 08:38:30 --> Controller Class Initialized
INFO - 2021-07-14 08:38:30 --> Helper loaded: language_helper
INFO - 2021-07-14 08:38:30 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:38:30 --> Model "Product_model" initialized
INFO - 2021-07-14 08:38:30 --> Final output sent to browser
DEBUG - 2021-07-14 08:38:30 --> Total execution time: 0.0692
INFO - 2021-07-14 08:38:31 --> Config Class Initialized
INFO - 2021-07-14 08:38:31 --> Hooks Class Initialized
DEBUG - 2021-07-14 08:38:31 --> UTF-8 Support Enabled
INFO - 2021-07-14 08:38:31 --> Utf8 Class Initialized
INFO - 2021-07-14 08:38:31 --> URI Class Initialized
INFO - 2021-07-14 08:38:31 --> Router Class Initialized
INFO - 2021-07-14 08:38:31 --> Output Class Initialized
INFO - 2021-07-14 08:38:31 --> Security Class Initialized
DEBUG - 2021-07-14 08:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 08:38:31 --> Input Class Initialized
INFO - 2021-07-14 08:38:31 --> Language Class Initialized
INFO - 2021-07-14 08:38:31 --> Loader Class Initialized
INFO - 2021-07-14 08:38:31 --> Helper loaded: html_helper
INFO - 2021-07-14 08:38:31 --> Helper loaded: url_helper
INFO - 2021-07-14 08:38:31 --> Helper loaded: form_helper
INFO - 2021-07-14 08:38:31 --> Database Driver Class Initialized
INFO - 2021-07-14 08:38:31 --> Form Validation Class Initialized
DEBUG - 2021-07-14 08:38:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 08:38:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 08:38:31 --> Encryption Class Initialized
INFO - 2021-07-14 08:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 08:38:31 --> Model "vendor_model" initialized
INFO - 2021-07-14 08:38:31 --> Model "coupon_model" initialized
INFO - 2021-07-14 08:38:31 --> Model "user_model" initialized
INFO - 2021-07-14 08:38:31 --> Model "role_model" initialized
INFO - 2021-07-14 08:38:31 --> Controller Class Initialized
INFO - 2021-07-14 08:38:31 --> Helper loaded: language_helper
INFO - 2021-07-14 08:38:31 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 08:38:31 --> Model "Product_model" initialized
INFO - 2021-07-14 08:38:31 --> Final output sent to browser
DEBUG - 2021-07-14 08:38:31 --> Total execution time: 0.0604
INFO - 2021-07-14 09:18:44 --> Config Class Initialized
INFO - 2021-07-14 09:18:44 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:18:44 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:18:44 --> Utf8 Class Initialized
INFO - 2021-07-14 09:18:44 --> URI Class Initialized
INFO - 2021-07-14 09:18:44 --> Router Class Initialized
INFO - 2021-07-14 09:18:44 --> Output Class Initialized
INFO - 2021-07-14 09:18:44 --> Security Class Initialized
DEBUG - 2021-07-14 09:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:18:44 --> Input Class Initialized
INFO - 2021-07-14 09:18:44 --> Language Class Initialized
INFO - 2021-07-14 09:18:44 --> Loader Class Initialized
INFO - 2021-07-14 09:18:44 --> Helper loaded: html_helper
INFO - 2021-07-14 09:18:44 --> Helper loaded: url_helper
INFO - 2021-07-14 09:18:44 --> Helper loaded: form_helper
INFO - 2021-07-14 09:18:44 --> Database Driver Class Initialized
INFO - 2021-07-14 09:18:44 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:18:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:18:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:18:44 --> Encryption Class Initialized
INFO - 2021-07-14 09:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:18:44 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:18:44 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:18:44 --> Model "user_model" initialized
INFO - 2021-07-14 09:18:44 --> Model "role_model" initialized
INFO - 2021-07-14 09:18:44 --> Controller Class Initialized
INFO - 2021-07-14 09:18:44 --> Helper loaded: language_helper
INFO - 2021-07-14 09:18:44 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:18:44 --> Model "Customer_model" initialized
INFO - 2021-07-14 09:18:44 --> Model "Product_model" initialized
INFO - 2021-07-14 09:18:44 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 09:18:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 09:18:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 09:18:44 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 09:18:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 09:18:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 09:18:44 --> Final output sent to browser
DEBUG - 2021-07-14 09:18:44 --> Total execution time: 0.1234
INFO - 2021-07-14 09:21:11 --> Config Class Initialized
INFO - 2021-07-14 09:21:11 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:21:11 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:21:11 --> Utf8 Class Initialized
INFO - 2021-07-14 09:21:11 --> URI Class Initialized
INFO - 2021-07-14 09:21:11 --> Router Class Initialized
INFO - 2021-07-14 09:21:11 --> Output Class Initialized
INFO - 2021-07-14 09:21:11 --> Security Class Initialized
DEBUG - 2021-07-14 09:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:21:11 --> Input Class Initialized
INFO - 2021-07-14 09:21:11 --> Language Class Initialized
INFO - 2021-07-14 09:21:11 --> Loader Class Initialized
INFO - 2021-07-14 09:21:11 --> Helper loaded: html_helper
INFO - 2021-07-14 09:21:11 --> Helper loaded: url_helper
INFO - 2021-07-14 09:21:11 --> Helper loaded: form_helper
INFO - 2021-07-14 09:21:11 --> Database Driver Class Initialized
INFO - 2021-07-14 09:21:11 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:21:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:21:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:21:11 --> Encryption Class Initialized
INFO - 2021-07-14 09:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:21:11 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:21:11 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:21:11 --> Model "user_model" initialized
INFO - 2021-07-14 09:21:11 --> Model "role_model" initialized
INFO - 2021-07-14 09:21:11 --> Controller Class Initialized
INFO - 2021-07-14 09:21:11 --> Helper loaded: language_helper
INFO - 2021-07-14 09:21:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:21:11 --> Model "Customer_model" initialized
INFO - 2021-07-14 09:21:11 --> Model "Product_model" initialized
INFO - 2021-07-14 09:21:11 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 09:21:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 09:21:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 09:21:11 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 09:21:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 09:21:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 09:21:11 --> Final output sent to browser
DEBUG - 2021-07-14 09:21:11 --> Total execution time: 0.0875
INFO - 2021-07-14 09:25:07 --> Config Class Initialized
INFO - 2021-07-14 09:25:07 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:25:07 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:25:07 --> Utf8 Class Initialized
INFO - 2021-07-14 09:25:07 --> URI Class Initialized
INFO - 2021-07-14 09:25:07 --> Router Class Initialized
INFO - 2021-07-14 09:25:07 --> Output Class Initialized
INFO - 2021-07-14 09:25:07 --> Security Class Initialized
DEBUG - 2021-07-14 09:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:25:07 --> Input Class Initialized
INFO - 2021-07-14 09:25:07 --> Language Class Initialized
INFO - 2021-07-14 09:25:08 --> Loader Class Initialized
INFO - 2021-07-14 09:25:08 --> Helper loaded: html_helper
INFO - 2021-07-14 09:25:08 --> Helper loaded: url_helper
INFO - 2021-07-14 09:25:08 --> Helper loaded: form_helper
INFO - 2021-07-14 09:25:08 --> Database Driver Class Initialized
INFO - 2021-07-14 09:25:08 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:25:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:25:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:25:08 --> Encryption Class Initialized
INFO - 2021-07-14 09:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:25:08 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:25:08 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:25:08 --> Model "user_model" initialized
INFO - 2021-07-14 09:25:08 --> Model "role_model" initialized
INFO - 2021-07-14 09:25:08 --> Controller Class Initialized
INFO - 2021-07-14 09:25:08 --> Helper loaded: language_helper
INFO - 2021-07-14 09:25:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:25:08 --> Model "Customer_model" initialized
INFO - 2021-07-14 09:25:08 --> Model "Product_model" initialized
INFO - 2021-07-14 09:25:08 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 09:25:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 09:25:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 09:25:08 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 09:25:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 09:25:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 09:25:08 --> Final output sent to browser
DEBUG - 2021-07-14 09:25:08 --> Total execution time: 0.0884
INFO - 2021-07-14 09:25:12 --> Config Class Initialized
INFO - 2021-07-14 09:25:12 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:25:12 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:25:12 --> Utf8 Class Initialized
INFO - 2021-07-14 09:25:12 --> URI Class Initialized
INFO - 2021-07-14 09:25:12 --> Router Class Initialized
INFO - 2021-07-14 09:25:12 --> Output Class Initialized
INFO - 2021-07-14 09:25:12 --> Security Class Initialized
DEBUG - 2021-07-14 09:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:25:12 --> Input Class Initialized
INFO - 2021-07-14 09:25:12 --> Language Class Initialized
INFO - 2021-07-14 09:25:12 --> Loader Class Initialized
INFO - 2021-07-14 09:25:12 --> Helper loaded: html_helper
INFO - 2021-07-14 09:25:12 --> Helper loaded: url_helper
INFO - 2021-07-14 09:25:12 --> Helper loaded: form_helper
INFO - 2021-07-14 09:25:12 --> Database Driver Class Initialized
INFO - 2021-07-14 09:25:12 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:25:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:25:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:25:12 --> Encryption Class Initialized
INFO - 2021-07-14 09:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:25:12 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:25:12 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:25:12 --> Model "user_model" initialized
INFO - 2021-07-14 09:25:12 --> Model "role_model" initialized
INFO - 2021-07-14 09:25:12 --> Controller Class Initialized
INFO - 2021-07-14 09:25:12 --> Helper loaded: language_helper
INFO - 2021-07-14 09:25:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:25:12 --> Model "Customer_model" initialized
INFO - 2021-07-14 09:25:12 --> Final output sent to browser
DEBUG - 2021-07-14 09:25:12 --> Total execution time: 0.0699
INFO - 2021-07-14 09:25:12 --> Config Class Initialized
INFO - 2021-07-14 09:25:12 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:25:12 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:25:12 --> Utf8 Class Initialized
INFO - 2021-07-14 09:25:12 --> URI Class Initialized
INFO - 2021-07-14 09:25:12 --> Router Class Initialized
INFO - 2021-07-14 09:25:12 --> Output Class Initialized
INFO - 2021-07-14 09:25:12 --> Security Class Initialized
DEBUG - 2021-07-14 09:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:25:12 --> Input Class Initialized
INFO - 2021-07-14 09:25:12 --> Language Class Initialized
INFO - 2021-07-14 09:25:12 --> Loader Class Initialized
INFO - 2021-07-14 09:25:12 --> Helper loaded: html_helper
INFO - 2021-07-14 09:25:12 --> Helper loaded: url_helper
INFO - 2021-07-14 09:25:12 --> Helper loaded: form_helper
INFO - 2021-07-14 09:25:12 --> Database Driver Class Initialized
INFO - 2021-07-14 09:25:12 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:25:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:25:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:25:12 --> Encryption Class Initialized
INFO - 2021-07-14 09:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:25:12 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:25:12 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:25:12 --> Model "user_model" initialized
INFO - 2021-07-14 09:25:12 --> Model "role_model" initialized
INFO - 2021-07-14 09:25:12 --> Controller Class Initialized
INFO - 2021-07-14 09:25:12 --> Helper loaded: language_helper
INFO - 2021-07-14 09:25:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:25:12 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 09:25:12 --> Final output sent to browser
DEBUG - 2021-07-14 09:25:12 --> Total execution time: 0.0733
INFO - 2021-07-14 09:25:38 --> Config Class Initialized
INFO - 2021-07-14 09:25:38 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:25:38 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:25:38 --> Utf8 Class Initialized
INFO - 2021-07-14 09:25:38 --> URI Class Initialized
INFO - 2021-07-14 09:25:38 --> Router Class Initialized
INFO - 2021-07-14 09:25:38 --> Output Class Initialized
INFO - 2021-07-14 09:25:38 --> Security Class Initialized
DEBUG - 2021-07-14 09:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:25:38 --> Input Class Initialized
INFO - 2021-07-14 09:25:38 --> Language Class Initialized
INFO - 2021-07-14 09:25:38 --> Loader Class Initialized
INFO - 2021-07-14 09:25:38 --> Helper loaded: html_helper
INFO - 2021-07-14 09:25:38 --> Helper loaded: url_helper
INFO - 2021-07-14 09:25:38 --> Helper loaded: form_helper
INFO - 2021-07-14 09:25:38 --> Database Driver Class Initialized
INFO - 2021-07-14 09:25:38 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:25:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:25:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:25:38 --> Encryption Class Initialized
INFO - 2021-07-14 09:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:25:38 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:25:38 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:25:38 --> Model "user_model" initialized
INFO - 2021-07-14 09:25:38 --> Model "role_model" initialized
INFO - 2021-07-14 09:25:38 --> Controller Class Initialized
INFO - 2021-07-14 09:25:38 --> Helper loaded: language_helper
INFO - 2021-07-14 09:25:38 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:25:38 --> Model "Product_model" initialized
INFO - 2021-07-14 09:25:38 --> Final output sent to browser
DEBUG - 2021-07-14 09:25:38 --> Total execution time: 0.0728
INFO - 2021-07-14 09:26:58 --> Config Class Initialized
INFO - 2021-07-14 09:26:58 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:26:58 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:26:58 --> Utf8 Class Initialized
INFO - 2021-07-14 09:26:58 --> URI Class Initialized
DEBUG - 2021-07-14 09:26:58 --> No URI present. Default controller set.
INFO - 2021-07-14 09:26:58 --> Router Class Initialized
INFO - 2021-07-14 09:26:58 --> Output Class Initialized
INFO - 2021-07-14 09:26:58 --> Security Class Initialized
DEBUG - 2021-07-14 09:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:26:58 --> Input Class Initialized
INFO - 2021-07-14 09:26:58 --> Language Class Initialized
INFO - 2021-07-14 09:26:59 --> Loader Class Initialized
INFO - 2021-07-14 09:26:59 --> Helper loaded: html_helper
INFO - 2021-07-14 09:26:59 --> Helper loaded: url_helper
INFO - 2021-07-14 09:26:59 --> Helper loaded: form_helper
INFO - 2021-07-14 09:26:59 --> Database Driver Class Initialized
INFO - 2021-07-14 09:26:59 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:26:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:26:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:26:59 --> Encryption Class Initialized
INFO - 2021-07-14 09:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:26:59 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:26:59 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:26:59 --> Model "user_model" initialized
INFO - 2021-07-14 09:26:59 --> Model "role_model" initialized
INFO - 2021-07-14 09:26:59 --> Controller Class Initialized
INFO - 2021-07-14 09:26:59 --> Helper loaded: language_helper
INFO - 2021-07-14 09:26:59 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:26:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-14 09:26:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-14 09:26:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-14 09:26:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 09:26:59 --> Final output sent to browser
DEBUG - 2021-07-14 09:26:59 --> Total execution time: 0.4536
INFO - 2021-07-14 09:39:53 --> Config Class Initialized
INFO - 2021-07-14 09:39:53 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:39:53 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:39:53 --> Utf8 Class Initialized
INFO - 2021-07-14 09:39:53 --> URI Class Initialized
INFO - 2021-07-14 09:39:53 --> Router Class Initialized
INFO - 2021-07-14 09:39:53 --> Output Class Initialized
INFO - 2021-07-14 09:39:53 --> Security Class Initialized
DEBUG - 2021-07-14 09:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:39:53 --> Input Class Initialized
INFO - 2021-07-14 09:39:53 --> Language Class Initialized
INFO - 2021-07-14 09:39:53 --> Loader Class Initialized
INFO - 2021-07-14 09:39:53 --> Helper loaded: html_helper
INFO - 2021-07-14 09:39:53 --> Helper loaded: url_helper
INFO - 2021-07-14 09:39:53 --> Helper loaded: form_helper
INFO - 2021-07-14 09:39:53 --> Database Driver Class Initialized
INFO - 2021-07-14 09:39:53 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:39:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:39:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:39:53 --> Encryption Class Initialized
INFO - 2021-07-14 09:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:39:53 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:39:53 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:39:53 --> Model "user_model" initialized
INFO - 2021-07-14 09:39:53 --> Model "role_model" initialized
INFO - 2021-07-14 09:39:53 --> Controller Class Initialized
INFO - 2021-07-14 09:39:53 --> Helper loaded: language_helper
INFO - 2021-07-14 09:39:53 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:39:53 --> Model "Customer_model" initialized
INFO - 2021-07-14 09:39:53 --> Model "Product_model" initialized
INFO - 2021-07-14 09:39:53 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 09:39:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 09:39:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 09:39:53 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 09:39:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 09:39:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 09:39:53 --> Final output sent to browser
DEBUG - 2021-07-14 09:39:53 --> Total execution time: 0.1695
INFO - 2021-07-14 09:39:55 --> Config Class Initialized
INFO - 2021-07-14 09:39:55 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:39:55 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:39:55 --> Utf8 Class Initialized
INFO - 2021-07-14 09:39:55 --> URI Class Initialized
INFO - 2021-07-14 09:39:55 --> Router Class Initialized
INFO - 2021-07-14 09:39:55 --> Output Class Initialized
INFO - 2021-07-14 09:39:55 --> Security Class Initialized
DEBUG - 2021-07-14 09:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:39:55 --> Input Class Initialized
INFO - 2021-07-14 09:39:55 --> Language Class Initialized
INFO - 2021-07-14 09:39:55 --> Loader Class Initialized
INFO - 2021-07-14 09:39:55 --> Helper loaded: html_helper
INFO - 2021-07-14 09:39:55 --> Helper loaded: url_helper
INFO - 2021-07-14 09:39:55 --> Helper loaded: form_helper
INFO - 2021-07-14 09:39:55 --> Database Driver Class Initialized
INFO - 2021-07-14 09:39:55 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:39:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:39:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:39:55 --> Encryption Class Initialized
INFO - 2021-07-14 09:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:39:55 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:39:55 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:39:55 --> Model "user_model" initialized
INFO - 2021-07-14 09:39:55 --> Model "role_model" initialized
INFO - 2021-07-14 09:39:55 --> Controller Class Initialized
INFO - 2021-07-14 09:39:55 --> Helper loaded: language_helper
INFO - 2021-07-14 09:39:55 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:39:55 --> Model "Customer_model" initialized
INFO - 2021-07-14 09:39:55 --> Model "Product_model" initialized
INFO - 2021-07-14 09:39:55 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 09:39:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 09:39:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 09:39:55 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 09:39:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 09:39:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 09:39:55 --> Final output sent to browser
DEBUG - 2021-07-14 09:39:55 --> Total execution time: 0.0816
INFO - 2021-07-14 09:40:02 --> Config Class Initialized
INFO - 2021-07-14 09:40:02 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:40:02 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:40:02 --> Utf8 Class Initialized
INFO - 2021-07-14 09:40:02 --> URI Class Initialized
INFO - 2021-07-14 09:40:02 --> Router Class Initialized
INFO - 2021-07-14 09:40:02 --> Output Class Initialized
INFO - 2021-07-14 09:40:02 --> Security Class Initialized
DEBUG - 2021-07-14 09:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:40:02 --> Input Class Initialized
INFO - 2021-07-14 09:40:02 --> Language Class Initialized
INFO - 2021-07-14 09:40:02 --> Loader Class Initialized
INFO - 2021-07-14 09:40:02 --> Helper loaded: html_helper
INFO - 2021-07-14 09:40:02 --> Helper loaded: url_helper
INFO - 2021-07-14 09:40:02 --> Helper loaded: form_helper
INFO - 2021-07-14 09:40:02 --> Database Driver Class Initialized
INFO - 2021-07-14 09:40:02 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:40:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:40:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:40:02 --> Encryption Class Initialized
INFO - 2021-07-14 09:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:40:02 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:40:02 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:40:02 --> Model "user_model" initialized
INFO - 2021-07-14 09:40:02 --> Model "role_model" initialized
INFO - 2021-07-14 09:40:02 --> Controller Class Initialized
INFO - 2021-07-14 09:40:02 --> Helper loaded: language_helper
INFO - 2021-07-14 09:40:02 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:40:02 --> Model "Customer_model" initialized
INFO - 2021-07-14 09:40:02 --> Final output sent to browser
DEBUG - 2021-07-14 09:40:02 --> Total execution time: 0.0633
INFO - 2021-07-14 09:40:03 --> Config Class Initialized
INFO - 2021-07-14 09:40:03 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:40:03 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:40:03 --> Utf8 Class Initialized
INFO - 2021-07-14 09:40:03 --> URI Class Initialized
INFO - 2021-07-14 09:40:03 --> Router Class Initialized
INFO - 2021-07-14 09:40:03 --> Output Class Initialized
INFO - 2021-07-14 09:40:03 --> Security Class Initialized
DEBUG - 2021-07-14 09:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:40:03 --> Input Class Initialized
INFO - 2021-07-14 09:40:03 --> Language Class Initialized
INFO - 2021-07-14 09:40:03 --> Loader Class Initialized
INFO - 2021-07-14 09:40:03 --> Helper loaded: html_helper
INFO - 2021-07-14 09:40:03 --> Helper loaded: url_helper
INFO - 2021-07-14 09:40:03 --> Helper loaded: form_helper
INFO - 2021-07-14 09:40:03 --> Database Driver Class Initialized
INFO - 2021-07-14 09:40:03 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:40:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:40:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:40:03 --> Encryption Class Initialized
INFO - 2021-07-14 09:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:40:03 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:40:03 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:40:03 --> Model "user_model" initialized
INFO - 2021-07-14 09:40:03 --> Model "role_model" initialized
INFO - 2021-07-14 09:40:03 --> Controller Class Initialized
INFO - 2021-07-14 09:40:03 --> Helper loaded: language_helper
INFO - 2021-07-14 09:40:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:40:03 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 09:40:03 --> Final output sent to browser
DEBUG - 2021-07-14 09:40:03 --> Total execution time: 0.0697
INFO - 2021-07-14 09:40:25 --> Config Class Initialized
INFO - 2021-07-14 09:40:25 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:40:25 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:40:25 --> Utf8 Class Initialized
INFO - 2021-07-14 09:40:25 --> URI Class Initialized
INFO - 2021-07-14 09:40:25 --> Router Class Initialized
INFO - 2021-07-14 09:40:25 --> Output Class Initialized
INFO - 2021-07-14 09:40:25 --> Security Class Initialized
DEBUG - 2021-07-14 09:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:40:25 --> Input Class Initialized
INFO - 2021-07-14 09:40:25 --> Language Class Initialized
INFO - 2021-07-14 09:40:25 --> Loader Class Initialized
INFO - 2021-07-14 09:40:25 --> Helper loaded: html_helper
INFO - 2021-07-14 09:40:25 --> Helper loaded: url_helper
INFO - 2021-07-14 09:40:25 --> Helper loaded: form_helper
INFO - 2021-07-14 09:40:25 --> Database Driver Class Initialized
INFO - 2021-07-14 09:40:25 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:40:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:40:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:40:25 --> Encryption Class Initialized
INFO - 2021-07-14 09:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:40:25 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:40:25 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:40:25 --> Model "user_model" initialized
INFO - 2021-07-14 09:40:25 --> Model "role_model" initialized
INFO - 2021-07-14 09:40:25 --> Controller Class Initialized
INFO - 2021-07-14 09:40:25 --> Helper loaded: language_helper
INFO - 2021-07-14 09:40:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:40:25 --> Model "Product_model" initialized
INFO - 2021-07-14 09:40:25 --> Final output sent to browser
DEBUG - 2021-07-14 09:40:25 --> Total execution time: 0.0710
INFO - 2021-07-14 09:42:48 --> Config Class Initialized
INFO - 2021-07-14 09:42:48 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:42:48 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:42:48 --> Utf8 Class Initialized
INFO - 2021-07-14 09:42:48 --> URI Class Initialized
INFO - 2021-07-14 09:42:48 --> Router Class Initialized
INFO - 2021-07-14 09:42:48 --> Output Class Initialized
INFO - 2021-07-14 09:42:48 --> Security Class Initialized
DEBUG - 2021-07-14 09:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:42:48 --> Input Class Initialized
INFO - 2021-07-14 09:42:48 --> Language Class Initialized
INFO - 2021-07-14 09:42:48 --> Loader Class Initialized
INFO - 2021-07-14 09:42:48 --> Helper loaded: html_helper
INFO - 2021-07-14 09:42:48 --> Helper loaded: url_helper
INFO - 2021-07-14 09:42:48 --> Helper loaded: form_helper
INFO - 2021-07-14 09:42:48 --> Database Driver Class Initialized
INFO - 2021-07-14 09:42:48 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:42:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:42:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:42:48 --> Encryption Class Initialized
INFO - 2021-07-14 09:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:42:48 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:42:48 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:42:48 --> Model "user_model" initialized
INFO - 2021-07-14 09:42:48 --> Model "role_model" initialized
INFO - 2021-07-14 09:42:48 --> Controller Class Initialized
INFO - 2021-07-14 09:42:48 --> Helper loaded: language_helper
INFO - 2021-07-14 09:42:48 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:42:48 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:42:48 --> Final output sent to browser
DEBUG - 2021-07-14 09:42:48 --> Total execution time: 0.0922
INFO - 2021-07-14 09:42:48 --> Config Class Initialized
INFO - 2021-07-14 09:42:48 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:42:48 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:42:48 --> Utf8 Class Initialized
INFO - 2021-07-14 09:42:48 --> URI Class Initialized
INFO - 2021-07-14 09:42:48 --> Router Class Initialized
INFO - 2021-07-14 09:42:48 --> Output Class Initialized
INFO - 2021-07-14 09:42:48 --> Security Class Initialized
DEBUG - 2021-07-14 09:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:42:48 --> Input Class Initialized
INFO - 2021-07-14 09:42:48 --> Language Class Initialized
INFO - 2021-07-14 09:42:48 --> Loader Class Initialized
INFO - 2021-07-14 09:42:48 --> Helper loaded: html_helper
INFO - 2021-07-14 09:42:48 --> Helper loaded: url_helper
INFO - 2021-07-14 09:42:48 --> Helper loaded: form_helper
INFO - 2021-07-14 09:42:48 --> Database Driver Class Initialized
INFO - 2021-07-14 09:42:48 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:42:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:42:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:42:48 --> Encryption Class Initialized
INFO - 2021-07-14 09:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:42:48 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:42:48 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:42:48 --> Model "user_model" initialized
INFO - 2021-07-14 09:42:48 --> Model "role_model" initialized
INFO - 2021-07-14 09:42:48 --> Controller Class Initialized
INFO - 2021-07-14 09:42:48 --> Helper loaded: language_helper
INFO - 2021-07-14 09:42:48 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:42:48 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:42:48 --> Final output sent to browser
DEBUG - 2021-07-14 09:42:48 --> Total execution time: 0.0754
INFO - 2021-07-14 09:42:50 --> Config Class Initialized
INFO - 2021-07-14 09:42:50 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:42:50 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:42:50 --> Utf8 Class Initialized
INFO - 2021-07-14 09:42:50 --> URI Class Initialized
INFO - 2021-07-14 09:42:50 --> Router Class Initialized
INFO - 2021-07-14 09:42:50 --> Output Class Initialized
INFO - 2021-07-14 09:42:50 --> Security Class Initialized
DEBUG - 2021-07-14 09:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:42:50 --> Input Class Initialized
INFO - 2021-07-14 09:42:50 --> Language Class Initialized
INFO - 2021-07-14 09:42:50 --> Loader Class Initialized
INFO - 2021-07-14 09:42:50 --> Helper loaded: html_helper
INFO - 2021-07-14 09:42:50 --> Helper loaded: url_helper
INFO - 2021-07-14 09:42:50 --> Helper loaded: form_helper
INFO - 2021-07-14 09:42:50 --> Database Driver Class Initialized
INFO - 2021-07-14 09:42:50 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:42:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:42:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:42:50 --> Encryption Class Initialized
INFO - 2021-07-14 09:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:42:50 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:42:50 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:42:50 --> Model "user_model" initialized
INFO - 2021-07-14 09:42:50 --> Model "role_model" initialized
INFO - 2021-07-14 09:42:50 --> Controller Class Initialized
INFO - 2021-07-14 09:42:50 --> Helper loaded: language_helper
INFO - 2021-07-14 09:42:50 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:42:50 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:42:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 09:42:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 09:42:50 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 09:42:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 09:42:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 09:42:50 --> Final output sent to browser
DEBUG - 2021-07-14 09:42:50 --> Total execution time: 0.0880
INFO - 2021-07-14 09:42:50 --> Config Class Initialized
INFO - 2021-07-14 09:42:50 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:42:50 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:42:50 --> Utf8 Class Initialized
INFO - 2021-07-14 09:42:50 --> Config Class Initialized
INFO - 2021-07-14 09:42:50 --> URI Class Initialized
INFO - 2021-07-14 09:42:50 --> Hooks Class Initialized
INFO - 2021-07-14 09:42:50 --> Router Class Initialized
INFO - 2021-07-14 09:42:50 --> Output Class Initialized
INFO - 2021-07-14 09:42:50 --> Security Class Initialized
DEBUG - 2021-07-14 09:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:42:50 --> Input Class Initialized
INFO - 2021-07-14 09:42:50 --> Language Class Initialized
INFO - 2021-07-14 09:42:50 --> Loader Class Initialized
DEBUG - 2021-07-14 09:42:50 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:42:50 --> Utf8 Class Initialized
INFO - 2021-07-14 09:42:50 --> Helper loaded: html_helper
INFO - 2021-07-14 09:42:50 --> URI Class Initialized
INFO - 2021-07-14 09:42:50 --> Helper loaded: url_helper
INFO - 2021-07-14 09:42:50 --> Helper loaded: form_helper
INFO - 2021-07-14 09:42:51 --> Router Class Initialized
INFO - 2021-07-14 09:42:51 --> Output Class Initialized
INFO - 2021-07-14 09:42:51 --> Database Driver Class Initialized
INFO - 2021-07-14 09:42:51 --> Security Class Initialized
DEBUG - 2021-07-14 09:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:42:51 --> Input Class Initialized
INFO - 2021-07-14 09:42:51 --> Language Class Initialized
INFO - 2021-07-14 09:42:51 --> Loader Class Initialized
INFO - 2021-07-14 09:42:51 --> Helper loaded: html_helper
INFO - 2021-07-14 09:42:51 --> Helper loaded: url_helper
INFO - 2021-07-14 09:42:51 --> Helper loaded: form_helper
INFO - 2021-07-14 09:42:51 --> Database Driver Class Initialized
INFO - 2021-07-14 09:42:51 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:42:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:42:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:42:51 --> Encryption Class Initialized
INFO - 2021-07-14 09:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:42:51 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:42:51 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:42:51 --> Model "user_model" initialized
INFO - 2021-07-14 09:42:51 --> Model "role_model" initialized
INFO - 2021-07-14 09:42:51 --> Controller Class Initialized
INFO - 2021-07-14 09:42:51 --> Helper loaded: language_helper
INFO - 2021-07-14 09:42:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:42:51 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:42:51 --> Final output sent to browser
DEBUG - 2021-07-14 09:42:51 --> Total execution time: 0.0884
INFO - 2021-07-14 09:42:51 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:42:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:42:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:42:51 --> Encryption Class Initialized
INFO - 2021-07-14 09:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:42:51 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:42:51 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:42:51 --> Model "user_model" initialized
INFO - 2021-07-14 09:42:51 --> Model "role_model" initialized
INFO - 2021-07-14 09:42:51 --> Controller Class Initialized
INFO - 2021-07-14 09:42:51 --> Helper loaded: language_helper
INFO - 2021-07-14 09:42:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:42:51 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:42:51 --> Final output sent to browser
DEBUG - 2021-07-14 09:42:51 --> Total execution time: 0.1069
INFO - 2021-07-14 09:44:13 --> Config Class Initialized
INFO - 2021-07-14 09:44:13 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:44:13 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:44:13 --> Utf8 Class Initialized
INFO - 2021-07-14 09:44:13 --> URI Class Initialized
INFO - 2021-07-14 09:44:13 --> Router Class Initialized
INFO - 2021-07-14 09:44:13 --> Output Class Initialized
INFO - 2021-07-14 09:44:13 --> Security Class Initialized
DEBUG - 2021-07-14 09:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:44:13 --> Input Class Initialized
INFO - 2021-07-14 09:44:13 --> Language Class Initialized
INFO - 2021-07-14 09:44:13 --> Loader Class Initialized
INFO - 2021-07-14 09:44:13 --> Helper loaded: html_helper
INFO - 2021-07-14 09:44:13 --> Helper loaded: url_helper
INFO - 2021-07-14 09:44:13 --> Helper loaded: form_helper
INFO - 2021-07-14 09:44:13 --> Database Driver Class Initialized
INFO - 2021-07-14 09:44:13 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:44:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:44:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:44:13 --> Encryption Class Initialized
INFO - 2021-07-14 09:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:44:13 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:44:13 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:44:13 --> Model "user_model" initialized
INFO - 2021-07-14 09:44:13 --> Model "role_model" initialized
INFO - 2021-07-14 09:44:13 --> Controller Class Initialized
INFO - 2021-07-14 09:44:13 --> Helper loaded: language_helper
INFO - 2021-07-14 09:44:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:44:13 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:44:13 --> Model "Customer_model" initialized
INFO - 2021-07-14 09:44:13 --> Model "Product_model" initialized
INFO - 2021-07-14 09:44:13 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 09:44:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 09:44:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 09:44:13 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 09:44:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 09:44:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 09:44:13 --> Final output sent to browser
DEBUG - 2021-07-14 09:44:13 --> Total execution time: 0.0902
INFO - 2021-07-14 09:44:17 --> Config Class Initialized
INFO - 2021-07-14 09:44:17 --> Hooks Class Initialized
INFO - 2021-07-14 09:44:17 --> Config Class Initialized
INFO - 2021-07-14 09:44:17 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:44:17 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:44:17 --> Utf8 Class Initialized
DEBUG - 2021-07-14 09:44:17 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:44:17 --> Utf8 Class Initialized
INFO - 2021-07-14 09:44:17 --> URI Class Initialized
INFO - 2021-07-14 09:44:17 --> URI Class Initialized
INFO - 2021-07-14 09:44:17 --> Router Class Initialized
INFO - 2021-07-14 09:44:17 --> Router Class Initialized
INFO - 2021-07-14 09:44:17 --> Output Class Initialized
INFO - 2021-07-14 09:44:17 --> Output Class Initialized
INFO - 2021-07-14 09:44:17 --> Security Class Initialized
INFO - 2021-07-14 09:44:17 --> Security Class Initialized
DEBUG - 2021-07-14 09:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 09:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:44:17 --> Input Class Initialized
INFO - 2021-07-14 09:44:17 --> Input Class Initialized
INFO - 2021-07-14 09:44:17 --> Language Class Initialized
INFO - 2021-07-14 09:44:17 --> Language Class Initialized
INFO - 2021-07-14 09:44:17 --> Loader Class Initialized
INFO - 2021-07-14 09:44:17 --> Loader Class Initialized
INFO - 2021-07-14 09:44:17 --> Helper loaded: html_helper
INFO - 2021-07-14 09:44:17 --> Helper loaded: html_helper
INFO - 2021-07-14 09:44:17 --> Helper loaded: url_helper
INFO - 2021-07-14 09:44:17 --> Helper loaded: url_helper
INFO - 2021-07-14 09:44:17 --> Helper loaded: form_helper
INFO - 2021-07-14 09:44:17 --> Helper loaded: form_helper
INFO - 2021-07-14 09:44:17 --> Database Driver Class Initialized
INFO - 2021-07-14 09:44:17 --> Database Driver Class Initialized
INFO - 2021-07-14 09:44:17 --> Form Validation Class Initialized
INFO - 2021-07-14 09:44:17 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:44:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:44:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:44:17 --> Encryption Class Initialized
DEBUG - 2021-07-14 09:44:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:44:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:44:17 --> Encryption Class Initialized
INFO - 2021-07-14 09:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:44:17 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:44:17 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:44:17 --> Model "user_model" initialized
INFO - 2021-07-14 09:44:17 --> Model "role_model" initialized
INFO - 2021-07-14 09:44:17 --> Controller Class Initialized
INFO - 2021-07-14 09:44:17 --> Helper loaded: language_helper
INFO - 2021-07-14 09:44:17 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:44:17 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:44:17 --> Final output sent to browser
DEBUG - 2021-07-14 09:44:17 --> Total execution time: 0.0760
INFO - 2021-07-14 09:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:44:17 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:44:17 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:44:17 --> Model "user_model" initialized
INFO - 2021-07-14 09:44:17 --> Model "role_model" initialized
INFO - 2021-07-14 09:44:17 --> Controller Class Initialized
INFO - 2021-07-14 09:44:17 --> Helper loaded: language_helper
INFO - 2021-07-14 09:44:17 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:44:17 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:44:17 --> Final output sent to browser
DEBUG - 2021-07-14 09:44:17 --> Total execution time: 0.0902
INFO - 2021-07-14 09:44:21 --> Config Class Initialized
INFO - 2021-07-14 09:44:21 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:44:21 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:44:21 --> Utf8 Class Initialized
INFO - 2021-07-14 09:44:21 --> URI Class Initialized
INFO - 2021-07-14 09:44:21 --> Router Class Initialized
INFO - 2021-07-14 09:44:21 --> Output Class Initialized
INFO - 2021-07-14 09:44:21 --> Security Class Initialized
DEBUG - 2021-07-14 09:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:44:21 --> Input Class Initialized
INFO - 2021-07-14 09:44:21 --> Language Class Initialized
INFO - 2021-07-14 09:44:21 --> Loader Class Initialized
INFO - 2021-07-14 09:44:21 --> Helper loaded: html_helper
INFO - 2021-07-14 09:44:21 --> Helper loaded: url_helper
INFO - 2021-07-14 09:44:21 --> Helper loaded: form_helper
INFO - 2021-07-14 09:44:21 --> Database Driver Class Initialized
INFO - 2021-07-14 09:44:21 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:44:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:44:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:44:21 --> Encryption Class Initialized
INFO - 2021-07-14 09:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:44:21 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:44:21 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:44:21 --> Model "user_model" initialized
INFO - 2021-07-14 09:44:21 --> Model "role_model" initialized
INFO - 2021-07-14 09:44:21 --> Controller Class Initialized
INFO - 2021-07-14 09:44:21 --> Helper loaded: language_helper
INFO - 2021-07-14 09:44:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:44:21 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:44:21 --> Final output sent to browser
DEBUG - 2021-07-14 09:44:21 --> Total execution time: 0.0804
INFO - 2021-07-14 09:44:27 --> Config Class Initialized
INFO - 2021-07-14 09:44:27 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:44:27 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:44:27 --> Utf8 Class Initialized
INFO - 2021-07-14 09:44:27 --> URI Class Initialized
INFO - 2021-07-14 09:44:27 --> Router Class Initialized
INFO - 2021-07-14 09:44:27 --> Output Class Initialized
INFO - 2021-07-14 09:44:27 --> Security Class Initialized
DEBUG - 2021-07-14 09:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:44:27 --> Input Class Initialized
INFO - 2021-07-14 09:44:27 --> Language Class Initialized
INFO - 2021-07-14 09:44:27 --> Loader Class Initialized
INFO - 2021-07-14 09:44:27 --> Helper loaded: html_helper
INFO - 2021-07-14 09:44:27 --> Helper loaded: url_helper
INFO - 2021-07-14 09:44:27 --> Helper loaded: form_helper
INFO - 2021-07-14 09:44:27 --> Database Driver Class Initialized
INFO - 2021-07-14 09:44:27 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:44:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:44:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:44:27 --> Encryption Class Initialized
INFO - 2021-07-14 09:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:44:27 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:44:27 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:44:27 --> Model "user_model" initialized
INFO - 2021-07-14 09:44:27 --> Model "role_model" initialized
INFO - 2021-07-14 09:44:27 --> Controller Class Initialized
INFO - 2021-07-14 09:44:27 --> Helper loaded: language_helper
INFO - 2021-07-14 09:44:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:44:27 --> Model "Customer_model" initialized
INFO - 2021-07-14 09:44:27 --> Model "Product_model" initialized
INFO - 2021-07-14 09:44:27 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 09:44:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 09:44:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 09:44:27 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 09:44:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 09:44:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 09:44:27 --> Final output sent to browser
DEBUG - 2021-07-14 09:44:27 --> Total execution time: 0.0839
INFO - 2021-07-14 09:44:35 --> Config Class Initialized
INFO - 2021-07-14 09:44:35 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:44:35 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:44:35 --> Utf8 Class Initialized
INFO - 2021-07-14 09:44:35 --> URI Class Initialized
INFO - 2021-07-14 09:44:35 --> Router Class Initialized
INFO - 2021-07-14 09:44:35 --> Output Class Initialized
INFO - 2021-07-14 09:44:35 --> Security Class Initialized
DEBUG - 2021-07-14 09:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:44:35 --> Input Class Initialized
INFO - 2021-07-14 09:44:35 --> Language Class Initialized
INFO - 2021-07-14 09:44:35 --> Loader Class Initialized
INFO - 2021-07-14 09:44:35 --> Helper loaded: html_helper
INFO - 2021-07-14 09:44:35 --> Helper loaded: url_helper
INFO - 2021-07-14 09:44:35 --> Helper loaded: form_helper
INFO - 2021-07-14 09:44:35 --> Database Driver Class Initialized
INFO - 2021-07-14 09:44:35 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:44:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:44:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:44:35 --> Encryption Class Initialized
INFO - 2021-07-14 09:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:44:35 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:44:35 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:44:35 --> Model "user_model" initialized
INFO - 2021-07-14 09:44:35 --> Model "role_model" initialized
INFO - 2021-07-14 09:44:35 --> Controller Class Initialized
INFO - 2021-07-14 09:44:35 --> Helper loaded: language_helper
INFO - 2021-07-14 09:44:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:44:35 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:44:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 09:44:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 09:44:35 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 09:44:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 09:44:35 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 09:44:35 --> Final output sent to browser
DEBUG - 2021-07-14 09:44:35 --> Total execution time: 0.0777
INFO - 2021-07-14 09:44:37 --> Config Class Initialized
INFO - 2021-07-14 09:44:37 --> Hooks Class Initialized
INFO - 2021-07-14 09:44:37 --> Config Class Initialized
INFO - 2021-07-14 09:44:37 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:44:37 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:44:37 --> Utf8 Class Initialized
DEBUG - 2021-07-14 09:44:37 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:44:37 --> Utf8 Class Initialized
INFO - 2021-07-14 09:44:37 --> URI Class Initialized
INFO - 2021-07-14 09:44:37 --> URI Class Initialized
INFO - 2021-07-14 09:44:37 --> Router Class Initialized
INFO - 2021-07-14 09:44:37 --> Router Class Initialized
INFO - 2021-07-14 09:44:37 --> Output Class Initialized
INFO - 2021-07-14 09:44:37 --> Output Class Initialized
INFO - 2021-07-14 09:44:37 --> Security Class Initialized
INFO - 2021-07-14 09:44:37 --> Security Class Initialized
DEBUG - 2021-07-14 09:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:44:37 --> Input Class Initialized
INFO - 2021-07-14 09:44:37 --> Language Class Initialized
DEBUG - 2021-07-14 09:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:44:37 --> Input Class Initialized
INFO - 2021-07-14 09:44:37 --> Language Class Initialized
INFO - 2021-07-14 09:44:37 --> Loader Class Initialized
INFO - 2021-07-14 09:44:37 --> Loader Class Initialized
INFO - 2021-07-14 09:44:37 --> Helper loaded: html_helper
INFO - 2021-07-14 09:44:37 --> Helper loaded: html_helper
INFO - 2021-07-14 09:44:37 --> Helper loaded: url_helper
INFO - 2021-07-14 09:44:37 --> Helper loaded: url_helper
INFO - 2021-07-14 09:44:37 --> Helper loaded: form_helper
INFO - 2021-07-14 09:44:37 --> Helper loaded: form_helper
INFO - 2021-07-14 09:44:37 --> Database Driver Class Initialized
INFO - 2021-07-14 09:44:37 --> Database Driver Class Initialized
INFO - 2021-07-14 09:44:37 --> Form Validation Class Initialized
INFO - 2021-07-14 09:44:37 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-14 09:44:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:44:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:44:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:44:37 --> Encryption Class Initialized
INFO - 2021-07-14 09:44:37 --> Encryption Class Initialized
INFO - 2021-07-14 09:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:44:37 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:44:37 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:44:37 --> Model "user_model" initialized
INFO - 2021-07-14 09:44:37 --> Model "role_model" initialized
INFO - 2021-07-14 09:44:37 --> Controller Class Initialized
INFO - 2021-07-14 09:44:37 --> Helper loaded: language_helper
INFO - 2021-07-14 09:44:37 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:44:37 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:44:37 --> Final output sent to browser
DEBUG - 2021-07-14 09:44:37 --> Total execution time: 0.0731
INFO - 2021-07-14 09:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:44:37 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:44:37 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:44:37 --> Model "user_model" initialized
INFO - 2021-07-14 09:44:37 --> Model "role_model" initialized
INFO - 2021-07-14 09:44:37 --> Controller Class Initialized
INFO - 2021-07-14 09:44:37 --> Helper loaded: language_helper
INFO - 2021-07-14 09:44:37 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:44:37 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:44:37 --> Final output sent to browser
DEBUG - 2021-07-14 09:44:37 --> Total execution time: 0.0865
INFO - 2021-07-14 09:44:50 --> Config Class Initialized
INFO - 2021-07-14 09:44:50 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:44:50 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:44:50 --> Utf8 Class Initialized
INFO - 2021-07-14 09:44:50 --> URI Class Initialized
INFO - 2021-07-14 09:44:50 --> Router Class Initialized
INFO - 2021-07-14 09:44:50 --> Output Class Initialized
INFO - 2021-07-14 09:44:50 --> Security Class Initialized
DEBUG - 2021-07-14 09:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:44:50 --> Input Class Initialized
INFO - 2021-07-14 09:44:50 --> Language Class Initialized
INFO - 2021-07-14 09:44:50 --> Loader Class Initialized
INFO - 2021-07-14 09:44:50 --> Helper loaded: html_helper
INFO - 2021-07-14 09:44:50 --> Helper loaded: url_helper
INFO - 2021-07-14 09:44:50 --> Helper loaded: form_helper
INFO - 2021-07-14 09:44:50 --> Database Driver Class Initialized
INFO - 2021-07-14 09:44:50 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:44:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:44:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:44:50 --> Encryption Class Initialized
INFO - 2021-07-14 09:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:44:50 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:44:50 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:44:50 --> Model "user_model" initialized
INFO - 2021-07-14 09:44:50 --> Model "role_model" initialized
INFO - 2021-07-14 09:44:50 --> Controller Class Initialized
INFO - 2021-07-14 09:44:50 --> Helper loaded: language_helper
INFO - 2021-07-14 09:44:50 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:44:50 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:44:50 --> Model "Customer_model" initialized
INFO - 2021-07-14 09:44:50 --> Model "Product_model" initialized
INFO - 2021-07-14 09:44:50 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 09:44:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 09:44:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 09:44:50 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 09:44:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 09:44:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 09:44:50 --> Final output sent to browser
DEBUG - 2021-07-14 09:44:50 --> Total execution time: 0.0898
INFO - 2021-07-14 09:44:53 --> Config Class Initialized
INFO - 2021-07-14 09:44:53 --> Hooks Class Initialized
INFO - 2021-07-14 09:44:53 --> Config Class Initialized
INFO - 2021-07-14 09:44:53 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:44:53 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:44:53 --> Utf8 Class Initialized
DEBUG - 2021-07-14 09:44:53 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:44:53 --> Utf8 Class Initialized
INFO - 2021-07-14 09:44:53 --> URI Class Initialized
INFO - 2021-07-14 09:44:53 --> URI Class Initialized
INFO - 2021-07-14 09:44:53 --> Router Class Initialized
INFO - 2021-07-14 09:44:53 --> Router Class Initialized
INFO - 2021-07-14 09:44:53 --> Output Class Initialized
INFO - 2021-07-14 09:44:53 --> Output Class Initialized
INFO - 2021-07-14 09:44:53 --> Security Class Initialized
INFO - 2021-07-14 09:44:53 --> Security Class Initialized
DEBUG - 2021-07-14 09:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:44:53 --> Input Class Initialized
INFO - 2021-07-14 09:44:53 --> Language Class Initialized
DEBUG - 2021-07-14 09:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:44:53 --> Input Class Initialized
INFO - 2021-07-14 09:44:53 --> Language Class Initialized
INFO - 2021-07-14 09:44:53 --> Loader Class Initialized
INFO - 2021-07-14 09:44:53 --> Helper loaded: html_helper
INFO - 2021-07-14 09:44:53 --> Loader Class Initialized
INFO - 2021-07-14 09:44:53 --> Helper loaded: url_helper
INFO - 2021-07-14 09:44:53 --> Helper loaded: html_helper
INFO - 2021-07-14 09:44:53 --> Helper loaded: url_helper
INFO - 2021-07-14 09:44:53 --> Helper loaded: form_helper
INFO - 2021-07-14 09:44:53 --> Helper loaded: form_helper
INFO - 2021-07-14 09:44:53 --> Database Driver Class Initialized
INFO - 2021-07-14 09:44:53 --> Database Driver Class Initialized
INFO - 2021-07-14 09:44:53 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:44:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:44:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:44:53 --> Encryption Class Initialized
INFO - 2021-07-14 09:44:53 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:44:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:44:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:44:53 --> Encryption Class Initialized
INFO - 2021-07-14 09:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:44:53 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:44:53 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:44:53 --> Model "user_model" initialized
INFO - 2021-07-14 09:44:53 --> Model "role_model" initialized
INFO - 2021-07-14 09:44:53 --> Controller Class Initialized
INFO - 2021-07-14 09:44:53 --> Helper loaded: language_helper
INFO - 2021-07-14 09:44:53 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:44:53 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:44:53 --> Final output sent to browser
DEBUG - 2021-07-14 09:44:53 --> Total execution time: 0.0742
INFO - 2021-07-14 09:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:44:53 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:44:53 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:44:53 --> Model "user_model" initialized
INFO - 2021-07-14 09:44:53 --> Model "role_model" initialized
INFO - 2021-07-14 09:44:53 --> Controller Class Initialized
INFO - 2021-07-14 09:44:53 --> Helper loaded: language_helper
INFO - 2021-07-14 09:44:53 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:44:53 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:44:53 --> Final output sent to browser
DEBUG - 2021-07-14 09:44:53 --> Total execution time: 0.0829
INFO - 2021-07-14 09:45:09 --> Config Class Initialized
INFO - 2021-07-14 09:45:09 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:45:09 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:45:09 --> Utf8 Class Initialized
INFO - 2021-07-14 09:45:09 --> URI Class Initialized
INFO - 2021-07-14 09:45:09 --> Router Class Initialized
INFO - 2021-07-14 09:45:09 --> Output Class Initialized
INFO - 2021-07-14 09:45:09 --> Security Class Initialized
DEBUG - 2021-07-14 09:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:45:09 --> Input Class Initialized
INFO - 2021-07-14 09:45:09 --> Language Class Initialized
INFO - 2021-07-14 09:45:09 --> Loader Class Initialized
INFO - 2021-07-14 09:45:09 --> Helper loaded: html_helper
INFO - 2021-07-14 09:45:09 --> Helper loaded: url_helper
INFO - 2021-07-14 09:45:09 --> Helper loaded: form_helper
INFO - 2021-07-14 09:45:09 --> Database Driver Class Initialized
INFO - 2021-07-14 09:45:09 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:45:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:45:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:45:09 --> Encryption Class Initialized
INFO - 2021-07-14 09:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:45:09 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:45:09 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:45:09 --> Model "user_model" initialized
INFO - 2021-07-14 09:45:09 --> Model "role_model" initialized
INFO - 2021-07-14 09:45:09 --> Controller Class Initialized
INFO - 2021-07-14 09:45:09 --> Helper loaded: language_helper
INFO - 2021-07-14 09:45:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:45:09 --> Model "Product_model" initialized
INFO - 2021-07-14 09:45:09 --> Final output sent to browser
DEBUG - 2021-07-14 09:45:09 --> Total execution time: 0.0736
INFO - 2021-07-14 09:45:10 --> Config Class Initialized
INFO - 2021-07-14 09:45:10 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:45:10 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:45:10 --> Utf8 Class Initialized
INFO - 2021-07-14 09:45:10 --> URI Class Initialized
INFO - 2021-07-14 09:45:10 --> Router Class Initialized
INFO - 2021-07-14 09:45:10 --> Output Class Initialized
INFO - 2021-07-14 09:45:10 --> Security Class Initialized
DEBUG - 2021-07-14 09:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:45:10 --> Input Class Initialized
INFO - 2021-07-14 09:45:10 --> Language Class Initialized
INFO - 2021-07-14 09:45:10 --> Loader Class Initialized
INFO - 2021-07-14 09:45:10 --> Helper loaded: html_helper
INFO - 2021-07-14 09:45:10 --> Helper loaded: url_helper
INFO - 2021-07-14 09:45:10 --> Helper loaded: form_helper
INFO - 2021-07-14 09:45:10 --> Database Driver Class Initialized
INFO - 2021-07-14 09:45:10 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:45:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:45:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:45:10 --> Encryption Class Initialized
INFO - 2021-07-14 09:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:45:10 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:45:10 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:45:10 --> Model "user_model" initialized
INFO - 2021-07-14 09:45:10 --> Model "role_model" initialized
INFO - 2021-07-14 09:45:10 --> Controller Class Initialized
INFO - 2021-07-14 09:45:10 --> Helper loaded: language_helper
INFO - 2021-07-14 09:45:10 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:45:10 --> Model "Product_model" initialized
INFO - 2021-07-14 09:45:10 --> Final output sent to browser
DEBUG - 2021-07-14 09:45:10 --> Total execution time: 0.0694
INFO - 2021-07-14 09:45:41 --> Config Class Initialized
INFO - 2021-07-14 09:45:41 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:45:41 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:45:41 --> Utf8 Class Initialized
INFO - 2021-07-14 09:45:41 --> URI Class Initialized
INFO - 2021-07-14 09:45:41 --> Router Class Initialized
INFO - 2021-07-14 09:45:41 --> Output Class Initialized
INFO - 2021-07-14 09:45:41 --> Security Class Initialized
DEBUG - 2021-07-14 09:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:45:41 --> Input Class Initialized
INFO - 2021-07-14 09:45:41 --> Language Class Initialized
INFO - 2021-07-14 09:45:41 --> Loader Class Initialized
INFO - 2021-07-14 09:45:41 --> Helper loaded: html_helper
INFO - 2021-07-14 09:45:41 --> Helper loaded: url_helper
INFO - 2021-07-14 09:45:41 --> Helper loaded: form_helper
INFO - 2021-07-14 09:45:41 --> Database Driver Class Initialized
INFO - 2021-07-14 09:45:41 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:45:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:45:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:45:41 --> Encryption Class Initialized
INFO - 2021-07-14 09:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:45:41 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:45:41 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:45:41 --> Model "user_model" initialized
INFO - 2021-07-14 09:45:41 --> Model "role_model" initialized
INFO - 2021-07-14 09:45:41 --> Controller Class Initialized
INFO - 2021-07-14 09:45:41 --> Helper loaded: language_helper
INFO - 2021-07-14 09:45:41 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:45:41 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:45:41 --> Final output sent to browser
DEBUG - 2021-07-14 09:45:41 --> Total execution time: 0.0762
INFO - 2021-07-14 09:45:49 --> Config Class Initialized
INFO - 2021-07-14 09:45:49 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:45:49 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:45:49 --> Utf8 Class Initialized
INFO - 2021-07-14 09:45:49 --> URI Class Initialized
INFO - 2021-07-14 09:45:49 --> Router Class Initialized
INFO - 2021-07-14 09:45:49 --> Output Class Initialized
INFO - 2021-07-14 09:45:49 --> Security Class Initialized
DEBUG - 2021-07-14 09:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:45:49 --> Input Class Initialized
INFO - 2021-07-14 09:45:49 --> Language Class Initialized
INFO - 2021-07-14 09:45:49 --> Loader Class Initialized
INFO - 2021-07-14 09:45:49 --> Helper loaded: html_helper
INFO - 2021-07-14 09:45:49 --> Helper loaded: url_helper
INFO - 2021-07-14 09:45:49 --> Helper loaded: form_helper
INFO - 2021-07-14 09:45:49 --> Database Driver Class Initialized
INFO - 2021-07-14 09:45:49 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:45:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:45:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:45:49 --> Encryption Class Initialized
INFO - 2021-07-14 09:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:45:49 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:45:49 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:45:49 --> Model "user_model" initialized
INFO - 2021-07-14 09:45:49 --> Model "role_model" initialized
INFO - 2021-07-14 09:45:49 --> Controller Class Initialized
INFO - 2021-07-14 09:45:49 --> Helper loaded: language_helper
INFO - 2021-07-14 09:45:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:45:49 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:45:49 --> Final output sent to browser
DEBUG - 2021-07-14 09:45:49 --> Total execution time: 0.1234
INFO - 2021-07-14 09:45:50 --> Config Class Initialized
INFO - 2021-07-14 09:45:50 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:45:50 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:45:50 --> Utf8 Class Initialized
INFO - 2021-07-14 09:45:50 --> URI Class Initialized
INFO - 2021-07-14 09:45:50 --> Router Class Initialized
INFO - 2021-07-14 09:45:50 --> Output Class Initialized
INFO - 2021-07-14 09:45:50 --> Security Class Initialized
DEBUG - 2021-07-14 09:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:45:50 --> Input Class Initialized
INFO - 2021-07-14 09:45:50 --> Language Class Initialized
INFO - 2021-07-14 09:45:50 --> Loader Class Initialized
INFO - 2021-07-14 09:45:50 --> Helper loaded: html_helper
INFO - 2021-07-14 09:45:50 --> Helper loaded: url_helper
INFO - 2021-07-14 09:45:50 --> Helper loaded: form_helper
INFO - 2021-07-14 09:45:50 --> Database Driver Class Initialized
INFO - 2021-07-14 09:45:50 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:45:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:45:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:45:50 --> Encryption Class Initialized
INFO - 2021-07-14 09:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:45:50 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:45:50 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:45:50 --> Model "user_model" initialized
INFO - 2021-07-14 09:45:50 --> Model "role_model" initialized
INFO - 2021-07-14 09:45:50 --> Controller Class Initialized
INFO - 2021-07-14 09:45:50 --> Helper loaded: language_helper
INFO - 2021-07-14 09:45:50 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:45:50 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:45:50 --> Final output sent to browser
DEBUG - 2021-07-14 09:45:50 --> Total execution time: 0.0685
INFO - 2021-07-14 09:45:52 --> Config Class Initialized
INFO - 2021-07-14 09:45:52 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:45:52 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:45:52 --> Utf8 Class Initialized
INFO - 2021-07-14 09:45:52 --> URI Class Initialized
INFO - 2021-07-14 09:45:52 --> Router Class Initialized
INFO - 2021-07-14 09:45:52 --> Output Class Initialized
INFO - 2021-07-14 09:45:52 --> Security Class Initialized
DEBUG - 2021-07-14 09:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:45:52 --> Input Class Initialized
INFO - 2021-07-14 09:45:52 --> Language Class Initialized
INFO - 2021-07-14 09:45:52 --> Loader Class Initialized
INFO - 2021-07-14 09:45:52 --> Helper loaded: html_helper
INFO - 2021-07-14 09:45:52 --> Helper loaded: url_helper
INFO - 2021-07-14 09:45:52 --> Helper loaded: form_helper
INFO - 2021-07-14 09:45:52 --> Database Driver Class Initialized
INFO - 2021-07-14 09:45:52 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:45:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:45:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:45:52 --> Encryption Class Initialized
INFO - 2021-07-14 09:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:45:52 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:45:52 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:45:52 --> Model "user_model" initialized
INFO - 2021-07-14 09:45:52 --> Model "role_model" initialized
INFO - 2021-07-14 09:45:52 --> Controller Class Initialized
INFO - 2021-07-14 09:45:52 --> Helper loaded: language_helper
INFO - 2021-07-14 09:45:52 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:45:52 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:45:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 09:45:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 09:45:52 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 09:45:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 09:45:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 09:45:52 --> Final output sent to browser
DEBUG - 2021-07-14 09:45:52 --> Total execution time: 0.0875
INFO - 2021-07-14 09:45:52 --> Config Class Initialized
INFO - 2021-07-14 09:45:52 --> Hooks Class Initialized
INFO - 2021-07-14 09:45:52 --> Config Class Initialized
INFO - 2021-07-14 09:45:52 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:45:52 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:45:52 --> Utf8 Class Initialized
DEBUG - 2021-07-14 09:45:52 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:45:52 --> Utf8 Class Initialized
INFO - 2021-07-14 09:45:52 --> URI Class Initialized
INFO - 2021-07-14 09:45:52 --> URI Class Initialized
INFO - 2021-07-14 09:45:52 --> Router Class Initialized
INFO - 2021-07-14 09:45:52 --> Router Class Initialized
INFO - 2021-07-14 09:45:52 --> Output Class Initialized
INFO - 2021-07-14 09:45:52 --> Output Class Initialized
INFO - 2021-07-14 09:45:52 --> Security Class Initialized
INFO - 2021-07-14 09:45:52 --> Security Class Initialized
DEBUG - 2021-07-14 09:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 09:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:45:52 --> Input Class Initialized
INFO - 2021-07-14 09:45:52 --> Input Class Initialized
INFO - 2021-07-14 09:45:52 --> Language Class Initialized
INFO - 2021-07-14 09:45:52 --> Language Class Initialized
INFO - 2021-07-14 09:45:52 --> Loader Class Initialized
INFO - 2021-07-14 09:45:52 --> Loader Class Initialized
INFO - 2021-07-14 09:45:52 --> Helper loaded: html_helper
INFO - 2021-07-14 09:45:52 --> Helper loaded: html_helper
INFO - 2021-07-14 09:45:52 --> Helper loaded: url_helper
INFO - 2021-07-14 09:45:52 --> Helper loaded: url_helper
INFO - 2021-07-14 09:45:52 --> Helper loaded: form_helper
INFO - 2021-07-14 09:45:52 --> Helper loaded: form_helper
INFO - 2021-07-14 09:45:52 --> Database Driver Class Initialized
INFO - 2021-07-14 09:45:52 --> Database Driver Class Initialized
INFO - 2021-07-14 09:45:52 --> Form Validation Class Initialized
INFO - 2021-07-14 09:45:52 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-14 09:45:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:45:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:45:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:45:52 --> Encryption Class Initialized
INFO - 2021-07-14 09:45:52 --> Encryption Class Initialized
INFO - 2021-07-14 09:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:45:52 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:45:52 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:45:52 --> Model "user_model" initialized
INFO - 2021-07-14 09:45:52 --> Model "role_model" initialized
INFO - 2021-07-14 09:45:52 --> Controller Class Initialized
INFO - 2021-07-14 09:45:52 --> Helper loaded: language_helper
INFO - 2021-07-14 09:45:52 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:45:52 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:45:52 --> Final output sent to browser
DEBUG - 2021-07-14 09:45:52 --> Total execution time: 0.0823
INFO - 2021-07-14 09:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:45:52 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:45:52 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:45:52 --> Model "user_model" initialized
INFO - 2021-07-14 09:45:52 --> Model "role_model" initialized
INFO - 2021-07-14 09:45:52 --> Controller Class Initialized
INFO - 2021-07-14 09:45:52 --> Helper loaded: language_helper
INFO - 2021-07-14 09:45:52 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:45:52 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:45:52 --> Final output sent to browser
DEBUG - 2021-07-14 09:45:52 --> Total execution time: 0.0936
INFO - 2021-07-14 09:46:18 --> Config Class Initialized
INFO - 2021-07-14 09:46:18 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:46:18 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:46:18 --> Utf8 Class Initialized
INFO - 2021-07-14 09:46:18 --> URI Class Initialized
INFO - 2021-07-14 09:46:18 --> Router Class Initialized
INFO - 2021-07-14 09:46:18 --> Output Class Initialized
INFO - 2021-07-14 09:46:18 --> Security Class Initialized
DEBUG - 2021-07-14 09:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:46:18 --> Input Class Initialized
INFO - 2021-07-14 09:46:18 --> Language Class Initialized
INFO - 2021-07-14 09:46:18 --> Loader Class Initialized
INFO - 2021-07-14 09:46:18 --> Helper loaded: html_helper
INFO - 2021-07-14 09:46:18 --> Helper loaded: url_helper
INFO - 2021-07-14 09:46:18 --> Helper loaded: form_helper
INFO - 2021-07-14 09:46:18 --> Database Driver Class Initialized
INFO - 2021-07-14 09:46:18 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:46:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:46:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:46:18 --> Encryption Class Initialized
INFO - 2021-07-14 09:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:46:18 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:46:18 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:46:18 --> Model "user_model" initialized
INFO - 2021-07-14 09:46:18 --> Model "role_model" initialized
INFO - 2021-07-14 09:46:18 --> Controller Class Initialized
INFO - 2021-07-14 09:46:18 --> Helper loaded: language_helper
INFO - 2021-07-14 09:46:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:46:18 --> Model "Customer_model" initialized
INFO - 2021-07-14 09:46:18 --> Model "Product_model" initialized
INFO - 2021-07-14 09:46:18 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 09:46:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 09:46:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 09:46:18 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 09:46:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 09:46:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 09:46:18 --> Final output sent to browser
DEBUG - 2021-07-14 09:46:18 --> Total execution time: 0.0829
INFO - 2021-07-14 09:46:21 --> Config Class Initialized
INFO - 2021-07-14 09:46:21 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:46:21 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:46:21 --> Utf8 Class Initialized
INFO - 2021-07-14 09:46:21 --> URI Class Initialized
INFO - 2021-07-14 09:46:21 --> Router Class Initialized
INFO - 2021-07-14 09:46:21 --> Output Class Initialized
INFO - 2021-07-14 09:46:21 --> Security Class Initialized
DEBUG - 2021-07-14 09:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:46:21 --> Input Class Initialized
INFO - 2021-07-14 09:46:21 --> Language Class Initialized
INFO - 2021-07-14 09:46:21 --> Loader Class Initialized
INFO - 2021-07-14 09:46:21 --> Helper loaded: html_helper
INFO - 2021-07-14 09:46:21 --> Helper loaded: url_helper
INFO - 2021-07-14 09:46:21 --> Helper loaded: form_helper
INFO - 2021-07-14 09:46:21 --> Database Driver Class Initialized
INFO - 2021-07-14 09:46:21 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:46:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:46:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:46:21 --> Encryption Class Initialized
INFO - 2021-07-14 09:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:46:21 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:46:21 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:46:21 --> Model "user_model" initialized
INFO - 2021-07-14 09:46:21 --> Model "role_model" initialized
INFO - 2021-07-14 09:46:21 --> Controller Class Initialized
INFO - 2021-07-14 09:46:21 --> Helper loaded: language_helper
INFO - 2021-07-14 09:46:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:46:21 --> Model "Customer_model" initialized
INFO - 2021-07-14 09:46:21 --> Final output sent to browser
DEBUG - 2021-07-14 09:46:21 --> Total execution time: 0.0600
INFO - 2021-07-14 09:46:21 --> Config Class Initialized
INFO - 2021-07-14 09:46:21 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:46:21 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:46:21 --> Utf8 Class Initialized
INFO - 2021-07-14 09:46:21 --> URI Class Initialized
INFO - 2021-07-14 09:46:21 --> Router Class Initialized
INFO - 2021-07-14 09:46:21 --> Output Class Initialized
INFO - 2021-07-14 09:46:21 --> Security Class Initialized
DEBUG - 2021-07-14 09:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:46:21 --> Input Class Initialized
INFO - 2021-07-14 09:46:21 --> Language Class Initialized
INFO - 2021-07-14 09:46:21 --> Loader Class Initialized
INFO - 2021-07-14 09:46:21 --> Helper loaded: html_helper
INFO - 2021-07-14 09:46:21 --> Helper loaded: url_helper
INFO - 2021-07-14 09:46:21 --> Helper loaded: form_helper
INFO - 2021-07-14 09:46:21 --> Database Driver Class Initialized
INFO - 2021-07-14 09:46:21 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:46:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:46:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:46:21 --> Encryption Class Initialized
INFO - 2021-07-14 09:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:46:21 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:46:21 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:46:21 --> Model "user_model" initialized
INFO - 2021-07-14 09:46:21 --> Model "role_model" initialized
INFO - 2021-07-14 09:46:21 --> Controller Class Initialized
INFO - 2021-07-14 09:46:21 --> Helper loaded: language_helper
INFO - 2021-07-14 09:46:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:46:21 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 09:46:21 --> Final output sent to browser
DEBUG - 2021-07-14 09:46:21 --> Total execution time: 0.0611
INFO - 2021-07-14 09:46:53 --> Config Class Initialized
INFO - 2021-07-14 09:46:53 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:46:53 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:46:53 --> Utf8 Class Initialized
INFO - 2021-07-14 09:46:53 --> URI Class Initialized
INFO - 2021-07-14 09:46:53 --> Router Class Initialized
INFO - 2021-07-14 09:46:53 --> Output Class Initialized
INFO - 2021-07-14 09:46:53 --> Security Class Initialized
DEBUG - 2021-07-14 09:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:46:53 --> Input Class Initialized
INFO - 2021-07-14 09:46:53 --> Language Class Initialized
INFO - 2021-07-14 09:46:53 --> Loader Class Initialized
INFO - 2021-07-14 09:46:53 --> Helper loaded: html_helper
INFO - 2021-07-14 09:46:53 --> Helper loaded: url_helper
INFO - 2021-07-14 09:46:53 --> Helper loaded: form_helper
INFO - 2021-07-14 09:46:53 --> Database Driver Class Initialized
INFO - 2021-07-14 09:46:53 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:46:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:46:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:46:53 --> Encryption Class Initialized
INFO - 2021-07-14 09:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:46:53 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:46:53 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:46:53 --> Model "user_model" initialized
INFO - 2021-07-14 09:46:53 --> Model "role_model" initialized
INFO - 2021-07-14 09:46:53 --> Controller Class Initialized
INFO - 2021-07-14 09:46:53 --> Helper loaded: language_helper
INFO - 2021-07-14 09:46:53 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:46:53 --> Model "Product_model" initialized
INFO - 2021-07-14 09:46:53 --> Final output sent to browser
DEBUG - 2021-07-14 09:46:53 --> Total execution time: 0.0726
INFO - 2021-07-14 09:48:03 --> Config Class Initialized
INFO - 2021-07-14 09:48:03 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:48:03 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:48:03 --> Utf8 Class Initialized
INFO - 2021-07-14 09:48:03 --> URI Class Initialized
INFO - 2021-07-14 09:48:03 --> Router Class Initialized
INFO - 2021-07-14 09:48:03 --> Output Class Initialized
INFO - 2021-07-14 09:48:03 --> Security Class Initialized
DEBUG - 2021-07-14 09:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:48:03 --> Input Class Initialized
INFO - 2021-07-14 09:48:03 --> Language Class Initialized
INFO - 2021-07-14 09:48:03 --> Loader Class Initialized
INFO - 2021-07-14 09:48:03 --> Helper loaded: html_helper
INFO - 2021-07-14 09:48:03 --> Helper loaded: url_helper
INFO - 2021-07-14 09:48:03 --> Helper loaded: form_helper
INFO - 2021-07-14 09:48:03 --> Database Driver Class Initialized
INFO - 2021-07-14 09:48:03 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:48:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:48:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:48:03 --> Encryption Class Initialized
INFO - 2021-07-14 09:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:48:03 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:48:03 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:48:03 --> Model "user_model" initialized
INFO - 2021-07-14 09:48:03 --> Model "role_model" initialized
INFO - 2021-07-14 09:48:03 --> Controller Class Initialized
INFO - 2021-07-14 09:48:03 --> Helper loaded: language_helper
INFO - 2021-07-14 09:48:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:48:03 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:48:03 --> Final output sent to browser
DEBUG - 2021-07-14 09:48:03 --> Total execution time: 0.0940
INFO - 2021-07-14 09:48:03 --> Config Class Initialized
INFO - 2021-07-14 09:48:03 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:48:03 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:48:03 --> Utf8 Class Initialized
INFO - 2021-07-14 09:48:03 --> URI Class Initialized
INFO - 2021-07-14 09:48:03 --> Router Class Initialized
INFO - 2021-07-14 09:48:03 --> Output Class Initialized
INFO - 2021-07-14 09:48:03 --> Security Class Initialized
DEBUG - 2021-07-14 09:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:48:03 --> Input Class Initialized
INFO - 2021-07-14 09:48:03 --> Language Class Initialized
INFO - 2021-07-14 09:48:03 --> Loader Class Initialized
INFO - 2021-07-14 09:48:03 --> Helper loaded: html_helper
INFO - 2021-07-14 09:48:03 --> Helper loaded: url_helper
INFO - 2021-07-14 09:48:03 --> Helper loaded: form_helper
INFO - 2021-07-14 09:48:03 --> Database Driver Class Initialized
INFO - 2021-07-14 09:48:03 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:48:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:48:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:48:03 --> Encryption Class Initialized
INFO - 2021-07-14 09:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:48:03 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:48:03 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:48:03 --> Model "user_model" initialized
INFO - 2021-07-14 09:48:03 --> Model "role_model" initialized
INFO - 2021-07-14 09:48:03 --> Controller Class Initialized
INFO - 2021-07-14 09:48:03 --> Helper loaded: language_helper
INFO - 2021-07-14 09:48:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:48:03 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:48:03 --> Final output sent to browser
DEBUG - 2021-07-14 09:48:03 --> Total execution time: 0.0764
INFO - 2021-07-14 09:48:05 --> Config Class Initialized
INFO - 2021-07-14 09:48:05 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:48:05 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:48:05 --> Utf8 Class Initialized
INFO - 2021-07-14 09:48:05 --> URI Class Initialized
INFO - 2021-07-14 09:48:05 --> Router Class Initialized
INFO - 2021-07-14 09:48:05 --> Output Class Initialized
INFO - 2021-07-14 09:48:05 --> Security Class Initialized
DEBUG - 2021-07-14 09:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:48:05 --> Input Class Initialized
INFO - 2021-07-14 09:48:05 --> Language Class Initialized
INFO - 2021-07-14 09:48:05 --> Loader Class Initialized
INFO - 2021-07-14 09:48:05 --> Helper loaded: html_helper
INFO - 2021-07-14 09:48:05 --> Helper loaded: url_helper
INFO - 2021-07-14 09:48:05 --> Helper loaded: form_helper
INFO - 2021-07-14 09:48:05 --> Database Driver Class Initialized
INFO - 2021-07-14 09:48:05 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:48:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:48:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:48:05 --> Encryption Class Initialized
INFO - 2021-07-14 09:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:48:05 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:48:05 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:48:05 --> Model "user_model" initialized
INFO - 2021-07-14 09:48:05 --> Model "role_model" initialized
INFO - 2021-07-14 09:48:05 --> Controller Class Initialized
INFO - 2021-07-14 09:48:05 --> Helper loaded: language_helper
INFO - 2021-07-14 09:48:05 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:48:05 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:48:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 09:48:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 09:48:05 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 09:48:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 09:48:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 09:48:05 --> Final output sent to browser
DEBUG - 2021-07-14 09:48:05 --> Total execution time: 0.0836
INFO - 2021-07-14 09:48:06 --> Config Class Initialized
INFO - 2021-07-14 09:48:06 --> Hooks Class Initialized
INFO - 2021-07-14 09:48:06 --> Config Class Initialized
INFO - 2021-07-14 09:48:06 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:48:06 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:48:06 --> Utf8 Class Initialized
DEBUG - 2021-07-14 09:48:06 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:48:06 --> Utf8 Class Initialized
INFO - 2021-07-14 09:48:06 --> URI Class Initialized
INFO - 2021-07-14 09:48:06 --> URI Class Initialized
INFO - 2021-07-14 09:48:06 --> Router Class Initialized
INFO - 2021-07-14 09:48:06 --> Router Class Initialized
INFO - 2021-07-14 09:48:06 --> Output Class Initialized
INFO - 2021-07-14 09:48:06 --> Output Class Initialized
INFO - 2021-07-14 09:48:06 --> Security Class Initialized
INFO - 2021-07-14 09:48:06 --> Security Class Initialized
DEBUG - 2021-07-14 09:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:48:06 --> Input Class Initialized
DEBUG - 2021-07-14 09:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:48:06 --> Input Class Initialized
INFO - 2021-07-14 09:48:06 --> Language Class Initialized
INFO - 2021-07-14 09:48:06 --> Language Class Initialized
INFO - 2021-07-14 09:48:06 --> Loader Class Initialized
INFO - 2021-07-14 09:48:06 --> Loader Class Initialized
INFO - 2021-07-14 09:48:06 --> Helper loaded: html_helper
INFO - 2021-07-14 09:48:06 --> Helper loaded: html_helper
INFO - 2021-07-14 09:48:06 --> Helper loaded: url_helper
INFO - 2021-07-14 09:48:06 --> Helper loaded: url_helper
INFO - 2021-07-14 09:48:06 --> Helper loaded: form_helper
INFO - 2021-07-14 09:48:06 --> Helper loaded: form_helper
INFO - 2021-07-14 09:48:06 --> Database Driver Class Initialized
INFO - 2021-07-14 09:48:06 --> Database Driver Class Initialized
INFO - 2021-07-14 09:48:06 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:48:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:48:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:48:06 --> Encryption Class Initialized
INFO - 2021-07-14 09:48:06 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:48:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:48:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:48:06 --> Encryption Class Initialized
INFO - 2021-07-14 09:48:06 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:48:06 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:48:06 --> Model "user_model" initialized
INFO - 2021-07-14 09:48:06 --> Model "role_model" initialized
INFO - 2021-07-14 09:48:06 --> Controller Class Initialized
INFO - 2021-07-14 09:48:06 --> Helper loaded: language_helper
INFO - 2021-07-14 09:48:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:48:06 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:48:06 --> Final output sent to browser
DEBUG - 2021-07-14 09:48:06 --> Total execution time: 0.0922
INFO - 2021-07-14 09:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:48:06 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:48:06 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:48:06 --> Model "user_model" initialized
INFO - 2021-07-14 09:48:06 --> Model "role_model" initialized
INFO - 2021-07-14 09:48:06 --> Controller Class Initialized
INFO - 2021-07-14 09:48:06 --> Helper loaded: language_helper
INFO - 2021-07-14 09:48:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:48:06 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:48:06 --> Final output sent to browser
DEBUG - 2021-07-14 09:48:06 --> Total execution time: 0.1036
INFO - 2021-07-14 09:48:41 --> Config Class Initialized
INFO - 2021-07-14 09:48:41 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:48:41 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:48:41 --> Utf8 Class Initialized
INFO - 2021-07-14 09:48:41 --> URI Class Initialized
INFO - 2021-07-14 09:48:41 --> Router Class Initialized
INFO - 2021-07-14 09:48:41 --> Output Class Initialized
INFO - 2021-07-14 09:48:41 --> Security Class Initialized
DEBUG - 2021-07-14 09:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:48:41 --> Input Class Initialized
INFO - 2021-07-14 09:48:41 --> Language Class Initialized
INFO - 2021-07-14 09:48:41 --> Loader Class Initialized
INFO - 2021-07-14 09:48:41 --> Helper loaded: html_helper
INFO - 2021-07-14 09:48:41 --> Helper loaded: url_helper
INFO - 2021-07-14 09:48:41 --> Helper loaded: form_helper
INFO - 2021-07-14 09:48:41 --> Database Driver Class Initialized
INFO - 2021-07-14 09:48:41 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:48:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:48:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:48:41 --> Encryption Class Initialized
INFO - 2021-07-14 09:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:48:41 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:48:41 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:48:41 --> Model "user_model" initialized
INFO - 2021-07-14 09:48:41 --> Model "role_model" initialized
INFO - 2021-07-14 09:48:41 --> Controller Class Initialized
INFO - 2021-07-14 09:48:41 --> Helper loaded: language_helper
INFO - 2021-07-14 09:48:41 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:48:41 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:48:41 --> Model "Customer_model" initialized
INFO - 2021-07-14 09:48:41 --> Model "Product_model" initialized
INFO - 2021-07-14 09:48:41 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 09:48:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 09:48:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 09:48:41 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 09:48:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 09:48:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 09:48:41 --> Final output sent to browser
DEBUG - 2021-07-14 09:48:41 --> Total execution time: 0.0900
INFO - 2021-07-14 09:48:44 --> Config Class Initialized
INFO - 2021-07-14 09:48:44 --> Hooks Class Initialized
INFO - 2021-07-14 09:48:44 --> Config Class Initialized
INFO - 2021-07-14 09:48:44 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:48:44 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:48:44 --> Utf8 Class Initialized
DEBUG - 2021-07-14 09:48:44 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:48:44 --> Utf8 Class Initialized
INFO - 2021-07-14 09:48:44 --> URI Class Initialized
INFO - 2021-07-14 09:48:44 --> URI Class Initialized
INFO - 2021-07-14 09:48:44 --> Router Class Initialized
INFO - 2021-07-14 09:48:44 --> Router Class Initialized
INFO - 2021-07-14 09:48:44 --> Output Class Initialized
INFO - 2021-07-14 09:48:44 --> Output Class Initialized
INFO - 2021-07-14 09:48:44 --> Security Class Initialized
INFO - 2021-07-14 09:48:44 --> Security Class Initialized
DEBUG - 2021-07-14 09:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 09:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:48:44 --> Input Class Initialized
INFO - 2021-07-14 09:48:44 --> Input Class Initialized
INFO - 2021-07-14 09:48:44 --> Language Class Initialized
INFO - 2021-07-14 09:48:44 --> Language Class Initialized
INFO - 2021-07-14 09:48:44 --> Loader Class Initialized
INFO - 2021-07-14 09:48:44 --> Loader Class Initialized
INFO - 2021-07-14 09:48:44 --> Helper loaded: html_helper
INFO - 2021-07-14 09:48:44 --> Helper loaded: html_helper
INFO - 2021-07-14 09:48:44 --> Helper loaded: url_helper
INFO - 2021-07-14 09:48:44 --> Helper loaded: url_helper
INFO - 2021-07-14 09:48:44 --> Helper loaded: form_helper
INFO - 2021-07-14 09:48:44 --> Helper loaded: form_helper
INFO - 2021-07-14 09:48:44 --> Database Driver Class Initialized
INFO - 2021-07-14 09:48:44 --> Database Driver Class Initialized
INFO - 2021-07-14 09:48:44 --> Form Validation Class Initialized
INFO - 2021-07-14 09:48:44 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-14 09:48:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:48:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:48:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:48:44 --> Encryption Class Initialized
INFO - 2021-07-14 09:48:44 --> Encryption Class Initialized
INFO - 2021-07-14 09:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:48:44 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:48:44 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:48:44 --> Model "user_model" initialized
INFO - 2021-07-14 09:48:44 --> Model "role_model" initialized
INFO - 2021-07-14 09:48:44 --> Controller Class Initialized
INFO - 2021-07-14 09:48:44 --> Helper loaded: language_helper
INFO - 2021-07-14 09:48:44 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:48:44 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:48:44 --> Final output sent to browser
DEBUG - 2021-07-14 09:48:44 --> Total execution time: 0.0759
INFO - 2021-07-14 09:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:48:44 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:48:44 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:48:44 --> Model "user_model" initialized
INFO - 2021-07-14 09:48:44 --> Model "role_model" initialized
INFO - 2021-07-14 09:48:44 --> Controller Class Initialized
INFO - 2021-07-14 09:48:44 --> Helper loaded: language_helper
INFO - 2021-07-14 09:48:44 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:48:44 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:48:44 --> Final output sent to browser
DEBUG - 2021-07-14 09:48:44 --> Total execution time: 0.0839
INFO - 2021-07-14 09:52:29 --> Config Class Initialized
INFO - 2021-07-14 09:52:29 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:52:29 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:52:29 --> Utf8 Class Initialized
INFO - 2021-07-14 09:52:29 --> URI Class Initialized
INFO - 2021-07-14 09:52:29 --> Router Class Initialized
INFO - 2021-07-14 09:52:29 --> Output Class Initialized
INFO - 2021-07-14 09:52:29 --> Security Class Initialized
DEBUG - 2021-07-14 09:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:52:29 --> Input Class Initialized
INFO - 2021-07-14 09:52:29 --> Language Class Initialized
INFO - 2021-07-14 09:52:29 --> Loader Class Initialized
INFO - 2021-07-14 09:52:29 --> Helper loaded: html_helper
INFO - 2021-07-14 09:52:29 --> Helper loaded: url_helper
INFO - 2021-07-14 09:52:29 --> Helper loaded: form_helper
INFO - 2021-07-14 09:52:29 --> Database Driver Class Initialized
INFO - 2021-07-14 09:52:29 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:52:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:52:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:52:29 --> Encryption Class Initialized
INFO - 2021-07-14 09:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:52:29 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:52:29 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:52:29 --> Model "user_model" initialized
INFO - 2021-07-14 09:52:29 --> Model "role_model" initialized
INFO - 2021-07-14 09:52:29 --> Controller Class Initialized
INFO - 2021-07-14 09:52:29 --> Helper loaded: language_helper
INFO - 2021-07-14 09:52:29 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:52:29 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:52:29 --> Model "Customer_model" initialized
INFO - 2021-07-14 09:52:29 --> Model "Product_model" initialized
INFO - 2021-07-14 09:52:29 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 09:52:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 09:52:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 09:52:29 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 09:52:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 09:52:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 09:52:29 --> Final output sent to browser
DEBUG - 2021-07-14 09:52:29 --> Total execution time: 0.0975
INFO - 2021-07-14 09:52:36 --> Config Class Initialized
INFO - 2021-07-14 09:52:36 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:52:36 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:52:36 --> Utf8 Class Initialized
INFO - 2021-07-14 09:52:36 --> URI Class Initialized
INFO - 2021-07-14 09:52:36 --> Router Class Initialized
INFO - 2021-07-14 09:52:36 --> Output Class Initialized
INFO - 2021-07-14 09:52:36 --> Security Class Initialized
DEBUG - 2021-07-14 09:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:52:36 --> Input Class Initialized
INFO - 2021-07-14 09:52:36 --> Language Class Initialized
INFO - 2021-07-14 09:52:36 --> Loader Class Initialized
INFO - 2021-07-14 09:52:36 --> Helper loaded: html_helper
INFO - 2021-07-14 09:52:36 --> Helper loaded: url_helper
INFO - 2021-07-14 09:52:36 --> Helper loaded: form_helper
INFO - 2021-07-14 09:52:36 --> Database Driver Class Initialized
INFO - 2021-07-14 09:52:36 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:52:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:52:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:52:36 --> Encryption Class Initialized
INFO - 2021-07-14 09:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:52:36 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:52:36 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:52:36 --> Model "user_model" initialized
INFO - 2021-07-14 09:52:36 --> Model "role_model" initialized
INFO - 2021-07-14 09:52:36 --> Controller Class Initialized
INFO - 2021-07-14 09:52:36 --> Helper loaded: language_helper
INFO - 2021-07-14 09:52:36 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:52:36 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:52:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 09:52:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 09:52:36 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 09:52:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 09:52:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 09:52:36 --> Final output sent to browser
DEBUG - 2021-07-14 09:52:36 --> Total execution time: 0.0801
INFO - 2021-07-14 09:52:44 --> Config Class Initialized
INFO - 2021-07-14 09:52:44 --> Hooks Class Initialized
INFO - 2021-07-14 09:52:44 --> Config Class Initialized
INFO - 2021-07-14 09:52:44 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:52:44 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:52:44 --> Utf8 Class Initialized
DEBUG - 2021-07-14 09:52:44 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:52:44 --> Utf8 Class Initialized
INFO - 2021-07-14 09:52:44 --> URI Class Initialized
INFO - 2021-07-14 09:52:44 --> URI Class Initialized
INFO - 2021-07-14 09:52:44 --> Router Class Initialized
INFO - 2021-07-14 09:52:44 --> Router Class Initialized
INFO - 2021-07-14 09:52:44 --> Output Class Initialized
INFO - 2021-07-14 09:52:44 --> Output Class Initialized
INFO - 2021-07-14 09:52:44 --> Security Class Initialized
INFO - 2021-07-14 09:52:44 --> Security Class Initialized
DEBUG - 2021-07-14 09:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 09:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:52:44 --> Input Class Initialized
INFO - 2021-07-14 09:52:44 --> Input Class Initialized
INFO - 2021-07-14 09:52:44 --> Language Class Initialized
INFO - 2021-07-14 09:52:44 --> Language Class Initialized
INFO - 2021-07-14 09:52:44 --> Loader Class Initialized
INFO - 2021-07-14 09:52:44 --> Loader Class Initialized
INFO - 2021-07-14 09:52:44 --> Helper loaded: html_helper
INFO - 2021-07-14 09:52:44 --> Helper loaded: html_helper
INFO - 2021-07-14 09:52:44 --> Helper loaded: url_helper
INFO - 2021-07-14 09:52:44 --> Helper loaded: url_helper
INFO - 2021-07-14 09:52:44 --> Helper loaded: form_helper
INFO - 2021-07-14 09:52:44 --> Helper loaded: form_helper
INFO - 2021-07-14 09:52:44 --> Database Driver Class Initialized
INFO - 2021-07-14 09:52:44 --> Database Driver Class Initialized
INFO - 2021-07-14 09:52:44 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:52:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:52:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:52:44 --> Encryption Class Initialized
INFO - 2021-07-14 09:52:44 --> Form Validation Class Initialized
INFO - 2021-07-14 09:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:52:44 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:52:44 --> Model "coupon_model" initialized
DEBUG - 2021-07-14 09:52:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:52:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:52:44 --> Model "user_model" initialized
INFO - 2021-07-14 09:52:44 --> Encryption Class Initialized
INFO - 2021-07-14 09:52:44 --> Model "role_model" initialized
INFO - 2021-07-14 09:52:44 --> Controller Class Initialized
INFO - 2021-07-14 09:52:44 --> Helper loaded: language_helper
INFO - 2021-07-14 09:52:44 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:52:44 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:52:44 --> Final output sent to browser
DEBUG - 2021-07-14 09:52:44 --> Total execution time: 0.0818
INFO - 2021-07-14 09:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:52:44 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:52:44 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:52:44 --> Model "user_model" initialized
INFO - 2021-07-14 09:52:44 --> Model "role_model" initialized
INFO - 2021-07-14 09:52:44 --> Controller Class Initialized
INFO - 2021-07-14 09:52:44 --> Helper loaded: language_helper
INFO - 2021-07-14 09:52:44 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:52:44 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:52:44 --> Final output sent to browser
DEBUG - 2021-07-14 09:52:44 --> Total execution time: 0.0920
INFO - 2021-07-14 09:52:51 --> Config Class Initialized
INFO - 2021-07-14 09:52:51 --> Hooks Class Initialized
INFO - 2021-07-14 09:52:51 --> Config Class Initialized
INFO - 2021-07-14 09:52:51 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:52:51 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 09:52:51 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:52:51 --> Utf8 Class Initialized
INFO - 2021-07-14 09:52:51 --> Utf8 Class Initialized
INFO - 2021-07-14 09:52:51 --> URI Class Initialized
INFO - 2021-07-14 09:52:51 --> URI Class Initialized
INFO - 2021-07-14 09:52:51 --> Router Class Initialized
INFO - 2021-07-14 09:52:51 --> Router Class Initialized
INFO - 2021-07-14 09:52:51 --> Output Class Initialized
INFO - 2021-07-14 09:52:51 --> Output Class Initialized
INFO - 2021-07-14 09:52:51 --> Security Class Initialized
INFO - 2021-07-14 09:52:51 --> Security Class Initialized
DEBUG - 2021-07-14 09:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 09:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:52:51 --> Input Class Initialized
INFO - 2021-07-14 09:52:51 --> Input Class Initialized
INFO - 2021-07-14 09:52:51 --> Language Class Initialized
INFO - 2021-07-14 09:52:51 --> Language Class Initialized
INFO - 2021-07-14 09:52:51 --> Loader Class Initialized
INFO - 2021-07-14 09:52:51 --> Loader Class Initialized
INFO - 2021-07-14 09:52:51 --> Helper loaded: html_helper
INFO - 2021-07-14 09:52:51 --> Helper loaded: html_helper
INFO - 2021-07-14 09:52:51 --> Helper loaded: url_helper
INFO - 2021-07-14 09:52:51 --> Helper loaded: url_helper
INFO - 2021-07-14 09:52:51 --> Helper loaded: form_helper
INFO - 2021-07-14 09:52:51 --> Helper loaded: form_helper
INFO - 2021-07-14 09:52:51 --> Database Driver Class Initialized
INFO - 2021-07-14 09:52:51 --> Database Driver Class Initialized
INFO - 2021-07-14 09:52:51 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:52:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:52:51 --> Form Validation Class Initialized
INFO - 2021-07-14 09:52:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:52:51 --> Encryption Class Initialized
DEBUG - 2021-07-14 09:52:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:52:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:52:51 --> Encryption Class Initialized
INFO - 2021-07-14 09:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:52:51 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:52:51 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:52:51 --> Model "user_model" initialized
INFO - 2021-07-14 09:52:51 --> Model "role_model" initialized
INFO - 2021-07-14 09:52:51 --> Controller Class Initialized
INFO - 2021-07-14 09:52:51 --> Helper loaded: language_helper
INFO - 2021-07-14 09:52:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:52:51 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:52:51 --> Final output sent to browser
DEBUG - 2021-07-14 09:52:51 --> Total execution time: 0.0814
INFO - 2021-07-14 09:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:52:51 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:52:51 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:52:51 --> Model "user_model" initialized
INFO - 2021-07-14 09:52:51 --> Model "role_model" initialized
INFO - 2021-07-14 09:52:51 --> Controller Class Initialized
INFO - 2021-07-14 09:52:51 --> Helper loaded: language_helper
INFO - 2021-07-14 09:52:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:52:51 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:52:51 --> Final output sent to browser
DEBUG - 2021-07-14 09:52:51 --> Total execution time: 0.0901
INFO - 2021-07-14 09:52:54 --> Config Class Initialized
INFO - 2021-07-14 09:52:54 --> Config Class Initialized
INFO - 2021-07-14 09:52:54 --> Hooks Class Initialized
INFO - 2021-07-14 09:52:54 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:52:54 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 09:52:54 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:52:54 --> Utf8 Class Initialized
INFO - 2021-07-14 09:52:54 --> Utf8 Class Initialized
INFO - 2021-07-14 09:52:54 --> URI Class Initialized
INFO - 2021-07-14 09:52:54 --> URI Class Initialized
INFO - 2021-07-14 09:52:54 --> Router Class Initialized
INFO - 2021-07-14 09:52:54 --> Router Class Initialized
INFO - 2021-07-14 09:52:54 --> Output Class Initialized
INFO - 2021-07-14 09:52:54 --> Output Class Initialized
INFO - 2021-07-14 09:52:54 --> Security Class Initialized
INFO - 2021-07-14 09:52:54 --> Security Class Initialized
DEBUG - 2021-07-14 09:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 09:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:52:54 --> Input Class Initialized
INFO - 2021-07-14 09:52:54 --> Input Class Initialized
INFO - 2021-07-14 09:52:54 --> Language Class Initialized
INFO - 2021-07-14 09:52:54 --> Language Class Initialized
INFO - 2021-07-14 09:52:54 --> Loader Class Initialized
INFO - 2021-07-14 09:52:54 --> Loader Class Initialized
INFO - 2021-07-14 09:52:54 --> Helper loaded: html_helper
INFO - 2021-07-14 09:52:54 --> Helper loaded: html_helper
INFO - 2021-07-14 09:52:54 --> Helper loaded: url_helper
INFO - 2021-07-14 09:52:54 --> Helper loaded: url_helper
INFO - 2021-07-14 09:52:54 --> Helper loaded: form_helper
INFO - 2021-07-14 09:52:54 --> Helper loaded: form_helper
INFO - 2021-07-14 09:52:54 --> Database Driver Class Initialized
INFO - 2021-07-14 09:52:54 --> Database Driver Class Initialized
INFO - 2021-07-14 09:52:54 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:52:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:52:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:52:54 --> Encryption Class Initialized
INFO - 2021-07-14 09:52:54 --> Form Validation Class Initialized
INFO - 2021-07-14 09:52:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-07-14 09:52:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:52:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:52:54 --> Encryption Class Initialized
INFO - 2021-07-14 09:52:54 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:52:54 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:52:54 --> Model "user_model" initialized
INFO - 2021-07-14 09:52:54 --> Model "role_model" initialized
INFO - 2021-07-14 09:52:54 --> Controller Class Initialized
INFO - 2021-07-14 09:52:54 --> Helper loaded: language_helper
INFO - 2021-07-14 09:52:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:52:54 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:52:54 --> Final output sent to browser
DEBUG - 2021-07-14 09:52:54 --> Total execution time: 0.0636
INFO - 2021-07-14 09:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:52:54 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:52:54 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:52:54 --> Model "user_model" initialized
INFO - 2021-07-14 09:52:54 --> Model "role_model" initialized
INFO - 2021-07-14 09:52:54 --> Controller Class Initialized
INFO - 2021-07-14 09:52:54 --> Helper loaded: language_helper
INFO - 2021-07-14 09:52:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:52:54 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:52:54 --> Final output sent to browser
DEBUG - 2021-07-14 09:52:54 --> Total execution time: 0.0722
INFO - 2021-07-14 09:53:00 --> Config Class Initialized
INFO - 2021-07-14 09:53:00 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:53:00 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:53:00 --> Utf8 Class Initialized
INFO - 2021-07-14 09:53:00 --> URI Class Initialized
INFO - 2021-07-14 09:53:00 --> Router Class Initialized
INFO - 2021-07-14 09:53:00 --> Output Class Initialized
INFO - 2021-07-14 09:53:00 --> Security Class Initialized
DEBUG - 2021-07-14 09:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:53:00 --> Input Class Initialized
INFO - 2021-07-14 09:53:00 --> Language Class Initialized
INFO - 2021-07-14 09:53:00 --> Loader Class Initialized
INFO - 2021-07-14 09:53:00 --> Helper loaded: html_helper
INFO - 2021-07-14 09:53:00 --> Helper loaded: url_helper
INFO - 2021-07-14 09:53:00 --> Helper loaded: form_helper
INFO - 2021-07-14 09:53:00 --> Database Driver Class Initialized
INFO - 2021-07-14 09:53:00 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:53:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:53:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:53:00 --> Encryption Class Initialized
INFO - 2021-07-14 09:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:53:00 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:53:00 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:53:00 --> Model "user_model" initialized
INFO - 2021-07-14 09:53:00 --> Model "role_model" initialized
INFO - 2021-07-14 09:53:00 --> Controller Class Initialized
INFO - 2021-07-14 09:53:00 --> Helper loaded: language_helper
INFO - 2021-07-14 09:53:00 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:53:00 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:53:00 --> Model "Customer_model" initialized
INFO - 2021-07-14 09:53:00 --> Model "Product_model" initialized
INFO - 2021-07-14 09:53:00 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 09:53:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 09:53:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 09:53:00 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 09:53:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 09:53:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 09:53:00 --> Final output sent to browser
DEBUG - 2021-07-14 09:53:00 --> Total execution time: 0.0820
INFO - 2021-07-14 09:53:51 --> Config Class Initialized
INFO - 2021-07-14 09:53:51 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:53:51 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:53:51 --> Utf8 Class Initialized
INFO - 2021-07-14 09:53:51 --> URI Class Initialized
INFO - 2021-07-14 09:53:51 --> Router Class Initialized
INFO - 2021-07-14 09:53:51 --> Output Class Initialized
INFO - 2021-07-14 09:53:51 --> Security Class Initialized
DEBUG - 2021-07-14 09:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:53:51 --> Input Class Initialized
INFO - 2021-07-14 09:53:51 --> Language Class Initialized
INFO - 2021-07-14 09:53:51 --> Loader Class Initialized
INFO - 2021-07-14 09:53:51 --> Helper loaded: html_helper
INFO - 2021-07-14 09:53:51 --> Helper loaded: url_helper
INFO - 2021-07-14 09:53:51 --> Helper loaded: form_helper
INFO - 2021-07-14 09:53:51 --> Database Driver Class Initialized
INFO - 2021-07-14 09:53:51 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:53:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:53:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:53:51 --> Encryption Class Initialized
INFO - 2021-07-14 09:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:53:51 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:53:51 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:53:51 --> Model "user_model" initialized
INFO - 2021-07-14 09:53:51 --> Model "role_model" initialized
INFO - 2021-07-14 09:53:51 --> Controller Class Initialized
INFO - 2021-07-14 09:53:51 --> Helper loaded: language_helper
INFO - 2021-07-14 09:53:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:53:51 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:53:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 09:53:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 09:53:51 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-14 09:53:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-14 09:53:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 09:53:51 --> Final output sent to browser
DEBUG - 2021-07-14 09:53:51 --> Total execution time: 0.0802
INFO - 2021-07-14 09:53:56 --> Config Class Initialized
INFO - 2021-07-14 09:53:56 --> Config Class Initialized
INFO - 2021-07-14 09:53:56 --> Hooks Class Initialized
INFO - 2021-07-14 09:53:56 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:53:56 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 09:53:56 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:53:56 --> Utf8 Class Initialized
INFO - 2021-07-14 09:53:56 --> Utf8 Class Initialized
INFO - 2021-07-14 09:53:56 --> URI Class Initialized
INFO - 2021-07-14 09:53:56 --> URI Class Initialized
INFO - 2021-07-14 09:53:56 --> Router Class Initialized
INFO - 2021-07-14 09:53:56 --> Router Class Initialized
INFO - 2021-07-14 09:53:56 --> Output Class Initialized
INFO - 2021-07-14 09:53:56 --> Output Class Initialized
INFO - 2021-07-14 09:53:56 --> Security Class Initialized
INFO - 2021-07-14 09:53:56 --> Security Class Initialized
DEBUG - 2021-07-14 09:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-14 09:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:53:56 --> Input Class Initialized
INFO - 2021-07-14 09:53:56 --> Input Class Initialized
INFO - 2021-07-14 09:53:56 --> Language Class Initialized
INFO - 2021-07-14 09:53:56 --> Language Class Initialized
INFO - 2021-07-14 09:53:56 --> Loader Class Initialized
INFO - 2021-07-14 09:53:56 --> Loader Class Initialized
INFO - 2021-07-14 09:53:56 --> Helper loaded: html_helper
INFO - 2021-07-14 09:53:56 --> Helper loaded: html_helper
INFO - 2021-07-14 09:53:56 --> Helper loaded: url_helper
INFO - 2021-07-14 09:53:56 --> Helper loaded: url_helper
INFO - 2021-07-14 09:53:56 --> Helper loaded: form_helper
INFO - 2021-07-14 09:53:56 --> Helper loaded: form_helper
INFO - 2021-07-14 09:53:56 --> Database Driver Class Initialized
INFO - 2021-07-14 09:53:56 --> Database Driver Class Initialized
INFO - 2021-07-14 09:53:56 --> Form Validation Class Initialized
INFO - 2021-07-14 09:53:56 --> Form Validation Class Initialized
DEBUG - 2021-07-14 09:53:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:53:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:53:56 --> Encryption Class Initialized
DEBUG - 2021-07-14 09:53:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 09:53:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 09:53:56 --> Encryption Class Initialized
INFO - 2021-07-14 09:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:53:56 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:53:56 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:53:56 --> Model "user_model" initialized
INFO - 2021-07-14 09:53:56 --> Model "role_model" initialized
INFO - 2021-07-14 09:53:56 --> Controller Class Initialized
INFO - 2021-07-14 09:53:56 --> Helper loaded: language_helper
INFO - 2021-07-14 09:53:56 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:53:56 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:53:56 --> Final output sent to browser
DEBUG - 2021-07-14 09:53:56 --> Total execution time: 0.0783
INFO - 2021-07-14 09:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:53:56 --> Model "vendor_model" initialized
INFO - 2021-07-14 09:53:56 --> Model "coupon_model" initialized
INFO - 2021-07-14 09:53:56 --> Model "user_model" initialized
INFO - 2021-07-14 09:53:56 --> Model "role_model" initialized
INFO - 2021-07-14 09:53:56 --> Controller Class Initialized
INFO - 2021-07-14 09:53:56 --> Helper loaded: language_helper
INFO - 2021-07-14 09:53:56 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 09:53:56 --> Model "Quotation_model" initialized
INFO - 2021-07-14 09:53:56 --> Final output sent to browser
DEBUG - 2021-07-14 09:53:56 --> Total execution time: 0.0890
INFO - 2021-07-14 12:45:40 --> Config Class Initialized
INFO - 2021-07-14 12:45:40 --> Hooks Class Initialized
DEBUG - 2021-07-14 12:45:40 --> UTF-8 Support Enabled
INFO - 2021-07-14 12:45:40 --> Utf8 Class Initialized
INFO - 2021-07-14 12:45:40 --> URI Class Initialized
INFO - 2021-07-14 12:45:40 --> Router Class Initialized
INFO - 2021-07-14 12:45:40 --> Output Class Initialized
INFO - 2021-07-14 12:45:40 --> Security Class Initialized
DEBUG - 2021-07-14 12:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 12:45:40 --> Input Class Initialized
INFO - 2021-07-14 12:45:40 --> Language Class Initialized
INFO - 2021-07-14 12:45:40 --> Loader Class Initialized
INFO - 2021-07-14 12:45:40 --> Helper loaded: html_helper
INFO - 2021-07-14 12:45:40 --> Helper loaded: url_helper
INFO - 2021-07-14 12:45:40 --> Helper loaded: form_helper
INFO - 2021-07-14 12:45:40 --> Database Driver Class Initialized
INFO - 2021-07-14 12:45:40 --> Form Validation Class Initialized
DEBUG - 2021-07-14 12:45:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 12:45:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 12:45:40 --> Encryption Class Initialized
INFO - 2021-07-14 12:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 12:45:40 --> Model "vendor_model" initialized
INFO - 2021-07-14 12:45:40 --> Model "coupon_model" initialized
INFO - 2021-07-14 12:45:40 --> Model "user_model" initialized
INFO - 2021-07-14 12:45:40 --> Model "role_model" initialized
INFO - 2021-07-14 12:45:40 --> Controller Class Initialized
INFO - 2021-07-14 12:45:40 --> Helper loaded: language_helper
INFO - 2021-07-14 12:45:40 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 12:45:40 --> Model "Quotation_model" initialized
INFO - 2021-07-14 12:45:40 --> Model "Customer_model" initialized
INFO - 2021-07-14 12:45:40 --> Model "Product_model" initialized
INFO - 2021-07-14 12:45:40 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-14 12:45:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-14 12:45:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-14 12:45:40 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 42
INFO - 2021-07-14 12:45:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-14 12:45:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 12:45:40 --> Final output sent to browser
DEBUG - 2021-07-14 12:45:40 --> Total execution time: 0.1325
INFO - 2021-07-14 12:46:02 --> Config Class Initialized
INFO - 2021-07-14 12:46:02 --> Hooks Class Initialized
DEBUG - 2021-07-14 12:46:02 --> UTF-8 Support Enabled
INFO - 2021-07-14 12:46:02 --> Utf8 Class Initialized
INFO - 2021-07-14 12:46:02 --> URI Class Initialized
DEBUG - 2021-07-14 12:46:02 --> No URI present. Default controller set.
INFO - 2021-07-14 12:46:02 --> Router Class Initialized
INFO - 2021-07-14 12:46:02 --> Output Class Initialized
INFO - 2021-07-14 12:46:02 --> Security Class Initialized
DEBUG - 2021-07-14 12:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 12:46:02 --> Input Class Initialized
INFO - 2021-07-14 12:46:02 --> Language Class Initialized
INFO - 2021-07-14 12:46:02 --> Loader Class Initialized
INFO - 2021-07-14 12:46:02 --> Helper loaded: html_helper
INFO - 2021-07-14 12:46:02 --> Helper loaded: url_helper
INFO - 2021-07-14 12:46:02 --> Helper loaded: form_helper
INFO - 2021-07-14 12:46:02 --> Database Driver Class Initialized
INFO - 2021-07-14 12:46:02 --> Form Validation Class Initialized
DEBUG - 2021-07-14 12:46:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 12:46:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 12:46:02 --> Encryption Class Initialized
INFO - 2021-07-14 12:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 12:46:02 --> Model "vendor_model" initialized
INFO - 2021-07-14 12:46:02 --> Model "coupon_model" initialized
INFO - 2021-07-14 12:46:02 --> Model "user_model" initialized
INFO - 2021-07-14 12:46:02 --> Model "role_model" initialized
INFO - 2021-07-14 12:46:02 --> Controller Class Initialized
INFO - 2021-07-14 12:46:02 --> Helper loaded: language_helper
INFO - 2021-07-14 12:46:02 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 12:46:02 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\login.php
INFO - 2021-07-14 12:46:02 --> Final output sent to browser
DEBUG - 2021-07-14 12:46:02 --> Total execution time: 0.1276
INFO - 2021-07-14 12:46:12 --> Config Class Initialized
INFO - 2021-07-14 12:46:12 --> Hooks Class Initialized
DEBUG - 2021-07-14 12:46:12 --> UTF-8 Support Enabled
INFO - 2021-07-14 12:46:12 --> Utf8 Class Initialized
INFO - 2021-07-14 12:46:12 --> URI Class Initialized
INFO - 2021-07-14 12:46:12 --> Router Class Initialized
INFO - 2021-07-14 12:46:12 --> Output Class Initialized
INFO - 2021-07-14 12:46:12 --> Security Class Initialized
DEBUG - 2021-07-14 12:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 12:46:12 --> Input Class Initialized
INFO - 2021-07-14 12:46:12 --> Language Class Initialized
INFO - 2021-07-14 12:46:12 --> Loader Class Initialized
INFO - 2021-07-14 12:46:12 --> Helper loaded: html_helper
INFO - 2021-07-14 12:46:12 --> Helper loaded: url_helper
INFO - 2021-07-14 12:46:12 --> Helper loaded: form_helper
INFO - 2021-07-14 12:46:12 --> Database Driver Class Initialized
INFO - 2021-07-14 12:46:12 --> Form Validation Class Initialized
DEBUG - 2021-07-14 12:46:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 12:46:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 12:46:12 --> Encryption Class Initialized
INFO - 2021-07-14 12:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 12:46:12 --> Model "vendor_model" initialized
INFO - 2021-07-14 12:46:12 --> Model "coupon_model" initialized
INFO - 2021-07-14 12:46:12 --> Model "user_model" initialized
INFO - 2021-07-14 12:46:12 --> Model "role_model" initialized
INFO - 2021-07-14 12:46:12 --> Controller Class Initialized
INFO - 2021-07-14 12:46:12 --> Helper loaded: language_helper
INFO - 2021-07-14 12:46:12 --> Language file loaded: language/english/content_lang.php
DEBUG - 2021-07-14 12:46:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-14 12:46:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-07-14 12:46:12 --> Model "User" initialized
INFO - 2021-07-14 12:46:12 --> Config Class Initialized
INFO - 2021-07-14 12:46:12 --> Hooks Class Initialized
DEBUG - 2021-07-14 12:46:12 --> UTF-8 Support Enabled
INFO - 2021-07-14 12:46:12 --> Utf8 Class Initialized
INFO - 2021-07-14 12:46:12 --> URI Class Initialized
INFO - 2021-07-14 12:46:12 --> Router Class Initialized
INFO - 2021-07-14 12:46:12 --> Output Class Initialized
INFO - 2021-07-14 12:46:12 --> Security Class Initialized
DEBUG - 2021-07-14 12:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 12:46:12 --> Input Class Initialized
INFO - 2021-07-14 12:46:12 --> Language Class Initialized
INFO - 2021-07-14 12:46:12 --> Loader Class Initialized
INFO - 2021-07-14 12:46:12 --> Helper loaded: html_helper
INFO - 2021-07-14 12:46:12 --> Helper loaded: url_helper
INFO - 2021-07-14 12:46:12 --> Helper loaded: form_helper
INFO - 2021-07-14 12:46:12 --> Database Driver Class Initialized
INFO - 2021-07-14 12:46:12 --> Form Validation Class Initialized
DEBUG - 2021-07-14 12:46:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-14 12:46:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-14 12:46:12 --> Encryption Class Initialized
INFO - 2021-07-14 12:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 12:46:13 --> Model "vendor_model" initialized
INFO - 2021-07-14 12:46:13 --> Model "coupon_model" initialized
INFO - 2021-07-14 12:46:13 --> Model "user_model" initialized
INFO - 2021-07-14 12:46:13 --> Model "role_model" initialized
INFO - 2021-07-14 12:46:13 --> Controller Class Initialized
INFO - 2021-07-14 12:46:13 --> Helper loaded: language_helper
INFO - 2021-07-14 12:46:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-14 12:46:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-14 12:46:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-14 12:46:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-14 12:46:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-14 12:46:13 --> Final output sent to browser
DEBUG - 2021-07-14 12:46:13 --> Total execution time: 0.0624
