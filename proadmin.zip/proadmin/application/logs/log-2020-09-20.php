<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-20 02:28:04 --> Config Class Initialized
INFO - 2020-09-20 02:28:04 --> Hooks Class Initialized
DEBUG - 2020-09-20 02:28:04 --> UTF-8 Support Enabled
INFO - 2020-09-20 02:28:04 --> Utf8 Class Initialized
INFO - 2020-09-20 02:28:04 --> URI Class Initialized
INFO - 2020-09-20 02:28:04 --> Router Class Initialized
INFO - 2020-09-20 02:28:04 --> Output Class Initialized
INFO - 2020-09-20 02:28:04 --> Security Class Initialized
DEBUG - 2020-09-20 02:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 02:28:04 --> Input Class Initialized
INFO - 2020-09-20 02:28:04 --> Language Class Initialized
INFO - 2020-09-20 02:28:04 --> Loader Class Initialized
INFO - 2020-09-20 02:28:04 --> Helper loaded: html_helper
INFO - 2020-09-20 02:28:04 --> Helper loaded: url_helper
INFO - 2020-09-20 02:28:04 --> Helper loaded: form_helper
INFO - 2020-09-20 02:28:05 --> Database Driver Class Initialized
INFO - 2020-09-20 02:28:05 --> Form Validation Class Initialized
DEBUG - 2020-09-20 02:28:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-20 02:28:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-20 02:28:05 --> Encryption Class Initialized
INFO - 2020-09-20 02:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 02:28:05 --> Controller Class Initialized
INFO - 2020-09-20 02:28:05 --> Helper loaded: language_helper
INFO - 2020-09-20 02:28:05 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-20 02:28:05 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-20 02:28:05 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-20 02:28:05 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\customer_care.php
INFO - 2020-09-20 02:28:05 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-20 02:28:05 --> Final output sent to browser
DEBUG - 2020-09-20 02:28:05 --> Total execution time: 1.3402
INFO - 2020-09-20 02:28:23 --> Config Class Initialized
INFO - 2020-09-20 02:28:23 --> Hooks Class Initialized
DEBUG - 2020-09-20 02:28:23 --> UTF-8 Support Enabled
INFO - 2020-09-20 02:28:23 --> Utf8 Class Initialized
INFO - 2020-09-20 02:28:23 --> URI Class Initialized
INFO - 2020-09-20 02:28:23 --> Router Class Initialized
INFO - 2020-09-20 02:28:23 --> Output Class Initialized
INFO - 2020-09-20 02:28:23 --> Security Class Initialized
DEBUG - 2020-09-20 02:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 02:28:23 --> Input Class Initialized
INFO - 2020-09-20 02:28:23 --> Language Class Initialized
INFO - 2020-09-20 02:28:23 --> Loader Class Initialized
INFO - 2020-09-20 02:28:23 --> Helper loaded: html_helper
INFO - 2020-09-20 02:28:23 --> Helper loaded: url_helper
INFO - 2020-09-20 02:28:23 --> Helper loaded: form_helper
INFO - 2020-09-20 02:28:23 --> Database Driver Class Initialized
INFO - 2020-09-20 02:28:23 --> Form Validation Class Initialized
DEBUG - 2020-09-20 02:28:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-20 02:28:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-20 02:28:23 --> Encryption Class Initialized
INFO - 2020-09-20 02:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 02:28:23 --> Controller Class Initialized
INFO - 2020-09-20 02:28:23 --> Helper loaded: language_helper
INFO - 2020-09-20 02:28:23 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-20 02:28:23 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-20 02:28:23 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-20 02:28:23 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment_custom.php
INFO - 2020-09-20 02:28:23 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-20 02:28:24 --> Final output sent to browser
DEBUG - 2020-09-20 02:28:24 --> Total execution time: 1.0419
