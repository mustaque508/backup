<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-14 04:41:51 --> Config Class Initialized
INFO - 2020-09-14 04:41:51 --> Hooks Class Initialized
DEBUG - 2020-09-14 04:41:51 --> UTF-8 Support Enabled
INFO - 2020-09-14 04:41:51 --> Utf8 Class Initialized
INFO - 2020-09-14 04:41:51 --> URI Class Initialized
INFO - 2020-09-14 04:41:51 --> Router Class Initialized
INFO - 2020-09-14 04:41:51 --> Output Class Initialized
INFO - 2020-09-14 04:41:51 --> Security Class Initialized
DEBUG - 2020-09-14 04:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 04:41:51 --> Input Class Initialized
INFO - 2020-09-14 04:41:51 --> Language Class Initialized
INFO - 2020-09-14 04:41:52 --> Loader Class Initialized
INFO - 2020-09-14 04:41:52 --> Helper loaded: html_helper
INFO - 2020-09-14 04:41:52 --> Helper loaded: url_helper
INFO - 2020-09-14 04:41:52 --> Helper loaded: form_helper
INFO - 2020-09-14 04:41:52 --> Database Driver Class Initialized
INFO - 2020-09-14 04:41:52 --> Form Validation Class Initialized
DEBUG - 2020-09-14 04:41:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-14 04:41:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-14 04:41:52 --> Encryption Class Initialized
INFO - 2020-09-14 04:41:53 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-14 04:41:53 --> Controller Class Initialized
INFO - 2020-09-14 04:41:53 --> Helper loaded: language_helper
INFO - 2020-09-14 04:41:53 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-14 04:41:53 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-14 04:41:53 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-14 04:41:53 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment_custom.php
INFO - 2020-09-14 04:41:53 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-14 04:41:53 --> Final output sent to browser
DEBUG - 2020-09-14 04:41:53 --> Total execution time: 2.5466
