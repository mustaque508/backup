<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-16 04:01:16 --> Config Class Initialized
INFO - 2020-09-16 04:01:16 --> Hooks Class Initialized
DEBUG - 2020-09-16 04:01:16 --> UTF-8 Support Enabled
INFO - 2020-09-16 04:01:16 --> Utf8 Class Initialized
INFO - 2020-09-16 04:01:16 --> URI Class Initialized
INFO - 2020-09-16 04:01:16 --> Router Class Initialized
INFO - 2020-09-16 04:01:16 --> Output Class Initialized
INFO - 2020-09-16 04:01:16 --> Security Class Initialized
DEBUG - 2020-09-16 04:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 04:01:16 --> Input Class Initialized
INFO - 2020-09-16 04:01:16 --> Language Class Initialized
INFO - 2020-09-16 04:01:17 --> Loader Class Initialized
INFO - 2020-09-16 04:01:17 --> Helper loaded: html_helper
INFO - 2020-09-16 04:01:17 --> Helper loaded: url_helper
INFO - 2020-09-16 04:01:17 --> Helper loaded: form_helper
INFO - 2020-09-16 04:01:17 --> Database Driver Class Initialized
INFO - 2020-09-16 04:01:17 --> Form Validation Class Initialized
DEBUG - 2020-09-16 04:01:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-16 04:01:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-16 04:01:17 --> Encryption Class Initialized
INFO - 2020-09-16 04:01:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-16 04:01:18 --> Controller Class Initialized
INFO - 2020-09-16 04:01:18 --> Helper loaded: language_helper
INFO - 2020-09-16 04:01:18 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-16 04:01:18 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-16 04:01:18 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-16 04:01:19 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment_custom.php
INFO - 2020-09-16 04:01:19 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-16 04:01:19 --> Final output sent to browser
DEBUG - 2020-09-16 04:01:19 --> Total execution time: 2.9497
INFO - 2020-09-16 06:26:43 --> Config Class Initialized
INFO - 2020-09-16 06:26:43 --> Hooks Class Initialized
DEBUG - 2020-09-16 06:26:43 --> UTF-8 Support Enabled
INFO - 2020-09-16 06:26:43 --> Utf8 Class Initialized
INFO - 2020-09-16 06:26:43 --> URI Class Initialized
DEBUG - 2020-09-16 06:26:43 --> No URI present. Default controller set.
INFO - 2020-09-16 06:26:43 --> Router Class Initialized
INFO - 2020-09-16 06:26:43 --> Output Class Initialized
INFO - 2020-09-16 06:26:43 --> Security Class Initialized
DEBUG - 2020-09-16 06:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 06:26:44 --> Input Class Initialized
INFO - 2020-09-16 06:26:44 --> Language Class Initialized
INFO - 2020-09-16 06:26:44 --> Loader Class Initialized
INFO - 2020-09-16 06:26:44 --> Helper loaded: html_helper
INFO - 2020-09-16 06:26:44 --> Helper loaded: url_helper
INFO - 2020-09-16 06:26:44 --> Helper loaded: form_helper
INFO - 2020-09-16 06:26:44 --> Database Driver Class Initialized
INFO - 2020-09-16 06:26:44 --> Form Validation Class Initialized
DEBUG - 2020-09-16 06:26:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-16 06:26:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-16 06:26:44 --> Encryption Class Initialized
INFO - 2020-09-16 06:26:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-16 06:26:44 --> Controller Class Initialized
INFO - 2020-09-16 06:26:45 --> Helper loaded: language_helper
INFO - 2020-09-16 06:26:45 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-16 06:26:45 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-16 06:26:45 --> Final output sent to browser
DEBUG - 2020-09-16 06:26:45 --> Total execution time: 1.6835
INFO - 2020-09-16 06:30:01 --> Config Class Initialized
INFO - 2020-09-16 06:30:01 --> Hooks Class Initialized
DEBUG - 2020-09-16 06:30:01 --> UTF-8 Support Enabled
INFO - 2020-09-16 06:30:01 --> Utf8 Class Initialized
INFO - 2020-09-16 06:30:01 --> URI Class Initialized
INFO - 2020-09-16 06:30:01 --> Router Class Initialized
INFO - 2020-09-16 06:30:01 --> Output Class Initialized
INFO - 2020-09-16 06:30:01 --> Security Class Initialized
DEBUG - 2020-09-16 06:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 06:30:01 --> Input Class Initialized
INFO - 2020-09-16 06:30:01 --> Language Class Initialized
INFO - 2020-09-16 06:30:01 --> Loader Class Initialized
INFO - 2020-09-16 06:30:01 --> Helper loaded: html_helper
INFO - 2020-09-16 06:30:01 --> Helper loaded: url_helper
INFO - 2020-09-16 06:30:01 --> Helper loaded: form_helper
INFO - 2020-09-16 06:30:01 --> Database Driver Class Initialized
INFO - 2020-09-16 06:30:01 --> Form Validation Class Initialized
DEBUG - 2020-09-16 06:30:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-16 06:30:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-16 06:30:01 --> Encryption Class Initialized
INFO - 2020-09-16 06:30:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-16 06:30:01 --> Controller Class Initialized
INFO - 2020-09-16 06:30:01 --> Helper loaded: language_helper
INFO - 2020-09-16 06:30:01 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-16 06:30:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-16 06:30:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-16 06:30:02 --> Model "User" initialized
INFO - 2020-09-16 06:30:03 --> Config Class Initialized
INFO - 2020-09-16 06:30:03 --> Hooks Class Initialized
DEBUG - 2020-09-16 06:30:03 --> UTF-8 Support Enabled
INFO - 2020-09-16 06:30:03 --> Utf8 Class Initialized
INFO - 2020-09-16 06:30:03 --> URI Class Initialized
INFO - 2020-09-16 06:30:03 --> Router Class Initialized
INFO - 2020-09-16 06:30:03 --> Output Class Initialized
INFO - 2020-09-16 06:30:03 --> Security Class Initialized
DEBUG - 2020-09-16 06:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 06:30:03 --> Input Class Initialized
INFO - 2020-09-16 06:30:03 --> Language Class Initialized
INFO - 2020-09-16 06:30:03 --> Loader Class Initialized
INFO - 2020-09-16 06:30:03 --> Helper loaded: html_helper
INFO - 2020-09-16 06:30:03 --> Helper loaded: url_helper
INFO - 2020-09-16 06:30:03 --> Helper loaded: form_helper
INFO - 2020-09-16 06:30:03 --> Database Driver Class Initialized
INFO - 2020-09-16 06:30:03 --> Form Validation Class Initialized
DEBUG - 2020-09-16 06:30:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-16 06:30:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-16 06:30:03 --> Encryption Class Initialized
INFO - 2020-09-16 06:30:03 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-16 06:30:03 --> Controller Class Initialized
INFO - 2020-09-16 06:30:03 --> Helper loaded: language_helper
INFO - 2020-09-16 06:30:03 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-16 06:30:04 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-16 06:30:04 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-16 06:30:04 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-16 06:30:04 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-16 06:30:04 --> Final output sent to browser
DEBUG - 2020-09-16 06:30:04 --> Total execution time: 1.1080
INFO - 2020-09-16 06:34:13 --> Config Class Initialized
INFO - 2020-09-16 06:34:13 --> Hooks Class Initialized
DEBUG - 2020-09-16 06:34:13 --> UTF-8 Support Enabled
INFO - 2020-09-16 06:34:13 --> Utf8 Class Initialized
INFO - 2020-09-16 06:34:13 --> URI Class Initialized
INFO - 2020-09-16 06:34:13 --> Router Class Initialized
INFO - 2020-09-16 06:34:13 --> Output Class Initialized
INFO - 2020-09-16 06:34:13 --> Security Class Initialized
DEBUG - 2020-09-16 06:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 06:34:13 --> Input Class Initialized
INFO - 2020-09-16 06:34:13 --> Language Class Initialized
INFO - 2020-09-16 06:34:13 --> Loader Class Initialized
INFO - 2020-09-16 06:34:13 --> Helper loaded: html_helper
INFO - 2020-09-16 06:34:13 --> Helper loaded: url_helper
INFO - 2020-09-16 06:34:13 --> Helper loaded: form_helper
INFO - 2020-09-16 06:34:13 --> Database Driver Class Initialized
INFO - 2020-09-16 06:34:13 --> Form Validation Class Initialized
DEBUG - 2020-09-16 06:34:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-16 06:34:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-16 06:34:13 --> Encryption Class Initialized
INFO - 2020-09-16 06:34:14 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-16 06:34:14 --> Controller Class Initialized
INFO - 2020-09-16 06:34:14 --> Helper loaded: language_helper
INFO - 2020-09-16 06:34:14 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-16 06:34:14 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-16 06:34:14 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-16 06:34:14 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment_custom.php
INFO - 2020-09-16 06:34:14 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-16 06:34:14 --> Final output sent to browser
DEBUG - 2020-09-16 06:34:14 --> Total execution time: 1.2978
INFO - 2020-09-16 06:35:30 --> Config Class Initialized
INFO - 2020-09-16 06:35:30 --> Hooks Class Initialized
DEBUG - 2020-09-16 06:35:30 --> UTF-8 Support Enabled
INFO - 2020-09-16 06:35:30 --> Utf8 Class Initialized
INFO - 2020-09-16 06:35:30 --> URI Class Initialized
INFO - 2020-09-16 06:35:30 --> Router Class Initialized
INFO - 2020-09-16 06:35:30 --> Output Class Initialized
INFO - 2020-09-16 06:35:30 --> Security Class Initialized
DEBUG - 2020-09-16 06:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 06:35:30 --> Input Class Initialized
INFO - 2020-09-16 06:35:30 --> Language Class Initialized
INFO - 2020-09-16 06:35:30 --> Loader Class Initialized
INFO - 2020-09-16 06:35:30 --> Helper loaded: html_helper
INFO - 2020-09-16 06:35:30 --> Helper loaded: url_helper
INFO - 2020-09-16 06:35:31 --> Helper loaded: form_helper
INFO - 2020-09-16 06:35:31 --> Database Driver Class Initialized
INFO - 2020-09-16 06:35:31 --> Form Validation Class Initialized
DEBUG - 2020-09-16 06:35:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-16 06:35:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-16 06:35:31 --> Encryption Class Initialized
INFO - 2020-09-16 06:35:31 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-16 06:35:31 --> Controller Class Initialized
INFO - 2020-09-16 06:35:31 --> Helper loaded: language_helper
INFO - 2020-09-16 06:35:31 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-16 06:35:31 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-16 06:35:31 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-16 06:35:31 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-16 06:35:31 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-16 06:35:31 --> Final output sent to browser
DEBUG - 2020-09-16 06:35:31 --> Total execution time: 1.0057
INFO - 2020-09-16 06:35:31 --> Config Class Initialized
INFO - 2020-09-16 06:35:31 --> Hooks Class Initialized
DEBUG - 2020-09-16 06:35:31 --> UTF-8 Support Enabled
INFO - 2020-09-16 06:35:31 --> Utf8 Class Initialized
INFO - 2020-09-16 06:35:31 --> URI Class Initialized
INFO - 2020-09-16 06:35:31 --> Router Class Initialized
INFO - 2020-09-16 06:35:31 --> Output Class Initialized
INFO - 2020-09-16 06:35:31 --> Security Class Initialized
DEBUG - 2020-09-16 06:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 06:35:31 --> Input Class Initialized
INFO - 2020-09-16 06:35:31 --> Language Class Initialized
INFO - 2020-09-16 06:35:31 --> Loader Class Initialized
INFO - 2020-09-16 06:35:32 --> Helper loaded: html_helper
INFO - 2020-09-16 06:35:32 --> Helper loaded: url_helper
INFO - 2020-09-16 06:35:32 --> Helper loaded: form_helper
INFO - 2020-09-16 06:35:32 --> Database Driver Class Initialized
INFO - 2020-09-16 06:35:32 --> Form Validation Class Initialized
DEBUG - 2020-09-16 06:35:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-16 06:35:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-16 06:35:32 --> Encryption Class Initialized
INFO - 2020-09-16 06:35:32 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-16 06:35:32 --> Controller Class Initialized
INFO - 2020-09-16 06:35:32 --> Helper loaded: language_helper
INFO - 2020-09-16 06:35:32 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-16 06:35:32 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-16 06:35:32 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-16 06:35:32 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-16 06:35:32 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-16 06:35:32 --> Final output sent to browser
DEBUG - 2020-09-16 06:35:32 --> Total execution time: 0.9578
INFO - 2020-09-16 06:38:25 --> Config Class Initialized
INFO - 2020-09-16 06:38:25 --> Hooks Class Initialized
DEBUG - 2020-09-16 06:38:25 --> UTF-8 Support Enabled
INFO - 2020-09-16 06:38:25 --> Utf8 Class Initialized
INFO - 2020-09-16 06:38:25 --> URI Class Initialized
INFO - 2020-09-16 06:38:25 --> Router Class Initialized
INFO - 2020-09-16 06:38:25 --> Output Class Initialized
INFO - 2020-09-16 06:38:25 --> Security Class Initialized
DEBUG - 2020-09-16 06:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 06:38:25 --> Input Class Initialized
INFO - 2020-09-16 06:38:25 --> Language Class Initialized
INFO - 2020-09-16 06:38:25 --> Loader Class Initialized
INFO - 2020-09-16 06:38:25 --> Helper loaded: html_helper
INFO - 2020-09-16 06:38:25 --> Helper loaded: url_helper
INFO - 2020-09-16 06:38:25 --> Helper loaded: form_helper
INFO - 2020-09-16 06:38:25 --> Database Driver Class Initialized
INFO - 2020-09-16 06:38:25 --> Form Validation Class Initialized
DEBUG - 2020-09-16 06:38:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-16 06:38:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-16 06:38:25 --> Encryption Class Initialized
INFO - 2020-09-16 06:38:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-16 06:38:26 --> Controller Class Initialized
INFO - 2020-09-16 06:38:26 --> Helper loaded: language_helper
INFO - 2020-09-16 06:38:26 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-16 06:38:26 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-16 06:38:26 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-16 06:38:26 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-16 06:38:26 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-16 06:38:26 --> Final output sent to browser
DEBUG - 2020-09-16 06:38:26 --> Total execution time: 0.9215
INFO - 2020-09-16 06:38:35 --> Config Class Initialized
INFO - 2020-09-16 06:38:35 --> Hooks Class Initialized
DEBUG - 2020-09-16 06:38:35 --> UTF-8 Support Enabled
INFO - 2020-09-16 06:38:35 --> Utf8 Class Initialized
INFO - 2020-09-16 06:38:35 --> URI Class Initialized
INFO - 2020-09-16 06:38:35 --> Router Class Initialized
INFO - 2020-09-16 06:38:35 --> Output Class Initialized
INFO - 2020-09-16 06:38:35 --> Security Class Initialized
DEBUG - 2020-09-16 06:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 06:38:35 --> Input Class Initialized
INFO - 2020-09-16 06:38:35 --> Language Class Initialized
INFO - 2020-09-16 06:38:35 --> Loader Class Initialized
INFO - 2020-09-16 06:38:35 --> Helper loaded: html_helper
INFO - 2020-09-16 06:38:35 --> Helper loaded: url_helper
INFO - 2020-09-16 06:38:35 --> Helper loaded: form_helper
INFO - 2020-09-16 06:38:35 --> Database Driver Class Initialized
INFO - 2020-09-16 06:38:35 --> Form Validation Class Initialized
DEBUG - 2020-09-16 06:38:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-16 06:38:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-16 06:38:35 --> Encryption Class Initialized
INFO - 2020-09-16 06:38:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-16 06:38:35 --> Controller Class Initialized
INFO - 2020-09-16 06:38:36 --> Helper loaded: language_helper
INFO - 2020-09-16 06:38:36 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-16 06:38:36 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-16 06:38:36 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-16 06:38:36 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-16 06:38:36 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-16 06:38:36 --> Final output sent to browser
DEBUG - 2020-09-16 06:38:36 --> Total execution time: 1.0017
INFO - 2020-09-16 06:38:40 --> Config Class Initialized
INFO - 2020-09-16 06:38:40 --> Hooks Class Initialized
DEBUG - 2020-09-16 06:38:40 --> UTF-8 Support Enabled
INFO - 2020-09-16 06:38:40 --> Utf8 Class Initialized
INFO - 2020-09-16 06:38:40 --> URI Class Initialized
INFO - 2020-09-16 06:38:40 --> Router Class Initialized
INFO - 2020-09-16 06:38:40 --> Output Class Initialized
INFO - 2020-09-16 06:38:40 --> Security Class Initialized
DEBUG - 2020-09-16 06:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 06:38:40 --> Input Class Initialized
INFO - 2020-09-16 06:38:40 --> Language Class Initialized
INFO - 2020-09-16 06:38:40 --> Loader Class Initialized
INFO - 2020-09-16 06:38:40 --> Helper loaded: html_helper
INFO - 2020-09-16 06:38:40 --> Helper loaded: url_helper
INFO - 2020-09-16 06:38:40 --> Helper loaded: form_helper
INFO - 2020-09-16 06:38:40 --> Database Driver Class Initialized
INFO - 2020-09-16 06:38:40 --> Form Validation Class Initialized
DEBUG - 2020-09-16 06:38:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-16 06:38:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-16 06:38:41 --> Encryption Class Initialized
INFO - 2020-09-16 06:38:41 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-16 06:38:41 --> Controller Class Initialized
INFO - 2020-09-16 06:38:41 --> Helper loaded: language_helper
INFO - 2020-09-16 06:38:41 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-16 06:38:41 --> Model "Sale_model" initialized
INFO - 2020-09-16 06:38:41 --> Final output sent to browser
DEBUG - 2020-09-16 06:38:41 --> Total execution time: 1.1800
INFO - 2020-09-16 06:38:50 --> Config Class Initialized
INFO - 2020-09-16 06:38:50 --> Hooks Class Initialized
DEBUG - 2020-09-16 06:38:50 --> UTF-8 Support Enabled
INFO - 2020-09-16 06:38:50 --> Utf8 Class Initialized
INFO - 2020-09-16 06:38:50 --> URI Class Initialized
INFO - 2020-09-16 06:38:50 --> Router Class Initialized
INFO - 2020-09-16 06:38:50 --> Output Class Initialized
INFO - 2020-09-16 06:38:50 --> Security Class Initialized
DEBUG - 2020-09-16 06:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 06:38:50 --> Input Class Initialized
INFO - 2020-09-16 06:38:50 --> Language Class Initialized
INFO - 2020-09-16 06:38:51 --> Loader Class Initialized
INFO - 2020-09-16 06:38:51 --> Helper loaded: html_helper
INFO - 2020-09-16 06:38:51 --> Helper loaded: url_helper
INFO - 2020-09-16 06:38:51 --> Helper loaded: form_helper
INFO - 2020-09-16 06:38:51 --> Database Driver Class Initialized
INFO - 2020-09-16 06:38:51 --> Form Validation Class Initialized
DEBUG - 2020-09-16 06:38:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-16 06:38:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-16 06:38:51 --> Encryption Class Initialized
INFO - 2020-09-16 06:38:51 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-16 06:38:51 --> Controller Class Initialized
INFO - 2020-09-16 06:38:51 --> Helper loaded: language_helper
INFO - 2020-09-16 06:38:51 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-16 06:38:51 --> Model "Sale_model" initialized
INFO - 2020-09-16 06:38:51 --> Final output sent to browser
DEBUG - 2020-09-16 06:38:51 --> Total execution time: 0.8832
INFO - 2020-09-16 06:48:24 --> Config Class Initialized
INFO - 2020-09-16 06:48:24 --> Hooks Class Initialized
DEBUG - 2020-09-16 06:48:24 --> UTF-8 Support Enabled
INFO - 2020-09-16 06:48:24 --> Utf8 Class Initialized
INFO - 2020-09-16 06:48:24 --> URI Class Initialized
INFO - 2020-09-16 06:48:25 --> Router Class Initialized
INFO - 2020-09-16 06:48:25 --> Output Class Initialized
INFO - 2020-09-16 06:48:25 --> Security Class Initialized
DEBUG - 2020-09-16 06:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 06:48:25 --> Input Class Initialized
INFO - 2020-09-16 06:48:25 --> Language Class Initialized
INFO - 2020-09-16 06:48:25 --> Loader Class Initialized
INFO - 2020-09-16 06:48:25 --> Helper loaded: html_helper
INFO - 2020-09-16 06:48:25 --> Helper loaded: url_helper
INFO - 2020-09-16 06:48:25 --> Helper loaded: form_helper
INFO - 2020-09-16 06:48:25 --> Database Driver Class Initialized
INFO - 2020-09-16 06:48:25 --> Form Validation Class Initialized
DEBUG - 2020-09-16 06:48:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-16 06:48:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-16 06:48:25 --> Encryption Class Initialized
INFO - 2020-09-16 06:48:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-16 06:48:25 --> Controller Class Initialized
INFO - 2020-09-16 06:48:25 --> Helper loaded: language_helper
INFO - 2020-09-16 06:48:25 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-16 06:48:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-16 06:48:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-16 06:48:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-16 06:48:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-16 06:48:25 --> Final output sent to browser
DEBUG - 2020-09-16 06:48:25 --> Total execution time: 0.9993
INFO - 2020-09-16 06:52:59 --> Config Class Initialized
INFO - 2020-09-16 06:52:59 --> Hooks Class Initialized
DEBUG - 2020-09-16 06:52:59 --> UTF-8 Support Enabled
INFO - 2020-09-16 06:52:59 --> Utf8 Class Initialized
INFO - 2020-09-16 06:52:59 --> URI Class Initialized
INFO - 2020-09-16 06:52:59 --> Router Class Initialized
INFO - 2020-09-16 06:52:59 --> Output Class Initialized
INFO - 2020-09-16 06:52:59 --> Security Class Initialized
DEBUG - 2020-09-16 06:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 06:52:59 --> Input Class Initialized
INFO - 2020-09-16 06:52:59 --> Language Class Initialized
INFO - 2020-09-16 06:52:59 --> Loader Class Initialized
INFO - 2020-09-16 06:52:59 --> Helper loaded: html_helper
INFO - 2020-09-16 06:52:59 --> Helper loaded: url_helper
INFO - 2020-09-16 06:52:59 --> Helper loaded: form_helper
INFO - 2020-09-16 06:52:59 --> Database Driver Class Initialized
INFO - 2020-09-16 06:52:59 --> Form Validation Class Initialized
DEBUG - 2020-09-16 06:52:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-16 06:52:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-16 06:52:59 --> Encryption Class Initialized
INFO - 2020-09-16 06:52:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-16 06:52:59 --> Controller Class Initialized
INFO - 2020-09-16 06:52:59 --> Helper loaded: language_helper
INFO - 2020-09-16 06:52:59 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-16 06:52:59 --> Model "Sale_model" initialized
INFO - 2020-09-16 06:53:00 --> Final output sent to browser
DEBUG - 2020-09-16 06:53:00 --> Total execution time: 0.9225
INFO - 2020-09-16 06:53:14 --> Config Class Initialized
INFO - 2020-09-16 06:53:14 --> Hooks Class Initialized
DEBUG - 2020-09-16 06:53:14 --> UTF-8 Support Enabled
INFO - 2020-09-16 06:53:14 --> Utf8 Class Initialized
INFO - 2020-09-16 06:53:14 --> URI Class Initialized
INFO - 2020-09-16 06:53:14 --> Router Class Initialized
INFO - 2020-09-16 06:53:14 --> Output Class Initialized
INFO - 2020-09-16 06:53:14 --> Security Class Initialized
DEBUG - 2020-09-16 06:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 06:53:14 --> Input Class Initialized
INFO - 2020-09-16 06:53:14 --> Language Class Initialized
INFO - 2020-09-16 06:53:14 --> Loader Class Initialized
INFO - 2020-09-16 06:53:14 --> Helper loaded: html_helper
INFO - 2020-09-16 06:53:14 --> Helper loaded: url_helper
INFO - 2020-09-16 06:53:14 --> Helper loaded: form_helper
INFO - 2020-09-16 06:53:14 --> Database Driver Class Initialized
INFO - 2020-09-16 06:53:14 --> Form Validation Class Initialized
DEBUG - 2020-09-16 06:53:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-16 06:53:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-16 06:53:14 --> Encryption Class Initialized
INFO - 2020-09-16 06:53:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-16 06:53:15 --> Controller Class Initialized
INFO - 2020-09-16 06:53:15 --> Helper loaded: language_helper
INFO - 2020-09-16 06:53:15 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-16 06:53:15 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-16 06:53:15 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-16 06:53:15 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment.php
INFO - 2020-09-16 06:53:15 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-16 06:53:15 --> Final output sent to browser
DEBUG - 2020-09-16 06:53:15 --> Total execution time: 1.0213
INFO - 2020-09-16 06:53:15 --> Config Class Initialized
INFO - 2020-09-16 06:53:15 --> Hooks Class Initialized
DEBUG - 2020-09-16 06:53:16 --> UTF-8 Support Enabled
INFO - 2020-09-16 06:53:16 --> Utf8 Class Initialized
INFO - 2020-09-16 06:53:16 --> URI Class Initialized
INFO - 2020-09-16 06:53:16 --> Router Class Initialized
INFO - 2020-09-16 06:53:16 --> Output Class Initialized
INFO - 2020-09-16 06:53:16 --> Security Class Initialized
DEBUG - 2020-09-16 06:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 06:53:16 --> Input Class Initialized
INFO - 2020-09-16 06:53:16 --> Language Class Initialized
INFO - 2020-09-16 06:53:16 --> Loader Class Initialized
INFO - 2020-09-16 06:53:16 --> Helper loaded: html_helper
INFO - 2020-09-16 06:53:16 --> Helper loaded: url_helper
INFO - 2020-09-16 06:53:16 --> Helper loaded: form_helper
INFO - 2020-09-16 06:53:16 --> Database Driver Class Initialized
INFO - 2020-09-16 06:53:16 --> Form Validation Class Initialized
DEBUG - 2020-09-16 06:53:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-16 06:53:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-16 06:53:16 --> Encryption Class Initialized
INFO - 2020-09-16 06:53:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-16 06:53:16 --> Controller Class Initialized
INFO - 2020-09-16 06:53:16 --> Helper loaded: language_helper
INFO - 2020-09-16 06:53:16 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-16 06:53:18 --> Final output sent to browser
DEBUG - 2020-09-16 06:53:18 --> Total execution time: 2.9306
INFO - 2020-09-16 06:53:26 --> Config Class Initialized
INFO - 2020-09-16 06:53:26 --> Hooks Class Initialized
DEBUG - 2020-09-16 06:53:26 --> UTF-8 Support Enabled
INFO - 2020-09-16 06:53:26 --> Utf8 Class Initialized
INFO - 2020-09-16 06:53:26 --> URI Class Initialized
INFO - 2020-09-16 06:53:26 --> Router Class Initialized
INFO - 2020-09-16 06:53:26 --> Output Class Initialized
INFO - 2020-09-16 06:53:26 --> Security Class Initialized
DEBUG - 2020-09-16 06:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 06:53:26 --> Input Class Initialized
INFO - 2020-09-16 06:53:26 --> Language Class Initialized
INFO - 2020-09-16 06:53:26 --> Loader Class Initialized
INFO - 2020-09-16 06:53:26 --> Helper loaded: html_helper
INFO - 2020-09-16 06:53:27 --> Helper loaded: url_helper
INFO - 2020-09-16 06:53:27 --> Helper loaded: form_helper
INFO - 2020-09-16 06:53:27 --> Database Driver Class Initialized
INFO - 2020-09-16 06:53:27 --> Form Validation Class Initialized
DEBUG - 2020-09-16 06:53:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-16 06:53:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-16 06:53:27 --> Encryption Class Initialized
INFO - 2020-09-16 06:53:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-16 06:53:27 --> Controller Class Initialized
INFO - 2020-09-16 06:53:27 --> Helper loaded: language_helper
INFO - 2020-09-16 06:53:27 --> Language file loaded: language/english/content_lang.php
ERROR - 2020-09-16 06:53:27 --> Severity: Notice --> Undefined index: order_id C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\controllers\Payment.php 184
INFO - 2020-09-16 06:53:29 --> Final output sent to browser
DEBUG - 2020-09-16 06:53:29 --> Total execution time: 2.9822
INFO - 2020-09-16 06:54:02 --> Config Class Initialized
INFO - 2020-09-16 06:54:02 --> Hooks Class Initialized
DEBUG - 2020-09-16 06:54:02 --> UTF-8 Support Enabled
INFO - 2020-09-16 06:54:02 --> Utf8 Class Initialized
INFO - 2020-09-16 06:54:02 --> URI Class Initialized
INFO - 2020-09-16 06:54:02 --> Router Class Initialized
INFO - 2020-09-16 06:54:02 --> Output Class Initialized
INFO - 2020-09-16 06:54:02 --> Security Class Initialized
DEBUG - 2020-09-16 06:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 06:54:02 --> Input Class Initialized
INFO - 2020-09-16 06:54:02 --> Language Class Initialized
INFO - 2020-09-16 06:54:02 --> Loader Class Initialized
INFO - 2020-09-16 06:54:02 --> Helper loaded: html_helper
INFO - 2020-09-16 06:54:02 --> Helper loaded: url_helper
INFO - 2020-09-16 06:54:02 --> Helper loaded: form_helper
INFO - 2020-09-16 06:54:03 --> Database Driver Class Initialized
INFO - 2020-09-16 06:54:03 --> Form Validation Class Initialized
DEBUG - 2020-09-16 06:54:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-16 06:54:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-16 06:54:03 --> Encryption Class Initialized
INFO - 2020-09-16 06:54:03 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-16 06:54:03 --> Controller Class Initialized
INFO - 2020-09-16 06:54:03 --> Helper loaded: language_helper
INFO - 2020-09-16 06:54:03 --> Language file loaded: language/english/content_lang.php
ERROR - 2020-09-16 06:54:03 --> Severity: Notice --> Undefined index: order_id C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\controllers\Payment.php 184
INFO - 2020-09-16 06:54:06 --> Final output sent to browser
DEBUG - 2020-09-16 06:54:06 --> Total execution time: 4.1237
INFO - 2020-09-16 06:54:31 --> Config Class Initialized
INFO - 2020-09-16 06:54:31 --> Hooks Class Initialized
DEBUG - 2020-09-16 06:54:31 --> UTF-8 Support Enabled
INFO - 2020-09-16 06:54:31 --> Utf8 Class Initialized
INFO - 2020-09-16 06:54:31 --> URI Class Initialized
INFO - 2020-09-16 06:54:31 --> Router Class Initialized
INFO - 2020-09-16 06:54:31 --> Output Class Initialized
INFO - 2020-09-16 06:54:31 --> Security Class Initialized
DEBUG - 2020-09-16 06:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 06:54:31 --> Input Class Initialized
INFO - 2020-09-16 06:54:31 --> Language Class Initialized
INFO - 2020-09-16 06:54:32 --> Loader Class Initialized
INFO - 2020-09-16 06:54:32 --> Helper loaded: html_helper
INFO - 2020-09-16 06:54:32 --> Helper loaded: url_helper
INFO - 2020-09-16 06:54:32 --> Helper loaded: form_helper
INFO - 2020-09-16 06:54:32 --> Database Driver Class Initialized
INFO - 2020-09-16 06:54:32 --> Form Validation Class Initialized
DEBUG - 2020-09-16 06:54:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-16 06:54:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-16 06:54:32 --> Encryption Class Initialized
INFO - 2020-09-16 06:54:32 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-16 06:54:32 --> Controller Class Initialized
INFO - 2020-09-16 06:54:32 --> Helper loaded: language_helper
INFO - 2020-09-16 06:54:33 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-16 06:54:33 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-16 06:54:33 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-16 06:54:33 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-16 06:54:33 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-16 06:54:33 --> Final output sent to browser
DEBUG - 2020-09-16 06:54:33 --> Total execution time: 1.6970
INFO - 2020-09-16 06:54:35 --> Config Class Initialized
INFO - 2020-09-16 06:54:35 --> Hooks Class Initialized
DEBUG - 2020-09-16 06:54:35 --> UTF-8 Support Enabled
INFO - 2020-09-16 06:54:35 --> Utf8 Class Initialized
INFO - 2020-09-16 06:54:35 --> URI Class Initialized
INFO - 2020-09-16 06:54:36 --> Router Class Initialized
INFO - 2020-09-16 06:54:36 --> Output Class Initialized
INFO - 2020-09-16 06:54:36 --> Security Class Initialized
DEBUG - 2020-09-16 06:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 06:54:36 --> Input Class Initialized
INFO - 2020-09-16 06:54:36 --> Language Class Initialized
INFO - 2020-09-16 06:54:36 --> Loader Class Initialized
INFO - 2020-09-16 06:54:36 --> Helper loaded: html_helper
INFO - 2020-09-16 06:54:36 --> Helper loaded: url_helper
INFO - 2020-09-16 06:54:36 --> Helper loaded: form_helper
INFO - 2020-09-16 06:54:36 --> Database Driver Class Initialized
INFO - 2020-09-16 06:54:36 --> Form Validation Class Initialized
DEBUG - 2020-09-16 06:54:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-16 06:54:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-16 06:54:36 --> Encryption Class Initialized
INFO - 2020-09-16 06:54:37 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-16 06:54:37 --> Controller Class Initialized
INFO - 2020-09-16 06:54:37 --> Helper loaded: language_helper
INFO - 2020-09-16 06:54:37 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-16 06:54:37 --> Model "Sale_model" initialized
INFO - 2020-09-16 06:54:37 --> Final output sent to browser
DEBUG - 2020-09-16 06:54:37 --> Total execution time: 1.6027
INFO - 2020-09-16 06:54:43 --> Config Class Initialized
INFO - 2020-09-16 06:54:43 --> Hooks Class Initialized
DEBUG - 2020-09-16 06:54:43 --> UTF-8 Support Enabled
INFO - 2020-09-16 06:54:43 --> Utf8 Class Initialized
INFO - 2020-09-16 06:54:43 --> URI Class Initialized
INFO - 2020-09-16 06:54:43 --> Router Class Initialized
INFO - 2020-09-16 06:54:43 --> Output Class Initialized
INFO - 2020-09-16 06:54:43 --> Security Class Initialized
DEBUG - 2020-09-16 06:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 06:54:43 --> Input Class Initialized
INFO - 2020-09-16 06:54:43 --> Language Class Initialized
INFO - 2020-09-16 06:54:43 --> Loader Class Initialized
INFO - 2020-09-16 06:54:43 --> Helper loaded: html_helper
INFO - 2020-09-16 06:54:43 --> Helper loaded: url_helper
INFO - 2020-09-16 06:54:43 --> Helper loaded: form_helper
INFO - 2020-09-16 06:54:43 --> Database Driver Class Initialized
INFO - 2020-09-16 06:54:43 --> Form Validation Class Initialized
DEBUG - 2020-09-16 06:54:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-16 06:54:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-16 06:54:44 --> Encryption Class Initialized
INFO - 2020-09-16 06:54:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-16 06:54:44 --> Controller Class Initialized
INFO - 2020-09-16 06:54:44 --> Helper loaded: language_helper
INFO - 2020-09-16 06:54:44 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-16 06:54:44 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-16 06:54:44 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-16 06:54:44 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment.php
INFO - 2020-09-16 06:54:44 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-16 06:54:44 --> Final output sent to browser
DEBUG - 2020-09-16 06:54:44 --> Total execution time: 1.1889
INFO - 2020-09-16 06:54:45 --> Config Class Initialized
INFO - 2020-09-16 06:54:45 --> Hooks Class Initialized
DEBUG - 2020-09-16 06:54:45 --> UTF-8 Support Enabled
INFO - 2020-09-16 06:54:45 --> Utf8 Class Initialized
INFO - 2020-09-16 06:54:45 --> URI Class Initialized
INFO - 2020-09-16 06:54:45 --> Router Class Initialized
INFO - 2020-09-16 06:54:45 --> Output Class Initialized
INFO - 2020-09-16 06:54:45 --> Security Class Initialized
DEBUG - 2020-09-16 06:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 06:54:45 --> Input Class Initialized
INFO - 2020-09-16 06:54:45 --> Language Class Initialized
INFO - 2020-09-16 06:54:45 --> Loader Class Initialized
INFO - 2020-09-16 06:54:45 --> Helper loaded: html_helper
INFO - 2020-09-16 06:54:45 --> Helper loaded: url_helper
INFO - 2020-09-16 06:54:45 --> Helper loaded: form_helper
INFO - 2020-09-16 06:54:46 --> Database Driver Class Initialized
INFO - 2020-09-16 06:54:46 --> Form Validation Class Initialized
DEBUG - 2020-09-16 06:54:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-16 06:54:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-16 06:54:46 --> Encryption Class Initialized
INFO - 2020-09-16 06:54:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-16 06:54:46 --> Controller Class Initialized
INFO - 2020-09-16 06:54:46 --> Helper loaded: language_helper
INFO - 2020-09-16 06:54:46 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-16 06:54:47 --> Final output sent to browser
DEBUG - 2020-09-16 06:54:47 --> Total execution time: 2.5423
INFO - 2020-09-16 11:58:55 --> Config Class Initialized
INFO - 2020-09-16 11:58:55 --> Hooks Class Initialized
DEBUG - 2020-09-16 11:58:55 --> UTF-8 Support Enabled
INFO - 2020-09-16 11:58:55 --> Utf8 Class Initialized
INFO - 2020-09-16 11:58:55 --> URI Class Initialized
DEBUG - 2020-09-16 11:58:56 --> No URI present. Default controller set.
INFO - 2020-09-16 11:58:56 --> Router Class Initialized
INFO - 2020-09-16 11:58:56 --> Output Class Initialized
INFO - 2020-09-16 11:58:56 --> Security Class Initialized
DEBUG - 2020-09-16 11:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 11:58:56 --> Input Class Initialized
INFO - 2020-09-16 11:58:56 --> Language Class Initialized
INFO - 2020-09-16 11:58:56 --> Loader Class Initialized
INFO - 2020-09-16 11:58:56 --> Helper loaded: html_helper
INFO - 2020-09-16 11:58:57 --> Helper loaded: url_helper
INFO - 2020-09-16 11:58:57 --> Helper loaded: form_helper
INFO - 2020-09-16 11:58:57 --> Database Driver Class Initialized
INFO - 2020-09-16 11:58:57 --> Form Validation Class Initialized
DEBUG - 2020-09-16 11:58:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-16 11:58:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-16 11:58:58 --> Encryption Class Initialized
ERROR - 2020-09-16 11:58:58 --> Query error: [Microsoft][ODBC Driver 17 for SQL Server][SQL Server]Invalid object name 'ci_sessions'. - Invalid query: SELECT "data"
FROM "ci_sessions"
WHERE "id" = 'fkork064cbtak8i53hfumjcrrfqtuuf0'
AND "ip_address" = '112.133.248.100'
INFO - 2020-09-16 11:58:58 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-16 11:58:58 --> Severity: Warning --> session_write_close(): Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-09-16 11:58:58 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: C:\Windows\Temp) Unknown 0
