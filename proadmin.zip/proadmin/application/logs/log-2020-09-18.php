<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-18 04:35:55 --> Config Class Initialized
INFO - 2020-09-18 04:35:55 --> Hooks Class Initialized
DEBUG - 2020-09-18 04:35:56 --> UTF-8 Support Enabled
INFO - 2020-09-18 04:35:56 --> Utf8 Class Initialized
INFO - 2020-09-18 04:35:56 --> URI Class Initialized
INFO - 2020-09-18 04:35:56 --> Router Class Initialized
INFO - 2020-09-18 04:35:56 --> Output Class Initialized
INFO - 2020-09-18 04:35:57 --> Security Class Initialized
DEBUG - 2020-09-18 04:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 04:35:57 --> Input Class Initialized
INFO - 2020-09-18 04:35:57 --> Language Class Initialized
INFO - 2020-09-18 04:35:57 --> Loader Class Initialized
INFO - 2020-09-18 04:35:57 --> Helper loaded: html_helper
INFO - 2020-09-18 04:35:57 --> Helper loaded: url_helper
INFO - 2020-09-18 04:35:57 --> Helper loaded: form_helper
INFO - 2020-09-18 04:35:58 --> Database Driver Class Initialized
INFO - 2020-09-18 04:35:58 --> Form Validation Class Initialized
DEBUG - 2020-09-18 04:35:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 04:35:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 04:35:58 --> Encryption Class Initialized
INFO - 2020-09-18 04:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 04:35:59 --> Controller Class Initialized
INFO - 2020-09-18 04:35:59 --> Helper loaded: language_helper
INFO - 2020-09-18 04:35:59 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 04:35:59 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 04:35:59 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 04:35:59 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment.php
INFO - 2020-09-18 04:35:59 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 04:35:59 --> Final output sent to browser
DEBUG - 2020-09-18 04:35:59 --> Total execution time: 3.9453
INFO - 2020-09-18 04:39:34 --> Config Class Initialized
INFO - 2020-09-18 04:39:34 --> Hooks Class Initialized
DEBUG - 2020-09-18 04:39:34 --> UTF-8 Support Enabled
INFO - 2020-09-18 04:39:34 --> Utf8 Class Initialized
INFO - 2020-09-18 04:39:34 --> URI Class Initialized
INFO - 2020-09-18 04:39:34 --> Router Class Initialized
INFO - 2020-09-18 04:39:34 --> Output Class Initialized
INFO - 2020-09-18 04:39:34 --> Security Class Initialized
DEBUG - 2020-09-18 04:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 04:39:34 --> Input Class Initialized
INFO - 2020-09-18 04:39:34 --> Language Class Initialized
INFO - 2020-09-18 04:39:35 --> Loader Class Initialized
INFO - 2020-09-18 04:39:35 --> Helper loaded: html_helper
INFO - 2020-09-18 04:39:35 --> Helper loaded: url_helper
INFO - 2020-09-18 04:39:35 --> Helper loaded: form_helper
INFO - 2020-09-18 04:39:35 --> Database Driver Class Initialized
INFO - 2020-09-18 04:39:35 --> Form Validation Class Initialized
DEBUG - 2020-09-18 04:39:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 04:39:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 04:39:35 --> Encryption Class Initialized
INFO - 2020-09-18 04:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 04:39:35 --> Controller Class Initialized
INFO - 2020-09-18 04:39:35 --> Helper loaded: language_helper
INFO - 2020-09-18 04:39:35 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 04:39:38 --> Final output sent to browser
DEBUG - 2020-09-18 04:39:38 --> Total execution time: 3.7747
INFO - 2020-09-18 04:39:57 --> Config Class Initialized
INFO - 2020-09-18 04:39:57 --> Hooks Class Initialized
DEBUG - 2020-09-18 04:39:57 --> UTF-8 Support Enabled
INFO - 2020-09-18 04:39:57 --> Utf8 Class Initialized
INFO - 2020-09-18 04:39:58 --> URI Class Initialized
INFO - 2020-09-18 04:39:58 --> Router Class Initialized
INFO - 2020-09-18 04:39:58 --> Output Class Initialized
INFO - 2020-09-18 04:39:58 --> Security Class Initialized
DEBUG - 2020-09-18 04:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 04:39:58 --> Input Class Initialized
INFO - 2020-09-18 04:39:58 --> Language Class Initialized
INFO - 2020-09-18 04:39:58 --> Loader Class Initialized
INFO - 2020-09-18 04:39:58 --> Helper loaded: html_helper
INFO - 2020-09-18 04:39:58 --> Helper loaded: url_helper
INFO - 2020-09-18 04:39:58 --> Helper loaded: form_helper
INFO - 2020-09-18 04:39:58 --> Database Driver Class Initialized
INFO - 2020-09-18 04:39:58 --> Form Validation Class Initialized
DEBUG - 2020-09-18 04:39:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 04:39:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 04:39:58 --> Encryption Class Initialized
INFO - 2020-09-18 04:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 04:39:58 --> Controller Class Initialized
INFO - 2020-09-18 04:39:58 --> Helper loaded: language_helper
INFO - 2020-09-18 04:39:58 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 04:39:58 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 04:39:58 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 04:39:58 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment_custom.php
INFO - 2020-09-18 04:39:58 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 04:39:58 --> Final output sent to browser
DEBUG - 2020-09-18 04:39:58 --> Total execution time: 1.0855
INFO - 2020-09-18 05:09:41 --> Config Class Initialized
INFO - 2020-09-18 05:09:41 --> Hooks Class Initialized
DEBUG - 2020-09-18 05:09:41 --> UTF-8 Support Enabled
INFO - 2020-09-18 05:09:41 --> Utf8 Class Initialized
INFO - 2020-09-18 05:09:41 --> URI Class Initialized
DEBUG - 2020-09-18 05:09:41 --> No URI present. Default controller set.
INFO - 2020-09-18 05:09:41 --> Router Class Initialized
INFO - 2020-09-18 05:09:41 --> Output Class Initialized
INFO - 2020-09-18 05:09:41 --> Security Class Initialized
DEBUG - 2020-09-18 05:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 05:09:41 --> Input Class Initialized
INFO - 2020-09-18 05:09:41 --> Language Class Initialized
INFO - 2020-09-18 05:09:42 --> Loader Class Initialized
INFO - 2020-09-18 05:09:42 --> Helper loaded: html_helper
INFO - 2020-09-18 05:09:42 --> Helper loaded: url_helper
INFO - 2020-09-18 05:09:42 --> Helper loaded: form_helper
INFO - 2020-09-18 05:09:42 --> Database Driver Class Initialized
INFO - 2020-09-18 05:09:42 --> Form Validation Class Initialized
DEBUG - 2020-09-18 05:09:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 05:09:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 05:09:42 --> Encryption Class Initialized
INFO - 2020-09-18 05:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 05:09:42 --> Controller Class Initialized
INFO - 2020-09-18 05:09:42 --> Helper loaded: language_helper
INFO - 2020-09-18 05:09:42 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 05:09:43 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-18 05:09:43 --> Final output sent to browser
DEBUG - 2020-09-18 05:09:43 --> Total execution time: 1.8905
INFO - 2020-09-18 05:09:50 --> Config Class Initialized
INFO - 2020-09-18 05:09:50 --> Hooks Class Initialized
DEBUG - 2020-09-18 05:09:50 --> UTF-8 Support Enabled
INFO - 2020-09-18 05:09:50 --> Utf8 Class Initialized
INFO - 2020-09-18 05:09:50 --> URI Class Initialized
INFO - 2020-09-18 05:09:50 --> Router Class Initialized
INFO - 2020-09-18 05:09:50 --> Output Class Initialized
INFO - 2020-09-18 05:09:50 --> Security Class Initialized
DEBUG - 2020-09-18 05:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 05:09:51 --> Input Class Initialized
INFO - 2020-09-18 05:09:51 --> Language Class Initialized
INFO - 2020-09-18 05:09:51 --> Loader Class Initialized
INFO - 2020-09-18 05:09:51 --> Helper loaded: html_helper
INFO - 2020-09-18 05:09:51 --> Helper loaded: url_helper
INFO - 2020-09-18 05:09:51 --> Helper loaded: form_helper
INFO - 2020-09-18 05:09:51 --> Database Driver Class Initialized
INFO - 2020-09-18 05:09:51 --> Form Validation Class Initialized
DEBUG - 2020-09-18 05:09:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 05:09:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 05:09:51 --> Encryption Class Initialized
INFO - 2020-09-18 05:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 05:09:51 --> Controller Class Initialized
INFO - 2020-09-18 05:09:51 --> Helper loaded: language_helper
INFO - 2020-09-18 05:09:51 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-18 05:09:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-18 05:09:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-18 05:09:52 --> Model "User" initialized
INFO - 2020-09-18 05:09:52 --> Config Class Initialized
INFO - 2020-09-18 05:09:52 --> Hooks Class Initialized
DEBUG - 2020-09-18 05:09:52 --> UTF-8 Support Enabled
INFO - 2020-09-18 05:09:52 --> Utf8 Class Initialized
INFO - 2020-09-18 05:09:53 --> URI Class Initialized
INFO - 2020-09-18 05:09:53 --> Router Class Initialized
INFO - 2020-09-18 05:09:53 --> Output Class Initialized
INFO - 2020-09-18 05:09:53 --> Security Class Initialized
DEBUG - 2020-09-18 05:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 05:09:53 --> Input Class Initialized
INFO - 2020-09-18 05:09:53 --> Language Class Initialized
INFO - 2020-09-18 05:09:53 --> Loader Class Initialized
INFO - 2020-09-18 05:09:53 --> Helper loaded: html_helper
INFO - 2020-09-18 05:09:53 --> Helper loaded: url_helper
INFO - 2020-09-18 05:09:53 --> Helper loaded: form_helper
INFO - 2020-09-18 05:09:53 --> Database Driver Class Initialized
INFO - 2020-09-18 05:09:53 --> Form Validation Class Initialized
DEBUG - 2020-09-18 05:09:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 05:09:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 05:09:53 --> Encryption Class Initialized
INFO - 2020-09-18 05:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 05:09:53 --> Controller Class Initialized
INFO - 2020-09-18 05:09:53 --> Helper loaded: language_helper
INFO - 2020-09-18 05:09:53 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 05:09:53 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-18 05:09:53 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 05:09:54 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-18 05:09:54 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 05:09:54 --> Final output sent to browser
DEBUG - 2020-09-18 05:09:54 --> Total execution time: 1.3746
INFO - 2020-09-18 05:09:58 --> Config Class Initialized
INFO - 2020-09-18 05:09:58 --> Hooks Class Initialized
DEBUG - 2020-09-18 05:09:58 --> UTF-8 Support Enabled
INFO - 2020-09-18 05:09:58 --> Utf8 Class Initialized
INFO - 2020-09-18 05:09:58 --> URI Class Initialized
INFO - 2020-09-18 05:09:58 --> Router Class Initialized
INFO - 2020-09-18 05:09:58 --> Output Class Initialized
INFO - 2020-09-18 05:09:58 --> Security Class Initialized
DEBUG - 2020-09-18 05:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 05:09:58 --> Input Class Initialized
INFO - 2020-09-18 05:09:58 --> Language Class Initialized
INFO - 2020-09-18 05:09:58 --> Loader Class Initialized
INFO - 2020-09-18 05:09:58 --> Helper loaded: html_helper
INFO - 2020-09-18 05:09:58 --> Helper loaded: url_helper
INFO - 2020-09-18 05:09:58 --> Helper loaded: form_helper
INFO - 2020-09-18 05:09:59 --> Database Driver Class Initialized
INFO - 2020-09-18 05:09:59 --> Form Validation Class Initialized
DEBUG - 2020-09-18 05:09:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 05:09:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 05:09:59 --> Encryption Class Initialized
INFO - 2020-09-18 05:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 05:09:59 --> Controller Class Initialized
INFO - 2020-09-18 05:09:59 --> Helper loaded: language_helper
INFO - 2020-09-18 05:09:59 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 05:10:00 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 05:10:00 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 05:10:00 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\customer_care.php
INFO - 2020-09-18 05:10:00 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 05:10:00 --> Final output sent to browser
DEBUG - 2020-09-18 05:10:00 --> Total execution time: 1.7119
INFO - 2020-09-18 05:10:25 --> Config Class Initialized
INFO - 2020-09-18 05:10:25 --> Hooks Class Initialized
DEBUG - 2020-09-18 05:10:25 --> UTF-8 Support Enabled
INFO - 2020-09-18 05:10:25 --> Utf8 Class Initialized
INFO - 2020-09-18 05:10:25 --> URI Class Initialized
INFO - 2020-09-18 05:10:25 --> Router Class Initialized
INFO - 2020-09-18 05:10:25 --> Output Class Initialized
INFO - 2020-09-18 05:10:25 --> Security Class Initialized
DEBUG - 2020-09-18 05:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 05:10:25 --> Input Class Initialized
INFO - 2020-09-18 05:10:25 --> Language Class Initialized
INFO - 2020-09-18 05:10:25 --> Loader Class Initialized
INFO - 2020-09-18 05:10:25 --> Helper loaded: html_helper
INFO - 2020-09-18 05:10:25 --> Helper loaded: url_helper
INFO - 2020-09-18 05:10:25 --> Helper loaded: form_helper
INFO - 2020-09-18 05:10:25 --> Database Driver Class Initialized
INFO - 2020-09-18 05:10:25 --> Form Validation Class Initialized
DEBUG - 2020-09-18 05:10:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 05:10:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 05:10:25 --> Encryption Class Initialized
INFO - 2020-09-18 05:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 05:10:26 --> Controller Class Initialized
INFO - 2020-09-18 05:10:26 --> Helper loaded: language_helper
INFO - 2020-09-18 05:10:26 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 05:10:26 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 05:10:26 --> Final output sent to browser
DEBUG - 2020-09-18 05:10:26 --> Total execution time: 1.2661
INFO - 2020-09-18 05:11:16 --> Config Class Initialized
INFO - 2020-09-18 05:11:16 --> Hooks Class Initialized
DEBUG - 2020-09-18 05:11:16 --> UTF-8 Support Enabled
INFO - 2020-09-18 05:11:16 --> Utf8 Class Initialized
INFO - 2020-09-18 05:11:16 --> URI Class Initialized
INFO - 2020-09-18 05:11:16 --> Router Class Initialized
INFO - 2020-09-18 05:11:16 --> Output Class Initialized
INFO - 2020-09-18 05:11:16 --> Security Class Initialized
DEBUG - 2020-09-18 05:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 05:11:16 --> Input Class Initialized
INFO - 2020-09-18 05:11:16 --> Language Class Initialized
INFO - 2020-09-18 05:11:16 --> Loader Class Initialized
INFO - 2020-09-18 05:11:16 --> Helper loaded: html_helper
INFO - 2020-09-18 05:11:16 --> Helper loaded: url_helper
INFO - 2020-09-18 05:11:16 --> Helper loaded: form_helper
INFO - 2020-09-18 05:11:16 --> Database Driver Class Initialized
INFO - 2020-09-18 05:11:16 --> Form Validation Class Initialized
DEBUG - 2020-09-18 05:11:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 05:11:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 05:11:16 --> Encryption Class Initialized
INFO - 2020-09-18 05:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 05:11:17 --> Controller Class Initialized
INFO - 2020-09-18 05:11:17 --> Helper loaded: language_helper
INFO - 2020-09-18 05:11:17 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 05:11:17 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 05:11:17 --> Final output sent to browser
DEBUG - 2020-09-18 05:11:17 --> Total execution time: 1.0266
INFO - 2020-09-18 05:11:25 --> Config Class Initialized
INFO - 2020-09-18 05:11:25 --> Hooks Class Initialized
DEBUG - 2020-09-18 05:11:25 --> UTF-8 Support Enabled
INFO - 2020-09-18 05:11:25 --> Utf8 Class Initialized
INFO - 2020-09-18 05:11:25 --> URI Class Initialized
INFO - 2020-09-18 05:11:25 --> Router Class Initialized
INFO - 2020-09-18 05:11:25 --> Output Class Initialized
INFO - 2020-09-18 05:11:25 --> Security Class Initialized
DEBUG - 2020-09-18 05:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 05:11:25 --> Input Class Initialized
INFO - 2020-09-18 05:11:25 --> Language Class Initialized
INFO - 2020-09-18 05:11:25 --> Loader Class Initialized
INFO - 2020-09-18 05:11:25 --> Helper loaded: html_helper
INFO - 2020-09-18 05:11:26 --> Helper loaded: url_helper
INFO - 2020-09-18 05:11:26 --> Helper loaded: form_helper
INFO - 2020-09-18 05:11:26 --> Database Driver Class Initialized
INFO - 2020-09-18 05:11:26 --> Form Validation Class Initialized
DEBUG - 2020-09-18 05:11:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 05:11:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 05:11:26 --> Encryption Class Initialized
INFO - 2020-09-18 05:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 05:11:26 --> Controller Class Initialized
INFO - 2020-09-18 05:11:26 --> Helper loaded: language_helper
INFO - 2020-09-18 05:11:26 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 05:11:26 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 05:11:26 --> Final output sent to browser
DEBUG - 2020-09-18 05:11:26 --> Total execution time: 1.3339
INFO - 2020-09-18 05:12:09 --> Config Class Initialized
INFO - 2020-09-18 05:12:09 --> Hooks Class Initialized
DEBUG - 2020-09-18 05:12:09 --> UTF-8 Support Enabled
INFO - 2020-09-18 05:12:09 --> Utf8 Class Initialized
INFO - 2020-09-18 05:12:09 --> URI Class Initialized
INFO - 2020-09-18 05:12:09 --> Router Class Initialized
INFO - 2020-09-18 05:12:09 --> Output Class Initialized
INFO - 2020-09-18 05:12:09 --> Security Class Initialized
DEBUG - 2020-09-18 05:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 05:12:09 --> Input Class Initialized
INFO - 2020-09-18 05:12:10 --> Language Class Initialized
INFO - 2020-09-18 05:12:10 --> Loader Class Initialized
INFO - 2020-09-18 05:12:10 --> Helper loaded: html_helper
INFO - 2020-09-18 05:12:10 --> Helper loaded: url_helper
INFO - 2020-09-18 05:12:10 --> Helper loaded: form_helper
INFO - 2020-09-18 05:12:10 --> Database Driver Class Initialized
INFO - 2020-09-18 05:12:10 --> Form Validation Class Initialized
DEBUG - 2020-09-18 05:12:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 05:12:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 05:12:10 --> Encryption Class Initialized
INFO - 2020-09-18 05:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 05:12:10 --> Controller Class Initialized
INFO - 2020-09-18 05:12:10 --> Helper loaded: language_helper
INFO - 2020-09-18 05:12:10 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 05:12:10 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 05:12:10 --> Final output sent to browser
DEBUG - 2020-09-18 05:12:10 --> Total execution time: 1.0948
INFO - 2020-09-18 05:12:39 --> Config Class Initialized
INFO - 2020-09-18 05:12:39 --> Hooks Class Initialized
DEBUG - 2020-09-18 05:12:39 --> UTF-8 Support Enabled
INFO - 2020-09-18 05:12:39 --> Utf8 Class Initialized
INFO - 2020-09-18 05:12:39 --> URI Class Initialized
INFO - 2020-09-18 05:12:39 --> Router Class Initialized
INFO - 2020-09-18 05:12:39 --> Output Class Initialized
INFO - 2020-09-18 05:12:39 --> Security Class Initialized
DEBUG - 2020-09-18 05:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 05:12:39 --> Input Class Initialized
INFO - 2020-09-18 05:12:39 --> Language Class Initialized
INFO - 2020-09-18 05:12:39 --> Loader Class Initialized
INFO - 2020-09-18 05:12:39 --> Helper loaded: html_helper
INFO - 2020-09-18 05:12:39 --> Helper loaded: url_helper
INFO - 2020-09-18 05:12:39 --> Helper loaded: form_helper
INFO - 2020-09-18 05:12:39 --> Database Driver Class Initialized
INFO - 2020-09-18 05:12:40 --> Form Validation Class Initialized
DEBUG - 2020-09-18 05:12:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 05:12:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 05:12:40 --> Encryption Class Initialized
INFO - 2020-09-18 05:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 05:12:40 --> Controller Class Initialized
INFO - 2020-09-18 05:12:40 --> Helper loaded: language_helper
INFO - 2020-09-18 05:12:40 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 05:12:40 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 05:12:40 --> Final output sent to browser
DEBUG - 2020-09-18 05:12:40 --> Total execution time: 1.0617
INFO - 2020-09-18 05:12:57 --> Config Class Initialized
INFO - 2020-09-18 05:12:57 --> Hooks Class Initialized
DEBUG - 2020-09-18 05:12:57 --> UTF-8 Support Enabled
INFO - 2020-09-18 05:12:57 --> Utf8 Class Initialized
INFO - 2020-09-18 05:12:57 --> URI Class Initialized
INFO - 2020-09-18 05:12:57 --> Router Class Initialized
INFO - 2020-09-18 05:12:57 --> Output Class Initialized
INFO - 2020-09-18 05:12:57 --> Security Class Initialized
DEBUG - 2020-09-18 05:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 05:12:57 --> Input Class Initialized
INFO - 2020-09-18 05:12:57 --> Language Class Initialized
INFO - 2020-09-18 05:12:57 --> Loader Class Initialized
INFO - 2020-09-18 05:12:57 --> Helper loaded: html_helper
INFO - 2020-09-18 05:12:57 --> Helper loaded: url_helper
INFO - 2020-09-18 05:12:57 --> Helper loaded: form_helper
INFO - 2020-09-18 05:12:57 --> Database Driver Class Initialized
INFO - 2020-09-18 05:12:58 --> Form Validation Class Initialized
DEBUG - 2020-09-18 05:12:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 05:12:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 05:12:58 --> Encryption Class Initialized
INFO - 2020-09-18 05:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 05:12:58 --> Controller Class Initialized
INFO - 2020-09-18 05:12:58 --> Helper loaded: language_helper
INFO - 2020-09-18 05:12:58 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 05:12:58 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 05:12:58 --> Final output sent to browser
DEBUG - 2020-09-18 05:12:58 --> Total execution time: 1.0662
INFO - 2020-09-18 05:13:12 --> Config Class Initialized
INFO - 2020-09-18 05:13:12 --> Hooks Class Initialized
DEBUG - 2020-09-18 05:13:12 --> UTF-8 Support Enabled
INFO - 2020-09-18 05:13:12 --> Utf8 Class Initialized
INFO - 2020-09-18 05:13:12 --> URI Class Initialized
INFO - 2020-09-18 05:13:12 --> Router Class Initialized
INFO - 2020-09-18 05:13:12 --> Output Class Initialized
INFO - 2020-09-18 05:13:12 --> Security Class Initialized
DEBUG - 2020-09-18 05:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 05:13:12 --> Input Class Initialized
INFO - 2020-09-18 05:13:12 --> Language Class Initialized
INFO - 2020-09-18 05:13:12 --> Loader Class Initialized
INFO - 2020-09-18 05:13:12 --> Helper loaded: html_helper
INFO - 2020-09-18 05:13:12 --> Helper loaded: url_helper
INFO - 2020-09-18 05:13:12 --> Helper loaded: form_helper
INFO - 2020-09-18 05:13:12 --> Database Driver Class Initialized
INFO - 2020-09-18 05:13:12 --> Form Validation Class Initialized
DEBUG - 2020-09-18 05:13:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 05:13:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 05:13:12 --> Encryption Class Initialized
INFO - 2020-09-18 05:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 05:13:12 --> Controller Class Initialized
INFO - 2020-09-18 05:13:12 --> Helper loaded: language_helper
INFO - 2020-09-18 05:13:13 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 05:13:13 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 05:13:13 --> Final output sent to browser
DEBUG - 2020-09-18 05:13:13 --> Total execution time: 1.0687
INFO - 2020-09-18 05:13:49 --> Config Class Initialized
INFO - 2020-09-18 05:13:49 --> Hooks Class Initialized
DEBUG - 2020-09-18 05:13:49 --> UTF-8 Support Enabled
INFO - 2020-09-18 05:13:49 --> Utf8 Class Initialized
INFO - 2020-09-18 05:13:49 --> URI Class Initialized
INFO - 2020-09-18 05:13:49 --> Router Class Initialized
INFO - 2020-09-18 05:13:49 --> Output Class Initialized
INFO - 2020-09-18 05:13:49 --> Security Class Initialized
DEBUG - 2020-09-18 05:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 05:13:49 --> Input Class Initialized
INFO - 2020-09-18 05:13:49 --> Language Class Initialized
INFO - 2020-09-18 05:13:49 --> Loader Class Initialized
INFO - 2020-09-18 05:13:49 --> Helper loaded: html_helper
INFO - 2020-09-18 05:13:49 --> Helper loaded: url_helper
INFO - 2020-09-18 05:13:49 --> Helper loaded: form_helper
INFO - 2020-09-18 05:13:49 --> Database Driver Class Initialized
INFO - 2020-09-18 05:13:50 --> Form Validation Class Initialized
DEBUG - 2020-09-18 05:13:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 05:13:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 05:13:50 --> Encryption Class Initialized
INFO - 2020-09-18 05:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 05:13:50 --> Controller Class Initialized
INFO - 2020-09-18 05:13:50 --> Helper loaded: language_helper
INFO - 2020-09-18 05:13:50 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 05:13:50 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 05:13:50 --> Final output sent to browser
DEBUG - 2020-09-18 05:13:50 --> Total execution time: 1.0900
INFO - 2020-09-18 05:14:13 --> Config Class Initialized
INFO - 2020-09-18 05:14:13 --> Hooks Class Initialized
DEBUG - 2020-09-18 05:14:13 --> UTF-8 Support Enabled
INFO - 2020-09-18 05:14:13 --> Utf8 Class Initialized
INFO - 2020-09-18 05:14:13 --> URI Class Initialized
INFO - 2020-09-18 05:14:13 --> Router Class Initialized
INFO - 2020-09-18 05:14:13 --> Output Class Initialized
INFO - 2020-09-18 05:14:13 --> Security Class Initialized
DEBUG - 2020-09-18 05:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 05:14:13 --> Input Class Initialized
INFO - 2020-09-18 05:14:13 --> Language Class Initialized
INFO - 2020-09-18 05:14:14 --> Loader Class Initialized
INFO - 2020-09-18 05:14:14 --> Helper loaded: html_helper
INFO - 2020-09-18 05:14:14 --> Helper loaded: url_helper
INFO - 2020-09-18 05:14:14 --> Helper loaded: form_helper
INFO - 2020-09-18 05:14:14 --> Database Driver Class Initialized
INFO - 2020-09-18 05:14:14 --> Form Validation Class Initialized
DEBUG - 2020-09-18 05:14:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 05:14:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 05:14:14 --> Encryption Class Initialized
INFO - 2020-09-18 05:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 05:14:14 --> Controller Class Initialized
INFO - 2020-09-18 05:14:14 --> Helper loaded: language_helper
INFO - 2020-09-18 05:14:14 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 05:14:14 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 05:14:14 --> Final output sent to browser
DEBUG - 2020-09-18 05:14:14 --> Total execution time: 1.0247
INFO - 2020-09-18 05:14:32 --> Config Class Initialized
INFO - 2020-09-18 05:14:32 --> Hooks Class Initialized
DEBUG - 2020-09-18 05:14:32 --> UTF-8 Support Enabled
INFO - 2020-09-18 05:14:32 --> Utf8 Class Initialized
INFO - 2020-09-18 05:14:32 --> URI Class Initialized
INFO - 2020-09-18 05:14:32 --> Router Class Initialized
INFO - 2020-09-18 05:14:32 --> Output Class Initialized
INFO - 2020-09-18 05:14:32 --> Security Class Initialized
DEBUG - 2020-09-18 05:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 05:14:32 --> Input Class Initialized
INFO - 2020-09-18 05:14:32 --> Language Class Initialized
INFO - 2020-09-18 05:14:32 --> Loader Class Initialized
INFO - 2020-09-18 05:14:33 --> Helper loaded: html_helper
INFO - 2020-09-18 05:14:33 --> Helper loaded: url_helper
INFO - 2020-09-18 05:14:33 --> Helper loaded: form_helper
INFO - 2020-09-18 05:14:33 --> Database Driver Class Initialized
INFO - 2020-09-18 05:14:33 --> Form Validation Class Initialized
DEBUG - 2020-09-18 05:14:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 05:14:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 05:14:33 --> Encryption Class Initialized
INFO - 2020-09-18 05:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 05:14:33 --> Controller Class Initialized
INFO - 2020-09-18 05:14:33 --> Helper loaded: language_helper
INFO - 2020-09-18 05:14:33 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 05:14:33 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 05:14:33 --> Final output sent to browser
DEBUG - 2020-09-18 05:14:33 --> Total execution time: 1.0187
INFO - 2020-09-18 05:15:21 --> Config Class Initialized
INFO - 2020-09-18 05:15:21 --> Hooks Class Initialized
DEBUG - 2020-09-18 05:15:21 --> UTF-8 Support Enabled
INFO - 2020-09-18 05:15:21 --> Utf8 Class Initialized
INFO - 2020-09-18 05:15:21 --> URI Class Initialized
INFO - 2020-09-18 05:15:21 --> Router Class Initialized
INFO - 2020-09-18 05:15:22 --> Output Class Initialized
INFO - 2020-09-18 05:15:22 --> Security Class Initialized
DEBUG - 2020-09-18 05:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 05:15:22 --> Input Class Initialized
INFO - 2020-09-18 05:15:22 --> Language Class Initialized
INFO - 2020-09-18 05:15:22 --> Loader Class Initialized
INFO - 2020-09-18 05:15:22 --> Helper loaded: html_helper
INFO - 2020-09-18 05:15:22 --> Helper loaded: url_helper
INFO - 2020-09-18 05:15:22 --> Helper loaded: form_helper
INFO - 2020-09-18 05:15:22 --> Database Driver Class Initialized
INFO - 2020-09-18 05:15:22 --> Form Validation Class Initialized
DEBUG - 2020-09-18 05:15:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 05:15:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 05:15:22 --> Encryption Class Initialized
INFO - 2020-09-18 05:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 05:15:22 --> Controller Class Initialized
INFO - 2020-09-18 05:15:22 --> Helper loaded: language_helper
INFO - 2020-09-18 05:15:22 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 05:15:22 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 05:15:22 --> Final output sent to browser
DEBUG - 2020-09-18 05:15:22 --> Total execution time: 1.0073
INFO - 2020-09-18 05:17:20 --> Config Class Initialized
INFO - 2020-09-18 05:17:20 --> Hooks Class Initialized
DEBUG - 2020-09-18 05:17:20 --> UTF-8 Support Enabled
INFO - 2020-09-18 05:17:21 --> Utf8 Class Initialized
INFO - 2020-09-18 05:17:21 --> URI Class Initialized
INFO - 2020-09-18 05:17:21 --> Router Class Initialized
INFO - 2020-09-18 05:17:21 --> Output Class Initialized
INFO - 2020-09-18 05:17:21 --> Security Class Initialized
DEBUG - 2020-09-18 05:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 05:17:21 --> Input Class Initialized
INFO - 2020-09-18 05:17:21 --> Language Class Initialized
INFO - 2020-09-18 05:17:21 --> Loader Class Initialized
INFO - 2020-09-18 05:17:21 --> Helper loaded: html_helper
INFO - 2020-09-18 05:17:21 --> Helper loaded: url_helper
INFO - 2020-09-18 05:17:21 --> Helper loaded: form_helper
INFO - 2020-09-18 05:17:21 --> Database Driver Class Initialized
INFO - 2020-09-18 05:17:21 --> Form Validation Class Initialized
DEBUG - 2020-09-18 05:17:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 05:17:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 05:17:21 --> Encryption Class Initialized
INFO - 2020-09-18 05:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 05:17:21 --> Controller Class Initialized
INFO - 2020-09-18 05:17:21 --> Helper loaded: language_helper
INFO - 2020-09-18 05:17:21 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 05:17:21 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 05:17:21 --> Final output sent to browser
DEBUG - 2020-09-18 05:17:21 --> Total execution time: 1.0257
INFO - 2020-09-18 05:17:25 --> Config Class Initialized
INFO - 2020-09-18 05:17:25 --> Hooks Class Initialized
DEBUG - 2020-09-18 05:17:25 --> UTF-8 Support Enabled
INFO - 2020-09-18 05:17:25 --> Utf8 Class Initialized
INFO - 2020-09-18 05:17:25 --> URI Class Initialized
INFO - 2020-09-18 05:17:25 --> Router Class Initialized
INFO - 2020-09-18 05:17:25 --> Output Class Initialized
INFO - 2020-09-18 05:17:25 --> Security Class Initialized
DEBUG - 2020-09-18 05:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 05:17:25 --> Input Class Initialized
INFO - 2020-09-18 05:17:25 --> Language Class Initialized
INFO - 2020-09-18 05:17:25 --> Loader Class Initialized
INFO - 2020-09-18 05:17:25 --> Helper loaded: html_helper
INFO - 2020-09-18 05:17:25 --> Helper loaded: url_helper
INFO - 2020-09-18 05:17:25 --> Helper loaded: form_helper
INFO - 2020-09-18 05:17:25 --> Database Driver Class Initialized
INFO - 2020-09-18 05:17:25 --> Form Validation Class Initialized
DEBUG - 2020-09-18 05:17:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 05:17:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 05:17:25 --> Encryption Class Initialized
INFO - 2020-09-18 05:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 05:17:25 --> Controller Class Initialized
INFO - 2020-09-18 05:17:25 --> Helper loaded: language_helper
INFO - 2020-09-18 05:17:26 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 05:17:26 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 05:17:26 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 05:17:26 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\customer_care.php
INFO - 2020-09-18 05:17:26 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 05:17:26 --> Final output sent to browser
DEBUG - 2020-09-18 05:17:26 --> Total execution time: 1.1342
INFO - 2020-09-18 05:17:29 --> Config Class Initialized
INFO - 2020-09-18 05:17:29 --> Hooks Class Initialized
DEBUG - 2020-09-18 05:17:29 --> UTF-8 Support Enabled
INFO - 2020-09-18 05:17:29 --> Utf8 Class Initialized
INFO - 2020-09-18 05:17:30 --> URI Class Initialized
INFO - 2020-09-18 05:17:30 --> Router Class Initialized
INFO - 2020-09-18 05:17:30 --> Output Class Initialized
INFO - 2020-09-18 05:17:30 --> Security Class Initialized
DEBUG - 2020-09-18 05:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 05:17:30 --> Input Class Initialized
INFO - 2020-09-18 05:17:30 --> Language Class Initialized
INFO - 2020-09-18 05:17:30 --> Loader Class Initialized
INFO - 2020-09-18 05:17:30 --> Helper loaded: html_helper
INFO - 2020-09-18 05:17:30 --> Helper loaded: url_helper
INFO - 2020-09-18 05:17:30 --> Helper loaded: form_helper
INFO - 2020-09-18 05:17:30 --> Database Driver Class Initialized
INFO - 2020-09-18 05:17:30 --> Form Validation Class Initialized
DEBUG - 2020-09-18 05:17:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 05:17:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 05:17:30 --> Encryption Class Initialized
INFO - 2020-09-18 05:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 05:17:30 --> Controller Class Initialized
INFO - 2020-09-18 05:17:30 --> Helper loaded: language_helper
INFO - 2020-09-18 05:17:30 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 05:17:30 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 05:17:30 --> Final output sent to browser
DEBUG - 2020-09-18 05:17:30 --> Total execution time: 1.0725
INFO - 2020-09-18 05:17:50 --> Config Class Initialized
INFO - 2020-09-18 05:17:50 --> Hooks Class Initialized
DEBUG - 2020-09-18 05:17:51 --> UTF-8 Support Enabled
INFO - 2020-09-18 05:17:51 --> Utf8 Class Initialized
INFO - 2020-09-18 05:17:51 --> URI Class Initialized
INFO - 2020-09-18 05:17:51 --> Router Class Initialized
INFO - 2020-09-18 05:17:51 --> Output Class Initialized
INFO - 2020-09-18 05:17:51 --> Security Class Initialized
DEBUG - 2020-09-18 05:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 05:17:51 --> Input Class Initialized
INFO - 2020-09-18 05:17:51 --> Language Class Initialized
INFO - 2020-09-18 05:17:51 --> Loader Class Initialized
INFO - 2020-09-18 05:17:51 --> Helper loaded: html_helper
INFO - 2020-09-18 05:17:51 --> Helper loaded: url_helper
INFO - 2020-09-18 05:17:51 --> Helper loaded: form_helper
INFO - 2020-09-18 05:17:51 --> Database Driver Class Initialized
INFO - 2020-09-18 05:17:51 --> Form Validation Class Initialized
DEBUG - 2020-09-18 05:17:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 05:17:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 05:17:51 --> Encryption Class Initialized
INFO - 2020-09-18 05:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 05:17:51 --> Controller Class Initialized
INFO - 2020-09-18 05:17:52 --> Helper loaded: language_helper
INFO - 2020-09-18 05:17:52 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 05:17:52 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 05:17:52 --> Final output sent to browser
DEBUG - 2020-09-18 05:17:52 --> Total execution time: 1.3575
INFO - 2020-09-18 05:17:57 --> Config Class Initialized
INFO - 2020-09-18 05:17:57 --> Hooks Class Initialized
DEBUG - 2020-09-18 05:17:57 --> UTF-8 Support Enabled
INFO - 2020-09-18 05:17:57 --> Utf8 Class Initialized
INFO - 2020-09-18 05:17:57 --> URI Class Initialized
INFO - 2020-09-18 05:17:57 --> Router Class Initialized
INFO - 2020-09-18 05:17:57 --> Output Class Initialized
INFO - 2020-09-18 05:17:57 --> Security Class Initialized
DEBUG - 2020-09-18 05:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 05:17:57 --> Input Class Initialized
INFO - 2020-09-18 05:17:58 --> Language Class Initialized
INFO - 2020-09-18 05:17:58 --> Loader Class Initialized
INFO - 2020-09-18 05:17:58 --> Helper loaded: html_helper
INFO - 2020-09-18 05:17:58 --> Helper loaded: url_helper
INFO - 2020-09-18 05:17:58 --> Helper loaded: form_helper
INFO - 2020-09-18 05:17:58 --> Database Driver Class Initialized
INFO - 2020-09-18 05:17:58 --> Form Validation Class Initialized
DEBUG - 2020-09-18 05:17:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 05:17:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 05:17:58 --> Encryption Class Initialized
INFO - 2020-09-18 05:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 05:17:58 --> Controller Class Initialized
INFO - 2020-09-18 05:17:58 --> Helper loaded: language_helper
INFO - 2020-09-18 05:17:58 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 05:17:58 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 05:17:58 --> Final output sent to browser
DEBUG - 2020-09-18 05:17:58 --> Total execution time: 0.9957
INFO - 2020-09-18 05:22:44 --> Config Class Initialized
INFO - 2020-09-18 05:22:44 --> Hooks Class Initialized
DEBUG - 2020-09-18 05:22:44 --> UTF-8 Support Enabled
INFO - 2020-09-18 05:22:44 --> Utf8 Class Initialized
INFO - 2020-09-18 05:22:44 --> URI Class Initialized
INFO - 2020-09-18 05:22:44 --> Router Class Initialized
INFO - 2020-09-18 05:22:44 --> Output Class Initialized
INFO - 2020-09-18 05:22:44 --> Security Class Initialized
DEBUG - 2020-09-18 05:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 05:22:44 --> Input Class Initialized
INFO - 2020-09-18 05:22:44 --> Language Class Initialized
INFO - 2020-09-18 05:22:44 --> Loader Class Initialized
INFO - 2020-09-18 05:22:44 --> Helper loaded: html_helper
INFO - 2020-09-18 05:22:45 --> Helper loaded: url_helper
INFO - 2020-09-18 05:22:45 --> Helper loaded: form_helper
INFO - 2020-09-18 05:22:45 --> Database Driver Class Initialized
INFO - 2020-09-18 05:22:45 --> Form Validation Class Initialized
DEBUG - 2020-09-18 05:22:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 05:22:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 05:22:45 --> Encryption Class Initialized
INFO - 2020-09-18 05:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 05:22:45 --> Controller Class Initialized
INFO - 2020-09-18 05:22:45 --> Helper loaded: language_helper
INFO - 2020-09-18 05:22:45 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 05:22:45 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 05:22:45 --> Final output sent to browser
DEBUG - 2020-09-18 05:22:45 --> Total execution time: 0.9918
INFO - 2020-09-18 10:03:17 --> Config Class Initialized
INFO - 2020-09-18 10:03:17 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:03:17 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:03:17 --> Utf8 Class Initialized
INFO - 2020-09-18 10:03:17 --> URI Class Initialized
INFO - 2020-09-18 10:03:17 --> Router Class Initialized
INFO - 2020-09-18 10:03:17 --> Output Class Initialized
INFO - 2020-09-18 10:03:17 --> Security Class Initialized
DEBUG - 2020-09-18 10:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:03:17 --> Input Class Initialized
INFO - 2020-09-18 10:03:17 --> Language Class Initialized
INFO - 2020-09-18 10:03:18 --> Loader Class Initialized
INFO - 2020-09-18 10:03:18 --> Helper loaded: html_helper
INFO - 2020-09-18 10:03:18 --> Helper loaded: url_helper
INFO - 2020-09-18 10:03:18 --> Helper loaded: form_helper
INFO - 2020-09-18 10:03:18 --> Database Driver Class Initialized
INFO - 2020-09-18 10:03:18 --> Form Validation Class Initialized
DEBUG - 2020-09-18 10:03:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 10:03:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 10:03:18 --> Encryption Class Initialized
INFO - 2020-09-18 10:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:03:18 --> Controller Class Initialized
INFO - 2020-09-18 10:03:18 --> Helper loaded: language_helper
INFO - 2020-09-18 10:03:18 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 10:03:18 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 10:03:18 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 10:03:19 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-18 10:03:19 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 10:03:19 --> Final output sent to browser
DEBUG - 2020-09-18 10:03:19 --> Total execution time: 1.9472
INFO - 2020-09-18 10:03:21 --> Config Class Initialized
INFO - 2020-09-18 10:03:21 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:03:21 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:03:21 --> Utf8 Class Initialized
INFO - 2020-09-18 10:03:21 --> URI Class Initialized
INFO - 2020-09-18 10:03:21 --> Router Class Initialized
INFO - 2020-09-18 10:03:21 --> Output Class Initialized
INFO - 2020-09-18 10:03:21 --> Security Class Initialized
DEBUG - 2020-09-18 10:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:03:21 --> Input Class Initialized
INFO - 2020-09-18 10:03:21 --> Language Class Initialized
INFO - 2020-09-18 10:03:21 --> Loader Class Initialized
INFO - 2020-09-18 10:03:21 --> Helper loaded: html_helper
INFO - 2020-09-18 10:03:21 --> Helper loaded: url_helper
INFO - 2020-09-18 10:03:21 --> Helper loaded: form_helper
INFO - 2020-09-18 10:03:21 --> Database Driver Class Initialized
INFO - 2020-09-18 10:03:21 --> Form Validation Class Initialized
DEBUG - 2020-09-18 10:03:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 10:03:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 10:03:21 --> Encryption Class Initialized
INFO - 2020-09-18 10:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:03:22 --> Controller Class Initialized
INFO - 2020-09-18 10:03:22 --> Helper loaded: language_helper
INFO - 2020-09-18 10:03:22 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 10:03:22 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 10:03:22 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 10:03:22 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment_custom.php
INFO - 2020-09-18 10:03:22 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 10:03:22 --> Final output sent to browser
DEBUG - 2020-09-18 10:03:22 --> Total execution time: 1.1740
INFO - 2020-09-18 10:03:23 --> Config Class Initialized
INFO - 2020-09-18 10:03:23 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:03:23 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:03:23 --> Utf8 Class Initialized
INFO - 2020-09-18 10:03:23 --> URI Class Initialized
INFO - 2020-09-18 10:03:23 --> Router Class Initialized
INFO - 2020-09-18 10:03:23 --> Output Class Initialized
INFO - 2020-09-18 10:03:23 --> Security Class Initialized
DEBUG - 2020-09-18 10:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:03:23 --> Input Class Initialized
INFO - 2020-09-18 10:03:23 --> Language Class Initialized
INFO - 2020-09-18 10:03:23 --> Loader Class Initialized
INFO - 2020-09-18 10:03:23 --> Helper loaded: html_helper
INFO - 2020-09-18 10:03:23 --> Helper loaded: url_helper
INFO - 2020-09-18 10:03:23 --> Helper loaded: form_helper
INFO - 2020-09-18 10:03:23 --> Database Driver Class Initialized
INFO - 2020-09-18 10:03:23 --> Form Validation Class Initialized
DEBUG - 2020-09-18 10:03:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 10:03:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 10:03:23 --> Encryption Class Initialized
INFO - 2020-09-18 10:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:03:23 --> Controller Class Initialized
INFO - 2020-09-18 10:03:23 --> Helper loaded: language_helper
INFO - 2020-09-18 10:03:23 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 10:03:23 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 10:03:23 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 10:03:23 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\customer_care.php
INFO - 2020-09-18 10:03:24 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 10:03:24 --> Final output sent to browser
DEBUG - 2020-09-18 10:03:24 --> Total execution time: 1.1373
INFO - 2020-09-18 10:03:32 --> Config Class Initialized
INFO - 2020-09-18 10:03:32 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:03:32 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:03:32 --> Utf8 Class Initialized
INFO - 2020-09-18 10:03:32 --> URI Class Initialized
INFO - 2020-09-18 10:03:32 --> Router Class Initialized
INFO - 2020-09-18 10:03:33 --> Output Class Initialized
INFO - 2020-09-18 10:03:33 --> Security Class Initialized
DEBUG - 2020-09-18 10:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:03:33 --> Input Class Initialized
INFO - 2020-09-18 10:03:33 --> Language Class Initialized
INFO - 2020-09-18 10:03:33 --> Loader Class Initialized
INFO - 2020-09-18 10:03:33 --> Helper loaded: html_helper
INFO - 2020-09-18 10:03:33 --> Helper loaded: url_helper
INFO - 2020-09-18 10:03:33 --> Helper loaded: form_helper
INFO - 2020-09-18 10:03:33 --> Database Driver Class Initialized
INFO - 2020-09-18 10:03:33 --> Form Validation Class Initialized
DEBUG - 2020-09-18 10:03:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 10:03:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 10:03:33 --> Encryption Class Initialized
INFO - 2020-09-18 10:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:03:33 --> Controller Class Initialized
INFO - 2020-09-18 10:03:33 --> Helper loaded: language_helper
INFO - 2020-09-18 10:03:33 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 10:03:33 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 10:03:33 --> Final output sent to browser
DEBUG - 2020-09-18 10:03:33 --> Total execution time: 1.0599
INFO - 2020-09-18 10:12:03 --> Config Class Initialized
INFO - 2020-09-18 10:12:03 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:12:03 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:12:03 --> Utf8 Class Initialized
INFO - 2020-09-18 10:12:03 --> URI Class Initialized
INFO - 2020-09-18 10:12:03 --> Router Class Initialized
INFO - 2020-09-18 10:12:03 --> Output Class Initialized
INFO - 2020-09-18 10:12:03 --> Security Class Initialized
DEBUG - 2020-09-18 10:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:12:03 --> Input Class Initialized
INFO - 2020-09-18 10:12:03 --> Language Class Initialized
INFO - 2020-09-18 10:12:03 --> Loader Class Initialized
INFO - 2020-09-18 10:12:03 --> Helper loaded: html_helper
INFO - 2020-09-18 10:12:03 --> Helper loaded: url_helper
INFO - 2020-09-18 10:12:03 --> Helper loaded: form_helper
INFO - 2020-09-18 10:12:03 --> Database Driver Class Initialized
INFO - 2020-09-18 10:12:03 --> Form Validation Class Initialized
DEBUG - 2020-09-18 10:12:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 10:12:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 10:12:03 --> Encryption Class Initialized
INFO - 2020-09-18 10:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:12:03 --> Controller Class Initialized
INFO - 2020-09-18 10:12:03 --> Helper loaded: language_helper
INFO - 2020-09-18 10:12:04 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 10:12:04 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 10:12:04 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 10:12:04 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\customer_care.php
INFO - 2020-09-18 10:12:04 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 10:12:04 --> Final output sent to browser
DEBUG - 2020-09-18 10:12:04 --> Total execution time: 1.1980
INFO - 2020-09-18 10:12:20 --> Config Class Initialized
INFO - 2020-09-18 10:12:20 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:12:20 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:12:20 --> Utf8 Class Initialized
INFO - 2020-09-18 10:12:20 --> URI Class Initialized
INFO - 2020-09-18 10:12:20 --> Router Class Initialized
INFO - 2020-09-18 10:12:21 --> Output Class Initialized
INFO - 2020-09-18 10:12:21 --> Security Class Initialized
DEBUG - 2020-09-18 10:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:12:21 --> Input Class Initialized
INFO - 2020-09-18 10:12:21 --> Language Class Initialized
INFO - 2020-09-18 10:12:21 --> Loader Class Initialized
INFO - 2020-09-18 10:12:21 --> Helper loaded: html_helper
INFO - 2020-09-18 10:12:21 --> Helper loaded: url_helper
INFO - 2020-09-18 10:12:21 --> Helper loaded: form_helper
INFO - 2020-09-18 10:12:21 --> Database Driver Class Initialized
INFO - 2020-09-18 10:12:21 --> Form Validation Class Initialized
DEBUG - 2020-09-18 10:12:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 10:12:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 10:12:21 --> Encryption Class Initialized
INFO - 2020-09-18 10:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:12:21 --> Controller Class Initialized
INFO - 2020-09-18 10:12:21 --> Helper loaded: language_helper
INFO - 2020-09-18 10:12:21 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 10:12:21 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 10:12:21 --> Final output sent to browser
DEBUG - 2020-09-18 10:12:21 --> Total execution time: 1.1050
INFO - 2020-09-18 10:12:32 --> Config Class Initialized
INFO - 2020-09-18 10:12:32 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:12:32 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:12:32 --> Utf8 Class Initialized
INFO - 2020-09-18 10:12:32 --> URI Class Initialized
INFO - 2020-09-18 10:12:32 --> Router Class Initialized
INFO - 2020-09-18 10:12:32 --> Output Class Initialized
INFO - 2020-09-18 10:12:33 --> Security Class Initialized
DEBUG - 2020-09-18 10:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:12:33 --> Input Class Initialized
INFO - 2020-09-18 10:12:33 --> Language Class Initialized
INFO - 2020-09-18 10:12:33 --> Loader Class Initialized
INFO - 2020-09-18 10:12:33 --> Helper loaded: html_helper
INFO - 2020-09-18 10:12:33 --> Helper loaded: url_helper
INFO - 2020-09-18 10:12:33 --> Helper loaded: form_helper
INFO - 2020-09-18 10:12:33 --> Database Driver Class Initialized
INFO - 2020-09-18 10:12:33 --> Form Validation Class Initialized
DEBUG - 2020-09-18 10:12:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 10:12:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 10:12:33 --> Encryption Class Initialized
INFO - 2020-09-18 10:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:12:33 --> Controller Class Initialized
INFO - 2020-09-18 10:12:33 --> Helper loaded: language_helper
INFO - 2020-09-18 10:12:33 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 10:12:33 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 10:12:33 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 10:12:33 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\customer_care.php
INFO - 2020-09-18 10:12:33 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 10:12:33 --> Final output sent to browser
DEBUG - 2020-09-18 10:12:33 --> Total execution time: 1.1354
INFO - 2020-09-18 10:12:53 --> Config Class Initialized
INFO - 2020-09-18 10:12:53 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:12:53 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:12:53 --> Utf8 Class Initialized
INFO - 2020-09-18 10:12:53 --> URI Class Initialized
INFO - 2020-09-18 10:12:53 --> Router Class Initialized
INFO - 2020-09-18 10:12:53 --> Output Class Initialized
INFO - 2020-09-18 10:12:53 --> Security Class Initialized
DEBUG - 2020-09-18 10:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:12:54 --> Input Class Initialized
INFO - 2020-09-18 10:12:54 --> Language Class Initialized
INFO - 2020-09-18 10:12:54 --> Loader Class Initialized
INFO - 2020-09-18 10:12:54 --> Helper loaded: html_helper
INFO - 2020-09-18 10:12:54 --> Helper loaded: url_helper
INFO - 2020-09-18 10:12:54 --> Helper loaded: form_helper
INFO - 2020-09-18 10:12:54 --> Database Driver Class Initialized
INFO - 2020-09-18 10:12:54 --> Form Validation Class Initialized
DEBUG - 2020-09-18 10:12:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 10:12:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 10:12:54 --> Encryption Class Initialized
INFO - 2020-09-18 10:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:12:54 --> Controller Class Initialized
INFO - 2020-09-18 10:12:54 --> Helper loaded: language_helper
INFO - 2020-09-18 10:12:54 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 10:12:54 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 10:12:54 --> Final output sent to browser
DEBUG - 2020-09-18 10:12:54 --> Total execution time: 1.0403
INFO - 2020-09-18 10:19:01 --> Config Class Initialized
INFO - 2020-09-18 10:19:01 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:19:01 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:19:01 --> Utf8 Class Initialized
INFO - 2020-09-18 10:19:01 --> URI Class Initialized
INFO - 2020-09-18 10:19:01 --> Router Class Initialized
INFO - 2020-09-18 10:19:01 --> Output Class Initialized
INFO - 2020-09-18 10:19:01 --> Security Class Initialized
DEBUG - 2020-09-18 10:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:19:01 --> Input Class Initialized
INFO - 2020-09-18 10:19:01 --> Language Class Initialized
INFO - 2020-09-18 10:19:01 --> Loader Class Initialized
INFO - 2020-09-18 10:19:01 --> Helper loaded: html_helper
INFO - 2020-09-18 10:19:01 --> Helper loaded: url_helper
INFO - 2020-09-18 10:19:01 --> Helper loaded: form_helper
INFO - 2020-09-18 10:19:01 --> Database Driver Class Initialized
INFO - 2020-09-18 10:19:01 --> Form Validation Class Initialized
DEBUG - 2020-09-18 10:19:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 10:19:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 10:19:02 --> Encryption Class Initialized
INFO - 2020-09-18 10:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:19:02 --> Controller Class Initialized
INFO - 2020-09-18 10:19:02 --> Helper loaded: language_helper
INFO - 2020-09-18 10:19:02 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 10:19:02 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 10:19:02 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 10:19:02 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\customer_care.php
INFO - 2020-09-18 10:19:02 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 10:19:02 --> Final output sent to browser
DEBUG - 2020-09-18 10:19:02 --> Total execution time: 1.1506
INFO - 2020-09-18 10:19:13 --> Config Class Initialized
INFO - 2020-09-18 10:19:13 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:19:13 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:19:13 --> Utf8 Class Initialized
INFO - 2020-09-18 10:19:13 --> URI Class Initialized
INFO - 2020-09-18 10:19:13 --> Router Class Initialized
INFO - 2020-09-18 10:19:13 --> Output Class Initialized
INFO - 2020-09-18 10:19:13 --> Security Class Initialized
DEBUG - 2020-09-18 10:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:19:13 --> Input Class Initialized
INFO - 2020-09-18 10:19:13 --> Language Class Initialized
INFO - 2020-09-18 10:19:13 --> Loader Class Initialized
INFO - 2020-09-18 10:19:13 --> Helper loaded: html_helper
INFO - 2020-09-18 10:19:13 --> Helper loaded: url_helper
INFO - 2020-09-18 10:19:13 --> Helper loaded: form_helper
INFO - 2020-09-18 10:19:13 --> Database Driver Class Initialized
INFO - 2020-09-18 10:19:13 --> Form Validation Class Initialized
DEBUG - 2020-09-18 10:19:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 10:19:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 10:19:13 --> Encryption Class Initialized
INFO - 2020-09-18 10:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:19:13 --> Controller Class Initialized
INFO - 2020-09-18 10:19:14 --> Helper loaded: language_helper
INFO - 2020-09-18 10:19:14 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 10:19:14 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 10:19:14 --> Final output sent to browser
DEBUG - 2020-09-18 10:19:14 --> Total execution time: 1.0438
INFO - 2020-09-18 10:23:09 --> Config Class Initialized
INFO - 2020-09-18 10:23:09 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:23:09 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:23:09 --> Utf8 Class Initialized
INFO - 2020-09-18 10:23:09 --> URI Class Initialized
INFO - 2020-09-18 10:23:09 --> Router Class Initialized
INFO - 2020-09-18 10:23:09 --> Output Class Initialized
INFO - 2020-09-18 10:23:09 --> Security Class Initialized
DEBUG - 2020-09-18 10:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:23:09 --> Input Class Initialized
INFO - 2020-09-18 10:23:09 --> Language Class Initialized
INFO - 2020-09-18 10:23:09 --> Loader Class Initialized
INFO - 2020-09-18 10:23:09 --> Helper loaded: html_helper
INFO - 2020-09-18 10:23:09 --> Helper loaded: url_helper
INFO - 2020-09-18 10:23:09 --> Helper loaded: form_helper
INFO - 2020-09-18 10:23:09 --> Database Driver Class Initialized
INFO - 2020-09-18 10:23:09 --> Form Validation Class Initialized
DEBUG - 2020-09-18 10:23:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 10:23:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 10:23:10 --> Encryption Class Initialized
INFO - 2020-09-18 10:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:23:10 --> Controller Class Initialized
INFO - 2020-09-18 10:23:10 --> Helper loaded: language_helper
INFO - 2020-09-18 10:23:10 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 10:23:10 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 10:23:10 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 10:23:10 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\customer_care.php
INFO - 2020-09-18 10:23:10 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 10:23:10 --> Final output sent to browser
DEBUG - 2020-09-18 10:23:10 --> Total execution time: 1.1526
INFO - 2020-09-18 10:23:21 --> Config Class Initialized
INFO - 2020-09-18 10:23:21 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:23:21 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:23:21 --> Utf8 Class Initialized
INFO - 2020-09-18 10:23:21 --> URI Class Initialized
INFO - 2020-09-18 10:23:21 --> Router Class Initialized
INFO - 2020-09-18 10:23:21 --> Output Class Initialized
INFO - 2020-09-18 10:23:21 --> Security Class Initialized
DEBUG - 2020-09-18 10:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:23:21 --> Input Class Initialized
INFO - 2020-09-18 10:23:21 --> Language Class Initialized
INFO - 2020-09-18 10:23:21 --> Loader Class Initialized
INFO - 2020-09-18 10:23:21 --> Helper loaded: html_helper
INFO - 2020-09-18 10:23:21 --> Helper loaded: url_helper
INFO - 2020-09-18 10:23:21 --> Helper loaded: form_helper
INFO - 2020-09-18 10:23:21 --> Database Driver Class Initialized
INFO - 2020-09-18 10:23:21 --> Form Validation Class Initialized
DEBUG - 2020-09-18 10:23:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 10:23:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 10:23:22 --> Encryption Class Initialized
INFO - 2020-09-18 10:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:23:22 --> Controller Class Initialized
INFO - 2020-09-18 10:23:22 --> Helper loaded: language_helper
INFO - 2020-09-18 10:23:22 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 10:23:22 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 10:23:22 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 10:23:22 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\customer_care.php
INFO - 2020-09-18 10:23:22 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 10:23:22 --> Final output sent to browser
DEBUG - 2020-09-18 10:23:22 --> Total execution time: 1.0538
INFO - 2020-09-18 10:24:28 --> Config Class Initialized
INFO - 2020-09-18 10:24:28 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:24:28 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:24:28 --> Utf8 Class Initialized
INFO - 2020-09-18 10:24:28 --> URI Class Initialized
INFO - 2020-09-18 10:24:28 --> Router Class Initialized
INFO - 2020-09-18 10:24:28 --> Output Class Initialized
INFO - 2020-09-18 10:24:29 --> Security Class Initialized
DEBUG - 2020-09-18 10:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:24:29 --> Input Class Initialized
INFO - 2020-09-18 10:24:29 --> Language Class Initialized
INFO - 2020-09-18 10:24:29 --> Loader Class Initialized
INFO - 2020-09-18 10:24:29 --> Helper loaded: html_helper
INFO - 2020-09-18 10:24:29 --> Helper loaded: url_helper
INFO - 2020-09-18 10:24:29 --> Helper loaded: form_helper
INFO - 2020-09-18 10:24:29 --> Database Driver Class Initialized
INFO - 2020-09-18 10:24:29 --> Form Validation Class Initialized
DEBUG - 2020-09-18 10:24:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 10:24:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 10:24:29 --> Encryption Class Initialized
INFO - 2020-09-18 10:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:24:29 --> Controller Class Initialized
INFO - 2020-09-18 10:24:29 --> Helper loaded: language_helper
INFO - 2020-09-18 10:24:29 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 10:24:29 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 10:24:29 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 10:24:29 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\customer_care.php
INFO - 2020-09-18 10:24:29 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 10:24:29 --> Final output sent to browser
DEBUG - 2020-09-18 10:24:29 --> Total execution time: 1.1210
INFO - 2020-09-18 10:25:52 --> Config Class Initialized
INFO - 2020-09-18 10:25:52 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:25:52 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:25:52 --> Utf8 Class Initialized
INFO - 2020-09-18 10:25:52 --> URI Class Initialized
INFO - 2020-09-18 10:25:52 --> Router Class Initialized
INFO - 2020-09-18 10:25:52 --> Output Class Initialized
INFO - 2020-09-18 10:25:52 --> Security Class Initialized
DEBUG - 2020-09-18 10:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:25:52 --> Input Class Initialized
INFO - 2020-09-18 10:25:52 --> Language Class Initialized
INFO - 2020-09-18 10:25:52 --> Loader Class Initialized
INFO - 2020-09-18 10:25:52 --> Helper loaded: html_helper
INFO - 2020-09-18 10:25:52 --> Helper loaded: url_helper
INFO - 2020-09-18 10:25:52 --> Helper loaded: form_helper
INFO - 2020-09-18 10:25:52 --> Database Driver Class Initialized
INFO - 2020-09-18 10:25:52 --> Form Validation Class Initialized
DEBUG - 2020-09-18 10:25:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 10:25:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 10:25:52 --> Encryption Class Initialized
INFO - 2020-09-18 10:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:25:52 --> Controller Class Initialized
INFO - 2020-09-18 10:25:52 --> Helper loaded: language_helper
INFO - 2020-09-18 10:25:52 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 10:25:53 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 10:25:53 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 10:25:53 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\customer_care.php
INFO - 2020-09-18 10:25:53 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 10:25:53 --> Final output sent to browser
DEBUG - 2020-09-18 10:25:53 --> Total execution time: 1.0867
INFO - 2020-09-18 10:26:08 --> Config Class Initialized
INFO - 2020-09-18 10:26:08 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:26:09 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:26:09 --> Utf8 Class Initialized
INFO - 2020-09-18 10:26:09 --> URI Class Initialized
INFO - 2020-09-18 10:26:09 --> Router Class Initialized
INFO - 2020-09-18 10:26:09 --> Output Class Initialized
INFO - 2020-09-18 10:26:09 --> Security Class Initialized
DEBUG - 2020-09-18 10:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:26:09 --> Input Class Initialized
INFO - 2020-09-18 10:26:09 --> Language Class Initialized
INFO - 2020-09-18 10:26:09 --> Loader Class Initialized
INFO - 2020-09-18 10:26:09 --> Helper loaded: html_helper
INFO - 2020-09-18 10:26:09 --> Helper loaded: url_helper
INFO - 2020-09-18 10:26:09 --> Helper loaded: form_helper
INFO - 2020-09-18 10:26:09 --> Database Driver Class Initialized
INFO - 2020-09-18 10:26:09 --> Form Validation Class Initialized
DEBUG - 2020-09-18 10:26:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 10:26:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 10:26:09 --> Encryption Class Initialized
INFO - 2020-09-18 10:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:26:09 --> Controller Class Initialized
INFO - 2020-09-18 10:26:09 --> Helper loaded: language_helper
INFO - 2020-09-18 10:26:09 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 10:26:09 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 10:26:09 --> Final output sent to browser
DEBUG - 2020-09-18 10:26:09 --> Total execution time: 1.0348
INFO - 2020-09-18 10:39:29 --> Config Class Initialized
INFO - 2020-09-18 10:39:29 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:39:29 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:39:29 --> Utf8 Class Initialized
INFO - 2020-09-18 10:39:29 --> URI Class Initialized
INFO - 2020-09-18 10:39:29 --> Router Class Initialized
INFO - 2020-09-18 10:39:29 --> Output Class Initialized
INFO - 2020-09-18 10:39:29 --> Security Class Initialized
DEBUG - 2020-09-18 10:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:39:29 --> Input Class Initialized
INFO - 2020-09-18 10:39:29 --> Language Class Initialized
INFO - 2020-09-18 10:39:30 --> Loader Class Initialized
INFO - 2020-09-18 10:39:30 --> Helper loaded: html_helper
INFO - 2020-09-18 10:39:30 --> Helper loaded: url_helper
INFO - 2020-09-18 10:39:30 --> Helper loaded: form_helper
INFO - 2020-09-18 10:39:30 --> Database Driver Class Initialized
INFO - 2020-09-18 10:39:30 --> Form Validation Class Initialized
DEBUG - 2020-09-18 10:39:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 10:39:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 10:39:30 --> Encryption Class Initialized
INFO - 2020-09-18 10:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:39:30 --> Controller Class Initialized
INFO - 2020-09-18 10:39:30 --> Helper loaded: language_helper
INFO - 2020-09-18 10:39:30 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 10:39:30 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 10:39:30 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 10:39:30 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\customer_care.php
INFO - 2020-09-18 10:39:30 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 10:39:30 --> Final output sent to browser
DEBUG - 2020-09-18 10:39:31 --> Total execution time: 1.5823
INFO - 2020-09-18 10:39:53 --> Config Class Initialized
INFO - 2020-09-18 10:39:53 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:39:53 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:39:53 --> Utf8 Class Initialized
INFO - 2020-09-18 10:39:53 --> URI Class Initialized
INFO - 2020-09-18 10:39:53 --> Router Class Initialized
INFO - 2020-09-18 10:39:53 --> Output Class Initialized
INFO - 2020-09-18 10:39:53 --> Security Class Initialized
DEBUG - 2020-09-18 10:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:39:53 --> Input Class Initialized
INFO - 2020-09-18 10:39:53 --> Language Class Initialized
INFO - 2020-09-18 10:39:53 --> Loader Class Initialized
INFO - 2020-09-18 10:39:53 --> Helper loaded: html_helper
INFO - 2020-09-18 10:39:54 --> Helper loaded: url_helper
INFO - 2020-09-18 10:39:54 --> Helper loaded: form_helper
INFO - 2020-09-18 10:39:54 --> Database Driver Class Initialized
INFO - 2020-09-18 10:39:54 --> Form Validation Class Initialized
DEBUG - 2020-09-18 10:39:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 10:39:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 10:39:54 --> Encryption Class Initialized
INFO - 2020-09-18 10:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:39:54 --> Controller Class Initialized
INFO - 2020-09-18 10:39:54 --> Helper loaded: language_helper
INFO - 2020-09-18 10:39:54 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 10:39:54 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 10:39:54 --> Final output sent to browser
DEBUG - 2020-09-18 10:39:54 --> Total execution time: 1.0741
INFO - 2020-09-18 10:40:18 --> Config Class Initialized
INFO - 2020-09-18 10:40:18 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:40:18 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:40:18 --> Utf8 Class Initialized
INFO - 2020-09-18 10:40:18 --> URI Class Initialized
INFO - 2020-09-18 10:40:18 --> Router Class Initialized
INFO - 2020-09-18 10:40:18 --> Output Class Initialized
INFO - 2020-09-18 10:40:18 --> Security Class Initialized
DEBUG - 2020-09-18 10:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:40:18 --> Input Class Initialized
INFO - 2020-09-18 10:40:18 --> Language Class Initialized
INFO - 2020-09-18 10:40:18 --> Loader Class Initialized
INFO - 2020-09-18 10:40:18 --> Helper loaded: html_helper
INFO - 2020-09-18 10:40:18 --> Helper loaded: url_helper
INFO - 2020-09-18 10:40:18 --> Helper loaded: form_helper
INFO - 2020-09-18 10:40:18 --> Database Driver Class Initialized
INFO - 2020-09-18 10:40:18 --> Form Validation Class Initialized
DEBUG - 2020-09-18 10:40:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 10:40:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 10:40:18 --> Encryption Class Initialized
INFO - 2020-09-18 10:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:40:18 --> Controller Class Initialized
INFO - 2020-09-18 10:40:18 --> Helper loaded: language_helper
INFO - 2020-09-18 10:40:19 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 10:40:19 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 10:40:19 --> Final output sent to browser
DEBUG - 2020-09-18 10:40:19 --> Total execution time: 1.0436
INFO - 2020-09-18 10:40:33 --> Config Class Initialized
INFO - 2020-09-18 10:40:33 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:40:33 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:40:34 --> Utf8 Class Initialized
INFO - 2020-09-18 10:40:34 --> URI Class Initialized
INFO - 2020-09-18 10:40:34 --> Router Class Initialized
INFO - 2020-09-18 10:40:34 --> Output Class Initialized
INFO - 2020-09-18 10:40:34 --> Security Class Initialized
DEBUG - 2020-09-18 10:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:40:34 --> Input Class Initialized
INFO - 2020-09-18 10:40:34 --> Language Class Initialized
INFO - 2020-09-18 10:40:34 --> Loader Class Initialized
INFO - 2020-09-18 10:40:34 --> Helper loaded: html_helper
INFO - 2020-09-18 10:40:34 --> Helper loaded: url_helper
INFO - 2020-09-18 10:40:34 --> Helper loaded: form_helper
INFO - 2020-09-18 10:40:34 --> Database Driver Class Initialized
INFO - 2020-09-18 10:40:34 --> Form Validation Class Initialized
DEBUG - 2020-09-18 10:40:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 10:40:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 10:40:34 --> Encryption Class Initialized
INFO - 2020-09-18 10:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:40:34 --> Controller Class Initialized
INFO - 2020-09-18 10:40:34 --> Helper loaded: language_helper
INFO - 2020-09-18 10:40:34 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 10:40:34 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 10:40:34 --> Final output sent to browser
DEBUG - 2020-09-18 10:40:34 --> Total execution time: 1.0224
INFO - 2020-09-18 10:40:42 --> Config Class Initialized
INFO - 2020-09-18 10:40:42 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:40:42 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:40:42 --> Utf8 Class Initialized
INFO - 2020-09-18 10:40:42 --> URI Class Initialized
INFO - 2020-09-18 10:40:42 --> Router Class Initialized
INFO - 2020-09-18 10:40:42 --> Output Class Initialized
INFO - 2020-09-18 10:40:42 --> Security Class Initialized
DEBUG - 2020-09-18 10:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:40:42 --> Input Class Initialized
INFO - 2020-09-18 10:40:42 --> Language Class Initialized
INFO - 2020-09-18 10:40:42 --> Loader Class Initialized
INFO - 2020-09-18 10:40:42 --> Helper loaded: html_helper
INFO - 2020-09-18 10:40:42 --> Helper loaded: url_helper
INFO - 2020-09-18 10:40:42 --> Helper loaded: form_helper
INFO - 2020-09-18 10:40:42 --> Database Driver Class Initialized
INFO - 2020-09-18 10:40:42 --> Form Validation Class Initialized
DEBUG - 2020-09-18 10:40:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 10:40:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 10:40:43 --> Encryption Class Initialized
INFO - 2020-09-18 10:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:40:43 --> Controller Class Initialized
INFO - 2020-09-18 10:40:43 --> Helper loaded: language_helper
INFO - 2020-09-18 10:40:43 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 10:40:43 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 10:40:43 --> Final output sent to browser
DEBUG - 2020-09-18 10:40:43 --> Total execution time: 1.0714
INFO - 2020-09-18 10:40:54 --> Config Class Initialized
INFO - 2020-09-18 10:40:54 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:40:54 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:40:54 --> Utf8 Class Initialized
INFO - 2020-09-18 10:40:54 --> URI Class Initialized
INFO - 2020-09-18 10:40:54 --> Router Class Initialized
INFO - 2020-09-18 10:40:54 --> Output Class Initialized
INFO - 2020-09-18 10:40:54 --> Security Class Initialized
DEBUG - 2020-09-18 10:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:40:54 --> Input Class Initialized
INFO - 2020-09-18 10:40:54 --> Language Class Initialized
INFO - 2020-09-18 10:40:54 --> Loader Class Initialized
INFO - 2020-09-18 10:40:54 --> Helper loaded: html_helper
INFO - 2020-09-18 10:40:55 --> Helper loaded: url_helper
INFO - 2020-09-18 10:40:55 --> Helper loaded: form_helper
INFO - 2020-09-18 10:40:55 --> Database Driver Class Initialized
INFO - 2020-09-18 10:40:55 --> Form Validation Class Initialized
DEBUG - 2020-09-18 10:40:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 10:40:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 10:40:55 --> Encryption Class Initialized
INFO - 2020-09-18 10:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:40:55 --> Controller Class Initialized
INFO - 2020-09-18 10:40:55 --> Helper loaded: language_helper
INFO - 2020-09-18 10:40:55 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 10:40:55 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 10:40:55 --> Final output sent to browser
DEBUG - 2020-09-18 10:40:55 --> Total execution time: 1.0552
INFO - 2020-09-18 10:41:00 --> Config Class Initialized
INFO - 2020-09-18 10:41:00 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:41:00 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:41:00 --> Utf8 Class Initialized
INFO - 2020-09-18 10:41:00 --> URI Class Initialized
INFO - 2020-09-18 10:41:00 --> Router Class Initialized
INFO - 2020-09-18 10:41:00 --> Output Class Initialized
INFO - 2020-09-18 10:41:00 --> Security Class Initialized
DEBUG - 2020-09-18 10:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:41:00 --> Input Class Initialized
INFO - 2020-09-18 10:41:00 --> Language Class Initialized
INFO - 2020-09-18 10:41:00 --> Loader Class Initialized
INFO - 2020-09-18 10:41:00 --> Helper loaded: html_helper
INFO - 2020-09-18 10:41:00 --> Helper loaded: url_helper
INFO - 2020-09-18 10:41:00 --> Helper loaded: form_helper
INFO - 2020-09-18 10:41:00 --> Database Driver Class Initialized
INFO - 2020-09-18 10:41:00 --> Form Validation Class Initialized
DEBUG - 2020-09-18 10:41:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 10:41:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 10:41:00 --> Encryption Class Initialized
INFO - 2020-09-18 10:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:41:01 --> Controller Class Initialized
INFO - 2020-09-18 10:41:01 --> Helper loaded: language_helper
INFO - 2020-09-18 10:41:01 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 10:41:01 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 10:41:01 --> Final output sent to browser
DEBUG - 2020-09-18 10:41:01 --> Total execution time: 1.0297
INFO - 2020-09-18 10:41:31 --> Config Class Initialized
INFO - 2020-09-18 10:41:31 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:41:31 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:41:31 --> Utf8 Class Initialized
INFO - 2020-09-18 10:41:31 --> URI Class Initialized
INFO - 2020-09-18 10:41:32 --> Router Class Initialized
INFO - 2020-09-18 10:41:32 --> Output Class Initialized
INFO - 2020-09-18 10:41:32 --> Security Class Initialized
DEBUG - 2020-09-18 10:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:41:32 --> Input Class Initialized
INFO - 2020-09-18 10:41:32 --> Language Class Initialized
INFO - 2020-09-18 10:41:32 --> Loader Class Initialized
INFO - 2020-09-18 10:41:32 --> Helper loaded: html_helper
INFO - 2020-09-18 10:41:32 --> Helper loaded: url_helper
INFO - 2020-09-18 10:41:32 --> Helper loaded: form_helper
INFO - 2020-09-18 10:41:32 --> Database Driver Class Initialized
INFO - 2020-09-18 10:41:32 --> Form Validation Class Initialized
DEBUG - 2020-09-18 10:41:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 10:41:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 10:41:32 --> Encryption Class Initialized
INFO - 2020-09-18 10:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:41:32 --> Controller Class Initialized
INFO - 2020-09-18 10:41:32 --> Helper loaded: language_helper
INFO - 2020-09-18 10:41:32 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 10:41:32 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 10:41:32 --> Final output sent to browser
DEBUG - 2020-09-18 10:41:32 --> Total execution time: 1.0872
INFO - 2020-09-18 10:41:47 --> Config Class Initialized
INFO - 2020-09-18 10:41:47 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:41:47 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:41:47 --> Utf8 Class Initialized
INFO - 2020-09-18 10:41:47 --> URI Class Initialized
INFO - 2020-09-18 10:41:47 --> Router Class Initialized
INFO - 2020-09-18 10:41:47 --> Output Class Initialized
INFO - 2020-09-18 10:41:47 --> Security Class Initialized
DEBUG - 2020-09-18 10:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:41:47 --> Input Class Initialized
INFO - 2020-09-18 10:41:47 --> Language Class Initialized
INFO - 2020-09-18 10:41:47 --> Loader Class Initialized
INFO - 2020-09-18 10:41:47 --> Helper loaded: html_helper
INFO - 2020-09-18 10:41:47 --> Helper loaded: url_helper
INFO - 2020-09-18 10:41:47 --> Helper loaded: form_helper
INFO - 2020-09-18 10:41:47 --> Database Driver Class Initialized
INFO - 2020-09-18 10:41:47 --> Form Validation Class Initialized
DEBUG - 2020-09-18 10:41:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 10:41:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 10:41:48 --> Encryption Class Initialized
INFO - 2020-09-18 10:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:41:48 --> Controller Class Initialized
INFO - 2020-09-18 10:41:48 --> Helper loaded: language_helper
INFO - 2020-09-18 10:41:48 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 10:41:48 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 10:41:48 --> Final output sent to browser
DEBUG - 2020-09-18 10:41:48 --> Total execution time: 1.0110
INFO - 2020-09-18 10:41:53 --> Config Class Initialized
INFO - 2020-09-18 10:41:53 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:41:53 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:41:53 --> Utf8 Class Initialized
INFO - 2020-09-18 10:41:53 --> URI Class Initialized
INFO - 2020-09-18 10:41:53 --> Router Class Initialized
INFO - 2020-09-18 10:41:53 --> Output Class Initialized
INFO - 2020-09-18 10:41:53 --> Security Class Initialized
DEBUG - 2020-09-18 10:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:41:53 --> Input Class Initialized
INFO - 2020-09-18 10:41:53 --> Language Class Initialized
INFO - 2020-09-18 10:41:53 --> Loader Class Initialized
INFO - 2020-09-18 10:41:53 --> Helper loaded: html_helper
INFO - 2020-09-18 10:41:53 --> Helper loaded: url_helper
INFO - 2020-09-18 10:41:53 --> Helper loaded: form_helper
INFO - 2020-09-18 10:41:53 --> Database Driver Class Initialized
INFO - 2020-09-18 10:41:53 --> Form Validation Class Initialized
DEBUG - 2020-09-18 10:41:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 10:41:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 10:41:53 --> Encryption Class Initialized
INFO - 2020-09-18 10:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:41:53 --> Controller Class Initialized
INFO - 2020-09-18 10:41:53 --> Helper loaded: language_helper
INFO - 2020-09-18 10:41:53 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 10:41:54 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 10:41:54 --> Final output sent to browser
DEBUG - 2020-09-18 10:41:54 --> Total execution time: 1.0110
INFO - 2020-09-18 12:00:05 --> Config Class Initialized
INFO - 2020-09-18 12:00:05 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:00:05 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:00:05 --> Utf8 Class Initialized
INFO - 2020-09-18 12:00:05 --> URI Class Initialized
INFO - 2020-09-18 12:00:05 --> Router Class Initialized
INFO - 2020-09-18 12:00:06 --> Output Class Initialized
INFO - 2020-09-18 12:00:06 --> Security Class Initialized
DEBUG - 2020-09-18 12:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:00:06 --> Input Class Initialized
INFO - 2020-09-18 12:00:06 --> Language Class Initialized
INFO - 2020-09-18 12:00:06 --> Loader Class Initialized
INFO - 2020-09-18 12:00:06 --> Helper loaded: html_helper
INFO - 2020-09-18 12:00:06 --> Helper loaded: url_helper
INFO - 2020-09-18 12:00:06 --> Helper loaded: form_helper
INFO - 2020-09-18 12:00:06 --> Database Driver Class Initialized
INFO - 2020-09-18 12:00:07 --> Form Validation Class Initialized
DEBUG - 2020-09-18 12:00:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 12:00:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 12:00:07 --> Encryption Class Initialized
INFO - 2020-09-18 12:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:00:07 --> Controller Class Initialized
INFO - 2020-09-18 12:00:07 --> Helper loaded: language_helper
INFO - 2020-09-18 12:00:07 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 12:00:07 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 12:00:07 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 12:00:08 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\customer_care.php
INFO - 2020-09-18 12:00:08 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 12:00:08 --> Final output sent to browser
DEBUG - 2020-09-18 12:00:08 --> Total execution time: 2.9744
INFO - 2020-09-18 12:00:19 --> Config Class Initialized
INFO - 2020-09-18 12:00:19 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:00:19 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:00:19 --> Utf8 Class Initialized
INFO - 2020-09-18 12:00:19 --> URI Class Initialized
INFO - 2020-09-18 12:00:19 --> Router Class Initialized
INFO - 2020-09-18 12:00:19 --> Output Class Initialized
INFO - 2020-09-18 12:00:19 --> Security Class Initialized
DEBUG - 2020-09-18 12:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:00:20 --> Input Class Initialized
INFO - 2020-09-18 12:00:20 --> Language Class Initialized
INFO - 2020-09-18 12:00:20 --> Loader Class Initialized
INFO - 2020-09-18 12:00:20 --> Helper loaded: html_helper
INFO - 2020-09-18 12:00:20 --> Helper loaded: url_helper
INFO - 2020-09-18 12:00:20 --> Helper loaded: form_helper
INFO - 2020-09-18 12:00:20 --> Database Driver Class Initialized
INFO - 2020-09-18 12:00:20 --> Form Validation Class Initialized
DEBUG - 2020-09-18 12:00:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 12:00:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 12:00:20 --> Encryption Class Initialized
INFO - 2020-09-18 12:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:00:20 --> Controller Class Initialized
INFO - 2020-09-18 12:00:20 --> Helper loaded: language_helper
INFO - 2020-09-18 12:00:20 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 12:00:20 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 12:00:20 --> Final output sent to browser
DEBUG - 2020-09-18 12:00:21 --> Total execution time: 1.3519
INFO - 2020-09-18 12:00:29 --> Config Class Initialized
INFO - 2020-09-18 12:00:30 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:00:30 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:00:30 --> Utf8 Class Initialized
INFO - 2020-09-18 12:00:30 --> URI Class Initialized
INFO - 2020-09-18 12:00:30 --> Router Class Initialized
INFO - 2020-09-18 12:00:30 --> Output Class Initialized
INFO - 2020-09-18 12:00:30 --> Security Class Initialized
DEBUG - 2020-09-18 12:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:00:30 --> Input Class Initialized
INFO - 2020-09-18 12:00:30 --> Language Class Initialized
INFO - 2020-09-18 12:00:30 --> Loader Class Initialized
INFO - 2020-09-18 12:00:30 --> Helper loaded: html_helper
INFO - 2020-09-18 12:00:30 --> Helper loaded: url_helper
INFO - 2020-09-18 12:00:30 --> Helper loaded: form_helper
INFO - 2020-09-18 12:00:30 --> Database Driver Class Initialized
INFO - 2020-09-18 12:00:30 --> Form Validation Class Initialized
DEBUG - 2020-09-18 12:00:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 12:00:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 12:00:30 --> Encryption Class Initialized
INFO - 2020-09-18 12:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:00:30 --> Controller Class Initialized
INFO - 2020-09-18 12:00:30 --> Helper loaded: language_helper
INFO - 2020-09-18 12:00:30 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 12:00:30 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 12:00:30 --> Final output sent to browser
DEBUG - 2020-09-18 12:00:30 --> Total execution time: 1.0097
INFO - 2020-09-18 12:00:34 --> Config Class Initialized
INFO - 2020-09-18 12:00:34 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:00:34 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:00:34 --> Utf8 Class Initialized
INFO - 2020-09-18 12:00:34 --> URI Class Initialized
INFO - 2020-09-18 12:00:34 --> Router Class Initialized
INFO - 2020-09-18 12:00:34 --> Output Class Initialized
INFO - 2020-09-18 12:00:34 --> Security Class Initialized
DEBUG - 2020-09-18 12:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:00:34 --> Input Class Initialized
INFO - 2020-09-18 12:00:34 --> Language Class Initialized
INFO - 2020-09-18 12:00:34 --> Loader Class Initialized
INFO - 2020-09-18 12:00:34 --> Helper loaded: html_helper
INFO - 2020-09-18 12:00:34 --> Helper loaded: url_helper
INFO - 2020-09-18 12:00:35 --> Helper loaded: form_helper
INFO - 2020-09-18 12:00:35 --> Database Driver Class Initialized
INFO - 2020-09-18 12:00:35 --> Form Validation Class Initialized
DEBUG - 2020-09-18 12:00:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 12:00:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 12:00:35 --> Encryption Class Initialized
INFO - 2020-09-18 12:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:00:35 --> Controller Class Initialized
INFO - 2020-09-18 12:00:35 --> Helper loaded: language_helper
INFO - 2020-09-18 12:00:35 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 12:00:35 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 12:00:35 --> Final output sent to browser
DEBUG - 2020-09-18 12:00:35 --> Total execution time: 1.0336
INFO - 2020-09-18 12:00:40 --> Config Class Initialized
INFO - 2020-09-18 12:00:40 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:00:40 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:00:40 --> Utf8 Class Initialized
INFO - 2020-09-18 12:00:40 --> URI Class Initialized
INFO - 2020-09-18 12:00:40 --> Router Class Initialized
INFO - 2020-09-18 12:00:40 --> Output Class Initialized
INFO - 2020-09-18 12:00:40 --> Security Class Initialized
DEBUG - 2020-09-18 12:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:00:40 --> Input Class Initialized
INFO - 2020-09-18 12:00:40 --> Language Class Initialized
INFO - 2020-09-18 12:00:40 --> Loader Class Initialized
INFO - 2020-09-18 12:00:40 --> Helper loaded: html_helper
INFO - 2020-09-18 12:00:40 --> Helper loaded: url_helper
INFO - 2020-09-18 12:00:40 --> Helper loaded: form_helper
INFO - 2020-09-18 12:00:40 --> Database Driver Class Initialized
INFO - 2020-09-18 12:00:40 --> Form Validation Class Initialized
DEBUG - 2020-09-18 12:00:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 12:00:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 12:00:40 --> Encryption Class Initialized
INFO - 2020-09-18 12:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:00:41 --> Controller Class Initialized
INFO - 2020-09-18 12:00:41 --> Helper loaded: language_helper
INFO - 2020-09-18 12:00:41 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 12:00:41 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 12:00:41 --> Final output sent to browser
DEBUG - 2020-09-18 12:00:41 --> Total execution time: 1.0740
INFO - 2020-09-18 12:00:45 --> Config Class Initialized
INFO - 2020-09-18 12:00:45 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:00:45 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:00:46 --> Utf8 Class Initialized
INFO - 2020-09-18 12:00:46 --> URI Class Initialized
INFO - 2020-09-18 12:00:46 --> Router Class Initialized
INFO - 2020-09-18 12:00:46 --> Output Class Initialized
INFO - 2020-09-18 12:00:46 --> Security Class Initialized
DEBUG - 2020-09-18 12:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:00:46 --> Input Class Initialized
INFO - 2020-09-18 12:00:46 --> Language Class Initialized
INFO - 2020-09-18 12:00:46 --> Loader Class Initialized
INFO - 2020-09-18 12:00:46 --> Helper loaded: html_helper
INFO - 2020-09-18 12:00:46 --> Helper loaded: url_helper
INFO - 2020-09-18 12:00:46 --> Helper loaded: form_helper
INFO - 2020-09-18 12:00:46 --> Database Driver Class Initialized
INFO - 2020-09-18 12:00:46 --> Form Validation Class Initialized
DEBUG - 2020-09-18 12:00:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 12:00:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 12:00:46 --> Encryption Class Initialized
INFO - 2020-09-18 12:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:00:46 --> Controller Class Initialized
INFO - 2020-09-18 12:00:46 --> Helper loaded: language_helper
INFO - 2020-09-18 12:00:46 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 12:00:46 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 12:00:46 --> Final output sent to browser
DEBUG - 2020-09-18 12:00:46 --> Total execution time: 1.0771
INFO - 2020-09-18 12:06:47 --> Config Class Initialized
INFO - 2020-09-18 12:06:47 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:06:47 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:06:47 --> Utf8 Class Initialized
INFO - 2020-09-18 12:06:47 --> URI Class Initialized
INFO - 2020-09-18 12:06:47 --> Router Class Initialized
INFO - 2020-09-18 12:06:47 --> Output Class Initialized
INFO - 2020-09-18 12:06:48 --> Security Class Initialized
DEBUG - 2020-09-18 12:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:06:48 --> Input Class Initialized
INFO - 2020-09-18 12:06:48 --> Language Class Initialized
INFO - 2020-09-18 12:06:48 --> Loader Class Initialized
INFO - 2020-09-18 12:06:48 --> Helper loaded: html_helper
INFO - 2020-09-18 12:06:48 --> Helper loaded: url_helper
INFO - 2020-09-18 12:06:48 --> Helper loaded: form_helper
INFO - 2020-09-18 12:06:48 --> Database Driver Class Initialized
INFO - 2020-09-18 12:06:48 --> Form Validation Class Initialized
DEBUG - 2020-09-18 12:06:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 12:06:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 12:06:48 --> Encryption Class Initialized
INFO - 2020-09-18 12:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:06:48 --> Controller Class Initialized
INFO - 2020-09-18 12:06:48 --> Helper loaded: language_helper
INFO - 2020-09-18 12:06:48 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 12:06:48 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 12:06:48 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 12:06:48 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\customer_care.php
INFO - 2020-09-18 12:06:48 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 12:06:48 --> Final output sent to browser
DEBUG - 2020-09-18 12:06:48 --> Total execution time: 1.2401
INFO - 2020-09-18 12:07:00 --> Config Class Initialized
INFO - 2020-09-18 12:07:00 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:07:00 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:07:00 --> Utf8 Class Initialized
INFO - 2020-09-18 12:07:00 --> URI Class Initialized
INFO - 2020-09-18 12:07:00 --> Router Class Initialized
INFO - 2020-09-18 12:07:00 --> Output Class Initialized
INFO - 2020-09-18 12:07:00 --> Security Class Initialized
DEBUG - 2020-09-18 12:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:07:00 --> Input Class Initialized
INFO - 2020-09-18 12:07:00 --> Language Class Initialized
INFO - 2020-09-18 12:07:00 --> Loader Class Initialized
INFO - 2020-09-18 12:07:00 --> Helper loaded: html_helper
INFO - 2020-09-18 12:07:00 --> Helper loaded: url_helper
INFO - 2020-09-18 12:07:00 --> Helper loaded: form_helper
INFO - 2020-09-18 12:07:00 --> Database Driver Class Initialized
INFO - 2020-09-18 12:07:00 --> Form Validation Class Initialized
DEBUG - 2020-09-18 12:07:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 12:07:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 12:07:01 --> Encryption Class Initialized
INFO - 2020-09-18 12:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:07:01 --> Controller Class Initialized
INFO - 2020-09-18 12:07:01 --> Helper loaded: language_helper
INFO - 2020-09-18 12:07:01 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 12:07:01 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 12:07:01 --> Final output sent to browser
DEBUG - 2020-09-18 12:07:01 --> Total execution time: 1.0620
INFO - 2020-09-18 12:08:02 --> Config Class Initialized
INFO - 2020-09-18 12:08:02 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:08:02 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:08:02 --> Utf8 Class Initialized
INFO - 2020-09-18 12:08:02 --> URI Class Initialized
INFO - 2020-09-18 12:08:02 --> Router Class Initialized
INFO - 2020-09-18 12:08:02 --> Output Class Initialized
INFO - 2020-09-18 12:08:03 --> Security Class Initialized
DEBUG - 2020-09-18 12:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:08:03 --> Input Class Initialized
INFO - 2020-09-18 12:08:03 --> Language Class Initialized
INFO - 2020-09-18 12:08:03 --> Loader Class Initialized
INFO - 2020-09-18 12:08:03 --> Helper loaded: html_helper
INFO - 2020-09-18 12:08:03 --> Helper loaded: url_helper
INFO - 2020-09-18 12:08:03 --> Helper loaded: form_helper
INFO - 2020-09-18 12:08:03 --> Database Driver Class Initialized
INFO - 2020-09-18 12:08:03 --> Form Validation Class Initialized
DEBUG - 2020-09-18 12:08:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 12:08:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 12:08:03 --> Encryption Class Initialized
INFO - 2020-09-18 12:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:08:03 --> Controller Class Initialized
INFO - 2020-09-18 12:08:03 --> Helper loaded: language_helper
INFO - 2020-09-18 12:08:03 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 12:08:03 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 12:08:03 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 12:08:03 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\customer_care.php
INFO - 2020-09-18 12:08:03 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 12:08:03 --> Final output sent to browser
DEBUG - 2020-09-18 12:08:03 --> Total execution time: 1.1714
INFO - 2020-09-18 12:08:17 --> Config Class Initialized
INFO - 2020-09-18 12:08:17 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:08:17 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:08:17 --> Utf8 Class Initialized
INFO - 2020-09-18 12:08:17 --> URI Class Initialized
INFO - 2020-09-18 12:08:17 --> Router Class Initialized
INFO - 2020-09-18 12:08:17 --> Output Class Initialized
INFO - 2020-09-18 12:08:17 --> Security Class Initialized
DEBUG - 2020-09-18 12:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:08:17 --> Input Class Initialized
INFO - 2020-09-18 12:08:17 --> Language Class Initialized
INFO - 2020-09-18 12:08:17 --> Loader Class Initialized
INFO - 2020-09-18 12:08:17 --> Helper loaded: html_helper
INFO - 2020-09-18 12:08:17 --> Helper loaded: url_helper
INFO - 2020-09-18 12:08:17 --> Helper loaded: form_helper
INFO - 2020-09-18 12:08:17 --> Database Driver Class Initialized
INFO - 2020-09-18 12:08:17 --> Form Validation Class Initialized
DEBUG - 2020-09-18 12:08:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 12:08:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 12:08:18 --> Encryption Class Initialized
INFO - 2020-09-18 12:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:08:18 --> Controller Class Initialized
INFO - 2020-09-18 12:08:18 --> Helper loaded: language_helper
INFO - 2020-09-18 12:08:18 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 12:08:18 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 12:08:18 --> Final output sent to browser
DEBUG - 2020-09-18 12:08:18 --> Total execution time: 1.0779
INFO - 2020-09-18 12:15:42 --> Config Class Initialized
INFO - 2020-09-18 12:15:42 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:15:42 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:15:42 --> Utf8 Class Initialized
INFO - 2020-09-18 12:15:42 --> URI Class Initialized
INFO - 2020-09-18 12:15:42 --> Router Class Initialized
INFO - 2020-09-18 12:15:42 --> Output Class Initialized
INFO - 2020-09-18 12:15:42 --> Security Class Initialized
DEBUG - 2020-09-18 12:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:15:42 --> Input Class Initialized
INFO - 2020-09-18 12:15:42 --> Language Class Initialized
INFO - 2020-09-18 12:15:42 --> Loader Class Initialized
INFO - 2020-09-18 12:15:43 --> Helper loaded: html_helper
INFO - 2020-09-18 12:15:43 --> Helper loaded: url_helper
INFO - 2020-09-18 12:15:43 --> Helper loaded: form_helper
INFO - 2020-09-18 12:15:43 --> Database Driver Class Initialized
INFO - 2020-09-18 12:15:43 --> Form Validation Class Initialized
DEBUG - 2020-09-18 12:15:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 12:15:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 12:15:43 --> Encryption Class Initialized
INFO - 2020-09-18 12:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:15:43 --> Controller Class Initialized
INFO - 2020-09-18 12:15:43 --> Helper loaded: language_helper
INFO - 2020-09-18 12:15:43 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 12:15:43 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 12:15:43 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 12:15:43 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\customer_care.php
INFO - 2020-09-18 12:15:43 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 12:15:43 --> Final output sent to browser
DEBUG - 2020-09-18 12:15:43 --> Total execution time: 1.2930
INFO - 2020-09-18 12:15:55 --> Config Class Initialized
INFO - 2020-09-18 12:15:55 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:15:55 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:15:56 --> Utf8 Class Initialized
INFO - 2020-09-18 12:15:56 --> URI Class Initialized
INFO - 2020-09-18 12:15:56 --> Router Class Initialized
INFO - 2020-09-18 12:15:56 --> Output Class Initialized
INFO - 2020-09-18 12:15:56 --> Security Class Initialized
DEBUG - 2020-09-18 12:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:15:56 --> Input Class Initialized
INFO - 2020-09-18 12:15:56 --> Language Class Initialized
INFO - 2020-09-18 12:15:56 --> Loader Class Initialized
INFO - 2020-09-18 12:15:56 --> Helper loaded: html_helper
INFO - 2020-09-18 12:15:56 --> Helper loaded: url_helper
INFO - 2020-09-18 12:15:56 --> Helper loaded: form_helper
INFO - 2020-09-18 12:15:56 --> Database Driver Class Initialized
INFO - 2020-09-18 12:15:56 --> Form Validation Class Initialized
DEBUG - 2020-09-18 12:15:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 12:15:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 12:15:56 --> Encryption Class Initialized
INFO - 2020-09-18 12:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:15:56 --> Controller Class Initialized
INFO - 2020-09-18 12:15:56 --> Helper loaded: language_helper
INFO - 2020-09-18 12:15:56 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 12:15:56 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 12:15:57 --> Final output sent to browser
DEBUG - 2020-09-18 12:15:57 --> Total execution time: 1.1446
INFO - 2020-09-18 12:19:20 --> Config Class Initialized
INFO - 2020-09-18 12:19:20 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:19:20 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:19:20 --> Utf8 Class Initialized
INFO - 2020-09-18 12:19:20 --> URI Class Initialized
INFO - 2020-09-18 12:19:20 --> Router Class Initialized
INFO - 2020-09-18 12:19:20 --> Output Class Initialized
INFO - 2020-09-18 12:19:20 --> Security Class Initialized
DEBUG - 2020-09-18 12:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:19:20 --> Input Class Initialized
INFO - 2020-09-18 12:19:20 --> Language Class Initialized
INFO - 2020-09-18 12:19:20 --> Loader Class Initialized
INFO - 2020-09-18 12:19:20 --> Helper loaded: html_helper
INFO - 2020-09-18 12:19:20 --> Helper loaded: url_helper
INFO - 2020-09-18 12:19:20 --> Helper loaded: form_helper
INFO - 2020-09-18 12:19:20 --> Database Driver Class Initialized
INFO - 2020-09-18 12:19:20 --> Form Validation Class Initialized
DEBUG - 2020-09-18 12:19:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 12:19:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 12:19:21 --> Encryption Class Initialized
INFO - 2020-09-18 12:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:19:21 --> Controller Class Initialized
INFO - 2020-09-18 12:19:21 --> Helper loaded: language_helper
INFO - 2020-09-18 12:19:21 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 12:19:21 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 12:19:21 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 12:19:21 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\customer_care.php
INFO - 2020-09-18 12:19:21 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 12:19:21 --> Final output sent to browser
DEBUG - 2020-09-18 12:19:21 --> Total execution time: 1.2441
INFO - 2020-09-18 12:19:32 --> Config Class Initialized
INFO - 2020-09-18 12:19:32 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:19:32 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:19:32 --> Utf8 Class Initialized
INFO - 2020-09-18 12:19:32 --> URI Class Initialized
INFO - 2020-09-18 12:19:32 --> Router Class Initialized
INFO - 2020-09-18 12:19:32 --> Output Class Initialized
INFO - 2020-09-18 12:19:32 --> Security Class Initialized
DEBUG - 2020-09-18 12:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:19:33 --> Input Class Initialized
INFO - 2020-09-18 12:19:33 --> Language Class Initialized
INFO - 2020-09-18 12:19:33 --> Loader Class Initialized
INFO - 2020-09-18 12:19:33 --> Helper loaded: html_helper
INFO - 2020-09-18 12:19:33 --> Helper loaded: url_helper
INFO - 2020-09-18 12:19:33 --> Helper loaded: form_helper
INFO - 2020-09-18 12:19:33 --> Database Driver Class Initialized
INFO - 2020-09-18 12:19:33 --> Form Validation Class Initialized
DEBUG - 2020-09-18 12:19:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 12:19:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 12:19:33 --> Encryption Class Initialized
INFO - 2020-09-18 12:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:19:33 --> Controller Class Initialized
INFO - 2020-09-18 12:19:33 --> Helper loaded: language_helper
INFO - 2020-09-18 12:19:33 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 12:19:33 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 12:19:33 --> Final output sent to browser
DEBUG - 2020-09-18 12:19:33 --> Total execution time: 1.0765
INFO - 2020-09-18 12:24:41 --> Config Class Initialized
INFO - 2020-09-18 12:24:41 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:24:42 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:24:42 --> Utf8 Class Initialized
INFO - 2020-09-18 12:24:42 --> URI Class Initialized
INFO - 2020-09-18 12:24:42 --> Router Class Initialized
INFO - 2020-09-18 12:24:42 --> Output Class Initialized
INFO - 2020-09-18 12:24:42 --> Security Class Initialized
DEBUG - 2020-09-18 12:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:24:42 --> Input Class Initialized
INFO - 2020-09-18 12:24:42 --> Language Class Initialized
INFO - 2020-09-18 12:24:42 --> Loader Class Initialized
INFO - 2020-09-18 12:24:42 --> Helper loaded: html_helper
INFO - 2020-09-18 12:24:42 --> Helper loaded: url_helper
INFO - 2020-09-18 12:24:42 --> Helper loaded: form_helper
INFO - 2020-09-18 12:24:42 --> Database Driver Class Initialized
INFO - 2020-09-18 12:24:42 --> Form Validation Class Initialized
DEBUG - 2020-09-18 12:24:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 12:24:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 12:24:42 --> Encryption Class Initialized
INFO - 2020-09-18 12:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:24:42 --> Controller Class Initialized
INFO - 2020-09-18 12:24:42 --> Helper loaded: language_helper
INFO - 2020-09-18 12:24:42 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 12:24:42 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 12:24:43 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 12:24:43 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\customer_care.php
INFO - 2020-09-18 12:24:43 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 12:24:43 --> Final output sent to browser
DEBUG - 2020-09-18 12:24:43 --> Total execution time: 1.2034
INFO - 2020-09-18 12:24:46 --> Config Class Initialized
INFO - 2020-09-18 12:24:46 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:24:46 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:24:46 --> Utf8 Class Initialized
INFO - 2020-09-18 12:24:47 --> URI Class Initialized
INFO - 2020-09-18 12:24:47 --> Router Class Initialized
INFO - 2020-09-18 12:24:47 --> Output Class Initialized
INFO - 2020-09-18 12:24:47 --> Security Class Initialized
DEBUG - 2020-09-18 12:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:24:47 --> Input Class Initialized
INFO - 2020-09-18 12:24:47 --> Language Class Initialized
INFO - 2020-09-18 12:24:47 --> Loader Class Initialized
INFO - 2020-09-18 12:24:47 --> Helper loaded: html_helper
INFO - 2020-09-18 12:24:47 --> Helper loaded: url_helper
INFO - 2020-09-18 12:24:47 --> Helper loaded: form_helper
INFO - 2020-09-18 12:24:47 --> Database Driver Class Initialized
INFO - 2020-09-18 12:24:47 --> Form Validation Class Initialized
DEBUG - 2020-09-18 12:24:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 12:24:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 12:24:47 --> Encryption Class Initialized
INFO - 2020-09-18 12:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:24:47 --> Controller Class Initialized
INFO - 2020-09-18 12:24:47 --> Helper loaded: language_helper
INFO - 2020-09-18 12:24:47 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 12:24:47 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 12:24:47 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 12:24:47 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\installation.php
INFO - 2020-09-18 12:24:48 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 12:24:48 --> Final output sent to browser
DEBUG - 2020-09-18 12:24:48 --> Total execution time: 1.2154
INFO - 2020-09-18 12:25:03 --> Config Class Initialized
INFO - 2020-09-18 12:25:04 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:25:04 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:25:04 --> Utf8 Class Initialized
INFO - 2020-09-18 12:25:04 --> URI Class Initialized
INFO - 2020-09-18 12:25:04 --> Router Class Initialized
INFO - 2020-09-18 12:25:04 --> Output Class Initialized
INFO - 2020-09-18 12:25:04 --> Security Class Initialized
DEBUG - 2020-09-18 12:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:25:04 --> Input Class Initialized
INFO - 2020-09-18 12:25:04 --> Language Class Initialized
INFO - 2020-09-18 12:25:04 --> Loader Class Initialized
INFO - 2020-09-18 12:25:04 --> Helper loaded: html_helper
INFO - 2020-09-18 12:25:04 --> Helper loaded: url_helper
INFO - 2020-09-18 12:25:04 --> Helper loaded: form_helper
INFO - 2020-09-18 12:25:04 --> Database Driver Class Initialized
INFO - 2020-09-18 12:25:04 --> Form Validation Class Initialized
DEBUG - 2020-09-18 12:25:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 12:25:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 12:25:04 --> Encryption Class Initialized
INFO - 2020-09-18 12:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:25:04 --> Controller Class Initialized
INFO - 2020-09-18 12:25:04 --> Helper loaded: language_helper
INFO - 2020-09-18 12:25:04 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 12:25:04 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 12:25:05 --> Final output sent to browser
DEBUG - 2020-09-18 12:25:05 --> Total execution time: 1.0844
INFO - 2020-09-18 12:37:02 --> Config Class Initialized
INFO - 2020-09-18 12:37:03 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:37:03 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:37:03 --> Utf8 Class Initialized
INFO - 2020-09-18 12:37:03 --> URI Class Initialized
INFO - 2020-09-18 12:37:03 --> Router Class Initialized
INFO - 2020-09-18 12:37:03 --> Output Class Initialized
INFO - 2020-09-18 12:37:03 --> Security Class Initialized
DEBUG - 2020-09-18 12:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:37:03 --> Input Class Initialized
INFO - 2020-09-18 12:37:03 --> Language Class Initialized
INFO - 2020-09-18 12:37:03 --> Loader Class Initialized
INFO - 2020-09-18 12:37:03 --> Helper loaded: html_helper
INFO - 2020-09-18 12:37:03 --> Helper loaded: url_helper
INFO - 2020-09-18 12:37:03 --> Helper loaded: form_helper
INFO - 2020-09-18 12:37:03 --> Database Driver Class Initialized
INFO - 2020-09-18 12:37:04 --> Form Validation Class Initialized
DEBUG - 2020-09-18 12:37:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 12:37:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 12:37:04 --> Encryption Class Initialized
INFO - 2020-09-18 12:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:37:04 --> Controller Class Initialized
INFO - 2020-09-18 12:37:04 --> Helper loaded: language_helper
INFO - 2020-09-18 12:37:04 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 12:37:04 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 12:37:04 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 12:37:04 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\installation.php
INFO - 2020-09-18 12:37:04 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 12:37:04 --> Final output sent to browser
DEBUG - 2020-09-18 12:37:04 --> Total execution time: 1.7509
INFO - 2020-09-18 12:37:17 --> Config Class Initialized
INFO - 2020-09-18 12:37:17 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:37:17 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:37:17 --> Utf8 Class Initialized
INFO - 2020-09-18 12:37:17 --> URI Class Initialized
INFO - 2020-09-18 12:37:17 --> Router Class Initialized
INFO - 2020-09-18 12:37:17 --> Output Class Initialized
INFO - 2020-09-18 12:37:17 --> Security Class Initialized
DEBUG - 2020-09-18 12:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:37:17 --> Input Class Initialized
INFO - 2020-09-18 12:37:17 --> Language Class Initialized
INFO - 2020-09-18 12:37:17 --> Loader Class Initialized
INFO - 2020-09-18 12:37:17 --> Helper loaded: html_helper
INFO - 2020-09-18 12:37:17 --> Helper loaded: url_helper
INFO - 2020-09-18 12:37:17 --> Helper loaded: form_helper
INFO - 2020-09-18 12:37:17 --> Database Driver Class Initialized
INFO - 2020-09-18 12:37:17 --> Form Validation Class Initialized
DEBUG - 2020-09-18 12:37:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 12:37:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 12:37:17 --> Encryption Class Initialized
INFO - 2020-09-18 12:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:37:18 --> Controller Class Initialized
INFO - 2020-09-18 12:37:18 --> Helper loaded: language_helper
INFO - 2020-09-18 12:37:18 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 12:37:18 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 12:37:18 --> Final output sent to browser
DEBUG - 2020-09-18 12:37:18 --> Total execution time: 1.1636
INFO - 2020-09-18 12:37:52 --> Config Class Initialized
INFO - 2020-09-18 12:37:52 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:37:52 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:37:52 --> Utf8 Class Initialized
INFO - 2020-09-18 12:37:52 --> URI Class Initialized
INFO - 2020-09-18 12:37:52 --> Router Class Initialized
INFO - 2020-09-18 12:37:52 --> Output Class Initialized
INFO - 2020-09-18 12:37:52 --> Security Class Initialized
DEBUG - 2020-09-18 12:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:37:52 --> Input Class Initialized
INFO - 2020-09-18 12:37:52 --> Language Class Initialized
INFO - 2020-09-18 12:37:52 --> Loader Class Initialized
INFO - 2020-09-18 12:37:52 --> Helper loaded: html_helper
INFO - 2020-09-18 12:37:52 --> Helper loaded: url_helper
INFO - 2020-09-18 12:37:52 --> Helper loaded: form_helper
INFO - 2020-09-18 12:37:52 --> Database Driver Class Initialized
INFO - 2020-09-18 12:37:52 --> Form Validation Class Initialized
DEBUG - 2020-09-18 12:37:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 12:37:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 12:37:52 --> Encryption Class Initialized
INFO - 2020-09-18 12:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:37:52 --> Controller Class Initialized
INFO - 2020-09-18 12:37:52 --> Helper loaded: language_helper
INFO - 2020-09-18 12:37:53 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 12:37:53 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 12:37:53 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 12:37:53 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\installation.php
INFO - 2020-09-18 12:37:53 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 12:37:53 --> Final output sent to browser
DEBUG - 2020-09-18 12:37:53 --> Total execution time: 1.1532
INFO - 2020-09-18 12:40:02 --> Config Class Initialized
INFO - 2020-09-18 12:40:02 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:40:02 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:40:02 --> Utf8 Class Initialized
INFO - 2020-09-18 12:40:02 --> URI Class Initialized
INFO - 2020-09-18 12:40:02 --> Router Class Initialized
INFO - 2020-09-18 12:40:02 --> Output Class Initialized
INFO - 2020-09-18 12:40:02 --> Security Class Initialized
DEBUG - 2020-09-18 12:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:40:03 --> Input Class Initialized
INFO - 2020-09-18 12:40:03 --> Language Class Initialized
INFO - 2020-09-18 12:40:03 --> Loader Class Initialized
INFO - 2020-09-18 12:40:03 --> Helper loaded: html_helper
INFO - 2020-09-18 12:40:03 --> Helper loaded: url_helper
INFO - 2020-09-18 12:40:03 --> Helper loaded: form_helper
INFO - 2020-09-18 12:40:03 --> Database Driver Class Initialized
INFO - 2020-09-18 12:40:03 --> Form Validation Class Initialized
DEBUG - 2020-09-18 12:40:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 12:40:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 12:40:03 --> Encryption Class Initialized
INFO - 2020-09-18 12:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:40:03 --> Controller Class Initialized
INFO - 2020-09-18 12:40:03 --> Helper loaded: language_helper
INFO - 2020-09-18 12:40:03 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 12:40:03 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 12:40:03 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 12:40:03 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\installation.php
INFO - 2020-09-18 12:40:03 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 12:40:03 --> Final output sent to browser
DEBUG - 2020-09-18 12:40:03 --> Total execution time: 1.1659
INFO - 2020-09-18 12:40:11 --> Config Class Initialized
INFO - 2020-09-18 12:40:11 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:40:11 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:40:11 --> Utf8 Class Initialized
INFO - 2020-09-18 12:40:11 --> URI Class Initialized
INFO - 2020-09-18 12:40:11 --> Router Class Initialized
INFO - 2020-09-18 12:40:11 --> Output Class Initialized
INFO - 2020-09-18 12:40:11 --> Security Class Initialized
DEBUG - 2020-09-18 12:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:40:11 --> Input Class Initialized
INFO - 2020-09-18 12:40:11 --> Language Class Initialized
INFO - 2020-09-18 12:40:11 --> Loader Class Initialized
INFO - 2020-09-18 12:40:11 --> Helper loaded: html_helper
INFO - 2020-09-18 12:40:12 --> Helper loaded: url_helper
INFO - 2020-09-18 12:40:12 --> Helper loaded: form_helper
INFO - 2020-09-18 12:40:12 --> Database Driver Class Initialized
INFO - 2020-09-18 12:40:12 --> Form Validation Class Initialized
DEBUG - 2020-09-18 12:40:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 12:40:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 12:40:12 --> Encryption Class Initialized
INFO - 2020-09-18 12:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:40:12 --> Controller Class Initialized
INFO - 2020-09-18 12:40:12 --> Helper loaded: language_helper
INFO - 2020-09-18 12:40:12 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 12:40:12 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 12:40:12 --> Final output sent to browser
DEBUG - 2020-09-18 12:40:12 --> Total execution time: 1.3260
INFO - 2020-09-18 12:40:53 --> Config Class Initialized
INFO - 2020-09-18 12:40:53 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:40:53 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:40:53 --> Utf8 Class Initialized
INFO - 2020-09-18 12:40:53 --> URI Class Initialized
INFO - 2020-09-18 12:40:53 --> Router Class Initialized
INFO - 2020-09-18 12:40:53 --> Output Class Initialized
INFO - 2020-09-18 12:40:53 --> Security Class Initialized
DEBUG - 2020-09-18 12:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:40:53 --> Input Class Initialized
INFO - 2020-09-18 12:40:53 --> Language Class Initialized
INFO - 2020-09-18 12:40:54 --> Loader Class Initialized
INFO - 2020-09-18 12:40:54 --> Helper loaded: html_helper
INFO - 2020-09-18 12:40:54 --> Helper loaded: url_helper
INFO - 2020-09-18 12:40:54 --> Helper loaded: form_helper
INFO - 2020-09-18 12:40:54 --> Database Driver Class Initialized
INFO - 2020-09-18 12:40:54 --> Form Validation Class Initialized
DEBUG - 2020-09-18 12:40:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 12:40:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 12:40:54 --> Encryption Class Initialized
INFO - 2020-09-18 12:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:40:54 --> Controller Class Initialized
INFO - 2020-09-18 12:40:54 --> Helper loaded: language_helper
INFO - 2020-09-18 12:40:54 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 12:40:54 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 12:40:54 --> Final output sent to browser
DEBUG - 2020-09-18 12:40:54 --> Total execution time: 1.3401
INFO - 2020-09-18 12:41:35 --> Config Class Initialized
INFO - 2020-09-18 12:41:35 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:41:35 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:41:35 --> Utf8 Class Initialized
INFO - 2020-09-18 12:41:35 --> URI Class Initialized
INFO - 2020-09-18 12:41:35 --> Router Class Initialized
INFO - 2020-09-18 12:41:35 --> Output Class Initialized
INFO - 2020-09-18 12:41:35 --> Security Class Initialized
DEBUG - 2020-09-18 12:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:41:35 --> Input Class Initialized
INFO - 2020-09-18 12:41:36 --> Language Class Initialized
INFO - 2020-09-18 12:41:36 --> Loader Class Initialized
INFO - 2020-09-18 12:41:36 --> Helper loaded: html_helper
INFO - 2020-09-18 12:41:36 --> Helper loaded: url_helper
INFO - 2020-09-18 12:41:36 --> Helper loaded: form_helper
INFO - 2020-09-18 12:41:36 --> Database Driver Class Initialized
INFO - 2020-09-18 12:41:36 --> Form Validation Class Initialized
DEBUG - 2020-09-18 12:41:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 12:41:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 12:41:36 --> Encryption Class Initialized
INFO - 2020-09-18 12:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:41:36 --> Controller Class Initialized
INFO - 2020-09-18 12:41:36 --> Helper loaded: language_helper
INFO - 2020-09-18 12:41:36 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 12:41:36 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 12:41:37 --> Final output sent to browser
DEBUG - 2020-09-18 12:41:37 --> Total execution time: 1.4356
INFO - 2020-09-18 12:42:28 --> Config Class Initialized
INFO - 2020-09-18 12:42:28 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:42:28 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:42:29 --> Utf8 Class Initialized
INFO - 2020-09-18 12:42:29 --> URI Class Initialized
INFO - 2020-09-18 12:42:29 --> Router Class Initialized
INFO - 2020-09-18 12:42:29 --> Output Class Initialized
INFO - 2020-09-18 12:42:29 --> Security Class Initialized
DEBUG - 2020-09-18 12:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:42:29 --> Input Class Initialized
INFO - 2020-09-18 12:42:29 --> Language Class Initialized
INFO - 2020-09-18 12:42:29 --> Loader Class Initialized
INFO - 2020-09-18 12:42:29 --> Helper loaded: html_helper
INFO - 2020-09-18 12:42:29 --> Helper loaded: url_helper
INFO - 2020-09-18 12:42:29 --> Helper loaded: form_helper
INFO - 2020-09-18 12:42:29 --> Database Driver Class Initialized
INFO - 2020-09-18 12:42:29 --> Form Validation Class Initialized
DEBUG - 2020-09-18 12:42:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 12:42:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 12:42:29 --> Encryption Class Initialized
INFO - 2020-09-18 12:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:42:29 --> Controller Class Initialized
INFO - 2020-09-18 12:42:29 --> Helper loaded: language_helper
INFO - 2020-09-18 12:42:29 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 12:42:29 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 12:42:30 --> Final output sent to browser
DEBUG - 2020-09-18 12:42:30 --> Total execution time: 1.2921
INFO - 2020-09-18 12:58:23 --> Config Class Initialized
INFO - 2020-09-18 12:58:23 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:58:23 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:58:23 --> Utf8 Class Initialized
INFO - 2020-09-18 12:58:24 --> URI Class Initialized
INFO - 2020-09-18 12:58:24 --> Router Class Initialized
INFO - 2020-09-18 12:58:24 --> Output Class Initialized
INFO - 2020-09-18 12:58:24 --> Security Class Initialized
DEBUG - 2020-09-18 12:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:58:24 --> Input Class Initialized
INFO - 2020-09-18 12:58:24 --> Language Class Initialized
INFO - 2020-09-18 12:58:24 --> Loader Class Initialized
INFO - 2020-09-18 12:58:24 --> Helper loaded: html_helper
INFO - 2020-09-18 12:58:24 --> Helper loaded: url_helper
INFO - 2020-09-18 12:58:24 --> Helper loaded: form_helper
INFO - 2020-09-18 12:58:24 --> Database Driver Class Initialized
INFO - 2020-09-18 12:58:24 --> Form Validation Class Initialized
DEBUG - 2020-09-18 12:58:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 12:58:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 12:58:24 --> Encryption Class Initialized
INFO - 2020-09-18 12:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:58:24 --> Controller Class Initialized
INFO - 2020-09-18 12:58:24 --> Helper loaded: language_helper
INFO - 2020-09-18 12:58:24 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 12:58:24 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 12:58:24 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 12:58:24 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\installation.php
INFO - 2020-09-18 12:58:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 12:58:25 --> Final output sent to browser
DEBUG - 2020-09-18 12:58:25 --> Total execution time: 1.2214
INFO - 2020-09-18 12:58:30 --> Config Class Initialized
INFO - 2020-09-18 12:58:30 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:58:30 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:58:30 --> Utf8 Class Initialized
INFO - 2020-09-18 12:58:30 --> URI Class Initialized
INFO - 2020-09-18 12:58:30 --> Router Class Initialized
INFO - 2020-09-18 12:58:30 --> Output Class Initialized
INFO - 2020-09-18 12:58:30 --> Security Class Initialized
DEBUG - 2020-09-18 12:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:58:30 --> Input Class Initialized
INFO - 2020-09-18 12:58:30 --> Language Class Initialized
INFO - 2020-09-18 12:58:30 --> Loader Class Initialized
INFO - 2020-09-18 12:58:30 --> Helper loaded: html_helper
INFO - 2020-09-18 12:58:30 --> Helper loaded: url_helper
INFO - 2020-09-18 12:58:30 --> Helper loaded: form_helper
INFO - 2020-09-18 12:58:30 --> Database Driver Class Initialized
INFO - 2020-09-18 12:58:30 --> Form Validation Class Initialized
DEBUG - 2020-09-18 12:58:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 12:58:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 12:58:30 --> Encryption Class Initialized
INFO - 2020-09-18 12:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:58:31 --> Controller Class Initialized
INFO - 2020-09-18 12:58:31 --> Helper loaded: language_helper
INFO - 2020-09-18 12:58:31 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 12:58:31 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 12:58:31 --> Final output sent to browser
DEBUG - 2020-09-18 12:58:31 --> Total execution time: 1.3084
INFO - 2020-09-18 13:00:38 --> Config Class Initialized
INFO - 2020-09-18 13:00:38 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:00:38 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:00:39 --> Utf8 Class Initialized
INFO - 2020-09-18 13:00:39 --> URI Class Initialized
INFO - 2020-09-18 13:00:39 --> Router Class Initialized
INFO - 2020-09-18 13:00:39 --> Output Class Initialized
INFO - 2020-09-18 13:00:39 --> Security Class Initialized
DEBUG - 2020-09-18 13:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:00:39 --> Input Class Initialized
INFO - 2020-09-18 13:00:39 --> Language Class Initialized
INFO - 2020-09-18 13:00:39 --> Loader Class Initialized
INFO - 2020-09-18 13:00:39 --> Helper loaded: html_helper
INFO - 2020-09-18 13:00:39 --> Helper loaded: url_helper
INFO - 2020-09-18 13:00:39 --> Helper loaded: form_helper
INFO - 2020-09-18 13:00:39 --> Database Driver Class Initialized
INFO - 2020-09-18 13:00:39 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:00:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:00:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:00:39 --> Encryption Class Initialized
INFO - 2020-09-18 13:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:00:39 --> Controller Class Initialized
INFO - 2020-09-18 13:00:39 --> Helper loaded: language_helper
INFO - 2020-09-18 13:00:39 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:00:39 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 13:00:39 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 13:00:39 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\installation.php
INFO - 2020-09-18 13:00:39 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 13:00:39 --> Final output sent to browser
DEBUG - 2020-09-18 13:00:40 --> Total execution time: 1.1389
INFO - 2020-09-18 13:03:28 --> Config Class Initialized
INFO - 2020-09-18 13:03:28 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:03:28 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:03:28 --> Utf8 Class Initialized
INFO - 2020-09-18 13:03:28 --> URI Class Initialized
INFO - 2020-09-18 13:03:28 --> Router Class Initialized
INFO - 2020-09-18 13:03:28 --> Output Class Initialized
INFO - 2020-09-18 13:03:28 --> Security Class Initialized
DEBUG - 2020-09-18 13:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:03:28 --> Input Class Initialized
INFO - 2020-09-18 13:03:28 --> Language Class Initialized
INFO - 2020-09-18 13:03:28 --> Loader Class Initialized
INFO - 2020-09-18 13:03:28 --> Helper loaded: html_helper
INFO - 2020-09-18 13:03:28 --> Helper loaded: url_helper
INFO - 2020-09-18 13:03:28 --> Helper loaded: form_helper
INFO - 2020-09-18 13:03:28 --> Database Driver Class Initialized
INFO - 2020-09-18 13:03:29 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:03:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:03:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:03:29 --> Encryption Class Initialized
INFO - 2020-09-18 13:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:03:29 --> Controller Class Initialized
INFO - 2020-09-18 13:03:29 --> Helper loaded: language_helper
INFO - 2020-09-18 13:03:29 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:03:29 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 13:03:29 --> Final output sent to browser
DEBUG - 2020-09-18 13:03:29 --> Total execution time: 1.2996
INFO - 2020-09-18 13:03:39 --> Config Class Initialized
INFO - 2020-09-18 13:03:39 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:03:39 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:03:39 --> Utf8 Class Initialized
INFO - 2020-09-18 13:03:39 --> URI Class Initialized
INFO - 2020-09-18 13:03:39 --> Router Class Initialized
INFO - 2020-09-18 13:03:39 --> Output Class Initialized
INFO - 2020-09-18 13:03:39 --> Security Class Initialized
DEBUG - 2020-09-18 13:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:03:39 --> Input Class Initialized
INFO - 2020-09-18 13:03:39 --> Language Class Initialized
INFO - 2020-09-18 13:03:39 --> Loader Class Initialized
INFO - 2020-09-18 13:03:39 --> Helper loaded: html_helper
INFO - 2020-09-18 13:03:39 --> Helper loaded: url_helper
INFO - 2020-09-18 13:03:39 --> Helper loaded: form_helper
INFO - 2020-09-18 13:03:39 --> Database Driver Class Initialized
INFO - 2020-09-18 13:03:39 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:03:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:03:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:03:40 --> Encryption Class Initialized
INFO - 2020-09-18 13:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:03:40 --> Controller Class Initialized
INFO - 2020-09-18 13:03:40 --> Helper loaded: language_helper
INFO - 2020-09-18 13:03:40 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:03:40 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 13:03:40 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 13:03:40 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\installation.php
INFO - 2020-09-18 13:03:40 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 13:03:40 --> Final output sent to browser
DEBUG - 2020-09-18 13:03:40 --> Total execution time: 1.2995
INFO - 2020-09-18 13:03:55 --> Config Class Initialized
INFO - 2020-09-18 13:03:55 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:03:55 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:03:55 --> Utf8 Class Initialized
INFO - 2020-09-18 13:03:55 --> URI Class Initialized
INFO - 2020-09-18 13:03:55 --> Router Class Initialized
INFO - 2020-09-18 13:03:55 --> Output Class Initialized
INFO - 2020-09-18 13:03:55 --> Security Class Initialized
DEBUG - 2020-09-18 13:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:03:55 --> Input Class Initialized
INFO - 2020-09-18 13:03:55 --> Language Class Initialized
INFO - 2020-09-18 13:03:55 --> Loader Class Initialized
INFO - 2020-09-18 13:03:55 --> Helper loaded: html_helper
INFO - 2020-09-18 13:03:55 --> Helper loaded: url_helper
INFO - 2020-09-18 13:03:55 --> Helper loaded: form_helper
INFO - 2020-09-18 13:03:55 --> Database Driver Class Initialized
INFO - 2020-09-18 13:03:55 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:03:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:03:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:03:55 --> Encryption Class Initialized
INFO - 2020-09-18 13:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:03:56 --> Controller Class Initialized
INFO - 2020-09-18 13:03:56 --> Helper loaded: language_helper
INFO - 2020-09-18 13:03:56 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:03:56 --> Model "Installation_model" initialized
INFO - 2020-09-18 13:03:56 --> Final output sent to browser
DEBUG - 2020-09-18 13:03:56 --> Total execution time: 1.2655
INFO - 2020-09-18 13:04:27 --> Config Class Initialized
INFO - 2020-09-18 13:04:27 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:04:27 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:04:27 --> Utf8 Class Initialized
INFO - 2020-09-18 13:04:27 --> URI Class Initialized
INFO - 2020-09-18 13:04:27 --> Router Class Initialized
INFO - 2020-09-18 13:04:27 --> Output Class Initialized
INFO - 2020-09-18 13:04:27 --> Security Class Initialized
DEBUG - 2020-09-18 13:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:04:27 --> Input Class Initialized
INFO - 2020-09-18 13:04:27 --> Language Class Initialized
INFO - 2020-09-18 13:04:27 --> Loader Class Initialized
INFO - 2020-09-18 13:04:28 --> Helper loaded: html_helper
INFO - 2020-09-18 13:04:28 --> Helper loaded: url_helper
INFO - 2020-09-18 13:04:28 --> Helper loaded: form_helper
INFO - 2020-09-18 13:04:28 --> Database Driver Class Initialized
INFO - 2020-09-18 13:04:28 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:04:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:04:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:04:28 --> Encryption Class Initialized
INFO - 2020-09-18 13:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:04:28 --> Controller Class Initialized
INFO - 2020-09-18 13:04:28 --> Helper loaded: language_helper
INFO - 2020-09-18 13:04:28 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:04:28 --> Model "Installation_model" initialized
INFO - 2020-09-18 13:04:28 --> Final output sent to browser
DEBUG - 2020-09-18 13:04:28 --> Total execution time: 1.1150
INFO - 2020-09-18 13:05:48 --> Config Class Initialized
INFO - 2020-09-18 13:05:48 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:05:48 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:05:48 --> Utf8 Class Initialized
INFO - 2020-09-18 13:05:48 --> URI Class Initialized
INFO - 2020-09-18 13:05:48 --> Router Class Initialized
INFO - 2020-09-18 13:05:48 --> Output Class Initialized
INFO - 2020-09-18 13:05:48 --> Security Class Initialized
DEBUG - 2020-09-18 13:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:05:49 --> Input Class Initialized
INFO - 2020-09-18 13:05:49 --> Language Class Initialized
INFO - 2020-09-18 13:05:49 --> Loader Class Initialized
INFO - 2020-09-18 13:05:49 --> Helper loaded: html_helper
INFO - 2020-09-18 13:05:49 --> Helper loaded: url_helper
INFO - 2020-09-18 13:05:49 --> Helper loaded: form_helper
INFO - 2020-09-18 13:05:49 --> Database Driver Class Initialized
INFO - 2020-09-18 13:05:49 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:05:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:05:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:05:49 --> Encryption Class Initialized
INFO - 2020-09-18 13:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:05:49 --> Controller Class Initialized
INFO - 2020-09-18 13:05:49 --> Helper loaded: language_helper
INFO - 2020-09-18 13:05:49 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:05:49 --> Model "Installation_model" initialized
INFO - 2020-09-18 13:05:49 --> Final output sent to browser
DEBUG - 2020-09-18 13:05:49 --> Total execution time: 1.1170
INFO - 2020-09-18 13:06:03 --> Config Class Initialized
INFO - 2020-09-18 13:06:03 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:06:03 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:06:03 --> Utf8 Class Initialized
INFO - 2020-09-18 13:06:03 --> URI Class Initialized
INFO - 2020-09-18 13:06:03 --> Router Class Initialized
INFO - 2020-09-18 13:06:03 --> Output Class Initialized
INFO - 2020-09-18 13:06:03 --> Security Class Initialized
DEBUG - 2020-09-18 13:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:06:03 --> Input Class Initialized
INFO - 2020-09-18 13:06:03 --> Language Class Initialized
INFO - 2020-09-18 13:06:04 --> Loader Class Initialized
INFO - 2020-09-18 13:06:04 --> Helper loaded: html_helper
INFO - 2020-09-18 13:06:04 --> Helper loaded: url_helper
INFO - 2020-09-18 13:06:04 --> Helper loaded: form_helper
INFO - 2020-09-18 13:06:04 --> Database Driver Class Initialized
INFO - 2020-09-18 13:06:04 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:06:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:06:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:06:04 --> Encryption Class Initialized
INFO - 2020-09-18 13:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:06:04 --> Controller Class Initialized
INFO - 2020-09-18 13:06:04 --> Helper loaded: language_helper
INFO - 2020-09-18 13:06:04 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:06:04 --> Model "Installation_model" initialized
INFO - 2020-09-18 13:06:04 --> Final output sent to browser
DEBUG - 2020-09-18 13:06:04 --> Total execution time: 1.1012
INFO - 2020-09-18 13:06:10 --> Config Class Initialized
INFO - 2020-09-18 13:06:10 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:06:10 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:06:10 --> Utf8 Class Initialized
INFO - 2020-09-18 13:06:10 --> URI Class Initialized
INFO - 2020-09-18 13:06:10 --> Router Class Initialized
INFO - 2020-09-18 13:06:10 --> Output Class Initialized
INFO - 2020-09-18 13:06:10 --> Security Class Initialized
DEBUG - 2020-09-18 13:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:06:10 --> Input Class Initialized
INFO - 2020-09-18 13:06:10 --> Language Class Initialized
INFO - 2020-09-18 13:06:10 --> Loader Class Initialized
INFO - 2020-09-18 13:06:11 --> Helper loaded: html_helper
INFO - 2020-09-18 13:06:11 --> Helper loaded: url_helper
INFO - 2020-09-18 13:06:11 --> Helper loaded: form_helper
INFO - 2020-09-18 13:06:11 --> Database Driver Class Initialized
INFO - 2020-09-18 13:06:11 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:06:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:06:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:06:11 --> Encryption Class Initialized
INFO - 2020-09-18 13:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:06:11 --> Controller Class Initialized
INFO - 2020-09-18 13:06:11 --> Helper loaded: language_helper
INFO - 2020-09-18 13:06:11 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:06:11 --> Model "Installation_model" initialized
INFO - 2020-09-18 13:06:11 --> Final output sent to browser
DEBUG - 2020-09-18 13:06:11 --> Total execution time: 1.0781
INFO - 2020-09-18 13:06:30 --> Config Class Initialized
INFO - 2020-09-18 13:06:30 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:06:30 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:06:30 --> Utf8 Class Initialized
INFO - 2020-09-18 13:06:30 --> URI Class Initialized
INFO - 2020-09-18 13:06:30 --> Router Class Initialized
INFO - 2020-09-18 13:06:31 --> Output Class Initialized
INFO - 2020-09-18 13:06:31 --> Security Class Initialized
DEBUG - 2020-09-18 13:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:06:31 --> Input Class Initialized
INFO - 2020-09-18 13:06:31 --> Language Class Initialized
INFO - 2020-09-18 13:06:31 --> Loader Class Initialized
INFO - 2020-09-18 13:06:31 --> Helper loaded: html_helper
INFO - 2020-09-18 13:06:31 --> Helper loaded: url_helper
INFO - 2020-09-18 13:06:31 --> Helper loaded: form_helper
INFO - 2020-09-18 13:06:31 --> Database Driver Class Initialized
INFO - 2020-09-18 13:06:31 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:06:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:06:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:06:31 --> Encryption Class Initialized
INFO - 2020-09-18 13:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:06:31 --> Controller Class Initialized
INFO - 2020-09-18 13:06:31 --> Helper loaded: language_helper
INFO - 2020-09-18 13:06:31 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:06:31 --> Model "Installation_model" initialized
INFO - 2020-09-18 13:06:31 --> Final output sent to browser
DEBUG - 2020-09-18 13:06:32 --> Total execution time: 1.3292
INFO - 2020-09-18 13:06:42 --> Config Class Initialized
INFO - 2020-09-18 13:06:42 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:06:42 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:06:42 --> Utf8 Class Initialized
INFO - 2020-09-18 13:06:42 --> URI Class Initialized
INFO - 2020-09-18 13:06:42 --> Router Class Initialized
INFO - 2020-09-18 13:06:42 --> Output Class Initialized
INFO - 2020-09-18 13:06:42 --> Security Class Initialized
DEBUG - 2020-09-18 13:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:06:42 --> Input Class Initialized
INFO - 2020-09-18 13:06:42 --> Language Class Initialized
INFO - 2020-09-18 13:06:42 --> Loader Class Initialized
INFO - 2020-09-18 13:06:42 --> Helper loaded: html_helper
INFO - 2020-09-18 13:06:42 --> Helper loaded: url_helper
INFO - 2020-09-18 13:06:43 --> Helper loaded: form_helper
INFO - 2020-09-18 13:06:43 --> Database Driver Class Initialized
INFO - 2020-09-18 13:06:43 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:06:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:06:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:06:43 --> Encryption Class Initialized
INFO - 2020-09-18 13:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:06:43 --> Controller Class Initialized
INFO - 2020-09-18 13:06:43 --> Helper loaded: language_helper
INFO - 2020-09-18 13:06:43 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:06:43 --> Model "Installation_model" initialized
INFO - 2020-09-18 13:06:43 --> Final output sent to browser
DEBUG - 2020-09-18 13:06:43 --> Total execution time: 1.3391
INFO - 2020-09-18 13:06:48 --> Config Class Initialized
INFO - 2020-09-18 13:06:48 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:06:49 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:06:49 --> Utf8 Class Initialized
INFO - 2020-09-18 13:06:49 --> URI Class Initialized
INFO - 2020-09-18 13:06:49 --> Router Class Initialized
INFO - 2020-09-18 13:06:49 --> Output Class Initialized
INFO - 2020-09-18 13:06:49 --> Security Class Initialized
DEBUG - 2020-09-18 13:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:06:49 --> Input Class Initialized
INFO - 2020-09-18 13:06:49 --> Language Class Initialized
INFO - 2020-09-18 13:06:49 --> Loader Class Initialized
INFO - 2020-09-18 13:06:49 --> Helper loaded: html_helper
INFO - 2020-09-18 13:06:49 --> Helper loaded: url_helper
INFO - 2020-09-18 13:06:49 --> Helper loaded: form_helper
INFO - 2020-09-18 13:06:49 --> Database Driver Class Initialized
INFO - 2020-09-18 13:06:49 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:06:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:06:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:06:49 --> Encryption Class Initialized
INFO - 2020-09-18 13:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:06:50 --> Controller Class Initialized
INFO - 2020-09-18 13:06:50 --> Helper loaded: language_helper
INFO - 2020-09-18 13:06:50 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:06:50 --> Model "Installation_model" initialized
INFO - 2020-09-18 13:06:50 --> Final output sent to browser
DEBUG - 2020-09-18 13:06:50 --> Total execution time: 1.3711
INFO - 2020-09-18 13:07:11 --> Config Class Initialized
INFO - 2020-09-18 13:07:11 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:07:11 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:07:11 --> Utf8 Class Initialized
INFO - 2020-09-18 13:07:11 --> URI Class Initialized
INFO - 2020-09-18 13:07:11 --> Router Class Initialized
INFO - 2020-09-18 13:07:11 --> Output Class Initialized
INFO - 2020-09-18 13:07:11 --> Security Class Initialized
DEBUG - 2020-09-18 13:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:07:11 --> Input Class Initialized
INFO - 2020-09-18 13:07:12 --> Language Class Initialized
INFO - 2020-09-18 13:07:12 --> Loader Class Initialized
INFO - 2020-09-18 13:07:12 --> Helper loaded: html_helper
INFO - 2020-09-18 13:07:12 --> Helper loaded: url_helper
INFO - 2020-09-18 13:07:12 --> Helper loaded: form_helper
INFO - 2020-09-18 13:07:12 --> Database Driver Class Initialized
INFO - 2020-09-18 13:07:12 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:07:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:07:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:07:12 --> Encryption Class Initialized
INFO - 2020-09-18 13:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:07:12 --> Controller Class Initialized
INFO - 2020-09-18 13:07:12 --> Helper loaded: language_helper
INFO - 2020-09-18 13:07:12 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:07:12 --> Model "Installation_model" initialized
INFO - 2020-09-18 13:07:12 --> Final output sent to browser
DEBUG - 2020-09-18 13:07:12 --> Total execution time: 1.2385
INFO - 2020-09-18 13:07:26 --> Config Class Initialized
INFO - 2020-09-18 13:07:26 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:07:26 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:07:26 --> Utf8 Class Initialized
INFO - 2020-09-18 13:07:26 --> URI Class Initialized
INFO - 2020-09-18 13:07:26 --> Router Class Initialized
INFO - 2020-09-18 13:07:26 --> Output Class Initialized
INFO - 2020-09-18 13:07:26 --> Security Class Initialized
DEBUG - 2020-09-18 13:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:07:26 --> Input Class Initialized
INFO - 2020-09-18 13:07:26 --> Language Class Initialized
INFO - 2020-09-18 13:07:26 --> Loader Class Initialized
INFO - 2020-09-18 13:07:27 --> Helper loaded: html_helper
INFO - 2020-09-18 13:07:27 --> Helper loaded: url_helper
INFO - 2020-09-18 13:07:27 --> Helper loaded: form_helper
INFO - 2020-09-18 13:07:27 --> Database Driver Class Initialized
INFO - 2020-09-18 13:07:27 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:07:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:07:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:07:27 --> Encryption Class Initialized
INFO - 2020-09-18 13:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:07:27 --> Controller Class Initialized
INFO - 2020-09-18 13:07:27 --> Helper loaded: language_helper
INFO - 2020-09-18 13:07:27 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:07:27 --> Model "Installation_model" initialized
INFO - 2020-09-18 13:07:27 --> Final output sent to browser
DEBUG - 2020-09-18 13:07:27 --> Total execution time: 1.1796
INFO - 2020-09-18 13:07:32 --> Config Class Initialized
INFO - 2020-09-18 13:07:32 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:07:32 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:07:32 --> Utf8 Class Initialized
INFO - 2020-09-18 13:07:32 --> URI Class Initialized
INFO - 2020-09-18 13:07:32 --> Router Class Initialized
INFO - 2020-09-18 13:07:33 --> Output Class Initialized
INFO - 2020-09-18 13:07:33 --> Security Class Initialized
DEBUG - 2020-09-18 13:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:07:33 --> Input Class Initialized
INFO - 2020-09-18 13:07:33 --> Language Class Initialized
INFO - 2020-09-18 13:07:33 --> Loader Class Initialized
INFO - 2020-09-18 13:07:33 --> Helper loaded: html_helper
INFO - 2020-09-18 13:07:33 --> Helper loaded: url_helper
INFO - 2020-09-18 13:07:33 --> Helper loaded: form_helper
INFO - 2020-09-18 13:07:33 --> Database Driver Class Initialized
INFO - 2020-09-18 13:07:33 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:07:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:07:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:07:33 --> Encryption Class Initialized
INFO - 2020-09-18 13:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:07:33 --> Controller Class Initialized
INFO - 2020-09-18 13:07:33 --> Helper loaded: language_helper
INFO - 2020-09-18 13:07:33 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:07:33 --> Model "Installation_model" initialized
INFO - 2020-09-18 13:07:33 --> Final output sent to browser
DEBUG - 2020-09-18 13:07:33 --> Total execution time: 1.1365
INFO - 2020-09-18 13:07:48 --> Config Class Initialized
INFO - 2020-09-18 13:07:48 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:07:48 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:07:48 --> Utf8 Class Initialized
INFO - 2020-09-18 13:07:48 --> URI Class Initialized
INFO - 2020-09-18 13:07:48 --> Router Class Initialized
INFO - 2020-09-18 13:07:48 --> Output Class Initialized
INFO - 2020-09-18 13:07:48 --> Security Class Initialized
DEBUG - 2020-09-18 13:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:07:48 --> Input Class Initialized
INFO - 2020-09-18 13:07:48 --> Language Class Initialized
INFO - 2020-09-18 13:07:48 --> Loader Class Initialized
INFO - 2020-09-18 13:07:48 --> Helper loaded: html_helper
INFO - 2020-09-18 13:07:48 --> Helper loaded: url_helper
INFO - 2020-09-18 13:07:48 --> Helper loaded: form_helper
INFO - 2020-09-18 13:07:48 --> Database Driver Class Initialized
INFO - 2020-09-18 13:07:48 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:07:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:07:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:07:48 --> Encryption Class Initialized
INFO - 2020-09-18 13:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:07:49 --> Controller Class Initialized
INFO - 2020-09-18 13:07:49 --> Helper loaded: language_helper
INFO - 2020-09-18 13:07:49 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:07:49 --> Model "Installation_model" initialized
INFO - 2020-09-18 13:07:49 --> Final output sent to browser
DEBUG - 2020-09-18 13:07:49 --> Total execution time: 1.0929
INFO - 2020-09-18 13:07:57 --> Config Class Initialized
INFO - 2020-09-18 13:07:57 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:07:57 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:07:57 --> Utf8 Class Initialized
INFO - 2020-09-18 13:07:57 --> URI Class Initialized
INFO - 2020-09-18 13:07:57 --> Router Class Initialized
INFO - 2020-09-18 13:07:57 --> Output Class Initialized
INFO - 2020-09-18 13:07:57 --> Security Class Initialized
DEBUG - 2020-09-18 13:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:07:57 --> Input Class Initialized
INFO - 2020-09-18 13:07:57 --> Language Class Initialized
INFO - 2020-09-18 13:07:57 --> Loader Class Initialized
INFO - 2020-09-18 13:07:57 --> Helper loaded: html_helper
INFO - 2020-09-18 13:07:57 --> Helper loaded: url_helper
INFO - 2020-09-18 13:07:58 --> Helper loaded: form_helper
INFO - 2020-09-18 13:07:58 --> Database Driver Class Initialized
INFO - 2020-09-18 13:07:58 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:07:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:07:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:07:58 --> Encryption Class Initialized
INFO - 2020-09-18 13:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:07:58 --> Controller Class Initialized
INFO - 2020-09-18 13:07:58 --> Helper loaded: language_helper
INFO - 2020-09-18 13:07:58 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:07:58 --> Model "Installation_model" initialized
INFO - 2020-09-18 13:07:58 --> Final output sent to browser
DEBUG - 2020-09-18 13:07:58 --> Total execution time: 1.1498
INFO - 2020-09-18 13:08:04 --> Config Class Initialized
INFO - 2020-09-18 13:08:04 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:08:04 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:08:04 --> Utf8 Class Initialized
INFO - 2020-09-18 13:08:04 --> URI Class Initialized
INFO - 2020-09-18 13:08:04 --> Router Class Initialized
INFO - 2020-09-18 13:08:04 --> Output Class Initialized
INFO - 2020-09-18 13:08:04 --> Security Class Initialized
DEBUG - 2020-09-18 13:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:08:04 --> Input Class Initialized
INFO - 2020-09-18 13:08:04 --> Language Class Initialized
INFO - 2020-09-18 13:08:04 --> Loader Class Initialized
INFO - 2020-09-18 13:08:04 --> Helper loaded: html_helper
INFO - 2020-09-18 13:08:04 --> Helper loaded: url_helper
INFO - 2020-09-18 13:08:04 --> Helper loaded: form_helper
INFO - 2020-09-18 13:08:04 --> Database Driver Class Initialized
INFO - 2020-09-18 13:08:04 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:08:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:08:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:08:04 --> Encryption Class Initialized
INFO - 2020-09-18 13:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:08:05 --> Controller Class Initialized
INFO - 2020-09-18 13:08:05 --> Helper loaded: language_helper
INFO - 2020-09-18 13:08:05 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:08:05 --> Model "Installation_model" initialized
INFO - 2020-09-18 13:08:05 --> Final output sent to browser
DEBUG - 2020-09-18 13:08:05 --> Total execution time: 1.1776
INFO - 2020-09-18 13:08:16 --> Config Class Initialized
INFO - 2020-09-18 13:08:17 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:08:17 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:08:17 --> Utf8 Class Initialized
INFO - 2020-09-18 13:08:17 --> URI Class Initialized
INFO - 2020-09-18 13:08:17 --> Router Class Initialized
INFO - 2020-09-18 13:08:17 --> Output Class Initialized
INFO - 2020-09-18 13:08:17 --> Security Class Initialized
DEBUG - 2020-09-18 13:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:08:17 --> Input Class Initialized
INFO - 2020-09-18 13:08:17 --> Language Class Initialized
INFO - 2020-09-18 13:08:17 --> Loader Class Initialized
INFO - 2020-09-18 13:08:17 --> Helper loaded: html_helper
INFO - 2020-09-18 13:08:17 --> Helper loaded: url_helper
INFO - 2020-09-18 13:08:17 --> Helper loaded: form_helper
INFO - 2020-09-18 13:08:17 --> Database Driver Class Initialized
INFO - 2020-09-18 13:08:17 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:08:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:08:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:08:17 --> Encryption Class Initialized
INFO - 2020-09-18 13:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:08:17 --> Controller Class Initialized
INFO - 2020-09-18 13:08:18 --> Helper loaded: language_helper
INFO - 2020-09-18 13:08:18 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:08:18 --> Model "Installation_model" initialized
INFO - 2020-09-18 13:08:18 --> Final output sent to browser
DEBUG - 2020-09-18 13:08:18 --> Total execution time: 1.2550
INFO - 2020-09-18 13:10:08 --> Config Class Initialized
INFO - 2020-09-18 13:10:08 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:10:08 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:10:08 --> Utf8 Class Initialized
INFO - 2020-09-18 13:10:08 --> URI Class Initialized
INFO - 2020-09-18 13:10:08 --> Router Class Initialized
INFO - 2020-09-18 13:10:08 --> Output Class Initialized
INFO - 2020-09-18 13:10:08 --> Security Class Initialized
DEBUG - 2020-09-18 13:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:10:08 --> Input Class Initialized
INFO - 2020-09-18 13:10:08 --> Language Class Initialized
INFO - 2020-09-18 13:10:09 --> Loader Class Initialized
INFO - 2020-09-18 13:10:09 --> Helper loaded: html_helper
INFO - 2020-09-18 13:10:09 --> Helper loaded: url_helper
INFO - 2020-09-18 13:10:09 --> Helper loaded: form_helper
INFO - 2020-09-18 13:10:09 --> Database Driver Class Initialized
INFO - 2020-09-18 13:10:09 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:10:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:10:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:10:09 --> Encryption Class Initialized
INFO - 2020-09-18 13:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:10:09 --> Controller Class Initialized
INFO - 2020-09-18 13:10:09 --> Helper loaded: language_helper
INFO - 2020-09-18 13:10:09 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:10:09 --> Final output sent to browser
DEBUG - 2020-09-18 13:10:09 --> Total execution time: 1.2554
INFO - 2020-09-18 13:10:10 --> Config Class Initialized
INFO - 2020-09-18 13:10:10 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:10:10 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:10:10 --> Utf8 Class Initialized
INFO - 2020-09-18 13:10:10 --> URI Class Initialized
DEBUG - 2020-09-18 13:10:10 --> No URI present. Default controller set.
INFO - 2020-09-18 13:10:10 --> Router Class Initialized
INFO - 2020-09-18 13:10:10 --> Output Class Initialized
INFO - 2020-09-18 13:10:10 --> Security Class Initialized
DEBUG - 2020-09-18 13:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:10:10 --> Input Class Initialized
INFO - 2020-09-18 13:10:10 --> Language Class Initialized
INFO - 2020-09-18 13:10:10 --> Loader Class Initialized
INFO - 2020-09-18 13:10:10 --> Helper loaded: html_helper
INFO - 2020-09-18 13:10:10 --> Helper loaded: url_helper
INFO - 2020-09-18 13:10:10 --> Helper loaded: form_helper
INFO - 2020-09-18 13:10:10 --> Database Driver Class Initialized
INFO - 2020-09-18 13:10:10 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:10:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:10:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:10:11 --> Encryption Class Initialized
INFO - 2020-09-18 13:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:10:11 --> Controller Class Initialized
INFO - 2020-09-18 13:10:11 --> Helper loaded: language_helper
INFO - 2020-09-18 13:10:11 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:10:11 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-18 13:10:11 --> Final output sent to browser
DEBUG - 2020-09-18 13:10:11 --> Total execution time: 1.1719
INFO - 2020-09-18 13:11:17 --> Config Class Initialized
INFO - 2020-09-18 13:11:17 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:11:17 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:11:17 --> Utf8 Class Initialized
INFO - 2020-09-18 13:11:17 --> URI Class Initialized
INFO - 2020-09-18 13:11:17 --> Router Class Initialized
INFO - 2020-09-18 13:11:17 --> Output Class Initialized
INFO - 2020-09-18 13:11:17 --> Security Class Initialized
DEBUG - 2020-09-18 13:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:11:17 --> Input Class Initialized
INFO - 2020-09-18 13:11:17 --> Language Class Initialized
INFO - 2020-09-18 13:11:17 --> Loader Class Initialized
INFO - 2020-09-18 13:11:17 --> Helper loaded: html_helper
INFO - 2020-09-18 13:11:17 --> Helper loaded: url_helper
INFO - 2020-09-18 13:11:17 --> Helper loaded: form_helper
INFO - 2020-09-18 13:11:17 --> Database Driver Class Initialized
INFO - 2020-09-18 13:11:17 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:11:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:11:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:11:18 --> Encryption Class Initialized
INFO - 2020-09-18 13:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:11:18 --> Controller Class Initialized
INFO - 2020-09-18 13:11:18 --> Helper loaded: language_helper
INFO - 2020-09-18 13:11:18 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-18 13:11:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-18 13:11:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-18 13:11:18 --> Model "User" initialized
INFO - 2020-09-18 13:11:19 --> Config Class Initialized
INFO - 2020-09-18 13:11:19 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:11:19 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:11:19 --> Utf8 Class Initialized
INFO - 2020-09-18 13:11:19 --> URI Class Initialized
INFO - 2020-09-18 13:11:19 --> Router Class Initialized
INFO - 2020-09-18 13:11:19 --> Output Class Initialized
INFO - 2020-09-18 13:11:19 --> Security Class Initialized
DEBUG - 2020-09-18 13:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:11:19 --> Input Class Initialized
INFO - 2020-09-18 13:11:19 --> Language Class Initialized
INFO - 2020-09-18 13:11:19 --> Loader Class Initialized
INFO - 2020-09-18 13:11:19 --> Helper loaded: html_helper
INFO - 2020-09-18 13:11:19 --> Helper loaded: url_helper
INFO - 2020-09-18 13:11:19 --> Helper loaded: form_helper
INFO - 2020-09-18 13:11:19 --> Database Driver Class Initialized
INFO - 2020-09-18 13:11:19 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:11:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:11:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:11:20 --> Encryption Class Initialized
INFO - 2020-09-18 13:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:11:20 --> Controller Class Initialized
INFO - 2020-09-18 13:11:20 --> Helper loaded: language_helper
INFO - 2020-09-18 13:11:20 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:11:20 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-18 13:11:20 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 13:11:20 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-18 13:11:20 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 13:11:20 --> Final output sent to browser
DEBUG - 2020-09-18 13:11:20 --> Total execution time: 1.3992
INFO - 2020-09-18 13:11:23 --> Config Class Initialized
INFO - 2020-09-18 13:11:23 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:11:23 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:11:23 --> Utf8 Class Initialized
INFO - 2020-09-18 13:11:23 --> URI Class Initialized
INFO - 2020-09-18 13:11:23 --> Router Class Initialized
INFO - 2020-09-18 13:11:23 --> Output Class Initialized
INFO - 2020-09-18 13:11:23 --> Security Class Initialized
DEBUG - 2020-09-18 13:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:11:23 --> Input Class Initialized
INFO - 2020-09-18 13:11:23 --> Language Class Initialized
INFO - 2020-09-18 13:11:23 --> Loader Class Initialized
INFO - 2020-09-18 13:11:23 --> Helper loaded: html_helper
INFO - 2020-09-18 13:11:23 --> Helper loaded: url_helper
INFO - 2020-09-18 13:11:23 --> Helper loaded: form_helper
INFO - 2020-09-18 13:11:23 --> Database Driver Class Initialized
INFO - 2020-09-18 13:11:23 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:11:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:11:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:11:24 --> Encryption Class Initialized
INFO - 2020-09-18 13:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:11:24 --> Controller Class Initialized
INFO - 2020-09-18 13:11:24 --> Helper loaded: language_helper
INFO - 2020-09-18 13:11:24 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:11:24 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 13:11:24 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 13:11:24 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\customer_care.php
INFO - 2020-09-18 13:11:24 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 13:11:24 --> Final output sent to browser
DEBUG - 2020-09-18 13:11:24 --> Total execution time: 1.2484
INFO - 2020-09-18 13:11:35 --> Config Class Initialized
INFO - 2020-09-18 13:11:35 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:11:35 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:11:35 --> Utf8 Class Initialized
INFO - 2020-09-18 13:11:35 --> URI Class Initialized
INFO - 2020-09-18 13:11:35 --> Router Class Initialized
INFO - 2020-09-18 13:11:35 --> Output Class Initialized
INFO - 2020-09-18 13:11:35 --> Security Class Initialized
DEBUG - 2020-09-18 13:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:11:35 --> Input Class Initialized
INFO - 2020-09-18 13:11:35 --> Language Class Initialized
INFO - 2020-09-18 13:11:36 --> Loader Class Initialized
INFO - 2020-09-18 13:11:36 --> Helper loaded: html_helper
INFO - 2020-09-18 13:11:36 --> Helper loaded: url_helper
INFO - 2020-09-18 13:11:36 --> Helper loaded: form_helper
INFO - 2020-09-18 13:11:36 --> Database Driver Class Initialized
INFO - 2020-09-18 13:11:36 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:11:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:11:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:11:36 --> Encryption Class Initialized
INFO - 2020-09-18 13:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:11:36 --> Controller Class Initialized
INFO - 2020-09-18 13:11:36 --> Helper loaded: language_helper
INFO - 2020-09-18 13:11:36 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:11:36 --> Model "Customer_care_model" initialized
INFO - 2020-09-18 13:11:36 --> Final output sent to browser
DEBUG - 2020-09-18 13:11:36 --> Total execution time: 1.1329
INFO - 2020-09-18 13:12:05 --> Config Class Initialized
INFO - 2020-09-18 13:12:05 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:12:05 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:12:05 --> Utf8 Class Initialized
INFO - 2020-09-18 13:12:05 --> URI Class Initialized
INFO - 2020-09-18 13:12:05 --> Router Class Initialized
INFO - 2020-09-18 13:12:05 --> Output Class Initialized
INFO - 2020-09-18 13:12:05 --> Security Class Initialized
DEBUG - 2020-09-18 13:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:12:05 --> Input Class Initialized
INFO - 2020-09-18 13:12:05 --> Language Class Initialized
INFO - 2020-09-18 13:12:05 --> Loader Class Initialized
INFO - 2020-09-18 13:12:05 --> Helper loaded: html_helper
INFO - 2020-09-18 13:12:05 --> Helper loaded: url_helper
INFO - 2020-09-18 13:12:05 --> Helper loaded: form_helper
INFO - 2020-09-18 13:12:05 --> Database Driver Class Initialized
INFO - 2020-09-18 13:12:05 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:12:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:12:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:12:05 --> Encryption Class Initialized
INFO - 2020-09-18 13:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:12:05 --> Controller Class Initialized
INFO - 2020-09-18 13:12:05 --> Helper loaded: language_helper
INFO - 2020-09-18 13:12:06 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:12:06 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 13:12:06 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 13:12:06 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\installation.php
INFO - 2020-09-18 13:12:06 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 13:12:06 --> Final output sent to browser
DEBUG - 2020-09-18 13:12:06 --> Total execution time: 1.1858
INFO - 2020-09-18 13:12:20 --> Config Class Initialized
INFO - 2020-09-18 13:12:20 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:12:20 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:12:20 --> Utf8 Class Initialized
INFO - 2020-09-18 13:12:20 --> URI Class Initialized
INFO - 2020-09-18 13:12:20 --> Router Class Initialized
INFO - 2020-09-18 13:12:20 --> Output Class Initialized
INFO - 2020-09-18 13:12:20 --> Security Class Initialized
DEBUG - 2020-09-18 13:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:12:20 --> Input Class Initialized
INFO - 2020-09-18 13:12:20 --> Language Class Initialized
INFO - 2020-09-18 13:12:20 --> Loader Class Initialized
INFO - 2020-09-18 13:12:20 --> Helper loaded: html_helper
INFO - 2020-09-18 13:12:20 --> Helper loaded: url_helper
INFO - 2020-09-18 13:12:20 --> Helper loaded: form_helper
INFO - 2020-09-18 13:12:20 --> Database Driver Class Initialized
INFO - 2020-09-18 13:12:20 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:12:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:12:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:12:20 --> Encryption Class Initialized
INFO - 2020-09-18 13:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:12:21 --> Controller Class Initialized
INFO - 2020-09-18 13:12:21 --> Helper loaded: language_helper
INFO - 2020-09-18 13:12:21 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:12:21 --> Model "Installation_model" initialized
INFO - 2020-09-18 13:12:21 --> Final output sent to browser
DEBUG - 2020-09-18 13:12:21 --> Total execution time: 1.2720
INFO - 2020-09-18 13:13:11 --> Config Class Initialized
INFO - 2020-09-18 13:13:11 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:13:11 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:13:11 --> Utf8 Class Initialized
INFO - 2020-09-18 13:13:11 --> URI Class Initialized
INFO - 2020-09-18 13:13:11 --> Router Class Initialized
INFO - 2020-09-18 13:13:11 --> Output Class Initialized
INFO - 2020-09-18 13:13:11 --> Security Class Initialized
DEBUG - 2020-09-18 13:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:13:11 --> Input Class Initialized
INFO - 2020-09-18 13:13:11 --> Language Class Initialized
INFO - 2020-09-18 13:13:11 --> Loader Class Initialized
INFO - 2020-09-18 13:13:11 --> Helper loaded: html_helper
INFO - 2020-09-18 13:13:12 --> Helper loaded: url_helper
INFO - 2020-09-18 13:13:12 --> Helper loaded: form_helper
INFO - 2020-09-18 13:13:12 --> Database Driver Class Initialized
INFO - 2020-09-18 13:13:12 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:13:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:13:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:13:12 --> Encryption Class Initialized
INFO - 2020-09-18 13:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:13:12 --> Controller Class Initialized
INFO - 2020-09-18 13:13:12 --> Helper loaded: language_helper
INFO - 2020-09-18 13:13:12 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:13:12 --> Final output sent to browser
DEBUG - 2020-09-18 13:13:12 --> Total execution time: 1.1503
INFO - 2020-09-18 13:13:13 --> Config Class Initialized
INFO - 2020-09-18 13:13:13 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:13:13 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:13:13 --> Utf8 Class Initialized
INFO - 2020-09-18 13:13:13 --> URI Class Initialized
DEBUG - 2020-09-18 13:13:13 --> No URI present. Default controller set.
INFO - 2020-09-18 13:13:13 --> Router Class Initialized
INFO - 2020-09-18 13:13:13 --> Output Class Initialized
INFO - 2020-09-18 13:13:13 --> Security Class Initialized
DEBUG - 2020-09-18 13:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:13:13 --> Input Class Initialized
INFO - 2020-09-18 13:13:13 --> Language Class Initialized
INFO - 2020-09-18 13:13:13 --> Loader Class Initialized
INFO - 2020-09-18 13:13:13 --> Helper loaded: html_helper
INFO - 2020-09-18 13:13:13 --> Helper loaded: url_helper
INFO - 2020-09-18 13:13:13 --> Helper loaded: form_helper
INFO - 2020-09-18 13:13:13 --> Database Driver Class Initialized
INFO - 2020-09-18 13:13:13 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:13:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:13:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:13:13 --> Encryption Class Initialized
INFO - 2020-09-18 13:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:13:13 --> Controller Class Initialized
INFO - 2020-09-18 13:13:13 --> Helper loaded: language_helper
INFO - 2020-09-18 13:13:14 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:13:14 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-18 13:13:14 --> Final output sent to browser
DEBUG - 2020-09-18 13:13:14 --> Total execution time: 1.1375
INFO - 2020-09-18 13:43:14 --> Config Class Initialized
INFO - 2020-09-18 13:43:14 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:43:14 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:43:14 --> Utf8 Class Initialized
INFO - 2020-09-18 13:43:14 --> URI Class Initialized
INFO - 2020-09-18 13:43:14 --> Router Class Initialized
INFO - 2020-09-18 13:43:14 --> Output Class Initialized
INFO - 2020-09-18 13:43:14 --> Security Class Initialized
DEBUG - 2020-09-18 13:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:43:14 --> Input Class Initialized
INFO - 2020-09-18 13:43:14 --> Language Class Initialized
INFO - 2020-09-18 13:43:15 --> Loader Class Initialized
INFO - 2020-09-18 13:43:15 --> Helper loaded: html_helper
INFO - 2020-09-18 13:43:15 --> Helper loaded: url_helper
INFO - 2020-09-18 13:43:15 --> Helper loaded: form_helper
INFO - 2020-09-18 13:43:15 --> Database Driver Class Initialized
INFO - 2020-09-18 13:43:15 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:43:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:43:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:43:15 --> Encryption Class Initialized
INFO - 2020-09-18 13:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:43:15 --> Controller Class Initialized
INFO - 2020-09-18 13:43:15 --> Helper loaded: language_helper
INFO - 2020-09-18 13:43:15 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-18 13:43:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-18 13:43:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-18 13:43:16 --> Model "User" initialized
INFO - 2020-09-18 13:43:16 --> Config Class Initialized
INFO - 2020-09-18 13:43:16 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:43:17 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:43:17 --> Utf8 Class Initialized
INFO - 2020-09-18 13:43:17 --> URI Class Initialized
INFO - 2020-09-18 13:43:17 --> Router Class Initialized
INFO - 2020-09-18 13:43:17 --> Output Class Initialized
INFO - 2020-09-18 13:43:17 --> Security Class Initialized
DEBUG - 2020-09-18 13:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:43:17 --> Input Class Initialized
INFO - 2020-09-18 13:43:17 --> Language Class Initialized
INFO - 2020-09-18 13:43:17 --> Loader Class Initialized
INFO - 2020-09-18 13:43:17 --> Helper loaded: html_helper
INFO - 2020-09-18 13:43:17 --> Helper loaded: url_helper
INFO - 2020-09-18 13:43:17 --> Helper loaded: form_helper
INFO - 2020-09-18 13:43:17 --> Database Driver Class Initialized
INFO - 2020-09-18 13:43:17 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:43:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:43:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:43:17 --> Encryption Class Initialized
INFO - 2020-09-18 13:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:43:17 --> Controller Class Initialized
INFO - 2020-09-18 13:43:17 --> Helper loaded: language_helper
INFO - 2020-09-18 13:43:17 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:43:18 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-18 13:43:18 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 13:43:18 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-18 13:43:18 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 13:43:18 --> Final output sent to browser
DEBUG - 2020-09-18 13:43:18 --> Total execution time: 1.3854
INFO - 2020-09-18 13:43:22 --> Config Class Initialized
INFO - 2020-09-18 13:43:22 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:43:22 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:43:22 --> Utf8 Class Initialized
INFO - 2020-09-18 13:43:23 --> URI Class Initialized
INFO - 2020-09-18 13:43:23 --> Router Class Initialized
INFO - 2020-09-18 13:43:23 --> Output Class Initialized
INFO - 2020-09-18 13:43:23 --> Security Class Initialized
DEBUG - 2020-09-18 13:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:43:23 --> Input Class Initialized
INFO - 2020-09-18 13:43:23 --> Language Class Initialized
INFO - 2020-09-18 13:43:23 --> Loader Class Initialized
INFO - 2020-09-18 13:43:23 --> Helper loaded: html_helper
INFO - 2020-09-18 13:43:23 --> Helper loaded: url_helper
INFO - 2020-09-18 13:43:23 --> Helper loaded: form_helper
INFO - 2020-09-18 13:43:23 --> Database Driver Class Initialized
INFO - 2020-09-18 13:43:23 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:43:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:43:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:43:23 --> Encryption Class Initialized
INFO - 2020-09-18 13:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:43:24 --> Controller Class Initialized
INFO - 2020-09-18 13:43:24 --> Helper loaded: language_helper
INFO - 2020-09-18 13:43:24 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:43:24 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-18 13:43:24 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 13:43:24 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-18 13:43:24 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 13:43:24 --> Final output sent to browser
DEBUG - 2020-09-18 13:43:24 --> Total execution time: 1.9396
INFO - 2020-09-18 13:43:27 --> Config Class Initialized
INFO - 2020-09-18 13:43:27 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:43:27 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:43:27 --> Utf8 Class Initialized
INFO - 2020-09-18 13:43:27 --> URI Class Initialized
INFO - 2020-09-18 13:43:27 --> Router Class Initialized
INFO - 2020-09-18 13:43:27 --> Output Class Initialized
INFO - 2020-09-18 13:43:27 --> Security Class Initialized
DEBUG - 2020-09-18 13:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:43:28 --> Input Class Initialized
INFO - 2020-09-18 13:43:28 --> Language Class Initialized
INFO - 2020-09-18 13:43:28 --> Loader Class Initialized
INFO - 2020-09-18 13:43:28 --> Helper loaded: html_helper
INFO - 2020-09-18 13:43:28 --> Helper loaded: url_helper
INFO - 2020-09-18 13:43:28 --> Helper loaded: form_helper
INFO - 2020-09-18 13:43:28 --> Database Driver Class Initialized
INFO - 2020-09-18 13:43:28 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:43:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:43:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:43:28 --> Encryption Class Initialized
INFO - 2020-09-18 13:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:43:29 --> Controller Class Initialized
INFO - 2020-09-18 13:43:29 --> Helper loaded: language_helper
INFO - 2020-09-18 13:43:29 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:43:29 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-18 13:43:29 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-18 13:43:29 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment_custom.php
INFO - 2020-09-18 13:43:29 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-18 13:43:29 --> Final output sent to browser
DEBUG - 2020-09-18 13:43:29 --> Total execution time: 1.7351
INFO - 2020-09-18 13:43:33 --> Config Class Initialized
INFO - 2020-09-18 13:43:33 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:43:33 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:43:33 --> Utf8 Class Initialized
INFO - 2020-09-18 13:43:33 --> URI Class Initialized
INFO - 2020-09-18 13:43:33 --> Router Class Initialized
INFO - 2020-09-18 13:43:33 --> Output Class Initialized
INFO - 2020-09-18 13:43:33 --> Security Class Initialized
DEBUG - 2020-09-18 13:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:43:33 --> Input Class Initialized
INFO - 2020-09-18 13:43:33 --> Language Class Initialized
INFO - 2020-09-18 13:43:33 --> Loader Class Initialized
INFO - 2020-09-18 13:43:33 --> Helper loaded: html_helper
INFO - 2020-09-18 13:43:34 --> Helper loaded: url_helper
INFO - 2020-09-18 13:43:34 --> Helper loaded: form_helper
INFO - 2020-09-18 13:43:34 --> Database Driver Class Initialized
INFO - 2020-09-18 13:43:34 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:43:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:43:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:43:34 --> Encryption Class Initialized
INFO - 2020-09-18 13:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:43:34 --> Controller Class Initialized
INFO - 2020-09-18 13:43:34 --> Helper loaded: language_helper
INFO - 2020-09-18 13:43:34 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:43:34 --> Final output sent to browser
DEBUG - 2020-09-18 13:43:34 --> Total execution time: 1.0683
INFO - 2020-09-18 13:43:35 --> Config Class Initialized
INFO - 2020-09-18 13:43:35 --> Hooks Class Initialized
DEBUG - 2020-09-18 13:43:35 --> UTF-8 Support Enabled
INFO - 2020-09-18 13:43:35 --> Utf8 Class Initialized
INFO - 2020-09-18 13:43:35 --> URI Class Initialized
DEBUG - 2020-09-18 13:43:35 --> No URI present. Default controller set.
INFO - 2020-09-18 13:43:35 --> Router Class Initialized
INFO - 2020-09-18 13:43:35 --> Output Class Initialized
INFO - 2020-09-18 13:43:35 --> Security Class Initialized
DEBUG - 2020-09-18 13:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 13:43:35 --> Input Class Initialized
INFO - 2020-09-18 13:43:35 --> Language Class Initialized
INFO - 2020-09-18 13:43:35 --> Loader Class Initialized
INFO - 2020-09-18 13:43:35 --> Helper loaded: html_helper
INFO - 2020-09-18 13:43:35 --> Helper loaded: url_helper
INFO - 2020-09-18 13:43:35 --> Helper loaded: form_helper
INFO - 2020-09-18 13:43:35 --> Database Driver Class Initialized
INFO - 2020-09-18 13:43:35 --> Form Validation Class Initialized
DEBUG - 2020-09-18 13:43:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-18 13:43:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-18 13:43:35 --> Encryption Class Initialized
INFO - 2020-09-18 13:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 13:43:35 --> Controller Class Initialized
INFO - 2020-09-18 13:43:36 --> Helper loaded: language_helper
INFO - 2020-09-18 13:43:36 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-18 13:43:36 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-18 13:43:36 --> Final output sent to browser
DEBUG - 2020-09-18 13:43:36 --> Total execution time: 1.1696
