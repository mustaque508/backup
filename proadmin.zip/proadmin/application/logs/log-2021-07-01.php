<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-01 06:37:00 --> Config Class Initialized
INFO - 2021-07-01 06:37:00 --> Hooks Class Initialized
DEBUG - 2021-07-01 06:37:00 --> UTF-8 Support Enabled
INFO - 2021-07-01 06:37:00 --> Utf8 Class Initialized
INFO - 2021-07-01 06:37:01 --> URI Class Initialized
INFO - 2021-07-01 06:37:02 --> Router Class Initialized
INFO - 2021-07-01 06:37:02 --> Output Class Initialized
INFO - 2021-07-01 06:37:02 --> Security Class Initialized
DEBUG - 2021-07-01 06:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 06:37:02 --> Input Class Initialized
INFO - 2021-07-01 06:37:02 --> Language Class Initialized
INFO - 2021-07-01 06:37:02 --> Loader Class Initialized
INFO - 2021-07-01 06:37:02 --> Helper loaded: html_helper
INFO - 2021-07-01 06:37:02 --> Helper loaded: url_helper
INFO - 2021-07-01 06:37:02 --> Helper loaded: form_helper
INFO - 2021-07-01 06:37:02 --> Database Driver Class Initialized
INFO - 2021-07-01 06:37:03 --> Form Validation Class Initialized
DEBUG - 2021-07-01 06:37:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:37:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 06:37:03 --> Encryption Class Initialized
INFO - 2021-07-01 06:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:37:03 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:37:03 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:37:03 --> Model "user_model" initialized
INFO - 2021-07-01 06:37:03 --> Model "role_model" initialized
INFO - 2021-07-01 06:37:03 --> Controller Class Initialized
INFO - 2021-07-01 06:37:04 --> Helper loaded: language_helper
INFO - 2021-07-01 06:37:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 06:37:04 --> Model "Customer_model" initialized
INFO - 2021-07-01 06:37:04 --> Model "Product_model" initialized
INFO - 2021-07-01 06:37:04 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 06:37:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 06:37:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 06:37:04 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 06:37:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 06:37:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 06:37:04 --> Final output sent to browser
DEBUG - 2021-07-01 06:37:04 --> Total execution time: 4.2941
INFO - 2021-07-01 06:37:08 --> Config Class Initialized
INFO - 2021-07-01 06:37:08 --> Hooks Class Initialized
DEBUG - 2021-07-01 06:37:08 --> UTF-8 Support Enabled
INFO - 2021-07-01 06:37:08 --> Utf8 Class Initialized
INFO - 2021-07-01 06:37:08 --> URI Class Initialized
INFO - 2021-07-01 06:37:08 --> Router Class Initialized
INFO - 2021-07-01 06:37:08 --> Output Class Initialized
INFO - 2021-07-01 06:37:08 --> Security Class Initialized
DEBUG - 2021-07-01 06:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 06:37:08 --> Input Class Initialized
INFO - 2021-07-01 06:37:08 --> Language Class Initialized
INFO - 2021-07-01 06:37:08 --> Loader Class Initialized
INFO - 2021-07-01 06:37:08 --> Helper loaded: html_helper
INFO - 2021-07-01 06:37:08 --> Helper loaded: url_helper
INFO - 2021-07-01 06:37:08 --> Helper loaded: form_helper
INFO - 2021-07-01 06:37:08 --> Database Driver Class Initialized
INFO - 2021-07-01 06:37:08 --> Form Validation Class Initialized
DEBUG - 2021-07-01 06:37:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:37:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 06:37:08 --> Encryption Class Initialized
INFO - 2021-07-01 06:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:37:08 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:37:08 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:37:08 --> Model "user_model" initialized
INFO - 2021-07-01 06:37:08 --> Model "role_model" initialized
INFO - 2021-07-01 06:37:08 --> Controller Class Initialized
INFO - 2021-07-01 06:37:08 --> Helper loaded: language_helper
INFO - 2021-07-01 06:37:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 06:37:08 --> Final output sent to browser
DEBUG - 2021-07-01 06:37:08 --> Total execution time: 0.1534
INFO - 2021-07-01 06:37:08 --> Config Class Initialized
INFO - 2021-07-01 06:37:08 --> Hooks Class Initialized
DEBUG - 2021-07-01 06:37:08 --> UTF-8 Support Enabled
INFO - 2021-07-01 06:37:08 --> Utf8 Class Initialized
INFO - 2021-07-01 06:37:08 --> URI Class Initialized
DEBUG - 2021-07-01 06:37:08 --> No URI present. Default controller set.
INFO - 2021-07-01 06:37:08 --> Router Class Initialized
INFO - 2021-07-01 06:37:08 --> Output Class Initialized
INFO - 2021-07-01 06:37:08 --> Security Class Initialized
DEBUG - 2021-07-01 06:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 06:37:08 --> Input Class Initialized
INFO - 2021-07-01 06:37:08 --> Language Class Initialized
INFO - 2021-07-01 06:37:08 --> Loader Class Initialized
INFO - 2021-07-01 06:37:08 --> Helper loaded: html_helper
INFO - 2021-07-01 06:37:08 --> Helper loaded: url_helper
INFO - 2021-07-01 06:37:08 --> Helper loaded: form_helper
INFO - 2021-07-01 06:37:08 --> Database Driver Class Initialized
INFO - 2021-07-01 06:37:08 --> Form Validation Class Initialized
DEBUG - 2021-07-01 06:37:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:37:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 06:37:08 --> Encryption Class Initialized
INFO - 2021-07-01 06:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:37:08 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:37:08 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:37:08 --> Model "user_model" initialized
INFO - 2021-07-01 06:37:08 --> Model "role_model" initialized
INFO - 2021-07-01 06:37:08 --> Controller Class Initialized
INFO - 2021-07-01 06:37:08 --> Helper loaded: language_helper
INFO - 2021-07-01 06:37:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 06:37:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\login.php
INFO - 2021-07-01 06:37:08 --> Final output sent to browser
DEBUG - 2021-07-01 06:37:08 --> Total execution time: 0.2014
INFO - 2021-07-01 06:37:17 --> Config Class Initialized
INFO - 2021-07-01 06:37:17 --> Hooks Class Initialized
DEBUG - 2021-07-01 06:37:17 --> UTF-8 Support Enabled
INFO - 2021-07-01 06:37:17 --> Utf8 Class Initialized
INFO - 2021-07-01 06:37:17 --> URI Class Initialized
INFO - 2021-07-01 06:37:17 --> Router Class Initialized
INFO - 2021-07-01 06:37:17 --> Output Class Initialized
INFO - 2021-07-01 06:37:17 --> Security Class Initialized
DEBUG - 2021-07-01 06:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 06:37:17 --> Input Class Initialized
INFO - 2021-07-01 06:37:17 --> Language Class Initialized
INFO - 2021-07-01 06:37:17 --> Loader Class Initialized
INFO - 2021-07-01 06:37:17 --> Helper loaded: html_helper
INFO - 2021-07-01 06:37:17 --> Helper loaded: url_helper
INFO - 2021-07-01 06:37:17 --> Helper loaded: form_helper
INFO - 2021-07-01 06:37:17 --> Database Driver Class Initialized
INFO - 2021-07-01 06:37:17 --> Form Validation Class Initialized
DEBUG - 2021-07-01 06:37:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:37:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 06:37:17 --> Encryption Class Initialized
INFO - 2021-07-01 06:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:37:17 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:37:17 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:37:17 --> Model "user_model" initialized
INFO - 2021-07-01 06:37:17 --> Model "role_model" initialized
INFO - 2021-07-01 06:37:17 --> Controller Class Initialized
INFO - 2021-07-01 06:37:17 --> Helper loaded: language_helper
INFO - 2021-07-01 06:37:17 --> Language file loaded: language/english/content_lang.php
DEBUG - 2021-07-01 06:37:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-01 06:37:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-07-01 06:37:17 --> Model "User" initialized
INFO - 2021-07-01 06:37:17 --> Config Class Initialized
INFO - 2021-07-01 06:37:17 --> Hooks Class Initialized
DEBUG - 2021-07-01 06:37:17 --> UTF-8 Support Enabled
INFO - 2021-07-01 06:37:17 --> Utf8 Class Initialized
INFO - 2021-07-01 06:37:17 --> URI Class Initialized
INFO - 2021-07-01 06:37:17 --> Router Class Initialized
INFO - 2021-07-01 06:37:17 --> Output Class Initialized
INFO - 2021-07-01 06:37:17 --> Security Class Initialized
DEBUG - 2021-07-01 06:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 06:37:17 --> Input Class Initialized
INFO - 2021-07-01 06:37:17 --> Language Class Initialized
INFO - 2021-07-01 06:37:17 --> Loader Class Initialized
INFO - 2021-07-01 06:37:17 --> Helper loaded: html_helper
INFO - 2021-07-01 06:37:17 --> Helper loaded: url_helper
INFO - 2021-07-01 06:37:17 --> Helper loaded: form_helper
INFO - 2021-07-01 06:37:17 --> Database Driver Class Initialized
INFO - 2021-07-01 06:37:17 --> Form Validation Class Initialized
DEBUG - 2021-07-01 06:37:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:37:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 06:37:17 --> Encryption Class Initialized
INFO - 2021-07-01 06:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:37:17 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:37:17 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:37:17 --> Model "user_model" initialized
INFO - 2021-07-01 06:37:17 --> Model "role_model" initialized
INFO - 2021-07-01 06:37:17 --> Controller Class Initialized
INFO - 2021-07-01 06:37:17 --> Helper loaded: language_helper
INFO - 2021-07-01 06:37:17 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 06:37:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-01 06:37:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-01 06:37:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-01 06:37:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 06:37:17 --> Final output sent to browser
DEBUG - 2021-07-01 06:37:17 --> Total execution time: 0.1894
INFO - 2021-07-01 06:38:23 --> Config Class Initialized
INFO - 2021-07-01 06:38:23 --> Hooks Class Initialized
DEBUG - 2021-07-01 06:38:23 --> UTF-8 Support Enabled
INFO - 2021-07-01 06:38:23 --> Utf8 Class Initialized
INFO - 2021-07-01 06:38:23 --> URI Class Initialized
INFO - 2021-07-01 06:38:23 --> Router Class Initialized
INFO - 2021-07-01 06:38:23 --> Output Class Initialized
INFO - 2021-07-01 06:38:23 --> Security Class Initialized
DEBUG - 2021-07-01 06:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 06:38:23 --> Input Class Initialized
INFO - 2021-07-01 06:38:23 --> Language Class Initialized
INFO - 2021-07-01 06:38:23 --> Loader Class Initialized
INFO - 2021-07-01 06:38:23 --> Helper loaded: html_helper
INFO - 2021-07-01 06:38:23 --> Helper loaded: url_helper
INFO - 2021-07-01 06:38:23 --> Helper loaded: form_helper
INFO - 2021-07-01 06:38:23 --> Database Driver Class Initialized
INFO - 2021-07-01 06:38:23 --> Form Validation Class Initialized
DEBUG - 2021-07-01 06:38:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:38:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 06:38:23 --> Encryption Class Initialized
INFO - 2021-07-01 06:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:38:23 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:38:23 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:38:23 --> Model "user_model" initialized
INFO - 2021-07-01 06:38:23 --> Model "role_model" initialized
INFO - 2021-07-01 06:38:23 --> Controller Class Initialized
INFO - 2021-07-01 06:38:23 --> Helper loaded: language_helper
INFO - 2021-07-01 06:38:23 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 06:38:23 --> Model "Customer_model" initialized
INFO - 2021-07-01 06:38:23 --> Model "Product_model" initialized
INFO - 2021-07-01 06:38:23 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 06:38:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 06:38:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 06:38:23 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 06:38:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 06:38:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 06:38:23 --> Final output sent to browser
DEBUG - 2021-07-01 06:38:23 --> Total execution time: 0.0747
INFO - 2021-07-01 06:38:29 --> Config Class Initialized
INFO - 2021-07-01 06:38:29 --> Hooks Class Initialized
DEBUG - 2021-07-01 06:38:29 --> UTF-8 Support Enabled
INFO - 2021-07-01 06:38:29 --> Utf8 Class Initialized
INFO - 2021-07-01 06:38:29 --> URI Class Initialized
INFO - 2021-07-01 06:38:29 --> Router Class Initialized
INFO - 2021-07-01 06:38:29 --> Output Class Initialized
INFO - 2021-07-01 06:38:29 --> Security Class Initialized
DEBUG - 2021-07-01 06:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 06:38:29 --> Input Class Initialized
INFO - 2021-07-01 06:38:29 --> Language Class Initialized
INFO - 2021-07-01 06:38:29 --> Loader Class Initialized
INFO - 2021-07-01 06:38:29 --> Helper loaded: html_helper
INFO - 2021-07-01 06:38:29 --> Helper loaded: url_helper
INFO - 2021-07-01 06:38:29 --> Helper loaded: form_helper
INFO - 2021-07-01 06:38:29 --> Database Driver Class Initialized
INFO - 2021-07-01 06:38:29 --> Form Validation Class Initialized
DEBUG - 2021-07-01 06:38:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:38:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 06:38:29 --> Encryption Class Initialized
INFO - 2021-07-01 06:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:38:29 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:38:29 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:38:29 --> Model "user_model" initialized
INFO - 2021-07-01 06:38:29 --> Model "role_model" initialized
INFO - 2021-07-01 06:38:29 --> Controller Class Initialized
INFO - 2021-07-01 06:38:29 --> Helper loaded: language_helper
INFO - 2021-07-01 06:38:29 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 06:38:29 --> Model "Customer_model" initialized
INFO - 2021-07-01 06:38:29 --> Final output sent to browser
DEBUG - 2021-07-01 06:38:29 --> Total execution time: 0.0767
INFO - 2021-07-01 06:40:47 --> Config Class Initialized
INFO - 2021-07-01 06:40:47 --> Hooks Class Initialized
DEBUG - 2021-07-01 06:40:47 --> UTF-8 Support Enabled
INFO - 2021-07-01 06:40:47 --> Utf8 Class Initialized
INFO - 2021-07-01 06:40:47 --> URI Class Initialized
INFO - 2021-07-01 06:40:47 --> Router Class Initialized
INFO - 2021-07-01 06:40:47 --> Output Class Initialized
INFO - 2021-07-01 06:40:47 --> Security Class Initialized
DEBUG - 2021-07-01 06:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 06:40:47 --> Input Class Initialized
INFO - 2021-07-01 06:40:47 --> Language Class Initialized
INFO - 2021-07-01 06:40:47 --> Loader Class Initialized
INFO - 2021-07-01 06:40:47 --> Helper loaded: html_helper
INFO - 2021-07-01 06:40:47 --> Helper loaded: url_helper
INFO - 2021-07-01 06:40:47 --> Helper loaded: form_helper
INFO - 2021-07-01 06:40:47 --> Database Driver Class Initialized
INFO - 2021-07-01 06:40:47 --> Form Validation Class Initialized
DEBUG - 2021-07-01 06:40:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:40:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 06:40:47 --> Encryption Class Initialized
INFO - 2021-07-01 06:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:40:47 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:40:47 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:40:47 --> Model "user_model" initialized
INFO - 2021-07-01 06:40:47 --> Model "role_model" initialized
INFO - 2021-07-01 06:40:47 --> Controller Class Initialized
INFO - 2021-07-01 06:40:47 --> Helper loaded: language_helper
INFO - 2021-07-01 06:40:47 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 06:40:47 --> Model "Customer_model" initialized
INFO - 2021-07-01 06:40:47 --> Model "Product_model" initialized
INFO - 2021-07-01 06:40:47 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 06:40:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 06:40:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 06:40:47 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 06:40:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 06:40:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 06:40:47 --> Final output sent to browser
DEBUG - 2021-07-01 06:40:47 --> Total execution time: 0.0793
INFO - 2021-07-01 06:42:18 --> Config Class Initialized
INFO - 2021-07-01 06:42:18 --> Hooks Class Initialized
DEBUG - 2021-07-01 06:42:18 --> UTF-8 Support Enabled
INFO - 2021-07-01 06:42:18 --> Utf8 Class Initialized
INFO - 2021-07-01 06:42:18 --> URI Class Initialized
INFO - 2021-07-01 06:42:18 --> Router Class Initialized
INFO - 2021-07-01 06:42:18 --> Output Class Initialized
INFO - 2021-07-01 06:42:18 --> Security Class Initialized
DEBUG - 2021-07-01 06:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 06:42:18 --> Input Class Initialized
INFO - 2021-07-01 06:42:18 --> Language Class Initialized
INFO - 2021-07-01 06:42:18 --> Loader Class Initialized
INFO - 2021-07-01 06:42:18 --> Helper loaded: html_helper
INFO - 2021-07-01 06:42:18 --> Helper loaded: url_helper
INFO - 2021-07-01 06:42:18 --> Helper loaded: form_helper
INFO - 2021-07-01 06:42:18 --> Database Driver Class Initialized
INFO - 2021-07-01 06:42:18 --> Form Validation Class Initialized
DEBUG - 2021-07-01 06:42:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:42:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 06:42:18 --> Encryption Class Initialized
INFO - 2021-07-01 06:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:42:18 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:42:18 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:42:18 --> Model "user_model" initialized
INFO - 2021-07-01 06:42:18 --> Model "role_model" initialized
INFO - 2021-07-01 06:42:18 --> Controller Class Initialized
INFO - 2021-07-01 06:42:18 --> Helper loaded: language_helper
INFO - 2021-07-01 06:42:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 06:42:18 --> Model "Customer_model" initialized
INFO - 2021-07-01 06:42:18 --> Model "Product_model" initialized
INFO - 2021-07-01 06:42:18 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 06:42:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 06:42:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 06:42:18 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 06:42:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 06:42:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 06:42:18 --> Final output sent to browser
DEBUG - 2021-07-01 06:42:18 --> Total execution time: 0.0821
INFO - 2021-07-01 06:42:19 --> Config Class Initialized
INFO - 2021-07-01 06:42:19 --> Hooks Class Initialized
DEBUG - 2021-07-01 06:42:19 --> UTF-8 Support Enabled
INFO - 2021-07-01 06:42:19 --> Utf8 Class Initialized
INFO - 2021-07-01 06:42:19 --> URI Class Initialized
INFO - 2021-07-01 06:42:19 --> Router Class Initialized
INFO - 2021-07-01 06:42:19 --> Output Class Initialized
INFO - 2021-07-01 06:42:19 --> Security Class Initialized
DEBUG - 2021-07-01 06:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 06:42:19 --> Input Class Initialized
INFO - 2021-07-01 06:42:19 --> Language Class Initialized
INFO - 2021-07-01 06:42:19 --> Loader Class Initialized
INFO - 2021-07-01 06:42:19 --> Helper loaded: html_helper
INFO - 2021-07-01 06:42:19 --> Helper loaded: url_helper
INFO - 2021-07-01 06:42:19 --> Helper loaded: form_helper
INFO - 2021-07-01 06:42:19 --> Database Driver Class Initialized
INFO - 2021-07-01 06:42:19 --> Form Validation Class Initialized
DEBUG - 2021-07-01 06:42:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:42:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 06:42:19 --> Encryption Class Initialized
INFO - 2021-07-01 06:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:42:19 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:42:19 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:42:19 --> Model "user_model" initialized
INFO - 2021-07-01 06:42:19 --> Model "role_model" initialized
INFO - 2021-07-01 06:42:19 --> Controller Class Initialized
INFO - 2021-07-01 06:42:19 --> Helper loaded: language_helper
INFO - 2021-07-01 06:42:19 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 06:42:19 --> Model "Customer_model" initialized
INFO - 2021-07-01 06:42:19 --> Model "Product_model" initialized
INFO - 2021-07-01 06:42:19 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 06:42:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 06:42:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 06:42:19 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 06:42:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 06:42:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 06:42:19 --> Final output sent to browser
DEBUG - 2021-07-01 06:42:19 --> Total execution time: 0.0899
INFO - 2021-07-01 06:43:15 --> Config Class Initialized
INFO - 2021-07-01 06:43:15 --> Hooks Class Initialized
DEBUG - 2021-07-01 06:43:15 --> UTF-8 Support Enabled
INFO - 2021-07-01 06:43:15 --> Utf8 Class Initialized
INFO - 2021-07-01 06:43:15 --> URI Class Initialized
INFO - 2021-07-01 06:43:15 --> Router Class Initialized
INFO - 2021-07-01 06:43:15 --> Output Class Initialized
INFO - 2021-07-01 06:43:15 --> Security Class Initialized
DEBUG - 2021-07-01 06:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 06:43:15 --> Input Class Initialized
INFO - 2021-07-01 06:43:15 --> Language Class Initialized
INFO - 2021-07-01 06:43:15 --> Loader Class Initialized
INFO - 2021-07-01 06:43:16 --> Helper loaded: html_helper
INFO - 2021-07-01 06:43:16 --> Helper loaded: url_helper
INFO - 2021-07-01 06:43:16 --> Helper loaded: form_helper
INFO - 2021-07-01 06:43:16 --> Database Driver Class Initialized
INFO - 2021-07-01 06:43:16 --> Form Validation Class Initialized
DEBUG - 2021-07-01 06:43:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:43:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 06:43:16 --> Encryption Class Initialized
INFO - 2021-07-01 06:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:43:16 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:43:16 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:43:16 --> Model "user_model" initialized
INFO - 2021-07-01 06:43:16 --> Model "role_model" initialized
INFO - 2021-07-01 06:43:16 --> Controller Class Initialized
INFO - 2021-07-01 06:43:16 --> Helper loaded: language_helper
INFO - 2021-07-01 06:43:16 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 06:43:16 --> Model "Customer_model" initialized
INFO - 2021-07-01 06:43:16 --> Final output sent to browser
DEBUG - 2021-07-01 06:43:16 --> Total execution time: 0.0757
INFO - 2021-07-01 06:43:21 --> Config Class Initialized
INFO - 2021-07-01 06:43:21 --> Hooks Class Initialized
DEBUG - 2021-07-01 06:43:21 --> UTF-8 Support Enabled
INFO - 2021-07-01 06:43:21 --> Utf8 Class Initialized
INFO - 2021-07-01 06:43:21 --> URI Class Initialized
INFO - 2021-07-01 06:43:21 --> Router Class Initialized
INFO - 2021-07-01 06:43:21 --> Output Class Initialized
INFO - 2021-07-01 06:43:21 --> Security Class Initialized
DEBUG - 2021-07-01 06:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 06:43:21 --> Input Class Initialized
INFO - 2021-07-01 06:43:21 --> Language Class Initialized
INFO - 2021-07-01 06:43:21 --> Loader Class Initialized
INFO - 2021-07-01 06:43:21 --> Helper loaded: html_helper
INFO - 2021-07-01 06:43:21 --> Helper loaded: url_helper
INFO - 2021-07-01 06:43:21 --> Helper loaded: form_helper
INFO - 2021-07-01 06:43:21 --> Database Driver Class Initialized
INFO - 2021-07-01 06:43:21 --> Form Validation Class Initialized
DEBUG - 2021-07-01 06:43:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:43:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 06:43:21 --> Encryption Class Initialized
INFO - 2021-07-01 06:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:43:21 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:43:21 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:43:21 --> Model "user_model" initialized
INFO - 2021-07-01 06:43:21 --> Model "role_model" initialized
INFO - 2021-07-01 06:43:21 --> Controller Class Initialized
INFO - 2021-07-01 06:43:21 --> Helper loaded: language_helper
INFO - 2021-07-01 06:43:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 06:43:21 --> Model "Customer_model" initialized
INFO - 2021-07-01 06:43:21 --> Final output sent to browser
DEBUG - 2021-07-01 06:43:21 --> Total execution time: 0.0600
INFO - 2021-07-01 06:43:25 --> Config Class Initialized
INFO - 2021-07-01 06:43:25 --> Hooks Class Initialized
DEBUG - 2021-07-01 06:43:25 --> UTF-8 Support Enabled
INFO - 2021-07-01 06:43:25 --> Utf8 Class Initialized
INFO - 2021-07-01 06:43:25 --> URI Class Initialized
INFO - 2021-07-01 06:43:25 --> Router Class Initialized
INFO - 2021-07-01 06:43:25 --> Output Class Initialized
INFO - 2021-07-01 06:43:25 --> Security Class Initialized
DEBUG - 2021-07-01 06:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 06:43:25 --> Input Class Initialized
INFO - 2021-07-01 06:43:25 --> Language Class Initialized
INFO - 2021-07-01 06:43:25 --> Loader Class Initialized
INFO - 2021-07-01 06:43:25 --> Helper loaded: html_helper
INFO - 2021-07-01 06:43:25 --> Helper loaded: url_helper
INFO - 2021-07-01 06:43:25 --> Helper loaded: form_helper
INFO - 2021-07-01 06:43:25 --> Database Driver Class Initialized
INFO - 2021-07-01 06:43:25 --> Form Validation Class Initialized
DEBUG - 2021-07-01 06:43:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:43:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 06:43:25 --> Encryption Class Initialized
INFO - 2021-07-01 06:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:43:25 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:43:25 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:43:25 --> Model "user_model" initialized
INFO - 2021-07-01 06:43:25 --> Model "role_model" initialized
INFO - 2021-07-01 06:43:25 --> Controller Class Initialized
INFO - 2021-07-01 06:43:25 --> Helper loaded: language_helper
INFO - 2021-07-01 06:43:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 06:43:25 --> Model "Customer_model" initialized
INFO - 2021-07-01 06:43:25 --> Final output sent to browser
DEBUG - 2021-07-01 06:43:25 --> Total execution time: 0.0607
INFO - 2021-07-01 06:43:53 --> Config Class Initialized
INFO - 2021-07-01 06:43:53 --> Hooks Class Initialized
DEBUG - 2021-07-01 06:43:53 --> UTF-8 Support Enabled
INFO - 2021-07-01 06:43:53 --> Utf8 Class Initialized
INFO - 2021-07-01 06:43:53 --> URI Class Initialized
INFO - 2021-07-01 06:43:53 --> Router Class Initialized
INFO - 2021-07-01 06:43:53 --> Output Class Initialized
INFO - 2021-07-01 06:43:53 --> Security Class Initialized
DEBUG - 2021-07-01 06:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 06:43:53 --> Input Class Initialized
INFO - 2021-07-01 06:43:53 --> Language Class Initialized
INFO - 2021-07-01 06:43:53 --> Loader Class Initialized
INFO - 2021-07-01 06:43:53 --> Helper loaded: html_helper
INFO - 2021-07-01 06:43:53 --> Helper loaded: url_helper
INFO - 2021-07-01 06:43:53 --> Helper loaded: form_helper
INFO - 2021-07-01 06:43:53 --> Database Driver Class Initialized
INFO - 2021-07-01 06:43:53 --> Form Validation Class Initialized
DEBUG - 2021-07-01 06:43:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:43:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 06:43:53 --> Encryption Class Initialized
INFO - 2021-07-01 06:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:43:53 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:43:53 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:43:53 --> Model "user_model" initialized
INFO - 2021-07-01 06:43:53 --> Model "role_model" initialized
INFO - 2021-07-01 06:43:53 --> Controller Class Initialized
INFO - 2021-07-01 06:43:53 --> Helper loaded: language_helper
INFO - 2021-07-01 06:43:53 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 06:43:53 --> Model "Product_model" initialized
INFO - 2021-07-01 06:43:53 --> Final output sent to browser
DEBUG - 2021-07-01 06:43:53 --> Total execution time: 0.0794
INFO - 2021-07-01 06:44:10 --> Config Class Initialized
INFO - 2021-07-01 06:44:10 --> Hooks Class Initialized
DEBUG - 2021-07-01 06:44:10 --> UTF-8 Support Enabled
INFO - 2021-07-01 06:44:10 --> Utf8 Class Initialized
INFO - 2021-07-01 06:44:10 --> URI Class Initialized
INFO - 2021-07-01 06:44:10 --> Router Class Initialized
INFO - 2021-07-01 06:44:10 --> Output Class Initialized
INFO - 2021-07-01 06:44:10 --> Security Class Initialized
DEBUG - 2021-07-01 06:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 06:44:10 --> Input Class Initialized
INFO - 2021-07-01 06:44:10 --> Language Class Initialized
INFO - 2021-07-01 06:44:10 --> Loader Class Initialized
INFO - 2021-07-01 06:44:10 --> Helper loaded: html_helper
INFO - 2021-07-01 06:44:10 --> Helper loaded: url_helper
INFO - 2021-07-01 06:44:10 --> Helper loaded: form_helper
INFO - 2021-07-01 06:44:10 --> Database Driver Class Initialized
INFO - 2021-07-01 06:44:10 --> Form Validation Class Initialized
DEBUG - 2021-07-01 06:44:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:44:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 06:44:10 --> Encryption Class Initialized
INFO - 2021-07-01 06:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:44:10 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:44:10 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:44:10 --> Model "user_model" initialized
INFO - 2021-07-01 06:44:10 --> Model "role_model" initialized
INFO - 2021-07-01 06:44:10 --> Controller Class Initialized
INFO - 2021-07-01 06:44:10 --> Helper loaded: language_helper
INFO - 2021-07-01 06:44:10 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 06:44:10 --> Model "Quotation_model" initialized
INFO - 2021-07-01 06:44:10 --> Final output sent to browser
DEBUG - 2021-07-01 06:44:10 --> Total execution time: 0.0942
INFO - 2021-07-01 06:44:10 --> Config Class Initialized
INFO - 2021-07-01 06:44:10 --> Hooks Class Initialized
DEBUG - 2021-07-01 06:44:10 --> UTF-8 Support Enabled
INFO - 2021-07-01 06:44:10 --> Utf8 Class Initialized
INFO - 2021-07-01 06:44:10 --> URI Class Initialized
INFO - 2021-07-01 06:44:10 --> Router Class Initialized
INFO - 2021-07-01 06:44:10 --> Output Class Initialized
INFO - 2021-07-01 06:44:10 --> Security Class Initialized
DEBUG - 2021-07-01 06:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 06:44:10 --> Input Class Initialized
INFO - 2021-07-01 06:44:10 --> Language Class Initialized
INFO - 2021-07-01 06:44:10 --> Loader Class Initialized
INFO - 2021-07-01 06:44:10 --> Helper loaded: html_helper
INFO - 2021-07-01 06:44:10 --> Helper loaded: url_helper
INFO - 2021-07-01 06:44:10 --> Helper loaded: form_helper
INFO - 2021-07-01 06:44:10 --> Database Driver Class Initialized
INFO - 2021-07-01 06:44:10 --> Form Validation Class Initialized
DEBUG - 2021-07-01 06:44:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:44:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 06:44:10 --> Encryption Class Initialized
INFO - 2021-07-01 06:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:44:10 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:44:10 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:44:10 --> Model "user_model" initialized
INFO - 2021-07-01 06:44:10 --> Model "role_model" initialized
INFO - 2021-07-01 06:44:10 --> Controller Class Initialized
INFO - 2021-07-01 06:44:10 --> Helper loaded: language_helper
INFO - 2021-07-01 06:44:10 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 06:44:10 --> Model "Quotation_model" initialized
INFO - 2021-07-01 06:44:10 --> Final output sent to browser
DEBUG - 2021-07-01 06:44:10 --> Total execution time: 0.0695
INFO - 2021-07-01 06:44:12 --> Config Class Initialized
INFO - 2021-07-01 06:44:12 --> Hooks Class Initialized
DEBUG - 2021-07-01 06:44:12 --> UTF-8 Support Enabled
INFO - 2021-07-01 06:44:12 --> Utf8 Class Initialized
INFO - 2021-07-01 06:44:12 --> URI Class Initialized
INFO - 2021-07-01 06:44:12 --> Router Class Initialized
INFO - 2021-07-01 06:44:12 --> Output Class Initialized
INFO - 2021-07-01 06:44:12 --> Security Class Initialized
DEBUG - 2021-07-01 06:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 06:44:12 --> Input Class Initialized
INFO - 2021-07-01 06:44:12 --> Language Class Initialized
INFO - 2021-07-01 06:44:12 --> Loader Class Initialized
INFO - 2021-07-01 06:44:12 --> Helper loaded: html_helper
INFO - 2021-07-01 06:44:12 --> Helper loaded: url_helper
INFO - 2021-07-01 06:44:12 --> Helper loaded: form_helper
INFO - 2021-07-01 06:44:12 --> Database Driver Class Initialized
INFO - 2021-07-01 06:44:12 --> Form Validation Class Initialized
DEBUG - 2021-07-01 06:44:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:44:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 06:44:12 --> Encryption Class Initialized
INFO - 2021-07-01 06:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:44:12 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:44:12 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:44:12 --> Model "user_model" initialized
INFO - 2021-07-01 06:44:12 --> Model "role_model" initialized
INFO - 2021-07-01 06:44:12 --> Controller Class Initialized
INFO - 2021-07-01 06:44:12 --> Helper loaded: language_helper
INFO - 2021-07-01 06:44:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 06:44:12 --> Model "Quotation_model" initialized
INFO - 2021-07-01 06:44:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 06:44:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 06:44:12 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 06:44:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 06:44:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 06:44:12 --> Final output sent to browser
DEBUG - 2021-07-01 06:44:12 --> Total execution time: 0.1958
INFO - 2021-07-01 06:44:13 --> Config Class Initialized
INFO - 2021-07-01 06:44:13 --> Hooks Class Initialized
INFO - 2021-07-01 06:44:13 --> Config Class Initialized
INFO - 2021-07-01 06:44:13 --> Hooks Class Initialized
DEBUG - 2021-07-01 06:44:13 --> UTF-8 Support Enabled
INFO - 2021-07-01 06:44:13 --> Utf8 Class Initialized
INFO - 2021-07-01 06:44:13 --> URI Class Initialized
DEBUG - 2021-07-01 06:44:13 --> UTF-8 Support Enabled
INFO - 2021-07-01 06:44:13 --> Utf8 Class Initialized
INFO - 2021-07-01 06:44:13 --> URI Class Initialized
INFO - 2021-07-01 06:44:13 --> Router Class Initialized
INFO - 2021-07-01 06:44:13 --> Router Class Initialized
INFO - 2021-07-01 06:44:13 --> Output Class Initialized
INFO - 2021-07-01 06:44:13 --> Output Class Initialized
INFO - 2021-07-01 06:44:13 --> Security Class Initialized
DEBUG - 2021-07-01 06:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 06:44:13 --> Security Class Initialized
INFO - 2021-07-01 06:44:13 --> Input Class Initialized
INFO - 2021-07-01 06:44:13 --> Language Class Initialized
DEBUG - 2021-07-01 06:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 06:44:13 --> Input Class Initialized
INFO - 2021-07-01 06:44:13 --> Language Class Initialized
INFO - 2021-07-01 06:44:13 --> Loader Class Initialized
INFO - 2021-07-01 06:44:13 --> Helper loaded: html_helper
INFO - 2021-07-01 06:44:13 --> Loader Class Initialized
INFO - 2021-07-01 06:44:13 --> Helper loaded: url_helper
INFO - 2021-07-01 06:44:13 --> Helper loaded: html_helper
INFO - 2021-07-01 06:44:13 --> Helper loaded: url_helper
INFO - 2021-07-01 06:44:13 --> Helper loaded: form_helper
INFO - 2021-07-01 06:44:13 --> Helper loaded: form_helper
INFO - 2021-07-01 06:44:13 --> Database Driver Class Initialized
INFO - 2021-07-01 06:44:13 --> Database Driver Class Initialized
INFO - 2021-07-01 06:44:13 --> Form Validation Class Initialized
INFO - 2021-07-01 06:44:13 --> Form Validation Class Initialized
DEBUG - 2021-07-01 06:44:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:44:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 06:44:13 --> Encryption Class Initialized
DEBUG - 2021-07-01 06:44:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:44:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 06:44:13 --> Encryption Class Initialized
INFO - 2021-07-01 06:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:44:13 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:44:13 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:44:13 --> Model "user_model" initialized
INFO - 2021-07-01 06:44:13 --> Model "role_model" initialized
INFO - 2021-07-01 06:44:13 --> Controller Class Initialized
INFO - 2021-07-01 06:44:13 --> Helper loaded: language_helper
INFO - 2021-07-01 06:44:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 06:44:13 --> Model "Quotation_model" initialized
INFO - 2021-07-01 06:44:13 --> Final output sent to browser
DEBUG - 2021-07-01 06:44:13 --> Total execution time: 0.0743
INFO - 2021-07-01 06:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:44:13 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:44:13 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:44:13 --> Model "user_model" initialized
INFO - 2021-07-01 06:44:13 --> Model "role_model" initialized
INFO - 2021-07-01 06:44:13 --> Controller Class Initialized
INFO - 2021-07-01 06:44:13 --> Helper loaded: language_helper
INFO - 2021-07-01 06:44:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 06:44:13 --> Model "Quotation_model" initialized
INFO - 2021-07-01 06:44:13 --> Final output sent to browser
DEBUG - 2021-07-01 06:44:13 --> Total execution time: 0.0855
INFO - 2021-07-01 06:49:25 --> Config Class Initialized
INFO - 2021-07-01 06:49:25 --> Hooks Class Initialized
DEBUG - 2021-07-01 06:49:25 --> UTF-8 Support Enabled
INFO - 2021-07-01 06:49:25 --> Utf8 Class Initialized
INFO - 2021-07-01 06:49:25 --> URI Class Initialized
INFO - 2021-07-01 06:49:25 --> Router Class Initialized
INFO - 2021-07-01 06:49:25 --> Output Class Initialized
INFO - 2021-07-01 06:49:25 --> Security Class Initialized
DEBUG - 2021-07-01 06:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 06:49:25 --> Input Class Initialized
INFO - 2021-07-01 06:49:25 --> Language Class Initialized
INFO - 2021-07-01 06:49:25 --> Loader Class Initialized
INFO - 2021-07-01 06:49:25 --> Helper loaded: html_helper
INFO - 2021-07-01 06:49:25 --> Helper loaded: url_helper
INFO - 2021-07-01 06:49:25 --> Helper loaded: form_helper
INFO - 2021-07-01 06:49:25 --> Database Driver Class Initialized
INFO - 2021-07-01 06:49:25 --> Form Validation Class Initialized
DEBUG - 2021-07-01 06:49:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:49:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 06:49:25 --> Encryption Class Initialized
INFO - 2021-07-01 06:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:49:25 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:49:25 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:49:25 --> Model "user_model" initialized
INFO - 2021-07-01 06:49:25 --> Model "role_model" initialized
INFO - 2021-07-01 06:49:25 --> Controller Class Initialized
INFO - 2021-07-01 06:49:25 --> Helper loaded: language_helper
INFO - 2021-07-01 06:49:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 06:49:25 --> Model "Quotation_model" initialized
INFO - 2021-07-01 06:49:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 06:49:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 06:49:25 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 06:49:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 06:49:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 06:49:25 --> Final output sent to browser
DEBUG - 2021-07-01 06:49:25 --> Total execution time: 0.0728
INFO - 2021-07-01 06:49:35 --> Config Class Initialized
INFO - 2021-07-01 06:49:35 --> Hooks Class Initialized
INFO - 2021-07-01 06:49:35 --> Config Class Initialized
INFO - 2021-07-01 06:49:35 --> Hooks Class Initialized
DEBUG - 2021-07-01 06:49:35 --> UTF-8 Support Enabled
DEBUG - 2021-07-01 06:49:35 --> UTF-8 Support Enabled
INFO - 2021-07-01 06:49:35 --> Utf8 Class Initialized
INFO - 2021-07-01 06:49:35 --> Utf8 Class Initialized
INFO - 2021-07-01 06:49:35 --> URI Class Initialized
INFO - 2021-07-01 06:49:35 --> URI Class Initialized
INFO - 2021-07-01 06:49:35 --> Router Class Initialized
INFO - 2021-07-01 06:49:35 --> Router Class Initialized
INFO - 2021-07-01 06:49:35 --> Output Class Initialized
INFO - 2021-07-01 06:49:35 --> Output Class Initialized
INFO - 2021-07-01 06:49:35 --> Security Class Initialized
DEBUG - 2021-07-01 06:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 06:49:35 --> Input Class Initialized
INFO - 2021-07-01 06:49:35 --> Language Class Initialized
INFO - 2021-07-01 06:49:35 --> Security Class Initialized
INFO - 2021-07-01 06:49:35 --> Loader Class Initialized
DEBUG - 2021-07-01 06:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 06:49:35 --> Input Class Initialized
INFO - 2021-07-01 06:49:35 --> Helper loaded: html_helper
INFO - 2021-07-01 06:49:35 --> Language Class Initialized
INFO - 2021-07-01 06:49:35 --> Helper loaded: url_helper
INFO - 2021-07-01 06:49:35 --> Loader Class Initialized
INFO - 2021-07-01 06:49:35 --> Helper loaded: form_helper
INFO - 2021-07-01 06:49:35 --> Helper loaded: html_helper
INFO - 2021-07-01 06:49:35 --> Helper loaded: url_helper
INFO - 2021-07-01 06:49:35 --> Helper loaded: form_helper
INFO - 2021-07-01 06:49:35 --> Database Driver Class Initialized
INFO - 2021-07-01 06:49:35 --> Database Driver Class Initialized
INFO - 2021-07-01 06:49:35 --> Form Validation Class Initialized
INFO - 2021-07-01 06:49:35 --> Form Validation Class Initialized
DEBUG - 2021-07-01 06:49:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:49:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 06:49:35 --> Encryption Class Initialized
DEBUG - 2021-07-01 06:49:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:49:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 06:49:35 --> Encryption Class Initialized
INFO - 2021-07-01 06:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:49:35 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:49:35 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:49:35 --> Model "user_model" initialized
INFO - 2021-07-01 06:49:35 --> Model "role_model" initialized
INFO - 2021-07-01 06:49:35 --> Controller Class Initialized
INFO - 2021-07-01 06:49:35 --> Helper loaded: language_helper
INFO - 2021-07-01 06:49:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 06:49:35 --> Model "Quotation_model" initialized
INFO - 2021-07-01 06:49:35 --> Final output sent to browser
DEBUG - 2021-07-01 06:49:35 --> Total execution time: 0.0760
INFO - 2021-07-01 06:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:49:35 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:49:35 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:49:35 --> Model "user_model" initialized
INFO - 2021-07-01 06:49:35 --> Model "role_model" initialized
INFO - 2021-07-01 06:49:35 --> Controller Class Initialized
INFO - 2021-07-01 06:49:35 --> Helper loaded: language_helper
INFO - 2021-07-01 06:49:35 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 06:49:35 --> Model "Quotation_model" initialized
INFO - 2021-07-01 06:49:35 --> Final output sent to browser
DEBUG - 2021-07-01 06:49:35 --> Total execution time: 0.0876
INFO - 2021-07-01 06:49:40 --> Config Class Initialized
INFO - 2021-07-01 06:49:40 --> Hooks Class Initialized
DEBUG - 2021-07-01 06:49:40 --> UTF-8 Support Enabled
INFO - 2021-07-01 06:49:40 --> Utf8 Class Initialized
INFO - 2021-07-01 06:49:40 --> URI Class Initialized
INFO - 2021-07-01 06:49:40 --> Router Class Initialized
INFO - 2021-07-01 06:49:40 --> Output Class Initialized
INFO - 2021-07-01 06:49:40 --> Security Class Initialized
DEBUG - 2021-07-01 06:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 06:49:40 --> Input Class Initialized
INFO - 2021-07-01 06:49:40 --> Language Class Initialized
INFO - 2021-07-01 06:49:40 --> Loader Class Initialized
INFO - 2021-07-01 06:49:40 --> Helper loaded: html_helper
INFO - 2021-07-01 06:49:40 --> Helper loaded: url_helper
INFO - 2021-07-01 06:49:40 --> Helper loaded: form_helper
INFO - 2021-07-01 06:49:40 --> Database Driver Class Initialized
INFO - 2021-07-01 06:49:40 --> Form Validation Class Initialized
DEBUG - 2021-07-01 06:49:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:49:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 06:49:40 --> Encryption Class Initialized
INFO - 2021-07-01 06:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:49:40 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:49:40 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:49:40 --> Model "user_model" initialized
INFO - 2021-07-01 06:49:40 --> Model "role_model" initialized
INFO - 2021-07-01 06:49:40 --> Controller Class Initialized
INFO - 2021-07-01 06:49:40 --> Helper loaded: language_helper
INFO - 2021-07-01 06:49:40 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 06:49:40 --> Model "Quotation_model" initialized
INFO - 2021-07-01 06:49:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 06:49:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 06:49:40 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 06:49:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 06:49:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 06:49:40 --> Final output sent to browser
DEBUG - 2021-07-01 06:49:40 --> Total execution time: 0.0652
INFO - 2021-07-01 06:55:43 --> Config Class Initialized
INFO - 2021-07-01 06:55:43 --> Hooks Class Initialized
DEBUG - 2021-07-01 06:55:43 --> UTF-8 Support Enabled
INFO - 2021-07-01 06:55:43 --> Utf8 Class Initialized
INFO - 2021-07-01 06:55:43 --> URI Class Initialized
INFO - 2021-07-01 06:55:43 --> Router Class Initialized
INFO - 2021-07-01 06:55:43 --> Output Class Initialized
INFO - 2021-07-01 06:55:43 --> Security Class Initialized
DEBUG - 2021-07-01 06:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 06:55:43 --> Input Class Initialized
INFO - 2021-07-01 06:55:43 --> Language Class Initialized
INFO - 2021-07-01 06:55:43 --> Loader Class Initialized
INFO - 2021-07-01 06:55:43 --> Helper loaded: html_helper
INFO - 2021-07-01 06:55:43 --> Helper loaded: url_helper
INFO - 2021-07-01 06:55:43 --> Helper loaded: form_helper
INFO - 2021-07-01 06:55:43 --> Database Driver Class Initialized
INFO - 2021-07-01 06:55:43 --> Form Validation Class Initialized
DEBUG - 2021-07-01 06:55:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:55:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 06:55:43 --> Encryption Class Initialized
INFO - 2021-07-01 06:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:55:43 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:55:43 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:55:43 --> Model "user_model" initialized
INFO - 2021-07-01 06:55:43 --> Model "role_model" initialized
INFO - 2021-07-01 06:55:43 --> Controller Class Initialized
INFO - 2021-07-01 06:55:43 --> Helper loaded: language_helper
INFO - 2021-07-01 06:55:43 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 06:55:43 --> Model "Quotation_model" initialized
INFO - 2021-07-01 06:55:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 06:55:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 06:55:43 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 06:55:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 06:55:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 06:55:43 --> Final output sent to browser
DEBUG - 2021-07-01 06:55:43 --> Total execution time: 0.1260
INFO - 2021-07-01 06:58:40 --> Config Class Initialized
INFO - 2021-07-01 06:58:40 --> Hooks Class Initialized
DEBUG - 2021-07-01 06:58:40 --> UTF-8 Support Enabled
INFO - 2021-07-01 06:58:40 --> Utf8 Class Initialized
INFO - 2021-07-01 06:58:40 --> URI Class Initialized
INFO - 2021-07-01 06:58:40 --> Router Class Initialized
INFO - 2021-07-01 06:58:40 --> Output Class Initialized
INFO - 2021-07-01 06:58:40 --> Security Class Initialized
DEBUG - 2021-07-01 06:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 06:58:40 --> Input Class Initialized
INFO - 2021-07-01 06:58:40 --> Language Class Initialized
INFO - 2021-07-01 06:58:40 --> Loader Class Initialized
INFO - 2021-07-01 06:58:40 --> Helper loaded: html_helper
INFO - 2021-07-01 06:58:40 --> Helper loaded: url_helper
INFO - 2021-07-01 06:58:40 --> Helper loaded: form_helper
INFO - 2021-07-01 06:58:40 --> Database Driver Class Initialized
INFO - 2021-07-01 06:58:40 --> Form Validation Class Initialized
DEBUG - 2021-07-01 06:58:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:58:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 06:58:40 --> Encryption Class Initialized
INFO - 2021-07-01 06:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:58:40 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:58:40 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:58:40 --> Model "user_model" initialized
INFO - 2021-07-01 06:58:40 --> Model "role_model" initialized
INFO - 2021-07-01 06:58:40 --> Controller Class Initialized
INFO - 2021-07-01 06:58:40 --> Helper loaded: language_helper
INFO - 2021-07-01 06:58:40 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 06:58:40 --> Model "Quotation_model" initialized
INFO - 2021-07-01 06:58:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 06:58:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 06:58:40 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 06:58:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 06:58:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 06:58:40 --> Final output sent to browser
DEBUG - 2021-07-01 06:58:40 --> Total execution time: 0.0735
INFO - 2021-07-01 06:58:56 --> Config Class Initialized
INFO - 2021-07-01 06:58:56 --> Hooks Class Initialized
INFO - 2021-07-01 06:58:56 --> Config Class Initialized
INFO - 2021-07-01 06:58:56 --> Hooks Class Initialized
DEBUG - 2021-07-01 06:58:56 --> UTF-8 Support Enabled
DEBUG - 2021-07-01 06:58:56 --> UTF-8 Support Enabled
INFO - 2021-07-01 06:58:56 --> Utf8 Class Initialized
INFO - 2021-07-01 06:58:56 --> Utf8 Class Initialized
INFO - 2021-07-01 06:58:56 --> URI Class Initialized
INFO - 2021-07-01 06:58:56 --> URI Class Initialized
INFO - 2021-07-01 06:58:56 --> Router Class Initialized
INFO - 2021-07-01 06:58:56 --> Router Class Initialized
INFO - 2021-07-01 06:58:56 --> Output Class Initialized
INFO - 2021-07-01 06:58:56 --> Output Class Initialized
INFO - 2021-07-01 06:58:56 --> Security Class Initialized
INFO - 2021-07-01 06:58:56 --> Security Class Initialized
DEBUG - 2021-07-01 06:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-01 06:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 06:58:56 --> Input Class Initialized
INFO - 2021-07-01 06:58:56 --> Input Class Initialized
INFO - 2021-07-01 06:58:56 --> Language Class Initialized
INFO - 2021-07-01 06:58:56 --> Language Class Initialized
INFO - 2021-07-01 06:58:56 --> Loader Class Initialized
INFO - 2021-07-01 06:58:56 --> Loader Class Initialized
INFO - 2021-07-01 06:58:56 --> Helper loaded: html_helper
INFO - 2021-07-01 06:58:56 --> Helper loaded: html_helper
INFO - 2021-07-01 06:58:56 --> Helper loaded: url_helper
INFO - 2021-07-01 06:58:56 --> Helper loaded: url_helper
INFO - 2021-07-01 06:58:56 --> Helper loaded: form_helper
INFO - 2021-07-01 06:58:56 --> Helper loaded: form_helper
INFO - 2021-07-01 06:58:56 --> Database Driver Class Initialized
INFO - 2021-07-01 06:58:56 --> Database Driver Class Initialized
INFO - 2021-07-01 06:58:56 --> Form Validation Class Initialized
INFO - 2021-07-01 06:58:56 --> Form Validation Class Initialized
DEBUG - 2021-07-01 06:58:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:58:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2021-07-01 06:58:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:58:56 --> Encryption Class Initialized
INFO - 2021-07-01 06:58:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 06:58:56 --> Encryption Class Initialized
INFO - 2021-07-01 06:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:58:56 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:58:56 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:58:56 --> Model "user_model" initialized
INFO - 2021-07-01 06:58:56 --> Model "role_model" initialized
INFO - 2021-07-01 06:58:56 --> Controller Class Initialized
INFO - 2021-07-01 06:58:56 --> Helper loaded: language_helper
INFO - 2021-07-01 06:58:56 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 06:58:56 --> Model "Quotation_model" initialized
INFO - 2021-07-01 06:58:56 --> Final output sent to browser
DEBUG - 2021-07-01 06:58:56 --> Total execution time: 0.0887
INFO - 2021-07-01 06:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:58:56 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:58:56 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:58:56 --> Model "user_model" initialized
INFO - 2021-07-01 06:58:56 --> Model "role_model" initialized
INFO - 2021-07-01 06:58:56 --> Controller Class Initialized
INFO - 2021-07-01 06:58:56 --> Helper loaded: language_helper
INFO - 2021-07-01 06:58:56 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 06:58:56 --> Model "Quotation_model" initialized
INFO - 2021-07-01 06:58:56 --> Final output sent to browser
DEBUG - 2021-07-01 06:58:56 --> Total execution time: 0.0999
INFO - 2021-07-01 06:59:00 --> Config Class Initialized
INFO - 2021-07-01 06:59:00 --> Config Class Initialized
INFO - 2021-07-01 06:59:00 --> Hooks Class Initialized
INFO - 2021-07-01 06:59:00 --> Hooks Class Initialized
DEBUG - 2021-07-01 06:59:00 --> UTF-8 Support Enabled
DEBUG - 2021-07-01 06:59:00 --> UTF-8 Support Enabled
INFO - 2021-07-01 06:59:00 --> Utf8 Class Initialized
INFO - 2021-07-01 06:59:00 --> Utf8 Class Initialized
INFO - 2021-07-01 06:59:00 --> URI Class Initialized
INFO - 2021-07-01 06:59:00 --> URI Class Initialized
INFO - 2021-07-01 06:59:00 --> Router Class Initialized
INFO - 2021-07-01 06:59:00 --> Router Class Initialized
INFO - 2021-07-01 06:59:00 --> Output Class Initialized
INFO - 2021-07-01 06:59:00 --> Security Class Initialized
INFO - 2021-07-01 06:59:00 --> Output Class Initialized
DEBUG - 2021-07-01 06:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 06:59:00 --> Input Class Initialized
INFO - 2021-07-01 06:59:00 --> Security Class Initialized
INFO - 2021-07-01 06:59:00 --> Language Class Initialized
DEBUG - 2021-07-01 06:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 06:59:00 --> Input Class Initialized
INFO - 2021-07-01 06:59:00 --> Language Class Initialized
INFO - 2021-07-01 06:59:00 --> Loader Class Initialized
INFO - 2021-07-01 06:59:00 --> Loader Class Initialized
INFO - 2021-07-01 06:59:00 --> Helper loaded: html_helper
INFO - 2021-07-01 06:59:00 --> Helper loaded: html_helper
INFO - 2021-07-01 06:59:00 --> Helper loaded: url_helper
INFO - 2021-07-01 06:59:00 --> Helper loaded: url_helper
INFO - 2021-07-01 06:59:00 --> Helper loaded: form_helper
INFO - 2021-07-01 06:59:00 --> Helper loaded: form_helper
INFO - 2021-07-01 06:59:00 --> Database Driver Class Initialized
INFO - 2021-07-01 06:59:00 --> Database Driver Class Initialized
INFO - 2021-07-01 06:59:00 --> Form Validation Class Initialized
INFO - 2021-07-01 06:59:00 --> Form Validation Class Initialized
DEBUG - 2021-07-01 06:59:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:59:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 06:59:00 --> Encryption Class Initialized
DEBUG - 2021-07-01 06:59:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:59:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 06:59:00 --> Encryption Class Initialized
INFO - 2021-07-01 06:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:59:00 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:59:00 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:59:00 --> Model "user_model" initialized
INFO - 2021-07-01 06:59:00 --> Model "role_model" initialized
INFO - 2021-07-01 06:59:00 --> Controller Class Initialized
INFO - 2021-07-01 06:59:00 --> Helper loaded: language_helper
INFO - 2021-07-01 06:59:00 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 06:59:00 --> Model "Quotation_model" initialized
INFO - 2021-07-01 06:59:00 --> Final output sent to browser
DEBUG - 2021-07-01 06:59:00 --> Total execution time: 0.0654
INFO - 2021-07-01 06:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:59:00 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:59:00 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:59:00 --> Model "user_model" initialized
INFO - 2021-07-01 06:59:00 --> Model "role_model" initialized
INFO - 2021-07-01 06:59:00 --> Controller Class Initialized
INFO - 2021-07-01 06:59:00 --> Helper loaded: language_helper
INFO - 2021-07-01 06:59:00 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 06:59:00 --> Model "Quotation_model" initialized
INFO - 2021-07-01 06:59:00 --> Final output sent to browser
DEBUG - 2021-07-01 06:59:00 --> Total execution time: 0.0754
INFO - 2021-07-01 06:59:03 --> Config Class Initialized
INFO - 2021-07-01 06:59:03 --> Hooks Class Initialized
DEBUG - 2021-07-01 06:59:03 --> UTF-8 Support Enabled
INFO - 2021-07-01 06:59:03 --> Utf8 Class Initialized
INFO - 2021-07-01 06:59:03 --> URI Class Initialized
INFO - 2021-07-01 06:59:03 --> Router Class Initialized
INFO - 2021-07-01 06:59:03 --> Output Class Initialized
INFO - 2021-07-01 06:59:03 --> Security Class Initialized
DEBUG - 2021-07-01 06:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 06:59:03 --> Input Class Initialized
INFO - 2021-07-01 06:59:03 --> Language Class Initialized
INFO - 2021-07-01 06:59:03 --> Loader Class Initialized
INFO - 2021-07-01 06:59:03 --> Helper loaded: html_helper
INFO - 2021-07-01 06:59:03 --> Helper loaded: url_helper
INFO - 2021-07-01 06:59:03 --> Helper loaded: form_helper
INFO - 2021-07-01 06:59:03 --> Database Driver Class Initialized
INFO - 2021-07-01 06:59:03 --> Form Validation Class Initialized
DEBUG - 2021-07-01 06:59:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 06:59:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 06:59:03 --> Encryption Class Initialized
INFO - 2021-07-01 06:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 06:59:03 --> Model "vendor_model" initialized
INFO - 2021-07-01 06:59:03 --> Model "coupon_model" initialized
INFO - 2021-07-01 06:59:03 --> Model "user_model" initialized
INFO - 2021-07-01 06:59:03 --> Model "role_model" initialized
INFO - 2021-07-01 06:59:03 --> Controller Class Initialized
INFO - 2021-07-01 06:59:03 --> Helper loaded: language_helper
INFO - 2021-07-01 06:59:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 06:59:03 --> Model "Quotation_model" initialized
INFO - 2021-07-01 06:59:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 06:59:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 06:59:03 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 06:59:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 06:59:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 06:59:03 --> Final output sent to browser
DEBUG - 2021-07-01 06:59:03 --> Total execution time: 0.0671
INFO - 2021-07-01 07:00:32 --> Config Class Initialized
INFO - 2021-07-01 07:00:32 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:00:32 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:00:32 --> Utf8 Class Initialized
INFO - 2021-07-01 07:00:32 --> URI Class Initialized
INFO - 2021-07-01 07:00:32 --> Router Class Initialized
INFO - 2021-07-01 07:00:32 --> Output Class Initialized
INFO - 2021-07-01 07:00:32 --> Security Class Initialized
DEBUG - 2021-07-01 07:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:00:32 --> Input Class Initialized
INFO - 2021-07-01 07:00:32 --> Language Class Initialized
INFO - 2021-07-01 07:00:32 --> Loader Class Initialized
INFO - 2021-07-01 07:00:32 --> Helper loaded: html_helper
INFO - 2021-07-01 07:00:32 --> Helper loaded: url_helper
INFO - 2021-07-01 07:00:32 --> Helper loaded: form_helper
INFO - 2021-07-01 07:00:32 --> Database Driver Class Initialized
INFO - 2021-07-01 07:00:32 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:00:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:00:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:00:32 --> Encryption Class Initialized
INFO - 2021-07-01 07:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:00:32 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:00:32 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:00:32 --> Model "user_model" initialized
INFO - 2021-07-01 07:00:32 --> Model "role_model" initialized
INFO - 2021-07-01 07:00:32 --> Controller Class Initialized
INFO - 2021-07-01 07:00:32 --> Helper loaded: language_helper
INFO - 2021-07-01 07:00:32 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:00:32 --> Model "Quotation_model" initialized
INFO - 2021-07-01 07:00:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:00:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:00:32 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 07:00:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 07:00:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:00:32 --> Final output sent to browser
DEBUG - 2021-07-01 07:00:32 --> Total execution time: 0.0673
INFO - 2021-07-01 07:04:57 --> Config Class Initialized
INFO - 2021-07-01 07:04:57 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:04:57 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:04:57 --> Utf8 Class Initialized
INFO - 2021-07-01 07:04:57 --> URI Class Initialized
INFO - 2021-07-01 07:04:57 --> Router Class Initialized
INFO - 2021-07-01 07:04:57 --> Output Class Initialized
INFO - 2021-07-01 07:04:57 --> Security Class Initialized
DEBUG - 2021-07-01 07:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:04:57 --> Input Class Initialized
INFO - 2021-07-01 07:04:57 --> Language Class Initialized
INFO - 2021-07-01 07:04:57 --> Loader Class Initialized
INFO - 2021-07-01 07:04:57 --> Helper loaded: html_helper
INFO - 2021-07-01 07:04:57 --> Helper loaded: url_helper
INFO - 2021-07-01 07:04:57 --> Helper loaded: form_helper
INFO - 2021-07-01 07:04:57 --> Database Driver Class Initialized
INFO - 2021-07-01 07:04:57 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:04:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:04:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:04:57 --> Encryption Class Initialized
INFO - 2021-07-01 07:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:04:57 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:04:57 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:04:57 --> Model "user_model" initialized
INFO - 2021-07-01 07:04:57 --> Model "role_model" initialized
INFO - 2021-07-01 07:04:57 --> Controller Class Initialized
INFO - 2021-07-01 07:04:57 --> Helper loaded: language_helper
INFO - 2021-07-01 07:04:57 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:04:57 --> Model "Quotation_model" initialized
INFO - 2021-07-01 07:04:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:04:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:04:57 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 07:04:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 07:04:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:04:57 --> Final output sent to browser
DEBUG - 2021-07-01 07:04:57 --> Total execution time: 0.0716
INFO - 2021-07-01 07:05:03 --> Config Class Initialized
INFO - 2021-07-01 07:05:03 --> Hooks Class Initialized
INFO - 2021-07-01 07:05:03 --> Config Class Initialized
INFO - 2021-07-01 07:05:03 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:05:03 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:05:03 --> Utf8 Class Initialized
DEBUG - 2021-07-01 07:05:03 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:05:03 --> Utf8 Class Initialized
INFO - 2021-07-01 07:05:03 --> URI Class Initialized
INFO - 2021-07-01 07:05:03 --> URI Class Initialized
INFO - 2021-07-01 07:05:03 --> Router Class Initialized
INFO - 2021-07-01 07:05:03 --> Router Class Initialized
INFO - 2021-07-01 07:05:03 --> Output Class Initialized
INFO - 2021-07-01 07:05:03 --> Output Class Initialized
INFO - 2021-07-01 07:05:03 --> Security Class Initialized
INFO - 2021-07-01 07:05:03 --> Security Class Initialized
DEBUG - 2021-07-01 07:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:05:03 --> Input Class Initialized
DEBUG - 2021-07-01 07:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:05:03 --> Input Class Initialized
INFO - 2021-07-01 07:05:03 --> Language Class Initialized
INFO - 2021-07-01 07:05:03 --> Language Class Initialized
INFO - 2021-07-01 07:05:03 --> Loader Class Initialized
INFO - 2021-07-01 07:05:03 --> Loader Class Initialized
INFO - 2021-07-01 07:05:03 --> Helper loaded: html_helper
INFO - 2021-07-01 07:05:03 --> Helper loaded: html_helper
INFO - 2021-07-01 07:05:03 --> Helper loaded: url_helper
INFO - 2021-07-01 07:05:03 --> Helper loaded: url_helper
INFO - 2021-07-01 07:05:03 --> Helper loaded: form_helper
INFO - 2021-07-01 07:05:03 --> Helper loaded: form_helper
INFO - 2021-07-01 07:05:03 --> Database Driver Class Initialized
INFO - 2021-07-01 07:05:03 --> Database Driver Class Initialized
INFO - 2021-07-01 07:05:03 --> Form Validation Class Initialized
INFO - 2021-07-01 07:05:03 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-01 07:05:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:05:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:05:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:05:03 --> Encryption Class Initialized
INFO - 2021-07-01 07:05:03 --> Encryption Class Initialized
INFO - 2021-07-01 07:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:05:03 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:05:03 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:05:03 --> Model "user_model" initialized
INFO - 2021-07-01 07:05:03 --> Model "role_model" initialized
INFO - 2021-07-01 07:05:03 --> Controller Class Initialized
INFO - 2021-07-01 07:05:03 --> Helper loaded: language_helper
INFO - 2021-07-01 07:05:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:05:03 --> Model "Quotation_model" initialized
INFO - 2021-07-01 07:05:03 --> Final output sent to browser
DEBUG - 2021-07-01 07:05:03 --> Total execution time: 0.0699
INFO - 2021-07-01 07:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:05:03 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:05:03 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:05:03 --> Model "user_model" initialized
INFO - 2021-07-01 07:05:03 --> Model "role_model" initialized
INFO - 2021-07-01 07:05:03 --> Controller Class Initialized
INFO - 2021-07-01 07:05:03 --> Helper loaded: language_helper
INFO - 2021-07-01 07:05:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:05:03 --> Model "Quotation_model" initialized
INFO - 2021-07-01 07:05:03 --> Final output sent to browser
DEBUG - 2021-07-01 07:05:03 --> Total execution time: 0.0809
INFO - 2021-07-01 07:05:13 --> Config Class Initialized
INFO - 2021-07-01 07:05:13 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:05:13 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:05:13 --> Utf8 Class Initialized
INFO - 2021-07-01 07:05:13 --> URI Class Initialized
INFO - 2021-07-01 07:05:13 --> Router Class Initialized
INFO - 2021-07-01 07:05:13 --> Output Class Initialized
INFO - 2021-07-01 07:05:13 --> Security Class Initialized
DEBUG - 2021-07-01 07:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:05:13 --> Input Class Initialized
INFO - 2021-07-01 07:05:13 --> Language Class Initialized
INFO - 2021-07-01 07:05:13 --> Loader Class Initialized
INFO - 2021-07-01 07:05:13 --> Helper loaded: html_helper
INFO - 2021-07-01 07:05:13 --> Helper loaded: url_helper
INFO - 2021-07-01 07:05:13 --> Helper loaded: form_helper
INFO - 2021-07-01 07:05:13 --> Database Driver Class Initialized
INFO - 2021-07-01 07:05:13 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:05:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:05:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:05:13 --> Encryption Class Initialized
INFO - 2021-07-01 07:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:05:13 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:05:13 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:05:13 --> Model "user_model" initialized
INFO - 2021-07-01 07:05:13 --> Model "role_model" initialized
INFO - 2021-07-01 07:05:13 --> Controller Class Initialized
INFO - 2021-07-01 07:05:13 --> Helper loaded: language_helper
INFO - 2021-07-01 07:05:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:05:13 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:05:13 --> Model "Product_model" initialized
INFO - 2021-07-01 07:05:13 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:05:13 --> Model "Quotation_model" initialized
INFO - 2021-07-01 07:05:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:05:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:05:13 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Invoices\create_invoice.php 33
INFO - 2021-07-01 07:05:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Invoices/create_invoice.php
INFO - 2021-07-01 07:05:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:05:13 --> Final output sent to browser
DEBUG - 2021-07-01 07:05:13 --> Total execution time: 0.0800
INFO - 2021-07-01 07:05:15 --> Config Class Initialized
INFO - 2021-07-01 07:05:15 --> Hooks Class Initialized
INFO - 2021-07-01 07:05:15 --> Config Class Initialized
INFO - 2021-07-01 07:05:15 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:05:15 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:05:15 --> Utf8 Class Initialized
DEBUG - 2021-07-01 07:05:15 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:05:15 --> Utf8 Class Initialized
INFO - 2021-07-01 07:05:15 --> URI Class Initialized
INFO - 2021-07-01 07:05:15 --> URI Class Initialized
INFO - 2021-07-01 07:05:15 --> Router Class Initialized
INFO - 2021-07-01 07:05:15 --> Router Class Initialized
INFO - 2021-07-01 07:05:15 --> Output Class Initialized
INFO - 2021-07-01 07:05:15 --> Output Class Initialized
INFO - 2021-07-01 07:05:15 --> Security Class Initialized
INFO - 2021-07-01 07:05:15 --> Security Class Initialized
DEBUG - 2021-07-01 07:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-01 07:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:05:15 --> Input Class Initialized
INFO - 2021-07-01 07:05:15 --> Input Class Initialized
INFO - 2021-07-01 07:05:15 --> Language Class Initialized
INFO - 2021-07-01 07:05:15 --> Language Class Initialized
INFO - 2021-07-01 07:05:15 --> Loader Class Initialized
INFO - 2021-07-01 07:05:15 --> Loader Class Initialized
INFO - 2021-07-01 07:05:15 --> Helper loaded: html_helper
INFO - 2021-07-01 07:05:15 --> Helper loaded: html_helper
INFO - 2021-07-01 07:05:15 --> Helper loaded: url_helper
INFO - 2021-07-01 07:05:15 --> Helper loaded: url_helper
INFO - 2021-07-01 07:05:15 --> Helper loaded: form_helper
INFO - 2021-07-01 07:05:15 --> Helper loaded: form_helper
INFO - 2021-07-01 07:05:15 --> Database Driver Class Initialized
INFO - 2021-07-01 07:05:15 --> Database Driver Class Initialized
INFO - 2021-07-01 07:05:15 --> Form Validation Class Initialized
INFO - 2021-07-01 07:05:15 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-01 07:05:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:05:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:05:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:05:15 --> Encryption Class Initialized
INFO - 2021-07-01 07:05:15 --> Encryption Class Initialized
INFO - 2021-07-01 07:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:05:15 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:05:15 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:05:15 --> Model "user_model" initialized
INFO - 2021-07-01 07:05:15 --> Model "role_model" initialized
INFO - 2021-07-01 07:05:15 --> Controller Class Initialized
INFO - 2021-07-01 07:05:15 --> Helper loaded: language_helper
INFO - 2021-07-01 07:05:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:05:15 --> Model "Quotation_model" initialized
INFO - 2021-07-01 07:05:15 --> Final output sent to browser
DEBUG - 2021-07-01 07:05:15 --> Total execution time: 0.0713
INFO - 2021-07-01 07:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:05:15 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:05:15 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:05:15 --> Model "user_model" initialized
INFO - 2021-07-01 07:05:15 --> Model "role_model" initialized
INFO - 2021-07-01 07:05:15 --> Controller Class Initialized
INFO - 2021-07-01 07:05:15 --> Helper loaded: language_helper
INFO - 2021-07-01 07:05:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:05:15 --> Model "Quotation_model" initialized
INFO - 2021-07-01 07:05:15 --> Final output sent to browser
DEBUG - 2021-07-01 07:05:15 --> Total execution time: 0.0806
INFO - 2021-07-01 07:05:21 --> Config Class Initialized
INFO - 2021-07-01 07:05:21 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:05:21 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:05:21 --> Utf8 Class Initialized
INFO - 2021-07-01 07:05:21 --> URI Class Initialized
INFO - 2021-07-01 07:05:21 --> Router Class Initialized
INFO - 2021-07-01 07:05:21 --> Output Class Initialized
INFO - 2021-07-01 07:05:21 --> Security Class Initialized
DEBUG - 2021-07-01 07:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:05:21 --> Input Class Initialized
INFO - 2021-07-01 07:05:21 --> Language Class Initialized
INFO - 2021-07-01 07:05:21 --> Loader Class Initialized
INFO - 2021-07-01 07:05:21 --> Helper loaded: html_helper
INFO - 2021-07-01 07:05:21 --> Helper loaded: url_helper
INFO - 2021-07-01 07:05:21 --> Helper loaded: form_helper
INFO - 2021-07-01 07:05:21 --> Database Driver Class Initialized
INFO - 2021-07-01 07:05:21 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:05:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:05:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:05:21 --> Encryption Class Initialized
INFO - 2021-07-01 07:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:05:21 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:05:21 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:05:21 --> Model "user_model" initialized
INFO - 2021-07-01 07:05:21 --> Model "role_model" initialized
INFO - 2021-07-01 07:05:21 --> Controller Class Initialized
INFO - 2021-07-01 07:05:21 --> Helper loaded: language_helper
INFO - 2021-07-01 07:05:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:05:21 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:05:21 --> Model "Product_model" initialized
INFO - 2021-07-01 07:05:21 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:05:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:05:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:05:21 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:05:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:05:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:05:21 --> Final output sent to browser
DEBUG - 2021-07-01 07:05:21 --> Total execution time: 0.0650
INFO - 2021-07-01 07:08:33 --> Config Class Initialized
INFO - 2021-07-01 07:08:33 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:08:33 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:08:33 --> Utf8 Class Initialized
INFO - 2021-07-01 07:08:33 --> URI Class Initialized
INFO - 2021-07-01 07:08:33 --> Router Class Initialized
INFO - 2021-07-01 07:08:33 --> Output Class Initialized
INFO - 2021-07-01 07:08:33 --> Security Class Initialized
DEBUG - 2021-07-01 07:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:08:33 --> Input Class Initialized
INFO - 2021-07-01 07:08:33 --> Language Class Initialized
INFO - 2021-07-01 07:08:33 --> Loader Class Initialized
INFO - 2021-07-01 07:08:33 --> Helper loaded: html_helper
INFO - 2021-07-01 07:08:33 --> Helper loaded: url_helper
INFO - 2021-07-01 07:08:33 --> Helper loaded: form_helper
INFO - 2021-07-01 07:08:33 --> Database Driver Class Initialized
INFO - 2021-07-01 07:08:33 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:08:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:08:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:08:33 --> Encryption Class Initialized
INFO - 2021-07-01 07:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:08:33 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:08:33 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:08:33 --> Model "user_model" initialized
INFO - 2021-07-01 07:08:33 --> Model "role_model" initialized
INFO - 2021-07-01 07:08:33 --> Controller Class Initialized
INFO - 2021-07-01 07:08:33 --> Helper loaded: language_helper
INFO - 2021-07-01 07:08:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:08:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:08:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-01 07:08:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\monthly_sales.php
INFO - 2021-07-01 07:08:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:08:33 --> Final output sent to browser
DEBUG - 2021-07-01 07:08:33 --> Total execution time: 0.0692
INFO - 2021-07-01 07:08:45 --> Config Class Initialized
INFO - 2021-07-01 07:08:45 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:08:45 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:08:45 --> Utf8 Class Initialized
INFO - 2021-07-01 07:08:45 --> URI Class Initialized
INFO - 2021-07-01 07:08:45 --> Router Class Initialized
INFO - 2021-07-01 07:08:45 --> Output Class Initialized
INFO - 2021-07-01 07:08:45 --> Security Class Initialized
DEBUG - 2021-07-01 07:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:08:45 --> Input Class Initialized
INFO - 2021-07-01 07:08:45 --> Language Class Initialized
INFO - 2021-07-01 07:08:45 --> Loader Class Initialized
INFO - 2021-07-01 07:08:45 --> Helper loaded: html_helper
INFO - 2021-07-01 07:08:45 --> Helper loaded: url_helper
INFO - 2021-07-01 07:08:45 --> Helper loaded: form_helper
INFO - 2021-07-01 07:08:45 --> Database Driver Class Initialized
INFO - 2021-07-01 07:08:45 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:08:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:08:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:08:45 --> Encryption Class Initialized
INFO - 2021-07-01 07:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:08:45 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:08:45 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:08:45 --> Model "user_model" initialized
INFO - 2021-07-01 07:08:45 --> Model "role_model" initialized
INFO - 2021-07-01 07:08:45 --> Controller Class Initialized
INFO - 2021-07-01 07:08:45 --> Helper loaded: language_helper
INFO - 2021-07-01 07:08:45 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:08:45 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:08:45 --> Model "Product_model" initialized
INFO - 2021-07-01 07:08:45 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:08:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:08:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:08:45 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:08:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:08:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:08:45 --> Final output sent to browser
DEBUG - 2021-07-01 07:08:45 --> Total execution time: 0.0773
INFO - 2021-07-01 07:08:48 --> Config Class Initialized
INFO - 2021-07-01 07:08:48 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:08:48 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:08:48 --> Utf8 Class Initialized
INFO - 2021-07-01 07:08:48 --> URI Class Initialized
INFO - 2021-07-01 07:08:48 --> Router Class Initialized
INFO - 2021-07-01 07:08:48 --> Output Class Initialized
INFO - 2021-07-01 07:08:48 --> Security Class Initialized
DEBUG - 2021-07-01 07:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:08:48 --> Input Class Initialized
INFO - 2021-07-01 07:08:48 --> Language Class Initialized
INFO - 2021-07-01 07:08:48 --> Loader Class Initialized
INFO - 2021-07-01 07:08:48 --> Helper loaded: html_helper
INFO - 2021-07-01 07:08:48 --> Helper loaded: url_helper
INFO - 2021-07-01 07:08:48 --> Helper loaded: form_helper
INFO - 2021-07-01 07:08:48 --> Database Driver Class Initialized
INFO - 2021-07-01 07:08:48 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:08:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:08:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:08:48 --> Encryption Class Initialized
INFO - 2021-07-01 07:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:08:48 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:08:48 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:08:48 --> Model "user_model" initialized
INFO - 2021-07-01 07:08:48 --> Model "role_model" initialized
INFO - 2021-07-01 07:08:48 --> Controller Class Initialized
INFO - 2021-07-01 07:08:48 --> Helper loaded: language_helper
INFO - 2021-07-01 07:08:48 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:08:48 --> Model "Invoice_model" initialized
INFO - 2021-07-01 07:08:48 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:08:48 --> Model "Product_model" initialized
INFO - 2021-07-01 07:08:48 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:08:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:08:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:08:48 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Invoices\edit_invoice.php 32
INFO - 2021-07-01 07:08:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Invoices/edit_invoice.php
INFO - 2021-07-01 07:08:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:08:48 --> Final output sent to browser
DEBUG - 2021-07-01 07:08:48 --> Total execution time: 0.0790
INFO - 2021-07-01 07:09:00 --> Config Class Initialized
INFO - 2021-07-01 07:09:00 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:09:00 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:09:00 --> Utf8 Class Initialized
INFO - 2021-07-01 07:09:00 --> URI Class Initialized
INFO - 2021-07-01 07:09:00 --> Router Class Initialized
INFO - 2021-07-01 07:09:00 --> Output Class Initialized
INFO - 2021-07-01 07:09:00 --> Security Class Initialized
DEBUG - 2021-07-01 07:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:09:00 --> Input Class Initialized
INFO - 2021-07-01 07:09:00 --> Language Class Initialized
INFO - 2021-07-01 07:09:00 --> Loader Class Initialized
INFO - 2021-07-01 07:09:00 --> Helper loaded: html_helper
INFO - 2021-07-01 07:09:00 --> Helper loaded: url_helper
INFO - 2021-07-01 07:09:00 --> Helper loaded: form_helper
INFO - 2021-07-01 07:09:00 --> Database Driver Class Initialized
INFO - 2021-07-01 07:09:00 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:09:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:09:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:09:00 --> Encryption Class Initialized
INFO - 2021-07-01 07:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:09:00 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:09:00 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:09:00 --> Model "user_model" initialized
INFO - 2021-07-01 07:09:00 --> Model "role_model" initialized
INFO - 2021-07-01 07:09:00 --> Controller Class Initialized
INFO - 2021-07-01 07:09:00 --> Helper loaded: language_helper
INFO - 2021-07-01 07:09:00 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:09:00 --> Model "Invoice_model" initialized
INFO - 2021-07-01 07:09:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:09:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:09:00 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Invoices\view_invoice_new.php 40
INFO - 2021-07-01 07:09:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Invoices/view_invoice_new.php
INFO - 2021-07-01 07:09:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:09:00 --> Final output sent to browser
DEBUG - 2021-07-01 07:09:00 --> Total execution time: 0.0628
INFO - 2021-07-01 07:09:08 --> Config Class Initialized
INFO - 2021-07-01 07:09:08 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:09:08 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:09:08 --> Utf8 Class Initialized
INFO - 2021-07-01 07:09:08 --> URI Class Initialized
INFO - 2021-07-01 07:09:08 --> Router Class Initialized
INFO - 2021-07-01 07:09:08 --> Output Class Initialized
INFO - 2021-07-01 07:09:08 --> Security Class Initialized
DEBUG - 2021-07-01 07:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:09:08 --> Input Class Initialized
INFO - 2021-07-01 07:09:08 --> Language Class Initialized
INFO - 2021-07-01 07:09:08 --> Loader Class Initialized
INFO - 2021-07-01 07:09:08 --> Helper loaded: html_helper
INFO - 2021-07-01 07:09:08 --> Helper loaded: url_helper
INFO - 2021-07-01 07:09:08 --> Helper loaded: form_helper
INFO - 2021-07-01 07:09:08 --> Database Driver Class Initialized
INFO - 2021-07-01 07:09:08 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:09:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:09:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:09:08 --> Encryption Class Initialized
INFO - 2021-07-01 07:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:09:08 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:09:08 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:09:08 --> Model "user_model" initialized
INFO - 2021-07-01 07:09:08 --> Model "role_model" initialized
INFO - 2021-07-01 07:09:08 --> Controller Class Initialized
INFO - 2021-07-01 07:09:08 --> Helper loaded: language_helper
INFO - 2021-07-01 07:09:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:09:08 --> Model "Invoice_model" initialized
INFO - 2021-07-01 07:09:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:09:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:09:08 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Invoices\view_invoice_new.php 40
INFO - 2021-07-01 07:09:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Invoices/view_invoice_new.php
INFO - 2021-07-01 07:09:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:09:08 --> Final output sent to browser
DEBUG - 2021-07-01 07:09:08 --> Total execution time: 0.0811
INFO - 2021-07-01 07:09:10 --> Config Class Initialized
INFO - 2021-07-01 07:09:10 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:09:10 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:09:10 --> Utf8 Class Initialized
INFO - 2021-07-01 07:09:10 --> URI Class Initialized
INFO - 2021-07-01 07:09:10 --> Router Class Initialized
INFO - 2021-07-01 07:09:10 --> Output Class Initialized
INFO - 2021-07-01 07:09:10 --> Security Class Initialized
DEBUG - 2021-07-01 07:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:09:10 --> Input Class Initialized
INFO - 2021-07-01 07:09:10 --> Language Class Initialized
INFO - 2021-07-01 07:09:10 --> Loader Class Initialized
INFO - 2021-07-01 07:09:10 --> Helper loaded: html_helper
INFO - 2021-07-01 07:09:10 --> Helper loaded: url_helper
INFO - 2021-07-01 07:09:10 --> Helper loaded: form_helper
INFO - 2021-07-01 07:09:10 --> Database Driver Class Initialized
INFO - 2021-07-01 07:09:10 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:09:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:09:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:09:10 --> Encryption Class Initialized
INFO - 2021-07-01 07:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:09:10 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:09:10 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:09:10 --> Model "user_model" initialized
INFO - 2021-07-01 07:09:10 --> Model "role_model" initialized
INFO - 2021-07-01 07:09:10 --> Controller Class Initialized
INFO - 2021-07-01 07:09:10 --> Helper loaded: language_helper
INFO - 2021-07-01 07:09:10 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:09:10 --> Model "Invoice_model" initialized
INFO - 2021-07-01 07:09:10 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:09:10 --> Model "Product_model" initialized
INFO - 2021-07-01 07:09:10 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:09:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:09:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:09:10 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Invoices\edit_invoice.php 32
INFO - 2021-07-01 07:09:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Invoices/edit_invoice.php
INFO - 2021-07-01 07:09:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:09:10 --> Final output sent to browser
DEBUG - 2021-07-01 07:09:10 --> Total execution time: 0.0780
INFO - 2021-07-01 07:09:17 --> Config Class Initialized
INFO - 2021-07-01 07:09:17 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:09:17 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:09:17 --> Utf8 Class Initialized
INFO - 2021-07-01 07:09:17 --> URI Class Initialized
INFO - 2021-07-01 07:09:17 --> Router Class Initialized
INFO - 2021-07-01 07:09:17 --> Output Class Initialized
INFO - 2021-07-01 07:09:17 --> Security Class Initialized
DEBUG - 2021-07-01 07:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:09:17 --> Input Class Initialized
INFO - 2021-07-01 07:09:17 --> Language Class Initialized
INFO - 2021-07-01 07:09:17 --> Loader Class Initialized
INFO - 2021-07-01 07:09:17 --> Helper loaded: html_helper
INFO - 2021-07-01 07:09:17 --> Helper loaded: url_helper
INFO - 2021-07-01 07:09:17 --> Helper loaded: form_helper
INFO - 2021-07-01 07:09:17 --> Database Driver Class Initialized
INFO - 2021-07-01 07:09:17 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:09:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:09:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:09:17 --> Encryption Class Initialized
INFO - 2021-07-01 07:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:09:17 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:09:17 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:09:17 --> Model "user_model" initialized
INFO - 2021-07-01 07:09:17 --> Model "role_model" initialized
INFO - 2021-07-01 07:09:17 --> Controller Class Initialized
INFO - 2021-07-01 07:09:17 --> Helper loaded: language_helper
INFO - 2021-07-01 07:09:17 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:09:17 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:09:17 --> Model "Product_model" initialized
INFO - 2021-07-01 07:09:17 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:09:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:09:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:09:17 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:09:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:09:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:09:17 --> Final output sent to browser
DEBUG - 2021-07-01 07:09:17 --> Total execution time: 0.0739
INFO - 2021-07-01 07:09:25 --> Config Class Initialized
INFO - 2021-07-01 07:09:25 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:09:25 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:09:25 --> Utf8 Class Initialized
INFO - 2021-07-01 07:09:25 --> URI Class Initialized
INFO - 2021-07-01 07:09:25 --> Router Class Initialized
INFO - 2021-07-01 07:09:25 --> Output Class Initialized
INFO - 2021-07-01 07:09:25 --> Security Class Initialized
DEBUG - 2021-07-01 07:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:09:25 --> Input Class Initialized
INFO - 2021-07-01 07:09:25 --> Language Class Initialized
INFO - 2021-07-01 07:09:25 --> Loader Class Initialized
INFO - 2021-07-01 07:09:25 --> Helper loaded: html_helper
INFO - 2021-07-01 07:09:25 --> Helper loaded: url_helper
INFO - 2021-07-01 07:09:25 --> Helper loaded: form_helper
INFO - 2021-07-01 07:09:25 --> Database Driver Class Initialized
INFO - 2021-07-01 07:09:25 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:09:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:09:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:09:25 --> Encryption Class Initialized
INFO - 2021-07-01 07:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:09:25 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:09:25 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:09:25 --> Model "user_model" initialized
INFO - 2021-07-01 07:09:25 --> Model "role_model" initialized
INFO - 2021-07-01 07:09:25 --> Controller Class Initialized
INFO - 2021-07-01 07:09:25 --> Helper loaded: language_helper
INFO - 2021-07-01 07:09:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:09:25 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:09:25 --> Final output sent to browser
DEBUG - 2021-07-01 07:09:25 --> Total execution time: 0.0602
INFO - 2021-07-01 07:09:52 --> Config Class Initialized
INFO - 2021-07-01 07:09:52 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:09:52 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:09:52 --> Utf8 Class Initialized
INFO - 2021-07-01 07:09:52 --> URI Class Initialized
INFO - 2021-07-01 07:09:52 --> Router Class Initialized
INFO - 2021-07-01 07:09:52 --> Output Class Initialized
INFO - 2021-07-01 07:09:52 --> Security Class Initialized
DEBUG - 2021-07-01 07:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:09:52 --> Input Class Initialized
INFO - 2021-07-01 07:09:52 --> Language Class Initialized
INFO - 2021-07-01 07:09:52 --> Loader Class Initialized
INFO - 2021-07-01 07:09:52 --> Helper loaded: html_helper
INFO - 2021-07-01 07:09:52 --> Helper loaded: url_helper
INFO - 2021-07-01 07:09:52 --> Helper loaded: form_helper
INFO - 2021-07-01 07:09:52 --> Database Driver Class Initialized
INFO - 2021-07-01 07:09:52 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:09:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:09:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:09:52 --> Encryption Class Initialized
INFO - 2021-07-01 07:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:09:52 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:09:52 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:09:52 --> Model "user_model" initialized
INFO - 2021-07-01 07:09:52 --> Model "role_model" initialized
INFO - 2021-07-01 07:09:52 --> Controller Class Initialized
INFO - 2021-07-01 07:09:52 --> Helper loaded: language_helper
INFO - 2021-07-01 07:09:52 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:09:52 --> Model "Product_model" initialized
INFO - 2021-07-01 07:09:52 --> Final output sent to browser
DEBUG - 2021-07-01 07:09:52 --> Total execution time: 0.0637
INFO - 2021-07-01 07:10:05 --> Config Class Initialized
INFO - 2021-07-01 07:10:05 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:10:05 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:10:05 --> Utf8 Class Initialized
INFO - 2021-07-01 07:10:05 --> URI Class Initialized
INFO - 2021-07-01 07:10:05 --> Router Class Initialized
INFO - 2021-07-01 07:10:05 --> Output Class Initialized
INFO - 2021-07-01 07:10:05 --> Security Class Initialized
DEBUG - 2021-07-01 07:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:10:05 --> Input Class Initialized
INFO - 2021-07-01 07:10:05 --> Language Class Initialized
INFO - 2021-07-01 07:10:05 --> Loader Class Initialized
INFO - 2021-07-01 07:10:05 --> Helper loaded: html_helper
INFO - 2021-07-01 07:10:05 --> Helper loaded: url_helper
INFO - 2021-07-01 07:10:05 --> Helper loaded: form_helper
INFO - 2021-07-01 07:10:05 --> Database Driver Class Initialized
INFO - 2021-07-01 07:10:05 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:10:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:10:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:10:05 --> Encryption Class Initialized
INFO - 2021-07-01 07:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:10:05 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:10:05 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:10:05 --> Model "user_model" initialized
INFO - 2021-07-01 07:10:05 --> Model "role_model" initialized
INFO - 2021-07-01 07:10:05 --> Controller Class Initialized
INFO - 2021-07-01 07:10:05 --> Helper loaded: language_helper
INFO - 2021-07-01 07:10:05 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:10:05 --> Model "Quotation_model" initialized
INFO - 2021-07-01 07:10:05 --> Final output sent to browser
DEBUG - 2021-07-01 07:10:05 --> Total execution time: 0.0721
INFO - 2021-07-01 07:10:05 --> Config Class Initialized
INFO - 2021-07-01 07:10:05 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:10:05 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:10:05 --> Utf8 Class Initialized
INFO - 2021-07-01 07:10:05 --> URI Class Initialized
INFO - 2021-07-01 07:10:05 --> Router Class Initialized
INFO - 2021-07-01 07:10:05 --> Output Class Initialized
INFO - 2021-07-01 07:10:05 --> Security Class Initialized
DEBUG - 2021-07-01 07:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:10:05 --> Input Class Initialized
INFO - 2021-07-01 07:10:05 --> Language Class Initialized
INFO - 2021-07-01 07:10:05 --> Loader Class Initialized
INFO - 2021-07-01 07:10:05 --> Helper loaded: html_helper
INFO - 2021-07-01 07:10:05 --> Helper loaded: url_helper
INFO - 2021-07-01 07:10:05 --> Helper loaded: form_helper
INFO - 2021-07-01 07:10:05 --> Database Driver Class Initialized
INFO - 2021-07-01 07:10:05 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:10:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:10:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:10:05 --> Encryption Class Initialized
INFO - 2021-07-01 07:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:10:05 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:10:05 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:10:05 --> Model "user_model" initialized
INFO - 2021-07-01 07:10:05 --> Model "role_model" initialized
INFO - 2021-07-01 07:10:05 --> Controller Class Initialized
INFO - 2021-07-01 07:10:05 --> Helper loaded: language_helper
INFO - 2021-07-01 07:10:05 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:10:05 --> Model "Quotation_model" initialized
INFO - 2021-07-01 07:10:05 --> Final output sent to browser
DEBUG - 2021-07-01 07:10:05 --> Total execution time: 0.0662
INFO - 2021-07-01 07:10:06 --> Config Class Initialized
INFO - 2021-07-01 07:10:06 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:10:06 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:10:06 --> Utf8 Class Initialized
INFO - 2021-07-01 07:10:06 --> URI Class Initialized
INFO - 2021-07-01 07:10:06 --> Router Class Initialized
INFO - 2021-07-01 07:10:06 --> Output Class Initialized
INFO - 2021-07-01 07:10:06 --> Security Class Initialized
DEBUG - 2021-07-01 07:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:10:06 --> Input Class Initialized
INFO - 2021-07-01 07:10:06 --> Language Class Initialized
INFO - 2021-07-01 07:10:06 --> Loader Class Initialized
INFO - 2021-07-01 07:10:06 --> Helper loaded: html_helper
INFO - 2021-07-01 07:10:06 --> Helper loaded: url_helper
INFO - 2021-07-01 07:10:06 --> Helper loaded: form_helper
INFO - 2021-07-01 07:10:06 --> Database Driver Class Initialized
INFO - 2021-07-01 07:10:06 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:10:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:10:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:10:06 --> Encryption Class Initialized
INFO - 2021-07-01 07:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:10:06 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:10:06 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:10:06 --> Model "user_model" initialized
INFO - 2021-07-01 07:10:06 --> Model "role_model" initialized
INFO - 2021-07-01 07:10:06 --> Controller Class Initialized
INFO - 2021-07-01 07:10:06 --> Helper loaded: language_helper
INFO - 2021-07-01 07:10:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:10:06 --> Model "Quotation_model" initialized
INFO - 2021-07-01 07:10:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:10:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:10:06 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 07:10:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 07:10:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:10:06 --> Final output sent to browser
DEBUG - 2021-07-01 07:10:06 --> Total execution time: 0.0661
INFO - 2021-07-01 07:10:07 --> Config Class Initialized
INFO - 2021-07-01 07:10:07 --> Hooks Class Initialized
INFO - 2021-07-01 07:10:07 --> Config Class Initialized
INFO - 2021-07-01 07:10:07 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:10:07 --> UTF-8 Support Enabled
DEBUG - 2021-07-01 07:10:07 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:10:07 --> Utf8 Class Initialized
INFO - 2021-07-01 07:10:07 --> Utf8 Class Initialized
INFO - 2021-07-01 07:10:07 --> URI Class Initialized
INFO - 2021-07-01 07:10:07 --> URI Class Initialized
INFO - 2021-07-01 07:10:07 --> Router Class Initialized
INFO - 2021-07-01 07:10:07 --> Router Class Initialized
INFO - 2021-07-01 07:10:07 --> Output Class Initialized
INFO - 2021-07-01 07:10:07 --> Output Class Initialized
INFO - 2021-07-01 07:10:07 --> Security Class Initialized
INFO - 2021-07-01 07:10:07 --> Security Class Initialized
DEBUG - 2021-07-01 07:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:10:07 --> Input Class Initialized
DEBUG - 2021-07-01 07:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:10:07 --> Input Class Initialized
INFO - 2021-07-01 07:10:07 --> Language Class Initialized
INFO - 2021-07-01 07:10:07 --> Language Class Initialized
INFO - 2021-07-01 07:10:07 --> Loader Class Initialized
INFO - 2021-07-01 07:10:07 --> Loader Class Initialized
INFO - 2021-07-01 07:10:07 --> Helper loaded: html_helper
INFO - 2021-07-01 07:10:07 --> Helper loaded: html_helper
INFO - 2021-07-01 07:10:07 --> Helper loaded: url_helper
INFO - 2021-07-01 07:10:07 --> Helper loaded: url_helper
INFO - 2021-07-01 07:10:07 --> Helper loaded: form_helper
INFO - 2021-07-01 07:10:07 --> Helper loaded: form_helper
INFO - 2021-07-01 07:10:08 --> Database Driver Class Initialized
INFO - 2021-07-01 07:10:08 --> Database Driver Class Initialized
INFO - 2021-07-01 07:10:08 --> Form Validation Class Initialized
INFO - 2021-07-01 07:10:08 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:10:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:10:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:10:08 --> Encryption Class Initialized
DEBUG - 2021-07-01 07:10:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:10:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:10:08 --> Encryption Class Initialized
INFO - 2021-07-01 07:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:10:08 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:10:08 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:10:08 --> Model "user_model" initialized
INFO - 2021-07-01 07:10:08 --> Model "role_model" initialized
INFO - 2021-07-01 07:10:08 --> Controller Class Initialized
INFO - 2021-07-01 07:10:08 --> Helper loaded: language_helper
INFO - 2021-07-01 07:10:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:10:08 --> Model "Quotation_model" initialized
INFO - 2021-07-01 07:10:08 --> Final output sent to browser
DEBUG - 2021-07-01 07:10:08 --> Total execution time: 0.0930
INFO - 2021-07-01 07:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:10:08 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:10:08 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:10:08 --> Model "user_model" initialized
INFO - 2021-07-01 07:10:08 --> Model "role_model" initialized
INFO - 2021-07-01 07:10:08 --> Controller Class Initialized
INFO - 2021-07-01 07:10:08 --> Helper loaded: language_helper
INFO - 2021-07-01 07:10:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:10:08 --> Model "Quotation_model" initialized
INFO - 2021-07-01 07:10:08 --> Final output sent to browser
DEBUG - 2021-07-01 07:10:08 --> Total execution time: 0.1038
INFO - 2021-07-01 07:10:21 --> Config Class Initialized
INFO - 2021-07-01 07:10:21 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:10:21 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:10:21 --> Utf8 Class Initialized
INFO - 2021-07-01 07:10:21 --> URI Class Initialized
INFO - 2021-07-01 07:10:21 --> Router Class Initialized
INFO - 2021-07-01 07:10:21 --> Output Class Initialized
INFO - 2021-07-01 07:10:21 --> Security Class Initialized
DEBUG - 2021-07-01 07:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:10:21 --> Input Class Initialized
INFO - 2021-07-01 07:10:21 --> Language Class Initialized
INFO - 2021-07-01 07:10:21 --> Loader Class Initialized
INFO - 2021-07-01 07:10:21 --> Helper loaded: html_helper
INFO - 2021-07-01 07:10:21 --> Helper loaded: url_helper
INFO - 2021-07-01 07:10:21 --> Helper loaded: form_helper
INFO - 2021-07-01 07:10:21 --> Database Driver Class Initialized
INFO - 2021-07-01 07:10:21 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:10:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:10:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:10:21 --> Encryption Class Initialized
INFO - 2021-07-01 07:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:10:21 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:10:21 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:10:21 --> Model "user_model" initialized
INFO - 2021-07-01 07:10:21 --> Model "role_model" initialized
INFO - 2021-07-01 07:10:21 --> Controller Class Initialized
INFO - 2021-07-01 07:10:21 --> Helper loaded: language_helper
INFO - 2021-07-01 07:10:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:10:21 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:10:21 --> Model "Product_model" initialized
INFO - 2021-07-01 07:10:21 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:10:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:10:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:10:21 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:10:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:10:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:10:21 --> Final output sent to browser
DEBUG - 2021-07-01 07:10:21 --> Total execution time: 0.0662
INFO - 2021-07-01 07:10:23 --> Config Class Initialized
INFO - 2021-07-01 07:10:23 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:10:23 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:10:23 --> Utf8 Class Initialized
INFO - 2021-07-01 07:10:23 --> URI Class Initialized
INFO - 2021-07-01 07:10:23 --> Router Class Initialized
INFO - 2021-07-01 07:10:23 --> Output Class Initialized
INFO - 2021-07-01 07:10:23 --> Security Class Initialized
DEBUG - 2021-07-01 07:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:10:23 --> Input Class Initialized
INFO - 2021-07-01 07:10:23 --> Language Class Initialized
INFO - 2021-07-01 07:10:23 --> Loader Class Initialized
INFO - 2021-07-01 07:10:23 --> Helper loaded: html_helper
INFO - 2021-07-01 07:10:23 --> Helper loaded: url_helper
INFO - 2021-07-01 07:10:23 --> Helper loaded: form_helper
INFO - 2021-07-01 07:10:23 --> Database Driver Class Initialized
INFO - 2021-07-01 07:10:23 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:10:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:10:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:10:23 --> Encryption Class Initialized
INFO - 2021-07-01 07:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:10:23 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:10:23 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:10:23 --> Model "user_model" initialized
INFO - 2021-07-01 07:10:23 --> Model "role_model" initialized
INFO - 2021-07-01 07:10:23 --> Controller Class Initialized
INFO - 2021-07-01 07:10:23 --> Helper loaded: language_helper
INFO - 2021-07-01 07:10:23 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:10:23 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:10:23 --> Model "Product_model" initialized
INFO - 2021-07-01 07:10:23 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:10:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:10:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:10:23 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:10:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:10:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:10:23 --> Final output sent to browser
DEBUG - 2021-07-01 07:10:23 --> Total execution time: 0.0960
INFO - 2021-07-01 07:22:05 --> Config Class Initialized
INFO - 2021-07-01 07:22:05 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:22:05 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:22:05 --> Utf8 Class Initialized
INFO - 2021-07-01 07:22:05 --> URI Class Initialized
INFO - 2021-07-01 07:22:05 --> Router Class Initialized
INFO - 2021-07-01 07:22:05 --> Output Class Initialized
INFO - 2021-07-01 07:22:05 --> Security Class Initialized
DEBUG - 2021-07-01 07:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:22:05 --> Input Class Initialized
INFO - 2021-07-01 07:22:05 --> Language Class Initialized
INFO - 2021-07-01 07:22:05 --> Loader Class Initialized
INFO - 2021-07-01 07:22:05 --> Helper loaded: html_helper
INFO - 2021-07-01 07:22:05 --> Helper loaded: url_helper
INFO - 2021-07-01 07:22:05 --> Helper loaded: form_helper
INFO - 2021-07-01 07:22:05 --> Database Driver Class Initialized
INFO - 2021-07-01 07:22:05 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:22:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:22:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:22:05 --> Encryption Class Initialized
INFO - 2021-07-01 07:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:22:05 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:22:05 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:22:05 --> Model "user_model" initialized
INFO - 2021-07-01 07:22:05 --> Model "role_model" initialized
INFO - 2021-07-01 07:22:05 --> Controller Class Initialized
INFO - 2021-07-01 07:22:05 --> Helper loaded: language_helper
INFO - 2021-07-01 07:22:05 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:22:05 --> Model "Quotation_model" initialized
INFO - 2021-07-01 07:22:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:22:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:22:05 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 07:22:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 07:22:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:22:05 --> Final output sent to browser
DEBUG - 2021-07-01 07:22:05 --> Total execution time: 0.0874
INFO - 2021-07-01 07:22:10 --> Config Class Initialized
INFO - 2021-07-01 07:22:10 --> Hooks Class Initialized
INFO - 2021-07-01 07:22:10 --> Config Class Initialized
INFO - 2021-07-01 07:22:10 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:22:10 --> UTF-8 Support Enabled
DEBUG - 2021-07-01 07:22:10 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:22:10 --> Utf8 Class Initialized
INFO - 2021-07-01 07:22:10 --> Utf8 Class Initialized
INFO - 2021-07-01 07:22:10 --> URI Class Initialized
INFO - 2021-07-01 07:22:10 --> URI Class Initialized
INFO - 2021-07-01 07:22:10 --> Router Class Initialized
INFO - 2021-07-01 07:22:10 --> Router Class Initialized
INFO - 2021-07-01 07:22:10 --> Output Class Initialized
INFO - 2021-07-01 07:22:10 --> Output Class Initialized
INFO - 2021-07-01 07:22:10 --> Security Class Initialized
INFO - 2021-07-01 07:22:10 --> Security Class Initialized
DEBUG - 2021-07-01 07:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:22:10 --> Input Class Initialized
INFO - 2021-07-01 07:22:10 --> Language Class Initialized
DEBUG - 2021-07-01 07:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:22:10 --> Input Class Initialized
INFO - 2021-07-01 07:22:10 --> Language Class Initialized
INFO - 2021-07-01 07:22:10 --> Loader Class Initialized
INFO - 2021-07-01 07:22:10 --> Helper loaded: html_helper
INFO - 2021-07-01 07:22:10 --> Loader Class Initialized
INFO - 2021-07-01 07:22:10 --> Helper loaded: url_helper
INFO - 2021-07-01 07:22:10 --> Helper loaded: html_helper
INFO - 2021-07-01 07:22:10 --> Helper loaded: form_helper
INFO - 2021-07-01 07:22:10 --> Helper loaded: url_helper
INFO - 2021-07-01 07:22:10 --> Helper loaded: form_helper
INFO - 2021-07-01 07:22:10 --> Database Driver Class Initialized
INFO - 2021-07-01 07:22:10 --> Database Driver Class Initialized
INFO - 2021-07-01 07:22:10 --> Form Validation Class Initialized
INFO - 2021-07-01 07:22:10 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-01 07:22:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:22:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:22:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:22:10 --> Encryption Class Initialized
INFO - 2021-07-01 07:22:10 --> Encryption Class Initialized
INFO - 2021-07-01 07:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:22:10 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:22:10 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:22:10 --> Model "user_model" initialized
INFO - 2021-07-01 07:22:10 --> Model "role_model" initialized
INFO - 2021-07-01 07:22:10 --> Controller Class Initialized
INFO - 2021-07-01 07:22:10 --> Helper loaded: language_helper
INFO - 2021-07-01 07:22:10 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:22:10 --> Model "Quotation_model" initialized
INFO - 2021-07-01 07:22:10 --> Final output sent to browser
DEBUG - 2021-07-01 07:22:10 --> Total execution time: 0.0900
INFO - 2021-07-01 07:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:22:10 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:22:10 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:22:10 --> Model "user_model" initialized
INFO - 2021-07-01 07:22:10 --> Model "role_model" initialized
INFO - 2021-07-01 07:22:10 --> Controller Class Initialized
INFO - 2021-07-01 07:22:10 --> Helper loaded: language_helper
INFO - 2021-07-01 07:22:10 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:22:10 --> Model "Quotation_model" initialized
INFO - 2021-07-01 07:22:10 --> Final output sent to browser
DEBUG - 2021-07-01 07:22:10 --> Total execution time: 0.1009
INFO - 2021-07-01 07:32:20 --> Config Class Initialized
INFO - 2021-07-01 07:32:20 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:32:20 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:32:20 --> Utf8 Class Initialized
INFO - 2021-07-01 07:32:20 --> URI Class Initialized
INFO - 2021-07-01 07:32:20 --> Router Class Initialized
INFO - 2021-07-01 07:32:20 --> Output Class Initialized
INFO - 2021-07-01 07:32:20 --> Security Class Initialized
DEBUG - 2021-07-01 07:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:32:20 --> Input Class Initialized
INFO - 2021-07-01 07:32:20 --> Language Class Initialized
INFO - 2021-07-01 07:32:20 --> Loader Class Initialized
INFO - 2021-07-01 07:32:20 --> Helper loaded: html_helper
INFO - 2021-07-01 07:32:20 --> Helper loaded: url_helper
INFO - 2021-07-01 07:32:20 --> Helper loaded: form_helper
INFO - 2021-07-01 07:32:20 --> Database Driver Class Initialized
INFO - 2021-07-01 07:32:20 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:32:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:32:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:32:20 --> Encryption Class Initialized
INFO - 2021-07-01 07:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:32:20 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:32:20 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:32:20 --> Model "user_model" initialized
INFO - 2021-07-01 07:32:20 --> Model "role_model" initialized
INFO - 2021-07-01 07:32:20 --> Controller Class Initialized
INFO - 2021-07-01 07:32:20 --> Helper loaded: language_helper
INFO - 2021-07-01 07:32:20 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:32:20 --> Model "Quotation_model" initialized
INFO - 2021-07-01 07:32:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:32:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:32:20 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 07:32:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 07:32:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:32:20 --> Final output sent to browser
DEBUG - 2021-07-01 07:32:20 --> Total execution time: 0.1222
INFO - 2021-07-01 07:32:25 --> Config Class Initialized
INFO - 2021-07-01 07:32:25 --> Hooks Class Initialized
INFO - 2021-07-01 07:32:25 --> Config Class Initialized
INFO - 2021-07-01 07:32:25 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:32:25 --> UTF-8 Support Enabled
DEBUG - 2021-07-01 07:32:25 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:32:25 --> Utf8 Class Initialized
INFO - 2021-07-01 07:32:25 --> Utf8 Class Initialized
INFO - 2021-07-01 07:32:25 --> URI Class Initialized
INFO - 2021-07-01 07:32:25 --> URI Class Initialized
INFO - 2021-07-01 07:32:25 --> Router Class Initialized
INFO - 2021-07-01 07:32:25 --> Router Class Initialized
INFO - 2021-07-01 07:32:25 --> Output Class Initialized
INFO - 2021-07-01 07:32:25 --> Output Class Initialized
INFO - 2021-07-01 07:32:25 --> Security Class Initialized
INFO - 2021-07-01 07:32:25 --> Security Class Initialized
DEBUG - 2021-07-01 07:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:32:25 --> Input Class Initialized
DEBUG - 2021-07-01 07:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:32:25 --> Input Class Initialized
INFO - 2021-07-01 07:32:25 --> Language Class Initialized
INFO - 2021-07-01 07:32:25 --> Language Class Initialized
INFO - 2021-07-01 07:32:25 --> Loader Class Initialized
INFO - 2021-07-01 07:32:25 --> Loader Class Initialized
INFO - 2021-07-01 07:32:25 --> Helper loaded: html_helper
INFO - 2021-07-01 07:32:25 --> Helper loaded: html_helper
INFO - 2021-07-01 07:32:25 --> Helper loaded: url_helper
INFO - 2021-07-01 07:32:25 --> Helper loaded: url_helper
INFO - 2021-07-01 07:32:25 --> Helper loaded: form_helper
INFO - 2021-07-01 07:32:25 --> Helper loaded: form_helper
INFO - 2021-07-01 07:32:25 --> Database Driver Class Initialized
INFO - 2021-07-01 07:32:25 --> Database Driver Class Initialized
INFO - 2021-07-01 07:32:25 --> Form Validation Class Initialized
INFO - 2021-07-01 07:32:25 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-01 07:32:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:32:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:32:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:32:25 --> Encryption Class Initialized
INFO - 2021-07-01 07:32:25 --> Encryption Class Initialized
INFO - 2021-07-01 07:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:32:25 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:32:25 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:32:25 --> Model "user_model" initialized
INFO - 2021-07-01 07:32:25 --> Model "role_model" initialized
INFO - 2021-07-01 07:32:25 --> Controller Class Initialized
INFO - 2021-07-01 07:32:25 --> Helper loaded: language_helper
INFO - 2021-07-01 07:32:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:32:25 --> Model "Quotation_model" initialized
INFO - 2021-07-01 07:32:25 --> Final output sent to browser
DEBUG - 2021-07-01 07:32:25 --> Total execution time: 0.0715
INFO - 2021-07-01 07:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:32:25 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:32:25 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:32:25 --> Model "user_model" initialized
INFO - 2021-07-01 07:32:25 --> Model "role_model" initialized
INFO - 2021-07-01 07:32:25 --> Controller Class Initialized
INFO - 2021-07-01 07:32:25 --> Helper loaded: language_helper
INFO - 2021-07-01 07:32:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:32:26 --> Model "Quotation_model" initialized
INFO - 2021-07-01 07:32:26 --> Final output sent to browser
DEBUG - 2021-07-01 07:32:26 --> Total execution time: 0.0808
INFO - 2021-07-01 07:32:29 --> Config Class Initialized
INFO - 2021-07-01 07:32:29 --> Config Class Initialized
INFO - 2021-07-01 07:32:29 --> Hooks Class Initialized
INFO - 2021-07-01 07:32:29 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:32:29 --> UTF-8 Support Enabled
DEBUG - 2021-07-01 07:32:29 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:32:29 --> Utf8 Class Initialized
INFO - 2021-07-01 07:32:29 --> Utf8 Class Initialized
INFO - 2021-07-01 07:32:29 --> URI Class Initialized
INFO - 2021-07-01 07:32:29 --> URI Class Initialized
INFO - 2021-07-01 07:32:29 --> Router Class Initialized
INFO - 2021-07-01 07:32:29 --> Router Class Initialized
INFO - 2021-07-01 07:32:29 --> Output Class Initialized
INFO - 2021-07-01 07:32:29 --> Output Class Initialized
INFO - 2021-07-01 07:32:29 --> Security Class Initialized
INFO - 2021-07-01 07:32:29 --> Security Class Initialized
DEBUG - 2021-07-01 07:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-01 07:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:32:29 --> Input Class Initialized
INFO - 2021-07-01 07:32:29 --> Input Class Initialized
INFO - 2021-07-01 07:32:29 --> Language Class Initialized
INFO - 2021-07-01 07:32:29 --> Language Class Initialized
INFO - 2021-07-01 07:32:29 --> Loader Class Initialized
INFO - 2021-07-01 07:32:29 --> Loader Class Initialized
INFO - 2021-07-01 07:32:29 --> Helper loaded: html_helper
INFO - 2021-07-01 07:32:29 --> Helper loaded: html_helper
INFO - 2021-07-01 07:32:29 --> Helper loaded: url_helper
INFO - 2021-07-01 07:32:29 --> Helper loaded: url_helper
INFO - 2021-07-01 07:32:29 --> Helper loaded: form_helper
INFO - 2021-07-01 07:32:29 --> Helper loaded: form_helper
INFO - 2021-07-01 07:32:29 --> Database Driver Class Initialized
INFO - 2021-07-01 07:32:29 --> Database Driver Class Initialized
INFO - 2021-07-01 07:32:29 --> Form Validation Class Initialized
INFO - 2021-07-01 07:32:29 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-01 07:32:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:32:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:32:29 --> Encryption Class Initialized
INFO - 2021-07-01 07:32:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:32:29 --> Encryption Class Initialized
INFO - 2021-07-01 07:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:32:29 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:32:29 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:32:29 --> Model "user_model" initialized
INFO - 2021-07-01 07:32:29 --> Model "role_model" initialized
INFO - 2021-07-01 07:32:29 --> Controller Class Initialized
INFO - 2021-07-01 07:32:29 --> Helper loaded: language_helper
INFO - 2021-07-01 07:32:29 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:32:29 --> Model "Quotation_model" initialized
INFO - 2021-07-01 07:32:29 --> Final output sent to browser
DEBUG - 2021-07-01 07:32:29 --> Total execution time: 0.0697
INFO - 2021-07-01 07:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:32:29 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:32:29 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:32:29 --> Model "user_model" initialized
INFO - 2021-07-01 07:32:29 --> Model "role_model" initialized
INFO - 2021-07-01 07:32:29 --> Controller Class Initialized
INFO - 2021-07-01 07:32:29 --> Helper loaded: language_helper
INFO - 2021-07-01 07:32:29 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:32:29 --> Model "Quotation_model" initialized
INFO - 2021-07-01 07:32:29 --> Final output sent to browser
DEBUG - 2021-07-01 07:32:29 --> Total execution time: 0.0807
INFO - 2021-07-01 07:33:45 --> Config Class Initialized
INFO - 2021-07-01 07:33:45 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:33:45 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:33:45 --> Utf8 Class Initialized
INFO - 2021-07-01 07:33:45 --> URI Class Initialized
INFO - 2021-07-01 07:33:45 --> Router Class Initialized
INFO - 2021-07-01 07:33:45 --> Output Class Initialized
INFO - 2021-07-01 07:33:45 --> Security Class Initialized
DEBUG - 2021-07-01 07:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:33:45 --> Input Class Initialized
INFO - 2021-07-01 07:33:45 --> Language Class Initialized
INFO - 2021-07-01 07:33:45 --> Loader Class Initialized
INFO - 2021-07-01 07:33:45 --> Helper loaded: html_helper
INFO - 2021-07-01 07:33:45 --> Helper loaded: url_helper
INFO - 2021-07-01 07:33:45 --> Helper loaded: form_helper
INFO - 2021-07-01 07:33:45 --> Database Driver Class Initialized
INFO - 2021-07-01 07:33:45 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:33:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:33:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:33:45 --> Encryption Class Initialized
INFO - 2021-07-01 07:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:33:45 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:33:45 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:33:45 --> Model "user_model" initialized
INFO - 2021-07-01 07:33:45 --> Model "role_model" initialized
INFO - 2021-07-01 07:33:45 --> Controller Class Initialized
INFO - 2021-07-01 07:33:45 --> Helper loaded: language_helper
INFO - 2021-07-01 07:33:45 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:33:45 --> Model "Quotation_model" initialized
INFO - 2021-07-01 07:33:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:33:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:33:45 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 07:33:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 07:33:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:33:45 --> Final output sent to browser
DEBUG - 2021-07-01 07:33:45 --> Total execution time: 0.0703
INFO - 2021-07-01 07:33:53 --> Config Class Initialized
INFO - 2021-07-01 07:33:53 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:33:53 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:33:53 --> Utf8 Class Initialized
INFO - 2021-07-01 07:33:53 --> URI Class Initialized
INFO - 2021-07-01 07:33:53 --> Router Class Initialized
INFO - 2021-07-01 07:33:53 --> Output Class Initialized
INFO - 2021-07-01 07:33:53 --> Security Class Initialized
DEBUG - 2021-07-01 07:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:33:53 --> Input Class Initialized
INFO - 2021-07-01 07:33:53 --> Language Class Initialized
INFO - 2021-07-01 07:33:53 --> Loader Class Initialized
INFO - 2021-07-01 07:33:53 --> Helper loaded: html_helper
INFO - 2021-07-01 07:33:53 --> Helper loaded: url_helper
INFO - 2021-07-01 07:33:53 --> Helper loaded: form_helper
INFO - 2021-07-01 07:33:53 --> Database Driver Class Initialized
INFO - 2021-07-01 07:33:53 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:33:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:33:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:33:53 --> Encryption Class Initialized
INFO - 2021-07-01 07:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:33:53 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:33:53 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:33:53 --> Model "user_model" initialized
INFO - 2021-07-01 07:33:53 --> Model "role_model" initialized
INFO - 2021-07-01 07:33:53 --> Controller Class Initialized
INFO - 2021-07-01 07:33:53 --> Helper loaded: language_helper
INFO - 2021-07-01 07:33:53 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:33:53 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:33:53 --> Model "Product_model" initialized
INFO - 2021-07-01 07:33:53 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:33:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:33:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:33:53 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:33:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:33:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:33:53 --> Final output sent to browser
DEBUG - 2021-07-01 07:33:53 --> Total execution time: 0.0716
INFO - 2021-07-01 07:36:08 --> Config Class Initialized
INFO - 2021-07-01 07:36:08 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:36:08 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:36:08 --> Utf8 Class Initialized
INFO - 2021-07-01 07:36:08 --> URI Class Initialized
INFO - 2021-07-01 07:36:08 --> Router Class Initialized
INFO - 2021-07-01 07:36:08 --> Output Class Initialized
INFO - 2021-07-01 07:36:08 --> Security Class Initialized
DEBUG - 2021-07-01 07:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:36:09 --> Input Class Initialized
INFO - 2021-07-01 07:36:09 --> Language Class Initialized
INFO - 2021-07-01 07:36:09 --> Loader Class Initialized
INFO - 2021-07-01 07:36:09 --> Helper loaded: html_helper
INFO - 2021-07-01 07:36:09 --> Helper loaded: url_helper
INFO - 2021-07-01 07:36:09 --> Helper loaded: form_helper
INFO - 2021-07-01 07:36:09 --> Database Driver Class Initialized
INFO - 2021-07-01 07:36:09 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:36:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:36:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:36:09 --> Encryption Class Initialized
INFO - 2021-07-01 07:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:36:09 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:36:09 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:36:09 --> Model "user_model" initialized
INFO - 2021-07-01 07:36:09 --> Model "role_model" initialized
INFO - 2021-07-01 07:36:09 --> Controller Class Initialized
INFO - 2021-07-01 07:36:09 --> Helper loaded: language_helper
INFO - 2021-07-01 07:36:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:36:09 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:36:09 --> Model "Product_model" initialized
INFO - 2021-07-01 07:36:09 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:36:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:36:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:36:09 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:36:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:36:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:36:09 --> Final output sent to browser
DEBUG - 2021-07-01 07:36:09 --> Total execution time: 0.0793
INFO - 2021-07-01 07:37:19 --> Config Class Initialized
INFO - 2021-07-01 07:37:19 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:37:19 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:37:19 --> Utf8 Class Initialized
INFO - 2021-07-01 07:37:19 --> URI Class Initialized
INFO - 2021-07-01 07:37:19 --> Router Class Initialized
INFO - 2021-07-01 07:37:19 --> Output Class Initialized
INFO - 2021-07-01 07:37:19 --> Security Class Initialized
DEBUG - 2021-07-01 07:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:37:19 --> Input Class Initialized
INFO - 2021-07-01 07:37:19 --> Language Class Initialized
INFO - 2021-07-01 07:37:19 --> Loader Class Initialized
INFO - 2021-07-01 07:37:19 --> Helper loaded: html_helper
INFO - 2021-07-01 07:37:19 --> Helper loaded: url_helper
INFO - 2021-07-01 07:37:19 --> Helper loaded: form_helper
INFO - 2021-07-01 07:37:19 --> Database Driver Class Initialized
INFO - 2021-07-01 07:37:19 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:37:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:37:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:37:19 --> Encryption Class Initialized
INFO - 2021-07-01 07:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:37:19 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:37:19 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:37:19 --> Model "user_model" initialized
INFO - 2021-07-01 07:37:19 --> Model "role_model" initialized
INFO - 2021-07-01 07:37:19 --> Controller Class Initialized
INFO - 2021-07-01 07:37:19 --> Helper loaded: language_helper
INFO - 2021-07-01 07:37:19 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:37:19 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:37:19 --> Model "Product_model" initialized
INFO - 2021-07-01 07:37:19 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:37:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:37:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:37:19 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:37:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:37:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:37:19 --> Final output sent to browser
DEBUG - 2021-07-01 07:37:19 --> Total execution time: 0.0759
INFO - 2021-07-01 07:37:20 --> Config Class Initialized
INFO - 2021-07-01 07:37:20 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:37:20 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:37:20 --> Utf8 Class Initialized
INFO - 2021-07-01 07:37:20 --> URI Class Initialized
INFO - 2021-07-01 07:37:20 --> Router Class Initialized
INFO - 2021-07-01 07:37:20 --> Output Class Initialized
INFO - 2021-07-01 07:37:20 --> Security Class Initialized
DEBUG - 2021-07-01 07:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:37:20 --> Input Class Initialized
INFO - 2021-07-01 07:37:20 --> Language Class Initialized
INFO - 2021-07-01 07:37:20 --> Loader Class Initialized
INFO - 2021-07-01 07:37:20 --> Helper loaded: html_helper
INFO - 2021-07-01 07:37:20 --> Helper loaded: url_helper
INFO - 2021-07-01 07:37:20 --> Helper loaded: form_helper
INFO - 2021-07-01 07:37:21 --> Database Driver Class Initialized
INFO - 2021-07-01 07:37:21 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:37:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:37:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:37:21 --> Encryption Class Initialized
INFO - 2021-07-01 07:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:37:21 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:37:21 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:37:21 --> Model "user_model" initialized
INFO - 2021-07-01 07:37:21 --> Model "role_model" initialized
INFO - 2021-07-01 07:37:21 --> Controller Class Initialized
INFO - 2021-07-01 07:37:21 --> Helper loaded: language_helper
INFO - 2021-07-01 07:37:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:37:21 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:37:21 --> Model "Product_model" initialized
INFO - 2021-07-01 07:37:21 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:37:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:37:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:37:21 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:37:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:37:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:37:21 --> Final output sent to browser
DEBUG - 2021-07-01 07:37:21 --> Total execution time: 0.0724
INFO - 2021-07-01 07:37:22 --> Config Class Initialized
INFO - 2021-07-01 07:37:22 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:37:22 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:37:22 --> Utf8 Class Initialized
INFO - 2021-07-01 07:37:22 --> URI Class Initialized
INFO - 2021-07-01 07:37:22 --> Router Class Initialized
INFO - 2021-07-01 07:37:22 --> Output Class Initialized
INFO - 2021-07-01 07:37:22 --> Security Class Initialized
DEBUG - 2021-07-01 07:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:37:22 --> Input Class Initialized
INFO - 2021-07-01 07:37:22 --> Language Class Initialized
INFO - 2021-07-01 07:37:22 --> Loader Class Initialized
INFO - 2021-07-01 07:37:22 --> Helper loaded: html_helper
INFO - 2021-07-01 07:37:22 --> Helper loaded: url_helper
INFO - 2021-07-01 07:37:22 --> Helper loaded: form_helper
INFO - 2021-07-01 07:37:22 --> Database Driver Class Initialized
INFO - 2021-07-01 07:37:22 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:37:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:37:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:37:22 --> Encryption Class Initialized
INFO - 2021-07-01 07:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:37:22 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:37:22 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:37:22 --> Model "user_model" initialized
INFO - 2021-07-01 07:37:22 --> Model "role_model" initialized
INFO - 2021-07-01 07:37:22 --> Controller Class Initialized
INFO - 2021-07-01 07:37:22 --> Helper loaded: language_helper
INFO - 2021-07-01 07:37:22 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:37:22 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:37:22 --> Model "Product_model" initialized
INFO - 2021-07-01 07:37:22 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:37:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:37:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:37:22 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:37:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:37:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:37:22 --> Final output sent to browser
DEBUG - 2021-07-01 07:37:22 --> Total execution time: 0.0755
INFO - 2021-07-01 07:37:31 --> Config Class Initialized
INFO - 2021-07-01 07:37:31 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:37:31 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:37:31 --> Utf8 Class Initialized
INFO - 2021-07-01 07:37:31 --> URI Class Initialized
INFO - 2021-07-01 07:37:31 --> Router Class Initialized
INFO - 2021-07-01 07:37:31 --> Output Class Initialized
INFO - 2021-07-01 07:37:31 --> Security Class Initialized
DEBUG - 2021-07-01 07:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:37:31 --> Input Class Initialized
INFO - 2021-07-01 07:37:31 --> Language Class Initialized
INFO - 2021-07-01 07:37:31 --> Loader Class Initialized
INFO - 2021-07-01 07:37:31 --> Helper loaded: html_helper
INFO - 2021-07-01 07:37:31 --> Helper loaded: url_helper
INFO - 2021-07-01 07:37:31 --> Helper loaded: form_helper
INFO - 2021-07-01 07:37:31 --> Database Driver Class Initialized
INFO - 2021-07-01 07:37:31 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:37:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:37:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:37:32 --> Encryption Class Initialized
INFO - 2021-07-01 07:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:37:32 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:37:32 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:37:32 --> Model "user_model" initialized
INFO - 2021-07-01 07:37:32 --> Model "role_model" initialized
INFO - 2021-07-01 07:37:32 --> Controller Class Initialized
INFO - 2021-07-01 07:37:32 --> Helper loaded: language_helper
INFO - 2021-07-01 07:37:32 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:37:32 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:37:32 --> Final output sent to browser
DEBUG - 2021-07-01 07:37:32 --> Total execution time: 0.0595
INFO - 2021-07-01 07:37:56 --> Config Class Initialized
INFO - 2021-07-01 07:37:56 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:37:56 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:37:56 --> Utf8 Class Initialized
INFO - 2021-07-01 07:37:56 --> URI Class Initialized
INFO - 2021-07-01 07:37:56 --> Router Class Initialized
INFO - 2021-07-01 07:37:56 --> Output Class Initialized
INFO - 2021-07-01 07:37:56 --> Security Class Initialized
DEBUG - 2021-07-01 07:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:37:56 --> Input Class Initialized
INFO - 2021-07-01 07:37:56 --> Language Class Initialized
INFO - 2021-07-01 07:37:56 --> Loader Class Initialized
INFO - 2021-07-01 07:37:56 --> Helper loaded: html_helper
INFO - 2021-07-01 07:37:56 --> Helper loaded: url_helper
INFO - 2021-07-01 07:37:56 --> Helper loaded: form_helper
INFO - 2021-07-01 07:37:56 --> Database Driver Class Initialized
INFO - 2021-07-01 07:37:56 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:37:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:37:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:37:56 --> Encryption Class Initialized
INFO - 2021-07-01 07:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:37:56 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:37:56 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:37:56 --> Model "user_model" initialized
INFO - 2021-07-01 07:37:56 --> Model "role_model" initialized
INFO - 2021-07-01 07:37:56 --> Controller Class Initialized
INFO - 2021-07-01 07:37:56 --> Helper loaded: language_helper
INFO - 2021-07-01 07:37:56 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:37:56 --> Model "Product_model" initialized
INFO - 2021-07-01 07:37:56 --> Final output sent to browser
DEBUG - 2021-07-01 07:37:56 --> Total execution time: 0.0636
INFO - 2021-07-01 07:38:09 --> Config Class Initialized
INFO - 2021-07-01 07:38:09 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:38:09 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:38:09 --> Utf8 Class Initialized
INFO - 2021-07-01 07:38:09 --> URI Class Initialized
INFO - 2021-07-01 07:38:09 --> Router Class Initialized
INFO - 2021-07-01 07:38:09 --> Output Class Initialized
INFO - 2021-07-01 07:38:09 --> Security Class Initialized
DEBUG - 2021-07-01 07:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:38:09 --> Input Class Initialized
INFO - 2021-07-01 07:38:09 --> Language Class Initialized
INFO - 2021-07-01 07:38:09 --> Loader Class Initialized
INFO - 2021-07-01 07:38:09 --> Helper loaded: html_helper
INFO - 2021-07-01 07:38:09 --> Helper loaded: url_helper
INFO - 2021-07-01 07:38:09 --> Helper loaded: form_helper
INFO - 2021-07-01 07:38:09 --> Database Driver Class Initialized
INFO - 2021-07-01 07:38:09 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:38:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:38:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:38:09 --> Encryption Class Initialized
INFO - 2021-07-01 07:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:38:09 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:38:09 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:38:09 --> Model "user_model" initialized
INFO - 2021-07-01 07:38:09 --> Model "role_model" initialized
INFO - 2021-07-01 07:38:09 --> Controller Class Initialized
INFO - 2021-07-01 07:38:09 --> Helper loaded: language_helper
INFO - 2021-07-01 07:38:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:38:09 --> Model "Quotation_model" initialized
INFO - 2021-07-01 07:38:09 --> Final output sent to browser
DEBUG - 2021-07-01 07:38:09 --> Total execution time: 0.0664
INFO - 2021-07-01 07:38:09 --> Config Class Initialized
INFO - 2021-07-01 07:38:09 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:38:09 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:38:09 --> Utf8 Class Initialized
INFO - 2021-07-01 07:38:09 --> URI Class Initialized
INFO - 2021-07-01 07:38:09 --> Router Class Initialized
INFO - 2021-07-01 07:38:09 --> Output Class Initialized
INFO - 2021-07-01 07:38:09 --> Security Class Initialized
DEBUG - 2021-07-01 07:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:38:09 --> Input Class Initialized
INFO - 2021-07-01 07:38:09 --> Language Class Initialized
INFO - 2021-07-01 07:38:09 --> Loader Class Initialized
INFO - 2021-07-01 07:38:09 --> Helper loaded: html_helper
INFO - 2021-07-01 07:38:09 --> Helper loaded: url_helper
INFO - 2021-07-01 07:38:09 --> Helper loaded: form_helper
INFO - 2021-07-01 07:38:09 --> Database Driver Class Initialized
INFO - 2021-07-01 07:38:10 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:38:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:38:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:38:10 --> Encryption Class Initialized
INFO - 2021-07-01 07:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:38:10 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:38:10 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:38:10 --> Model "user_model" initialized
INFO - 2021-07-01 07:38:10 --> Model "role_model" initialized
INFO - 2021-07-01 07:38:10 --> Controller Class Initialized
INFO - 2021-07-01 07:38:10 --> Helper loaded: language_helper
INFO - 2021-07-01 07:38:10 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:38:10 --> Model "Quotation_model" initialized
INFO - 2021-07-01 07:38:10 --> Final output sent to browser
DEBUG - 2021-07-01 07:38:10 --> Total execution time: 0.0631
INFO - 2021-07-01 07:38:11 --> Config Class Initialized
INFO - 2021-07-01 07:38:11 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:38:11 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:38:11 --> Utf8 Class Initialized
INFO - 2021-07-01 07:38:11 --> URI Class Initialized
INFO - 2021-07-01 07:38:11 --> Router Class Initialized
INFO - 2021-07-01 07:38:11 --> Output Class Initialized
INFO - 2021-07-01 07:38:11 --> Security Class Initialized
DEBUG - 2021-07-01 07:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:38:11 --> Input Class Initialized
INFO - 2021-07-01 07:38:11 --> Language Class Initialized
INFO - 2021-07-01 07:38:11 --> Loader Class Initialized
INFO - 2021-07-01 07:38:11 --> Helper loaded: html_helper
INFO - 2021-07-01 07:38:11 --> Helper loaded: url_helper
INFO - 2021-07-01 07:38:11 --> Helper loaded: form_helper
INFO - 2021-07-01 07:38:11 --> Database Driver Class Initialized
INFO - 2021-07-01 07:38:11 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:38:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:38:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:38:11 --> Encryption Class Initialized
INFO - 2021-07-01 07:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:38:11 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:38:11 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:38:11 --> Model "user_model" initialized
INFO - 2021-07-01 07:38:11 --> Model "role_model" initialized
INFO - 2021-07-01 07:38:11 --> Controller Class Initialized
INFO - 2021-07-01 07:38:11 --> Helper loaded: language_helper
INFO - 2021-07-01 07:38:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:38:11 --> Model "Quotation_model" initialized
INFO - 2021-07-01 07:38:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:38:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:38:11 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 07:38:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 07:38:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:38:11 --> Final output sent to browser
DEBUG - 2021-07-01 07:38:11 --> Total execution time: 0.0775
INFO - 2021-07-01 07:38:12 --> Config Class Initialized
INFO - 2021-07-01 07:38:12 --> Hooks Class Initialized
INFO - 2021-07-01 07:38:12 --> Config Class Initialized
INFO - 2021-07-01 07:38:12 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:38:12 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:38:12 --> Utf8 Class Initialized
INFO - 2021-07-01 07:38:12 --> URI Class Initialized
DEBUG - 2021-07-01 07:38:12 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:38:12 --> Utf8 Class Initialized
INFO - 2021-07-01 07:38:12 --> URI Class Initialized
INFO - 2021-07-01 07:38:12 --> Router Class Initialized
INFO - 2021-07-01 07:38:12 --> Router Class Initialized
INFO - 2021-07-01 07:38:12 --> Output Class Initialized
INFO - 2021-07-01 07:38:12 --> Security Class Initialized
INFO - 2021-07-01 07:38:12 --> Output Class Initialized
DEBUG - 2021-07-01 07:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:38:12 --> Input Class Initialized
INFO - 2021-07-01 07:38:12 --> Security Class Initialized
INFO - 2021-07-01 07:38:12 --> Language Class Initialized
DEBUG - 2021-07-01 07:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:38:12 --> Input Class Initialized
INFO - 2021-07-01 07:38:12 --> Language Class Initialized
INFO - 2021-07-01 07:38:12 --> Loader Class Initialized
INFO - 2021-07-01 07:38:12 --> Helper loaded: html_helper
INFO - 2021-07-01 07:38:12 --> Loader Class Initialized
INFO - 2021-07-01 07:38:12 --> Helper loaded: url_helper
INFO - 2021-07-01 07:38:12 --> Helper loaded: html_helper
INFO - 2021-07-01 07:38:12 --> Helper loaded: url_helper
INFO - 2021-07-01 07:38:12 --> Helper loaded: form_helper
INFO - 2021-07-01 07:38:12 --> Helper loaded: form_helper
INFO - 2021-07-01 07:38:12 --> Database Driver Class Initialized
INFO - 2021-07-01 07:38:12 --> Database Driver Class Initialized
INFO - 2021-07-01 07:38:12 --> Form Validation Class Initialized
INFO - 2021-07-01 07:38:12 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-01 07:38:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:38:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:38:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:38:12 --> Encryption Class Initialized
INFO - 2021-07-01 07:38:12 --> Encryption Class Initialized
INFO - 2021-07-01 07:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:38:12 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:38:12 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:38:12 --> Model "user_model" initialized
INFO - 2021-07-01 07:38:12 --> Model "role_model" initialized
INFO - 2021-07-01 07:38:12 --> Controller Class Initialized
INFO - 2021-07-01 07:38:12 --> Helper loaded: language_helper
INFO - 2021-07-01 07:38:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:38:12 --> Model "Quotation_model" initialized
INFO - 2021-07-01 07:38:12 --> Final output sent to browser
DEBUG - 2021-07-01 07:38:12 --> Total execution time: 0.0666
INFO - 2021-07-01 07:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:38:12 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:38:12 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:38:12 --> Model "user_model" initialized
INFO - 2021-07-01 07:38:12 --> Model "role_model" initialized
INFO - 2021-07-01 07:38:12 --> Controller Class Initialized
INFO - 2021-07-01 07:38:12 --> Helper loaded: language_helper
INFO - 2021-07-01 07:38:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:38:12 --> Model "Quotation_model" initialized
INFO - 2021-07-01 07:38:12 --> Final output sent to browser
DEBUG - 2021-07-01 07:38:12 --> Total execution time: 0.0754
INFO - 2021-07-01 07:38:29 --> Config Class Initialized
INFO - 2021-07-01 07:38:29 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:38:29 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:38:29 --> Utf8 Class Initialized
INFO - 2021-07-01 07:38:29 --> URI Class Initialized
INFO - 2021-07-01 07:38:29 --> Router Class Initialized
INFO - 2021-07-01 07:38:29 --> Output Class Initialized
INFO - 2021-07-01 07:38:29 --> Security Class Initialized
DEBUG - 2021-07-01 07:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:38:29 --> Input Class Initialized
INFO - 2021-07-01 07:38:29 --> Language Class Initialized
INFO - 2021-07-01 07:38:29 --> Loader Class Initialized
INFO - 2021-07-01 07:38:29 --> Helper loaded: html_helper
INFO - 2021-07-01 07:38:29 --> Helper loaded: url_helper
INFO - 2021-07-01 07:38:29 --> Helper loaded: form_helper
INFO - 2021-07-01 07:38:29 --> Database Driver Class Initialized
INFO - 2021-07-01 07:38:29 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:38:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:38:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:38:29 --> Encryption Class Initialized
INFO - 2021-07-01 07:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:38:29 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:38:29 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:38:29 --> Model "user_model" initialized
INFO - 2021-07-01 07:38:29 --> Model "role_model" initialized
INFO - 2021-07-01 07:38:29 --> Controller Class Initialized
INFO - 2021-07-01 07:38:29 --> Helper loaded: language_helper
INFO - 2021-07-01 07:38:29 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:38:29 --> Model "Quotation_model" initialized
INFO - 2021-07-01 07:38:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:38:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:38:29 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 07:38:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 07:38:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:38:29 --> Final output sent to browser
DEBUG - 2021-07-01 07:38:29 --> Total execution time: 0.0694
INFO - 2021-07-01 07:38:50 --> Config Class Initialized
INFO - 2021-07-01 07:38:50 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:38:50 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:38:50 --> Utf8 Class Initialized
INFO - 2021-07-01 07:38:50 --> URI Class Initialized
INFO - 2021-07-01 07:38:50 --> Router Class Initialized
INFO - 2021-07-01 07:38:50 --> Output Class Initialized
INFO - 2021-07-01 07:38:50 --> Security Class Initialized
DEBUG - 2021-07-01 07:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:38:50 --> Input Class Initialized
INFO - 2021-07-01 07:38:50 --> Language Class Initialized
INFO - 2021-07-01 07:38:50 --> Loader Class Initialized
INFO - 2021-07-01 07:38:50 --> Helper loaded: html_helper
INFO - 2021-07-01 07:38:50 --> Helper loaded: url_helper
INFO - 2021-07-01 07:38:50 --> Helper loaded: form_helper
INFO - 2021-07-01 07:38:50 --> Database Driver Class Initialized
INFO - 2021-07-01 07:38:50 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:38:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:38:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:38:50 --> Encryption Class Initialized
INFO - 2021-07-01 07:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:38:50 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:38:50 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:38:50 --> Model "user_model" initialized
INFO - 2021-07-01 07:38:50 --> Model "role_model" initialized
INFO - 2021-07-01 07:38:50 --> Controller Class Initialized
INFO - 2021-07-01 07:38:50 --> Helper loaded: language_helper
INFO - 2021-07-01 07:38:50 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:38:50 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:38:50 --> Model "Product_model" initialized
INFO - 2021-07-01 07:38:50 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:38:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:38:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:38:50 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:38:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:38:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:38:50 --> Final output sent to browser
DEBUG - 2021-07-01 07:38:50 --> Total execution time: 0.0728
INFO - 2021-07-01 07:38:53 --> Config Class Initialized
INFO - 2021-07-01 07:38:53 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:38:53 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:38:53 --> Utf8 Class Initialized
INFO - 2021-07-01 07:38:53 --> URI Class Initialized
INFO - 2021-07-01 07:38:53 --> Router Class Initialized
INFO - 2021-07-01 07:38:53 --> Output Class Initialized
INFO - 2021-07-01 07:38:53 --> Security Class Initialized
DEBUG - 2021-07-01 07:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:38:53 --> Input Class Initialized
INFO - 2021-07-01 07:38:53 --> Language Class Initialized
INFO - 2021-07-01 07:38:53 --> Loader Class Initialized
INFO - 2021-07-01 07:38:53 --> Helper loaded: html_helper
INFO - 2021-07-01 07:38:53 --> Helper loaded: url_helper
INFO - 2021-07-01 07:38:53 --> Helper loaded: form_helper
INFO - 2021-07-01 07:38:53 --> Database Driver Class Initialized
INFO - 2021-07-01 07:38:53 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:38:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:38:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:38:53 --> Encryption Class Initialized
INFO - 2021-07-01 07:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:38:53 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:38:53 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:38:53 --> Model "user_model" initialized
INFO - 2021-07-01 07:38:53 --> Model "role_model" initialized
INFO - 2021-07-01 07:38:53 --> Controller Class Initialized
INFO - 2021-07-01 07:38:53 --> Helper loaded: language_helper
INFO - 2021-07-01 07:38:53 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:38:53 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:38:53 --> Model "Product_model" initialized
INFO - 2021-07-01 07:38:53 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:38:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:38:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:38:53 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:38:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:38:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:38:53 --> Final output sent to browser
DEBUG - 2021-07-01 07:38:53 --> Total execution time: 0.0706
INFO - 2021-07-01 07:40:09 --> Config Class Initialized
INFO - 2021-07-01 07:40:09 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:40:09 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:40:09 --> Utf8 Class Initialized
INFO - 2021-07-01 07:40:09 --> URI Class Initialized
INFO - 2021-07-01 07:40:09 --> Router Class Initialized
INFO - 2021-07-01 07:40:09 --> Output Class Initialized
INFO - 2021-07-01 07:40:09 --> Security Class Initialized
DEBUG - 2021-07-01 07:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:40:09 --> Input Class Initialized
INFO - 2021-07-01 07:40:09 --> Language Class Initialized
INFO - 2021-07-01 07:40:09 --> Loader Class Initialized
INFO - 2021-07-01 07:40:09 --> Helper loaded: html_helper
INFO - 2021-07-01 07:40:09 --> Helper loaded: url_helper
INFO - 2021-07-01 07:40:09 --> Helper loaded: form_helper
INFO - 2021-07-01 07:40:09 --> Database Driver Class Initialized
INFO - 2021-07-01 07:40:09 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:40:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:40:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:40:09 --> Encryption Class Initialized
INFO - 2021-07-01 07:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:40:09 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:40:09 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:40:09 --> Model "user_model" initialized
INFO - 2021-07-01 07:40:09 --> Model "role_model" initialized
INFO - 2021-07-01 07:40:09 --> Controller Class Initialized
INFO - 2021-07-01 07:40:09 --> Helper loaded: language_helper
INFO - 2021-07-01 07:40:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:40:09 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:40:09 --> Model "Product_model" initialized
INFO - 2021-07-01 07:40:09 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:40:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:40:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:40:09 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:40:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:40:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:40:09 --> Final output sent to browser
DEBUG - 2021-07-01 07:40:09 --> Total execution time: 0.0832
INFO - 2021-07-01 07:49:45 --> Config Class Initialized
INFO - 2021-07-01 07:49:45 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:49:45 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:49:45 --> Utf8 Class Initialized
INFO - 2021-07-01 07:49:45 --> URI Class Initialized
INFO - 2021-07-01 07:49:45 --> Router Class Initialized
INFO - 2021-07-01 07:49:45 --> Output Class Initialized
INFO - 2021-07-01 07:49:45 --> Security Class Initialized
DEBUG - 2021-07-01 07:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:49:45 --> Input Class Initialized
INFO - 2021-07-01 07:49:45 --> Language Class Initialized
INFO - 2021-07-01 07:49:45 --> Loader Class Initialized
INFO - 2021-07-01 07:49:45 --> Helper loaded: html_helper
INFO - 2021-07-01 07:49:45 --> Helper loaded: url_helper
INFO - 2021-07-01 07:49:45 --> Helper loaded: form_helper
INFO - 2021-07-01 07:49:45 --> Database Driver Class Initialized
INFO - 2021-07-01 07:49:45 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:49:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:49:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:49:45 --> Encryption Class Initialized
INFO - 2021-07-01 07:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:49:45 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:49:45 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:49:45 --> Model "user_model" initialized
INFO - 2021-07-01 07:49:45 --> Model "role_model" initialized
INFO - 2021-07-01 07:49:45 --> Controller Class Initialized
INFO - 2021-07-01 07:49:45 --> Helper loaded: language_helper
INFO - 2021-07-01 07:49:45 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:49:45 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:49:45 --> Model "Product_model" initialized
INFO - 2021-07-01 07:49:45 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:49:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:49:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:49:45 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:49:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:49:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:49:45 --> Final output sent to browser
DEBUG - 2021-07-01 07:49:45 --> Total execution time: 0.1017
INFO - 2021-07-01 07:50:01 --> Config Class Initialized
INFO - 2021-07-01 07:50:01 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:50:01 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:50:01 --> Utf8 Class Initialized
INFO - 2021-07-01 07:50:01 --> URI Class Initialized
INFO - 2021-07-01 07:50:01 --> Router Class Initialized
INFO - 2021-07-01 07:50:01 --> Output Class Initialized
INFO - 2021-07-01 07:50:01 --> Security Class Initialized
DEBUG - 2021-07-01 07:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:50:01 --> Input Class Initialized
INFO - 2021-07-01 07:50:01 --> Language Class Initialized
INFO - 2021-07-01 07:50:01 --> Loader Class Initialized
INFO - 2021-07-01 07:50:01 --> Helper loaded: html_helper
INFO - 2021-07-01 07:50:01 --> Helper loaded: url_helper
INFO - 2021-07-01 07:50:01 --> Helper loaded: form_helper
INFO - 2021-07-01 07:50:01 --> Database Driver Class Initialized
INFO - 2021-07-01 07:50:01 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:50:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:50:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:50:01 --> Encryption Class Initialized
INFO - 2021-07-01 07:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:50:01 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:50:01 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:50:01 --> Model "user_model" initialized
INFO - 2021-07-01 07:50:01 --> Model "role_model" initialized
INFO - 2021-07-01 07:50:01 --> Controller Class Initialized
INFO - 2021-07-01 07:50:01 --> Helper loaded: language_helper
INFO - 2021-07-01 07:50:01 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:50:01 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:50:01 --> Model "Product_model" initialized
INFO - 2021-07-01 07:50:01 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:50:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:50:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:50:01 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:50:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:50:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:50:01 --> Final output sent to browser
DEBUG - 2021-07-01 07:50:01 --> Total execution time: 0.0770
INFO - 2021-07-01 07:50:04 --> Config Class Initialized
INFO - 2021-07-01 07:50:04 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:50:04 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:50:04 --> Utf8 Class Initialized
INFO - 2021-07-01 07:50:04 --> URI Class Initialized
INFO - 2021-07-01 07:50:04 --> Router Class Initialized
INFO - 2021-07-01 07:50:04 --> Output Class Initialized
INFO - 2021-07-01 07:50:04 --> Security Class Initialized
DEBUG - 2021-07-01 07:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:50:04 --> Input Class Initialized
INFO - 2021-07-01 07:50:04 --> Language Class Initialized
INFO - 2021-07-01 07:50:04 --> Loader Class Initialized
INFO - 2021-07-01 07:50:04 --> Helper loaded: html_helper
INFO - 2021-07-01 07:50:04 --> Helper loaded: url_helper
INFO - 2021-07-01 07:50:04 --> Helper loaded: form_helper
INFO - 2021-07-01 07:50:04 --> Database Driver Class Initialized
INFO - 2021-07-01 07:50:04 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:50:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:50:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:50:04 --> Encryption Class Initialized
INFO - 2021-07-01 07:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:50:04 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:50:04 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:50:04 --> Model "user_model" initialized
INFO - 2021-07-01 07:50:04 --> Model "role_model" initialized
INFO - 2021-07-01 07:50:04 --> Controller Class Initialized
INFO - 2021-07-01 07:50:04 --> Helper loaded: language_helper
INFO - 2021-07-01 07:50:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:50:04 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:50:04 --> Model "Product_model" initialized
INFO - 2021-07-01 07:50:04 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:50:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:50:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:50:04 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:50:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:50:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:50:04 --> Final output sent to browser
DEBUG - 2021-07-01 07:50:04 --> Total execution time: 0.0777
INFO - 2021-07-01 07:50:05 --> Config Class Initialized
INFO - 2021-07-01 07:50:05 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:50:05 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:50:05 --> Utf8 Class Initialized
INFO - 2021-07-01 07:50:05 --> URI Class Initialized
INFO - 2021-07-01 07:50:06 --> Router Class Initialized
INFO - 2021-07-01 07:50:06 --> Output Class Initialized
INFO - 2021-07-01 07:50:06 --> Security Class Initialized
DEBUG - 2021-07-01 07:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:50:06 --> Input Class Initialized
INFO - 2021-07-01 07:50:06 --> Language Class Initialized
INFO - 2021-07-01 07:50:06 --> Loader Class Initialized
INFO - 2021-07-01 07:50:06 --> Helper loaded: html_helper
INFO - 2021-07-01 07:50:06 --> Helper loaded: url_helper
INFO - 2021-07-01 07:50:06 --> Helper loaded: form_helper
INFO - 2021-07-01 07:50:06 --> Database Driver Class Initialized
INFO - 2021-07-01 07:50:06 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:50:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:50:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:50:06 --> Encryption Class Initialized
INFO - 2021-07-01 07:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:50:06 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:50:06 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:50:06 --> Model "user_model" initialized
INFO - 2021-07-01 07:50:06 --> Model "role_model" initialized
INFO - 2021-07-01 07:50:06 --> Controller Class Initialized
INFO - 2021-07-01 07:50:06 --> Helper loaded: language_helper
INFO - 2021-07-01 07:50:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:50:06 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:50:06 --> Model "Product_model" initialized
INFO - 2021-07-01 07:50:06 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:50:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:50:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:50:06 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:50:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:50:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:50:06 --> Final output sent to browser
DEBUG - 2021-07-01 07:50:06 --> Total execution time: 0.0787
INFO - 2021-07-01 07:50:07 --> Config Class Initialized
INFO - 2021-07-01 07:50:07 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:50:07 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:50:07 --> Utf8 Class Initialized
INFO - 2021-07-01 07:50:07 --> URI Class Initialized
INFO - 2021-07-01 07:50:07 --> Router Class Initialized
INFO - 2021-07-01 07:50:07 --> Output Class Initialized
INFO - 2021-07-01 07:50:07 --> Security Class Initialized
DEBUG - 2021-07-01 07:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:50:07 --> Input Class Initialized
INFO - 2021-07-01 07:50:07 --> Language Class Initialized
INFO - 2021-07-01 07:50:07 --> Loader Class Initialized
INFO - 2021-07-01 07:50:07 --> Helper loaded: html_helper
INFO - 2021-07-01 07:50:07 --> Helper loaded: url_helper
INFO - 2021-07-01 07:50:07 --> Helper loaded: form_helper
INFO - 2021-07-01 07:50:07 --> Database Driver Class Initialized
INFO - 2021-07-01 07:50:07 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:50:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:50:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:50:07 --> Encryption Class Initialized
INFO - 2021-07-01 07:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:50:07 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:50:07 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:50:07 --> Model "user_model" initialized
INFO - 2021-07-01 07:50:07 --> Model "role_model" initialized
INFO - 2021-07-01 07:50:07 --> Controller Class Initialized
INFO - 2021-07-01 07:50:07 --> Helper loaded: language_helper
INFO - 2021-07-01 07:50:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:50:07 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:50:07 --> Model "Product_model" initialized
INFO - 2021-07-01 07:50:07 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:50:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:50:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:50:07 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:50:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:50:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:50:07 --> Final output sent to browser
DEBUG - 2021-07-01 07:50:07 --> Total execution time: 0.0760
INFO - 2021-07-01 07:50:08 --> Config Class Initialized
INFO - 2021-07-01 07:50:08 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:50:08 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:50:08 --> Utf8 Class Initialized
INFO - 2021-07-01 07:50:08 --> URI Class Initialized
INFO - 2021-07-01 07:50:08 --> Router Class Initialized
INFO - 2021-07-01 07:50:08 --> Output Class Initialized
INFO - 2021-07-01 07:50:08 --> Security Class Initialized
DEBUG - 2021-07-01 07:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:50:08 --> Input Class Initialized
INFO - 2021-07-01 07:50:08 --> Language Class Initialized
INFO - 2021-07-01 07:50:08 --> Loader Class Initialized
INFO - 2021-07-01 07:50:08 --> Helper loaded: html_helper
INFO - 2021-07-01 07:50:08 --> Helper loaded: url_helper
INFO - 2021-07-01 07:50:08 --> Helper loaded: form_helper
INFO - 2021-07-01 07:50:08 --> Database Driver Class Initialized
INFO - 2021-07-01 07:50:08 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:50:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:50:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:50:08 --> Encryption Class Initialized
INFO - 2021-07-01 07:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:50:08 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:50:08 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:50:08 --> Model "user_model" initialized
INFO - 2021-07-01 07:50:08 --> Model "role_model" initialized
INFO - 2021-07-01 07:50:08 --> Controller Class Initialized
INFO - 2021-07-01 07:50:08 --> Helper loaded: language_helper
INFO - 2021-07-01 07:50:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:50:08 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:50:08 --> Model "Product_model" initialized
INFO - 2021-07-01 07:50:08 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:50:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:50:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:50:08 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:50:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:50:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:50:08 --> Final output sent to browser
DEBUG - 2021-07-01 07:50:08 --> Total execution time: 0.0845
INFO - 2021-07-01 07:50:09 --> Config Class Initialized
INFO - 2021-07-01 07:50:09 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:50:09 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:50:09 --> Utf8 Class Initialized
INFO - 2021-07-01 07:50:09 --> URI Class Initialized
INFO - 2021-07-01 07:50:09 --> Router Class Initialized
INFO - 2021-07-01 07:50:09 --> Output Class Initialized
INFO - 2021-07-01 07:50:09 --> Security Class Initialized
DEBUG - 2021-07-01 07:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:50:09 --> Input Class Initialized
INFO - 2021-07-01 07:50:09 --> Language Class Initialized
INFO - 2021-07-01 07:50:09 --> Loader Class Initialized
INFO - 2021-07-01 07:50:09 --> Helper loaded: html_helper
INFO - 2021-07-01 07:50:09 --> Helper loaded: url_helper
INFO - 2021-07-01 07:50:09 --> Helper loaded: form_helper
INFO - 2021-07-01 07:50:09 --> Database Driver Class Initialized
INFO - 2021-07-01 07:50:09 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:50:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:50:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:50:09 --> Encryption Class Initialized
INFO - 2021-07-01 07:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:50:09 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:50:09 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:50:09 --> Model "user_model" initialized
INFO - 2021-07-01 07:50:09 --> Model "role_model" initialized
INFO - 2021-07-01 07:50:09 --> Controller Class Initialized
INFO - 2021-07-01 07:50:09 --> Helper loaded: language_helper
INFO - 2021-07-01 07:50:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:50:09 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:50:09 --> Model "Product_model" initialized
INFO - 2021-07-01 07:50:09 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:50:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:50:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:50:09 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:50:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:50:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:50:09 --> Final output sent to browser
DEBUG - 2021-07-01 07:50:09 --> Total execution time: 0.0600
INFO - 2021-07-01 07:50:10 --> Config Class Initialized
INFO - 2021-07-01 07:50:10 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:50:10 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:50:10 --> Utf8 Class Initialized
INFO - 2021-07-01 07:50:10 --> URI Class Initialized
INFO - 2021-07-01 07:50:10 --> Router Class Initialized
INFO - 2021-07-01 07:50:10 --> Output Class Initialized
INFO - 2021-07-01 07:50:10 --> Security Class Initialized
DEBUG - 2021-07-01 07:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:50:10 --> Input Class Initialized
INFO - 2021-07-01 07:50:10 --> Language Class Initialized
INFO - 2021-07-01 07:50:10 --> Loader Class Initialized
INFO - 2021-07-01 07:50:10 --> Helper loaded: html_helper
INFO - 2021-07-01 07:50:10 --> Helper loaded: url_helper
INFO - 2021-07-01 07:50:10 --> Helper loaded: form_helper
INFO - 2021-07-01 07:50:10 --> Database Driver Class Initialized
INFO - 2021-07-01 07:50:10 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:50:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:50:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:50:10 --> Encryption Class Initialized
INFO - 2021-07-01 07:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:50:10 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:50:10 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:50:10 --> Model "user_model" initialized
INFO - 2021-07-01 07:50:10 --> Model "role_model" initialized
INFO - 2021-07-01 07:50:10 --> Controller Class Initialized
INFO - 2021-07-01 07:50:10 --> Helper loaded: language_helper
INFO - 2021-07-01 07:50:10 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:50:10 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:50:10 --> Model "Product_model" initialized
INFO - 2021-07-01 07:50:10 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:50:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:50:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:50:10 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:50:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:50:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:50:10 --> Final output sent to browser
DEBUG - 2021-07-01 07:50:10 --> Total execution time: 0.0695
INFO - 2021-07-01 07:54:25 --> Config Class Initialized
INFO - 2021-07-01 07:54:25 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:54:25 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:54:25 --> Utf8 Class Initialized
INFO - 2021-07-01 07:54:25 --> URI Class Initialized
INFO - 2021-07-01 07:54:25 --> Router Class Initialized
INFO - 2021-07-01 07:54:25 --> Output Class Initialized
INFO - 2021-07-01 07:54:25 --> Security Class Initialized
DEBUG - 2021-07-01 07:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:54:25 --> Input Class Initialized
INFO - 2021-07-01 07:54:25 --> Language Class Initialized
INFO - 2021-07-01 07:54:25 --> Loader Class Initialized
INFO - 2021-07-01 07:54:25 --> Helper loaded: html_helper
INFO - 2021-07-01 07:54:25 --> Helper loaded: url_helper
INFO - 2021-07-01 07:54:25 --> Helper loaded: form_helper
INFO - 2021-07-01 07:54:25 --> Database Driver Class Initialized
INFO - 2021-07-01 07:54:25 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:54:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:54:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:54:25 --> Encryption Class Initialized
INFO - 2021-07-01 07:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:54:25 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:54:25 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:54:25 --> Model "user_model" initialized
INFO - 2021-07-01 07:54:25 --> Model "role_model" initialized
INFO - 2021-07-01 07:54:25 --> Controller Class Initialized
INFO - 2021-07-01 07:54:25 --> Helper loaded: language_helper
INFO - 2021-07-01 07:54:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:54:25 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:54:25 --> Model "Product_model" initialized
INFO - 2021-07-01 07:54:25 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:54:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:54:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:54:25 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:54:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:54:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:54:25 --> Final output sent to browser
DEBUG - 2021-07-01 07:54:25 --> Total execution time: 0.0790
INFO - 2021-07-01 07:54:26 --> Config Class Initialized
INFO - 2021-07-01 07:54:26 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:54:26 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:54:26 --> Utf8 Class Initialized
INFO - 2021-07-01 07:54:26 --> URI Class Initialized
INFO - 2021-07-01 07:54:26 --> Router Class Initialized
INFO - 2021-07-01 07:54:26 --> Output Class Initialized
INFO - 2021-07-01 07:54:26 --> Security Class Initialized
DEBUG - 2021-07-01 07:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:54:26 --> Input Class Initialized
INFO - 2021-07-01 07:54:26 --> Language Class Initialized
INFO - 2021-07-01 07:54:26 --> Loader Class Initialized
INFO - 2021-07-01 07:54:26 --> Helper loaded: html_helper
INFO - 2021-07-01 07:54:26 --> Helper loaded: url_helper
INFO - 2021-07-01 07:54:26 --> Helper loaded: form_helper
INFO - 2021-07-01 07:54:26 --> Database Driver Class Initialized
INFO - 2021-07-01 07:54:26 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:54:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:54:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:54:26 --> Encryption Class Initialized
INFO - 2021-07-01 07:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:54:26 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:54:26 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:54:26 --> Model "user_model" initialized
INFO - 2021-07-01 07:54:26 --> Model "role_model" initialized
INFO - 2021-07-01 07:54:26 --> Controller Class Initialized
INFO - 2021-07-01 07:54:26 --> Helper loaded: language_helper
INFO - 2021-07-01 07:54:26 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:54:26 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:54:26 --> Model "Product_model" initialized
INFO - 2021-07-01 07:54:26 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:54:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:54:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:54:26 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:54:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:54:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:54:26 --> Final output sent to browser
DEBUG - 2021-07-01 07:54:26 --> Total execution time: 0.0791
INFO - 2021-07-01 07:54:27 --> Config Class Initialized
INFO - 2021-07-01 07:54:27 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:54:27 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:54:27 --> Utf8 Class Initialized
INFO - 2021-07-01 07:54:27 --> URI Class Initialized
INFO - 2021-07-01 07:54:27 --> Router Class Initialized
INFO - 2021-07-01 07:54:27 --> Output Class Initialized
INFO - 2021-07-01 07:54:27 --> Security Class Initialized
DEBUG - 2021-07-01 07:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:54:27 --> Input Class Initialized
INFO - 2021-07-01 07:54:27 --> Language Class Initialized
INFO - 2021-07-01 07:54:27 --> Loader Class Initialized
INFO - 2021-07-01 07:54:27 --> Helper loaded: html_helper
INFO - 2021-07-01 07:54:27 --> Helper loaded: url_helper
INFO - 2021-07-01 07:54:27 --> Helper loaded: form_helper
INFO - 2021-07-01 07:54:27 --> Database Driver Class Initialized
INFO - 2021-07-01 07:54:27 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:54:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:54:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:54:27 --> Encryption Class Initialized
INFO - 2021-07-01 07:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:54:27 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:54:27 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:54:27 --> Model "user_model" initialized
INFO - 2021-07-01 07:54:27 --> Model "role_model" initialized
INFO - 2021-07-01 07:54:27 --> Controller Class Initialized
INFO - 2021-07-01 07:54:27 --> Helper loaded: language_helper
INFO - 2021-07-01 07:54:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:54:27 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:54:27 --> Model "Product_model" initialized
INFO - 2021-07-01 07:54:27 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:54:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:54:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:54:27 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:54:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:54:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:54:27 --> Final output sent to browser
DEBUG - 2021-07-01 07:54:27 --> Total execution time: 0.0776
INFO - 2021-07-01 07:54:28 --> Config Class Initialized
INFO - 2021-07-01 07:54:28 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:54:28 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:54:28 --> Utf8 Class Initialized
INFO - 2021-07-01 07:54:28 --> URI Class Initialized
INFO - 2021-07-01 07:54:28 --> Router Class Initialized
INFO - 2021-07-01 07:54:28 --> Output Class Initialized
INFO - 2021-07-01 07:54:28 --> Security Class Initialized
DEBUG - 2021-07-01 07:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:54:28 --> Input Class Initialized
INFO - 2021-07-01 07:54:28 --> Language Class Initialized
INFO - 2021-07-01 07:54:28 --> Loader Class Initialized
INFO - 2021-07-01 07:54:28 --> Helper loaded: html_helper
INFO - 2021-07-01 07:54:28 --> Helper loaded: url_helper
INFO - 2021-07-01 07:54:28 --> Helper loaded: form_helper
INFO - 2021-07-01 07:54:28 --> Database Driver Class Initialized
INFO - 2021-07-01 07:54:28 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:54:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:54:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:54:28 --> Encryption Class Initialized
INFO - 2021-07-01 07:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:54:28 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:54:28 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:54:28 --> Model "user_model" initialized
INFO - 2021-07-01 07:54:28 --> Model "role_model" initialized
INFO - 2021-07-01 07:54:28 --> Controller Class Initialized
INFO - 2021-07-01 07:54:28 --> Helper loaded: language_helper
INFO - 2021-07-01 07:54:28 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:54:28 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:54:28 --> Model "Product_model" initialized
INFO - 2021-07-01 07:54:28 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:54:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:54:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:54:28 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:54:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:54:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:54:28 --> Final output sent to browser
DEBUG - 2021-07-01 07:54:28 --> Total execution time: 0.1411
INFO - 2021-07-01 07:54:29 --> Config Class Initialized
INFO - 2021-07-01 07:54:29 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:54:29 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:54:29 --> Utf8 Class Initialized
INFO - 2021-07-01 07:54:29 --> URI Class Initialized
INFO - 2021-07-01 07:54:29 --> Router Class Initialized
INFO - 2021-07-01 07:54:29 --> Output Class Initialized
INFO - 2021-07-01 07:54:29 --> Security Class Initialized
DEBUG - 2021-07-01 07:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:54:29 --> Input Class Initialized
INFO - 2021-07-01 07:54:29 --> Language Class Initialized
INFO - 2021-07-01 07:54:29 --> Loader Class Initialized
INFO - 2021-07-01 07:54:29 --> Helper loaded: html_helper
INFO - 2021-07-01 07:54:29 --> Helper loaded: url_helper
INFO - 2021-07-01 07:54:29 --> Helper loaded: form_helper
INFO - 2021-07-01 07:54:29 --> Database Driver Class Initialized
INFO - 2021-07-01 07:54:29 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:54:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:54:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:54:29 --> Encryption Class Initialized
INFO - 2021-07-01 07:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:54:29 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:54:29 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:54:29 --> Model "user_model" initialized
INFO - 2021-07-01 07:54:29 --> Model "role_model" initialized
INFO - 2021-07-01 07:54:29 --> Controller Class Initialized
INFO - 2021-07-01 07:54:29 --> Helper loaded: language_helper
INFO - 2021-07-01 07:54:29 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:54:29 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:54:29 --> Model "Product_model" initialized
INFO - 2021-07-01 07:54:29 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:54:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:54:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:54:29 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:54:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:54:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:54:29 --> Final output sent to browser
DEBUG - 2021-07-01 07:54:29 --> Total execution time: 0.2832
INFO - 2021-07-01 07:55:14 --> Config Class Initialized
INFO - 2021-07-01 07:55:14 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:55:14 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:55:14 --> Utf8 Class Initialized
INFO - 2021-07-01 07:55:14 --> URI Class Initialized
INFO - 2021-07-01 07:55:14 --> Router Class Initialized
INFO - 2021-07-01 07:55:14 --> Output Class Initialized
INFO - 2021-07-01 07:55:14 --> Security Class Initialized
DEBUG - 2021-07-01 07:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:55:14 --> Input Class Initialized
INFO - 2021-07-01 07:55:14 --> Language Class Initialized
INFO - 2021-07-01 07:55:14 --> Loader Class Initialized
INFO - 2021-07-01 07:55:14 --> Helper loaded: html_helper
INFO - 2021-07-01 07:55:14 --> Helper loaded: url_helper
INFO - 2021-07-01 07:55:14 --> Helper loaded: form_helper
INFO - 2021-07-01 07:55:14 --> Database Driver Class Initialized
INFO - 2021-07-01 07:55:14 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:55:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:55:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:55:14 --> Encryption Class Initialized
INFO - 2021-07-01 07:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:55:14 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:55:14 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:55:14 --> Model "user_model" initialized
INFO - 2021-07-01 07:55:14 --> Model "role_model" initialized
INFO - 2021-07-01 07:55:14 --> Controller Class Initialized
INFO - 2021-07-01 07:55:14 --> Helper loaded: language_helper
INFO - 2021-07-01 07:55:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:55:14 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:55:14 --> Model "Product_model" initialized
INFO - 2021-07-01 07:55:14 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:55:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:55:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:55:14 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:55:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:55:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:55:14 --> Final output sent to browser
DEBUG - 2021-07-01 07:55:14 --> Total execution time: 0.0797
INFO - 2021-07-01 07:55:16 --> Config Class Initialized
INFO - 2021-07-01 07:55:16 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:55:16 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:55:16 --> Utf8 Class Initialized
INFO - 2021-07-01 07:55:16 --> URI Class Initialized
INFO - 2021-07-01 07:55:16 --> Router Class Initialized
INFO - 2021-07-01 07:55:16 --> Output Class Initialized
INFO - 2021-07-01 07:55:16 --> Security Class Initialized
DEBUG - 2021-07-01 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:55:16 --> Input Class Initialized
INFO - 2021-07-01 07:55:16 --> Language Class Initialized
INFO - 2021-07-01 07:55:16 --> Loader Class Initialized
INFO - 2021-07-01 07:55:16 --> Helper loaded: html_helper
INFO - 2021-07-01 07:55:16 --> Helper loaded: url_helper
INFO - 2021-07-01 07:55:16 --> Helper loaded: form_helper
INFO - 2021-07-01 07:55:16 --> Database Driver Class Initialized
INFO - 2021-07-01 07:55:16 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:55:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:55:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:55:16 --> Encryption Class Initialized
INFO - 2021-07-01 07:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:55:16 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:55:16 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:55:16 --> Model "user_model" initialized
INFO - 2021-07-01 07:55:16 --> Model "role_model" initialized
INFO - 2021-07-01 07:55:16 --> Controller Class Initialized
INFO - 2021-07-01 07:55:16 --> Helper loaded: language_helper
INFO - 2021-07-01 07:55:16 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:55:16 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:55:16 --> Model "Product_model" initialized
INFO - 2021-07-01 07:55:16 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:55:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:55:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:55:16 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:55:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:55:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:55:16 --> Final output sent to browser
DEBUG - 2021-07-01 07:55:16 --> Total execution time: 0.0921
INFO - 2021-07-01 07:55:17 --> Config Class Initialized
INFO - 2021-07-01 07:55:17 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:55:17 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:55:17 --> Utf8 Class Initialized
INFO - 2021-07-01 07:55:17 --> URI Class Initialized
INFO - 2021-07-01 07:55:17 --> Router Class Initialized
INFO - 2021-07-01 07:55:17 --> Output Class Initialized
INFO - 2021-07-01 07:55:17 --> Security Class Initialized
DEBUG - 2021-07-01 07:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:55:17 --> Input Class Initialized
INFO - 2021-07-01 07:55:17 --> Language Class Initialized
INFO - 2021-07-01 07:55:17 --> Loader Class Initialized
INFO - 2021-07-01 07:55:17 --> Helper loaded: html_helper
INFO - 2021-07-01 07:55:17 --> Helper loaded: url_helper
INFO - 2021-07-01 07:55:17 --> Helper loaded: form_helper
INFO - 2021-07-01 07:55:17 --> Database Driver Class Initialized
INFO - 2021-07-01 07:55:17 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:55:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:55:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:55:17 --> Encryption Class Initialized
INFO - 2021-07-01 07:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:55:17 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:55:17 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:55:17 --> Model "user_model" initialized
INFO - 2021-07-01 07:55:17 --> Model "role_model" initialized
INFO - 2021-07-01 07:55:17 --> Controller Class Initialized
INFO - 2021-07-01 07:55:17 --> Helper loaded: language_helper
INFO - 2021-07-01 07:55:17 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:55:17 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:55:17 --> Model "Product_model" initialized
INFO - 2021-07-01 07:55:17 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:55:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:55:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:55:17 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:55:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:55:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:55:17 --> Final output sent to browser
DEBUG - 2021-07-01 07:55:17 --> Total execution time: 0.0737
INFO - 2021-07-01 07:55:18 --> Config Class Initialized
INFO - 2021-07-01 07:55:18 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:55:18 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:55:18 --> Utf8 Class Initialized
INFO - 2021-07-01 07:55:18 --> URI Class Initialized
INFO - 2021-07-01 07:55:18 --> Router Class Initialized
INFO - 2021-07-01 07:55:18 --> Output Class Initialized
INFO - 2021-07-01 07:55:18 --> Security Class Initialized
DEBUG - 2021-07-01 07:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:55:18 --> Input Class Initialized
INFO - 2021-07-01 07:55:18 --> Language Class Initialized
INFO - 2021-07-01 07:55:18 --> Loader Class Initialized
INFO - 2021-07-01 07:55:18 --> Helper loaded: html_helper
INFO - 2021-07-01 07:55:18 --> Helper loaded: url_helper
INFO - 2021-07-01 07:55:18 --> Helper loaded: form_helper
INFO - 2021-07-01 07:55:18 --> Database Driver Class Initialized
INFO - 2021-07-01 07:55:18 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:55:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:55:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:55:18 --> Encryption Class Initialized
INFO - 2021-07-01 07:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:55:18 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:55:18 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:55:18 --> Model "user_model" initialized
INFO - 2021-07-01 07:55:18 --> Model "role_model" initialized
INFO - 2021-07-01 07:55:18 --> Controller Class Initialized
INFO - 2021-07-01 07:55:18 --> Helper loaded: language_helper
INFO - 2021-07-01 07:55:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:55:18 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:55:18 --> Model "Product_model" initialized
INFO - 2021-07-01 07:55:18 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:55:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:55:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:55:18 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:55:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:55:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:55:18 --> Final output sent to browser
DEBUG - 2021-07-01 07:55:18 --> Total execution time: 0.0739
INFO - 2021-07-01 07:55:19 --> Config Class Initialized
INFO - 2021-07-01 07:55:19 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:55:19 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:55:19 --> Utf8 Class Initialized
INFO - 2021-07-01 07:55:19 --> URI Class Initialized
INFO - 2021-07-01 07:55:19 --> Router Class Initialized
INFO - 2021-07-01 07:55:19 --> Output Class Initialized
INFO - 2021-07-01 07:55:19 --> Security Class Initialized
DEBUG - 2021-07-01 07:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:55:19 --> Input Class Initialized
INFO - 2021-07-01 07:55:19 --> Language Class Initialized
INFO - 2021-07-01 07:55:19 --> Loader Class Initialized
INFO - 2021-07-01 07:55:19 --> Helper loaded: html_helper
INFO - 2021-07-01 07:55:19 --> Helper loaded: url_helper
INFO - 2021-07-01 07:55:19 --> Helper loaded: form_helper
INFO - 2021-07-01 07:55:19 --> Database Driver Class Initialized
INFO - 2021-07-01 07:55:19 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:55:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:55:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:55:19 --> Encryption Class Initialized
INFO - 2021-07-01 07:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:55:19 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:55:19 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:55:19 --> Model "user_model" initialized
INFO - 2021-07-01 07:55:19 --> Model "role_model" initialized
INFO - 2021-07-01 07:55:19 --> Controller Class Initialized
INFO - 2021-07-01 07:55:19 --> Helper loaded: language_helper
INFO - 2021-07-01 07:55:19 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:55:19 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:55:19 --> Model "Product_model" initialized
INFO - 2021-07-01 07:55:19 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:55:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:55:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:55:19 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:55:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:55:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:55:19 --> Final output sent to browser
DEBUG - 2021-07-01 07:55:19 --> Total execution time: 0.0733
INFO - 2021-07-01 07:55:21 --> Config Class Initialized
INFO - 2021-07-01 07:55:21 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:55:21 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:55:21 --> Utf8 Class Initialized
INFO - 2021-07-01 07:55:21 --> URI Class Initialized
INFO - 2021-07-01 07:55:21 --> Router Class Initialized
INFO - 2021-07-01 07:55:21 --> Output Class Initialized
INFO - 2021-07-01 07:55:21 --> Security Class Initialized
DEBUG - 2021-07-01 07:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:55:21 --> Input Class Initialized
INFO - 2021-07-01 07:55:21 --> Language Class Initialized
INFO - 2021-07-01 07:55:21 --> Loader Class Initialized
INFO - 2021-07-01 07:55:21 --> Helper loaded: html_helper
INFO - 2021-07-01 07:55:21 --> Helper loaded: url_helper
INFO - 2021-07-01 07:55:21 --> Helper loaded: form_helper
INFO - 2021-07-01 07:55:21 --> Database Driver Class Initialized
INFO - 2021-07-01 07:55:21 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:55:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:55:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:55:21 --> Encryption Class Initialized
INFO - 2021-07-01 07:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:55:21 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:55:21 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:55:21 --> Model "user_model" initialized
INFO - 2021-07-01 07:55:21 --> Model "role_model" initialized
INFO - 2021-07-01 07:55:21 --> Controller Class Initialized
INFO - 2021-07-01 07:55:21 --> Helper loaded: language_helper
INFO - 2021-07-01 07:55:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:55:21 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:55:21 --> Model "Product_model" initialized
INFO - 2021-07-01 07:55:21 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:55:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:55:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:55:21 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:55:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:55:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:55:21 --> Final output sent to browser
DEBUG - 2021-07-01 07:55:21 --> Total execution time: 0.0775
INFO - 2021-07-01 07:55:22 --> Config Class Initialized
INFO - 2021-07-01 07:55:22 --> Hooks Class Initialized
DEBUG - 2021-07-01 07:55:22 --> UTF-8 Support Enabled
INFO - 2021-07-01 07:55:22 --> Utf8 Class Initialized
INFO - 2021-07-01 07:55:22 --> URI Class Initialized
INFO - 2021-07-01 07:55:22 --> Router Class Initialized
INFO - 2021-07-01 07:55:22 --> Output Class Initialized
INFO - 2021-07-01 07:55:22 --> Security Class Initialized
DEBUG - 2021-07-01 07:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 07:55:22 --> Input Class Initialized
INFO - 2021-07-01 07:55:22 --> Language Class Initialized
INFO - 2021-07-01 07:55:22 --> Loader Class Initialized
INFO - 2021-07-01 07:55:22 --> Helper loaded: html_helper
INFO - 2021-07-01 07:55:22 --> Helper loaded: url_helper
INFO - 2021-07-01 07:55:22 --> Helper loaded: form_helper
INFO - 2021-07-01 07:55:22 --> Database Driver Class Initialized
INFO - 2021-07-01 07:55:22 --> Form Validation Class Initialized
DEBUG - 2021-07-01 07:55:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 07:55:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 07:55:22 --> Encryption Class Initialized
INFO - 2021-07-01 07:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 07:55:22 --> Model "vendor_model" initialized
INFO - 2021-07-01 07:55:22 --> Model "coupon_model" initialized
INFO - 2021-07-01 07:55:22 --> Model "user_model" initialized
INFO - 2021-07-01 07:55:22 --> Model "role_model" initialized
INFO - 2021-07-01 07:55:22 --> Controller Class Initialized
INFO - 2021-07-01 07:55:22 --> Helper loaded: language_helper
INFO - 2021-07-01 07:55:22 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 07:55:22 --> Model "Customer_model" initialized
INFO - 2021-07-01 07:55:22 --> Model "Product_model" initialized
INFO - 2021-07-01 07:55:22 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 07:55:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 07:55:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 07:55:22 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 07:55:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 07:55:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 07:55:22 --> Final output sent to browser
DEBUG - 2021-07-01 07:55:22 --> Total execution time: 0.0736
INFO - 2021-07-01 08:00:45 --> Config Class Initialized
INFO - 2021-07-01 08:00:45 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:00:45 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:00:45 --> Utf8 Class Initialized
INFO - 2021-07-01 08:00:45 --> URI Class Initialized
INFO - 2021-07-01 08:00:45 --> Router Class Initialized
INFO - 2021-07-01 08:00:45 --> Output Class Initialized
INFO - 2021-07-01 08:00:45 --> Security Class Initialized
DEBUG - 2021-07-01 08:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:00:45 --> Input Class Initialized
INFO - 2021-07-01 08:00:45 --> Language Class Initialized
INFO - 2021-07-01 08:00:45 --> Loader Class Initialized
INFO - 2021-07-01 08:00:45 --> Helper loaded: html_helper
INFO - 2021-07-01 08:00:45 --> Helper loaded: url_helper
INFO - 2021-07-01 08:00:45 --> Helper loaded: form_helper
INFO - 2021-07-01 08:00:45 --> Database Driver Class Initialized
INFO - 2021-07-01 08:00:45 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:00:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:00:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:00:45 --> Encryption Class Initialized
INFO - 2021-07-01 08:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:00:45 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:00:45 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:00:45 --> Model "user_model" initialized
INFO - 2021-07-01 08:00:45 --> Model "role_model" initialized
INFO - 2021-07-01 08:00:45 --> Controller Class Initialized
INFO - 2021-07-01 08:00:45 --> Helper loaded: language_helper
INFO - 2021-07-01 08:00:45 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:00:45 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:00:45 --> Final output sent to browser
DEBUG - 2021-07-01 08:00:45 --> Total execution time: 0.0695
INFO - 2021-07-01 08:00:47 --> Config Class Initialized
INFO - 2021-07-01 08:00:47 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:00:47 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:00:47 --> Utf8 Class Initialized
INFO - 2021-07-01 08:00:47 --> URI Class Initialized
INFO - 2021-07-01 08:00:47 --> Router Class Initialized
INFO - 2021-07-01 08:00:47 --> Output Class Initialized
INFO - 2021-07-01 08:00:47 --> Security Class Initialized
DEBUG - 2021-07-01 08:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:00:47 --> Input Class Initialized
INFO - 2021-07-01 08:00:47 --> Language Class Initialized
INFO - 2021-07-01 08:00:47 --> Loader Class Initialized
INFO - 2021-07-01 08:00:47 --> Helper loaded: html_helper
INFO - 2021-07-01 08:00:47 --> Helper loaded: url_helper
INFO - 2021-07-01 08:00:47 --> Helper loaded: form_helper
INFO - 2021-07-01 08:00:47 --> Database Driver Class Initialized
INFO - 2021-07-01 08:00:47 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:00:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:00:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:00:47 --> Encryption Class Initialized
INFO - 2021-07-01 08:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:00:47 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:00:47 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:00:47 --> Model "user_model" initialized
INFO - 2021-07-01 08:00:47 --> Model "role_model" initialized
INFO - 2021-07-01 08:00:47 --> Controller Class Initialized
INFO - 2021-07-01 08:00:47 --> Helper loaded: language_helper
INFO - 2021-07-01 08:00:47 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:00:47 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:00:47 --> Final output sent to browser
DEBUG - 2021-07-01 08:00:47 --> Total execution time: 0.0607
INFO - 2021-07-01 08:00:49 --> Config Class Initialized
INFO - 2021-07-01 08:00:49 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:00:49 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:00:49 --> Utf8 Class Initialized
INFO - 2021-07-01 08:00:49 --> URI Class Initialized
INFO - 2021-07-01 08:00:49 --> Router Class Initialized
INFO - 2021-07-01 08:00:49 --> Output Class Initialized
INFO - 2021-07-01 08:00:49 --> Security Class Initialized
DEBUG - 2021-07-01 08:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:00:49 --> Input Class Initialized
INFO - 2021-07-01 08:00:49 --> Language Class Initialized
INFO - 2021-07-01 08:00:49 --> Loader Class Initialized
INFO - 2021-07-01 08:00:49 --> Helper loaded: html_helper
INFO - 2021-07-01 08:00:49 --> Helper loaded: url_helper
INFO - 2021-07-01 08:00:49 --> Helper loaded: form_helper
INFO - 2021-07-01 08:00:49 --> Database Driver Class Initialized
INFO - 2021-07-01 08:00:49 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:00:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:00:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:00:49 --> Encryption Class Initialized
INFO - 2021-07-01 08:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:00:49 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:00:49 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:00:49 --> Model "user_model" initialized
INFO - 2021-07-01 08:00:49 --> Model "role_model" initialized
INFO - 2021-07-01 08:00:49 --> Controller Class Initialized
INFO - 2021-07-01 08:00:49 --> Helper loaded: language_helper
INFO - 2021-07-01 08:00:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:00:49 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:00:49 --> Model "Product_model" initialized
INFO - 2021-07-01 08:00:49 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:00:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:00:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:00:49 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:00:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:00:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:00:49 --> Final output sent to browser
DEBUG - 2021-07-01 08:00:49 --> Total execution time: 0.0770
INFO - 2021-07-01 08:02:29 --> Config Class Initialized
INFO - 2021-07-01 08:02:29 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:02:29 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:02:29 --> Utf8 Class Initialized
INFO - 2021-07-01 08:02:29 --> URI Class Initialized
INFO - 2021-07-01 08:02:29 --> Router Class Initialized
INFO - 2021-07-01 08:02:29 --> Output Class Initialized
INFO - 2021-07-01 08:02:29 --> Security Class Initialized
DEBUG - 2021-07-01 08:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:02:29 --> Input Class Initialized
INFO - 2021-07-01 08:02:29 --> Language Class Initialized
INFO - 2021-07-01 08:02:29 --> Loader Class Initialized
INFO - 2021-07-01 08:02:29 --> Helper loaded: html_helper
INFO - 2021-07-01 08:02:29 --> Helper loaded: url_helper
INFO - 2021-07-01 08:02:29 --> Helper loaded: form_helper
INFO - 2021-07-01 08:02:29 --> Database Driver Class Initialized
INFO - 2021-07-01 08:02:29 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:02:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:02:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:02:29 --> Encryption Class Initialized
INFO - 2021-07-01 08:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:02:29 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:02:29 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:02:29 --> Model "user_model" initialized
INFO - 2021-07-01 08:02:29 --> Model "role_model" initialized
INFO - 2021-07-01 08:02:29 --> Controller Class Initialized
INFO - 2021-07-01 08:02:29 --> Helper loaded: language_helper
INFO - 2021-07-01 08:02:29 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:02:29 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:02:29 --> Model "Product_model" initialized
INFO - 2021-07-01 08:02:29 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:02:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:02:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:02:30 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:02:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:02:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:02:30 --> Final output sent to browser
DEBUG - 2021-07-01 08:02:30 --> Total execution time: 0.0821
INFO - 2021-07-01 08:03:42 --> Config Class Initialized
INFO - 2021-07-01 08:03:42 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:03:42 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:03:42 --> Utf8 Class Initialized
INFO - 2021-07-01 08:03:42 --> URI Class Initialized
INFO - 2021-07-01 08:03:42 --> Router Class Initialized
INFO - 2021-07-01 08:03:42 --> Output Class Initialized
INFO - 2021-07-01 08:03:42 --> Security Class Initialized
DEBUG - 2021-07-01 08:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:03:42 --> Input Class Initialized
INFO - 2021-07-01 08:03:42 --> Language Class Initialized
INFO - 2021-07-01 08:03:42 --> Loader Class Initialized
INFO - 2021-07-01 08:03:42 --> Helper loaded: html_helper
INFO - 2021-07-01 08:03:42 --> Helper loaded: url_helper
INFO - 2021-07-01 08:03:42 --> Helper loaded: form_helper
INFO - 2021-07-01 08:03:42 --> Database Driver Class Initialized
INFO - 2021-07-01 08:03:42 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:03:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:03:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:03:42 --> Encryption Class Initialized
INFO - 2021-07-01 08:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:03:42 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:03:42 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:03:42 --> Model "user_model" initialized
INFO - 2021-07-01 08:03:42 --> Model "role_model" initialized
INFO - 2021-07-01 08:03:42 --> Controller Class Initialized
INFO - 2021-07-01 08:03:42 --> Helper loaded: language_helper
INFO - 2021-07-01 08:03:42 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:03:42 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:03:42 --> Model "Product_model" initialized
INFO - 2021-07-01 08:03:42 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:03:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:03:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:03:42 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:03:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:03:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:03:42 --> Final output sent to browser
DEBUG - 2021-07-01 08:03:42 --> Total execution time: 0.0839
INFO - 2021-07-01 08:11:00 --> Config Class Initialized
INFO - 2021-07-01 08:11:00 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:11:00 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:11:00 --> Utf8 Class Initialized
INFO - 2021-07-01 08:11:00 --> URI Class Initialized
INFO - 2021-07-01 08:11:00 --> Router Class Initialized
INFO - 2021-07-01 08:11:00 --> Output Class Initialized
INFO - 2021-07-01 08:11:00 --> Security Class Initialized
DEBUG - 2021-07-01 08:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:11:00 --> Input Class Initialized
INFO - 2021-07-01 08:11:00 --> Language Class Initialized
INFO - 2021-07-01 08:11:00 --> Loader Class Initialized
INFO - 2021-07-01 08:11:00 --> Helper loaded: html_helper
INFO - 2021-07-01 08:11:00 --> Helper loaded: url_helper
INFO - 2021-07-01 08:11:00 --> Helper loaded: form_helper
INFO - 2021-07-01 08:11:00 --> Database Driver Class Initialized
INFO - 2021-07-01 08:11:00 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:11:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:11:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:11:00 --> Encryption Class Initialized
INFO - 2021-07-01 08:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:11:00 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:11:00 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:11:00 --> Model "user_model" initialized
INFO - 2021-07-01 08:11:00 --> Model "role_model" initialized
INFO - 2021-07-01 08:11:00 --> Controller Class Initialized
INFO - 2021-07-01 08:11:00 --> Helper loaded: language_helper
INFO - 2021-07-01 08:11:00 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:11:00 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:11:00 --> Model "Product_model" initialized
INFO - 2021-07-01 08:11:00 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:11:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:11:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:11:00 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:11:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:11:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:11:00 --> Final output sent to browser
DEBUG - 2021-07-01 08:11:00 --> Total execution time: 0.0852
INFO - 2021-07-01 08:11:09 --> Config Class Initialized
INFO - 2021-07-01 08:11:09 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:11:09 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:11:09 --> Utf8 Class Initialized
INFO - 2021-07-01 08:11:09 --> URI Class Initialized
INFO - 2021-07-01 08:11:09 --> Router Class Initialized
INFO - 2021-07-01 08:11:09 --> Output Class Initialized
INFO - 2021-07-01 08:11:09 --> Security Class Initialized
DEBUG - 2021-07-01 08:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:11:09 --> Input Class Initialized
INFO - 2021-07-01 08:11:09 --> Language Class Initialized
INFO - 2021-07-01 08:11:09 --> Loader Class Initialized
INFO - 2021-07-01 08:11:09 --> Helper loaded: html_helper
INFO - 2021-07-01 08:11:09 --> Helper loaded: url_helper
INFO - 2021-07-01 08:11:09 --> Helper loaded: form_helper
INFO - 2021-07-01 08:11:09 --> Database Driver Class Initialized
INFO - 2021-07-01 08:11:09 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:11:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:11:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:11:09 --> Encryption Class Initialized
INFO - 2021-07-01 08:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:11:09 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:11:09 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:11:09 --> Model "user_model" initialized
INFO - 2021-07-01 08:11:09 --> Model "role_model" initialized
INFO - 2021-07-01 08:11:09 --> Controller Class Initialized
INFO - 2021-07-01 08:11:09 --> Helper loaded: language_helper
INFO - 2021-07-01 08:11:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:11:09 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:11:09 --> Model "Product_model" initialized
INFO - 2021-07-01 08:11:09 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:11:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:11:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:11:09 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:11:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:11:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:11:09 --> Final output sent to browser
DEBUG - 2021-07-01 08:11:09 --> Total execution time: 0.0781
INFO - 2021-07-01 08:11:10 --> Config Class Initialized
INFO - 2021-07-01 08:11:10 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:11:10 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:11:10 --> Utf8 Class Initialized
INFO - 2021-07-01 08:11:10 --> URI Class Initialized
INFO - 2021-07-01 08:11:10 --> Router Class Initialized
INFO - 2021-07-01 08:11:10 --> Output Class Initialized
INFO - 2021-07-01 08:11:10 --> Security Class Initialized
DEBUG - 2021-07-01 08:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:11:10 --> Input Class Initialized
INFO - 2021-07-01 08:11:10 --> Language Class Initialized
INFO - 2021-07-01 08:11:10 --> Loader Class Initialized
INFO - 2021-07-01 08:11:10 --> Helper loaded: html_helper
INFO - 2021-07-01 08:11:10 --> Helper loaded: url_helper
INFO - 2021-07-01 08:11:10 --> Helper loaded: form_helper
INFO - 2021-07-01 08:11:10 --> Database Driver Class Initialized
INFO - 2021-07-01 08:11:10 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:11:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:11:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:11:10 --> Encryption Class Initialized
INFO - 2021-07-01 08:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:11:10 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:11:10 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:11:10 --> Model "user_model" initialized
INFO - 2021-07-01 08:11:10 --> Model "role_model" initialized
INFO - 2021-07-01 08:11:10 --> Controller Class Initialized
INFO - 2021-07-01 08:11:10 --> Helper loaded: language_helper
INFO - 2021-07-01 08:11:10 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:11:10 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:11:10 --> Model "Product_model" initialized
INFO - 2021-07-01 08:11:10 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:11:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:11:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:11:10 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:11:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:11:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:11:10 --> Final output sent to browser
DEBUG - 2021-07-01 08:11:10 --> Total execution time: 0.0788
INFO - 2021-07-01 08:11:12 --> Config Class Initialized
INFO - 2021-07-01 08:11:12 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:11:12 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:11:12 --> Utf8 Class Initialized
INFO - 2021-07-01 08:11:12 --> URI Class Initialized
INFO - 2021-07-01 08:11:12 --> Router Class Initialized
INFO - 2021-07-01 08:11:12 --> Output Class Initialized
INFO - 2021-07-01 08:11:12 --> Security Class Initialized
DEBUG - 2021-07-01 08:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:11:12 --> Input Class Initialized
INFO - 2021-07-01 08:11:12 --> Language Class Initialized
INFO - 2021-07-01 08:11:12 --> Loader Class Initialized
INFO - 2021-07-01 08:11:12 --> Helper loaded: html_helper
INFO - 2021-07-01 08:11:12 --> Helper loaded: url_helper
INFO - 2021-07-01 08:11:12 --> Helper loaded: form_helper
INFO - 2021-07-01 08:11:12 --> Database Driver Class Initialized
INFO - 2021-07-01 08:11:12 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:11:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:11:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:11:12 --> Encryption Class Initialized
INFO - 2021-07-01 08:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:11:12 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:11:12 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:11:12 --> Model "user_model" initialized
INFO - 2021-07-01 08:11:12 --> Model "role_model" initialized
INFO - 2021-07-01 08:11:12 --> Controller Class Initialized
INFO - 2021-07-01 08:11:12 --> Helper loaded: language_helper
INFO - 2021-07-01 08:11:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:11:12 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:11:12 --> Model "Product_model" initialized
INFO - 2021-07-01 08:11:12 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:11:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:11:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:11:12 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:11:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:11:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:11:12 --> Final output sent to browser
DEBUG - 2021-07-01 08:11:12 --> Total execution time: 0.0773
INFO - 2021-07-01 08:11:13 --> Config Class Initialized
INFO - 2021-07-01 08:11:13 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:11:13 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:11:13 --> Utf8 Class Initialized
INFO - 2021-07-01 08:11:13 --> URI Class Initialized
INFO - 2021-07-01 08:11:13 --> Router Class Initialized
INFO - 2021-07-01 08:11:13 --> Output Class Initialized
INFO - 2021-07-01 08:11:13 --> Security Class Initialized
DEBUG - 2021-07-01 08:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:11:13 --> Input Class Initialized
INFO - 2021-07-01 08:11:13 --> Language Class Initialized
INFO - 2021-07-01 08:11:13 --> Loader Class Initialized
INFO - 2021-07-01 08:11:13 --> Helper loaded: html_helper
INFO - 2021-07-01 08:11:13 --> Helper loaded: url_helper
INFO - 2021-07-01 08:11:13 --> Helper loaded: form_helper
INFO - 2021-07-01 08:11:13 --> Database Driver Class Initialized
INFO - 2021-07-01 08:11:13 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:11:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:11:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:11:13 --> Encryption Class Initialized
INFO - 2021-07-01 08:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:11:13 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:11:13 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:11:13 --> Model "user_model" initialized
INFO - 2021-07-01 08:11:13 --> Model "role_model" initialized
INFO - 2021-07-01 08:11:13 --> Controller Class Initialized
INFO - 2021-07-01 08:11:13 --> Helper loaded: language_helper
INFO - 2021-07-01 08:11:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:11:13 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:11:13 --> Model "Product_model" initialized
INFO - 2021-07-01 08:11:13 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:11:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:11:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:11:13 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:11:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:11:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:11:13 --> Final output sent to browser
DEBUG - 2021-07-01 08:11:13 --> Total execution time: 0.1044
INFO - 2021-07-01 08:11:14 --> Config Class Initialized
INFO - 2021-07-01 08:11:14 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:11:14 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:11:14 --> Utf8 Class Initialized
INFO - 2021-07-01 08:11:14 --> URI Class Initialized
INFO - 2021-07-01 08:11:14 --> Router Class Initialized
INFO - 2021-07-01 08:11:14 --> Output Class Initialized
INFO - 2021-07-01 08:11:14 --> Security Class Initialized
DEBUG - 2021-07-01 08:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:11:14 --> Input Class Initialized
INFO - 2021-07-01 08:11:14 --> Language Class Initialized
INFO - 2021-07-01 08:11:14 --> Loader Class Initialized
INFO - 2021-07-01 08:11:14 --> Helper loaded: html_helper
INFO - 2021-07-01 08:11:14 --> Helper loaded: url_helper
INFO - 2021-07-01 08:11:14 --> Helper loaded: form_helper
INFO - 2021-07-01 08:11:14 --> Database Driver Class Initialized
INFO - 2021-07-01 08:11:14 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:11:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:11:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:11:14 --> Encryption Class Initialized
INFO - 2021-07-01 08:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:11:14 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:11:14 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:11:14 --> Model "user_model" initialized
INFO - 2021-07-01 08:11:14 --> Model "role_model" initialized
INFO - 2021-07-01 08:11:14 --> Controller Class Initialized
INFO - 2021-07-01 08:11:14 --> Helper loaded: language_helper
INFO - 2021-07-01 08:11:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:11:14 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:11:14 --> Model "Product_model" initialized
INFO - 2021-07-01 08:11:14 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:11:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:11:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:11:14 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:11:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:11:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:11:14 --> Final output sent to browser
DEBUG - 2021-07-01 08:11:14 --> Total execution time: 0.0857
INFO - 2021-07-01 08:11:14 --> Config Class Initialized
INFO - 2021-07-01 08:11:14 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:11:14 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:11:14 --> Utf8 Class Initialized
INFO - 2021-07-01 08:11:14 --> URI Class Initialized
INFO - 2021-07-01 08:11:14 --> Router Class Initialized
INFO - 2021-07-01 08:11:14 --> Output Class Initialized
INFO - 2021-07-01 08:11:14 --> Security Class Initialized
DEBUG - 2021-07-01 08:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:11:14 --> Input Class Initialized
INFO - 2021-07-01 08:11:14 --> Language Class Initialized
INFO - 2021-07-01 08:11:14 --> Loader Class Initialized
INFO - 2021-07-01 08:11:14 --> Helper loaded: html_helper
INFO - 2021-07-01 08:11:14 --> Helper loaded: url_helper
INFO - 2021-07-01 08:11:14 --> Helper loaded: form_helper
INFO - 2021-07-01 08:11:15 --> Database Driver Class Initialized
INFO - 2021-07-01 08:11:15 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:11:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:11:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:11:15 --> Encryption Class Initialized
INFO - 2021-07-01 08:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:11:15 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:11:15 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:11:15 --> Model "user_model" initialized
INFO - 2021-07-01 08:11:15 --> Model "role_model" initialized
INFO - 2021-07-01 08:11:15 --> Controller Class Initialized
INFO - 2021-07-01 08:11:15 --> Helper loaded: language_helper
INFO - 2021-07-01 08:11:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:11:15 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:11:15 --> Model "Product_model" initialized
INFO - 2021-07-01 08:11:15 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:11:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:11:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:11:15 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:11:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:11:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:11:15 --> Final output sent to browser
DEBUG - 2021-07-01 08:11:15 --> Total execution time: 0.0785
INFO - 2021-07-01 08:11:30 --> Config Class Initialized
INFO - 2021-07-01 08:11:30 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:11:30 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:11:30 --> Utf8 Class Initialized
INFO - 2021-07-01 08:11:30 --> URI Class Initialized
INFO - 2021-07-01 08:11:30 --> Router Class Initialized
INFO - 2021-07-01 08:11:30 --> Output Class Initialized
INFO - 2021-07-01 08:11:30 --> Security Class Initialized
DEBUG - 2021-07-01 08:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:11:30 --> Input Class Initialized
INFO - 2021-07-01 08:11:30 --> Language Class Initialized
INFO - 2021-07-01 08:11:30 --> Loader Class Initialized
INFO - 2021-07-01 08:11:30 --> Helper loaded: html_helper
INFO - 2021-07-01 08:11:30 --> Helper loaded: url_helper
INFO - 2021-07-01 08:11:30 --> Helper loaded: form_helper
INFO - 2021-07-01 08:11:30 --> Database Driver Class Initialized
INFO - 2021-07-01 08:11:30 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:11:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:11:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:11:30 --> Encryption Class Initialized
INFO - 2021-07-01 08:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:11:30 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:11:30 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:11:30 --> Model "user_model" initialized
INFO - 2021-07-01 08:11:30 --> Model "role_model" initialized
INFO - 2021-07-01 08:11:30 --> Controller Class Initialized
INFO - 2021-07-01 08:11:30 --> Helper loaded: language_helper
INFO - 2021-07-01 08:11:30 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:11:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:11:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-01 08:11:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\create_user.php
INFO - 2021-07-01 08:11:30 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:11:30 --> Final output sent to browser
DEBUG - 2021-07-01 08:11:30 --> Total execution time: 0.1304
INFO - 2021-07-01 08:11:43 --> Config Class Initialized
INFO - 2021-07-01 08:11:43 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:11:43 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:11:43 --> Utf8 Class Initialized
INFO - 2021-07-01 08:11:43 --> URI Class Initialized
INFO - 2021-07-01 08:11:43 --> Router Class Initialized
INFO - 2021-07-01 08:11:43 --> Output Class Initialized
INFO - 2021-07-01 08:11:43 --> Security Class Initialized
DEBUG - 2021-07-01 08:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:11:43 --> Input Class Initialized
INFO - 2021-07-01 08:11:43 --> Language Class Initialized
INFO - 2021-07-01 08:11:43 --> Loader Class Initialized
INFO - 2021-07-01 08:11:43 --> Helper loaded: html_helper
INFO - 2021-07-01 08:11:43 --> Helper loaded: url_helper
INFO - 2021-07-01 08:11:43 --> Helper loaded: form_helper
INFO - 2021-07-01 08:11:43 --> Database Driver Class Initialized
INFO - 2021-07-01 08:11:43 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:11:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:11:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:11:43 --> Encryption Class Initialized
INFO - 2021-07-01 08:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:11:43 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:11:43 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:11:43 --> Model "user_model" initialized
INFO - 2021-07-01 08:11:43 --> Model "role_model" initialized
INFO - 2021-07-01 08:11:43 --> Controller Class Initialized
INFO - 2021-07-01 08:11:43 --> Helper loaded: language_helper
INFO - 2021-07-01 08:11:43 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:11:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-07-01 08:11:43 --> Final output sent to browser
DEBUG - 2021-07-01 08:11:43 --> Total execution time: 0.0701
INFO - 2021-07-01 08:11:47 --> Config Class Initialized
INFO - 2021-07-01 08:11:47 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:11:47 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:11:47 --> Utf8 Class Initialized
INFO - 2021-07-01 08:11:47 --> URI Class Initialized
INFO - 2021-07-01 08:11:47 --> Router Class Initialized
INFO - 2021-07-01 08:11:47 --> Output Class Initialized
INFO - 2021-07-01 08:11:47 --> Security Class Initialized
DEBUG - 2021-07-01 08:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:11:47 --> Input Class Initialized
INFO - 2021-07-01 08:11:47 --> Language Class Initialized
INFO - 2021-07-01 08:11:47 --> Loader Class Initialized
INFO - 2021-07-01 08:11:47 --> Helper loaded: html_helper
INFO - 2021-07-01 08:11:47 --> Helper loaded: url_helper
INFO - 2021-07-01 08:11:47 --> Helper loaded: form_helper
INFO - 2021-07-01 08:11:47 --> Database Driver Class Initialized
INFO - 2021-07-01 08:11:47 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:11:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:11:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:11:47 --> Encryption Class Initialized
INFO - 2021-07-01 08:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:11:47 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:11:47 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:11:47 --> Model "user_model" initialized
INFO - 2021-07-01 08:11:47 --> Model "role_model" initialized
INFO - 2021-07-01 08:11:47 --> Controller Class Initialized
INFO - 2021-07-01 08:11:47 --> Helper loaded: language_helper
INFO - 2021-07-01 08:11:47 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:11:47 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:11:47 --> Model "Product_model" initialized
INFO - 2021-07-01 08:11:47 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:11:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:11:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:11:47 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:11:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:11:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:11:47 --> Final output sent to browser
DEBUG - 2021-07-01 08:11:47 --> Total execution time: 0.0781
INFO - 2021-07-01 08:11:55 --> Config Class Initialized
INFO - 2021-07-01 08:11:55 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:11:55 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:11:55 --> Utf8 Class Initialized
INFO - 2021-07-01 08:11:55 --> URI Class Initialized
INFO - 2021-07-01 08:11:55 --> Router Class Initialized
INFO - 2021-07-01 08:11:55 --> Output Class Initialized
INFO - 2021-07-01 08:11:55 --> Security Class Initialized
DEBUG - 2021-07-01 08:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:11:55 --> Input Class Initialized
INFO - 2021-07-01 08:11:55 --> Language Class Initialized
INFO - 2021-07-01 08:11:55 --> Loader Class Initialized
INFO - 2021-07-01 08:11:55 --> Helper loaded: html_helper
INFO - 2021-07-01 08:11:55 --> Helper loaded: url_helper
INFO - 2021-07-01 08:11:55 --> Helper loaded: form_helper
INFO - 2021-07-01 08:11:55 --> Database Driver Class Initialized
INFO - 2021-07-01 08:11:55 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:11:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:11:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:11:55 --> Encryption Class Initialized
INFO - 2021-07-01 08:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:11:55 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:11:55 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:11:55 --> Model "user_model" initialized
INFO - 2021-07-01 08:11:55 --> Model "role_model" initialized
INFO - 2021-07-01 08:11:55 --> Controller Class Initialized
INFO - 2021-07-01 08:11:55 --> Helper loaded: language_helper
INFO - 2021-07-01 08:11:55 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:11:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:11:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:11:55 --> Severity: Notice --> Undefined variable: user_data D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\create_user.php 84
ERROR - 2021-07-01 08:11:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\create_user.php 84
INFO - 2021-07-01 08:11:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\create_user.php
INFO - 2021-07-01 08:11:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:11:55 --> Final output sent to browser
DEBUG - 2021-07-01 08:11:55 --> Total execution time: 0.0694
INFO - 2021-07-01 08:11:56 --> Config Class Initialized
INFO - 2021-07-01 08:11:56 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:11:56 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:11:56 --> Utf8 Class Initialized
INFO - 2021-07-01 08:11:56 --> URI Class Initialized
INFO - 2021-07-01 08:11:56 --> Router Class Initialized
INFO - 2021-07-01 08:11:56 --> Output Class Initialized
INFO - 2021-07-01 08:11:56 --> Security Class Initialized
DEBUG - 2021-07-01 08:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:11:56 --> Input Class Initialized
INFO - 2021-07-01 08:11:56 --> Language Class Initialized
INFO - 2021-07-01 08:11:56 --> Loader Class Initialized
INFO - 2021-07-01 08:11:56 --> Helper loaded: html_helper
INFO - 2021-07-01 08:11:56 --> Helper loaded: url_helper
INFO - 2021-07-01 08:11:56 --> Helper loaded: form_helper
INFO - 2021-07-01 08:11:56 --> Database Driver Class Initialized
INFO - 2021-07-01 08:11:56 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:11:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:11:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:11:56 --> Encryption Class Initialized
INFO - 2021-07-01 08:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:11:56 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:11:56 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:11:56 --> Model "user_model" initialized
INFO - 2021-07-01 08:11:56 --> Model "role_model" initialized
INFO - 2021-07-01 08:11:56 --> Controller Class Initialized
INFO - 2021-07-01 08:11:56 --> Helper loaded: language_helper
INFO - 2021-07-01 08:11:56 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:11:56 --> Final output sent to browser
DEBUG - 2021-07-01 08:11:56 --> Total execution time: 0.0737
INFO - 2021-07-01 08:11:59 --> Config Class Initialized
INFO - 2021-07-01 08:11:59 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:11:59 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:11:59 --> Utf8 Class Initialized
INFO - 2021-07-01 08:11:59 --> URI Class Initialized
INFO - 2021-07-01 08:11:59 --> Router Class Initialized
INFO - 2021-07-01 08:11:59 --> Output Class Initialized
INFO - 2021-07-01 08:11:59 --> Security Class Initialized
DEBUG - 2021-07-01 08:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:11:59 --> Input Class Initialized
INFO - 2021-07-01 08:11:59 --> Language Class Initialized
INFO - 2021-07-01 08:11:59 --> Loader Class Initialized
INFO - 2021-07-01 08:11:59 --> Helper loaded: html_helper
INFO - 2021-07-01 08:11:59 --> Helper loaded: url_helper
INFO - 2021-07-01 08:11:59 --> Helper loaded: form_helper
INFO - 2021-07-01 08:11:59 --> Database Driver Class Initialized
INFO - 2021-07-01 08:11:59 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:11:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:11:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:11:59 --> Encryption Class Initialized
INFO - 2021-07-01 08:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:11:59 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:11:59 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:11:59 --> Model "user_model" initialized
INFO - 2021-07-01 08:11:59 --> Model "role_model" initialized
INFO - 2021-07-01 08:11:59 --> Controller Class Initialized
INFO - 2021-07-01 08:11:59 --> Helper loaded: language_helper
INFO - 2021-07-01 08:11:59 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:11:59 --> Final output sent to browser
DEBUG - 2021-07-01 08:11:59 --> Total execution time: 0.0598
INFO - 2021-07-01 08:12:09 --> Config Class Initialized
INFO - 2021-07-01 08:12:09 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:12:09 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:12:09 --> Utf8 Class Initialized
INFO - 2021-07-01 08:12:09 --> URI Class Initialized
INFO - 2021-07-01 08:12:09 --> Router Class Initialized
INFO - 2021-07-01 08:12:09 --> Output Class Initialized
INFO - 2021-07-01 08:12:09 --> Security Class Initialized
DEBUG - 2021-07-01 08:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:12:09 --> Input Class Initialized
INFO - 2021-07-01 08:12:09 --> Language Class Initialized
INFO - 2021-07-01 08:12:09 --> Loader Class Initialized
INFO - 2021-07-01 08:12:09 --> Helper loaded: html_helper
INFO - 2021-07-01 08:12:09 --> Helper loaded: url_helper
INFO - 2021-07-01 08:12:09 --> Helper loaded: form_helper
INFO - 2021-07-01 08:12:09 --> Database Driver Class Initialized
INFO - 2021-07-01 08:12:09 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:12:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:12:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:12:09 --> Encryption Class Initialized
INFO - 2021-07-01 08:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:12:09 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:12:09 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:12:09 --> Model "user_model" initialized
INFO - 2021-07-01 08:12:09 --> Model "role_model" initialized
INFO - 2021-07-01 08:12:09 --> Controller Class Initialized
INFO - 2021-07-01 08:12:09 --> Helper loaded: language_helper
INFO - 2021-07-01 08:12:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:12:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:12:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-01 08:12:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\create_role.php
INFO - 2021-07-01 08:12:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:12:09 --> Final output sent to browser
DEBUG - 2021-07-01 08:12:09 --> Total execution time: 0.0722
INFO - 2021-07-01 08:12:10 --> Config Class Initialized
INFO - 2021-07-01 08:12:10 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:12:10 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:12:10 --> Utf8 Class Initialized
INFO - 2021-07-01 08:12:10 --> URI Class Initialized
INFO - 2021-07-01 08:12:10 --> Router Class Initialized
INFO - 2021-07-01 08:12:10 --> Output Class Initialized
INFO - 2021-07-01 08:12:10 --> Security Class Initialized
DEBUG - 2021-07-01 08:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:12:10 --> Input Class Initialized
INFO - 2021-07-01 08:12:10 --> Language Class Initialized
INFO - 2021-07-01 08:12:10 --> Loader Class Initialized
INFO - 2021-07-01 08:12:10 --> Helper loaded: html_helper
INFO - 2021-07-01 08:12:10 --> Helper loaded: url_helper
INFO - 2021-07-01 08:12:10 --> Helper loaded: form_helper
INFO - 2021-07-01 08:12:10 --> Database Driver Class Initialized
INFO - 2021-07-01 08:12:10 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:12:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:12:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:12:10 --> Encryption Class Initialized
INFO - 2021-07-01 08:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:12:10 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:12:10 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:12:10 --> Model "user_model" initialized
INFO - 2021-07-01 08:12:10 --> Model "role_model" initialized
INFO - 2021-07-01 08:12:10 --> Controller Class Initialized
INFO - 2021-07-01 08:12:10 --> Helper loaded: language_helper
INFO - 2021-07-01 08:12:10 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:12:10 --> Final output sent to browser
DEBUG - 2021-07-01 08:12:10 --> Total execution time: 0.0827
INFO - 2021-07-01 08:12:13 --> Config Class Initialized
INFO - 2021-07-01 08:12:13 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:12:13 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:12:13 --> Utf8 Class Initialized
INFO - 2021-07-01 08:12:13 --> URI Class Initialized
INFO - 2021-07-01 08:12:13 --> Router Class Initialized
INFO - 2021-07-01 08:12:13 --> Output Class Initialized
INFO - 2021-07-01 08:12:13 --> Security Class Initialized
DEBUG - 2021-07-01 08:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:12:13 --> Input Class Initialized
INFO - 2021-07-01 08:12:13 --> Language Class Initialized
INFO - 2021-07-01 08:12:13 --> Loader Class Initialized
INFO - 2021-07-01 08:12:13 --> Helper loaded: html_helper
INFO - 2021-07-01 08:12:13 --> Helper loaded: url_helper
INFO - 2021-07-01 08:12:13 --> Helper loaded: form_helper
INFO - 2021-07-01 08:12:13 --> Database Driver Class Initialized
INFO - 2021-07-01 08:12:13 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:12:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:12:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:12:13 --> Encryption Class Initialized
INFO - 2021-07-01 08:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:12:13 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:12:13 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:12:13 --> Model "user_model" initialized
INFO - 2021-07-01 08:12:13 --> Model "role_model" initialized
INFO - 2021-07-01 08:12:13 --> Controller Class Initialized
INFO - 2021-07-01 08:12:13 --> Helper loaded: language_helper
INFO - 2021-07-01 08:12:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:12:13 --> Final output sent to browser
DEBUG - 2021-07-01 08:12:13 --> Total execution time: 0.0669
INFO - 2021-07-01 08:12:17 --> Config Class Initialized
INFO - 2021-07-01 08:12:17 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:12:17 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:12:17 --> Utf8 Class Initialized
INFO - 2021-07-01 08:12:17 --> URI Class Initialized
INFO - 2021-07-01 08:12:17 --> Router Class Initialized
INFO - 2021-07-01 08:12:17 --> Output Class Initialized
INFO - 2021-07-01 08:12:17 --> Security Class Initialized
DEBUG - 2021-07-01 08:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:12:17 --> Input Class Initialized
INFO - 2021-07-01 08:12:17 --> Language Class Initialized
INFO - 2021-07-01 08:12:17 --> Loader Class Initialized
INFO - 2021-07-01 08:12:17 --> Helper loaded: html_helper
INFO - 2021-07-01 08:12:17 --> Helper loaded: url_helper
INFO - 2021-07-01 08:12:17 --> Helper loaded: form_helper
INFO - 2021-07-01 08:12:17 --> Database Driver Class Initialized
INFO - 2021-07-01 08:12:17 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:12:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:12:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:12:17 --> Encryption Class Initialized
INFO - 2021-07-01 08:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:12:17 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:12:17 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:12:17 --> Model "user_model" initialized
INFO - 2021-07-01 08:12:17 --> Model "role_model" initialized
INFO - 2021-07-01 08:12:17 --> Controller Class Initialized
INFO - 2021-07-01 08:12:17 --> Helper loaded: language_helper
INFO - 2021-07-01 08:12:17 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:12:17 --> Final output sent to browser
DEBUG - 2021-07-01 08:12:17 --> Total execution time: 0.0742
INFO - 2021-07-01 08:12:22 --> Config Class Initialized
INFO - 2021-07-01 08:12:22 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:12:22 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:12:22 --> Utf8 Class Initialized
INFO - 2021-07-01 08:12:22 --> URI Class Initialized
INFO - 2021-07-01 08:12:22 --> Router Class Initialized
INFO - 2021-07-01 08:12:22 --> Output Class Initialized
INFO - 2021-07-01 08:12:22 --> Security Class Initialized
DEBUG - 2021-07-01 08:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:12:22 --> Input Class Initialized
INFO - 2021-07-01 08:12:22 --> Language Class Initialized
INFO - 2021-07-01 08:12:22 --> Loader Class Initialized
INFO - 2021-07-01 08:12:22 --> Helper loaded: html_helper
INFO - 2021-07-01 08:12:22 --> Helper loaded: url_helper
INFO - 2021-07-01 08:12:22 --> Helper loaded: form_helper
INFO - 2021-07-01 08:12:22 --> Database Driver Class Initialized
INFO - 2021-07-01 08:12:22 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:12:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:12:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:12:22 --> Encryption Class Initialized
INFO - 2021-07-01 08:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:12:22 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:12:22 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:12:22 --> Model "user_model" initialized
INFO - 2021-07-01 08:12:22 --> Model "role_model" initialized
INFO - 2021-07-01 08:12:22 --> Controller Class Initialized
INFO - 2021-07-01 08:12:22 --> Helper loaded: language_helper
INFO - 2021-07-01 08:12:22 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:12:22 --> Final output sent to browser
DEBUG - 2021-07-01 08:12:22 --> Total execution time: 0.0653
INFO - 2021-07-01 08:12:25 --> Config Class Initialized
INFO - 2021-07-01 08:12:25 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:12:25 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:12:25 --> Utf8 Class Initialized
INFO - 2021-07-01 08:12:25 --> URI Class Initialized
INFO - 2021-07-01 08:12:25 --> Router Class Initialized
INFO - 2021-07-01 08:12:25 --> Output Class Initialized
INFO - 2021-07-01 08:12:25 --> Security Class Initialized
DEBUG - 2021-07-01 08:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:12:25 --> Input Class Initialized
INFO - 2021-07-01 08:12:25 --> Language Class Initialized
INFO - 2021-07-01 08:12:25 --> Loader Class Initialized
INFO - 2021-07-01 08:12:25 --> Helper loaded: html_helper
INFO - 2021-07-01 08:12:25 --> Helper loaded: url_helper
INFO - 2021-07-01 08:12:25 --> Helper loaded: form_helper
INFO - 2021-07-01 08:12:25 --> Database Driver Class Initialized
INFO - 2021-07-01 08:12:25 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:12:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:12:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:12:25 --> Encryption Class Initialized
INFO - 2021-07-01 08:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:12:25 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:12:25 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:12:25 --> Model "user_model" initialized
INFO - 2021-07-01 08:12:25 --> Model "role_model" initialized
INFO - 2021-07-01 08:12:25 --> Controller Class Initialized
INFO - 2021-07-01 08:12:25 --> Helper loaded: language_helper
INFO - 2021-07-01 08:12:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:12:25 --> Final output sent to browser
DEBUG - 2021-07-01 08:12:25 --> Total execution time: 0.0659
INFO - 2021-07-01 08:12:28 --> Config Class Initialized
INFO - 2021-07-01 08:12:28 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:12:28 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:12:28 --> Utf8 Class Initialized
INFO - 2021-07-01 08:12:28 --> URI Class Initialized
INFO - 2021-07-01 08:12:28 --> Router Class Initialized
INFO - 2021-07-01 08:12:28 --> Output Class Initialized
INFO - 2021-07-01 08:12:28 --> Security Class Initialized
DEBUG - 2021-07-01 08:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:12:28 --> Input Class Initialized
INFO - 2021-07-01 08:12:28 --> Language Class Initialized
INFO - 2021-07-01 08:12:28 --> Loader Class Initialized
INFO - 2021-07-01 08:12:28 --> Helper loaded: html_helper
INFO - 2021-07-01 08:12:28 --> Helper loaded: url_helper
INFO - 2021-07-01 08:12:28 --> Helper loaded: form_helper
INFO - 2021-07-01 08:12:28 --> Database Driver Class Initialized
INFO - 2021-07-01 08:12:28 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:12:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:12:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:12:28 --> Encryption Class Initialized
INFO - 2021-07-01 08:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:12:28 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:12:28 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:12:28 --> Model "user_model" initialized
INFO - 2021-07-01 08:12:28 --> Model "role_model" initialized
INFO - 2021-07-01 08:12:28 --> Controller Class Initialized
INFO - 2021-07-01 08:12:28 --> Helper loaded: language_helper
INFO - 2021-07-01 08:12:28 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:12:28 --> Final output sent to browser
DEBUG - 2021-07-01 08:12:28 --> Total execution time: 0.0641
INFO - 2021-07-01 08:12:33 --> Config Class Initialized
INFO - 2021-07-01 08:12:33 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:12:33 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:12:33 --> Utf8 Class Initialized
INFO - 2021-07-01 08:12:33 --> URI Class Initialized
INFO - 2021-07-01 08:12:33 --> Router Class Initialized
INFO - 2021-07-01 08:12:33 --> Output Class Initialized
INFO - 2021-07-01 08:12:33 --> Security Class Initialized
DEBUG - 2021-07-01 08:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:12:33 --> Input Class Initialized
INFO - 2021-07-01 08:12:33 --> Language Class Initialized
INFO - 2021-07-01 08:12:33 --> Loader Class Initialized
INFO - 2021-07-01 08:12:33 --> Helper loaded: html_helper
INFO - 2021-07-01 08:12:33 --> Helper loaded: url_helper
INFO - 2021-07-01 08:12:33 --> Helper loaded: form_helper
INFO - 2021-07-01 08:12:33 --> Database Driver Class Initialized
INFO - 2021-07-01 08:12:33 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:12:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:12:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:12:33 --> Encryption Class Initialized
INFO - 2021-07-01 08:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:12:33 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:12:33 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:12:33 --> Model "user_model" initialized
INFO - 2021-07-01 08:12:33 --> Model "role_model" initialized
INFO - 2021-07-01 08:12:33 --> Controller Class Initialized
INFO - 2021-07-01 08:12:33 --> Helper loaded: language_helper
INFO - 2021-07-01 08:12:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:12:33 --> Final output sent to browser
DEBUG - 2021-07-01 08:12:33 --> Total execution time: 0.0645
INFO - 2021-07-01 08:12:38 --> Config Class Initialized
INFO - 2021-07-01 08:12:38 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:12:38 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:12:38 --> Utf8 Class Initialized
INFO - 2021-07-01 08:12:38 --> URI Class Initialized
INFO - 2021-07-01 08:12:38 --> Router Class Initialized
INFO - 2021-07-01 08:12:38 --> Output Class Initialized
INFO - 2021-07-01 08:12:38 --> Security Class Initialized
DEBUG - 2021-07-01 08:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:12:38 --> Input Class Initialized
INFO - 2021-07-01 08:12:38 --> Language Class Initialized
INFO - 2021-07-01 08:12:38 --> Loader Class Initialized
INFO - 2021-07-01 08:12:38 --> Helper loaded: html_helper
INFO - 2021-07-01 08:12:38 --> Helper loaded: url_helper
INFO - 2021-07-01 08:12:38 --> Helper loaded: form_helper
INFO - 2021-07-01 08:12:38 --> Database Driver Class Initialized
INFO - 2021-07-01 08:12:38 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:12:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:12:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:12:38 --> Encryption Class Initialized
INFO - 2021-07-01 08:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:12:38 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:12:38 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:12:38 --> Model "user_model" initialized
INFO - 2021-07-01 08:12:38 --> Model "role_model" initialized
INFO - 2021-07-01 08:12:38 --> Controller Class Initialized
INFO - 2021-07-01 08:12:38 --> Helper loaded: language_helper
INFO - 2021-07-01 08:12:38 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:12:38 --> Final output sent to browser
DEBUG - 2021-07-01 08:12:38 --> Total execution time: 0.0661
INFO - 2021-07-01 08:12:49 --> Config Class Initialized
INFO - 2021-07-01 08:12:49 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:12:49 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:12:49 --> Utf8 Class Initialized
INFO - 2021-07-01 08:12:49 --> URI Class Initialized
INFO - 2021-07-01 08:12:49 --> Router Class Initialized
INFO - 2021-07-01 08:12:49 --> Output Class Initialized
INFO - 2021-07-01 08:12:49 --> Security Class Initialized
DEBUG - 2021-07-01 08:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:12:49 --> Input Class Initialized
INFO - 2021-07-01 08:12:49 --> Language Class Initialized
INFO - 2021-07-01 08:12:49 --> Loader Class Initialized
INFO - 2021-07-01 08:12:49 --> Helper loaded: html_helper
INFO - 2021-07-01 08:12:49 --> Helper loaded: url_helper
INFO - 2021-07-01 08:12:49 --> Helper loaded: form_helper
INFO - 2021-07-01 08:12:49 --> Database Driver Class Initialized
INFO - 2021-07-01 08:12:49 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:12:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:12:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:12:49 --> Encryption Class Initialized
INFO - 2021-07-01 08:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:12:49 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:12:49 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:12:49 --> Model "user_model" initialized
INFO - 2021-07-01 08:12:49 --> Model "role_model" initialized
INFO - 2021-07-01 08:12:49 --> Controller Class Initialized
INFO - 2021-07-01 08:12:49 --> Helper loaded: language_helper
INFO - 2021-07-01 08:12:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:12:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-07-01 08:12:50 --> Final output sent to browser
DEBUG - 2021-07-01 08:12:50 --> Total execution time: 0.1449
INFO - 2021-07-01 08:12:50 --> Config Class Initialized
INFO - 2021-07-01 08:12:50 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:12:50 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:12:50 --> Utf8 Class Initialized
INFO - 2021-07-01 08:12:50 --> URI Class Initialized
INFO - 2021-07-01 08:12:50 --> Router Class Initialized
INFO - 2021-07-01 08:12:50 --> Output Class Initialized
INFO - 2021-07-01 08:12:50 --> Security Class Initialized
DEBUG - 2021-07-01 08:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:12:50 --> Input Class Initialized
INFO - 2021-07-01 08:12:50 --> Language Class Initialized
INFO - 2021-07-01 08:12:50 --> Loader Class Initialized
INFO - 2021-07-01 08:12:50 --> Helper loaded: html_helper
INFO - 2021-07-01 08:12:50 --> Helper loaded: url_helper
INFO - 2021-07-01 08:12:50 --> Helper loaded: form_helper
INFO - 2021-07-01 08:12:50 --> Database Driver Class Initialized
INFO - 2021-07-01 08:12:50 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:12:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:12:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:12:50 --> Encryption Class Initialized
INFO - 2021-07-01 08:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:12:50 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:12:50 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:12:50 --> Model "user_model" initialized
INFO - 2021-07-01 08:12:50 --> Model "role_model" initialized
INFO - 2021-07-01 08:12:50 --> Controller Class Initialized
INFO - 2021-07-01 08:12:50 --> Helper loaded: language_helper
INFO - 2021-07-01 08:12:50 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:12:50 --> Final output sent to browser
DEBUG - 2021-07-01 08:12:50 --> Total execution time: 0.0707
INFO - 2021-07-01 08:13:27 --> Config Class Initialized
INFO - 2021-07-01 08:13:27 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:13:27 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:13:27 --> Utf8 Class Initialized
INFO - 2021-07-01 08:13:27 --> URI Class Initialized
INFO - 2021-07-01 08:13:27 --> Router Class Initialized
INFO - 2021-07-01 08:13:27 --> Output Class Initialized
INFO - 2021-07-01 08:13:27 --> Security Class Initialized
DEBUG - 2021-07-01 08:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:13:27 --> Input Class Initialized
INFO - 2021-07-01 08:13:27 --> Language Class Initialized
INFO - 2021-07-01 08:13:27 --> Loader Class Initialized
INFO - 2021-07-01 08:13:27 --> Helper loaded: html_helper
INFO - 2021-07-01 08:13:27 --> Helper loaded: url_helper
INFO - 2021-07-01 08:13:27 --> Helper loaded: form_helper
INFO - 2021-07-01 08:13:27 --> Database Driver Class Initialized
INFO - 2021-07-01 08:13:27 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:13:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:13:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:13:27 --> Encryption Class Initialized
INFO - 2021-07-01 08:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:13:27 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:13:27 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:13:27 --> Model "user_model" initialized
INFO - 2021-07-01 08:13:27 --> Model "role_model" initialized
INFO - 2021-07-01 08:13:27 --> Controller Class Initialized
INFO - 2021-07-01 08:13:27 --> Helper loaded: language_helper
INFO - 2021-07-01 08:13:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:13:27 --> Final output sent to browser
DEBUG - 2021-07-01 08:13:27 --> Total execution time: 0.0699
INFO - 2021-07-01 08:13:37 --> Config Class Initialized
INFO - 2021-07-01 08:13:37 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:13:37 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:13:37 --> Utf8 Class Initialized
INFO - 2021-07-01 08:13:37 --> URI Class Initialized
INFO - 2021-07-01 08:13:37 --> Router Class Initialized
INFO - 2021-07-01 08:13:37 --> Output Class Initialized
INFO - 2021-07-01 08:13:37 --> Security Class Initialized
DEBUG - 2021-07-01 08:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:13:37 --> Input Class Initialized
INFO - 2021-07-01 08:13:37 --> Language Class Initialized
INFO - 2021-07-01 08:13:37 --> Loader Class Initialized
INFO - 2021-07-01 08:13:37 --> Helper loaded: html_helper
INFO - 2021-07-01 08:13:37 --> Helper loaded: url_helper
INFO - 2021-07-01 08:13:37 --> Helper loaded: form_helper
INFO - 2021-07-01 08:13:37 --> Database Driver Class Initialized
INFO - 2021-07-01 08:13:37 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:13:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:13:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:13:37 --> Encryption Class Initialized
INFO - 2021-07-01 08:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:13:37 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:13:37 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:13:37 --> Model "user_model" initialized
INFO - 2021-07-01 08:13:37 --> Model "role_model" initialized
INFO - 2021-07-01 08:13:37 --> Controller Class Initialized
INFO - 2021-07-01 08:13:37 --> Helper loaded: language_helper
INFO - 2021-07-01 08:13:37 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:13:37 --> Final output sent to browser
DEBUG - 2021-07-01 08:13:37 --> Total execution time: 0.0612
INFO - 2021-07-01 08:13:44 --> Config Class Initialized
INFO - 2021-07-01 08:13:44 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:13:44 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:13:44 --> Utf8 Class Initialized
INFO - 2021-07-01 08:13:44 --> URI Class Initialized
INFO - 2021-07-01 08:13:44 --> Router Class Initialized
INFO - 2021-07-01 08:13:44 --> Output Class Initialized
INFO - 2021-07-01 08:13:44 --> Security Class Initialized
DEBUG - 2021-07-01 08:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:13:44 --> Input Class Initialized
INFO - 2021-07-01 08:13:44 --> Language Class Initialized
INFO - 2021-07-01 08:13:44 --> Loader Class Initialized
INFO - 2021-07-01 08:13:44 --> Helper loaded: html_helper
INFO - 2021-07-01 08:13:44 --> Helper loaded: url_helper
INFO - 2021-07-01 08:13:44 --> Helper loaded: form_helper
INFO - 2021-07-01 08:13:44 --> Database Driver Class Initialized
INFO - 2021-07-01 08:13:44 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:13:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:13:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:13:44 --> Encryption Class Initialized
INFO - 2021-07-01 08:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:13:44 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:13:44 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:13:44 --> Model "user_model" initialized
INFO - 2021-07-01 08:13:44 --> Model "role_model" initialized
INFO - 2021-07-01 08:13:44 --> Controller Class Initialized
INFO - 2021-07-01 08:13:44 --> Helper loaded: language_helper
INFO - 2021-07-01 08:13:44 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:13:44 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:13:44 --> Model "Product_model" initialized
INFO - 2021-07-01 08:13:44 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:13:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:13:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:13:44 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:13:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:13:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:13:44 --> Final output sent to browser
DEBUG - 2021-07-01 08:13:44 --> Total execution time: 0.0779
INFO - 2021-07-01 08:13:47 --> Config Class Initialized
INFO - 2021-07-01 08:13:47 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:13:47 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:13:47 --> Utf8 Class Initialized
INFO - 2021-07-01 08:13:47 --> URI Class Initialized
INFO - 2021-07-01 08:13:47 --> Router Class Initialized
INFO - 2021-07-01 08:13:47 --> Output Class Initialized
INFO - 2021-07-01 08:13:47 --> Security Class Initialized
DEBUG - 2021-07-01 08:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:13:47 --> Input Class Initialized
INFO - 2021-07-01 08:13:47 --> Language Class Initialized
INFO - 2021-07-01 08:13:47 --> Loader Class Initialized
INFO - 2021-07-01 08:13:47 --> Helper loaded: html_helper
INFO - 2021-07-01 08:13:47 --> Helper loaded: url_helper
INFO - 2021-07-01 08:13:47 --> Helper loaded: form_helper
INFO - 2021-07-01 08:13:47 --> Database Driver Class Initialized
INFO - 2021-07-01 08:13:47 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:13:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:13:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:13:47 --> Encryption Class Initialized
INFO - 2021-07-01 08:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:13:47 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:13:47 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:13:47 --> Model "user_model" initialized
INFO - 2021-07-01 08:13:47 --> Model "role_model" initialized
INFO - 2021-07-01 08:13:47 --> Controller Class Initialized
INFO - 2021-07-01 08:13:47 --> Helper loaded: language_helper
INFO - 2021-07-01 08:13:47 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:13:47 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:13:47 --> Model "Product_model" initialized
INFO - 2021-07-01 08:13:47 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:13:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:13:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:13:47 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:13:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:13:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:13:47 --> Final output sent to browser
DEBUG - 2021-07-01 08:13:47 --> Total execution time: 0.0796
INFO - 2021-07-01 08:15:21 --> Config Class Initialized
INFO - 2021-07-01 08:15:21 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:15:21 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:15:21 --> Utf8 Class Initialized
INFO - 2021-07-01 08:15:21 --> URI Class Initialized
INFO - 2021-07-01 08:15:21 --> Router Class Initialized
INFO - 2021-07-01 08:15:21 --> Output Class Initialized
INFO - 2021-07-01 08:15:21 --> Security Class Initialized
DEBUG - 2021-07-01 08:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:15:21 --> Input Class Initialized
INFO - 2021-07-01 08:15:21 --> Language Class Initialized
INFO - 2021-07-01 08:15:21 --> Loader Class Initialized
INFO - 2021-07-01 08:15:21 --> Helper loaded: html_helper
INFO - 2021-07-01 08:15:21 --> Helper loaded: url_helper
INFO - 2021-07-01 08:15:21 --> Helper loaded: form_helper
INFO - 2021-07-01 08:15:21 --> Database Driver Class Initialized
INFO - 2021-07-01 08:15:21 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:15:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:15:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:15:21 --> Encryption Class Initialized
INFO - 2021-07-01 08:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:15:21 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:15:21 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:15:21 --> Model "user_model" initialized
INFO - 2021-07-01 08:15:21 --> Model "role_model" initialized
INFO - 2021-07-01 08:15:21 --> Controller Class Initialized
INFO - 2021-07-01 08:15:21 --> Helper loaded: language_helper
INFO - 2021-07-01 08:15:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:15:21 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:15:21 --> Model "Product_model" initialized
INFO - 2021-07-01 08:15:21 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:15:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:15:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:15:21 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:15:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:15:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:15:21 --> Final output sent to browser
DEBUG - 2021-07-01 08:15:21 --> Total execution time: 0.0697
INFO - 2021-07-01 08:16:39 --> Config Class Initialized
INFO - 2021-07-01 08:16:39 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:16:39 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:16:39 --> Utf8 Class Initialized
INFO - 2021-07-01 08:16:39 --> URI Class Initialized
INFO - 2021-07-01 08:16:39 --> Router Class Initialized
INFO - 2021-07-01 08:16:39 --> Output Class Initialized
INFO - 2021-07-01 08:16:39 --> Security Class Initialized
DEBUG - 2021-07-01 08:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:16:39 --> Input Class Initialized
INFO - 2021-07-01 08:16:39 --> Language Class Initialized
INFO - 2021-07-01 08:16:39 --> Loader Class Initialized
INFO - 2021-07-01 08:16:39 --> Helper loaded: html_helper
INFO - 2021-07-01 08:16:39 --> Helper loaded: url_helper
INFO - 2021-07-01 08:16:39 --> Helper loaded: form_helper
INFO - 2021-07-01 08:16:39 --> Database Driver Class Initialized
INFO - 2021-07-01 08:16:39 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:16:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:16:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:16:39 --> Encryption Class Initialized
INFO - 2021-07-01 08:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:16:40 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:16:40 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:16:40 --> Model "user_model" initialized
INFO - 2021-07-01 08:16:40 --> Model "role_model" initialized
INFO - 2021-07-01 08:16:40 --> Controller Class Initialized
INFO - 2021-07-01 08:16:40 --> Helper loaded: language_helper
INFO - 2021-07-01 08:16:40 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:16:40 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:16:40 --> Model "Product_model" initialized
INFO - 2021-07-01 08:16:40 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:16:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:16:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:16:40 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:16:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:16:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:16:40 --> Final output sent to browser
DEBUG - 2021-07-01 08:16:40 --> Total execution time: 0.0865
INFO - 2021-07-01 08:18:16 --> Config Class Initialized
INFO - 2021-07-01 08:18:16 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:18:16 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:18:16 --> Utf8 Class Initialized
INFO - 2021-07-01 08:18:16 --> URI Class Initialized
INFO - 2021-07-01 08:18:16 --> Router Class Initialized
INFO - 2021-07-01 08:18:16 --> Output Class Initialized
INFO - 2021-07-01 08:18:16 --> Security Class Initialized
DEBUG - 2021-07-01 08:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:18:16 --> Input Class Initialized
INFO - 2021-07-01 08:18:16 --> Language Class Initialized
INFO - 2021-07-01 08:18:16 --> Loader Class Initialized
INFO - 2021-07-01 08:18:16 --> Helper loaded: html_helper
INFO - 2021-07-01 08:18:16 --> Helper loaded: url_helper
INFO - 2021-07-01 08:18:16 --> Helper loaded: form_helper
INFO - 2021-07-01 08:18:16 --> Database Driver Class Initialized
INFO - 2021-07-01 08:18:16 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:18:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:18:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:18:16 --> Encryption Class Initialized
INFO - 2021-07-01 08:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:18:16 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:18:16 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:18:16 --> Model "user_model" initialized
INFO - 2021-07-01 08:18:16 --> Model "role_model" initialized
INFO - 2021-07-01 08:18:16 --> Controller Class Initialized
INFO - 2021-07-01 08:18:16 --> Helper loaded: language_helper
INFO - 2021-07-01 08:18:16 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:18:16 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:18:16 --> Model "Product_model" initialized
INFO - 2021-07-01 08:18:16 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:18:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:18:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:18:16 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:18:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:18:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:18:16 --> Final output sent to browser
DEBUG - 2021-07-01 08:18:16 --> Total execution time: 0.0802
INFO - 2021-07-01 08:19:21 --> Config Class Initialized
INFO - 2021-07-01 08:19:21 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:19:21 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:19:21 --> Utf8 Class Initialized
INFO - 2021-07-01 08:19:21 --> URI Class Initialized
INFO - 2021-07-01 08:19:21 --> Router Class Initialized
INFO - 2021-07-01 08:19:21 --> Output Class Initialized
INFO - 2021-07-01 08:19:21 --> Security Class Initialized
DEBUG - 2021-07-01 08:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:19:21 --> Input Class Initialized
INFO - 2021-07-01 08:19:21 --> Language Class Initialized
INFO - 2021-07-01 08:19:21 --> Loader Class Initialized
INFO - 2021-07-01 08:19:21 --> Helper loaded: html_helper
INFO - 2021-07-01 08:19:21 --> Helper loaded: url_helper
INFO - 2021-07-01 08:19:21 --> Helper loaded: form_helper
INFO - 2021-07-01 08:19:21 --> Database Driver Class Initialized
INFO - 2021-07-01 08:19:21 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:19:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:19:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:19:21 --> Encryption Class Initialized
INFO - 2021-07-01 08:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:19:21 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:19:21 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:19:21 --> Model "user_model" initialized
INFO - 2021-07-01 08:19:21 --> Model "role_model" initialized
INFO - 2021-07-01 08:19:21 --> Controller Class Initialized
INFO - 2021-07-01 08:19:21 --> Helper loaded: language_helper
INFO - 2021-07-01 08:19:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:19:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:19:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-01 08:19:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\customer_care.php
INFO - 2021-07-01 08:19:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:19:21 --> Final output sent to browser
DEBUG - 2021-07-01 08:19:21 --> Total execution time: 0.0718
INFO - 2021-07-01 08:19:24 --> Config Class Initialized
INFO - 2021-07-01 08:19:24 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:19:24 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:19:24 --> Utf8 Class Initialized
INFO - 2021-07-01 08:19:24 --> URI Class Initialized
INFO - 2021-07-01 08:19:24 --> Router Class Initialized
INFO - 2021-07-01 08:19:24 --> Output Class Initialized
INFO - 2021-07-01 08:19:24 --> Security Class Initialized
DEBUG - 2021-07-01 08:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:19:24 --> Input Class Initialized
INFO - 2021-07-01 08:19:24 --> Language Class Initialized
INFO - 2021-07-01 08:19:24 --> Loader Class Initialized
INFO - 2021-07-01 08:19:24 --> Helper loaded: html_helper
INFO - 2021-07-01 08:19:24 --> Helper loaded: url_helper
INFO - 2021-07-01 08:19:24 --> Helper loaded: form_helper
INFO - 2021-07-01 08:19:24 --> Database Driver Class Initialized
INFO - 2021-07-01 08:19:24 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:19:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:19:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:19:24 --> Encryption Class Initialized
INFO - 2021-07-01 08:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:19:24 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:19:24 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:19:24 --> Model "user_model" initialized
INFO - 2021-07-01 08:19:24 --> Model "role_model" initialized
INFO - 2021-07-01 08:19:24 --> Controller Class Initialized
INFO - 2021-07-01 08:19:24 --> Helper loaded: language_helper
INFO - 2021-07-01 08:19:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:19:24 --> Model "Customer_care_model" initialized
INFO - 2021-07-01 08:19:25 --> Final output sent to browser
DEBUG - 2021-07-01 08:19:25 --> Total execution time: 0.5661
INFO - 2021-07-01 08:19:39 --> Config Class Initialized
INFO - 2021-07-01 08:19:39 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:19:39 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:19:39 --> Utf8 Class Initialized
INFO - 2021-07-01 08:19:39 --> URI Class Initialized
INFO - 2021-07-01 08:19:39 --> Router Class Initialized
INFO - 2021-07-01 08:19:39 --> Output Class Initialized
INFO - 2021-07-01 08:19:39 --> Security Class Initialized
DEBUG - 2021-07-01 08:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:19:39 --> Input Class Initialized
INFO - 2021-07-01 08:19:39 --> Language Class Initialized
INFO - 2021-07-01 08:19:39 --> Loader Class Initialized
INFO - 2021-07-01 08:19:39 --> Helper loaded: html_helper
INFO - 2021-07-01 08:19:39 --> Helper loaded: url_helper
INFO - 2021-07-01 08:19:39 --> Helper loaded: form_helper
INFO - 2021-07-01 08:19:39 --> Database Driver Class Initialized
INFO - 2021-07-01 08:19:39 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:19:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:19:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:19:39 --> Encryption Class Initialized
INFO - 2021-07-01 08:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:19:39 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:19:39 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:19:39 --> Model "user_model" initialized
INFO - 2021-07-01 08:19:39 --> Model "role_model" initialized
INFO - 2021-07-01 08:19:39 --> Controller Class Initialized
INFO - 2021-07-01 08:19:39 --> Helper loaded: language_helper
INFO - 2021-07-01 08:19:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:19:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:19:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-01 08:19:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\customer_care.php
INFO - 2021-07-01 08:19:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:19:39 --> Final output sent to browser
DEBUG - 2021-07-01 08:19:39 --> Total execution time: 0.0669
INFO - 2021-07-01 08:19:43 --> Config Class Initialized
INFO - 2021-07-01 08:19:43 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:19:43 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:19:43 --> Utf8 Class Initialized
INFO - 2021-07-01 08:19:43 --> URI Class Initialized
INFO - 2021-07-01 08:19:43 --> Router Class Initialized
INFO - 2021-07-01 08:19:43 --> Output Class Initialized
INFO - 2021-07-01 08:19:43 --> Security Class Initialized
DEBUG - 2021-07-01 08:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:19:43 --> Input Class Initialized
INFO - 2021-07-01 08:19:43 --> Language Class Initialized
INFO - 2021-07-01 08:19:43 --> Loader Class Initialized
INFO - 2021-07-01 08:19:43 --> Helper loaded: html_helper
INFO - 2021-07-01 08:19:43 --> Helper loaded: url_helper
INFO - 2021-07-01 08:19:43 --> Helper loaded: form_helper
INFO - 2021-07-01 08:19:43 --> Database Driver Class Initialized
INFO - 2021-07-01 08:19:43 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:19:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:19:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:19:43 --> Encryption Class Initialized
INFO - 2021-07-01 08:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:19:43 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:19:43 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:19:43 --> Model "user_model" initialized
INFO - 2021-07-01 08:19:43 --> Model "role_model" initialized
INFO - 2021-07-01 08:19:43 --> Controller Class Initialized
INFO - 2021-07-01 08:19:43 --> Helper loaded: language_helper
INFO - 2021-07-01 08:19:43 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:19:43 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:19:43 --> Model "Product_model" initialized
INFO - 2021-07-01 08:19:43 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:19:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:19:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:19:43 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:19:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:19:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:19:43 --> Final output sent to browser
DEBUG - 2021-07-01 08:19:43 --> Total execution time: 0.1021
INFO - 2021-07-01 08:19:46 --> Config Class Initialized
INFO - 2021-07-01 08:19:46 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:19:46 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:19:46 --> Utf8 Class Initialized
INFO - 2021-07-01 08:19:46 --> URI Class Initialized
INFO - 2021-07-01 08:19:46 --> Router Class Initialized
INFO - 2021-07-01 08:19:46 --> Output Class Initialized
INFO - 2021-07-01 08:19:46 --> Security Class Initialized
DEBUG - 2021-07-01 08:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:19:46 --> Input Class Initialized
INFO - 2021-07-01 08:19:46 --> Language Class Initialized
INFO - 2021-07-01 08:19:46 --> Loader Class Initialized
INFO - 2021-07-01 08:19:46 --> Helper loaded: html_helper
INFO - 2021-07-01 08:19:46 --> Helper loaded: url_helper
INFO - 2021-07-01 08:19:46 --> Helper loaded: form_helper
INFO - 2021-07-01 08:19:46 --> Database Driver Class Initialized
INFO - 2021-07-01 08:19:46 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:19:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:19:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:19:46 --> Encryption Class Initialized
INFO - 2021-07-01 08:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:19:46 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:19:46 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:19:46 --> Model "user_model" initialized
INFO - 2021-07-01 08:19:46 --> Model "role_model" initialized
INFO - 2021-07-01 08:19:46 --> Controller Class Initialized
INFO - 2021-07-01 08:19:46 --> Helper loaded: language_helper
INFO - 2021-07-01 08:19:46 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:19:46 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:19:46 --> Model "Product_model" initialized
INFO - 2021-07-01 08:19:46 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:19:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:19:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:19:46 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:19:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:19:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:19:46 --> Final output sent to browser
DEBUG - 2021-07-01 08:19:46 --> Total execution time: 0.0726
INFO - 2021-07-01 08:19:48 --> Config Class Initialized
INFO - 2021-07-01 08:19:48 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:19:48 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:19:48 --> Utf8 Class Initialized
INFO - 2021-07-01 08:19:48 --> URI Class Initialized
INFO - 2021-07-01 08:19:48 --> Router Class Initialized
INFO - 2021-07-01 08:19:48 --> Output Class Initialized
INFO - 2021-07-01 08:19:48 --> Security Class Initialized
DEBUG - 2021-07-01 08:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:19:48 --> Input Class Initialized
INFO - 2021-07-01 08:19:48 --> Language Class Initialized
INFO - 2021-07-01 08:19:48 --> Loader Class Initialized
INFO - 2021-07-01 08:19:48 --> Helper loaded: html_helper
INFO - 2021-07-01 08:19:48 --> Helper loaded: url_helper
INFO - 2021-07-01 08:19:48 --> Helper loaded: form_helper
INFO - 2021-07-01 08:19:48 --> Database Driver Class Initialized
INFO - 2021-07-01 08:19:48 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:19:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:19:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:19:48 --> Encryption Class Initialized
INFO - 2021-07-01 08:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:19:48 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:19:48 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:19:48 --> Model "user_model" initialized
INFO - 2021-07-01 08:19:48 --> Model "role_model" initialized
INFO - 2021-07-01 08:19:48 --> Controller Class Initialized
INFO - 2021-07-01 08:19:48 --> Helper loaded: language_helper
INFO - 2021-07-01 08:19:48 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:19:48 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:19:48 --> Model "Product_model" initialized
INFO - 2021-07-01 08:19:48 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:19:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:19:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:19:48 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:19:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:19:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:19:48 --> Final output sent to browser
DEBUG - 2021-07-01 08:19:48 --> Total execution time: 0.0742
INFO - 2021-07-01 08:19:50 --> Config Class Initialized
INFO - 2021-07-01 08:19:50 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:19:50 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:19:50 --> Utf8 Class Initialized
INFO - 2021-07-01 08:19:50 --> URI Class Initialized
INFO - 2021-07-01 08:19:50 --> Router Class Initialized
INFO - 2021-07-01 08:19:50 --> Output Class Initialized
INFO - 2021-07-01 08:19:50 --> Security Class Initialized
DEBUG - 2021-07-01 08:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:19:50 --> Input Class Initialized
INFO - 2021-07-01 08:19:50 --> Language Class Initialized
INFO - 2021-07-01 08:19:50 --> Loader Class Initialized
INFO - 2021-07-01 08:19:50 --> Helper loaded: html_helper
INFO - 2021-07-01 08:19:50 --> Helper loaded: url_helper
INFO - 2021-07-01 08:19:50 --> Helper loaded: form_helper
INFO - 2021-07-01 08:19:50 --> Database Driver Class Initialized
INFO - 2021-07-01 08:19:50 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:19:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:19:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:19:50 --> Encryption Class Initialized
INFO - 2021-07-01 08:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:19:50 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:19:50 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:19:50 --> Model "user_model" initialized
INFO - 2021-07-01 08:19:50 --> Model "role_model" initialized
INFO - 2021-07-01 08:19:50 --> Controller Class Initialized
INFO - 2021-07-01 08:19:50 --> Helper loaded: language_helper
INFO - 2021-07-01 08:19:50 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:19:50 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:19:50 --> Model "Product_model" initialized
INFO - 2021-07-01 08:19:50 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:19:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:19:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:19:50 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:19:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:19:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:19:50 --> Final output sent to browser
DEBUG - 2021-07-01 08:19:50 --> Total execution time: 0.0731
INFO - 2021-07-01 08:19:51 --> Config Class Initialized
INFO - 2021-07-01 08:19:51 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:19:51 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:19:51 --> Utf8 Class Initialized
INFO - 2021-07-01 08:19:51 --> URI Class Initialized
INFO - 2021-07-01 08:19:51 --> Router Class Initialized
INFO - 2021-07-01 08:19:51 --> Output Class Initialized
INFO - 2021-07-01 08:19:51 --> Security Class Initialized
DEBUG - 2021-07-01 08:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:19:51 --> Input Class Initialized
INFO - 2021-07-01 08:19:51 --> Language Class Initialized
INFO - 2021-07-01 08:19:51 --> Loader Class Initialized
INFO - 2021-07-01 08:19:51 --> Helper loaded: html_helper
INFO - 2021-07-01 08:19:51 --> Helper loaded: url_helper
INFO - 2021-07-01 08:19:51 --> Helper loaded: form_helper
INFO - 2021-07-01 08:19:51 --> Database Driver Class Initialized
INFO - 2021-07-01 08:19:51 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:19:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:19:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:19:51 --> Encryption Class Initialized
INFO - 2021-07-01 08:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:19:51 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:19:51 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:19:51 --> Model "user_model" initialized
INFO - 2021-07-01 08:19:51 --> Model "role_model" initialized
INFO - 2021-07-01 08:19:51 --> Controller Class Initialized
INFO - 2021-07-01 08:19:51 --> Helper loaded: language_helper
INFO - 2021-07-01 08:19:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:19:51 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:19:51 --> Model "Product_model" initialized
INFO - 2021-07-01 08:19:51 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:19:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:19:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:19:51 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:19:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:19:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:19:51 --> Final output sent to browser
DEBUG - 2021-07-01 08:19:51 --> Total execution time: 0.0797
INFO - 2021-07-01 08:22:33 --> Config Class Initialized
INFO - 2021-07-01 08:22:33 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:22:33 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:22:33 --> Utf8 Class Initialized
INFO - 2021-07-01 08:22:33 --> URI Class Initialized
INFO - 2021-07-01 08:22:33 --> Router Class Initialized
INFO - 2021-07-01 08:22:33 --> Output Class Initialized
INFO - 2021-07-01 08:22:33 --> Security Class Initialized
DEBUG - 2021-07-01 08:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:22:33 --> Input Class Initialized
INFO - 2021-07-01 08:22:33 --> Language Class Initialized
INFO - 2021-07-01 08:22:33 --> Loader Class Initialized
INFO - 2021-07-01 08:22:33 --> Helper loaded: html_helper
INFO - 2021-07-01 08:22:33 --> Helper loaded: url_helper
INFO - 2021-07-01 08:22:33 --> Helper loaded: form_helper
INFO - 2021-07-01 08:22:33 --> Database Driver Class Initialized
INFO - 2021-07-01 08:22:33 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:22:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:22:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:22:33 --> Encryption Class Initialized
INFO - 2021-07-01 08:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:22:33 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:22:33 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:22:33 --> Model "user_model" initialized
INFO - 2021-07-01 08:22:33 --> Model "role_model" initialized
INFO - 2021-07-01 08:22:33 --> Controller Class Initialized
INFO - 2021-07-01 08:22:33 --> Helper loaded: language_helper
INFO - 2021-07-01 08:22:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:22:33 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:22:33 --> Model "Product_model" initialized
INFO - 2021-07-01 08:22:33 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:22:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:22:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:22:33 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:22:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:22:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:22:33 --> Final output sent to browser
DEBUG - 2021-07-01 08:22:33 --> Total execution time: 0.0792
INFO - 2021-07-01 08:29:06 --> Config Class Initialized
INFO - 2021-07-01 08:29:06 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:29:06 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:29:06 --> Utf8 Class Initialized
INFO - 2021-07-01 08:29:06 --> URI Class Initialized
INFO - 2021-07-01 08:29:06 --> Router Class Initialized
INFO - 2021-07-01 08:29:06 --> Output Class Initialized
INFO - 2021-07-01 08:29:06 --> Security Class Initialized
DEBUG - 2021-07-01 08:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:29:06 --> Input Class Initialized
INFO - 2021-07-01 08:29:06 --> Language Class Initialized
INFO - 2021-07-01 08:29:06 --> Loader Class Initialized
INFO - 2021-07-01 08:29:06 --> Helper loaded: html_helper
INFO - 2021-07-01 08:29:06 --> Helper loaded: url_helper
INFO - 2021-07-01 08:29:06 --> Helper loaded: form_helper
INFO - 2021-07-01 08:29:06 --> Database Driver Class Initialized
INFO - 2021-07-01 08:29:06 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:29:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:29:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:29:06 --> Encryption Class Initialized
INFO - 2021-07-01 08:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:29:06 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:29:06 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:29:06 --> Model "user_model" initialized
INFO - 2021-07-01 08:29:06 --> Model "role_model" initialized
INFO - 2021-07-01 08:29:06 --> Controller Class Initialized
INFO - 2021-07-01 08:29:06 --> Helper loaded: language_helper
INFO - 2021-07-01 08:29:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:29:06 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:29:06 --> Model "Product_model" initialized
INFO - 2021-07-01 08:29:06 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:29:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:29:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:29:06 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:29:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:29:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:29:06 --> Final output sent to browser
DEBUG - 2021-07-01 08:29:06 --> Total execution time: 0.0794
INFO - 2021-07-01 08:29:07 --> Config Class Initialized
INFO - 2021-07-01 08:29:07 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:29:07 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:29:07 --> Utf8 Class Initialized
INFO - 2021-07-01 08:29:07 --> URI Class Initialized
INFO - 2021-07-01 08:29:07 --> Router Class Initialized
INFO - 2021-07-01 08:29:07 --> Output Class Initialized
INFO - 2021-07-01 08:29:07 --> Security Class Initialized
DEBUG - 2021-07-01 08:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:29:07 --> Input Class Initialized
INFO - 2021-07-01 08:29:07 --> Language Class Initialized
INFO - 2021-07-01 08:29:07 --> Loader Class Initialized
INFO - 2021-07-01 08:29:07 --> Helper loaded: html_helper
INFO - 2021-07-01 08:29:07 --> Helper loaded: url_helper
INFO - 2021-07-01 08:29:07 --> Helper loaded: form_helper
INFO - 2021-07-01 08:29:07 --> Database Driver Class Initialized
INFO - 2021-07-01 08:29:07 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:29:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:29:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:29:07 --> Encryption Class Initialized
INFO - 2021-07-01 08:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:29:07 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:29:07 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:29:07 --> Model "user_model" initialized
INFO - 2021-07-01 08:29:07 --> Model "role_model" initialized
INFO - 2021-07-01 08:29:07 --> Controller Class Initialized
INFO - 2021-07-01 08:29:07 --> Helper loaded: language_helper
INFO - 2021-07-01 08:29:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:29:07 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:29:07 --> Model "Product_model" initialized
INFO - 2021-07-01 08:29:07 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:29:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:29:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:29:07 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:29:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:29:07 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:29:07 --> Final output sent to browser
DEBUG - 2021-07-01 08:29:07 --> Total execution time: 0.0994
INFO - 2021-07-01 08:29:08 --> Config Class Initialized
INFO - 2021-07-01 08:29:08 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:29:08 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:29:08 --> Utf8 Class Initialized
INFO - 2021-07-01 08:29:08 --> URI Class Initialized
INFO - 2021-07-01 08:29:08 --> Router Class Initialized
INFO - 2021-07-01 08:29:08 --> Output Class Initialized
INFO - 2021-07-01 08:29:08 --> Security Class Initialized
DEBUG - 2021-07-01 08:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:29:08 --> Input Class Initialized
INFO - 2021-07-01 08:29:08 --> Language Class Initialized
INFO - 2021-07-01 08:29:08 --> Loader Class Initialized
INFO - 2021-07-01 08:29:08 --> Helper loaded: html_helper
INFO - 2021-07-01 08:29:08 --> Helper loaded: url_helper
INFO - 2021-07-01 08:29:08 --> Helper loaded: form_helper
INFO - 2021-07-01 08:29:08 --> Database Driver Class Initialized
INFO - 2021-07-01 08:29:08 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:29:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:29:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:29:08 --> Encryption Class Initialized
INFO - 2021-07-01 08:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:29:08 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:29:08 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:29:08 --> Model "user_model" initialized
INFO - 2021-07-01 08:29:08 --> Model "role_model" initialized
INFO - 2021-07-01 08:29:08 --> Controller Class Initialized
INFO - 2021-07-01 08:29:08 --> Helper loaded: language_helper
INFO - 2021-07-01 08:29:08 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:29:08 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:29:08 --> Model "Product_model" initialized
INFO - 2021-07-01 08:29:08 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:29:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:29:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:29:08 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:29:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:29:08 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:29:08 --> Final output sent to browser
DEBUG - 2021-07-01 08:29:08 --> Total execution time: 0.0739
INFO - 2021-07-01 08:29:09 --> Config Class Initialized
INFO - 2021-07-01 08:29:09 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:29:09 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:29:09 --> Utf8 Class Initialized
INFO - 2021-07-01 08:29:09 --> URI Class Initialized
INFO - 2021-07-01 08:29:09 --> Router Class Initialized
INFO - 2021-07-01 08:29:09 --> Output Class Initialized
INFO - 2021-07-01 08:29:09 --> Security Class Initialized
DEBUG - 2021-07-01 08:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:29:09 --> Input Class Initialized
INFO - 2021-07-01 08:29:09 --> Language Class Initialized
INFO - 2021-07-01 08:29:09 --> Loader Class Initialized
INFO - 2021-07-01 08:29:09 --> Helper loaded: html_helper
INFO - 2021-07-01 08:29:09 --> Helper loaded: url_helper
INFO - 2021-07-01 08:29:09 --> Helper loaded: form_helper
INFO - 2021-07-01 08:29:09 --> Database Driver Class Initialized
INFO - 2021-07-01 08:29:09 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:29:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:29:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:29:09 --> Encryption Class Initialized
INFO - 2021-07-01 08:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:29:09 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:29:09 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:29:09 --> Model "user_model" initialized
INFO - 2021-07-01 08:29:09 --> Model "role_model" initialized
INFO - 2021-07-01 08:29:09 --> Controller Class Initialized
INFO - 2021-07-01 08:29:09 --> Helper loaded: language_helper
INFO - 2021-07-01 08:29:09 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:29:09 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:29:09 --> Model "Product_model" initialized
INFO - 2021-07-01 08:29:09 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:29:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:29:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:29:09 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:29:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:29:09 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:29:09 --> Final output sent to browser
DEBUG - 2021-07-01 08:29:09 --> Total execution time: 0.0923
INFO - 2021-07-01 08:29:10 --> Config Class Initialized
INFO - 2021-07-01 08:29:10 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:29:10 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:29:10 --> Utf8 Class Initialized
INFO - 2021-07-01 08:29:10 --> URI Class Initialized
INFO - 2021-07-01 08:29:10 --> Router Class Initialized
INFO - 2021-07-01 08:29:10 --> Output Class Initialized
INFO - 2021-07-01 08:29:10 --> Security Class Initialized
DEBUG - 2021-07-01 08:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:29:10 --> Input Class Initialized
INFO - 2021-07-01 08:29:10 --> Language Class Initialized
INFO - 2021-07-01 08:29:10 --> Loader Class Initialized
INFO - 2021-07-01 08:29:10 --> Helper loaded: html_helper
INFO - 2021-07-01 08:29:10 --> Helper loaded: url_helper
INFO - 2021-07-01 08:29:10 --> Helper loaded: form_helper
INFO - 2021-07-01 08:29:10 --> Database Driver Class Initialized
INFO - 2021-07-01 08:29:10 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:29:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:29:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:29:10 --> Encryption Class Initialized
INFO - 2021-07-01 08:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:29:10 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:29:10 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:29:10 --> Model "user_model" initialized
INFO - 2021-07-01 08:29:10 --> Model "role_model" initialized
INFO - 2021-07-01 08:29:10 --> Controller Class Initialized
INFO - 2021-07-01 08:29:10 --> Helper loaded: language_helper
INFO - 2021-07-01 08:29:10 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:29:10 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:29:10 --> Model "Product_model" initialized
INFO - 2021-07-01 08:29:10 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:29:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:29:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:29:10 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:29:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:29:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:29:10 --> Final output sent to browser
DEBUG - 2021-07-01 08:29:10 --> Total execution time: 0.1854
INFO - 2021-07-01 08:29:11 --> Config Class Initialized
INFO - 2021-07-01 08:29:11 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:29:11 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:29:11 --> Utf8 Class Initialized
INFO - 2021-07-01 08:29:11 --> URI Class Initialized
INFO - 2021-07-01 08:29:11 --> Router Class Initialized
INFO - 2021-07-01 08:29:11 --> Output Class Initialized
INFO - 2021-07-01 08:29:11 --> Security Class Initialized
DEBUG - 2021-07-01 08:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:29:11 --> Input Class Initialized
INFO - 2021-07-01 08:29:11 --> Language Class Initialized
INFO - 2021-07-01 08:29:11 --> Loader Class Initialized
INFO - 2021-07-01 08:29:11 --> Helper loaded: html_helper
INFO - 2021-07-01 08:29:11 --> Helper loaded: url_helper
INFO - 2021-07-01 08:29:11 --> Helper loaded: form_helper
INFO - 2021-07-01 08:29:11 --> Database Driver Class Initialized
INFO - 2021-07-01 08:29:11 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:29:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:29:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:29:11 --> Encryption Class Initialized
INFO - 2021-07-01 08:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:29:11 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:29:11 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:29:11 --> Model "user_model" initialized
INFO - 2021-07-01 08:29:11 --> Model "role_model" initialized
INFO - 2021-07-01 08:29:11 --> Controller Class Initialized
INFO - 2021-07-01 08:29:11 --> Helper loaded: language_helper
INFO - 2021-07-01 08:29:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:29:11 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:29:11 --> Model "Product_model" initialized
INFO - 2021-07-01 08:29:11 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:29:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:29:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:29:11 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:29:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:29:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:29:11 --> Final output sent to browser
DEBUG - 2021-07-01 08:29:11 --> Total execution time: 0.0796
INFO - 2021-07-01 08:29:12 --> Config Class Initialized
INFO - 2021-07-01 08:29:12 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:29:12 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:29:12 --> Utf8 Class Initialized
INFO - 2021-07-01 08:29:12 --> URI Class Initialized
INFO - 2021-07-01 08:29:12 --> Router Class Initialized
INFO - 2021-07-01 08:29:12 --> Output Class Initialized
INFO - 2021-07-01 08:29:12 --> Security Class Initialized
DEBUG - 2021-07-01 08:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:29:12 --> Input Class Initialized
INFO - 2021-07-01 08:29:12 --> Language Class Initialized
INFO - 2021-07-01 08:29:12 --> Loader Class Initialized
INFO - 2021-07-01 08:29:12 --> Helper loaded: html_helper
INFO - 2021-07-01 08:29:12 --> Helper loaded: url_helper
INFO - 2021-07-01 08:29:12 --> Helper loaded: form_helper
INFO - 2021-07-01 08:29:12 --> Database Driver Class Initialized
INFO - 2021-07-01 08:29:12 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:29:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:29:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:29:12 --> Encryption Class Initialized
INFO - 2021-07-01 08:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:29:12 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:29:12 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:29:12 --> Model "user_model" initialized
INFO - 2021-07-01 08:29:12 --> Model "role_model" initialized
INFO - 2021-07-01 08:29:12 --> Controller Class Initialized
INFO - 2021-07-01 08:29:12 --> Helper loaded: language_helper
INFO - 2021-07-01 08:29:12 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:29:12 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:29:12 --> Model "Product_model" initialized
INFO - 2021-07-01 08:29:12 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:29:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:29:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:29:12 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:29:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:29:12 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:29:12 --> Final output sent to browser
DEBUG - 2021-07-01 08:29:12 --> Total execution time: 0.0762
INFO - 2021-07-01 08:29:13 --> Config Class Initialized
INFO - 2021-07-01 08:29:13 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:29:13 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:29:13 --> Utf8 Class Initialized
INFO - 2021-07-01 08:29:13 --> URI Class Initialized
INFO - 2021-07-01 08:29:13 --> Router Class Initialized
INFO - 2021-07-01 08:29:13 --> Output Class Initialized
INFO - 2021-07-01 08:29:13 --> Security Class Initialized
DEBUG - 2021-07-01 08:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:29:13 --> Input Class Initialized
INFO - 2021-07-01 08:29:13 --> Language Class Initialized
INFO - 2021-07-01 08:29:13 --> Loader Class Initialized
INFO - 2021-07-01 08:29:13 --> Helper loaded: html_helper
INFO - 2021-07-01 08:29:13 --> Helper loaded: url_helper
INFO - 2021-07-01 08:29:13 --> Helper loaded: form_helper
INFO - 2021-07-01 08:29:13 --> Database Driver Class Initialized
INFO - 2021-07-01 08:29:13 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:29:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:29:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:29:13 --> Encryption Class Initialized
INFO - 2021-07-01 08:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:29:13 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:29:13 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:29:13 --> Model "user_model" initialized
INFO - 2021-07-01 08:29:13 --> Model "role_model" initialized
INFO - 2021-07-01 08:29:13 --> Controller Class Initialized
INFO - 2021-07-01 08:29:13 --> Helper loaded: language_helper
INFO - 2021-07-01 08:29:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:29:13 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:29:13 --> Model "Product_model" initialized
INFO - 2021-07-01 08:29:13 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:29:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:29:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:29:13 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:29:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:29:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:29:13 --> Final output sent to browser
DEBUG - 2021-07-01 08:29:13 --> Total execution time: 0.1906
INFO - 2021-07-01 08:29:14 --> Config Class Initialized
INFO - 2021-07-01 08:29:14 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:29:14 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:29:14 --> Utf8 Class Initialized
INFO - 2021-07-01 08:29:14 --> URI Class Initialized
INFO - 2021-07-01 08:29:14 --> Router Class Initialized
INFO - 2021-07-01 08:29:14 --> Output Class Initialized
INFO - 2021-07-01 08:29:14 --> Security Class Initialized
DEBUG - 2021-07-01 08:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:29:14 --> Input Class Initialized
INFO - 2021-07-01 08:29:14 --> Language Class Initialized
INFO - 2021-07-01 08:29:14 --> Loader Class Initialized
INFO - 2021-07-01 08:29:14 --> Helper loaded: html_helper
INFO - 2021-07-01 08:29:14 --> Helper loaded: url_helper
INFO - 2021-07-01 08:29:14 --> Helper loaded: form_helper
INFO - 2021-07-01 08:29:14 --> Database Driver Class Initialized
INFO - 2021-07-01 08:29:14 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:29:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:29:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:29:14 --> Encryption Class Initialized
INFO - 2021-07-01 08:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:29:14 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:29:14 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:29:14 --> Model "user_model" initialized
INFO - 2021-07-01 08:29:14 --> Model "role_model" initialized
INFO - 2021-07-01 08:29:14 --> Controller Class Initialized
INFO - 2021-07-01 08:29:14 --> Helper loaded: language_helper
INFO - 2021-07-01 08:29:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:29:14 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:29:14 --> Model "Product_model" initialized
INFO - 2021-07-01 08:29:14 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:29:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:29:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:29:14 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:29:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:29:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:29:14 --> Final output sent to browser
DEBUG - 2021-07-01 08:29:14 --> Total execution time: 0.0688
INFO - 2021-07-01 08:29:15 --> Config Class Initialized
INFO - 2021-07-01 08:29:15 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:29:15 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:29:15 --> Utf8 Class Initialized
INFO - 2021-07-01 08:29:15 --> URI Class Initialized
INFO - 2021-07-01 08:29:15 --> Router Class Initialized
INFO - 2021-07-01 08:29:15 --> Output Class Initialized
INFO - 2021-07-01 08:29:15 --> Security Class Initialized
DEBUG - 2021-07-01 08:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:29:15 --> Input Class Initialized
INFO - 2021-07-01 08:29:15 --> Language Class Initialized
INFO - 2021-07-01 08:29:15 --> Loader Class Initialized
INFO - 2021-07-01 08:29:15 --> Helper loaded: html_helper
INFO - 2021-07-01 08:29:15 --> Helper loaded: url_helper
INFO - 2021-07-01 08:29:15 --> Helper loaded: form_helper
INFO - 2021-07-01 08:29:15 --> Database Driver Class Initialized
INFO - 2021-07-01 08:29:15 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:29:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:29:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:29:15 --> Encryption Class Initialized
INFO - 2021-07-01 08:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:29:15 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:29:15 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:29:15 --> Model "user_model" initialized
INFO - 2021-07-01 08:29:15 --> Model "role_model" initialized
INFO - 2021-07-01 08:29:15 --> Controller Class Initialized
INFO - 2021-07-01 08:29:15 --> Helper loaded: language_helper
INFO - 2021-07-01 08:29:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:29:15 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:29:15 --> Model "Product_model" initialized
INFO - 2021-07-01 08:29:15 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:29:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:29:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:29:15 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:29:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:29:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:29:15 --> Final output sent to browser
DEBUG - 2021-07-01 08:29:15 --> Total execution time: 0.0709
INFO - 2021-07-01 08:31:17 --> Config Class Initialized
INFO - 2021-07-01 08:31:17 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:31:17 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:31:17 --> Utf8 Class Initialized
INFO - 2021-07-01 08:31:17 --> URI Class Initialized
INFO - 2021-07-01 08:31:17 --> Router Class Initialized
INFO - 2021-07-01 08:31:17 --> Output Class Initialized
INFO - 2021-07-01 08:31:17 --> Security Class Initialized
DEBUG - 2021-07-01 08:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:31:17 --> Input Class Initialized
INFO - 2021-07-01 08:31:17 --> Language Class Initialized
INFO - 2021-07-01 08:31:17 --> Loader Class Initialized
INFO - 2021-07-01 08:31:17 --> Helper loaded: html_helper
INFO - 2021-07-01 08:31:17 --> Helper loaded: url_helper
INFO - 2021-07-01 08:31:17 --> Helper loaded: form_helper
INFO - 2021-07-01 08:31:17 --> Database Driver Class Initialized
INFO - 2021-07-01 08:31:17 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:31:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:31:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:31:17 --> Encryption Class Initialized
INFO - 2021-07-01 08:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:31:17 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:31:17 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:31:17 --> Model "user_model" initialized
INFO - 2021-07-01 08:31:17 --> Model "role_model" initialized
INFO - 2021-07-01 08:31:17 --> Controller Class Initialized
INFO - 2021-07-01 08:31:17 --> Helper loaded: language_helper
INFO - 2021-07-01 08:31:17 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:31:17 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:31:17 --> Model "Product_model" initialized
INFO - 2021-07-01 08:31:17 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:31:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:31:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:31:17 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:31:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:31:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:31:17 --> Final output sent to browser
DEBUG - 2021-07-01 08:31:17 --> Total execution time: 0.0810
INFO - 2021-07-01 08:31:46 --> Config Class Initialized
INFO - 2021-07-01 08:31:46 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:31:46 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:31:46 --> Utf8 Class Initialized
INFO - 2021-07-01 08:31:46 --> URI Class Initialized
INFO - 2021-07-01 08:31:46 --> Router Class Initialized
INFO - 2021-07-01 08:31:46 --> Output Class Initialized
INFO - 2021-07-01 08:31:46 --> Security Class Initialized
DEBUG - 2021-07-01 08:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:31:46 --> Input Class Initialized
INFO - 2021-07-01 08:31:46 --> Language Class Initialized
INFO - 2021-07-01 08:31:46 --> Loader Class Initialized
INFO - 2021-07-01 08:31:46 --> Helper loaded: html_helper
INFO - 2021-07-01 08:31:46 --> Helper loaded: url_helper
INFO - 2021-07-01 08:31:46 --> Helper loaded: form_helper
INFO - 2021-07-01 08:31:46 --> Database Driver Class Initialized
INFO - 2021-07-01 08:31:46 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:31:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:31:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:31:46 --> Encryption Class Initialized
INFO - 2021-07-01 08:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:31:46 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:31:46 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:31:46 --> Model "user_model" initialized
INFO - 2021-07-01 08:31:46 --> Model "role_model" initialized
INFO - 2021-07-01 08:31:46 --> Controller Class Initialized
INFO - 2021-07-01 08:31:46 --> Helper loaded: language_helper
INFO - 2021-07-01 08:31:46 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:31:46 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:31:46 --> Model "Product_model" initialized
INFO - 2021-07-01 08:31:46 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:31:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:31:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:31:46 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:31:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:31:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:31:46 --> Final output sent to browser
DEBUG - 2021-07-01 08:31:46 --> Total execution time: 0.0789
INFO - 2021-07-01 08:31:48 --> Config Class Initialized
INFO - 2021-07-01 08:31:48 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:31:48 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:31:48 --> Utf8 Class Initialized
INFO - 2021-07-01 08:31:48 --> URI Class Initialized
INFO - 2021-07-01 08:31:48 --> Router Class Initialized
INFO - 2021-07-01 08:31:48 --> Output Class Initialized
INFO - 2021-07-01 08:31:48 --> Security Class Initialized
DEBUG - 2021-07-01 08:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:31:48 --> Input Class Initialized
INFO - 2021-07-01 08:31:48 --> Language Class Initialized
INFO - 2021-07-01 08:31:48 --> Loader Class Initialized
INFO - 2021-07-01 08:31:48 --> Helper loaded: html_helper
INFO - 2021-07-01 08:31:48 --> Helper loaded: url_helper
INFO - 2021-07-01 08:31:48 --> Helper loaded: form_helper
INFO - 2021-07-01 08:31:48 --> Database Driver Class Initialized
INFO - 2021-07-01 08:31:48 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:31:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:31:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:31:48 --> Encryption Class Initialized
INFO - 2021-07-01 08:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:31:48 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:31:48 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:31:48 --> Model "user_model" initialized
INFO - 2021-07-01 08:31:48 --> Model "role_model" initialized
INFO - 2021-07-01 08:31:48 --> Controller Class Initialized
INFO - 2021-07-01 08:31:48 --> Helper loaded: language_helper
INFO - 2021-07-01 08:31:48 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:31:48 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:31:48 --> Model "Product_model" initialized
INFO - 2021-07-01 08:31:48 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:31:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:31:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:31:48 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:31:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:31:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:31:48 --> Final output sent to browser
DEBUG - 2021-07-01 08:31:48 --> Total execution time: 0.0805
INFO - 2021-07-01 08:31:49 --> Config Class Initialized
INFO - 2021-07-01 08:31:49 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:31:49 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:31:49 --> Utf8 Class Initialized
INFO - 2021-07-01 08:31:49 --> URI Class Initialized
INFO - 2021-07-01 08:31:49 --> Router Class Initialized
INFO - 2021-07-01 08:31:49 --> Output Class Initialized
INFO - 2021-07-01 08:31:49 --> Security Class Initialized
DEBUG - 2021-07-01 08:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:31:49 --> Input Class Initialized
INFO - 2021-07-01 08:31:49 --> Language Class Initialized
INFO - 2021-07-01 08:31:49 --> Loader Class Initialized
INFO - 2021-07-01 08:31:49 --> Helper loaded: html_helper
INFO - 2021-07-01 08:31:49 --> Helper loaded: url_helper
INFO - 2021-07-01 08:31:49 --> Helper loaded: form_helper
INFO - 2021-07-01 08:31:49 --> Database Driver Class Initialized
INFO - 2021-07-01 08:31:49 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:31:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:31:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:31:49 --> Encryption Class Initialized
INFO - 2021-07-01 08:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:31:49 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:31:49 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:31:49 --> Model "user_model" initialized
INFO - 2021-07-01 08:31:49 --> Model "role_model" initialized
INFO - 2021-07-01 08:31:49 --> Controller Class Initialized
INFO - 2021-07-01 08:31:49 --> Helper loaded: language_helper
INFO - 2021-07-01 08:31:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:31:49 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:31:49 --> Model "Product_model" initialized
INFO - 2021-07-01 08:31:49 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:31:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:31:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:31:49 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:31:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:31:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:31:49 --> Final output sent to browser
DEBUG - 2021-07-01 08:31:49 --> Total execution time: 0.0760
INFO - 2021-07-01 08:31:50 --> Config Class Initialized
INFO - 2021-07-01 08:31:50 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:31:50 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:31:50 --> Utf8 Class Initialized
INFO - 2021-07-01 08:31:50 --> URI Class Initialized
INFO - 2021-07-01 08:31:50 --> Router Class Initialized
INFO - 2021-07-01 08:31:50 --> Output Class Initialized
INFO - 2021-07-01 08:31:50 --> Security Class Initialized
DEBUG - 2021-07-01 08:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:31:50 --> Input Class Initialized
INFO - 2021-07-01 08:31:50 --> Language Class Initialized
INFO - 2021-07-01 08:31:50 --> Loader Class Initialized
INFO - 2021-07-01 08:31:50 --> Helper loaded: html_helper
INFO - 2021-07-01 08:31:50 --> Helper loaded: url_helper
INFO - 2021-07-01 08:31:50 --> Helper loaded: form_helper
INFO - 2021-07-01 08:31:50 --> Database Driver Class Initialized
INFO - 2021-07-01 08:31:50 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:31:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:31:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:31:50 --> Encryption Class Initialized
INFO - 2021-07-01 08:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:31:50 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:31:50 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:31:50 --> Model "user_model" initialized
INFO - 2021-07-01 08:31:50 --> Model "role_model" initialized
INFO - 2021-07-01 08:31:50 --> Controller Class Initialized
INFO - 2021-07-01 08:31:50 --> Helper loaded: language_helper
INFO - 2021-07-01 08:31:50 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:31:50 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:31:50 --> Model "Product_model" initialized
INFO - 2021-07-01 08:31:50 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:31:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:31:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:31:50 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:31:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:31:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:31:50 --> Final output sent to browser
DEBUG - 2021-07-01 08:31:50 --> Total execution time: 0.0777
INFO - 2021-07-01 08:31:51 --> Config Class Initialized
INFO - 2021-07-01 08:31:51 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:31:51 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:31:51 --> Utf8 Class Initialized
INFO - 2021-07-01 08:31:51 --> URI Class Initialized
INFO - 2021-07-01 08:31:51 --> Router Class Initialized
INFO - 2021-07-01 08:31:51 --> Output Class Initialized
INFO - 2021-07-01 08:31:51 --> Security Class Initialized
DEBUG - 2021-07-01 08:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:31:51 --> Input Class Initialized
INFO - 2021-07-01 08:31:51 --> Language Class Initialized
INFO - 2021-07-01 08:31:51 --> Loader Class Initialized
INFO - 2021-07-01 08:31:51 --> Helper loaded: html_helper
INFO - 2021-07-01 08:31:51 --> Helper loaded: url_helper
INFO - 2021-07-01 08:31:51 --> Helper loaded: form_helper
INFO - 2021-07-01 08:31:51 --> Database Driver Class Initialized
INFO - 2021-07-01 08:31:51 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:31:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:31:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:31:51 --> Encryption Class Initialized
INFO - 2021-07-01 08:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:31:51 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:31:51 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:31:51 --> Model "user_model" initialized
INFO - 2021-07-01 08:31:51 --> Model "role_model" initialized
INFO - 2021-07-01 08:31:51 --> Controller Class Initialized
INFO - 2021-07-01 08:31:51 --> Helper loaded: language_helper
INFO - 2021-07-01 08:31:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:31:51 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:31:51 --> Model "Product_model" initialized
INFO - 2021-07-01 08:31:51 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:31:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:31:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:31:51 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:31:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:31:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:31:51 --> Final output sent to browser
DEBUG - 2021-07-01 08:31:51 --> Total execution time: 0.2349
INFO - 2021-07-01 08:31:52 --> Config Class Initialized
INFO - 2021-07-01 08:31:52 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:31:52 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:31:52 --> Utf8 Class Initialized
INFO - 2021-07-01 08:31:52 --> URI Class Initialized
INFO - 2021-07-01 08:31:52 --> Router Class Initialized
INFO - 2021-07-01 08:31:52 --> Output Class Initialized
INFO - 2021-07-01 08:31:52 --> Security Class Initialized
DEBUG - 2021-07-01 08:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:31:52 --> Input Class Initialized
INFO - 2021-07-01 08:31:52 --> Language Class Initialized
INFO - 2021-07-01 08:31:52 --> Loader Class Initialized
INFO - 2021-07-01 08:31:52 --> Helper loaded: html_helper
INFO - 2021-07-01 08:31:52 --> Helper loaded: url_helper
INFO - 2021-07-01 08:31:52 --> Helper loaded: form_helper
INFO - 2021-07-01 08:31:52 --> Database Driver Class Initialized
INFO - 2021-07-01 08:31:52 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:31:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:31:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:31:52 --> Encryption Class Initialized
INFO - 2021-07-01 08:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:31:52 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:31:52 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:31:52 --> Model "user_model" initialized
INFO - 2021-07-01 08:31:52 --> Model "role_model" initialized
INFO - 2021-07-01 08:31:52 --> Controller Class Initialized
INFO - 2021-07-01 08:31:52 --> Helper loaded: language_helper
INFO - 2021-07-01 08:31:52 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:31:52 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:31:52 --> Model "Product_model" initialized
INFO - 2021-07-01 08:31:52 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:31:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:31:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:31:52 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:31:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:31:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:31:52 --> Final output sent to browser
DEBUG - 2021-07-01 08:31:52 --> Total execution time: 0.4377
INFO - 2021-07-01 08:31:52 --> Config Class Initialized
INFO - 2021-07-01 08:31:52 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:31:53 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:31:53 --> Utf8 Class Initialized
INFO - 2021-07-01 08:31:53 --> URI Class Initialized
INFO - 2021-07-01 08:31:53 --> Router Class Initialized
INFO - 2021-07-01 08:31:53 --> Output Class Initialized
INFO - 2021-07-01 08:31:53 --> Security Class Initialized
DEBUG - 2021-07-01 08:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:31:53 --> Input Class Initialized
INFO - 2021-07-01 08:31:53 --> Language Class Initialized
INFO - 2021-07-01 08:31:53 --> Loader Class Initialized
INFO - 2021-07-01 08:31:53 --> Helper loaded: html_helper
INFO - 2021-07-01 08:31:53 --> Helper loaded: url_helper
INFO - 2021-07-01 08:31:53 --> Helper loaded: form_helper
INFO - 2021-07-01 08:31:53 --> Database Driver Class Initialized
INFO - 2021-07-01 08:31:53 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:31:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:31:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:31:53 --> Encryption Class Initialized
INFO - 2021-07-01 08:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:31:53 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:31:53 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:31:53 --> Model "user_model" initialized
INFO - 2021-07-01 08:31:53 --> Model "role_model" initialized
INFO - 2021-07-01 08:31:53 --> Controller Class Initialized
INFO - 2021-07-01 08:31:53 --> Helper loaded: language_helper
INFO - 2021-07-01 08:31:53 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:31:53 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:31:53 --> Model "Product_model" initialized
INFO - 2021-07-01 08:31:53 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:31:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:31:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:31:53 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:31:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:31:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:31:53 --> Final output sent to browser
DEBUG - 2021-07-01 08:31:53 --> Total execution time: 0.0865
INFO - 2021-07-01 08:31:53 --> Config Class Initialized
INFO - 2021-07-01 08:31:53 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:31:53 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:31:53 --> Utf8 Class Initialized
INFO - 2021-07-01 08:31:53 --> URI Class Initialized
INFO - 2021-07-01 08:31:53 --> Router Class Initialized
INFO - 2021-07-01 08:31:53 --> Output Class Initialized
INFO - 2021-07-01 08:31:53 --> Security Class Initialized
DEBUG - 2021-07-01 08:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:31:53 --> Input Class Initialized
INFO - 2021-07-01 08:31:53 --> Language Class Initialized
INFO - 2021-07-01 08:31:53 --> Loader Class Initialized
INFO - 2021-07-01 08:31:53 --> Helper loaded: html_helper
INFO - 2021-07-01 08:31:53 --> Helper loaded: url_helper
INFO - 2021-07-01 08:31:53 --> Helper loaded: form_helper
INFO - 2021-07-01 08:31:53 --> Database Driver Class Initialized
INFO - 2021-07-01 08:31:54 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:31:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:31:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:31:54 --> Encryption Class Initialized
INFO - 2021-07-01 08:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:31:54 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:31:54 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:31:54 --> Model "user_model" initialized
INFO - 2021-07-01 08:31:54 --> Model "role_model" initialized
INFO - 2021-07-01 08:31:54 --> Controller Class Initialized
INFO - 2021-07-01 08:31:54 --> Helper loaded: language_helper
INFO - 2021-07-01 08:31:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:31:54 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:31:54 --> Model "Product_model" initialized
INFO - 2021-07-01 08:31:54 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:31:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:31:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:31:54 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:31:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:31:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:31:54 --> Final output sent to browser
DEBUG - 2021-07-01 08:31:54 --> Total execution time: 0.3201
INFO - 2021-07-01 08:35:23 --> Config Class Initialized
INFO - 2021-07-01 08:35:23 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:35:23 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:35:23 --> Utf8 Class Initialized
INFO - 2021-07-01 08:35:23 --> URI Class Initialized
INFO - 2021-07-01 08:35:23 --> Router Class Initialized
INFO - 2021-07-01 08:35:23 --> Output Class Initialized
INFO - 2021-07-01 08:35:23 --> Security Class Initialized
DEBUG - 2021-07-01 08:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:35:23 --> Input Class Initialized
INFO - 2021-07-01 08:35:23 --> Language Class Initialized
INFO - 2021-07-01 08:35:23 --> Loader Class Initialized
INFO - 2021-07-01 08:35:23 --> Helper loaded: html_helper
INFO - 2021-07-01 08:35:23 --> Helper loaded: url_helper
INFO - 2021-07-01 08:35:23 --> Helper loaded: form_helper
INFO - 2021-07-01 08:35:23 --> Database Driver Class Initialized
INFO - 2021-07-01 08:35:23 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:35:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:35:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:35:23 --> Encryption Class Initialized
INFO - 2021-07-01 08:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:35:23 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:35:23 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:35:23 --> Model "user_model" initialized
INFO - 2021-07-01 08:35:23 --> Model "role_model" initialized
INFO - 2021-07-01 08:35:23 --> Controller Class Initialized
INFO - 2021-07-01 08:35:23 --> Helper loaded: language_helper
INFO - 2021-07-01 08:35:23 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:35:23 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:35:23 --> Model "Product_model" initialized
INFO - 2021-07-01 08:35:23 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:35:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:35:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:35:23 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:35:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:35:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:35:23 --> Final output sent to browser
DEBUG - 2021-07-01 08:35:23 --> Total execution time: 0.0817
INFO - 2021-07-01 08:35:54 --> Config Class Initialized
INFO - 2021-07-01 08:35:54 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:35:54 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:35:54 --> Utf8 Class Initialized
INFO - 2021-07-01 08:35:54 --> URI Class Initialized
INFO - 2021-07-01 08:35:54 --> Router Class Initialized
INFO - 2021-07-01 08:35:54 --> Output Class Initialized
INFO - 2021-07-01 08:35:54 --> Security Class Initialized
DEBUG - 2021-07-01 08:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:35:54 --> Input Class Initialized
INFO - 2021-07-01 08:35:54 --> Language Class Initialized
INFO - 2021-07-01 08:35:54 --> Loader Class Initialized
INFO - 2021-07-01 08:35:54 --> Helper loaded: html_helper
INFO - 2021-07-01 08:35:54 --> Helper loaded: url_helper
INFO - 2021-07-01 08:35:54 --> Helper loaded: form_helper
INFO - 2021-07-01 08:35:54 --> Database Driver Class Initialized
INFO - 2021-07-01 08:35:54 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:35:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:35:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:35:54 --> Encryption Class Initialized
INFO - 2021-07-01 08:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:35:54 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:35:54 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:35:54 --> Model "user_model" initialized
INFO - 2021-07-01 08:35:54 --> Model "role_model" initialized
INFO - 2021-07-01 08:35:54 --> Controller Class Initialized
INFO - 2021-07-01 08:35:54 --> Helper loaded: language_helper
INFO - 2021-07-01 08:35:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:35:54 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:35:54 --> Model "Product_model" initialized
INFO - 2021-07-01 08:35:54 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:35:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:35:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:35:54 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:35:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:35:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:35:54 --> Final output sent to browser
DEBUG - 2021-07-01 08:35:54 --> Total execution time: 0.0773
INFO - 2021-07-01 08:36:34 --> Config Class Initialized
INFO - 2021-07-01 08:36:34 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:36:34 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:36:34 --> Utf8 Class Initialized
INFO - 2021-07-01 08:36:34 --> URI Class Initialized
INFO - 2021-07-01 08:36:34 --> Router Class Initialized
INFO - 2021-07-01 08:36:34 --> Output Class Initialized
INFO - 2021-07-01 08:36:34 --> Security Class Initialized
DEBUG - 2021-07-01 08:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:36:34 --> Input Class Initialized
INFO - 2021-07-01 08:36:34 --> Language Class Initialized
INFO - 2021-07-01 08:36:34 --> Loader Class Initialized
INFO - 2021-07-01 08:36:34 --> Helper loaded: html_helper
INFO - 2021-07-01 08:36:34 --> Helper loaded: url_helper
INFO - 2021-07-01 08:36:34 --> Helper loaded: form_helper
INFO - 2021-07-01 08:36:34 --> Database Driver Class Initialized
INFO - 2021-07-01 08:36:34 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:36:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:36:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:36:34 --> Encryption Class Initialized
INFO - 2021-07-01 08:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:36:34 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:36:34 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:36:34 --> Model "user_model" initialized
INFO - 2021-07-01 08:36:34 --> Model "role_model" initialized
INFO - 2021-07-01 08:36:34 --> Controller Class Initialized
INFO - 2021-07-01 08:36:34 --> Helper loaded: language_helper
INFO - 2021-07-01 08:36:34 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:36:34 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:36:34 --> Model "Product_model" initialized
INFO - 2021-07-01 08:36:34 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:36:34 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:36:34 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:36:34 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:36:34 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:36:34 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:36:34 --> Final output sent to browser
DEBUG - 2021-07-01 08:36:34 --> Total execution time: 0.0779
INFO - 2021-07-01 08:37:14 --> Config Class Initialized
INFO - 2021-07-01 08:37:14 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:37:14 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:37:14 --> Utf8 Class Initialized
INFO - 2021-07-01 08:37:14 --> URI Class Initialized
INFO - 2021-07-01 08:37:14 --> Router Class Initialized
INFO - 2021-07-01 08:37:14 --> Output Class Initialized
INFO - 2021-07-01 08:37:14 --> Security Class Initialized
DEBUG - 2021-07-01 08:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:37:14 --> Input Class Initialized
INFO - 2021-07-01 08:37:14 --> Language Class Initialized
INFO - 2021-07-01 08:37:14 --> Loader Class Initialized
INFO - 2021-07-01 08:37:14 --> Helper loaded: html_helper
INFO - 2021-07-01 08:37:14 --> Helper loaded: url_helper
INFO - 2021-07-01 08:37:14 --> Helper loaded: form_helper
INFO - 2021-07-01 08:37:14 --> Database Driver Class Initialized
INFO - 2021-07-01 08:37:14 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:37:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:37:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:37:14 --> Encryption Class Initialized
INFO - 2021-07-01 08:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:37:14 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:37:14 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:37:14 --> Model "user_model" initialized
INFO - 2021-07-01 08:37:14 --> Model "role_model" initialized
INFO - 2021-07-01 08:37:14 --> Controller Class Initialized
INFO - 2021-07-01 08:37:14 --> Helper loaded: language_helper
INFO - 2021-07-01 08:37:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:37:14 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:37:14 --> Model "Product_model" initialized
INFO - 2021-07-01 08:37:14 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:37:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:37:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:37:14 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:37:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:37:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:37:14 --> Final output sent to browser
DEBUG - 2021-07-01 08:37:14 --> Total execution time: 0.0787
INFO - 2021-07-01 08:37:27 --> Config Class Initialized
INFO - 2021-07-01 08:37:27 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:37:27 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:37:27 --> Utf8 Class Initialized
INFO - 2021-07-01 08:37:27 --> URI Class Initialized
INFO - 2021-07-01 08:37:27 --> Router Class Initialized
INFO - 2021-07-01 08:37:27 --> Output Class Initialized
INFO - 2021-07-01 08:37:27 --> Security Class Initialized
DEBUG - 2021-07-01 08:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:37:27 --> Input Class Initialized
INFO - 2021-07-01 08:37:27 --> Language Class Initialized
INFO - 2021-07-01 08:37:27 --> Loader Class Initialized
INFO - 2021-07-01 08:37:27 --> Helper loaded: html_helper
INFO - 2021-07-01 08:37:27 --> Helper loaded: url_helper
INFO - 2021-07-01 08:37:27 --> Helper loaded: form_helper
INFO - 2021-07-01 08:37:27 --> Database Driver Class Initialized
INFO - 2021-07-01 08:37:27 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:37:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:37:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:37:27 --> Encryption Class Initialized
INFO - 2021-07-01 08:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:37:27 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:37:27 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:37:27 --> Model "user_model" initialized
INFO - 2021-07-01 08:37:27 --> Model "role_model" initialized
INFO - 2021-07-01 08:37:27 --> Controller Class Initialized
INFO - 2021-07-01 08:37:27 --> Helper loaded: language_helper
INFO - 2021-07-01 08:37:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:37:27 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:37:27 --> Model "Product_model" initialized
INFO - 2021-07-01 08:37:27 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:37:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:37:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:37:27 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:37:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:37:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:37:27 --> Final output sent to browser
DEBUG - 2021-07-01 08:37:27 --> Total execution time: 0.0781
INFO - 2021-07-01 08:41:04 --> Config Class Initialized
INFO - 2021-07-01 08:41:04 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:41:04 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:41:04 --> Utf8 Class Initialized
INFO - 2021-07-01 08:41:04 --> URI Class Initialized
INFO - 2021-07-01 08:41:04 --> Router Class Initialized
INFO - 2021-07-01 08:41:04 --> Output Class Initialized
INFO - 2021-07-01 08:41:04 --> Security Class Initialized
DEBUG - 2021-07-01 08:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:41:04 --> Input Class Initialized
INFO - 2021-07-01 08:41:04 --> Language Class Initialized
INFO - 2021-07-01 08:41:04 --> Loader Class Initialized
INFO - 2021-07-01 08:41:04 --> Helper loaded: html_helper
INFO - 2021-07-01 08:41:04 --> Helper loaded: url_helper
INFO - 2021-07-01 08:41:04 --> Helper loaded: form_helper
INFO - 2021-07-01 08:41:04 --> Database Driver Class Initialized
INFO - 2021-07-01 08:41:04 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:41:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:41:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:41:04 --> Encryption Class Initialized
INFO - 2021-07-01 08:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:41:04 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:41:04 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:41:04 --> Model "user_model" initialized
INFO - 2021-07-01 08:41:04 --> Model "role_model" initialized
INFO - 2021-07-01 08:41:04 --> Controller Class Initialized
INFO - 2021-07-01 08:41:04 --> Helper loaded: language_helper
INFO - 2021-07-01 08:41:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:41:04 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:41:04 --> Model "Product_model" initialized
INFO - 2021-07-01 08:41:04 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:41:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:41:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:41:04 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:41:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:41:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:41:04 --> Final output sent to browser
DEBUG - 2021-07-01 08:41:04 --> Total execution time: 0.0848
INFO - 2021-07-01 08:46:58 --> Config Class Initialized
INFO - 2021-07-01 08:46:58 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:46:58 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:46:58 --> Utf8 Class Initialized
INFO - 2021-07-01 08:46:58 --> URI Class Initialized
INFO - 2021-07-01 08:46:58 --> Router Class Initialized
INFO - 2021-07-01 08:46:58 --> Output Class Initialized
INFO - 2021-07-01 08:46:58 --> Security Class Initialized
DEBUG - 2021-07-01 08:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:46:58 --> Input Class Initialized
INFO - 2021-07-01 08:46:58 --> Language Class Initialized
INFO - 2021-07-01 08:46:58 --> Loader Class Initialized
INFO - 2021-07-01 08:46:58 --> Helper loaded: html_helper
INFO - 2021-07-01 08:46:58 --> Helper loaded: url_helper
INFO - 2021-07-01 08:46:58 --> Helper loaded: form_helper
INFO - 2021-07-01 08:46:58 --> Database Driver Class Initialized
INFO - 2021-07-01 08:46:58 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:46:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:46:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:46:58 --> Encryption Class Initialized
INFO - 2021-07-01 08:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:46:58 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:46:58 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:46:58 --> Model "user_model" initialized
INFO - 2021-07-01 08:46:58 --> Model "role_model" initialized
INFO - 2021-07-01 08:46:58 --> Controller Class Initialized
INFO - 2021-07-01 08:46:58 --> Helper loaded: language_helper
INFO - 2021-07-01 08:46:58 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:46:58 --> Model "Customer_model" initialized
INFO - 2021-07-01 08:46:58 --> Model "Product_model" initialized
INFO - 2021-07-01 08:46:58 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 08:46:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:46:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:46:58 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 08:46:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 08:46:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:46:58 --> Final output sent to browser
DEBUG - 2021-07-01 08:46:58 --> Total execution time: 0.0762
INFO - 2021-07-01 08:48:51 --> Config Class Initialized
INFO - 2021-07-01 08:48:51 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:48:51 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:48:51 --> Utf8 Class Initialized
INFO - 2021-07-01 08:48:51 --> URI Class Initialized
INFO - 2021-07-01 08:48:51 --> Router Class Initialized
INFO - 2021-07-01 08:48:51 --> Output Class Initialized
INFO - 2021-07-01 08:48:51 --> Security Class Initialized
DEBUG - 2021-07-01 08:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:48:51 --> Input Class Initialized
INFO - 2021-07-01 08:48:51 --> Language Class Initialized
INFO - 2021-07-01 08:48:51 --> Loader Class Initialized
INFO - 2021-07-01 08:48:51 --> Helper loaded: html_helper
INFO - 2021-07-01 08:48:51 --> Helper loaded: url_helper
INFO - 2021-07-01 08:48:51 --> Helper loaded: form_helper
INFO - 2021-07-01 08:48:51 --> Database Driver Class Initialized
INFO - 2021-07-01 08:48:51 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:48:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:48:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:48:51 --> Encryption Class Initialized
INFO - 2021-07-01 08:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:48:51 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:48:51 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:48:51 --> Model "user_model" initialized
INFO - 2021-07-01 08:48:51 --> Model "role_model" initialized
INFO - 2021-07-01 08:48:51 --> Controller Class Initialized
INFO - 2021-07-01 08:48:51 --> Helper loaded: language_helper
INFO - 2021-07-01 08:48:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:48:51 --> Model "Quotation_model" initialized
INFO - 2021-07-01 08:48:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:48:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:48:51 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 08:48:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 08:48:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:48:51 --> Final output sent to browser
DEBUG - 2021-07-01 08:48:51 --> Total execution time: 0.0772
INFO - 2021-07-01 08:48:55 --> Config Class Initialized
INFO - 2021-07-01 08:48:55 --> Hooks Class Initialized
INFO - 2021-07-01 08:48:55 --> Config Class Initialized
INFO - 2021-07-01 08:48:55 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:48:55 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:48:55 --> Utf8 Class Initialized
DEBUG - 2021-07-01 08:48:55 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:48:55 --> Utf8 Class Initialized
INFO - 2021-07-01 08:48:55 --> URI Class Initialized
INFO - 2021-07-01 08:48:55 --> URI Class Initialized
INFO - 2021-07-01 08:48:55 --> Router Class Initialized
INFO - 2021-07-01 08:48:55 --> Router Class Initialized
INFO - 2021-07-01 08:48:55 --> Output Class Initialized
INFO - 2021-07-01 08:48:55 --> Output Class Initialized
INFO - 2021-07-01 08:48:55 --> Security Class Initialized
INFO - 2021-07-01 08:48:55 --> Security Class Initialized
DEBUG - 2021-07-01 08:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:48:55 --> Input Class Initialized
DEBUG - 2021-07-01 08:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:48:55 --> Input Class Initialized
INFO - 2021-07-01 08:48:55 --> Language Class Initialized
INFO - 2021-07-01 08:48:55 --> Language Class Initialized
INFO - 2021-07-01 08:48:55 --> Loader Class Initialized
INFO - 2021-07-01 08:48:55 --> Loader Class Initialized
INFO - 2021-07-01 08:48:55 --> Helper loaded: html_helper
INFO - 2021-07-01 08:48:55 --> Helper loaded: html_helper
INFO - 2021-07-01 08:48:55 --> Helper loaded: url_helper
INFO - 2021-07-01 08:48:55 --> Helper loaded: url_helper
INFO - 2021-07-01 08:48:55 --> Helper loaded: form_helper
INFO - 2021-07-01 08:48:55 --> Helper loaded: form_helper
INFO - 2021-07-01 08:48:55 --> Database Driver Class Initialized
INFO - 2021-07-01 08:48:55 --> Database Driver Class Initialized
INFO - 2021-07-01 08:48:55 --> Form Validation Class Initialized
INFO - 2021-07-01 08:48:55 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-01 08:48:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:48:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:48:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:48:55 --> Encryption Class Initialized
INFO - 2021-07-01 08:48:55 --> Encryption Class Initialized
INFO - 2021-07-01 08:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:48:55 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:48:55 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:48:55 --> Model "user_model" initialized
INFO - 2021-07-01 08:48:55 --> Model "role_model" initialized
INFO - 2021-07-01 08:48:55 --> Controller Class Initialized
INFO - 2021-07-01 08:48:55 --> Helper loaded: language_helper
INFO - 2021-07-01 08:48:55 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:48:55 --> Model "Quotation_model" initialized
INFO - 2021-07-01 08:48:55 --> Final output sent to browser
DEBUG - 2021-07-01 08:48:55 --> Total execution time: 0.0690
INFO - 2021-07-01 08:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:48:55 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:48:55 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:48:55 --> Model "user_model" initialized
INFO - 2021-07-01 08:48:55 --> Model "role_model" initialized
INFO - 2021-07-01 08:48:55 --> Controller Class Initialized
INFO - 2021-07-01 08:48:55 --> Helper loaded: language_helper
INFO - 2021-07-01 08:48:55 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:48:55 --> Model "Quotation_model" initialized
INFO - 2021-07-01 08:48:55 --> Final output sent to browser
DEBUG - 2021-07-01 08:48:55 --> Total execution time: 0.0792
INFO - 2021-07-01 08:50:26 --> Config Class Initialized
INFO - 2021-07-01 08:50:26 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:50:26 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:50:26 --> Utf8 Class Initialized
INFO - 2021-07-01 08:50:26 --> URI Class Initialized
INFO - 2021-07-01 08:50:26 --> Router Class Initialized
INFO - 2021-07-01 08:50:26 --> Output Class Initialized
INFO - 2021-07-01 08:50:26 --> Security Class Initialized
DEBUG - 2021-07-01 08:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:50:26 --> Input Class Initialized
INFO - 2021-07-01 08:50:26 --> Language Class Initialized
INFO - 2021-07-01 08:50:26 --> Loader Class Initialized
INFO - 2021-07-01 08:50:26 --> Helper loaded: html_helper
INFO - 2021-07-01 08:50:26 --> Helper loaded: url_helper
INFO - 2021-07-01 08:50:26 --> Helper loaded: form_helper
INFO - 2021-07-01 08:50:26 --> Database Driver Class Initialized
INFO - 2021-07-01 08:50:26 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:50:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:50:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:50:26 --> Encryption Class Initialized
INFO - 2021-07-01 08:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:50:26 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:50:26 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:50:26 --> Model "user_model" initialized
INFO - 2021-07-01 08:50:26 --> Model "role_model" initialized
INFO - 2021-07-01 08:50:26 --> Controller Class Initialized
INFO - 2021-07-01 08:50:26 --> Helper loaded: language_helper
INFO - 2021-07-01 08:50:26 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:50:26 --> Model "Quotation_model" initialized
INFO - 2021-07-01 08:50:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:50:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:50:26 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 08:50:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 08:50:26 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:50:26 --> Final output sent to browser
DEBUG - 2021-07-01 08:50:26 --> Total execution time: 0.0786
INFO - 2021-07-01 08:50:29 --> Config Class Initialized
INFO - 2021-07-01 08:50:29 --> Hooks Class Initialized
INFO - 2021-07-01 08:50:29 --> Config Class Initialized
INFO - 2021-07-01 08:50:29 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:50:29 --> UTF-8 Support Enabled
DEBUG - 2021-07-01 08:50:29 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:50:29 --> Utf8 Class Initialized
INFO - 2021-07-01 08:50:29 --> Utf8 Class Initialized
INFO - 2021-07-01 08:50:29 --> URI Class Initialized
INFO - 2021-07-01 08:50:29 --> URI Class Initialized
INFO - 2021-07-01 08:50:29 --> Router Class Initialized
INFO - 2021-07-01 08:50:29 --> Router Class Initialized
INFO - 2021-07-01 08:50:29 --> Output Class Initialized
INFO - 2021-07-01 08:50:29 --> Output Class Initialized
INFO - 2021-07-01 08:50:29 --> Security Class Initialized
INFO - 2021-07-01 08:50:29 --> Security Class Initialized
DEBUG - 2021-07-01 08:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:50:29 --> Input Class Initialized
INFO - 2021-07-01 08:50:29 --> Language Class Initialized
DEBUG - 2021-07-01 08:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:50:29 --> Input Class Initialized
INFO - 2021-07-01 08:50:29 --> Language Class Initialized
INFO - 2021-07-01 08:50:29 --> Loader Class Initialized
INFO - 2021-07-01 08:50:29 --> Helper loaded: html_helper
INFO - 2021-07-01 08:50:29 --> Helper loaded: url_helper
INFO - 2021-07-01 08:50:29 --> Loader Class Initialized
INFO - 2021-07-01 08:50:29 --> Helper loaded: form_helper
INFO - 2021-07-01 08:50:29 --> Helper loaded: html_helper
INFO - 2021-07-01 08:50:29 --> Helper loaded: url_helper
INFO - 2021-07-01 08:50:29 --> Helper loaded: form_helper
INFO - 2021-07-01 08:50:29 --> Database Driver Class Initialized
INFO - 2021-07-01 08:50:29 --> Database Driver Class Initialized
INFO - 2021-07-01 08:50:29 --> Form Validation Class Initialized
INFO - 2021-07-01 08:50:29 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-01 08:50:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:50:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:50:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:50:29 --> Encryption Class Initialized
INFO - 2021-07-01 08:50:29 --> Encryption Class Initialized
INFO - 2021-07-01 08:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:50:29 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:50:29 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:50:29 --> Model "user_model" initialized
INFO - 2021-07-01 08:50:29 --> Model "role_model" initialized
INFO - 2021-07-01 08:50:29 --> Controller Class Initialized
INFO - 2021-07-01 08:50:29 --> Helper loaded: language_helper
INFO - 2021-07-01 08:50:29 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:50:29 --> Model "Quotation_model" initialized
INFO - 2021-07-01 08:50:29 --> Final output sent to browser
DEBUG - 2021-07-01 08:50:29 --> Total execution time: 0.0740
INFO - 2021-07-01 08:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:50:29 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:50:29 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:50:29 --> Model "user_model" initialized
INFO - 2021-07-01 08:50:29 --> Model "role_model" initialized
INFO - 2021-07-01 08:50:29 --> Controller Class Initialized
INFO - 2021-07-01 08:50:29 --> Helper loaded: language_helper
INFO - 2021-07-01 08:50:29 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:50:29 --> Model "Quotation_model" initialized
INFO - 2021-07-01 08:50:29 --> Final output sent to browser
DEBUG - 2021-07-01 08:50:29 --> Total execution time: 0.0839
INFO - 2021-07-01 08:53:39 --> Config Class Initialized
INFO - 2021-07-01 08:53:39 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:53:39 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:53:39 --> Utf8 Class Initialized
INFO - 2021-07-01 08:53:39 --> URI Class Initialized
INFO - 2021-07-01 08:53:39 --> Router Class Initialized
INFO - 2021-07-01 08:53:39 --> Output Class Initialized
INFO - 2021-07-01 08:53:39 --> Security Class Initialized
DEBUG - 2021-07-01 08:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:53:39 --> Input Class Initialized
INFO - 2021-07-01 08:53:39 --> Language Class Initialized
INFO - 2021-07-01 08:53:39 --> Loader Class Initialized
INFO - 2021-07-01 08:53:39 --> Helper loaded: html_helper
INFO - 2021-07-01 08:53:39 --> Helper loaded: url_helper
INFO - 2021-07-01 08:53:39 --> Helper loaded: form_helper
INFO - 2021-07-01 08:53:39 --> Database Driver Class Initialized
INFO - 2021-07-01 08:53:39 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:53:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:53:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:53:39 --> Encryption Class Initialized
INFO - 2021-07-01 08:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:53:40 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:53:40 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:53:40 --> Model "user_model" initialized
INFO - 2021-07-01 08:53:40 --> Model "role_model" initialized
INFO - 2021-07-01 08:53:40 --> Controller Class Initialized
INFO - 2021-07-01 08:53:40 --> Helper loaded: language_helper
INFO - 2021-07-01 08:53:40 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:53:40 --> Model "Quotation_model" initialized
INFO - 2021-07-01 08:53:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 08:53:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 08:53:40 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 08:53:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 08:53:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 08:53:40 --> Final output sent to browser
DEBUG - 2021-07-01 08:53:40 --> Total execution time: 0.1125
INFO - 2021-07-01 08:53:48 --> Config Class Initialized
INFO - 2021-07-01 08:53:48 --> Hooks Class Initialized
INFO - 2021-07-01 08:53:48 --> Config Class Initialized
INFO - 2021-07-01 08:53:48 --> Hooks Class Initialized
DEBUG - 2021-07-01 08:53:48 --> UTF-8 Support Enabled
DEBUG - 2021-07-01 08:53:48 --> UTF-8 Support Enabled
INFO - 2021-07-01 08:53:48 --> Utf8 Class Initialized
INFO - 2021-07-01 08:53:48 --> Utf8 Class Initialized
INFO - 2021-07-01 08:53:48 --> URI Class Initialized
INFO - 2021-07-01 08:53:48 --> URI Class Initialized
INFO - 2021-07-01 08:53:48 --> Router Class Initialized
INFO - 2021-07-01 08:53:48 --> Router Class Initialized
INFO - 2021-07-01 08:53:48 --> Output Class Initialized
INFO - 2021-07-01 08:53:48 --> Output Class Initialized
INFO - 2021-07-01 08:53:48 --> Security Class Initialized
INFO - 2021-07-01 08:53:48 --> Security Class Initialized
DEBUG - 2021-07-01 08:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-01 08:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 08:53:48 --> Input Class Initialized
INFO - 2021-07-01 08:53:48 --> Input Class Initialized
INFO - 2021-07-01 08:53:48 --> Language Class Initialized
INFO - 2021-07-01 08:53:48 --> Language Class Initialized
INFO - 2021-07-01 08:53:48 --> Loader Class Initialized
INFO - 2021-07-01 08:53:48 --> Loader Class Initialized
INFO - 2021-07-01 08:53:48 --> Helper loaded: html_helper
INFO - 2021-07-01 08:53:48 --> Helper loaded: html_helper
INFO - 2021-07-01 08:53:48 --> Helper loaded: url_helper
INFO - 2021-07-01 08:53:48 --> Helper loaded: url_helper
INFO - 2021-07-01 08:53:48 --> Helper loaded: form_helper
INFO - 2021-07-01 08:53:48 --> Helper loaded: form_helper
INFO - 2021-07-01 08:53:48 --> Database Driver Class Initialized
INFO - 2021-07-01 08:53:48 --> Database Driver Class Initialized
INFO - 2021-07-01 08:53:48 --> Form Validation Class Initialized
INFO - 2021-07-01 08:53:48 --> Form Validation Class Initialized
DEBUG - 2021-07-01 08:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-01 08:53:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 08:53:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:53:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 08:53:48 --> Encryption Class Initialized
INFO - 2021-07-01 08:53:48 --> Encryption Class Initialized
INFO - 2021-07-01 08:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:53:48 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:53:48 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:53:48 --> Model "user_model" initialized
INFO - 2021-07-01 08:53:48 --> Model "role_model" initialized
INFO - 2021-07-01 08:53:48 --> Controller Class Initialized
INFO - 2021-07-01 08:53:48 --> Helper loaded: language_helper
INFO - 2021-07-01 08:53:48 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:53:48 --> Model "Quotation_model" initialized
INFO - 2021-07-01 08:53:48 --> Final output sent to browser
DEBUG - 2021-07-01 08:53:48 --> Total execution time: 0.0705
INFO - 2021-07-01 08:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 08:53:48 --> Model "vendor_model" initialized
INFO - 2021-07-01 08:53:48 --> Model "coupon_model" initialized
INFO - 2021-07-01 08:53:48 --> Model "user_model" initialized
INFO - 2021-07-01 08:53:48 --> Model "role_model" initialized
INFO - 2021-07-01 08:53:48 --> Controller Class Initialized
INFO - 2021-07-01 08:53:48 --> Helper loaded: language_helper
INFO - 2021-07-01 08:53:48 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 08:53:48 --> Model "Quotation_model" initialized
INFO - 2021-07-01 08:53:48 --> Final output sent to browser
DEBUG - 2021-07-01 08:53:48 --> Total execution time: 0.0812
INFO - 2021-07-01 09:00:40 --> Config Class Initialized
INFO - 2021-07-01 09:00:40 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:00:40 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:00:40 --> Utf8 Class Initialized
INFO - 2021-07-01 09:00:40 --> URI Class Initialized
INFO - 2021-07-01 09:00:40 --> Router Class Initialized
INFO - 2021-07-01 09:00:40 --> Output Class Initialized
INFO - 2021-07-01 09:00:40 --> Security Class Initialized
DEBUG - 2021-07-01 09:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:00:40 --> Input Class Initialized
INFO - 2021-07-01 09:00:40 --> Language Class Initialized
INFO - 2021-07-01 09:00:40 --> Loader Class Initialized
INFO - 2021-07-01 09:00:40 --> Helper loaded: html_helper
INFO - 2021-07-01 09:00:40 --> Helper loaded: url_helper
INFO - 2021-07-01 09:00:40 --> Helper loaded: form_helper
INFO - 2021-07-01 09:00:40 --> Database Driver Class Initialized
INFO - 2021-07-01 09:00:40 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:00:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:00:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:00:40 --> Encryption Class Initialized
INFO - 2021-07-01 09:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:00:40 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:00:40 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:00:40 --> Model "user_model" initialized
INFO - 2021-07-01 09:00:40 --> Model "role_model" initialized
INFO - 2021-07-01 09:00:40 --> Controller Class Initialized
INFO - 2021-07-01 09:00:40 --> Helper loaded: language_helper
INFO - 2021-07-01 09:00:40 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:00:40 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:00:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:00:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:00:40 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:00:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:00:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:00:40 --> Final output sent to browser
DEBUG - 2021-07-01 09:00:40 --> Total execution time: 0.1604
INFO - 2021-07-01 09:01:01 --> Config Class Initialized
INFO - 2021-07-01 09:01:01 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:01:01 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:01:01 --> Utf8 Class Initialized
INFO - 2021-07-01 09:01:01 --> URI Class Initialized
INFO - 2021-07-01 09:01:01 --> Router Class Initialized
INFO - 2021-07-01 09:01:01 --> Output Class Initialized
INFO - 2021-07-01 09:01:01 --> Security Class Initialized
DEBUG - 2021-07-01 09:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:01:01 --> Input Class Initialized
INFO - 2021-07-01 09:01:01 --> Language Class Initialized
INFO - 2021-07-01 09:01:01 --> Loader Class Initialized
INFO - 2021-07-01 09:01:01 --> Helper loaded: html_helper
INFO - 2021-07-01 09:01:01 --> Helper loaded: url_helper
INFO - 2021-07-01 09:01:01 --> Helper loaded: form_helper
INFO - 2021-07-01 09:01:01 --> Database Driver Class Initialized
INFO - 2021-07-01 09:01:01 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:01:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:01:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:01:01 --> Encryption Class Initialized
INFO - 2021-07-01 09:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:01:01 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:01:01 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:01:01 --> Model "user_model" initialized
INFO - 2021-07-01 09:01:01 --> Model "role_model" initialized
INFO - 2021-07-01 09:01:01 --> Controller Class Initialized
INFO - 2021-07-01 09:01:01 --> Helper loaded: language_helper
INFO - 2021-07-01 09:01:01 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:01:01 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:01:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:01:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:01:01 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:01:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:01:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:01:01 --> Final output sent to browser
DEBUG - 2021-07-01 09:01:01 --> Total execution time: 0.0834
INFO - 2021-07-01 09:01:54 --> Config Class Initialized
INFO - 2021-07-01 09:01:54 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:01:54 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:01:54 --> Utf8 Class Initialized
INFO - 2021-07-01 09:01:54 --> URI Class Initialized
INFO - 2021-07-01 09:01:54 --> Router Class Initialized
INFO - 2021-07-01 09:01:54 --> Output Class Initialized
INFO - 2021-07-01 09:01:54 --> Security Class Initialized
DEBUG - 2021-07-01 09:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:01:54 --> Input Class Initialized
INFO - 2021-07-01 09:01:54 --> Language Class Initialized
INFO - 2021-07-01 09:01:54 --> Loader Class Initialized
INFO - 2021-07-01 09:01:54 --> Helper loaded: html_helper
INFO - 2021-07-01 09:01:54 --> Helper loaded: url_helper
INFO - 2021-07-01 09:01:54 --> Helper loaded: form_helper
INFO - 2021-07-01 09:01:54 --> Database Driver Class Initialized
INFO - 2021-07-01 09:01:54 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:01:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:01:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:01:54 --> Encryption Class Initialized
INFO - 2021-07-01 09:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:01:54 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:01:54 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:01:54 --> Model "user_model" initialized
INFO - 2021-07-01 09:01:54 --> Model "role_model" initialized
INFO - 2021-07-01 09:01:54 --> Controller Class Initialized
INFO - 2021-07-01 09:01:54 --> Helper loaded: language_helper
INFO - 2021-07-01 09:01:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:01:54 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:01:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:01:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:01:54 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:01:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:01:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:01:54 --> Final output sent to browser
DEBUG - 2021-07-01 09:01:54 --> Total execution time: 0.1102
INFO - 2021-07-01 09:02:14 --> Config Class Initialized
INFO - 2021-07-01 09:02:14 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:02:14 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:02:14 --> Utf8 Class Initialized
INFO - 2021-07-01 09:02:14 --> URI Class Initialized
INFO - 2021-07-01 09:02:14 --> Router Class Initialized
INFO - 2021-07-01 09:02:14 --> Output Class Initialized
INFO - 2021-07-01 09:02:14 --> Security Class Initialized
DEBUG - 2021-07-01 09:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:02:14 --> Input Class Initialized
INFO - 2021-07-01 09:02:14 --> Language Class Initialized
INFO - 2021-07-01 09:02:14 --> Loader Class Initialized
INFO - 2021-07-01 09:02:14 --> Helper loaded: html_helper
INFO - 2021-07-01 09:02:14 --> Helper loaded: url_helper
INFO - 2021-07-01 09:02:14 --> Helper loaded: form_helper
INFO - 2021-07-01 09:02:14 --> Database Driver Class Initialized
INFO - 2021-07-01 09:02:14 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:02:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:02:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:02:14 --> Encryption Class Initialized
INFO - 2021-07-01 09:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:02:14 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:02:14 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:02:14 --> Model "user_model" initialized
INFO - 2021-07-01 09:02:14 --> Model "role_model" initialized
INFO - 2021-07-01 09:02:14 --> Controller Class Initialized
INFO - 2021-07-01 09:02:14 --> Helper loaded: language_helper
INFO - 2021-07-01 09:02:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:02:14 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:02:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:02:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:02:14 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:02:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:02:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:02:14 --> Final output sent to browser
DEBUG - 2021-07-01 09:02:14 --> Total execution time: 0.0741
INFO - 2021-07-01 09:03:19 --> Config Class Initialized
INFO - 2021-07-01 09:03:19 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:03:19 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:03:19 --> Utf8 Class Initialized
INFO - 2021-07-01 09:03:19 --> URI Class Initialized
INFO - 2021-07-01 09:03:19 --> Router Class Initialized
INFO - 2021-07-01 09:03:19 --> Output Class Initialized
INFO - 2021-07-01 09:03:19 --> Security Class Initialized
DEBUG - 2021-07-01 09:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:03:19 --> Input Class Initialized
INFO - 2021-07-01 09:03:19 --> Language Class Initialized
INFO - 2021-07-01 09:03:19 --> Loader Class Initialized
INFO - 2021-07-01 09:03:19 --> Helper loaded: html_helper
INFO - 2021-07-01 09:03:19 --> Helper loaded: url_helper
INFO - 2021-07-01 09:03:19 --> Helper loaded: form_helper
INFO - 2021-07-01 09:03:19 --> Database Driver Class Initialized
INFO - 2021-07-01 09:03:19 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:03:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:03:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:03:19 --> Encryption Class Initialized
INFO - 2021-07-01 09:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:03:19 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:03:19 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:03:19 --> Model "user_model" initialized
INFO - 2021-07-01 09:03:19 --> Model "role_model" initialized
INFO - 2021-07-01 09:03:19 --> Controller Class Initialized
INFO - 2021-07-01 09:03:19 --> Helper loaded: language_helper
INFO - 2021-07-01 09:03:19 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:03:19 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:03:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:03:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:03:19 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:03:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:03:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:03:19 --> Final output sent to browser
DEBUG - 2021-07-01 09:03:19 --> Total execution time: 0.1211
INFO - 2021-07-01 09:03:25 --> Config Class Initialized
INFO - 2021-07-01 09:03:25 --> Config Class Initialized
INFO - 2021-07-01 09:03:25 --> Hooks Class Initialized
INFO - 2021-07-01 09:03:25 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:03:25 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:03:25 --> Utf8 Class Initialized
DEBUG - 2021-07-01 09:03:25 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:03:25 --> Utf8 Class Initialized
INFO - 2021-07-01 09:03:25 --> URI Class Initialized
INFO - 2021-07-01 09:03:25 --> URI Class Initialized
INFO - 2021-07-01 09:03:25 --> Router Class Initialized
INFO - 2021-07-01 09:03:25 --> Router Class Initialized
INFO - 2021-07-01 09:03:25 --> Output Class Initialized
INFO - 2021-07-01 09:03:25 --> Output Class Initialized
INFO - 2021-07-01 09:03:25 --> Security Class Initialized
INFO - 2021-07-01 09:03:25 --> Security Class Initialized
DEBUG - 2021-07-01 09:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:03:25 --> Input Class Initialized
INFO - 2021-07-01 09:03:25 --> Language Class Initialized
DEBUG - 2021-07-01 09:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:03:25 --> Loader Class Initialized
INFO - 2021-07-01 09:03:25 --> Helper loaded: html_helper
INFO - 2021-07-01 09:03:25 --> Helper loaded: url_helper
INFO - 2021-07-01 09:03:25 --> Helper loaded: form_helper
INFO - 2021-07-01 09:03:25 --> Input Class Initialized
INFO - 2021-07-01 09:03:25 --> Language Class Initialized
INFO - 2021-07-01 09:03:25 --> Database Driver Class Initialized
INFO - 2021-07-01 09:03:25 --> Loader Class Initialized
INFO - 2021-07-01 09:03:25 --> Helper loaded: html_helper
INFO - 2021-07-01 09:03:25 --> Helper loaded: url_helper
INFO - 2021-07-01 09:03:25 --> Helper loaded: form_helper
INFO - 2021-07-01 09:03:25 --> Database Driver Class Initialized
INFO - 2021-07-01 09:03:25 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:03:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:03:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:03:25 --> Encryption Class Initialized
INFO - 2021-07-01 09:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:03:25 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:03:25 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:03:25 --> Model "user_model" initialized
INFO - 2021-07-01 09:03:25 --> Model "role_model" initialized
INFO - 2021-07-01 09:03:25 --> Controller Class Initialized
INFO - 2021-07-01 09:03:25 --> Helper loaded: language_helper
INFO - 2021-07-01 09:03:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:03:25 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:03:25 --> Final output sent to browser
DEBUG - 2021-07-01 09:03:25 --> Total execution time: 0.0789
INFO - 2021-07-01 09:03:25 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:03:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:03:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:03:25 --> Encryption Class Initialized
INFO - 2021-07-01 09:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:03:25 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:03:25 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:03:25 --> Model "user_model" initialized
INFO - 2021-07-01 09:03:25 --> Model "role_model" initialized
INFO - 2021-07-01 09:03:25 --> Controller Class Initialized
INFO - 2021-07-01 09:03:25 --> Helper loaded: language_helper
INFO - 2021-07-01 09:03:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:03:25 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:03:25 --> Final output sent to browser
DEBUG - 2021-07-01 09:03:25 --> Total execution time: 0.1075
INFO - 2021-07-01 09:04:18 --> Config Class Initialized
INFO - 2021-07-01 09:04:18 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:04:18 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:04:18 --> Utf8 Class Initialized
INFO - 2021-07-01 09:04:18 --> URI Class Initialized
INFO - 2021-07-01 09:04:18 --> Router Class Initialized
INFO - 2021-07-01 09:04:18 --> Output Class Initialized
INFO - 2021-07-01 09:04:18 --> Security Class Initialized
DEBUG - 2021-07-01 09:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:04:18 --> Input Class Initialized
INFO - 2021-07-01 09:04:18 --> Language Class Initialized
INFO - 2021-07-01 09:04:18 --> Loader Class Initialized
INFO - 2021-07-01 09:04:18 --> Helper loaded: html_helper
INFO - 2021-07-01 09:04:18 --> Helper loaded: url_helper
INFO - 2021-07-01 09:04:18 --> Helper loaded: form_helper
INFO - 2021-07-01 09:04:18 --> Database Driver Class Initialized
INFO - 2021-07-01 09:04:18 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:04:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:04:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:04:18 --> Encryption Class Initialized
INFO - 2021-07-01 09:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:04:18 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:04:18 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:04:18 --> Model "user_model" initialized
INFO - 2021-07-01 09:04:18 --> Model "role_model" initialized
INFO - 2021-07-01 09:04:18 --> Controller Class Initialized
INFO - 2021-07-01 09:04:18 --> Helper loaded: language_helper
INFO - 2021-07-01 09:04:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:04:18 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:04:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:04:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:04:18 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:04:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:04:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:04:18 --> Final output sent to browser
DEBUG - 2021-07-01 09:04:18 --> Total execution time: 0.0806
INFO - 2021-07-01 09:04:42 --> Config Class Initialized
INFO - 2021-07-01 09:04:42 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:04:42 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:04:42 --> Utf8 Class Initialized
INFO - 2021-07-01 09:04:42 --> URI Class Initialized
INFO - 2021-07-01 09:04:42 --> Router Class Initialized
INFO - 2021-07-01 09:04:42 --> Output Class Initialized
INFO - 2021-07-01 09:04:42 --> Security Class Initialized
DEBUG - 2021-07-01 09:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:04:42 --> Input Class Initialized
INFO - 2021-07-01 09:04:42 --> Language Class Initialized
INFO - 2021-07-01 09:04:42 --> Loader Class Initialized
INFO - 2021-07-01 09:04:42 --> Helper loaded: html_helper
INFO - 2021-07-01 09:04:42 --> Helper loaded: url_helper
INFO - 2021-07-01 09:04:42 --> Helper loaded: form_helper
INFO - 2021-07-01 09:04:42 --> Database Driver Class Initialized
INFO - 2021-07-01 09:04:42 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:04:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:04:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:04:42 --> Encryption Class Initialized
INFO - 2021-07-01 09:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:04:42 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:04:42 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:04:42 --> Model "user_model" initialized
INFO - 2021-07-01 09:04:42 --> Model "role_model" initialized
INFO - 2021-07-01 09:04:42 --> Controller Class Initialized
INFO - 2021-07-01 09:04:42 --> Helper loaded: language_helper
INFO - 2021-07-01 09:04:42 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:04:42 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:04:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:04:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:04:42 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:04:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:04:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:04:42 --> Final output sent to browser
DEBUG - 2021-07-01 09:04:42 --> Total execution time: 0.1059
INFO - 2021-07-01 09:04:46 --> Config Class Initialized
INFO - 2021-07-01 09:04:46 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:04:46 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:04:46 --> Utf8 Class Initialized
INFO - 2021-07-01 09:04:46 --> URI Class Initialized
INFO - 2021-07-01 09:04:46 --> Router Class Initialized
INFO - 2021-07-01 09:04:46 --> Output Class Initialized
INFO - 2021-07-01 09:04:46 --> Security Class Initialized
DEBUG - 2021-07-01 09:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:04:46 --> Input Class Initialized
INFO - 2021-07-01 09:04:46 --> Language Class Initialized
INFO - 2021-07-01 09:04:46 --> Loader Class Initialized
INFO - 2021-07-01 09:04:46 --> Helper loaded: html_helper
INFO - 2021-07-01 09:04:46 --> Helper loaded: url_helper
INFO - 2021-07-01 09:04:46 --> Helper loaded: form_helper
INFO - 2021-07-01 09:04:46 --> Database Driver Class Initialized
INFO - 2021-07-01 09:04:46 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:04:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:04:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:04:46 --> Encryption Class Initialized
INFO - 2021-07-01 09:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:04:46 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:04:46 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:04:46 --> Model "user_model" initialized
INFO - 2021-07-01 09:04:46 --> Model "role_model" initialized
INFO - 2021-07-01 09:04:46 --> Controller Class Initialized
INFO - 2021-07-01 09:04:46 --> Helper loaded: language_helper
INFO - 2021-07-01 09:04:46 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:04:46 --> Model "Customer_model" initialized
INFO - 2021-07-01 09:04:46 --> Model "Product_model" initialized
INFO - 2021-07-01 09:04:46 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 09:04:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:04:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:04:46 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 09:04:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 09:04:46 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:04:46 --> Final output sent to browser
DEBUG - 2021-07-01 09:04:46 --> Total execution time: 0.0790
INFO - 2021-07-01 09:04:51 --> Config Class Initialized
INFO - 2021-07-01 09:04:51 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:04:51 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:04:51 --> Utf8 Class Initialized
INFO - 2021-07-01 09:04:51 --> URI Class Initialized
INFO - 2021-07-01 09:04:51 --> Router Class Initialized
INFO - 2021-07-01 09:04:51 --> Output Class Initialized
INFO - 2021-07-01 09:04:51 --> Security Class Initialized
DEBUG - 2021-07-01 09:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:04:51 --> Input Class Initialized
INFO - 2021-07-01 09:04:51 --> Language Class Initialized
INFO - 2021-07-01 09:04:51 --> Loader Class Initialized
INFO - 2021-07-01 09:04:51 --> Helper loaded: html_helper
INFO - 2021-07-01 09:04:51 --> Helper loaded: url_helper
INFO - 2021-07-01 09:04:51 --> Helper loaded: form_helper
INFO - 2021-07-01 09:04:51 --> Database Driver Class Initialized
INFO - 2021-07-01 09:04:51 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:04:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:04:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:04:51 --> Encryption Class Initialized
INFO - 2021-07-01 09:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:04:51 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:04:51 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:04:51 --> Model "user_model" initialized
INFO - 2021-07-01 09:04:51 --> Model "role_model" initialized
INFO - 2021-07-01 09:04:51 --> Controller Class Initialized
INFO - 2021-07-01 09:04:51 --> Helper loaded: language_helper
INFO - 2021-07-01 09:04:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:04:51 --> Model "Customer_model" initialized
INFO - 2021-07-01 09:04:51 --> Model "Product_model" initialized
INFO - 2021-07-01 09:04:51 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 09:04:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:04:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:04:51 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 09:04:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 09:04:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:04:51 --> Final output sent to browser
DEBUG - 2021-07-01 09:04:51 --> Total execution time: 0.0777
INFO - 2021-07-01 09:04:52 --> Config Class Initialized
INFO - 2021-07-01 09:04:52 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:04:52 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:04:52 --> Utf8 Class Initialized
INFO - 2021-07-01 09:04:52 --> URI Class Initialized
INFO - 2021-07-01 09:04:52 --> Router Class Initialized
INFO - 2021-07-01 09:04:52 --> Output Class Initialized
INFO - 2021-07-01 09:04:52 --> Security Class Initialized
DEBUG - 2021-07-01 09:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:04:52 --> Input Class Initialized
INFO - 2021-07-01 09:04:52 --> Language Class Initialized
INFO - 2021-07-01 09:04:52 --> Loader Class Initialized
INFO - 2021-07-01 09:04:52 --> Helper loaded: html_helper
INFO - 2021-07-01 09:04:52 --> Helper loaded: url_helper
INFO - 2021-07-01 09:04:52 --> Helper loaded: form_helper
INFO - 2021-07-01 09:04:52 --> Database Driver Class Initialized
INFO - 2021-07-01 09:04:52 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:04:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:04:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:04:52 --> Encryption Class Initialized
INFO - 2021-07-01 09:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:04:52 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:04:52 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:04:52 --> Model "user_model" initialized
INFO - 2021-07-01 09:04:52 --> Model "role_model" initialized
INFO - 2021-07-01 09:04:52 --> Controller Class Initialized
INFO - 2021-07-01 09:04:52 --> Helper loaded: language_helper
INFO - 2021-07-01 09:04:52 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:04:52 --> Model "Customer_model" initialized
INFO - 2021-07-01 09:04:52 --> Model "Product_model" initialized
INFO - 2021-07-01 09:04:52 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 09:04:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:04:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:04:52 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 09:04:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 09:04:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:04:52 --> Final output sent to browser
DEBUG - 2021-07-01 09:04:52 --> Total execution time: 0.0856
INFO - 2021-07-01 09:04:56 --> Config Class Initialized
INFO - 2021-07-01 09:04:56 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:04:56 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:04:56 --> Utf8 Class Initialized
INFO - 2021-07-01 09:04:56 --> URI Class Initialized
INFO - 2021-07-01 09:04:56 --> Router Class Initialized
INFO - 2021-07-01 09:04:56 --> Output Class Initialized
INFO - 2021-07-01 09:04:56 --> Security Class Initialized
DEBUG - 2021-07-01 09:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:04:56 --> Input Class Initialized
INFO - 2021-07-01 09:04:56 --> Language Class Initialized
INFO - 2021-07-01 09:04:56 --> Loader Class Initialized
INFO - 2021-07-01 09:04:56 --> Helper loaded: html_helper
INFO - 2021-07-01 09:04:56 --> Helper loaded: url_helper
INFO - 2021-07-01 09:04:56 --> Helper loaded: form_helper
INFO - 2021-07-01 09:04:56 --> Database Driver Class Initialized
INFO - 2021-07-01 09:04:56 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:04:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:04:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:04:56 --> Encryption Class Initialized
INFO - 2021-07-01 09:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:04:56 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:04:56 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:04:56 --> Model "user_model" initialized
INFO - 2021-07-01 09:04:56 --> Model "role_model" initialized
INFO - 2021-07-01 09:04:56 --> Controller Class Initialized
INFO - 2021-07-01 09:04:56 --> Helper loaded: language_helper
INFO - 2021-07-01 09:04:56 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:04:56 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:04:56 --> Model "Customer_model" initialized
INFO - 2021-07-01 09:04:56 --> Model "Product_model" initialized
INFO - 2021-07-01 09:04:56 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 09:04:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:04:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:04:56 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 09:04:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 09:04:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:04:56 --> Final output sent to browser
DEBUG - 2021-07-01 09:04:56 --> Total execution time: 0.0816
INFO - 2021-07-01 09:05:03 --> Config Class Initialized
INFO - 2021-07-01 09:05:03 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:05:03 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:05:03 --> Utf8 Class Initialized
INFO - 2021-07-01 09:05:03 --> URI Class Initialized
INFO - 2021-07-01 09:05:03 --> Router Class Initialized
INFO - 2021-07-01 09:05:03 --> Output Class Initialized
INFO - 2021-07-01 09:05:03 --> Security Class Initialized
DEBUG - 2021-07-01 09:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:05:03 --> Input Class Initialized
INFO - 2021-07-01 09:05:03 --> Language Class Initialized
INFO - 2021-07-01 09:05:03 --> Loader Class Initialized
INFO - 2021-07-01 09:05:03 --> Helper loaded: html_helper
INFO - 2021-07-01 09:05:03 --> Helper loaded: url_helper
INFO - 2021-07-01 09:05:03 --> Helper loaded: form_helper
INFO - 2021-07-01 09:05:03 --> Database Driver Class Initialized
INFO - 2021-07-01 09:05:03 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:05:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:05:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:05:03 --> Encryption Class Initialized
INFO - 2021-07-01 09:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:05:03 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:05:03 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:05:03 --> Model "user_model" initialized
INFO - 2021-07-01 09:05:03 --> Model "role_model" initialized
INFO - 2021-07-01 09:05:03 --> Controller Class Initialized
INFO - 2021-07-01 09:05:03 --> Helper loaded: language_helper
INFO - 2021-07-01 09:05:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:05:03 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:05:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:05:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:05:03 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:05:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:05:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:05:03 --> Final output sent to browser
DEBUG - 2021-07-01 09:05:03 --> Total execution time: 0.0768
INFO - 2021-07-01 09:05:47 --> Config Class Initialized
INFO - 2021-07-01 09:05:47 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:05:47 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:05:47 --> Utf8 Class Initialized
INFO - 2021-07-01 09:05:47 --> URI Class Initialized
INFO - 2021-07-01 09:05:47 --> Router Class Initialized
INFO - 2021-07-01 09:05:47 --> Output Class Initialized
INFO - 2021-07-01 09:05:47 --> Security Class Initialized
DEBUG - 2021-07-01 09:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:05:47 --> Input Class Initialized
INFO - 2021-07-01 09:05:47 --> Language Class Initialized
INFO - 2021-07-01 09:05:47 --> Loader Class Initialized
INFO - 2021-07-01 09:05:47 --> Helper loaded: html_helper
INFO - 2021-07-01 09:05:47 --> Helper loaded: url_helper
INFO - 2021-07-01 09:05:47 --> Helper loaded: form_helper
INFO - 2021-07-01 09:05:47 --> Database Driver Class Initialized
INFO - 2021-07-01 09:05:47 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:05:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:05:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:05:47 --> Encryption Class Initialized
INFO - 2021-07-01 09:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:05:47 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:05:47 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:05:47 --> Model "user_model" initialized
INFO - 2021-07-01 09:05:47 --> Model "role_model" initialized
INFO - 2021-07-01 09:05:47 --> Controller Class Initialized
INFO - 2021-07-01 09:05:47 --> Helper loaded: language_helper
INFO - 2021-07-01 09:05:47 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:05:47 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:05:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:05:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:05:48 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:05:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:05:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:05:48 --> Final output sent to browser
DEBUG - 2021-07-01 09:05:48 --> Total execution time: 0.1245
INFO - 2021-07-01 09:08:21 --> Config Class Initialized
INFO - 2021-07-01 09:08:21 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:08:21 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:08:21 --> Utf8 Class Initialized
INFO - 2021-07-01 09:08:21 --> URI Class Initialized
INFO - 2021-07-01 09:08:21 --> Router Class Initialized
INFO - 2021-07-01 09:08:21 --> Output Class Initialized
INFO - 2021-07-01 09:08:21 --> Security Class Initialized
DEBUG - 2021-07-01 09:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:08:21 --> Input Class Initialized
INFO - 2021-07-01 09:08:21 --> Language Class Initialized
INFO - 2021-07-01 09:08:21 --> Loader Class Initialized
INFO - 2021-07-01 09:08:21 --> Helper loaded: html_helper
INFO - 2021-07-01 09:08:21 --> Helper loaded: url_helper
INFO - 2021-07-01 09:08:21 --> Helper loaded: form_helper
INFO - 2021-07-01 09:08:21 --> Database Driver Class Initialized
INFO - 2021-07-01 09:08:21 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:08:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:08:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:08:21 --> Encryption Class Initialized
INFO - 2021-07-01 09:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:08:21 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:08:21 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:08:21 --> Model "user_model" initialized
INFO - 2021-07-01 09:08:21 --> Model "role_model" initialized
INFO - 2021-07-01 09:08:21 --> Controller Class Initialized
INFO - 2021-07-01 09:08:21 --> Helper loaded: language_helper
INFO - 2021-07-01 09:08:21 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:08:21 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:08:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:08:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:08:21 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:08:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:08:21 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:08:21 --> Final output sent to browser
DEBUG - 2021-07-01 09:08:21 --> Total execution time: 0.1115
INFO - 2021-07-01 09:08:49 --> Config Class Initialized
INFO - 2021-07-01 09:08:49 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:08:49 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:08:49 --> Utf8 Class Initialized
INFO - 2021-07-01 09:08:49 --> URI Class Initialized
INFO - 2021-07-01 09:08:49 --> Router Class Initialized
INFO - 2021-07-01 09:08:49 --> Output Class Initialized
INFO - 2021-07-01 09:08:49 --> Security Class Initialized
DEBUG - 2021-07-01 09:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:08:49 --> Input Class Initialized
INFO - 2021-07-01 09:08:49 --> Language Class Initialized
INFO - 2021-07-01 09:08:49 --> Loader Class Initialized
INFO - 2021-07-01 09:08:49 --> Helper loaded: html_helper
INFO - 2021-07-01 09:08:49 --> Helper loaded: url_helper
INFO - 2021-07-01 09:08:49 --> Helper loaded: form_helper
INFO - 2021-07-01 09:08:49 --> Database Driver Class Initialized
INFO - 2021-07-01 09:08:49 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:08:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:08:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:08:49 --> Encryption Class Initialized
INFO - 2021-07-01 09:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:08:49 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:08:49 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:08:49 --> Model "user_model" initialized
INFO - 2021-07-01 09:08:49 --> Model "role_model" initialized
INFO - 2021-07-01 09:08:49 --> Controller Class Initialized
INFO - 2021-07-01 09:08:49 --> Helper loaded: language_helper
INFO - 2021-07-01 09:08:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:08:49 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:08:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:08:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:08:49 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:08:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:08:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:08:49 --> Final output sent to browser
DEBUG - 2021-07-01 09:08:49 --> Total execution time: 0.1017
INFO - 2021-07-01 09:12:31 --> Config Class Initialized
INFO - 2021-07-01 09:12:31 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:12:31 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:12:31 --> Utf8 Class Initialized
INFO - 2021-07-01 09:12:31 --> URI Class Initialized
INFO - 2021-07-01 09:12:31 --> Router Class Initialized
INFO - 2021-07-01 09:12:31 --> Output Class Initialized
INFO - 2021-07-01 09:12:31 --> Security Class Initialized
DEBUG - 2021-07-01 09:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:12:31 --> Input Class Initialized
INFO - 2021-07-01 09:12:31 --> Language Class Initialized
INFO - 2021-07-01 09:12:31 --> Loader Class Initialized
INFO - 2021-07-01 09:12:31 --> Helper loaded: html_helper
INFO - 2021-07-01 09:12:31 --> Helper loaded: url_helper
INFO - 2021-07-01 09:12:31 --> Helper loaded: form_helper
INFO - 2021-07-01 09:12:31 --> Database Driver Class Initialized
INFO - 2021-07-01 09:12:31 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:12:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:12:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:12:31 --> Encryption Class Initialized
INFO - 2021-07-01 09:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:12:31 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:12:31 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:12:31 --> Model "user_model" initialized
INFO - 2021-07-01 09:12:31 --> Model "role_model" initialized
INFO - 2021-07-01 09:12:31 --> Controller Class Initialized
INFO - 2021-07-01 09:12:31 --> Helper loaded: language_helper
INFO - 2021-07-01 09:12:31 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:12:31 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:12:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:12:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:12:31 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:12:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:12:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:12:31 --> Final output sent to browser
DEBUG - 2021-07-01 09:12:31 --> Total execution time: 0.1138
INFO - 2021-07-01 09:13:16 --> Config Class Initialized
INFO - 2021-07-01 09:13:16 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:13:16 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:13:16 --> Utf8 Class Initialized
INFO - 2021-07-01 09:13:16 --> URI Class Initialized
INFO - 2021-07-01 09:13:16 --> Router Class Initialized
INFO - 2021-07-01 09:13:16 --> Output Class Initialized
INFO - 2021-07-01 09:13:16 --> Security Class Initialized
DEBUG - 2021-07-01 09:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:13:16 --> Input Class Initialized
INFO - 2021-07-01 09:13:16 --> Language Class Initialized
INFO - 2021-07-01 09:13:16 --> Loader Class Initialized
INFO - 2021-07-01 09:13:16 --> Helper loaded: html_helper
INFO - 2021-07-01 09:13:16 --> Helper loaded: url_helper
INFO - 2021-07-01 09:13:16 --> Helper loaded: form_helper
INFO - 2021-07-01 09:13:16 --> Database Driver Class Initialized
INFO - 2021-07-01 09:13:16 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:13:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:13:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:13:16 --> Encryption Class Initialized
INFO - 2021-07-01 09:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:13:16 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:13:16 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:13:16 --> Model "user_model" initialized
INFO - 2021-07-01 09:13:16 --> Model "role_model" initialized
INFO - 2021-07-01 09:13:16 --> Controller Class Initialized
INFO - 2021-07-01 09:13:16 --> Helper loaded: language_helper
INFO - 2021-07-01 09:13:16 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:13:16 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:13:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:13:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:13:16 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:13:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:13:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:13:16 --> Final output sent to browser
DEBUG - 2021-07-01 09:13:16 --> Total execution time: 0.0764
INFO - 2021-07-01 09:13:59 --> Config Class Initialized
INFO - 2021-07-01 09:13:59 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:13:59 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:13:59 --> Utf8 Class Initialized
INFO - 2021-07-01 09:13:59 --> URI Class Initialized
INFO - 2021-07-01 09:13:59 --> Router Class Initialized
INFO - 2021-07-01 09:13:59 --> Output Class Initialized
INFO - 2021-07-01 09:13:59 --> Security Class Initialized
DEBUG - 2021-07-01 09:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:13:59 --> Input Class Initialized
INFO - 2021-07-01 09:13:59 --> Language Class Initialized
INFO - 2021-07-01 09:13:59 --> Loader Class Initialized
INFO - 2021-07-01 09:13:59 --> Helper loaded: html_helper
INFO - 2021-07-01 09:13:59 --> Helper loaded: url_helper
INFO - 2021-07-01 09:13:59 --> Helper loaded: form_helper
INFO - 2021-07-01 09:13:59 --> Database Driver Class Initialized
INFO - 2021-07-01 09:14:00 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:14:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:14:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:14:00 --> Encryption Class Initialized
INFO - 2021-07-01 09:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:14:00 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:14:00 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:14:00 --> Model "user_model" initialized
INFO - 2021-07-01 09:14:00 --> Model "role_model" initialized
INFO - 2021-07-01 09:14:00 --> Controller Class Initialized
INFO - 2021-07-01 09:14:00 --> Helper loaded: language_helper
INFO - 2021-07-01 09:14:00 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:14:00 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:14:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:14:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:14:00 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:14:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:14:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:14:00 --> Final output sent to browser
DEBUG - 2021-07-01 09:14:00 --> Total execution time: 0.1193
INFO - 2021-07-01 09:14:01 --> Config Class Initialized
INFO - 2021-07-01 09:14:01 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:14:01 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:14:01 --> Utf8 Class Initialized
INFO - 2021-07-01 09:14:01 --> URI Class Initialized
INFO - 2021-07-01 09:14:01 --> Router Class Initialized
INFO - 2021-07-01 09:14:01 --> Output Class Initialized
INFO - 2021-07-01 09:14:01 --> Security Class Initialized
DEBUG - 2021-07-01 09:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:14:01 --> Input Class Initialized
INFO - 2021-07-01 09:14:01 --> Language Class Initialized
INFO - 2021-07-01 09:14:01 --> Loader Class Initialized
INFO - 2021-07-01 09:14:01 --> Helper loaded: html_helper
INFO - 2021-07-01 09:14:01 --> Helper loaded: url_helper
INFO - 2021-07-01 09:14:01 --> Helper loaded: form_helper
INFO - 2021-07-01 09:14:01 --> Database Driver Class Initialized
INFO - 2021-07-01 09:14:01 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:14:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:14:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:14:01 --> Encryption Class Initialized
INFO - 2021-07-01 09:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:14:01 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:14:01 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:14:01 --> Model "user_model" initialized
INFO - 2021-07-01 09:14:01 --> Model "role_model" initialized
INFO - 2021-07-01 09:14:01 --> Controller Class Initialized
INFO - 2021-07-01 09:14:01 --> Helper loaded: language_helper
INFO - 2021-07-01 09:14:01 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:14:01 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:14:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:14:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:14:01 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:14:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:14:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:14:01 --> Final output sent to browser
DEBUG - 2021-07-01 09:14:01 --> Total execution time: 0.1015
INFO - 2021-07-01 09:14:49 --> Config Class Initialized
INFO - 2021-07-01 09:14:49 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:14:49 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:14:49 --> Utf8 Class Initialized
INFO - 2021-07-01 09:14:49 --> URI Class Initialized
INFO - 2021-07-01 09:14:49 --> Router Class Initialized
INFO - 2021-07-01 09:14:49 --> Output Class Initialized
INFO - 2021-07-01 09:14:49 --> Security Class Initialized
DEBUG - 2021-07-01 09:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:14:49 --> Input Class Initialized
INFO - 2021-07-01 09:14:49 --> Language Class Initialized
INFO - 2021-07-01 09:14:49 --> Loader Class Initialized
INFO - 2021-07-01 09:14:49 --> Helper loaded: html_helper
INFO - 2021-07-01 09:14:49 --> Helper loaded: url_helper
INFO - 2021-07-01 09:14:49 --> Helper loaded: form_helper
INFO - 2021-07-01 09:14:49 --> Database Driver Class Initialized
INFO - 2021-07-01 09:14:49 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:14:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:14:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:14:49 --> Encryption Class Initialized
INFO - 2021-07-01 09:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:14:49 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:14:49 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:14:49 --> Model "user_model" initialized
INFO - 2021-07-01 09:14:49 --> Model "role_model" initialized
INFO - 2021-07-01 09:14:49 --> Controller Class Initialized
INFO - 2021-07-01 09:14:49 --> Helper loaded: language_helper
INFO - 2021-07-01 09:14:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:14:49 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:14:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:14:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:14:49 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:14:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:14:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:14:49 --> Final output sent to browser
DEBUG - 2021-07-01 09:14:49 --> Total execution time: 0.1108
INFO - 2021-07-01 09:15:03 --> Config Class Initialized
INFO - 2021-07-01 09:15:03 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:15:03 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:15:03 --> Utf8 Class Initialized
INFO - 2021-07-01 09:15:03 --> URI Class Initialized
INFO - 2021-07-01 09:15:03 --> Router Class Initialized
INFO - 2021-07-01 09:15:03 --> Output Class Initialized
INFO - 2021-07-01 09:15:03 --> Security Class Initialized
DEBUG - 2021-07-01 09:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:15:03 --> Input Class Initialized
INFO - 2021-07-01 09:15:03 --> Language Class Initialized
INFO - 2021-07-01 09:15:03 --> Loader Class Initialized
INFO - 2021-07-01 09:15:03 --> Helper loaded: html_helper
INFO - 2021-07-01 09:15:03 --> Helper loaded: url_helper
INFO - 2021-07-01 09:15:03 --> Helper loaded: form_helper
INFO - 2021-07-01 09:15:03 --> Database Driver Class Initialized
INFO - 2021-07-01 09:15:03 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:15:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:15:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:15:03 --> Encryption Class Initialized
INFO - 2021-07-01 09:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:15:03 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:15:03 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:15:03 --> Model "user_model" initialized
INFO - 2021-07-01 09:15:03 --> Model "role_model" initialized
INFO - 2021-07-01 09:15:03 --> Controller Class Initialized
INFO - 2021-07-01 09:15:03 --> Helper loaded: language_helper
INFO - 2021-07-01 09:15:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:15:03 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:15:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:15:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:15:03 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:15:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:15:03 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:15:03 --> Final output sent to browser
DEBUG - 2021-07-01 09:15:03 --> Total execution time: 0.0736
INFO - 2021-07-01 09:15:17 --> Config Class Initialized
INFO - 2021-07-01 09:15:17 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:15:17 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:15:17 --> Utf8 Class Initialized
INFO - 2021-07-01 09:15:17 --> URI Class Initialized
INFO - 2021-07-01 09:15:17 --> Router Class Initialized
INFO - 2021-07-01 09:15:17 --> Output Class Initialized
INFO - 2021-07-01 09:15:17 --> Security Class Initialized
DEBUG - 2021-07-01 09:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:15:17 --> Input Class Initialized
INFO - 2021-07-01 09:15:17 --> Language Class Initialized
INFO - 2021-07-01 09:15:17 --> Loader Class Initialized
INFO - 2021-07-01 09:15:17 --> Helper loaded: html_helper
INFO - 2021-07-01 09:15:17 --> Helper loaded: url_helper
INFO - 2021-07-01 09:15:17 --> Helper loaded: form_helper
INFO - 2021-07-01 09:15:17 --> Database Driver Class Initialized
INFO - 2021-07-01 09:15:17 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:15:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:15:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:15:17 --> Encryption Class Initialized
INFO - 2021-07-01 09:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:15:17 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:15:17 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:15:17 --> Model "user_model" initialized
INFO - 2021-07-01 09:15:17 --> Model "role_model" initialized
INFO - 2021-07-01 09:15:17 --> Controller Class Initialized
INFO - 2021-07-01 09:15:17 --> Helper loaded: language_helper
INFO - 2021-07-01 09:15:17 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:15:17 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:15:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:15:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:15:17 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:15:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:15:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:15:17 --> Final output sent to browser
DEBUG - 2021-07-01 09:15:17 --> Total execution time: 0.1069
INFO - 2021-07-01 09:15:27 --> Config Class Initialized
INFO - 2021-07-01 09:15:27 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:15:27 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:15:27 --> Utf8 Class Initialized
INFO - 2021-07-01 09:15:27 --> URI Class Initialized
INFO - 2021-07-01 09:15:27 --> Router Class Initialized
INFO - 2021-07-01 09:15:27 --> Output Class Initialized
INFO - 2021-07-01 09:15:27 --> Security Class Initialized
DEBUG - 2021-07-01 09:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:15:27 --> Input Class Initialized
INFO - 2021-07-01 09:15:27 --> Language Class Initialized
INFO - 2021-07-01 09:15:27 --> Loader Class Initialized
INFO - 2021-07-01 09:15:27 --> Helper loaded: html_helper
INFO - 2021-07-01 09:15:27 --> Helper loaded: url_helper
INFO - 2021-07-01 09:15:27 --> Helper loaded: form_helper
INFO - 2021-07-01 09:15:27 --> Database Driver Class Initialized
INFO - 2021-07-01 09:15:27 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:15:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:15:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:15:27 --> Encryption Class Initialized
INFO - 2021-07-01 09:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:15:27 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:15:27 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:15:27 --> Model "user_model" initialized
INFO - 2021-07-01 09:15:27 --> Model "role_model" initialized
INFO - 2021-07-01 09:15:27 --> Controller Class Initialized
INFO - 2021-07-01 09:15:27 --> Helper loaded: language_helper
INFO - 2021-07-01 09:15:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:15:27 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:15:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:15:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:15:27 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:15:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:15:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:15:27 --> Final output sent to browser
DEBUG - 2021-07-01 09:15:27 --> Total execution time: 0.0798
INFO - 2021-07-01 09:15:42 --> Config Class Initialized
INFO - 2021-07-01 09:15:42 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:15:42 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:15:42 --> Utf8 Class Initialized
INFO - 2021-07-01 09:15:42 --> URI Class Initialized
INFO - 2021-07-01 09:15:42 --> Router Class Initialized
INFO - 2021-07-01 09:15:42 --> Output Class Initialized
INFO - 2021-07-01 09:15:42 --> Security Class Initialized
DEBUG - 2021-07-01 09:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:15:42 --> Input Class Initialized
INFO - 2021-07-01 09:15:42 --> Language Class Initialized
INFO - 2021-07-01 09:15:42 --> Loader Class Initialized
INFO - 2021-07-01 09:15:42 --> Helper loaded: html_helper
INFO - 2021-07-01 09:15:42 --> Helper loaded: url_helper
INFO - 2021-07-01 09:15:42 --> Helper loaded: form_helper
INFO - 2021-07-01 09:15:42 --> Database Driver Class Initialized
INFO - 2021-07-01 09:15:42 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:15:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:15:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:15:42 --> Encryption Class Initialized
INFO - 2021-07-01 09:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:15:42 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:15:42 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:15:42 --> Model "user_model" initialized
INFO - 2021-07-01 09:15:42 --> Model "role_model" initialized
INFO - 2021-07-01 09:15:42 --> Controller Class Initialized
INFO - 2021-07-01 09:15:42 --> Helper loaded: language_helper
INFO - 2021-07-01 09:15:42 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:15:42 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:15:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:15:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:15:42 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:15:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:15:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:15:42 --> Final output sent to browser
DEBUG - 2021-07-01 09:15:42 --> Total execution time: 0.1066
INFO - 2021-07-01 09:15:59 --> Config Class Initialized
INFO - 2021-07-01 09:15:59 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:15:59 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:15:59 --> Utf8 Class Initialized
INFO - 2021-07-01 09:15:59 --> URI Class Initialized
INFO - 2021-07-01 09:15:59 --> Router Class Initialized
INFO - 2021-07-01 09:15:59 --> Output Class Initialized
INFO - 2021-07-01 09:15:59 --> Security Class Initialized
DEBUG - 2021-07-01 09:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:15:59 --> Input Class Initialized
INFO - 2021-07-01 09:15:59 --> Language Class Initialized
INFO - 2021-07-01 09:15:59 --> Loader Class Initialized
INFO - 2021-07-01 09:15:59 --> Helper loaded: html_helper
INFO - 2021-07-01 09:15:59 --> Helper loaded: url_helper
INFO - 2021-07-01 09:15:59 --> Helper loaded: form_helper
INFO - 2021-07-01 09:15:59 --> Database Driver Class Initialized
INFO - 2021-07-01 09:15:59 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:15:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:15:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:15:59 --> Encryption Class Initialized
INFO - 2021-07-01 09:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:15:59 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:15:59 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:15:59 --> Model "user_model" initialized
INFO - 2021-07-01 09:15:59 --> Model "role_model" initialized
INFO - 2021-07-01 09:15:59 --> Controller Class Initialized
INFO - 2021-07-01 09:15:59 --> Helper loaded: language_helper
INFO - 2021-07-01 09:15:59 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:15:59 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:15:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:15:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:15:59 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:15:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:15:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:15:59 --> Final output sent to browser
DEBUG - 2021-07-01 09:15:59 --> Total execution time: 0.1097
INFO - 2021-07-01 09:16:25 --> Config Class Initialized
INFO - 2021-07-01 09:16:25 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:16:25 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:16:25 --> Utf8 Class Initialized
INFO - 2021-07-01 09:16:25 --> URI Class Initialized
INFO - 2021-07-01 09:16:25 --> Router Class Initialized
INFO - 2021-07-01 09:16:25 --> Output Class Initialized
INFO - 2021-07-01 09:16:25 --> Security Class Initialized
DEBUG - 2021-07-01 09:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:16:25 --> Input Class Initialized
INFO - 2021-07-01 09:16:25 --> Language Class Initialized
INFO - 2021-07-01 09:16:25 --> Loader Class Initialized
INFO - 2021-07-01 09:16:25 --> Helper loaded: html_helper
INFO - 2021-07-01 09:16:25 --> Helper loaded: url_helper
INFO - 2021-07-01 09:16:25 --> Helper loaded: form_helper
INFO - 2021-07-01 09:16:25 --> Database Driver Class Initialized
INFO - 2021-07-01 09:16:25 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:16:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:16:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:16:25 --> Encryption Class Initialized
INFO - 2021-07-01 09:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:16:25 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:16:25 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:16:25 --> Model "user_model" initialized
INFO - 2021-07-01 09:16:25 --> Model "role_model" initialized
INFO - 2021-07-01 09:16:25 --> Controller Class Initialized
INFO - 2021-07-01 09:16:25 --> Helper loaded: language_helper
INFO - 2021-07-01 09:16:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:16:25 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:16:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:16:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:16:25 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:16:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:16:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:16:25 --> Final output sent to browser
DEBUG - 2021-07-01 09:16:25 --> Total execution time: 0.1112
INFO - 2021-07-01 09:17:15 --> Config Class Initialized
INFO - 2021-07-01 09:17:15 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:17:15 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:17:15 --> Utf8 Class Initialized
INFO - 2021-07-01 09:17:15 --> URI Class Initialized
INFO - 2021-07-01 09:17:15 --> Router Class Initialized
INFO - 2021-07-01 09:17:15 --> Output Class Initialized
INFO - 2021-07-01 09:17:15 --> Security Class Initialized
DEBUG - 2021-07-01 09:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:17:15 --> Input Class Initialized
INFO - 2021-07-01 09:17:15 --> Language Class Initialized
INFO - 2021-07-01 09:17:15 --> Loader Class Initialized
INFO - 2021-07-01 09:17:15 --> Helper loaded: html_helper
INFO - 2021-07-01 09:17:15 --> Helper loaded: url_helper
INFO - 2021-07-01 09:17:15 --> Helper loaded: form_helper
INFO - 2021-07-01 09:17:15 --> Database Driver Class Initialized
INFO - 2021-07-01 09:17:15 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:17:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:17:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:17:15 --> Encryption Class Initialized
INFO - 2021-07-01 09:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:17:15 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:17:15 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:17:15 --> Model "user_model" initialized
INFO - 2021-07-01 09:17:15 --> Model "role_model" initialized
INFO - 2021-07-01 09:17:15 --> Controller Class Initialized
INFO - 2021-07-01 09:17:15 --> Helper loaded: language_helper
INFO - 2021-07-01 09:17:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:17:15 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:17:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:17:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:17:15 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:17:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:17:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:17:15 --> Final output sent to browser
DEBUG - 2021-07-01 09:17:15 --> Total execution time: 0.1119
INFO - 2021-07-01 09:20:29 --> Config Class Initialized
INFO - 2021-07-01 09:20:29 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:20:29 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:20:29 --> Utf8 Class Initialized
INFO - 2021-07-01 09:20:29 --> URI Class Initialized
INFO - 2021-07-01 09:20:29 --> Router Class Initialized
INFO - 2021-07-01 09:20:29 --> Output Class Initialized
INFO - 2021-07-01 09:20:29 --> Security Class Initialized
DEBUG - 2021-07-01 09:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:20:29 --> Input Class Initialized
INFO - 2021-07-01 09:20:29 --> Language Class Initialized
INFO - 2021-07-01 09:20:29 --> Loader Class Initialized
INFO - 2021-07-01 09:20:29 --> Helper loaded: html_helper
INFO - 2021-07-01 09:20:29 --> Helper loaded: url_helper
INFO - 2021-07-01 09:20:29 --> Helper loaded: form_helper
INFO - 2021-07-01 09:20:29 --> Database Driver Class Initialized
INFO - 2021-07-01 09:20:29 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:20:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:20:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:20:29 --> Encryption Class Initialized
INFO - 2021-07-01 09:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:20:29 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:20:29 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:20:29 --> Model "user_model" initialized
INFO - 2021-07-01 09:20:29 --> Model "role_model" initialized
INFO - 2021-07-01 09:20:29 --> Controller Class Initialized
INFO - 2021-07-01 09:20:29 --> Helper loaded: language_helper
INFO - 2021-07-01 09:20:29 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:20:29 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:20:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:20:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:20:29 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:20:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:20:29 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:20:29 --> Final output sent to browser
DEBUG - 2021-07-01 09:20:29 --> Total execution time: 0.1213
INFO - 2021-07-01 09:26:24 --> Config Class Initialized
INFO - 2021-07-01 09:26:24 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:26:24 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:26:24 --> Utf8 Class Initialized
INFO - 2021-07-01 09:26:24 --> URI Class Initialized
INFO - 2021-07-01 09:26:24 --> Router Class Initialized
INFO - 2021-07-01 09:26:24 --> Output Class Initialized
INFO - 2021-07-01 09:26:24 --> Security Class Initialized
DEBUG - 2021-07-01 09:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:26:24 --> Input Class Initialized
INFO - 2021-07-01 09:26:24 --> Language Class Initialized
INFO - 2021-07-01 09:26:24 --> Loader Class Initialized
INFO - 2021-07-01 09:26:24 --> Helper loaded: html_helper
INFO - 2021-07-01 09:26:24 --> Helper loaded: url_helper
INFO - 2021-07-01 09:26:24 --> Helper loaded: form_helper
INFO - 2021-07-01 09:26:24 --> Database Driver Class Initialized
INFO - 2021-07-01 09:26:24 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:26:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:26:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:26:24 --> Encryption Class Initialized
INFO - 2021-07-01 09:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:26:24 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:26:24 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:26:24 --> Model "user_model" initialized
INFO - 2021-07-01 09:26:24 --> Model "role_model" initialized
INFO - 2021-07-01 09:26:24 --> Controller Class Initialized
INFO - 2021-07-01 09:26:24 --> Helper loaded: language_helper
INFO - 2021-07-01 09:26:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:26:24 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:26:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:26:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:26:24 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:26:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:26:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:26:24 --> Final output sent to browser
DEBUG - 2021-07-01 09:26:24 --> Total execution time: 0.1085
INFO - 2021-07-01 09:28:04 --> Config Class Initialized
INFO - 2021-07-01 09:28:04 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:28:04 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:28:04 --> Utf8 Class Initialized
INFO - 2021-07-01 09:28:04 --> URI Class Initialized
INFO - 2021-07-01 09:28:04 --> Router Class Initialized
INFO - 2021-07-01 09:28:04 --> Output Class Initialized
INFO - 2021-07-01 09:28:04 --> Security Class Initialized
DEBUG - 2021-07-01 09:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:28:04 --> Input Class Initialized
INFO - 2021-07-01 09:28:04 --> Language Class Initialized
INFO - 2021-07-01 09:28:04 --> Loader Class Initialized
INFO - 2021-07-01 09:28:04 --> Helper loaded: html_helper
INFO - 2021-07-01 09:28:04 --> Helper loaded: url_helper
INFO - 2021-07-01 09:28:04 --> Helper loaded: form_helper
INFO - 2021-07-01 09:28:04 --> Database Driver Class Initialized
INFO - 2021-07-01 09:28:04 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:28:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:28:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:28:04 --> Encryption Class Initialized
INFO - 2021-07-01 09:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:28:04 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:28:04 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:28:04 --> Model "user_model" initialized
INFO - 2021-07-01 09:28:04 --> Model "role_model" initialized
INFO - 2021-07-01 09:28:04 --> Controller Class Initialized
INFO - 2021-07-01 09:28:04 --> Helper loaded: language_helper
INFO - 2021-07-01 09:28:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:28:04 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:28:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:28:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:28:04 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:28:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:28:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:28:04 --> Final output sent to browser
DEBUG - 2021-07-01 09:28:04 --> Total execution time: 0.1058
INFO - 2021-07-01 09:28:47 --> Config Class Initialized
INFO - 2021-07-01 09:28:47 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:28:47 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:28:47 --> Utf8 Class Initialized
INFO - 2021-07-01 09:28:47 --> URI Class Initialized
INFO - 2021-07-01 09:28:47 --> Router Class Initialized
INFO - 2021-07-01 09:28:47 --> Output Class Initialized
INFO - 2021-07-01 09:28:47 --> Security Class Initialized
DEBUG - 2021-07-01 09:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:28:47 --> Input Class Initialized
INFO - 2021-07-01 09:28:47 --> Language Class Initialized
INFO - 2021-07-01 09:28:47 --> Loader Class Initialized
INFO - 2021-07-01 09:28:47 --> Helper loaded: html_helper
INFO - 2021-07-01 09:28:47 --> Helper loaded: url_helper
INFO - 2021-07-01 09:28:47 --> Helper loaded: form_helper
INFO - 2021-07-01 09:28:47 --> Database Driver Class Initialized
INFO - 2021-07-01 09:28:47 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:28:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:28:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:28:47 --> Encryption Class Initialized
INFO - 2021-07-01 09:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:28:47 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:28:47 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:28:47 --> Model "user_model" initialized
INFO - 2021-07-01 09:28:47 --> Model "role_model" initialized
INFO - 2021-07-01 09:28:47 --> Controller Class Initialized
INFO - 2021-07-01 09:28:47 --> Helper loaded: language_helper
INFO - 2021-07-01 09:28:47 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:28:47 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:28:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:28:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:28:47 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:28:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:28:47 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:28:47 --> Final output sent to browser
DEBUG - 2021-07-01 09:28:47 --> Total execution time: 0.1130
INFO - 2021-07-01 09:29:18 --> Config Class Initialized
INFO - 2021-07-01 09:29:18 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:29:18 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:29:18 --> Utf8 Class Initialized
INFO - 2021-07-01 09:29:18 --> URI Class Initialized
INFO - 2021-07-01 09:29:18 --> Router Class Initialized
INFO - 2021-07-01 09:29:18 --> Output Class Initialized
INFO - 2021-07-01 09:29:18 --> Security Class Initialized
DEBUG - 2021-07-01 09:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:29:18 --> Input Class Initialized
INFO - 2021-07-01 09:29:18 --> Language Class Initialized
INFO - 2021-07-01 09:29:18 --> Loader Class Initialized
INFO - 2021-07-01 09:29:18 --> Helper loaded: html_helper
INFO - 2021-07-01 09:29:18 --> Helper loaded: url_helper
INFO - 2021-07-01 09:29:18 --> Helper loaded: form_helper
INFO - 2021-07-01 09:29:18 --> Database Driver Class Initialized
INFO - 2021-07-01 09:29:18 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:29:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:29:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:29:18 --> Encryption Class Initialized
INFO - 2021-07-01 09:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:29:18 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:29:18 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:29:18 --> Model "user_model" initialized
INFO - 2021-07-01 09:29:18 --> Model "role_model" initialized
INFO - 2021-07-01 09:29:18 --> Controller Class Initialized
INFO - 2021-07-01 09:29:18 --> Helper loaded: language_helper
INFO - 2021-07-01 09:29:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:29:18 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:29:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:29:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:29:19 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:29:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:29:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:29:19 --> Final output sent to browser
DEBUG - 2021-07-01 09:29:19 --> Total execution time: 0.1198
INFO - 2021-07-01 09:29:20 --> Config Class Initialized
INFO - 2021-07-01 09:29:20 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:29:20 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:29:20 --> Utf8 Class Initialized
INFO - 2021-07-01 09:29:20 --> URI Class Initialized
INFO - 2021-07-01 09:29:20 --> Router Class Initialized
INFO - 2021-07-01 09:29:20 --> Output Class Initialized
INFO - 2021-07-01 09:29:20 --> Security Class Initialized
DEBUG - 2021-07-01 09:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:29:20 --> Input Class Initialized
INFO - 2021-07-01 09:29:20 --> Language Class Initialized
INFO - 2021-07-01 09:29:20 --> Loader Class Initialized
INFO - 2021-07-01 09:29:20 --> Helper loaded: html_helper
INFO - 2021-07-01 09:29:20 --> Helper loaded: url_helper
INFO - 2021-07-01 09:29:20 --> Helper loaded: form_helper
INFO - 2021-07-01 09:29:20 --> Database Driver Class Initialized
INFO - 2021-07-01 09:29:20 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:29:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:29:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:29:20 --> Encryption Class Initialized
INFO - 2021-07-01 09:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:29:20 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:29:20 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:29:20 --> Model "user_model" initialized
INFO - 2021-07-01 09:29:20 --> Model "role_model" initialized
INFO - 2021-07-01 09:29:20 --> Controller Class Initialized
INFO - 2021-07-01 09:29:20 --> Helper loaded: language_helper
INFO - 2021-07-01 09:29:20 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:29:20 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:29:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:29:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:29:20 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:29:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:29:20 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:29:20 --> Final output sent to browser
DEBUG - 2021-07-01 09:29:20 --> Total execution time: 0.0761
INFO - 2021-07-01 09:35:34 --> Config Class Initialized
INFO - 2021-07-01 09:35:34 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:35:34 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:35:34 --> Utf8 Class Initialized
INFO - 2021-07-01 09:35:34 --> URI Class Initialized
INFO - 2021-07-01 09:35:34 --> Router Class Initialized
INFO - 2021-07-01 09:35:34 --> Output Class Initialized
INFO - 2021-07-01 09:35:34 --> Security Class Initialized
DEBUG - 2021-07-01 09:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:35:34 --> Input Class Initialized
INFO - 2021-07-01 09:35:34 --> Language Class Initialized
INFO - 2021-07-01 09:35:34 --> Loader Class Initialized
INFO - 2021-07-01 09:35:34 --> Helper loaded: html_helper
INFO - 2021-07-01 09:35:34 --> Helper loaded: url_helper
INFO - 2021-07-01 09:35:34 --> Helper loaded: form_helper
INFO - 2021-07-01 09:35:34 --> Database Driver Class Initialized
INFO - 2021-07-01 09:35:34 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:35:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:35:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:35:34 --> Encryption Class Initialized
INFO - 2021-07-01 09:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:35:34 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:35:34 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:35:34 --> Model "user_model" initialized
INFO - 2021-07-01 09:35:34 --> Model "role_model" initialized
INFO - 2021-07-01 09:35:34 --> Controller Class Initialized
INFO - 2021-07-01 09:35:34 --> Helper loaded: language_helper
INFO - 2021-07-01 09:35:34 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:35:34 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:35:34 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:35:34 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:35:34 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:35:34 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:35:34 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:35:34 --> Final output sent to browser
DEBUG - 2021-07-01 09:35:34 --> Total execution time: 0.0844
INFO - 2021-07-01 09:38:28 --> Config Class Initialized
INFO - 2021-07-01 09:38:28 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:38:28 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:38:28 --> Utf8 Class Initialized
INFO - 2021-07-01 09:38:28 --> URI Class Initialized
INFO - 2021-07-01 09:38:28 --> Router Class Initialized
INFO - 2021-07-01 09:38:28 --> Output Class Initialized
INFO - 2021-07-01 09:38:28 --> Security Class Initialized
DEBUG - 2021-07-01 09:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:38:28 --> Input Class Initialized
INFO - 2021-07-01 09:38:28 --> Language Class Initialized
INFO - 2021-07-01 09:38:28 --> Loader Class Initialized
INFO - 2021-07-01 09:38:28 --> Helper loaded: html_helper
INFO - 2021-07-01 09:38:28 --> Helper loaded: url_helper
INFO - 2021-07-01 09:38:28 --> Helper loaded: form_helper
INFO - 2021-07-01 09:38:28 --> Database Driver Class Initialized
INFO - 2021-07-01 09:38:28 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:38:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:38:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:38:28 --> Encryption Class Initialized
INFO - 2021-07-01 09:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:38:28 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:38:28 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:38:28 --> Model "user_model" initialized
INFO - 2021-07-01 09:38:28 --> Model "role_model" initialized
INFO - 2021-07-01 09:38:28 --> Controller Class Initialized
INFO - 2021-07-01 09:38:28 --> Helper loaded: language_helper
INFO - 2021-07-01 09:38:28 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:38:28 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:38:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:38:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:38:28 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:38:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:38:28 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:38:28 --> Final output sent to browser
DEBUG - 2021-07-01 09:38:28 --> Total execution time: 0.1187
INFO - 2021-07-01 09:38:52 --> Config Class Initialized
INFO - 2021-07-01 09:38:52 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:38:52 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:38:52 --> Utf8 Class Initialized
INFO - 2021-07-01 09:38:52 --> URI Class Initialized
INFO - 2021-07-01 09:38:52 --> Router Class Initialized
INFO - 2021-07-01 09:38:52 --> Output Class Initialized
INFO - 2021-07-01 09:38:52 --> Security Class Initialized
DEBUG - 2021-07-01 09:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:38:52 --> Input Class Initialized
INFO - 2021-07-01 09:38:52 --> Language Class Initialized
INFO - 2021-07-01 09:38:52 --> Loader Class Initialized
INFO - 2021-07-01 09:38:52 --> Helper loaded: html_helper
INFO - 2021-07-01 09:38:52 --> Helper loaded: url_helper
INFO - 2021-07-01 09:38:52 --> Helper loaded: form_helper
INFO - 2021-07-01 09:38:52 --> Database Driver Class Initialized
INFO - 2021-07-01 09:38:52 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:38:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:38:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:38:52 --> Encryption Class Initialized
INFO - 2021-07-01 09:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:38:52 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:38:52 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:38:52 --> Model "user_model" initialized
INFO - 2021-07-01 09:38:52 --> Model "role_model" initialized
INFO - 2021-07-01 09:38:52 --> Controller Class Initialized
INFO - 2021-07-01 09:38:52 --> Helper loaded: language_helper
INFO - 2021-07-01 09:38:52 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:38:52 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:38:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:38:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:38:52 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:38:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:38:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:38:52 --> Final output sent to browser
DEBUG - 2021-07-01 09:38:52 --> Total execution time: 0.0701
INFO - 2021-07-01 09:45:04 --> Config Class Initialized
INFO - 2021-07-01 09:45:04 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:45:04 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:45:04 --> Utf8 Class Initialized
INFO - 2021-07-01 09:45:04 --> URI Class Initialized
INFO - 2021-07-01 09:45:04 --> Router Class Initialized
INFO - 2021-07-01 09:45:04 --> Output Class Initialized
INFO - 2021-07-01 09:45:04 --> Security Class Initialized
DEBUG - 2021-07-01 09:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:45:04 --> Input Class Initialized
INFO - 2021-07-01 09:45:04 --> Language Class Initialized
INFO - 2021-07-01 09:45:04 --> Loader Class Initialized
INFO - 2021-07-01 09:45:04 --> Helper loaded: html_helper
INFO - 2021-07-01 09:45:04 --> Helper loaded: url_helper
INFO - 2021-07-01 09:45:04 --> Helper loaded: form_helper
INFO - 2021-07-01 09:45:04 --> Database Driver Class Initialized
INFO - 2021-07-01 09:45:04 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:45:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:45:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:45:04 --> Encryption Class Initialized
INFO - 2021-07-01 09:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:45:04 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:45:04 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:45:04 --> Model "user_model" initialized
INFO - 2021-07-01 09:45:04 --> Model "role_model" initialized
INFO - 2021-07-01 09:45:04 --> Controller Class Initialized
INFO - 2021-07-01 09:45:04 --> Helper loaded: language_helper
INFO - 2021-07-01 09:45:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:45:04 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:45:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:45:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:45:05 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:45:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:45:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:45:05 --> Final output sent to browser
DEBUG - 2021-07-01 09:45:05 --> Total execution time: 0.1308
INFO - 2021-07-01 09:45:44 --> Config Class Initialized
INFO - 2021-07-01 09:45:44 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:45:44 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:45:44 --> Utf8 Class Initialized
INFO - 2021-07-01 09:45:44 --> URI Class Initialized
INFO - 2021-07-01 09:45:44 --> Router Class Initialized
INFO - 2021-07-01 09:45:44 --> Output Class Initialized
INFO - 2021-07-01 09:45:44 --> Security Class Initialized
DEBUG - 2021-07-01 09:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:45:44 --> Input Class Initialized
INFO - 2021-07-01 09:45:44 --> Language Class Initialized
INFO - 2021-07-01 09:45:44 --> Loader Class Initialized
INFO - 2021-07-01 09:45:44 --> Helper loaded: html_helper
INFO - 2021-07-01 09:45:44 --> Helper loaded: url_helper
INFO - 2021-07-01 09:45:44 --> Helper loaded: form_helper
INFO - 2021-07-01 09:45:44 --> Database Driver Class Initialized
INFO - 2021-07-01 09:45:44 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:45:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:45:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:45:44 --> Encryption Class Initialized
INFO - 2021-07-01 09:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:45:44 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:45:44 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:45:44 --> Model "user_model" initialized
INFO - 2021-07-01 09:45:44 --> Model "role_model" initialized
INFO - 2021-07-01 09:45:44 --> Controller Class Initialized
INFO - 2021-07-01 09:45:44 --> Helper loaded: language_helper
INFO - 2021-07-01 09:45:44 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:45:44 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:45:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:45:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:45:44 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:45:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:45:44 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:45:44 --> Final output sent to browser
DEBUG - 2021-07-01 09:45:44 --> Total execution time: 0.1063
INFO - 2021-07-01 09:49:49 --> Config Class Initialized
INFO - 2021-07-01 09:49:49 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:49:49 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:49:49 --> Utf8 Class Initialized
INFO - 2021-07-01 09:49:49 --> URI Class Initialized
INFO - 2021-07-01 09:49:49 --> Router Class Initialized
INFO - 2021-07-01 09:49:49 --> Output Class Initialized
INFO - 2021-07-01 09:49:49 --> Security Class Initialized
DEBUG - 2021-07-01 09:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:49:49 --> Input Class Initialized
INFO - 2021-07-01 09:49:49 --> Language Class Initialized
INFO - 2021-07-01 09:49:49 --> Loader Class Initialized
INFO - 2021-07-01 09:49:49 --> Helper loaded: html_helper
INFO - 2021-07-01 09:49:49 --> Helper loaded: url_helper
INFO - 2021-07-01 09:49:49 --> Helper loaded: form_helper
INFO - 2021-07-01 09:49:49 --> Database Driver Class Initialized
INFO - 2021-07-01 09:49:49 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:49:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:49:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:49:49 --> Encryption Class Initialized
INFO - 2021-07-01 09:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:49:49 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:49:49 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:49:49 --> Model "user_model" initialized
INFO - 2021-07-01 09:49:49 --> Model "role_model" initialized
INFO - 2021-07-01 09:49:49 --> Controller Class Initialized
INFO - 2021-07-01 09:49:49 --> Helper loaded: language_helper
INFO - 2021-07-01 09:49:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:49:49 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:49:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:49:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:49:49 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:49:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:49:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:49:49 --> Final output sent to browser
DEBUG - 2021-07-01 09:49:49 --> Total execution time: 0.1159
INFO - 2021-07-01 09:49:52 --> Config Class Initialized
INFO - 2021-07-01 09:49:52 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:49:52 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:49:52 --> Utf8 Class Initialized
INFO - 2021-07-01 09:49:52 --> URI Class Initialized
INFO - 2021-07-01 09:49:52 --> Router Class Initialized
INFO - 2021-07-01 09:49:52 --> Output Class Initialized
INFO - 2021-07-01 09:49:52 --> Security Class Initialized
DEBUG - 2021-07-01 09:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:49:52 --> Input Class Initialized
INFO - 2021-07-01 09:49:52 --> Language Class Initialized
INFO - 2021-07-01 09:49:52 --> Loader Class Initialized
INFO - 2021-07-01 09:49:52 --> Helper loaded: html_helper
INFO - 2021-07-01 09:49:52 --> Helper loaded: url_helper
INFO - 2021-07-01 09:49:52 --> Helper loaded: form_helper
INFO - 2021-07-01 09:49:52 --> Database Driver Class Initialized
INFO - 2021-07-01 09:49:52 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:49:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:49:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:49:52 --> Encryption Class Initialized
INFO - 2021-07-01 09:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:49:52 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:49:52 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:49:52 --> Model "user_model" initialized
INFO - 2021-07-01 09:49:52 --> Model "role_model" initialized
INFO - 2021-07-01 09:49:52 --> Controller Class Initialized
INFO - 2021-07-01 09:49:52 --> Helper loaded: language_helper
INFO - 2021-07-01 09:49:52 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:49:52 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:49:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:49:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:49:52 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:49:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:49:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:49:52 --> Final output sent to browser
DEBUG - 2021-07-01 09:49:52 --> Total execution time: 0.0759
INFO - 2021-07-01 09:49:55 --> Config Class Initialized
INFO - 2021-07-01 09:49:55 --> Hooks Class Initialized
INFO - 2021-07-01 09:49:55 --> Config Class Initialized
INFO - 2021-07-01 09:49:55 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:49:55 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:49:55 --> Utf8 Class Initialized
DEBUG - 2021-07-01 09:49:55 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:49:55 --> Utf8 Class Initialized
INFO - 2021-07-01 09:49:55 --> URI Class Initialized
INFO - 2021-07-01 09:49:55 --> URI Class Initialized
INFO - 2021-07-01 09:49:55 --> Router Class Initialized
INFO - 2021-07-01 09:49:55 --> Output Class Initialized
INFO - 2021-07-01 09:49:55 --> Security Class Initialized
DEBUG - 2021-07-01 09:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:49:55 --> Input Class Initialized
INFO - 2021-07-01 09:49:55 --> Language Class Initialized
INFO - 2021-07-01 09:49:55 --> Router Class Initialized
INFO - 2021-07-01 09:49:55 --> Loader Class Initialized
INFO - 2021-07-01 09:49:55 --> Helper loaded: html_helper
INFO - 2021-07-01 09:49:55 --> Helper loaded: url_helper
INFO - 2021-07-01 09:49:55 --> Helper loaded: form_helper
INFO - 2021-07-01 09:49:55 --> Output Class Initialized
INFO - 2021-07-01 09:49:55 --> Database Driver Class Initialized
INFO - 2021-07-01 09:49:55 --> Security Class Initialized
DEBUG - 2021-07-01 09:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:49:55 --> Input Class Initialized
INFO - 2021-07-01 09:49:55 --> Language Class Initialized
INFO - 2021-07-01 09:49:55 --> Loader Class Initialized
INFO - 2021-07-01 09:49:55 --> Helper loaded: html_helper
INFO - 2021-07-01 09:49:55 --> Helper loaded: url_helper
INFO - 2021-07-01 09:49:55 --> Helper loaded: form_helper
INFO - 2021-07-01 09:49:55 --> Database Driver Class Initialized
INFO - 2021-07-01 09:49:55 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:49:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:49:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:49:55 --> Encryption Class Initialized
INFO - 2021-07-01 09:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:49:55 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:49:55 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:49:55 --> Model "user_model" initialized
INFO - 2021-07-01 09:49:55 --> Model "role_model" initialized
INFO - 2021-07-01 09:49:55 --> Controller Class Initialized
INFO - 2021-07-01 09:49:55 --> Form Validation Class Initialized
INFO - 2021-07-01 09:49:55 --> Helper loaded: language_helper
INFO - 2021-07-01 09:49:55 --> Language file loaded: language/english/content_lang.php
DEBUG - 2021-07-01 09:49:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:49:55 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:49:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:49:55 --> Encryption Class Initialized
INFO - 2021-07-01 09:49:55 --> Final output sent to browser
DEBUG - 2021-07-01 09:49:55 --> Total execution time: 0.0704
INFO - 2021-07-01 09:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:49:55 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:49:55 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:49:55 --> Model "user_model" initialized
INFO - 2021-07-01 09:49:55 --> Model "role_model" initialized
INFO - 2021-07-01 09:49:55 --> Controller Class Initialized
INFO - 2021-07-01 09:49:55 --> Helper loaded: language_helper
INFO - 2021-07-01 09:49:55 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:49:55 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:49:55 --> Final output sent to browser
DEBUG - 2021-07-01 09:49:55 --> Total execution time: 0.0797
INFO - 2021-07-01 09:50:40 --> Config Class Initialized
INFO - 2021-07-01 09:50:40 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:50:40 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:50:40 --> Utf8 Class Initialized
INFO - 2021-07-01 09:50:40 --> URI Class Initialized
INFO - 2021-07-01 09:50:40 --> Router Class Initialized
INFO - 2021-07-01 09:50:40 --> Output Class Initialized
INFO - 2021-07-01 09:50:40 --> Security Class Initialized
DEBUG - 2021-07-01 09:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:50:40 --> Input Class Initialized
INFO - 2021-07-01 09:50:40 --> Language Class Initialized
INFO - 2021-07-01 09:50:40 --> Loader Class Initialized
INFO - 2021-07-01 09:50:40 --> Helper loaded: html_helper
INFO - 2021-07-01 09:50:40 --> Helper loaded: url_helper
INFO - 2021-07-01 09:50:40 --> Helper loaded: form_helper
INFO - 2021-07-01 09:50:40 --> Database Driver Class Initialized
INFO - 2021-07-01 09:50:40 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:50:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:50:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:50:40 --> Encryption Class Initialized
INFO - 2021-07-01 09:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:50:40 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:50:40 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:50:40 --> Model "user_model" initialized
INFO - 2021-07-01 09:50:40 --> Model "role_model" initialized
INFO - 2021-07-01 09:50:40 --> Controller Class Initialized
INFO - 2021-07-01 09:50:40 --> Helper loaded: language_helper
INFO - 2021-07-01 09:50:40 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:50:40 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:50:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:50:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:50:40 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:50:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:50:40 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:50:40 --> Final output sent to browser
DEBUG - 2021-07-01 09:50:40 --> Total execution time: 0.1127
INFO - 2021-07-01 09:51:53 --> Config Class Initialized
INFO - 2021-07-01 09:51:53 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:51:53 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:51:53 --> Utf8 Class Initialized
INFO - 2021-07-01 09:51:53 --> URI Class Initialized
INFO - 2021-07-01 09:51:53 --> Router Class Initialized
INFO - 2021-07-01 09:51:53 --> Output Class Initialized
INFO - 2021-07-01 09:51:53 --> Security Class Initialized
DEBUG - 2021-07-01 09:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:51:53 --> Input Class Initialized
INFO - 2021-07-01 09:51:53 --> Language Class Initialized
INFO - 2021-07-01 09:51:53 --> Loader Class Initialized
INFO - 2021-07-01 09:51:53 --> Helper loaded: html_helper
INFO - 2021-07-01 09:51:53 --> Helper loaded: url_helper
INFO - 2021-07-01 09:51:53 --> Helper loaded: form_helper
INFO - 2021-07-01 09:51:53 --> Database Driver Class Initialized
INFO - 2021-07-01 09:51:53 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:51:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:51:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:51:53 --> Encryption Class Initialized
INFO - 2021-07-01 09:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:51:53 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:51:53 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:51:53 --> Model "user_model" initialized
INFO - 2021-07-01 09:51:53 --> Model "role_model" initialized
INFO - 2021-07-01 09:51:53 --> Controller Class Initialized
INFO - 2021-07-01 09:51:53 --> Helper loaded: language_helper
INFO - 2021-07-01 09:51:53 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:51:53 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:51:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:51:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:51:53 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:51:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:51:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:51:53 --> Final output sent to browser
DEBUG - 2021-07-01 09:51:53 --> Total execution time: 0.1111
INFO - 2021-07-01 09:51:56 --> Config Class Initialized
INFO - 2021-07-01 09:51:56 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:51:56 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:51:56 --> Utf8 Class Initialized
INFO - 2021-07-01 09:51:56 --> URI Class Initialized
INFO - 2021-07-01 09:51:56 --> Router Class Initialized
INFO - 2021-07-01 09:51:56 --> Output Class Initialized
INFO - 2021-07-01 09:51:56 --> Security Class Initialized
DEBUG - 2021-07-01 09:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:51:56 --> Input Class Initialized
INFO - 2021-07-01 09:51:56 --> Language Class Initialized
INFO - 2021-07-01 09:51:56 --> Loader Class Initialized
INFO - 2021-07-01 09:51:56 --> Helper loaded: html_helper
INFO - 2021-07-01 09:51:56 --> Helper loaded: url_helper
INFO - 2021-07-01 09:51:56 --> Helper loaded: form_helper
INFO - 2021-07-01 09:51:56 --> Database Driver Class Initialized
INFO - 2021-07-01 09:51:56 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:51:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:51:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:51:56 --> Encryption Class Initialized
INFO - 2021-07-01 09:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:51:56 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:51:56 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:51:56 --> Model "user_model" initialized
INFO - 2021-07-01 09:51:56 --> Model "role_model" initialized
INFO - 2021-07-01 09:51:56 --> Controller Class Initialized
INFO - 2021-07-01 09:51:56 --> Helper loaded: language_helper
INFO - 2021-07-01 09:51:56 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:51:56 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:51:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:51:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:51:56 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:51:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:51:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:51:56 --> Final output sent to browser
DEBUG - 2021-07-01 09:51:56 --> Total execution time: 0.0833
INFO - 2021-07-01 09:51:57 --> Config Class Initialized
INFO - 2021-07-01 09:51:57 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:51:57 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:51:57 --> Utf8 Class Initialized
INFO - 2021-07-01 09:51:57 --> URI Class Initialized
INFO - 2021-07-01 09:51:57 --> Router Class Initialized
INFO - 2021-07-01 09:51:57 --> Output Class Initialized
INFO - 2021-07-01 09:51:57 --> Security Class Initialized
DEBUG - 2021-07-01 09:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:51:57 --> Input Class Initialized
INFO - 2021-07-01 09:51:57 --> Language Class Initialized
INFO - 2021-07-01 09:51:57 --> Loader Class Initialized
INFO - 2021-07-01 09:51:57 --> Helper loaded: html_helper
INFO - 2021-07-01 09:51:57 --> Helper loaded: url_helper
INFO - 2021-07-01 09:51:57 --> Helper loaded: form_helper
INFO - 2021-07-01 09:51:57 --> Database Driver Class Initialized
INFO - 2021-07-01 09:51:57 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:51:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:51:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:51:57 --> Encryption Class Initialized
INFO - 2021-07-01 09:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:51:57 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:51:57 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:51:57 --> Model "user_model" initialized
INFO - 2021-07-01 09:51:57 --> Model "role_model" initialized
INFO - 2021-07-01 09:51:57 --> Controller Class Initialized
INFO - 2021-07-01 09:51:57 --> Helper loaded: language_helper
INFO - 2021-07-01 09:51:57 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:51:57 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:51:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:51:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:51:57 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:51:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:51:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:51:57 --> Final output sent to browser
DEBUG - 2021-07-01 09:51:57 --> Total execution time: 0.0781
INFO - 2021-07-01 09:51:58 --> Config Class Initialized
INFO - 2021-07-01 09:51:58 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:51:58 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:51:58 --> Utf8 Class Initialized
INFO - 2021-07-01 09:51:58 --> URI Class Initialized
INFO - 2021-07-01 09:51:58 --> Router Class Initialized
INFO - 2021-07-01 09:51:58 --> Output Class Initialized
INFO - 2021-07-01 09:51:58 --> Security Class Initialized
DEBUG - 2021-07-01 09:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:51:58 --> Input Class Initialized
INFO - 2021-07-01 09:51:58 --> Language Class Initialized
INFO - 2021-07-01 09:51:58 --> Loader Class Initialized
INFO - 2021-07-01 09:51:58 --> Helper loaded: html_helper
INFO - 2021-07-01 09:51:58 --> Helper loaded: url_helper
INFO - 2021-07-01 09:51:58 --> Helper loaded: form_helper
INFO - 2021-07-01 09:51:58 --> Database Driver Class Initialized
INFO - 2021-07-01 09:51:58 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:51:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:51:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:51:58 --> Encryption Class Initialized
INFO - 2021-07-01 09:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:51:58 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:51:58 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:51:58 --> Model "user_model" initialized
INFO - 2021-07-01 09:51:58 --> Model "role_model" initialized
INFO - 2021-07-01 09:51:58 --> Controller Class Initialized
INFO - 2021-07-01 09:51:58 --> Helper loaded: language_helper
INFO - 2021-07-01 09:51:58 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:51:58 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:51:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:51:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:51:58 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:51:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:51:58 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:51:58 --> Final output sent to browser
DEBUG - 2021-07-01 09:51:58 --> Total execution time: 0.0781
INFO - 2021-07-01 09:51:59 --> Config Class Initialized
INFO - 2021-07-01 09:51:59 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:51:59 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:51:59 --> Utf8 Class Initialized
INFO - 2021-07-01 09:51:59 --> URI Class Initialized
INFO - 2021-07-01 09:51:59 --> Router Class Initialized
INFO - 2021-07-01 09:51:59 --> Output Class Initialized
INFO - 2021-07-01 09:51:59 --> Security Class Initialized
DEBUG - 2021-07-01 09:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:51:59 --> Input Class Initialized
INFO - 2021-07-01 09:51:59 --> Language Class Initialized
INFO - 2021-07-01 09:51:59 --> Loader Class Initialized
INFO - 2021-07-01 09:51:59 --> Helper loaded: html_helper
INFO - 2021-07-01 09:51:59 --> Helper loaded: url_helper
INFO - 2021-07-01 09:51:59 --> Helper loaded: form_helper
INFO - 2021-07-01 09:51:59 --> Database Driver Class Initialized
INFO - 2021-07-01 09:51:59 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:51:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:51:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:51:59 --> Encryption Class Initialized
INFO - 2021-07-01 09:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:51:59 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:51:59 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:51:59 --> Model "user_model" initialized
INFO - 2021-07-01 09:51:59 --> Model "role_model" initialized
INFO - 2021-07-01 09:51:59 --> Controller Class Initialized
INFO - 2021-07-01 09:51:59 --> Helper loaded: language_helper
INFO - 2021-07-01 09:51:59 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:51:59 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:51:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:51:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:51:59 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:51:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:51:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:51:59 --> Final output sent to browser
DEBUG - 2021-07-01 09:51:59 --> Total execution time: 0.0723
INFO - 2021-07-01 09:52:16 --> Config Class Initialized
INFO - 2021-07-01 09:52:16 --> Hooks Class Initialized
INFO - 2021-07-01 09:52:16 --> Config Class Initialized
INFO - 2021-07-01 09:52:16 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:52:16 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:52:16 --> Utf8 Class Initialized
DEBUG - 2021-07-01 09:52:16 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:52:16 --> Utf8 Class Initialized
INFO - 2021-07-01 09:52:16 --> URI Class Initialized
INFO - 2021-07-01 09:52:16 --> URI Class Initialized
INFO - 2021-07-01 09:52:16 --> Router Class Initialized
INFO - 2021-07-01 09:52:16 --> Router Class Initialized
INFO - 2021-07-01 09:52:16 --> Output Class Initialized
INFO - 2021-07-01 09:52:16 --> Output Class Initialized
INFO - 2021-07-01 09:52:16 --> Security Class Initialized
INFO - 2021-07-01 09:52:16 --> Security Class Initialized
DEBUG - 2021-07-01 09:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:52:16 --> Input Class Initialized
DEBUG - 2021-07-01 09:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:52:16 --> Language Class Initialized
INFO - 2021-07-01 09:52:16 --> Input Class Initialized
INFO - 2021-07-01 09:52:16 --> Language Class Initialized
INFO - 2021-07-01 09:52:16 --> Loader Class Initialized
INFO - 2021-07-01 09:52:16 --> Loader Class Initialized
INFO - 2021-07-01 09:52:16 --> Helper loaded: html_helper
INFO - 2021-07-01 09:52:16 --> Helper loaded: html_helper
INFO - 2021-07-01 09:52:16 --> Helper loaded: url_helper
INFO - 2021-07-01 09:52:16 --> Helper loaded: url_helper
INFO - 2021-07-01 09:52:16 --> Helper loaded: form_helper
INFO - 2021-07-01 09:52:16 --> Helper loaded: form_helper
INFO - 2021-07-01 09:52:16 --> Database Driver Class Initialized
INFO - 2021-07-01 09:52:16 --> Database Driver Class Initialized
INFO - 2021-07-01 09:52:16 --> Form Validation Class Initialized
INFO - 2021-07-01 09:52:16 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-01 09:52:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:52:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:52:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:52:16 --> Encryption Class Initialized
INFO - 2021-07-01 09:52:16 --> Encryption Class Initialized
INFO - 2021-07-01 09:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:52:16 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:52:16 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:52:16 --> Model "user_model" initialized
INFO - 2021-07-01 09:52:16 --> Model "role_model" initialized
INFO - 2021-07-01 09:52:16 --> Controller Class Initialized
INFO - 2021-07-01 09:52:16 --> Helper loaded: language_helper
INFO - 2021-07-01 09:52:16 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:52:16 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:52:16 --> Final output sent to browser
DEBUG - 2021-07-01 09:52:16 --> Total execution time: 0.0721
INFO - 2021-07-01 09:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:52:16 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:52:16 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:52:16 --> Model "user_model" initialized
INFO - 2021-07-01 09:52:16 --> Model "role_model" initialized
INFO - 2021-07-01 09:52:16 --> Controller Class Initialized
INFO - 2021-07-01 09:52:16 --> Helper loaded: language_helper
INFO - 2021-07-01 09:52:16 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:52:16 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:52:16 --> Final output sent to browser
DEBUG - 2021-07-01 09:52:16 --> Total execution time: 0.0841
INFO - 2021-07-01 09:52:48 --> Config Class Initialized
INFO - 2021-07-01 09:52:48 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:52:48 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:52:48 --> Utf8 Class Initialized
INFO - 2021-07-01 09:52:48 --> URI Class Initialized
INFO - 2021-07-01 09:52:48 --> Router Class Initialized
INFO - 2021-07-01 09:52:48 --> Output Class Initialized
INFO - 2021-07-01 09:52:48 --> Security Class Initialized
DEBUG - 2021-07-01 09:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:52:48 --> Input Class Initialized
INFO - 2021-07-01 09:52:48 --> Language Class Initialized
INFO - 2021-07-01 09:52:48 --> Loader Class Initialized
INFO - 2021-07-01 09:52:48 --> Helper loaded: html_helper
INFO - 2021-07-01 09:52:48 --> Helper loaded: url_helper
INFO - 2021-07-01 09:52:48 --> Helper loaded: form_helper
INFO - 2021-07-01 09:52:48 --> Database Driver Class Initialized
INFO - 2021-07-01 09:52:48 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:52:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:52:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:52:48 --> Encryption Class Initialized
INFO - 2021-07-01 09:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:52:48 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:52:48 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:52:48 --> Model "user_model" initialized
INFO - 2021-07-01 09:52:48 --> Model "role_model" initialized
INFO - 2021-07-01 09:52:48 --> Controller Class Initialized
INFO - 2021-07-01 09:52:48 --> Helper loaded: language_helper
INFO - 2021-07-01 09:52:48 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:52:48 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:52:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:52:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:52:48 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:52:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:52:48 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:52:48 --> Final output sent to browser
DEBUG - 2021-07-01 09:52:48 --> Total execution time: 0.1123
INFO - 2021-07-01 09:52:56 --> Config Class Initialized
INFO - 2021-07-01 09:52:56 --> Hooks Class Initialized
INFO - 2021-07-01 09:52:56 --> Config Class Initialized
INFO - 2021-07-01 09:52:56 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:52:56 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:52:56 --> Utf8 Class Initialized
DEBUG - 2021-07-01 09:52:56 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:52:56 --> Utf8 Class Initialized
INFO - 2021-07-01 09:52:56 --> URI Class Initialized
INFO - 2021-07-01 09:52:56 --> URI Class Initialized
INFO - 2021-07-01 09:52:56 --> Router Class Initialized
INFO - 2021-07-01 09:52:56 --> Router Class Initialized
INFO - 2021-07-01 09:52:56 --> Output Class Initialized
INFO - 2021-07-01 09:52:56 --> Output Class Initialized
INFO - 2021-07-01 09:52:56 --> Security Class Initialized
INFO - 2021-07-01 09:52:56 --> Security Class Initialized
DEBUG - 2021-07-01 09:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-01 09:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:52:56 --> Input Class Initialized
INFO - 2021-07-01 09:52:56 --> Input Class Initialized
INFO - 2021-07-01 09:52:56 --> Language Class Initialized
INFO - 2021-07-01 09:52:56 --> Language Class Initialized
INFO - 2021-07-01 09:52:56 --> Loader Class Initialized
INFO - 2021-07-01 09:52:56 --> Loader Class Initialized
INFO - 2021-07-01 09:52:56 --> Helper loaded: html_helper
INFO - 2021-07-01 09:52:56 --> Helper loaded: html_helper
INFO - 2021-07-01 09:52:56 --> Helper loaded: url_helper
INFO - 2021-07-01 09:52:56 --> Helper loaded: url_helper
INFO - 2021-07-01 09:52:56 --> Helper loaded: form_helper
INFO - 2021-07-01 09:52:56 --> Helper loaded: form_helper
INFO - 2021-07-01 09:52:56 --> Database Driver Class Initialized
INFO - 2021-07-01 09:52:56 --> Database Driver Class Initialized
INFO - 2021-07-01 09:52:56 --> Form Validation Class Initialized
INFO - 2021-07-01 09:52:56 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-01 09:52:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:52:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:52:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:52:56 --> Encryption Class Initialized
INFO - 2021-07-01 09:52:56 --> Encryption Class Initialized
INFO - 2021-07-01 09:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:52:56 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:52:56 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:52:56 --> Model "user_model" initialized
INFO - 2021-07-01 09:52:56 --> Model "role_model" initialized
INFO - 2021-07-01 09:52:56 --> Controller Class Initialized
INFO - 2021-07-01 09:52:56 --> Helper loaded: language_helper
INFO - 2021-07-01 09:52:56 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:52:56 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:52:56 --> Final output sent to browser
DEBUG - 2021-07-01 09:52:56 --> Total execution time: 0.0740
INFO - 2021-07-01 09:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:52:56 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:52:56 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:52:56 --> Model "user_model" initialized
INFO - 2021-07-01 09:52:56 --> Model "role_model" initialized
INFO - 2021-07-01 09:52:56 --> Controller Class Initialized
INFO - 2021-07-01 09:52:56 --> Helper loaded: language_helper
INFO - 2021-07-01 09:52:56 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:52:56 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:52:56 --> Final output sent to browser
DEBUG - 2021-07-01 09:52:56 --> Total execution time: 0.0846
INFO - 2021-07-01 09:54:31 --> Config Class Initialized
INFO - 2021-07-01 09:54:31 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:54:31 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:54:31 --> Utf8 Class Initialized
INFO - 2021-07-01 09:54:31 --> URI Class Initialized
INFO - 2021-07-01 09:54:31 --> Router Class Initialized
INFO - 2021-07-01 09:54:31 --> Output Class Initialized
INFO - 2021-07-01 09:54:31 --> Security Class Initialized
DEBUG - 2021-07-01 09:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:54:31 --> Input Class Initialized
INFO - 2021-07-01 09:54:31 --> Language Class Initialized
INFO - 2021-07-01 09:54:31 --> Loader Class Initialized
INFO - 2021-07-01 09:54:31 --> Helper loaded: html_helper
INFO - 2021-07-01 09:54:31 --> Helper loaded: url_helper
INFO - 2021-07-01 09:54:31 --> Helper loaded: form_helper
INFO - 2021-07-01 09:54:31 --> Database Driver Class Initialized
INFO - 2021-07-01 09:54:31 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:54:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:54:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:54:31 --> Encryption Class Initialized
INFO - 2021-07-01 09:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:54:31 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:54:31 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:54:31 --> Model "user_model" initialized
INFO - 2021-07-01 09:54:31 --> Model "role_model" initialized
INFO - 2021-07-01 09:54:31 --> Controller Class Initialized
INFO - 2021-07-01 09:54:31 --> Helper loaded: language_helper
INFO - 2021-07-01 09:54:31 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:54:31 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:54:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:54:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:54:31 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:54:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:54:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:54:31 --> Final output sent to browser
DEBUG - 2021-07-01 09:54:31 --> Total execution time: 0.1100
INFO - 2021-07-01 09:54:34 --> Config Class Initialized
INFO - 2021-07-01 09:54:34 --> Hooks Class Initialized
INFO - 2021-07-01 09:54:34 --> Config Class Initialized
INFO - 2021-07-01 09:54:34 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:54:34 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:54:34 --> Utf8 Class Initialized
DEBUG - 2021-07-01 09:54:34 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:54:34 --> Utf8 Class Initialized
INFO - 2021-07-01 09:54:34 --> URI Class Initialized
INFO - 2021-07-01 09:54:34 --> URI Class Initialized
INFO - 2021-07-01 09:54:34 --> Router Class Initialized
INFO - 2021-07-01 09:54:34 --> Router Class Initialized
INFO - 2021-07-01 09:54:34 --> Output Class Initialized
INFO - 2021-07-01 09:54:34 --> Output Class Initialized
INFO - 2021-07-01 09:54:34 --> Security Class Initialized
INFO - 2021-07-01 09:54:34 --> Security Class Initialized
DEBUG - 2021-07-01 09:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-01 09:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:54:34 --> Input Class Initialized
INFO - 2021-07-01 09:54:34 --> Input Class Initialized
INFO - 2021-07-01 09:54:34 --> Language Class Initialized
INFO - 2021-07-01 09:54:34 --> Language Class Initialized
INFO - 2021-07-01 09:54:34 --> Loader Class Initialized
INFO - 2021-07-01 09:54:34 --> Loader Class Initialized
INFO - 2021-07-01 09:54:34 --> Helper loaded: html_helper
INFO - 2021-07-01 09:54:34 --> Helper loaded: html_helper
INFO - 2021-07-01 09:54:34 --> Helper loaded: url_helper
INFO - 2021-07-01 09:54:34 --> Helper loaded: url_helper
INFO - 2021-07-01 09:54:34 --> Helper loaded: form_helper
INFO - 2021-07-01 09:54:34 --> Helper loaded: form_helper
INFO - 2021-07-01 09:54:34 --> Database Driver Class Initialized
INFO - 2021-07-01 09:54:34 --> Database Driver Class Initialized
INFO - 2021-07-01 09:54:34 --> Form Validation Class Initialized
INFO - 2021-07-01 09:54:34 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-07-01 09:54:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:54:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:54:34 --> Encryption Class Initialized
INFO - 2021-07-01 09:54:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:54:34 --> Encryption Class Initialized
INFO - 2021-07-01 09:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:54:34 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:54:34 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:54:34 --> Model "user_model" initialized
INFO - 2021-07-01 09:54:34 --> Model "role_model" initialized
INFO - 2021-07-01 09:54:34 --> Controller Class Initialized
INFO - 2021-07-01 09:54:34 --> Helper loaded: language_helper
INFO - 2021-07-01 09:54:34 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:54:34 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:54:34 --> Final output sent to browser
DEBUG - 2021-07-01 09:54:34 --> Total execution time: 0.0700
INFO - 2021-07-01 09:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:54:34 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:54:34 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:54:34 --> Model "user_model" initialized
INFO - 2021-07-01 09:54:34 --> Model "role_model" initialized
INFO - 2021-07-01 09:54:34 --> Controller Class Initialized
INFO - 2021-07-01 09:54:34 --> Helper loaded: language_helper
INFO - 2021-07-01 09:54:34 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:54:34 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:54:34 --> Final output sent to browser
DEBUG - 2021-07-01 09:54:34 --> Total execution time: 0.0829
INFO - 2021-07-01 09:55:15 --> Config Class Initialized
INFO - 2021-07-01 09:55:15 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:55:15 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:55:15 --> Utf8 Class Initialized
INFO - 2021-07-01 09:55:15 --> URI Class Initialized
INFO - 2021-07-01 09:55:15 --> Router Class Initialized
INFO - 2021-07-01 09:55:15 --> Output Class Initialized
INFO - 2021-07-01 09:55:15 --> Security Class Initialized
DEBUG - 2021-07-01 09:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:55:15 --> Input Class Initialized
INFO - 2021-07-01 09:55:15 --> Language Class Initialized
INFO - 2021-07-01 09:55:15 --> Loader Class Initialized
INFO - 2021-07-01 09:55:15 --> Helper loaded: html_helper
INFO - 2021-07-01 09:55:15 --> Helper loaded: url_helper
INFO - 2021-07-01 09:55:15 --> Helper loaded: form_helper
INFO - 2021-07-01 09:55:15 --> Database Driver Class Initialized
INFO - 2021-07-01 09:55:16 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:55:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:55:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:55:16 --> Encryption Class Initialized
INFO - 2021-07-01 09:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:55:16 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:55:16 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:55:16 --> Model "user_model" initialized
INFO - 2021-07-01 09:55:16 --> Model "role_model" initialized
INFO - 2021-07-01 09:55:16 --> Controller Class Initialized
INFO - 2021-07-01 09:55:16 --> Helper loaded: language_helper
INFO - 2021-07-01 09:55:16 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:55:16 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:55:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:55:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:55:16 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:55:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:55:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:55:16 --> Final output sent to browser
DEBUG - 2021-07-01 09:55:16 --> Total execution time: 0.1174
INFO - 2021-07-01 09:55:24 --> Config Class Initialized
INFO - 2021-07-01 09:55:24 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:55:24 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:55:24 --> Utf8 Class Initialized
INFO - 2021-07-01 09:55:24 --> URI Class Initialized
INFO - 2021-07-01 09:55:24 --> Router Class Initialized
INFO - 2021-07-01 09:55:24 --> Output Class Initialized
INFO - 2021-07-01 09:55:24 --> Security Class Initialized
DEBUG - 2021-07-01 09:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:55:24 --> Input Class Initialized
INFO - 2021-07-01 09:55:24 --> Language Class Initialized
INFO - 2021-07-01 09:55:24 --> Loader Class Initialized
INFO - 2021-07-01 09:55:24 --> Helper loaded: html_helper
INFO - 2021-07-01 09:55:24 --> Helper loaded: url_helper
INFO - 2021-07-01 09:55:24 --> Helper loaded: form_helper
INFO - 2021-07-01 09:55:24 --> Database Driver Class Initialized
INFO - 2021-07-01 09:55:24 --> Config Class Initialized
INFO - 2021-07-01 09:55:24 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:55:24 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:55:24 --> Utf8 Class Initialized
INFO - 2021-07-01 09:55:24 --> URI Class Initialized
INFO - 2021-07-01 09:55:24 --> Router Class Initialized
INFO - 2021-07-01 09:55:24 --> Output Class Initialized
INFO - 2021-07-01 09:55:24 --> Security Class Initialized
DEBUG - 2021-07-01 09:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:55:24 --> Input Class Initialized
INFO - 2021-07-01 09:55:24 --> Language Class Initialized
INFO - 2021-07-01 09:55:24 --> Loader Class Initialized
INFO - 2021-07-01 09:55:24 --> Helper loaded: html_helper
INFO - 2021-07-01 09:55:24 --> Helper loaded: url_helper
INFO - 2021-07-01 09:55:24 --> Helper loaded: form_helper
INFO - 2021-07-01 09:55:24 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:55:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:55:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:55:24 --> Encryption Class Initialized
INFO - 2021-07-01 09:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:55:24 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:55:24 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:55:24 --> Model "user_model" initialized
INFO - 2021-07-01 09:55:24 --> Model "role_model" initialized
INFO - 2021-07-01 09:55:24 --> Controller Class Initialized
INFO - 2021-07-01 09:55:24 --> Helper loaded: language_helper
INFO - 2021-07-01 09:55:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:55:24 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:55:24 --> Database Driver Class Initialized
INFO - 2021-07-01 09:55:24 --> Final output sent to browser
DEBUG - 2021-07-01 09:55:24 --> Total execution time: 0.0990
INFO - 2021-07-01 09:55:24 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:55:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:55:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:55:24 --> Encryption Class Initialized
INFO - 2021-07-01 09:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:55:24 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:55:24 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:55:24 --> Model "user_model" initialized
INFO - 2021-07-01 09:55:24 --> Model "role_model" initialized
INFO - 2021-07-01 09:55:24 --> Controller Class Initialized
INFO - 2021-07-01 09:55:24 --> Helper loaded: language_helper
INFO - 2021-07-01 09:55:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:55:24 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:55:24 --> Final output sent to browser
DEBUG - 2021-07-01 09:55:24 --> Total execution time: 0.0926
INFO - 2021-07-01 09:55:49 --> Config Class Initialized
INFO - 2021-07-01 09:55:49 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:55:49 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:55:49 --> Utf8 Class Initialized
INFO - 2021-07-01 09:55:49 --> URI Class Initialized
INFO - 2021-07-01 09:55:49 --> Router Class Initialized
INFO - 2021-07-01 09:55:49 --> Output Class Initialized
INFO - 2021-07-01 09:55:49 --> Security Class Initialized
DEBUG - 2021-07-01 09:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:55:49 --> Input Class Initialized
INFO - 2021-07-01 09:55:49 --> Language Class Initialized
INFO - 2021-07-01 09:55:49 --> Loader Class Initialized
INFO - 2021-07-01 09:55:49 --> Helper loaded: html_helper
INFO - 2021-07-01 09:55:49 --> Helper loaded: url_helper
INFO - 2021-07-01 09:55:49 --> Helper loaded: form_helper
INFO - 2021-07-01 09:55:49 --> Database Driver Class Initialized
INFO - 2021-07-01 09:55:49 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:55:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:55:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:55:49 --> Encryption Class Initialized
INFO - 2021-07-01 09:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:55:49 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:55:49 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:55:49 --> Model "user_model" initialized
INFO - 2021-07-01 09:55:49 --> Model "role_model" initialized
INFO - 2021-07-01 09:55:49 --> Controller Class Initialized
INFO - 2021-07-01 09:55:49 --> Helper loaded: language_helper
INFO - 2021-07-01 09:55:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:55:49 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:55:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:55:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:55:49 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:55:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:55:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:55:49 --> Final output sent to browser
DEBUG - 2021-07-01 09:55:49 --> Total execution time: 0.1003
INFO - 2021-07-01 09:55:54 --> Config Class Initialized
INFO - 2021-07-01 09:55:54 --> Hooks Class Initialized
INFO - 2021-07-01 09:55:54 --> Config Class Initialized
INFO - 2021-07-01 09:55:54 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:55:54 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:55:54 --> Utf8 Class Initialized
DEBUG - 2021-07-01 09:55:54 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:55:54 --> Utf8 Class Initialized
INFO - 2021-07-01 09:55:54 --> URI Class Initialized
INFO - 2021-07-01 09:55:54 --> URI Class Initialized
INFO - 2021-07-01 09:55:54 --> Router Class Initialized
INFO - 2021-07-01 09:55:54 --> Router Class Initialized
INFO - 2021-07-01 09:55:54 --> Output Class Initialized
INFO - 2021-07-01 09:55:54 --> Output Class Initialized
INFO - 2021-07-01 09:55:54 --> Security Class Initialized
INFO - 2021-07-01 09:55:54 --> Security Class Initialized
DEBUG - 2021-07-01 09:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-01 09:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:55:54 --> Input Class Initialized
INFO - 2021-07-01 09:55:54 --> Input Class Initialized
INFO - 2021-07-01 09:55:54 --> Language Class Initialized
INFO - 2021-07-01 09:55:54 --> Loader Class Initialized
INFO - 2021-07-01 09:55:54 --> Helper loaded: html_helper
INFO - 2021-07-01 09:55:54 --> Helper loaded: url_helper
INFO - 2021-07-01 09:55:54 --> Helper loaded: form_helper
INFO - 2021-07-01 09:55:54 --> Language Class Initialized
INFO - 2021-07-01 09:55:54 --> Loader Class Initialized
INFO - 2021-07-01 09:55:54 --> Database Driver Class Initialized
INFO - 2021-07-01 09:55:54 --> Helper loaded: html_helper
INFO - 2021-07-01 09:55:54 --> Helper loaded: url_helper
INFO - 2021-07-01 09:55:54 --> Helper loaded: form_helper
INFO - 2021-07-01 09:55:54 --> Database Driver Class Initialized
INFO - 2021-07-01 09:55:54 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:55:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:55:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:55:54 --> Encryption Class Initialized
INFO - 2021-07-01 09:55:54 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:55:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:55:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:55:54 --> Encryption Class Initialized
INFO - 2021-07-01 09:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:55:54 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:55:54 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:55:54 --> Model "user_model" initialized
INFO - 2021-07-01 09:55:54 --> Model "role_model" initialized
INFO - 2021-07-01 09:55:54 --> Controller Class Initialized
INFO - 2021-07-01 09:55:54 --> Helper loaded: language_helper
INFO - 2021-07-01 09:55:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:55:54 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:55:54 --> Final output sent to browser
DEBUG - 2021-07-01 09:55:54 --> Total execution time: 0.0756
INFO - 2021-07-01 09:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:55:54 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:55:54 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:55:54 --> Model "user_model" initialized
INFO - 2021-07-01 09:55:54 --> Model "role_model" initialized
INFO - 2021-07-01 09:55:54 --> Controller Class Initialized
INFO - 2021-07-01 09:55:54 --> Helper loaded: language_helper
INFO - 2021-07-01 09:55:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:55:54 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:55:54 --> Final output sent to browser
DEBUG - 2021-07-01 09:55:54 --> Total execution time: 0.0878
INFO - 2021-07-01 09:56:36 --> Config Class Initialized
INFO - 2021-07-01 09:56:36 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:56:36 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:56:36 --> Utf8 Class Initialized
INFO - 2021-07-01 09:56:36 --> URI Class Initialized
INFO - 2021-07-01 09:56:36 --> Router Class Initialized
INFO - 2021-07-01 09:56:36 --> Output Class Initialized
INFO - 2021-07-01 09:56:36 --> Security Class Initialized
DEBUG - 2021-07-01 09:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:56:36 --> Input Class Initialized
INFO - 2021-07-01 09:56:36 --> Language Class Initialized
INFO - 2021-07-01 09:56:36 --> Loader Class Initialized
INFO - 2021-07-01 09:56:36 --> Helper loaded: html_helper
INFO - 2021-07-01 09:56:36 --> Helper loaded: url_helper
INFO - 2021-07-01 09:56:36 --> Helper loaded: form_helper
INFO - 2021-07-01 09:56:37 --> Database Driver Class Initialized
INFO - 2021-07-01 09:56:37 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:56:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:56:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:56:37 --> Encryption Class Initialized
INFO - 2021-07-01 09:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:56:37 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:56:37 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:56:37 --> Model "user_model" initialized
INFO - 2021-07-01 09:56:37 --> Model "role_model" initialized
INFO - 2021-07-01 09:56:37 --> Controller Class Initialized
INFO - 2021-07-01 09:56:37 --> Helper loaded: language_helper
INFO - 2021-07-01 09:56:37 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:56:37 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:56:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:56:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:56:37 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:56:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:56:37 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:56:37 --> Final output sent to browser
DEBUG - 2021-07-01 09:56:37 --> Total execution time: 0.1111
INFO - 2021-07-01 09:56:38 --> Config Class Initialized
INFO - 2021-07-01 09:56:38 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:56:38 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:56:38 --> Utf8 Class Initialized
INFO - 2021-07-01 09:56:38 --> URI Class Initialized
INFO - 2021-07-01 09:56:38 --> Router Class Initialized
INFO - 2021-07-01 09:56:38 --> Output Class Initialized
INFO - 2021-07-01 09:56:38 --> Security Class Initialized
DEBUG - 2021-07-01 09:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:56:38 --> Input Class Initialized
INFO - 2021-07-01 09:56:38 --> Language Class Initialized
INFO - 2021-07-01 09:56:38 --> Loader Class Initialized
INFO - 2021-07-01 09:56:38 --> Helper loaded: html_helper
INFO - 2021-07-01 09:56:38 --> Helper loaded: url_helper
INFO - 2021-07-01 09:56:38 --> Helper loaded: form_helper
INFO - 2021-07-01 09:56:38 --> Database Driver Class Initialized
INFO - 2021-07-01 09:56:38 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:56:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:56:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:56:38 --> Encryption Class Initialized
INFO - 2021-07-01 09:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:56:38 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:56:38 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:56:38 --> Model "user_model" initialized
INFO - 2021-07-01 09:56:38 --> Model "role_model" initialized
INFO - 2021-07-01 09:56:38 --> Controller Class Initialized
INFO - 2021-07-01 09:56:38 --> Helper loaded: language_helper
INFO - 2021-07-01 09:56:38 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:56:38 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:56:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:56:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:56:38 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:56:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:56:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:56:38 --> Final output sent to browser
DEBUG - 2021-07-01 09:56:38 --> Total execution time: 0.0693
INFO - 2021-07-01 09:56:59 --> Config Class Initialized
INFO - 2021-07-01 09:56:59 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:56:59 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:56:59 --> Utf8 Class Initialized
INFO - 2021-07-01 09:56:59 --> URI Class Initialized
INFO - 2021-07-01 09:56:59 --> Router Class Initialized
INFO - 2021-07-01 09:56:59 --> Output Class Initialized
INFO - 2021-07-01 09:56:59 --> Security Class Initialized
DEBUG - 2021-07-01 09:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:56:59 --> Input Class Initialized
INFO - 2021-07-01 09:56:59 --> Language Class Initialized
INFO - 2021-07-01 09:56:59 --> Loader Class Initialized
INFO - 2021-07-01 09:56:59 --> Helper loaded: html_helper
INFO - 2021-07-01 09:56:59 --> Helper loaded: url_helper
INFO - 2021-07-01 09:56:59 --> Helper loaded: form_helper
INFO - 2021-07-01 09:56:59 --> Database Driver Class Initialized
INFO - 2021-07-01 09:56:59 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:56:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:56:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:56:59 --> Encryption Class Initialized
INFO - 2021-07-01 09:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:56:59 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:56:59 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:56:59 --> Model "user_model" initialized
INFO - 2021-07-01 09:56:59 --> Model "role_model" initialized
INFO - 2021-07-01 09:56:59 --> Controller Class Initialized
INFO - 2021-07-01 09:56:59 --> Helper loaded: language_helper
INFO - 2021-07-01 09:56:59 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:56:59 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:56:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:56:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:56:59 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:56:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:56:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:56:59 --> Final output sent to browser
DEBUG - 2021-07-01 09:56:59 --> Total execution time: 0.0730
INFO - 2021-07-01 09:58:00 --> Config Class Initialized
INFO - 2021-07-01 09:58:00 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:58:00 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:58:00 --> Utf8 Class Initialized
INFO - 2021-07-01 09:58:00 --> URI Class Initialized
INFO - 2021-07-01 09:58:00 --> Router Class Initialized
INFO - 2021-07-01 09:58:00 --> Output Class Initialized
INFO - 2021-07-01 09:58:00 --> Security Class Initialized
DEBUG - 2021-07-01 09:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:58:00 --> Input Class Initialized
INFO - 2021-07-01 09:58:00 --> Language Class Initialized
INFO - 2021-07-01 09:58:00 --> Loader Class Initialized
INFO - 2021-07-01 09:58:00 --> Helper loaded: html_helper
INFO - 2021-07-01 09:58:00 --> Helper loaded: url_helper
INFO - 2021-07-01 09:58:00 --> Helper loaded: form_helper
INFO - 2021-07-01 09:58:00 --> Database Driver Class Initialized
INFO - 2021-07-01 09:58:00 --> Form Validation Class Initialized
DEBUG - 2021-07-01 09:58:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 09:58:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 09:58:00 --> Encryption Class Initialized
INFO - 2021-07-01 09:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:58:01 --> Model "vendor_model" initialized
INFO - 2021-07-01 09:58:01 --> Model "coupon_model" initialized
INFO - 2021-07-01 09:58:01 --> Model "user_model" initialized
INFO - 2021-07-01 09:58:01 --> Model "role_model" initialized
INFO - 2021-07-01 09:58:01 --> Controller Class Initialized
INFO - 2021-07-01 09:58:01 --> Helper loaded: language_helper
INFO - 2021-07-01 09:58:01 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 09:58:01 --> Model "Quotation_model" initialized
INFO - 2021-07-01 09:58:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 09:58:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 09:58:01 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 09:58:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 09:58:01 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 09:58:01 --> Final output sent to browser
DEBUG - 2021-07-01 09:58:01 --> Total execution time: 0.0654
INFO - 2021-07-01 10:00:27 --> Config Class Initialized
INFO - 2021-07-01 10:00:27 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:00:27 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:00:27 --> Utf8 Class Initialized
INFO - 2021-07-01 10:00:27 --> URI Class Initialized
INFO - 2021-07-01 10:00:27 --> Router Class Initialized
INFO - 2021-07-01 10:00:27 --> Output Class Initialized
INFO - 2021-07-01 10:00:27 --> Security Class Initialized
DEBUG - 2021-07-01 10:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:00:27 --> Input Class Initialized
INFO - 2021-07-01 10:00:27 --> Language Class Initialized
INFO - 2021-07-01 10:00:27 --> Loader Class Initialized
INFO - 2021-07-01 10:00:27 --> Helper loaded: html_helper
INFO - 2021-07-01 10:00:27 --> Helper loaded: url_helper
INFO - 2021-07-01 10:00:27 --> Helper loaded: form_helper
INFO - 2021-07-01 10:00:27 --> Database Driver Class Initialized
INFO - 2021-07-01 10:00:27 --> Form Validation Class Initialized
DEBUG - 2021-07-01 10:00:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 10:00:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 10:00:27 --> Encryption Class Initialized
INFO - 2021-07-01 10:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:00:27 --> Model "vendor_model" initialized
INFO - 2021-07-01 10:00:27 --> Model "coupon_model" initialized
INFO - 2021-07-01 10:00:27 --> Model "user_model" initialized
INFO - 2021-07-01 10:00:27 --> Model "role_model" initialized
INFO - 2021-07-01 10:00:27 --> Controller Class Initialized
INFO - 2021-07-01 10:00:27 --> Helper loaded: language_helper
INFO - 2021-07-01 10:00:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 10:00:27 --> Model "Quotation_model" initialized
INFO - 2021-07-01 10:00:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 10:00:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 10:00:27 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 10:00:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 10:00:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 10:00:27 --> Final output sent to browser
DEBUG - 2021-07-01 10:00:27 --> Total execution time: 0.0844
INFO - 2021-07-01 10:00:32 --> Config Class Initialized
INFO - 2021-07-01 10:00:32 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:00:32 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:00:32 --> Utf8 Class Initialized
INFO - 2021-07-01 10:00:32 --> URI Class Initialized
INFO - 2021-07-01 10:00:32 --> Router Class Initialized
INFO - 2021-07-01 10:00:32 --> Output Class Initialized
INFO - 2021-07-01 10:00:32 --> Security Class Initialized
DEBUG - 2021-07-01 10:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:00:32 --> Input Class Initialized
INFO - 2021-07-01 10:00:32 --> Language Class Initialized
INFO - 2021-07-01 10:00:32 --> Loader Class Initialized
INFO - 2021-07-01 10:00:32 --> Helper loaded: html_helper
INFO - 2021-07-01 10:00:32 --> Helper loaded: url_helper
INFO - 2021-07-01 10:00:32 --> Helper loaded: form_helper
INFO - 2021-07-01 10:00:32 --> Database Driver Class Initialized
INFO - 2021-07-01 10:00:32 --> Form Validation Class Initialized
DEBUG - 2021-07-01 10:00:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 10:00:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 10:00:32 --> Encryption Class Initialized
INFO - 2021-07-01 10:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:00:32 --> Model "vendor_model" initialized
INFO - 2021-07-01 10:00:32 --> Model "coupon_model" initialized
INFO - 2021-07-01 10:00:32 --> Model "user_model" initialized
INFO - 2021-07-01 10:00:32 --> Model "role_model" initialized
INFO - 2021-07-01 10:00:32 --> Controller Class Initialized
INFO - 2021-07-01 10:00:33 --> Helper loaded: language_helper
INFO - 2021-07-01 10:00:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 10:00:33 --> Model "Quotation_model" initialized
INFO - 2021-07-01 10:00:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 10:00:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 10:00:33 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 10:00:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 10:00:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 10:00:33 --> Final output sent to browser
DEBUG - 2021-07-01 10:00:33 --> Total execution time: 0.0676
INFO - 2021-07-01 10:00:33 --> Config Class Initialized
INFO - 2021-07-01 10:00:33 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:00:33 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:00:33 --> Utf8 Class Initialized
INFO - 2021-07-01 10:00:33 --> URI Class Initialized
INFO - 2021-07-01 10:00:33 --> Router Class Initialized
INFO - 2021-07-01 10:00:33 --> Output Class Initialized
INFO - 2021-07-01 10:00:33 --> Security Class Initialized
DEBUG - 2021-07-01 10:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:00:33 --> Input Class Initialized
INFO - 2021-07-01 10:00:33 --> Language Class Initialized
INFO - 2021-07-01 10:00:33 --> Loader Class Initialized
INFO - 2021-07-01 10:00:33 --> Helper loaded: html_helper
INFO - 2021-07-01 10:00:33 --> Helper loaded: url_helper
INFO - 2021-07-01 10:00:33 --> Helper loaded: form_helper
INFO - 2021-07-01 10:00:33 --> Database Driver Class Initialized
INFO - 2021-07-01 10:00:33 --> Form Validation Class Initialized
DEBUG - 2021-07-01 10:00:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 10:00:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 10:00:33 --> Encryption Class Initialized
INFO - 2021-07-01 10:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:00:33 --> Model "vendor_model" initialized
INFO - 2021-07-01 10:00:33 --> Model "coupon_model" initialized
INFO - 2021-07-01 10:00:33 --> Model "user_model" initialized
INFO - 2021-07-01 10:00:33 --> Model "role_model" initialized
INFO - 2021-07-01 10:00:33 --> Controller Class Initialized
INFO - 2021-07-01 10:00:33 --> Helper loaded: language_helper
INFO - 2021-07-01 10:00:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 10:00:33 --> Model "Quotation_model" initialized
INFO - 2021-07-01 10:00:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 10:00:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 10:00:33 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 10:00:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 10:00:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 10:00:33 --> Final output sent to browser
DEBUG - 2021-07-01 10:00:33 --> Total execution time: 0.0708
INFO - 2021-07-01 10:01:05 --> Config Class Initialized
INFO - 2021-07-01 10:01:05 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:01:05 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:01:05 --> Utf8 Class Initialized
INFO - 2021-07-01 10:01:05 --> URI Class Initialized
INFO - 2021-07-01 10:01:05 --> Router Class Initialized
INFO - 2021-07-01 10:01:05 --> Output Class Initialized
INFO - 2021-07-01 10:01:05 --> Security Class Initialized
DEBUG - 2021-07-01 10:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:01:05 --> Input Class Initialized
INFO - 2021-07-01 10:01:05 --> Language Class Initialized
INFO - 2021-07-01 10:01:05 --> Loader Class Initialized
INFO - 2021-07-01 10:01:05 --> Helper loaded: html_helper
INFO - 2021-07-01 10:01:05 --> Helper loaded: url_helper
INFO - 2021-07-01 10:01:05 --> Helper loaded: form_helper
INFO - 2021-07-01 10:01:05 --> Database Driver Class Initialized
INFO - 2021-07-01 10:01:05 --> Form Validation Class Initialized
DEBUG - 2021-07-01 10:01:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 10:01:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 10:01:05 --> Encryption Class Initialized
INFO - 2021-07-01 10:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:01:05 --> Model "vendor_model" initialized
INFO - 2021-07-01 10:01:05 --> Model "coupon_model" initialized
INFO - 2021-07-01 10:01:05 --> Model "user_model" initialized
INFO - 2021-07-01 10:01:05 --> Model "role_model" initialized
INFO - 2021-07-01 10:01:05 --> Controller Class Initialized
INFO - 2021-07-01 10:01:05 --> Helper loaded: language_helper
INFO - 2021-07-01 10:01:05 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 10:01:05 --> Model "Quotation_model" initialized
INFO - 2021-07-01 10:01:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 10:01:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 10:01:05 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 10:01:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 10:01:05 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 10:01:05 --> Final output sent to browser
DEBUG - 2021-07-01 10:01:05 --> Total execution time: 0.0797
INFO - 2021-07-01 10:21:31 --> Config Class Initialized
INFO - 2021-07-01 10:21:31 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:21:31 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:21:31 --> Utf8 Class Initialized
INFO - 2021-07-01 10:21:31 --> URI Class Initialized
INFO - 2021-07-01 10:21:31 --> Router Class Initialized
INFO - 2021-07-01 10:21:31 --> Output Class Initialized
INFO - 2021-07-01 10:21:31 --> Security Class Initialized
DEBUG - 2021-07-01 10:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:21:31 --> Input Class Initialized
INFO - 2021-07-01 10:21:31 --> Language Class Initialized
INFO - 2021-07-01 10:21:31 --> Loader Class Initialized
INFO - 2021-07-01 10:21:31 --> Helper loaded: html_helper
INFO - 2021-07-01 10:21:31 --> Helper loaded: url_helper
INFO - 2021-07-01 10:21:31 --> Helper loaded: form_helper
INFO - 2021-07-01 10:21:31 --> Database Driver Class Initialized
INFO - 2021-07-01 10:21:31 --> Form Validation Class Initialized
DEBUG - 2021-07-01 10:21:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 10:21:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 10:21:31 --> Encryption Class Initialized
INFO - 2021-07-01 10:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:21:31 --> Model "vendor_model" initialized
INFO - 2021-07-01 10:21:31 --> Model "coupon_model" initialized
INFO - 2021-07-01 10:21:31 --> Model "user_model" initialized
INFO - 2021-07-01 10:21:31 --> Model "role_model" initialized
INFO - 2021-07-01 10:21:31 --> Controller Class Initialized
INFO - 2021-07-01 10:21:31 --> Helper loaded: language_helper
INFO - 2021-07-01 10:21:31 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 10:21:31 --> Model "Quotation_model" initialized
INFO - 2021-07-01 10:21:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 10:21:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 10:21:31 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 10:21:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 10:21:31 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 10:21:31 --> Final output sent to browser
DEBUG - 2021-07-01 10:21:31 --> Total execution time: 0.4997
INFO - 2021-07-01 10:28:15 --> Config Class Initialized
INFO - 2021-07-01 10:28:15 --> Config Class Initialized
INFO - 2021-07-01 10:28:15 --> Hooks Class Initialized
INFO - 2021-07-01 10:28:15 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:28:15 --> UTF-8 Support Enabled
DEBUG - 2021-07-01 10:28:15 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:28:15 --> Utf8 Class Initialized
INFO - 2021-07-01 10:28:15 --> URI Class Initialized
INFO - 2021-07-01 10:28:15 --> Utf8 Class Initialized
INFO - 2021-07-01 10:28:15 --> Router Class Initialized
INFO - 2021-07-01 10:28:15 --> URI Class Initialized
INFO - 2021-07-01 10:28:15 --> Router Class Initialized
INFO - 2021-07-01 10:28:15 --> Output Class Initialized
INFO - 2021-07-01 10:28:15 --> Security Class Initialized
DEBUG - 2021-07-01 10:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:28:15 --> Input Class Initialized
INFO - 2021-07-01 10:28:15 --> Language Class Initialized
INFO - 2021-07-01 10:28:15 --> Output Class Initialized
INFO - 2021-07-01 10:28:15 --> Loader Class Initialized
INFO - 2021-07-01 10:28:15 --> Security Class Initialized
INFO - 2021-07-01 10:28:15 --> Helper loaded: html_helper
DEBUG - 2021-07-01 10:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:28:15 --> Helper loaded: url_helper
INFO - 2021-07-01 10:28:15 --> Input Class Initialized
INFO - 2021-07-01 10:28:15 --> Helper loaded: form_helper
INFO - 2021-07-01 10:28:15 --> Language Class Initialized
INFO - 2021-07-01 10:28:15 --> Loader Class Initialized
INFO - 2021-07-01 10:28:15 --> Helper loaded: html_helper
INFO - 2021-07-01 10:28:15 --> Database Driver Class Initialized
INFO - 2021-07-01 10:28:15 --> Helper loaded: url_helper
INFO - 2021-07-01 10:28:15 --> Helper loaded: form_helper
INFO - 2021-07-01 10:28:15 --> Database Driver Class Initialized
INFO - 2021-07-01 10:28:15 --> Form Validation Class Initialized
DEBUG - 2021-07-01 10:28:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 10:28:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 10:28:15 --> Form Validation Class Initialized
INFO - 2021-07-01 10:28:15 --> Encryption Class Initialized
DEBUG - 2021-07-01 10:28:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 10:28:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 10:28:15 --> Encryption Class Initialized
INFO - 2021-07-01 10:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:28:15 --> Model "vendor_model" initialized
INFO - 2021-07-01 10:28:15 --> Model "coupon_model" initialized
INFO - 2021-07-01 10:28:15 --> Model "user_model" initialized
INFO - 2021-07-01 10:28:15 --> Model "role_model" initialized
INFO - 2021-07-01 10:28:15 --> Controller Class Initialized
INFO - 2021-07-01 10:28:15 --> Helper loaded: language_helper
INFO - 2021-07-01 10:28:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 10:28:15 --> Model "Quotation_model" initialized
INFO - 2021-07-01 10:28:15 --> Final output sent to browser
DEBUG - 2021-07-01 10:28:15 --> Total execution time: 0.2169
INFO - 2021-07-01 10:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:28:15 --> Model "vendor_model" initialized
INFO - 2021-07-01 10:28:15 --> Model "coupon_model" initialized
INFO - 2021-07-01 10:28:15 --> Model "user_model" initialized
INFO - 2021-07-01 10:28:15 --> Model "role_model" initialized
INFO - 2021-07-01 10:28:15 --> Controller Class Initialized
INFO - 2021-07-01 10:28:15 --> Helper loaded: language_helper
INFO - 2021-07-01 10:28:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 10:28:15 --> Model "Quotation_model" initialized
INFO - 2021-07-01 10:28:15 --> Final output sent to browser
DEBUG - 2021-07-01 10:28:15 --> Total execution time: 0.2265
INFO - 2021-07-01 10:28:19 --> Config Class Initialized
INFO - 2021-07-01 10:28:19 --> Config Class Initialized
INFO - 2021-07-01 10:28:19 --> Hooks Class Initialized
INFO - 2021-07-01 10:28:19 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:28:19 --> UTF-8 Support Enabled
DEBUG - 2021-07-01 10:28:19 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:28:19 --> Utf8 Class Initialized
INFO - 2021-07-01 10:28:19 --> Utf8 Class Initialized
INFO - 2021-07-01 10:28:19 --> URI Class Initialized
INFO - 2021-07-01 10:28:19 --> URI Class Initialized
INFO - 2021-07-01 10:28:19 --> Router Class Initialized
INFO - 2021-07-01 10:28:19 --> Router Class Initialized
INFO - 2021-07-01 10:28:19 --> Output Class Initialized
INFO - 2021-07-01 10:28:19 --> Security Class Initialized
DEBUG - 2021-07-01 10:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:28:19 --> Input Class Initialized
INFO - 2021-07-01 10:28:19 --> Language Class Initialized
INFO - 2021-07-01 10:28:19 --> Loader Class Initialized
INFO - 2021-07-01 10:28:19 --> Helper loaded: html_helper
INFO - 2021-07-01 10:28:19 --> Helper loaded: url_helper
INFO - 2021-07-01 10:28:19 --> Output Class Initialized
INFO - 2021-07-01 10:28:19 --> Helper loaded: form_helper
INFO - 2021-07-01 10:28:19 --> Security Class Initialized
DEBUG - 2021-07-01 10:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:28:19 --> Input Class Initialized
INFO - 2021-07-01 10:28:19 --> Language Class Initialized
INFO - 2021-07-01 10:28:19 --> Loader Class Initialized
INFO - 2021-07-01 10:28:19 --> Database Driver Class Initialized
INFO - 2021-07-01 10:28:19 --> Helper loaded: html_helper
INFO - 2021-07-01 10:28:19 --> Helper loaded: url_helper
INFO - 2021-07-01 10:28:19 --> Helper loaded: form_helper
INFO - 2021-07-01 10:28:19 --> Database Driver Class Initialized
INFO - 2021-07-01 10:28:19 --> Form Validation Class Initialized
DEBUG - 2021-07-01 10:28:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 10:28:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 10:28:19 --> Encryption Class Initialized
INFO - 2021-07-01 10:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:28:19 --> Model "vendor_model" initialized
INFO - 2021-07-01 10:28:19 --> Model "coupon_model" initialized
INFO - 2021-07-01 10:28:19 --> Form Validation Class Initialized
INFO - 2021-07-01 10:28:19 --> Model "user_model" initialized
INFO - 2021-07-01 10:28:19 --> Model "role_model" initialized
INFO - 2021-07-01 10:28:19 --> Controller Class Initialized
DEBUG - 2021-07-01 10:28:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 10:28:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 10:28:19 --> Encryption Class Initialized
INFO - 2021-07-01 10:28:19 --> Helper loaded: language_helper
INFO - 2021-07-01 10:28:19 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 10:28:19 --> Model "Quotation_model" initialized
INFO - 2021-07-01 10:28:19 --> Final output sent to browser
DEBUG - 2021-07-01 10:28:19 --> Total execution time: 0.0734
INFO - 2021-07-01 10:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:28:19 --> Model "vendor_model" initialized
INFO - 2021-07-01 10:28:19 --> Model "coupon_model" initialized
INFO - 2021-07-01 10:28:19 --> Model "user_model" initialized
INFO - 2021-07-01 10:28:19 --> Model "role_model" initialized
INFO - 2021-07-01 10:28:19 --> Controller Class Initialized
INFO - 2021-07-01 10:28:19 --> Helper loaded: language_helper
INFO - 2021-07-01 10:28:19 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 10:28:19 --> Model "Quotation_model" initialized
INFO - 2021-07-01 10:28:19 --> Final output sent to browser
DEBUG - 2021-07-01 10:28:19 --> Total execution time: 0.0827
INFO - 2021-07-01 10:29:17 --> Config Class Initialized
INFO - 2021-07-01 10:29:17 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:29:17 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:29:17 --> Utf8 Class Initialized
INFO - 2021-07-01 10:29:17 --> URI Class Initialized
INFO - 2021-07-01 10:29:17 --> Router Class Initialized
INFO - 2021-07-01 10:29:17 --> Output Class Initialized
INFO - 2021-07-01 10:29:17 --> Security Class Initialized
DEBUG - 2021-07-01 10:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:29:17 --> Input Class Initialized
INFO - 2021-07-01 10:29:17 --> Language Class Initialized
INFO - 2021-07-01 10:29:17 --> Loader Class Initialized
INFO - 2021-07-01 10:29:17 --> Helper loaded: html_helper
INFO - 2021-07-01 10:29:17 --> Helper loaded: url_helper
INFO - 2021-07-01 10:29:17 --> Helper loaded: form_helper
INFO - 2021-07-01 10:29:17 --> Database Driver Class Initialized
INFO - 2021-07-01 10:29:17 --> Form Validation Class Initialized
DEBUG - 2021-07-01 10:29:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 10:29:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 10:29:17 --> Encryption Class Initialized
INFO - 2021-07-01 10:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:29:17 --> Model "vendor_model" initialized
INFO - 2021-07-01 10:29:17 --> Model "coupon_model" initialized
INFO - 2021-07-01 10:29:17 --> Model "user_model" initialized
INFO - 2021-07-01 10:29:17 --> Model "role_model" initialized
INFO - 2021-07-01 10:29:17 --> Controller Class Initialized
INFO - 2021-07-01 10:29:17 --> Helper loaded: language_helper
INFO - 2021-07-01 10:29:17 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 10:29:17 --> Model "Quotation_model" initialized
INFO - 2021-07-01 10:29:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 10:29:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 10:29:17 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 10:29:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 10:29:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 10:29:17 --> Final output sent to browser
DEBUG - 2021-07-01 10:29:17 --> Total execution time: 0.0795
INFO - 2021-07-01 10:29:22 --> Config Class Initialized
INFO - 2021-07-01 10:29:22 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:29:22 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:29:22 --> Utf8 Class Initialized
INFO - 2021-07-01 10:29:22 --> URI Class Initialized
INFO - 2021-07-01 10:29:22 --> Router Class Initialized
INFO - 2021-07-01 10:29:22 --> Output Class Initialized
INFO - 2021-07-01 10:29:22 --> Security Class Initialized
DEBUG - 2021-07-01 10:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:29:22 --> Input Class Initialized
INFO - 2021-07-01 10:29:22 --> Language Class Initialized
INFO - 2021-07-01 10:29:22 --> Loader Class Initialized
INFO - 2021-07-01 10:29:22 --> Helper loaded: html_helper
INFO - 2021-07-01 10:29:22 --> Helper loaded: url_helper
INFO - 2021-07-01 10:29:22 --> Helper loaded: form_helper
INFO - 2021-07-01 10:29:22 --> Database Driver Class Initialized
INFO - 2021-07-01 10:29:22 --> Form Validation Class Initialized
DEBUG - 2021-07-01 10:29:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 10:29:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 10:29:22 --> Encryption Class Initialized
INFO - 2021-07-01 10:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:29:22 --> Model "vendor_model" initialized
INFO - 2021-07-01 10:29:22 --> Model "coupon_model" initialized
INFO - 2021-07-01 10:29:22 --> Model "user_model" initialized
INFO - 2021-07-01 10:29:22 --> Model "role_model" initialized
INFO - 2021-07-01 10:29:22 --> Controller Class Initialized
INFO - 2021-07-01 10:29:22 --> Helper loaded: language_helper
INFO - 2021-07-01 10:29:22 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 10:29:22 --> Model "Customer_model" initialized
INFO - 2021-07-01 10:29:22 --> Model "Product_model" initialized
INFO - 2021-07-01 10:29:22 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 10:29:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 10:29:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 10:29:22 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 10:29:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 10:29:22 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 10:29:22 --> Final output sent to browser
DEBUG - 2021-07-01 10:29:22 --> Total execution time: 0.1410
INFO - 2021-07-01 10:29:24 --> Config Class Initialized
INFO - 2021-07-01 10:29:24 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:29:24 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:29:24 --> Utf8 Class Initialized
INFO - 2021-07-01 10:29:24 --> URI Class Initialized
INFO - 2021-07-01 10:29:24 --> Router Class Initialized
INFO - 2021-07-01 10:29:24 --> Output Class Initialized
INFO - 2021-07-01 10:29:24 --> Security Class Initialized
DEBUG - 2021-07-01 10:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:29:24 --> Input Class Initialized
INFO - 2021-07-01 10:29:24 --> Language Class Initialized
INFO - 2021-07-01 10:29:24 --> Loader Class Initialized
INFO - 2021-07-01 10:29:24 --> Helper loaded: html_helper
INFO - 2021-07-01 10:29:24 --> Helper loaded: url_helper
INFO - 2021-07-01 10:29:24 --> Helper loaded: form_helper
INFO - 2021-07-01 10:29:24 --> Database Driver Class Initialized
INFO - 2021-07-01 10:29:24 --> Form Validation Class Initialized
DEBUG - 2021-07-01 10:29:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 10:29:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 10:29:24 --> Encryption Class Initialized
INFO - 2021-07-01 10:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:29:24 --> Model "vendor_model" initialized
INFO - 2021-07-01 10:29:24 --> Model "coupon_model" initialized
INFO - 2021-07-01 10:29:24 --> Model "user_model" initialized
INFO - 2021-07-01 10:29:24 --> Model "role_model" initialized
INFO - 2021-07-01 10:29:24 --> Controller Class Initialized
INFO - 2021-07-01 10:29:24 --> Helper loaded: language_helper
INFO - 2021-07-01 10:29:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 10:29:24 --> Model "Customer_model" initialized
INFO - 2021-07-01 10:29:24 --> Model "Product_model" initialized
INFO - 2021-07-01 10:29:24 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 10:29:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 10:29:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 10:29:24 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 10:29:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 10:29:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 10:29:24 --> Final output sent to browser
DEBUG - 2021-07-01 10:29:24 --> Total execution time: 0.0783
INFO - 2021-07-01 10:29:33 --> Config Class Initialized
INFO - 2021-07-01 10:29:33 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:29:33 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:29:33 --> Utf8 Class Initialized
INFO - 2021-07-01 10:29:33 --> URI Class Initialized
INFO - 2021-07-01 10:29:33 --> Router Class Initialized
INFO - 2021-07-01 10:29:33 --> Output Class Initialized
INFO - 2021-07-01 10:29:33 --> Security Class Initialized
DEBUG - 2021-07-01 10:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:29:33 --> Input Class Initialized
INFO - 2021-07-01 10:29:33 --> Language Class Initialized
INFO - 2021-07-01 10:29:33 --> Loader Class Initialized
INFO - 2021-07-01 10:29:33 --> Helper loaded: html_helper
INFO - 2021-07-01 10:29:33 --> Helper loaded: url_helper
INFO - 2021-07-01 10:29:33 --> Helper loaded: form_helper
INFO - 2021-07-01 10:29:33 --> Database Driver Class Initialized
INFO - 2021-07-01 10:29:33 --> Form Validation Class Initialized
DEBUG - 2021-07-01 10:29:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 10:29:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 10:29:33 --> Encryption Class Initialized
INFO - 2021-07-01 10:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:29:33 --> Model "vendor_model" initialized
INFO - 2021-07-01 10:29:33 --> Model "coupon_model" initialized
INFO - 2021-07-01 10:29:33 --> Model "user_model" initialized
INFO - 2021-07-01 10:29:33 --> Model "role_model" initialized
INFO - 2021-07-01 10:29:33 --> Controller Class Initialized
INFO - 2021-07-01 10:29:33 --> Helper loaded: language_helper
INFO - 2021-07-01 10:29:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 10:29:33 --> Model "Customer_model" initialized
INFO - 2021-07-01 10:29:33 --> Model "Product_model" initialized
INFO - 2021-07-01 10:29:33 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 10:29:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 10:29:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 10:29:33 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 10:29:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 10:29:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 10:29:33 --> Final output sent to browser
DEBUG - 2021-07-01 10:29:33 --> Total execution time: 0.0794
INFO - 2021-07-01 10:52:48 --> Config Class Initialized
INFO - 2021-07-01 10:52:48 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:52:48 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:52:48 --> Utf8 Class Initialized
INFO - 2021-07-01 10:52:48 --> URI Class Initialized
INFO - 2021-07-01 10:52:49 --> Router Class Initialized
INFO - 2021-07-01 10:52:49 --> Output Class Initialized
INFO - 2021-07-01 10:52:49 --> Security Class Initialized
DEBUG - 2021-07-01 10:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:52:49 --> Input Class Initialized
INFO - 2021-07-01 10:52:49 --> Language Class Initialized
INFO - 2021-07-01 10:52:49 --> Loader Class Initialized
INFO - 2021-07-01 10:52:49 --> Helper loaded: html_helper
INFO - 2021-07-01 10:52:49 --> Helper loaded: url_helper
INFO - 2021-07-01 10:52:49 --> Helper loaded: form_helper
INFO - 2021-07-01 10:52:49 --> Database Driver Class Initialized
INFO - 2021-07-01 10:52:49 --> Form Validation Class Initialized
DEBUG - 2021-07-01 10:52:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 10:52:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 10:52:49 --> Encryption Class Initialized
INFO - 2021-07-01 10:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:52:49 --> Model "vendor_model" initialized
INFO - 2021-07-01 10:52:49 --> Model "coupon_model" initialized
INFO - 2021-07-01 10:52:49 --> Model "user_model" initialized
INFO - 2021-07-01 10:52:49 --> Model "role_model" initialized
INFO - 2021-07-01 10:52:49 --> Controller Class Initialized
INFO - 2021-07-01 10:52:49 --> Helper loaded: language_helper
INFO - 2021-07-01 10:52:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 10:52:49 --> Model "Customer_model" initialized
INFO - 2021-07-01 10:52:49 --> Model "Product_model" initialized
INFO - 2021-07-01 10:52:49 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 10:52:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 10:52:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 10:52:49 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 10:52:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 10:52:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 10:52:49 --> Final output sent to browser
DEBUG - 2021-07-01 10:52:49 --> Total execution time: 0.1748
INFO - 2021-07-01 10:52:50 --> Config Class Initialized
INFO - 2021-07-01 10:52:50 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:52:50 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:52:50 --> Utf8 Class Initialized
INFO - 2021-07-01 10:52:50 --> URI Class Initialized
INFO - 2021-07-01 10:52:50 --> Router Class Initialized
INFO - 2021-07-01 10:52:50 --> Output Class Initialized
INFO - 2021-07-01 10:52:50 --> Security Class Initialized
DEBUG - 2021-07-01 10:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:52:50 --> Input Class Initialized
INFO - 2021-07-01 10:52:50 --> Language Class Initialized
INFO - 2021-07-01 10:52:50 --> Loader Class Initialized
INFO - 2021-07-01 10:52:50 --> Helper loaded: html_helper
INFO - 2021-07-01 10:52:50 --> Helper loaded: url_helper
INFO - 2021-07-01 10:52:50 --> Helper loaded: form_helper
INFO - 2021-07-01 10:52:50 --> Database Driver Class Initialized
INFO - 2021-07-01 10:52:50 --> Form Validation Class Initialized
DEBUG - 2021-07-01 10:52:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 10:52:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 10:52:50 --> Encryption Class Initialized
INFO - 2021-07-01 10:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:52:50 --> Model "vendor_model" initialized
INFO - 2021-07-01 10:52:50 --> Model "coupon_model" initialized
INFO - 2021-07-01 10:52:50 --> Model "user_model" initialized
INFO - 2021-07-01 10:52:50 --> Model "role_model" initialized
INFO - 2021-07-01 10:52:50 --> Controller Class Initialized
INFO - 2021-07-01 10:52:50 --> Helper loaded: language_helper
INFO - 2021-07-01 10:52:50 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 10:52:50 --> Model "Customer_model" initialized
INFO - 2021-07-01 10:52:50 --> Model "Product_model" initialized
INFO - 2021-07-01 10:52:50 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 10:52:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 10:52:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 10:52:50 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 10:52:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 10:52:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 10:52:50 --> Final output sent to browser
DEBUG - 2021-07-01 10:52:50 --> Total execution time: 0.0979
INFO - 2021-07-01 10:52:51 --> Config Class Initialized
INFO - 2021-07-01 10:52:51 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:52:51 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:52:51 --> Utf8 Class Initialized
INFO - 2021-07-01 10:52:51 --> URI Class Initialized
INFO - 2021-07-01 10:52:51 --> Router Class Initialized
INFO - 2021-07-01 10:52:51 --> Output Class Initialized
INFO - 2021-07-01 10:52:51 --> Security Class Initialized
DEBUG - 2021-07-01 10:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:52:51 --> Input Class Initialized
INFO - 2021-07-01 10:52:51 --> Language Class Initialized
INFO - 2021-07-01 10:52:51 --> Loader Class Initialized
INFO - 2021-07-01 10:52:51 --> Helper loaded: html_helper
INFO - 2021-07-01 10:52:51 --> Helper loaded: url_helper
INFO - 2021-07-01 10:52:51 --> Helper loaded: form_helper
INFO - 2021-07-01 10:52:51 --> Database Driver Class Initialized
INFO - 2021-07-01 10:52:51 --> Form Validation Class Initialized
DEBUG - 2021-07-01 10:52:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 10:52:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 10:52:51 --> Encryption Class Initialized
INFO - 2021-07-01 10:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:52:51 --> Model "vendor_model" initialized
INFO - 2021-07-01 10:52:51 --> Model "coupon_model" initialized
INFO - 2021-07-01 10:52:51 --> Model "user_model" initialized
INFO - 2021-07-01 10:52:51 --> Model "role_model" initialized
INFO - 2021-07-01 10:52:51 --> Controller Class Initialized
INFO - 2021-07-01 10:52:51 --> Helper loaded: language_helper
INFO - 2021-07-01 10:52:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 10:52:51 --> Model "Customer_model" initialized
INFO - 2021-07-01 10:52:51 --> Model "Product_model" initialized
INFO - 2021-07-01 10:52:51 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 10:52:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 10:52:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 10:52:51 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 10:52:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 10:52:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 10:52:51 --> Final output sent to browser
DEBUG - 2021-07-01 10:52:51 --> Total execution time: 0.2919
INFO - 2021-07-01 10:53:51 --> Config Class Initialized
INFO - 2021-07-01 10:53:51 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:53:51 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:53:51 --> Utf8 Class Initialized
INFO - 2021-07-01 10:53:51 --> URI Class Initialized
INFO - 2021-07-01 10:53:51 --> Router Class Initialized
INFO - 2021-07-01 10:53:51 --> Output Class Initialized
INFO - 2021-07-01 10:53:51 --> Security Class Initialized
DEBUG - 2021-07-01 10:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:53:51 --> Input Class Initialized
INFO - 2021-07-01 10:53:51 --> Language Class Initialized
INFO - 2021-07-01 10:53:51 --> Loader Class Initialized
INFO - 2021-07-01 10:53:51 --> Helper loaded: html_helper
INFO - 2021-07-01 10:53:51 --> Helper loaded: url_helper
INFO - 2021-07-01 10:53:51 --> Helper loaded: form_helper
INFO - 2021-07-01 10:53:51 --> Database Driver Class Initialized
INFO - 2021-07-01 10:53:51 --> Form Validation Class Initialized
DEBUG - 2021-07-01 10:53:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 10:53:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 10:53:51 --> Encryption Class Initialized
INFO - 2021-07-01 10:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:53:51 --> Model "vendor_model" initialized
INFO - 2021-07-01 10:53:51 --> Model "coupon_model" initialized
INFO - 2021-07-01 10:53:51 --> Model "user_model" initialized
INFO - 2021-07-01 10:53:51 --> Model "role_model" initialized
INFO - 2021-07-01 10:53:51 --> Controller Class Initialized
INFO - 2021-07-01 10:53:51 --> Helper loaded: language_helper
INFO - 2021-07-01 10:53:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 10:53:51 --> Model "Customer_model" initialized
INFO - 2021-07-01 10:53:51 --> Model "Product_model" initialized
INFO - 2021-07-01 10:53:51 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 10:53:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 10:53:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 10:53:51 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 10:53:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 10:53:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 10:53:51 --> Final output sent to browser
DEBUG - 2021-07-01 10:53:51 --> Total execution time: 0.0810
INFO - 2021-07-01 10:53:52 --> Config Class Initialized
INFO - 2021-07-01 10:53:52 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:53:52 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:53:52 --> Utf8 Class Initialized
INFO - 2021-07-01 10:53:52 --> URI Class Initialized
INFO - 2021-07-01 10:53:52 --> Router Class Initialized
INFO - 2021-07-01 10:53:52 --> Output Class Initialized
INFO - 2021-07-01 10:53:52 --> Security Class Initialized
DEBUG - 2021-07-01 10:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:53:52 --> Input Class Initialized
INFO - 2021-07-01 10:53:52 --> Language Class Initialized
INFO - 2021-07-01 10:53:52 --> Loader Class Initialized
INFO - 2021-07-01 10:53:52 --> Helper loaded: html_helper
INFO - 2021-07-01 10:53:52 --> Helper loaded: url_helper
INFO - 2021-07-01 10:53:52 --> Helper loaded: form_helper
INFO - 2021-07-01 10:53:52 --> Database Driver Class Initialized
INFO - 2021-07-01 10:53:52 --> Form Validation Class Initialized
DEBUG - 2021-07-01 10:53:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 10:53:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 10:53:52 --> Encryption Class Initialized
INFO - 2021-07-01 10:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:53:52 --> Model "vendor_model" initialized
INFO - 2021-07-01 10:53:52 --> Model "coupon_model" initialized
INFO - 2021-07-01 10:53:52 --> Model "user_model" initialized
INFO - 2021-07-01 10:53:52 --> Model "role_model" initialized
INFO - 2021-07-01 10:53:52 --> Controller Class Initialized
INFO - 2021-07-01 10:53:52 --> Helper loaded: language_helper
INFO - 2021-07-01 10:53:52 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 10:53:52 --> Model "Customer_model" initialized
INFO - 2021-07-01 10:53:52 --> Model "Product_model" initialized
INFO - 2021-07-01 10:53:52 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 10:53:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 10:53:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 10:53:52 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 10:53:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 10:53:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 10:53:52 --> Final output sent to browser
DEBUG - 2021-07-01 10:53:52 --> Total execution time: 0.0838
INFO - 2021-07-01 10:53:53 --> Config Class Initialized
INFO - 2021-07-01 10:53:53 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:53:53 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:53:53 --> Utf8 Class Initialized
INFO - 2021-07-01 10:53:53 --> URI Class Initialized
INFO - 2021-07-01 10:53:53 --> Router Class Initialized
INFO - 2021-07-01 10:53:53 --> Output Class Initialized
INFO - 2021-07-01 10:53:53 --> Security Class Initialized
DEBUG - 2021-07-01 10:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:53:53 --> Input Class Initialized
INFO - 2021-07-01 10:53:53 --> Language Class Initialized
INFO - 2021-07-01 10:53:53 --> Loader Class Initialized
INFO - 2021-07-01 10:53:53 --> Helper loaded: html_helper
INFO - 2021-07-01 10:53:53 --> Helper loaded: url_helper
INFO - 2021-07-01 10:53:53 --> Helper loaded: form_helper
INFO - 2021-07-01 10:53:53 --> Database Driver Class Initialized
INFO - 2021-07-01 10:53:53 --> Form Validation Class Initialized
DEBUG - 2021-07-01 10:53:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 10:53:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 10:53:53 --> Encryption Class Initialized
INFO - 2021-07-01 10:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:53:53 --> Model "vendor_model" initialized
INFO - 2021-07-01 10:53:53 --> Model "coupon_model" initialized
INFO - 2021-07-01 10:53:53 --> Model "user_model" initialized
INFO - 2021-07-01 10:53:53 --> Model "role_model" initialized
INFO - 2021-07-01 10:53:53 --> Controller Class Initialized
INFO - 2021-07-01 10:53:53 --> Helper loaded: language_helper
INFO - 2021-07-01 10:53:53 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 10:53:53 --> Model "Customer_model" initialized
INFO - 2021-07-01 10:53:53 --> Model "Product_model" initialized
INFO - 2021-07-01 10:53:53 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 10:53:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 10:53:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 10:53:53 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 10:53:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 10:53:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 10:53:53 --> Final output sent to browser
DEBUG - 2021-07-01 10:53:53 --> Total execution time: 0.0887
INFO - 2021-07-01 10:54:49 --> Config Class Initialized
INFO - 2021-07-01 10:54:49 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:54:49 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:54:49 --> Utf8 Class Initialized
INFO - 2021-07-01 10:54:49 --> URI Class Initialized
INFO - 2021-07-01 10:54:49 --> Router Class Initialized
INFO - 2021-07-01 10:54:49 --> Output Class Initialized
INFO - 2021-07-01 10:54:49 --> Security Class Initialized
DEBUG - 2021-07-01 10:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:54:49 --> Input Class Initialized
INFO - 2021-07-01 10:54:49 --> Language Class Initialized
INFO - 2021-07-01 10:54:49 --> Loader Class Initialized
INFO - 2021-07-01 10:54:49 --> Helper loaded: html_helper
INFO - 2021-07-01 10:54:49 --> Helper loaded: url_helper
INFO - 2021-07-01 10:54:49 --> Helper loaded: form_helper
INFO - 2021-07-01 10:54:49 --> Database Driver Class Initialized
INFO - 2021-07-01 10:54:49 --> Form Validation Class Initialized
DEBUG - 2021-07-01 10:54:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 10:54:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 10:54:49 --> Encryption Class Initialized
INFO - 2021-07-01 10:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:54:49 --> Model "vendor_model" initialized
INFO - 2021-07-01 10:54:49 --> Model "coupon_model" initialized
INFO - 2021-07-01 10:54:49 --> Model "user_model" initialized
INFO - 2021-07-01 10:54:49 --> Model "role_model" initialized
INFO - 2021-07-01 10:54:49 --> Controller Class Initialized
INFO - 2021-07-01 10:54:49 --> Helper loaded: language_helper
INFO - 2021-07-01 10:54:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 10:54:49 --> Model "Customer_model" initialized
INFO - 2021-07-01 10:54:49 --> Model "Product_model" initialized
INFO - 2021-07-01 10:54:49 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 10:54:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 10:54:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 10:54:49 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 10:54:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 10:54:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 10:54:49 --> Final output sent to browser
DEBUG - 2021-07-01 10:54:49 --> Total execution time: 0.0789
INFO - 2021-07-01 10:54:50 --> Config Class Initialized
INFO - 2021-07-01 10:54:50 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:54:50 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:54:50 --> Utf8 Class Initialized
INFO - 2021-07-01 10:54:50 --> URI Class Initialized
INFO - 2021-07-01 10:54:50 --> Router Class Initialized
INFO - 2021-07-01 10:54:50 --> Output Class Initialized
INFO - 2021-07-01 10:54:50 --> Security Class Initialized
DEBUG - 2021-07-01 10:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:54:50 --> Input Class Initialized
INFO - 2021-07-01 10:54:50 --> Language Class Initialized
INFO - 2021-07-01 10:54:50 --> Loader Class Initialized
INFO - 2021-07-01 10:54:50 --> Helper loaded: html_helper
INFO - 2021-07-01 10:54:50 --> Helper loaded: url_helper
INFO - 2021-07-01 10:54:50 --> Helper loaded: form_helper
INFO - 2021-07-01 10:54:50 --> Database Driver Class Initialized
INFO - 2021-07-01 10:54:50 --> Form Validation Class Initialized
DEBUG - 2021-07-01 10:54:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 10:54:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 10:54:50 --> Encryption Class Initialized
INFO - 2021-07-01 10:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:54:50 --> Model "vendor_model" initialized
INFO - 2021-07-01 10:54:50 --> Model "coupon_model" initialized
INFO - 2021-07-01 10:54:50 --> Model "user_model" initialized
INFO - 2021-07-01 10:54:50 --> Model "role_model" initialized
INFO - 2021-07-01 10:54:50 --> Controller Class Initialized
INFO - 2021-07-01 10:54:50 --> Helper loaded: language_helper
INFO - 2021-07-01 10:54:50 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 10:54:50 --> Model "Customer_model" initialized
INFO - 2021-07-01 10:54:50 --> Model "Product_model" initialized
INFO - 2021-07-01 10:54:50 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 10:54:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 10:54:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 10:54:50 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 10:54:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 10:54:50 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 10:54:50 --> Final output sent to browser
DEBUG - 2021-07-01 10:54:50 --> Total execution time: 0.0817
INFO - 2021-07-01 10:54:51 --> Config Class Initialized
INFO - 2021-07-01 10:54:51 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:54:51 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:54:51 --> Utf8 Class Initialized
INFO - 2021-07-01 10:54:51 --> URI Class Initialized
INFO - 2021-07-01 10:54:51 --> Router Class Initialized
INFO - 2021-07-01 10:54:51 --> Output Class Initialized
INFO - 2021-07-01 10:54:51 --> Security Class Initialized
DEBUG - 2021-07-01 10:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:54:51 --> Input Class Initialized
INFO - 2021-07-01 10:54:51 --> Language Class Initialized
INFO - 2021-07-01 10:54:51 --> Loader Class Initialized
INFO - 2021-07-01 10:54:51 --> Helper loaded: html_helper
INFO - 2021-07-01 10:54:51 --> Helper loaded: url_helper
INFO - 2021-07-01 10:54:51 --> Helper loaded: form_helper
INFO - 2021-07-01 10:54:51 --> Database Driver Class Initialized
INFO - 2021-07-01 10:54:51 --> Form Validation Class Initialized
DEBUG - 2021-07-01 10:54:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 10:54:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 10:54:51 --> Encryption Class Initialized
INFO - 2021-07-01 10:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:54:51 --> Model "vendor_model" initialized
INFO - 2021-07-01 10:54:51 --> Model "coupon_model" initialized
INFO - 2021-07-01 10:54:51 --> Model "user_model" initialized
INFO - 2021-07-01 10:54:51 --> Model "role_model" initialized
INFO - 2021-07-01 10:54:51 --> Controller Class Initialized
INFO - 2021-07-01 10:54:51 --> Helper loaded: language_helper
INFO - 2021-07-01 10:54:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 10:54:51 --> Model "Customer_model" initialized
INFO - 2021-07-01 10:54:51 --> Model "Product_model" initialized
INFO - 2021-07-01 10:54:51 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 10:54:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 10:54:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 10:54:51 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 10:54:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 10:54:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 10:54:51 --> Final output sent to browser
DEBUG - 2021-07-01 10:54:51 --> Total execution time: 0.0755
INFO - 2021-07-01 10:54:52 --> Config Class Initialized
INFO - 2021-07-01 10:54:52 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:54:52 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:54:52 --> Utf8 Class Initialized
INFO - 2021-07-01 10:54:52 --> URI Class Initialized
INFO - 2021-07-01 10:54:52 --> Router Class Initialized
INFO - 2021-07-01 10:54:52 --> Output Class Initialized
INFO - 2021-07-01 10:54:52 --> Security Class Initialized
DEBUG - 2021-07-01 10:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:54:52 --> Input Class Initialized
INFO - 2021-07-01 10:54:52 --> Language Class Initialized
INFO - 2021-07-01 10:54:52 --> Loader Class Initialized
INFO - 2021-07-01 10:54:52 --> Helper loaded: html_helper
INFO - 2021-07-01 10:54:52 --> Helper loaded: url_helper
INFO - 2021-07-01 10:54:52 --> Helper loaded: form_helper
INFO - 2021-07-01 10:54:52 --> Database Driver Class Initialized
INFO - 2021-07-01 10:54:52 --> Form Validation Class Initialized
DEBUG - 2021-07-01 10:54:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 10:54:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 10:54:52 --> Encryption Class Initialized
INFO - 2021-07-01 10:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:54:52 --> Model "vendor_model" initialized
INFO - 2021-07-01 10:54:52 --> Model "coupon_model" initialized
INFO - 2021-07-01 10:54:52 --> Model "user_model" initialized
INFO - 2021-07-01 10:54:52 --> Model "role_model" initialized
INFO - 2021-07-01 10:54:52 --> Controller Class Initialized
INFO - 2021-07-01 10:54:52 --> Helper loaded: language_helper
INFO - 2021-07-01 10:54:52 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 10:54:52 --> Model "Customer_model" initialized
INFO - 2021-07-01 10:54:52 --> Model "Product_model" initialized
INFO - 2021-07-01 10:54:52 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 10:54:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 10:54:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 10:54:52 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 10:54:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 10:54:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 10:54:52 --> Final output sent to browser
DEBUG - 2021-07-01 10:54:52 --> Total execution time: 0.0832
INFO - 2021-07-01 10:56:33 --> Config Class Initialized
INFO - 2021-07-01 10:56:33 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:56:33 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:56:33 --> Utf8 Class Initialized
INFO - 2021-07-01 10:56:33 --> URI Class Initialized
INFO - 2021-07-01 10:56:33 --> Router Class Initialized
INFO - 2021-07-01 10:56:33 --> Output Class Initialized
INFO - 2021-07-01 10:56:33 --> Security Class Initialized
DEBUG - 2021-07-01 10:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:56:33 --> Input Class Initialized
INFO - 2021-07-01 10:56:33 --> Language Class Initialized
INFO - 2021-07-01 10:56:33 --> Loader Class Initialized
INFO - 2021-07-01 10:56:33 --> Helper loaded: html_helper
INFO - 2021-07-01 10:56:33 --> Helper loaded: url_helper
INFO - 2021-07-01 10:56:33 --> Helper loaded: form_helper
INFO - 2021-07-01 10:56:33 --> Database Driver Class Initialized
INFO - 2021-07-01 10:56:33 --> Form Validation Class Initialized
DEBUG - 2021-07-01 10:56:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 10:56:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 10:56:33 --> Encryption Class Initialized
INFO - 2021-07-01 10:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:56:33 --> Model "vendor_model" initialized
INFO - 2021-07-01 10:56:33 --> Model "coupon_model" initialized
INFO - 2021-07-01 10:56:33 --> Model "user_model" initialized
INFO - 2021-07-01 10:56:33 --> Model "role_model" initialized
INFO - 2021-07-01 10:56:33 --> Controller Class Initialized
INFO - 2021-07-01 10:56:33 --> Helper loaded: language_helper
INFO - 2021-07-01 10:56:33 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 10:56:33 --> Model "Customer_model" initialized
INFO - 2021-07-01 10:56:33 --> Model "Product_model" initialized
INFO - 2021-07-01 10:56:33 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 10:56:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 10:56:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 10:56:33 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 10:56:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 10:56:33 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 10:56:33 --> Final output sent to browser
DEBUG - 2021-07-01 10:56:33 --> Total execution time: 0.0954
INFO - 2021-07-01 10:58:23 --> Config Class Initialized
INFO - 2021-07-01 10:58:23 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:58:23 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:58:23 --> Utf8 Class Initialized
INFO - 2021-07-01 10:58:23 --> URI Class Initialized
INFO - 2021-07-01 10:58:23 --> Router Class Initialized
INFO - 2021-07-01 10:58:23 --> Output Class Initialized
INFO - 2021-07-01 10:58:23 --> Security Class Initialized
DEBUG - 2021-07-01 10:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:58:23 --> Input Class Initialized
INFO - 2021-07-01 10:58:23 --> Language Class Initialized
INFO - 2021-07-01 10:58:23 --> Loader Class Initialized
INFO - 2021-07-01 10:58:23 --> Helper loaded: html_helper
INFO - 2021-07-01 10:58:23 --> Helper loaded: url_helper
INFO - 2021-07-01 10:58:23 --> Helper loaded: form_helper
INFO - 2021-07-01 10:58:23 --> Database Driver Class Initialized
INFO - 2021-07-01 10:58:23 --> Form Validation Class Initialized
DEBUG - 2021-07-01 10:58:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 10:58:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 10:58:23 --> Encryption Class Initialized
INFO - 2021-07-01 10:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:58:23 --> Model "vendor_model" initialized
INFO - 2021-07-01 10:58:23 --> Model "coupon_model" initialized
INFO - 2021-07-01 10:58:23 --> Model "user_model" initialized
INFO - 2021-07-01 10:58:23 --> Model "role_model" initialized
INFO - 2021-07-01 10:58:23 --> Controller Class Initialized
INFO - 2021-07-01 10:58:23 --> Helper loaded: language_helper
INFO - 2021-07-01 10:58:23 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 10:58:23 --> Model "Customer_model" initialized
INFO - 2021-07-01 10:58:23 --> Model "Product_model" initialized
INFO - 2021-07-01 10:58:23 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 10:58:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 10:58:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 10:58:23 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 10:58:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 10:58:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 10:58:23 --> Final output sent to browser
DEBUG - 2021-07-01 10:58:23 --> Total execution time: 0.0822
INFO - 2021-07-01 11:00:55 --> Config Class Initialized
INFO - 2021-07-01 11:00:55 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:00:55 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:00:55 --> Utf8 Class Initialized
INFO - 2021-07-01 11:00:55 --> URI Class Initialized
INFO - 2021-07-01 11:00:55 --> Router Class Initialized
INFO - 2021-07-01 11:00:55 --> Output Class Initialized
INFO - 2021-07-01 11:00:55 --> Security Class Initialized
DEBUG - 2021-07-01 11:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:00:55 --> Input Class Initialized
INFO - 2021-07-01 11:00:55 --> Language Class Initialized
INFO - 2021-07-01 11:00:55 --> Loader Class Initialized
INFO - 2021-07-01 11:00:55 --> Helper loaded: html_helper
INFO - 2021-07-01 11:00:55 --> Helper loaded: url_helper
INFO - 2021-07-01 11:00:55 --> Helper loaded: form_helper
INFO - 2021-07-01 11:00:55 --> Database Driver Class Initialized
INFO - 2021-07-01 11:00:55 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:00:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:00:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:00:55 --> Encryption Class Initialized
INFO - 2021-07-01 11:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:00:55 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:00:55 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:00:55 --> Model "user_model" initialized
INFO - 2021-07-01 11:00:55 --> Model "role_model" initialized
INFO - 2021-07-01 11:00:55 --> Controller Class Initialized
INFO - 2021-07-01 11:00:55 --> Helper loaded: language_helper
INFO - 2021-07-01 11:00:55 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:00:55 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:00:55 --> Model "Product_model" initialized
INFO - 2021-07-01 11:00:55 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:00:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:00:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:00:55 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:00:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:00:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:00:55 --> Final output sent to browser
DEBUG - 2021-07-01 11:00:55 --> Total execution time: 0.1780
INFO - 2021-07-01 11:18:13 --> Config Class Initialized
INFO - 2021-07-01 11:18:13 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:18:13 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:18:13 --> Utf8 Class Initialized
INFO - 2021-07-01 11:18:13 --> URI Class Initialized
INFO - 2021-07-01 11:18:13 --> Router Class Initialized
INFO - 2021-07-01 11:18:13 --> Output Class Initialized
INFO - 2021-07-01 11:18:13 --> Security Class Initialized
DEBUG - 2021-07-01 11:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:18:13 --> Input Class Initialized
INFO - 2021-07-01 11:18:13 --> Language Class Initialized
INFO - 2021-07-01 11:18:14 --> Loader Class Initialized
INFO - 2021-07-01 11:18:14 --> Helper loaded: html_helper
INFO - 2021-07-01 11:18:14 --> Helper loaded: url_helper
INFO - 2021-07-01 11:18:14 --> Helper loaded: form_helper
INFO - 2021-07-01 11:18:14 --> Database Driver Class Initialized
INFO - 2021-07-01 11:18:14 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:18:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:18:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:18:14 --> Encryption Class Initialized
INFO - 2021-07-01 11:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:18:14 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:18:14 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:18:14 --> Model "user_model" initialized
INFO - 2021-07-01 11:18:14 --> Model "role_model" initialized
INFO - 2021-07-01 11:18:14 --> Controller Class Initialized
INFO - 2021-07-01 11:18:14 --> Helper loaded: language_helper
INFO - 2021-07-01 11:18:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:18:14 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:18:14 --> Model "Product_model" initialized
INFO - 2021-07-01 11:18:14 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:18:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:18:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:18:14 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:18:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:18:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:18:14 --> Final output sent to browser
DEBUG - 2021-07-01 11:18:14 --> Total execution time: 0.3507
INFO - 2021-07-01 11:21:49 --> Config Class Initialized
INFO - 2021-07-01 11:21:49 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:21:49 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:21:49 --> Utf8 Class Initialized
INFO - 2021-07-01 11:21:49 --> URI Class Initialized
INFO - 2021-07-01 11:21:49 --> Router Class Initialized
INFO - 2021-07-01 11:21:49 --> Output Class Initialized
INFO - 2021-07-01 11:21:49 --> Security Class Initialized
DEBUG - 2021-07-01 11:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:21:49 --> Input Class Initialized
INFO - 2021-07-01 11:21:49 --> Language Class Initialized
INFO - 2021-07-01 11:21:49 --> Loader Class Initialized
INFO - 2021-07-01 11:21:49 --> Helper loaded: html_helper
INFO - 2021-07-01 11:21:49 --> Helper loaded: url_helper
INFO - 2021-07-01 11:21:49 --> Helper loaded: form_helper
INFO - 2021-07-01 11:21:49 --> Database Driver Class Initialized
INFO - 2021-07-01 11:21:49 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:21:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:21:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:21:49 --> Encryption Class Initialized
INFO - 2021-07-01 11:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:21:49 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:21:49 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:21:49 --> Model "user_model" initialized
INFO - 2021-07-01 11:21:49 --> Model "role_model" initialized
INFO - 2021-07-01 11:21:49 --> Controller Class Initialized
INFO - 2021-07-01 11:21:49 --> Helper loaded: language_helper
INFO - 2021-07-01 11:21:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:21:49 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:21:49 --> Model "Product_model" initialized
INFO - 2021-07-01 11:21:49 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:21:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:21:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:21:49 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:21:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:21:49 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:21:49 --> Final output sent to browser
DEBUG - 2021-07-01 11:21:49 --> Total execution time: 0.1267
INFO - 2021-07-01 11:21:51 --> Config Class Initialized
INFO - 2021-07-01 11:21:51 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:21:51 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:21:51 --> Utf8 Class Initialized
INFO - 2021-07-01 11:21:51 --> URI Class Initialized
INFO - 2021-07-01 11:21:51 --> Router Class Initialized
INFO - 2021-07-01 11:21:51 --> Output Class Initialized
INFO - 2021-07-01 11:21:51 --> Security Class Initialized
DEBUG - 2021-07-01 11:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:21:51 --> Input Class Initialized
INFO - 2021-07-01 11:21:51 --> Language Class Initialized
INFO - 2021-07-01 11:21:51 --> Loader Class Initialized
INFO - 2021-07-01 11:21:51 --> Helper loaded: html_helper
INFO - 2021-07-01 11:21:51 --> Helper loaded: url_helper
INFO - 2021-07-01 11:21:51 --> Helper loaded: form_helper
INFO - 2021-07-01 11:21:51 --> Database Driver Class Initialized
INFO - 2021-07-01 11:21:51 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:21:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:21:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:21:51 --> Encryption Class Initialized
INFO - 2021-07-01 11:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:21:51 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:21:51 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:21:51 --> Model "user_model" initialized
INFO - 2021-07-01 11:21:51 --> Model "role_model" initialized
INFO - 2021-07-01 11:21:51 --> Controller Class Initialized
INFO - 2021-07-01 11:21:51 --> Helper loaded: language_helper
INFO - 2021-07-01 11:21:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:21:51 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:21:51 --> Model "Product_model" initialized
INFO - 2021-07-01 11:21:51 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:21:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:21:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:21:51 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:21:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:21:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:21:51 --> Final output sent to browser
DEBUG - 2021-07-01 11:21:51 --> Total execution time: 0.0781
INFO - 2021-07-01 11:21:52 --> Config Class Initialized
INFO - 2021-07-01 11:21:52 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:21:52 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:21:52 --> Utf8 Class Initialized
INFO - 2021-07-01 11:21:52 --> URI Class Initialized
INFO - 2021-07-01 11:21:52 --> Router Class Initialized
INFO - 2021-07-01 11:21:52 --> Output Class Initialized
INFO - 2021-07-01 11:21:52 --> Security Class Initialized
DEBUG - 2021-07-01 11:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:21:52 --> Input Class Initialized
INFO - 2021-07-01 11:21:52 --> Language Class Initialized
INFO - 2021-07-01 11:21:52 --> Loader Class Initialized
INFO - 2021-07-01 11:21:52 --> Helper loaded: html_helper
INFO - 2021-07-01 11:21:52 --> Helper loaded: url_helper
INFO - 2021-07-01 11:21:52 --> Helper loaded: form_helper
INFO - 2021-07-01 11:21:52 --> Database Driver Class Initialized
INFO - 2021-07-01 11:21:52 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:21:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:21:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:21:52 --> Encryption Class Initialized
INFO - 2021-07-01 11:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:21:52 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:21:52 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:21:52 --> Model "user_model" initialized
INFO - 2021-07-01 11:21:52 --> Model "role_model" initialized
INFO - 2021-07-01 11:21:52 --> Controller Class Initialized
INFO - 2021-07-01 11:21:52 --> Helper loaded: language_helper
INFO - 2021-07-01 11:21:52 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:21:52 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:21:52 --> Model "Product_model" initialized
INFO - 2021-07-01 11:21:52 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:21:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:21:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:21:52 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:21:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:21:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:21:52 --> Final output sent to browser
DEBUG - 2021-07-01 11:21:52 --> Total execution time: 0.0775
INFO - 2021-07-01 11:21:53 --> Config Class Initialized
INFO - 2021-07-01 11:21:53 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:21:53 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:21:53 --> Utf8 Class Initialized
INFO - 2021-07-01 11:21:53 --> URI Class Initialized
INFO - 2021-07-01 11:21:53 --> Router Class Initialized
INFO - 2021-07-01 11:21:53 --> Output Class Initialized
INFO - 2021-07-01 11:21:53 --> Security Class Initialized
DEBUG - 2021-07-01 11:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:21:53 --> Input Class Initialized
INFO - 2021-07-01 11:21:53 --> Language Class Initialized
INFO - 2021-07-01 11:21:53 --> Loader Class Initialized
INFO - 2021-07-01 11:21:53 --> Helper loaded: html_helper
INFO - 2021-07-01 11:21:53 --> Helper loaded: url_helper
INFO - 2021-07-01 11:21:53 --> Helper loaded: form_helper
INFO - 2021-07-01 11:21:53 --> Database Driver Class Initialized
INFO - 2021-07-01 11:21:53 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:21:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:21:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:21:53 --> Encryption Class Initialized
INFO - 2021-07-01 11:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:21:53 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:21:53 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:21:53 --> Model "user_model" initialized
INFO - 2021-07-01 11:21:53 --> Model "role_model" initialized
INFO - 2021-07-01 11:21:53 --> Controller Class Initialized
INFO - 2021-07-01 11:21:53 --> Helper loaded: language_helper
INFO - 2021-07-01 11:21:53 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:21:53 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:21:53 --> Model "Product_model" initialized
INFO - 2021-07-01 11:21:53 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:21:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:21:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:21:53 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:21:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:21:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:21:53 --> Final output sent to browser
DEBUG - 2021-07-01 11:21:53 --> Total execution time: 0.0923
INFO - 2021-07-01 11:21:54 --> Config Class Initialized
INFO - 2021-07-01 11:21:54 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:21:54 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:21:54 --> Utf8 Class Initialized
INFO - 2021-07-01 11:21:54 --> URI Class Initialized
INFO - 2021-07-01 11:21:54 --> Router Class Initialized
INFO - 2021-07-01 11:21:54 --> Output Class Initialized
INFO - 2021-07-01 11:21:54 --> Security Class Initialized
DEBUG - 2021-07-01 11:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:21:54 --> Input Class Initialized
INFO - 2021-07-01 11:21:54 --> Language Class Initialized
INFO - 2021-07-01 11:21:54 --> Loader Class Initialized
INFO - 2021-07-01 11:21:54 --> Helper loaded: html_helper
INFO - 2021-07-01 11:21:54 --> Helper loaded: url_helper
INFO - 2021-07-01 11:21:54 --> Helper loaded: form_helper
INFO - 2021-07-01 11:21:54 --> Database Driver Class Initialized
INFO - 2021-07-01 11:21:54 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:21:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:21:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:21:54 --> Encryption Class Initialized
INFO - 2021-07-01 11:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:21:54 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:21:54 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:21:54 --> Model "user_model" initialized
INFO - 2021-07-01 11:21:54 --> Model "role_model" initialized
INFO - 2021-07-01 11:21:54 --> Controller Class Initialized
INFO - 2021-07-01 11:21:54 --> Helper loaded: language_helper
INFO - 2021-07-01 11:21:54 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:21:54 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:21:54 --> Model "Product_model" initialized
INFO - 2021-07-01 11:21:54 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:21:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:21:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:21:54 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:21:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:21:54 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:21:54 --> Final output sent to browser
DEBUG - 2021-07-01 11:21:54 --> Total execution time: 0.0731
INFO - 2021-07-01 11:21:55 --> Config Class Initialized
INFO - 2021-07-01 11:21:55 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:21:55 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:21:55 --> Utf8 Class Initialized
INFO - 2021-07-01 11:21:55 --> URI Class Initialized
INFO - 2021-07-01 11:21:55 --> Router Class Initialized
INFO - 2021-07-01 11:21:55 --> Output Class Initialized
INFO - 2021-07-01 11:21:55 --> Security Class Initialized
DEBUG - 2021-07-01 11:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:21:55 --> Input Class Initialized
INFO - 2021-07-01 11:21:55 --> Language Class Initialized
INFO - 2021-07-01 11:21:55 --> Loader Class Initialized
INFO - 2021-07-01 11:21:55 --> Helper loaded: html_helper
INFO - 2021-07-01 11:21:55 --> Helper loaded: url_helper
INFO - 2021-07-01 11:21:55 --> Helper loaded: form_helper
INFO - 2021-07-01 11:21:55 --> Database Driver Class Initialized
INFO - 2021-07-01 11:21:55 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:21:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:21:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:21:55 --> Encryption Class Initialized
INFO - 2021-07-01 11:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:21:55 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:21:55 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:21:55 --> Model "user_model" initialized
INFO - 2021-07-01 11:21:55 --> Model "role_model" initialized
INFO - 2021-07-01 11:21:55 --> Controller Class Initialized
INFO - 2021-07-01 11:21:55 --> Helper loaded: language_helper
INFO - 2021-07-01 11:21:55 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:21:55 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:21:55 --> Model "Product_model" initialized
INFO - 2021-07-01 11:21:55 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:21:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:21:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:21:55 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:21:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:21:55 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:21:55 --> Final output sent to browser
DEBUG - 2021-07-01 11:21:55 --> Total execution time: 0.0801
INFO - 2021-07-01 11:21:56 --> Config Class Initialized
INFO - 2021-07-01 11:21:56 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:21:56 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:21:56 --> Utf8 Class Initialized
INFO - 2021-07-01 11:21:56 --> URI Class Initialized
INFO - 2021-07-01 11:21:56 --> Router Class Initialized
INFO - 2021-07-01 11:21:56 --> Output Class Initialized
INFO - 2021-07-01 11:21:56 --> Security Class Initialized
DEBUG - 2021-07-01 11:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:21:56 --> Input Class Initialized
INFO - 2021-07-01 11:21:56 --> Language Class Initialized
INFO - 2021-07-01 11:21:56 --> Loader Class Initialized
INFO - 2021-07-01 11:21:56 --> Helper loaded: html_helper
INFO - 2021-07-01 11:21:56 --> Helper loaded: url_helper
INFO - 2021-07-01 11:21:56 --> Helper loaded: form_helper
INFO - 2021-07-01 11:21:56 --> Database Driver Class Initialized
INFO - 2021-07-01 11:21:56 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:21:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:21:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:21:56 --> Encryption Class Initialized
INFO - 2021-07-01 11:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:21:56 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:21:56 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:21:56 --> Model "user_model" initialized
INFO - 2021-07-01 11:21:56 --> Model "role_model" initialized
INFO - 2021-07-01 11:21:56 --> Controller Class Initialized
INFO - 2021-07-01 11:21:56 --> Helper loaded: language_helper
INFO - 2021-07-01 11:21:56 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:21:56 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:21:56 --> Model "Product_model" initialized
INFO - 2021-07-01 11:21:56 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:21:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:21:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:21:56 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:21:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:21:56 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:21:56 --> Final output sent to browser
DEBUG - 2021-07-01 11:21:56 --> Total execution time: 0.0794
INFO - 2021-07-01 11:24:24 --> Config Class Initialized
INFO - 2021-07-01 11:24:24 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:24:24 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:24:24 --> Utf8 Class Initialized
INFO - 2021-07-01 11:24:24 --> URI Class Initialized
INFO - 2021-07-01 11:24:24 --> Router Class Initialized
INFO - 2021-07-01 11:24:24 --> Output Class Initialized
INFO - 2021-07-01 11:24:24 --> Security Class Initialized
DEBUG - 2021-07-01 11:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:24:24 --> Input Class Initialized
INFO - 2021-07-01 11:24:24 --> Language Class Initialized
INFO - 2021-07-01 11:24:24 --> Loader Class Initialized
INFO - 2021-07-01 11:24:24 --> Helper loaded: html_helper
INFO - 2021-07-01 11:24:24 --> Helper loaded: url_helper
INFO - 2021-07-01 11:24:24 --> Helper loaded: form_helper
INFO - 2021-07-01 11:24:24 --> Database Driver Class Initialized
INFO - 2021-07-01 11:24:24 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:24:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:24:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:24:24 --> Encryption Class Initialized
INFO - 2021-07-01 11:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:24:24 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:24:24 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:24:24 --> Model "user_model" initialized
INFO - 2021-07-01 11:24:24 --> Model "role_model" initialized
INFO - 2021-07-01 11:24:24 --> Controller Class Initialized
INFO - 2021-07-01 11:24:24 --> Helper loaded: language_helper
INFO - 2021-07-01 11:24:24 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:24:24 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:24:24 --> Model "Product_model" initialized
INFO - 2021-07-01 11:24:24 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:24:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:24:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:24:24 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:24:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:24:24 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:24:24 --> Final output sent to browser
DEBUG - 2021-07-01 11:24:24 --> Total execution time: 0.0752
INFO - 2021-07-01 11:25:25 --> Config Class Initialized
INFO - 2021-07-01 11:25:25 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:25:25 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:25:25 --> Utf8 Class Initialized
INFO - 2021-07-01 11:25:25 --> URI Class Initialized
INFO - 2021-07-01 11:25:25 --> Router Class Initialized
INFO - 2021-07-01 11:25:25 --> Output Class Initialized
INFO - 2021-07-01 11:25:25 --> Security Class Initialized
DEBUG - 2021-07-01 11:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:25:25 --> Input Class Initialized
INFO - 2021-07-01 11:25:25 --> Language Class Initialized
INFO - 2021-07-01 11:25:25 --> Loader Class Initialized
INFO - 2021-07-01 11:25:25 --> Helper loaded: html_helper
INFO - 2021-07-01 11:25:25 --> Helper loaded: url_helper
INFO - 2021-07-01 11:25:25 --> Helper loaded: form_helper
INFO - 2021-07-01 11:25:25 --> Database Driver Class Initialized
INFO - 2021-07-01 11:25:25 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:25:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:25:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:25:25 --> Encryption Class Initialized
INFO - 2021-07-01 11:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:25:25 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:25:25 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:25:25 --> Model "user_model" initialized
INFO - 2021-07-01 11:25:25 --> Model "role_model" initialized
INFO - 2021-07-01 11:25:25 --> Controller Class Initialized
INFO - 2021-07-01 11:25:25 --> Helper loaded: language_helper
INFO - 2021-07-01 11:25:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:25:25 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:25:25 --> Model "Product_model" initialized
INFO - 2021-07-01 11:25:25 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:25:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:25:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:25:25 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:25:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:25:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:25:25 --> Final output sent to browser
DEBUG - 2021-07-01 11:25:25 --> Total execution time: 0.0957
INFO - 2021-07-01 11:25:57 --> Config Class Initialized
INFO - 2021-07-01 11:25:57 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:25:57 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:25:57 --> Utf8 Class Initialized
INFO - 2021-07-01 11:25:57 --> URI Class Initialized
INFO - 2021-07-01 11:25:57 --> Router Class Initialized
INFO - 2021-07-01 11:25:57 --> Output Class Initialized
INFO - 2021-07-01 11:25:57 --> Security Class Initialized
DEBUG - 2021-07-01 11:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:25:57 --> Input Class Initialized
INFO - 2021-07-01 11:25:57 --> Language Class Initialized
INFO - 2021-07-01 11:25:57 --> Loader Class Initialized
INFO - 2021-07-01 11:25:57 --> Helper loaded: html_helper
INFO - 2021-07-01 11:25:57 --> Helper loaded: url_helper
INFO - 2021-07-01 11:25:57 --> Helper loaded: form_helper
INFO - 2021-07-01 11:25:57 --> Database Driver Class Initialized
INFO - 2021-07-01 11:25:57 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:25:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:25:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:25:57 --> Encryption Class Initialized
INFO - 2021-07-01 11:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:25:57 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:25:57 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:25:57 --> Model "user_model" initialized
INFO - 2021-07-01 11:25:57 --> Model "role_model" initialized
INFO - 2021-07-01 11:25:57 --> Controller Class Initialized
INFO - 2021-07-01 11:25:57 --> Helper loaded: language_helper
INFO - 2021-07-01 11:25:57 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:25:57 --> Model "Quotation_model" initialized
INFO - 2021-07-01 11:25:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:25:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:25:57 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 11:25:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 11:25:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:25:57 --> Final output sent to browser
DEBUG - 2021-07-01 11:25:57 --> Total execution time: 0.1516
INFO - 2021-07-01 11:26:13 --> Config Class Initialized
INFO - 2021-07-01 11:26:13 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:26:13 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:26:13 --> Utf8 Class Initialized
INFO - 2021-07-01 11:26:13 --> URI Class Initialized
INFO - 2021-07-01 11:26:13 --> Router Class Initialized
INFO - 2021-07-01 11:26:13 --> Output Class Initialized
INFO - 2021-07-01 11:26:13 --> Security Class Initialized
DEBUG - 2021-07-01 11:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:26:13 --> Input Class Initialized
INFO - 2021-07-01 11:26:13 --> Language Class Initialized
INFO - 2021-07-01 11:26:13 --> Loader Class Initialized
INFO - 2021-07-01 11:26:13 --> Helper loaded: html_helper
INFO - 2021-07-01 11:26:13 --> Helper loaded: url_helper
INFO - 2021-07-01 11:26:13 --> Helper loaded: form_helper
INFO - 2021-07-01 11:26:13 --> Database Driver Class Initialized
INFO - 2021-07-01 11:26:13 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:26:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:26:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:26:13 --> Encryption Class Initialized
INFO - 2021-07-01 11:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:26:13 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:26:13 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:26:13 --> Model "user_model" initialized
INFO - 2021-07-01 11:26:13 --> Model "role_model" initialized
INFO - 2021-07-01 11:26:13 --> Controller Class Initialized
INFO - 2021-07-01 11:26:13 --> Helper loaded: language_helper
INFO - 2021-07-01 11:26:13 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:26:13 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:26:13 --> Model "Product_model" initialized
INFO - 2021-07-01 11:26:13 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:26:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:26:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:26:13 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:26:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:26:13 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:26:13 --> Final output sent to browser
DEBUG - 2021-07-01 11:26:13 --> Total execution time: 0.0814
INFO - 2021-07-01 11:26:14 --> Config Class Initialized
INFO - 2021-07-01 11:26:14 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:26:14 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:26:14 --> Utf8 Class Initialized
INFO - 2021-07-01 11:26:14 --> URI Class Initialized
INFO - 2021-07-01 11:26:14 --> Router Class Initialized
INFO - 2021-07-01 11:26:14 --> Output Class Initialized
INFO - 2021-07-01 11:26:14 --> Security Class Initialized
DEBUG - 2021-07-01 11:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:26:14 --> Input Class Initialized
INFO - 2021-07-01 11:26:14 --> Language Class Initialized
INFO - 2021-07-01 11:26:14 --> Loader Class Initialized
INFO - 2021-07-01 11:26:14 --> Helper loaded: html_helper
INFO - 2021-07-01 11:26:14 --> Helper loaded: url_helper
INFO - 2021-07-01 11:26:14 --> Helper loaded: form_helper
INFO - 2021-07-01 11:26:14 --> Database Driver Class Initialized
INFO - 2021-07-01 11:26:14 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:26:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:26:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:26:14 --> Encryption Class Initialized
INFO - 2021-07-01 11:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:26:14 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:26:14 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:26:14 --> Model "user_model" initialized
INFO - 2021-07-01 11:26:14 --> Model "role_model" initialized
INFO - 2021-07-01 11:26:14 --> Controller Class Initialized
INFO - 2021-07-01 11:26:14 --> Helper loaded: language_helper
INFO - 2021-07-01 11:26:14 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:26:14 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:26:14 --> Model "Product_model" initialized
INFO - 2021-07-01 11:26:14 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:26:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:26:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:26:14 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:26:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:26:14 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:26:14 --> Final output sent to browser
DEBUG - 2021-07-01 11:26:14 --> Total execution time: 0.0742
INFO - 2021-07-01 11:26:14 --> Config Class Initialized
INFO - 2021-07-01 11:26:14 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:26:14 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:26:14 --> Utf8 Class Initialized
INFO - 2021-07-01 11:26:14 --> URI Class Initialized
INFO - 2021-07-01 11:26:14 --> Router Class Initialized
INFO - 2021-07-01 11:26:14 --> Output Class Initialized
INFO - 2021-07-01 11:26:14 --> Security Class Initialized
DEBUG - 2021-07-01 11:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:26:14 --> Input Class Initialized
INFO - 2021-07-01 11:26:14 --> Language Class Initialized
INFO - 2021-07-01 11:26:14 --> Loader Class Initialized
INFO - 2021-07-01 11:26:14 --> Helper loaded: html_helper
INFO - 2021-07-01 11:26:14 --> Helper loaded: url_helper
INFO - 2021-07-01 11:26:14 --> Helper loaded: form_helper
INFO - 2021-07-01 11:26:14 --> Database Driver Class Initialized
INFO - 2021-07-01 11:26:15 --> Config Class Initialized
INFO - 2021-07-01 11:26:15 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:26:15 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:26:15 --> Utf8 Class Initialized
INFO - 2021-07-01 11:26:15 --> URI Class Initialized
INFO - 2021-07-01 11:26:15 --> Router Class Initialized
INFO - 2021-07-01 11:26:15 --> Output Class Initialized
INFO - 2021-07-01 11:26:15 --> Security Class Initialized
DEBUG - 2021-07-01 11:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:26:15 --> Input Class Initialized
INFO - 2021-07-01 11:26:15 --> Language Class Initialized
INFO - 2021-07-01 11:26:15 --> Loader Class Initialized
INFO - 2021-07-01 11:26:15 --> Helper loaded: html_helper
INFO - 2021-07-01 11:26:15 --> Helper loaded: url_helper
INFO - 2021-07-01 11:26:15 --> Helper loaded: form_helper
INFO - 2021-07-01 11:26:15 --> Database Driver Class Initialized
INFO - 2021-07-01 11:26:15 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:26:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:26:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:26:15 --> Encryption Class Initialized
INFO - 2021-07-01 11:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:26:15 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:26:15 --> Form Validation Class Initialized
INFO - 2021-07-01 11:26:15 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:26:15 --> Model "user_model" initialized
INFO - 2021-07-01 11:26:15 --> Model "role_model" initialized
DEBUG - 2021-07-01 11:26:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:26:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:26:15 --> Controller Class Initialized
INFO - 2021-07-01 11:26:15 --> Encryption Class Initialized
INFO - 2021-07-01 11:26:15 --> Helper loaded: language_helper
INFO - 2021-07-01 11:26:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:26:15 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:26:15 --> Model "Product_model" initialized
INFO - 2021-07-01 11:26:15 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:26:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:26:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:26:15 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:26:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:26:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:26:15 --> Final output sent to browser
DEBUG - 2021-07-01 11:26:15 --> Total execution time: 0.3774
INFO - 2021-07-01 11:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:26:15 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:26:15 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:26:15 --> Model "user_model" initialized
INFO - 2021-07-01 11:26:15 --> Model "role_model" initialized
INFO - 2021-07-01 11:26:15 --> Controller Class Initialized
INFO - 2021-07-01 11:26:15 --> Helper loaded: language_helper
INFO - 2021-07-01 11:26:15 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:26:15 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:26:15 --> Model "Product_model" initialized
INFO - 2021-07-01 11:26:15 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:26:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:26:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:26:15 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:26:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:26:15 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:26:15 --> Final output sent to browser
DEBUG - 2021-07-01 11:26:15 --> Total execution time: 0.0911
INFO - 2021-07-01 11:26:15 --> Config Class Initialized
INFO - 2021-07-01 11:26:15 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:26:15 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:26:15 --> Utf8 Class Initialized
INFO - 2021-07-01 11:26:15 --> URI Class Initialized
INFO - 2021-07-01 11:26:15 --> Router Class Initialized
INFO - 2021-07-01 11:26:15 --> Output Class Initialized
INFO - 2021-07-01 11:26:15 --> Security Class Initialized
DEBUG - 2021-07-01 11:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:26:15 --> Input Class Initialized
INFO - 2021-07-01 11:26:15 --> Language Class Initialized
INFO - 2021-07-01 11:26:15 --> Loader Class Initialized
INFO - 2021-07-01 11:26:15 --> Helper loaded: html_helper
INFO - 2021-07-01 11:26:15 --> Helper loaded: url_helper
INFO - 2021-07-01 11:26:15 --> Helper loaded: form_helper
INFO - 2021-07-01 11:26:15 --> Database Driver Class Initialized
INFO - 2021-07-01 11:26:16 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:26:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:26:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:26:16 --> Encryption Class Initialized
INFO - 2021-07-01 11:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:26:16 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:26:16 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:26:16 --> Model "user_model" initialized
INFO - 2021-07-01 11:26:16 --> Model "role_model" initialized
INFO - 2021-07-01 11:26:16 --> Controller Class Initialized
INFO - 2021-07-01 11:26:16 --> Helper loaded: language_helper
INFO - 2021-07-01 11:26:16 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:26:16 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:26:16 --> Model "Product_model" initialized
INFO - 2021-07-01 11:26:16 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:26:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:26:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:26:16 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:26:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:26:16 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:26:16 --> Final output sent to browser
DEBUG - 2021-07-01 11:26:16 --> Total execution time: 0.7285
INFO - 2021-07-01 11:31:19 --> Config Class Initialized
INFO - 2021-07-01 11:31:19 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:31:19 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:31:19 --> Utf8 Class Initialized
INFO - 2021-07-01 11:31:19 --> URI Class Initialized
INFO - 2021-07-01 11:31:19 --> Router Class Initialized
INFO - 2021-07-01 11:31:19 --> Output Class Initialized
INFO - 2021-07-01 11:31:19 --> Security Class Initialized
DEBUG - 2021-07-01 11:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:31:19 --> Input Class Initialized
INFO - 2021-07-01 11:31:19 --> Language Class Initialized
INFO - 2021-07-01 11:31:19 --> Loader Class Initialized
INFO - 2021-07-01 11:31:19 --> Helper loaded: html_helper
INFO - 2021-07-01 11:31:19 --> Helper loaded: url_helper
INFO - 2021-07-01 11:31:19 --> Helper loaded: form_helper
INFO - 2021-07-01 11:31:19 --> Database Driver Class Initialized
INFO - 2021-07-01 11:31:19 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:31:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:31:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:31:19 --> Encryption Class Initialized
INFO - 2021-07-01 11:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:31:19 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:31:19 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:31:19 --> Model "user_model" initialized
INFO - 2021-07-01 11:31:19 --> Model "role_model" initialized
INFO - 2021-07-01 11:31:19 --> Controller Class Initialized
INFO - 2021-07-01 11:31:19 --> Helper loaded: language_helper
INFO - 2021-07-01 11:31:19 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:31:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:31:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-01 11:31:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\complaints.php
INFO - 2021-07-01 11:31:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:31:19 --> Final output sent to browser
DEBUG - 2021-07-01 11:31:19 --> Total execution time: 0.1218
INFO - 2021-07-01 11:31:26 --> Config Class Initialized
INFO - 2021-07-01 11:31:26 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:31:26 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:31:26 --> Utf8 Class Initialized
INFO - 2021-07-01 11:31:26 --> URI Class Initialized
INFO - 2021-07-01 11:31:26 --> Router Class Initialized
INFO - 2021-07-01 11:31:26 --> Output Class Initialized
INFO - 2021-07-01 11:31:27 --> Security Class Initialized
DEBUG - 2021-07-01 11:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:31:27 --> Input Class Initialized
INFO - 2021-07-01 11:31:27 --> Language Class Initialized
INFO - 2021-07-01 11:31:27 --> Loader Class Initialized
INFO - 2021-07-01 11:31:27 --> Helper loaded: html_helper
INFO - 2021-07-01 11:31:27 --> Helper loaded: url_helper
INFO - 2021-07-01 11:31:27 --> Helper loaded: form_helper
INFO - 2021-07-01 11:31:27 --> Database Driver Class Initialized
INFO - 2021-07-01 11:31:27 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:31:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:31:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:31:27 --> Encryption Class Initialized
INFO - 2021-07-01 11:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:31:27 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:31:27 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:31:27 --> Model "user_model" initialized
INFO - 2021-07-01 11:31:27 --> Model "role_model" initialized
INFO - 2021-07-01 11:31:27 --> Controller Class Initialized
INFO - 2021-07-01 11:31:27 --> Helper loaded: language_helper
INFO - 2021-07-01 11:31:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:31:27 --> Model "complaints_model" initialized
INFO - 2021-07-01 11:31:27 --> Final output sent to browser
DEBUG - 2021-07-01 11:31:27 --> Total execution time: 0.1359
INFO - 2021-07-01 11:31:44 --> Config Class Initialized
INFO - 2021-07-01 11:31:44 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:31:44 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:31:44 --> Utf8 Class Initialized
INFO - 2021-07-01 11:31:44 --> URI Class Initialized
INFO - 2021-07-01 11:31:44 --> Router Class Initialized
INFO - 2021-07-01 11:31:44 --> Output Class Initialized
INFO - 2021-07-01 11:31:44 --> Security Class Initialized
DEBUG - 2021-07-01 11:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:31:44 --> Input Class Initialized
INFO - 2021-07-01 11:31:44 --> Language Class Initialized
INFO - 2021-07-01 11:31:44 --> Loader Class Initialized
INFO - 2021-07-01 11:31:44 --> Helper loaded: html_helper
INFO - 2021-07-01 11:31:44 --> Helper loaded: url_helper
INFO - 2021-07-01 11:31:44 --> Helper loaded: form_helper
INFO - 2021-07-01 11:31:44 --> Database Driver Class Initialized
INFO - 2021-07-01 11:31:44 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:31:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:31:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:31:44 --> Encryption Class Initialized
INFO - 2021-07-01 11:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:31:44 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:31:44 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:31:44 --> Model "user_model" initialized
INFO - 2021-07-01 11:31:44 --> Model "role_model" initialized
INFO - 2021-07-01 11:31:44 --> Controller Class Initialized
INFO - 2021-07-01 11:31:44 --> Helper loaded: language_helper
INFO - 2021-07-01 11:31:44 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:31:44 --> Model "complaints_model" initialized
INFO - 2021-07-01 11:31:44 --> Final output sent to browser
DEBUG - 2021-07-01 11:31:44 --> Total execution time: 0.0903
INFO - 2021-07-01 11:31:55 --> Config Class Initialized
INFO - 2021-07-01 11:31:55 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:31:55 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:31:55 --> Utf8 Class Initialized
INFO - 2021-07-01 11:31:55 --> URI Class Initialized
INFO - 2021-07-01 11:31:55 --> Router Class Initialized
INFO - 2021-07-01 11:31:55 --> Output Class Initialized
INFO - 2021-07-01 11:31:55 --> Security Class Initialized
DEBUG - 2021-07-01 11:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:31:55 --> Input Class Initialized
INFO - 2021-07-01 11:31:55 --> Language Class Initialized
INFO - 2021-07-01 11:31:55 --> Loader Class Initialized
INFO - 2021-07-01 11:31:55 --> Helper loaded: html_helper
INFO - 2021-07-01 11:31:55 --> Helper loaded: url_helper
INFO - 2021-07-01 11:31:55 --> Helper loaded: form_helper
INFO - 2021-07-01 11:31:55 --> Database Driver Class Initialized
INFO - 2021-07-01 11:31:55 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:31:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:31:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:31:55 --> Encryption Class Initialized
INFO - 2021-07-01 11:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:31:55 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:31:55 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:31:55 --> Model "user_model" initialized
INFO - 2021-07-01 11:31:55 --> Model "role_model" initialized
INFO - 2021-07-01 11:31:55 --> Controller Class Initialized
INFO - 2021-07-01 11:31:55 --> Helper loaded: language_helper
INFO - 2021-07-01 11:31:55 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:31:55 --> Model "complaints_model" initialized
INFO - 2021-07-01 11:31:55 --> Final output sent to browser
DEBUG - 2021-07-01 11:31:55 --> Total execution time: 0.0737
INFO - 2021-07-01 11:32:18 --> Config Class Initialized
INFO - 2021-07-01 11:32:18 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:32:18 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:32:18 --> Utf8 Class Initialized
INFO - 2021-07-01 11:32:18 --> URI Class Initialized
INFO - 2021-07-01 11:32:18 --> Router Class Initialized
INFO - 2021-07-01 11:32:18 --> Output Class Initialized
INFO - 2021-07-01 11:32:18 --> Security Class Initialized
DEBUG - 2021-07-01 11:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:32:18 --> Input Class Initialized
INFO - 2021-07-01 11:32:18 --> Language Class Initialized
INFO - 2021-07-01 11:32:18 --> Loader Class Initialized
INFO - 2021-07-01 11:32:18 --> Helper loaded: html_helper
INFO - 2021-07-01 11:32:18 --> Helper loaded: url_helper
INFO - 2021-07-01 11:32:18 --> Helper loaded: form_helper
INFO - 2021-07-01 11:32:18 --> Database Driver Class Initialized
INFO - 2021-07-01 11:32:18 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:32:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:32:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:32:18 --> Encryption Class Initialized
INFO - 2021-07-01 11:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:32:18 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:32:18 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:32:18 --> Model "user_model" initialized
INFO - 2021-07-01 11:32:18 --> Model "role_model" initialized
INFO - 2021-07-01 11:32:18 --> Controller Class Initialized
INFO - 2021-07-01 11:32:18 --> Helper loaded: language_helper
INFO - 2021-07-01 11:32:18 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:32:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:32:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-01 11:32:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\coupon_report.php
INFO - 2021-07-01 11:32:18 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:32:18 --> Final output sent to browser
DEBUG - 2021-07-01 11:32:18 --> Total execution time: 0.1243
INFO - 2021-07-01 11:32:23 --> Config Class Initialized
INFO - 2021-07-01 11:32:23 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:32:23 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:32:23 --> Utf8 Class Initialized
INFO - 2021-07-01 11:32:23 --> URI Class Initialized
INFO - 2021-07-01 11:32:23 --> Router Class Initialized
INFO - 2021-07-01 11:32:23 --> Output Class Initialized
INFO - 2021-07-01 11:32:23 --> Security Class Initialized
DEBUG - 2021-07-01 11:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:32:23 --> Input Class Initialized
INFO - 2021-07-01 11:32:23 --> Language Class Initialized
INFO - 2021-07-01 11:32:23 --> Loader Class Initialized
INFO - 2021-07-01 11:32:23 --> Helper loaded: html_helper
INFO - 2021-07-01 11:32:23 --> Helper loaded: url_helper
INFO - 2021-07-01 11:32:23 --> Helper loaded: form_helper
INFO - 2021-07-01 11:32:23 --> Database Driver Class Initialized
INFO - 2021-07-01 11:32:23 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:32:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:32:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:32:23 --> Encryption Class Initialized
INFO - 2021-07-01 11:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:32:23 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:32:23 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:32:23 --> Model "user_model" initialized
INFO - 2021-07-01 11:32:23 --> Model "role_model" initialized
INFO - 2021-07-01 11:32:23 --> Controller Class Initialized
INFO - 2021-07-01 11:32:23 --> Helper loaded: language_helper
INFO - 2021-07-01 11:32:23 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:32:23 --> Final output sent to browser
DEBUG - 2021-07-01 11:32:23 --> Total execution time: 0.1317
INFO - 2021-07-01 11:32:45 --> Config Class Initialized
INFO - 2021-07-01 11:32:45 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:32:45 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:32:45 --> Utf8 Class Initialized
INFO - 2021-07-01 11:32:45 --> URI Class Initialized
INFO - 2021-07-01 11:32:45 --> Router Class Initialized
INFO - 2021-07-01 11:32:45 --> Output Class Initialized
INFO - 2021-07-01 11:32:45 --> Security Class Initialized
DEBUG - 2021-07-01 11:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:32:45 --> Input Class Initialized
INFO - 2021-07-01 11:32:45 --> Language Class Initialized
INFO - 2021-07-01 11:32:45 --> Loader Class Initialized
INFO - 2021-07-01 11:32:45 --> Helper loaded: html_helper
INFO - 2021-07-01 11:32:45 --> Helper loaded: url_helper
INFO - 2021-07-01 11:32:45 --> Helper loaded: form_helper
INFO - 2021-07-01 11:32:45 --> Database Driver Class Initialized
INFO - 2021-07-01 11:32:45 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:32:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:32:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:32:45 --> Encryption Class Initialized
INFO - 2021-07-01 11:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:32:45 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:32:45 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:32:45 --> Model "user_model" initialized
INFO - 2021-07-01 11:32:45 --> Model "role_model" initialized
INFO - 2021-07-01 11:32:45 --> Controller Class Initialized
INFO - 2021-07-01 11:32:45 --> Helper loaded: language_helper
INFO - 2021-07-01 11:32:45 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:32:45 --> Final output sent to browser
DEBUG - 2021-07-01 11:32:45 --> Total execution time: 0.0808
INFO - 2021-07-01 11:33:43 --> Config Class Initialized
INFO - 2021-07-01 11:33:43 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:33:43 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:33:43 --> Utf8 Class Initialized
INFO - 2021-07-01 11:33:43 --> URI Class Initialized
INFO - 2021-07-01 11:33:43 --> Router Class Initialized
INFO - 2021-07-01 11:33:43 --> Output Class Initialized
INFO - 2021-07-01 11:33:43 --> Security Class Initialized
DEBUG - 2021-07-01 11:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:33:43 --> Input Class Initialized
INFO - 2021-07-01 11:33:43 --> Language Class Initialized
INFO - 2021-07-01 11:33:43 --> Loader Class Initialized
INFO - 2021-07-01 11:33:43 --> Helper loaded: html_helper
INFO - 2021-07-01 11:33:43 --> Helper loaded: url_helper
INFO - 2021-07-01 11:33:43 --> Helper loaded: form_helper
INFO - 2021-07-01 11:33:43 --> Database Driver Class Initialized
INFO - 2021-07-01 11:33:43 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:33:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:33:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:33:43 --> Encryption Class Initialized
INFO - 2021-07-01 11:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:33:43 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:33:43 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:33:43 --> Model "user_model" initialized
INFO - 2021-07-01 11:33:43 --> Model "role_model" initialized
INFO - 2021-07-01 11:33:43 --> Controller Class Initialized
INFO - 2021-07-01 11:33:43 --> Helper loaded: language_helper
INFO - 2021-07-01 11:33:43 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:33:43 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:33:43 --> Model "Product_model" initialized
INFO - 2021-07-01 11:33:43 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:33:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:33:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:33:43 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:33:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:33:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:33:43 --> Final output sent to browser
DEBUG - 2021-07-01 11:33:43 --> Total execution time: 0.1761
INFO - 2021-07-01 11:33:59 --> Config Class Initialized
INFO - 2021-07-01 11:33:59 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:33:59 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:33:59 --> Utf8 Class Initialized
INFO - 2021-07-01 11:33:59 --> URI Class Initialized
INFO - 2021-07-01 11:33:59 --> Router Class Initialized
INFO - 2021-07-01 11:33:59 --> Output Class Initialized
INFO - 2021-07-01 11:33:59 --> Security Class Initialized
DEBUG - 2021-07-01 11:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:33:59 --> Input Class Initialized
INFO - 2021-07-01 11:33:59 --> Language Class Initialized
INFO - 2021-07-01 11:33:59 --> Loader Class Initialized
INFO - 2021-07-01 11:33:59 --> Helper loaded: html_helper
INFO - 2021-07-01 11:33:59 --> Helper loaded: url_helper
INFO - 2021-07-01 11:33:59 --> Helper loaded: form_helper
INFO - 2021-07-01 11:33:59 --> Database Driver Class Initialized
INFO - 2021-07-01 11:33:59 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:33:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:33:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:33:59 --> Encryption Class Initialized
INFO - 2021-07-01 11:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:33:59 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:33:59 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:33:59 --> Model "user_model" initialized
INFO - 2021-07-01 11:33:59 --> Model "role_model" initialized
INFO - 2021-07-01 11:33:59 --> Controller Class Initialized
INFO - 2021-07-01 11:33:59 --> Helper loaded: language_helper
INFO - 2021-07-01 11:33:59 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:33:59 --> Model "Invoice_model" initialized
INFO - 2021-07-01 11:33:59 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:33:59 --> Model "Product_model" initialized
INFO - 2021-07-01 11:33:59 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:33:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:33:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:33:59 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Invoices\edit_invoice.php 32
INFO - 2021-07-01 11:33:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Invoices/edit_invoice.php
INFO - 2021-07-01 11:33:59 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:33:59 --> Final output sent to browser
DEBUG - 2021-07-01 11:33:59 --> Total execution time: 0.1117
INFO - 2021-07-01 11:34:04 --> Config Class Initialized
INFO - 2021-07-01 11:34:04 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:34:04 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:34:04 --> Utf8 Class Initialized
INFO - 2021-07-01 11:34:04 --> URI Class Initialized
INFO - 2021-07-01 11:34:04 --> Router Class Initialized
INFO - 2021-07-01 11:34:04 --> Output Class Initialized
INFO - 2021-07-01 11:34:04 --> Security Class Initialized
DEBUG - 2021-07-01 11:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:34:04 --> Input Class Initialized
INFO - 2021-07-01 11:34:04 --> Language Class Initialized
INFO - 2021-07-01 11:34:04 --> Loader Class Initialized
INFO - 2021-07-01 11:34:04 --> Helper loaded: html_helper
INFO - 2021-07-01 11:34:04 --> Helper loaded: url_helper
INFO - 2021-07-01 11:34:04 --> Helper loaded: form_helper
INFO - 2021-07-01 11:34:04 --> Database Driver Class Initialized
INFO - 2021-07-01 11:34:04 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:34:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:34:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:34:04 --> Encryption Class Initialized
INFO - 2021-07-01 11:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:34:04 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:34:04 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:34:04 --> Model "user_model" initialized
INFO - 2021-07-01 11:34:04 --> Model "role_model" initialized
INFO - 2021-07-01 11:34:04 --> Controller Class Initialized
INFO - 2021-07-01 11:34:04 --> Helper loaded: language_helper
INFO - 2021-07-01 11:34:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:34:04 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:34:04 --> Model "Product_model" initialized
INFO - 2021-07-01 11:34:04 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:34:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:34:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:34:04 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:34:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:34:04 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:34:04 --> Final output sent to browser
DEBUG - 2021-07-01 11:34:04 --> Total execution time: 0.0807
INFO - 2021-07-01 11:34:36 --> Config Class Initialized
INFO - 2021-07-01 11:34:36 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:34:36 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:34:36 --> Utf8 Class Initialized
INFO - 2021-07-01 11:34:36 --> URI Class Initialized
INFO - 2021-07-01 11:34:36 --> Router Class Initialized
INFO - 2021-07-01 11:34:36 --> Output Class Initialized
INFO - 2021-07-01 11:34:36 --> Security Class Initialized
DEBUG - 2021-07-01 11:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:34:36 --> Input Class Initialized
INFO - 2021-07-01 11:34:36 --> Language Class Initialized
INFO - 2021-07-01 11:34:36 --> Loader Class Initialized
INFO - 2021-07-01 11:34:36 --> Helper loaded: html_helper
INFO - 2021-07-01 11:34:36 --> Helper loaded: url_helper
INFO - 2021-07-01 11:34:36 --> Helper loaded: form_helper
INFO - 2021-07-01 11:34:36 --> Database Driver Class Initialized
INFO - 2021-07-01 11:34:36 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:34:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:34:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:34:36 --> Encryption Class Initialized
INFO - 2021-07-01 11:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:34:36 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:34:36 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:34:36 --> Model "user_model" initialized
INFO - 2021-07-01 11:34:36 --> Model "role_model" initialized
INFO - 2021-07-01 11:34:36 --> Controller Class Initialized
INFO - 2021-07-01 11:34:36 --> Helper loaded: language_helper
INFO - 2021-07-01 11:34:36 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:34:36 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:34:36 --> Model "Product_model" initialized
INFO - 2021-07-01 11:34:36 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:34:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:34:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:34:36 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:34:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:34:36 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:34:36 --> Final output sent to browser
DEBUG - 2021-07-01 11:34:36 --> Total execution time: 0.0811
INFO - 2021-07-01 11:34:38 --> Config Class Initialized
INFO - 2021-07-01 11:34:38 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:34:38 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:34:38 --> Utf8 Class Initialized
INFO - 2021-07-01 11:34:38 --> URI Class Initialized
INFO - 2021-07-01 11:34:38 --> Router Class Initialized
INFO - 2021-07-01 11:34:38 --> Output Class Initialized
INFO - 2021-07-01 11:34:38 --> Security Class Initialized
DEBUG - 2021-07-01 11:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:34:38 --> Input Class Initialized
INFO - 2021-07-01 11:34:38 --> Language Class Initialized
INFO - 2021-07-01 11:34:38 --> Loader Class Initialized
INFO - 2021-07-01 11:34:38 --> Helper loaded: html_helper
INFO - 2021-07-01 11:34:38 --> Helper loaded: url_helper
INFO - 2021-07-01 11:34:38 --> Helper loaded: form_helper
INFO - 2021-07-01 11:34:38 --> Database Driver Class Initialized
INFO - 2021-07-01 11:34:38 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:34:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:34:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:34:38 --> Encryption Class Initialized
INFO - 2021-07-01 11:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:34:38 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:34:38 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:34:38 --> Model "user_model" initialized
INFO - 2021-07-01 11:34:38 --> Model "role_model" initialized
INFO - 2021-07-01 11:34:38 --> Controller Class Initialized
INFO - 2021-07-01 11:34:38 --> Helper loaded: language_helper
INFO - 2021-07-01 11:34:38 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:34:38 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:34:38 --> Model "Product_model" initialized
INFO - 2021-07-01 11:34:38 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:34:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:34:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:34:38 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:34:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:34:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:34:38 --> Final output sent to browser
DEBUG - 2021-07-01 11:34:38 --> Total execution time: 0.0852
INFO - 2021-07-01 11:34:41 --> Config Class Initialized
INFO - 2021-07-01 11:34:41 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:34:41 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:34:41 --> Utf8 Class Initialized
INFO - 2021-07-01 11:34:41 --> URI Class Initialized
INFO - 2021-07-01 11:34:41 --> Router Class Initialized
INFO - 2021-07-01 11:34:41 --> Output Class Initialized
INFO - 2021-07-01 11:34:41 --> Security Class Initialized
DEBUG - 2021-07-01 11:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:34:41 --> Input Class Initialized
INFO - 2021-07-01 11:34:41 --> Language Class Initialized
INFO - 2021-07-01 11:34:41 --> Loader Class Initialized
INFO - 2021-07-01 11:34:41 --> Helper loaded: html_helper
INFO - 2021-07-01 11:34:41 --> Helper loaded: url_helper
INFO - 2021-07-01 11:34:41 --> Helper loaded: form_helper
INFO - 2021-07-01 11:34:41 --> Database Driver Class Initialized
INFO - 2021-07-01 11:34:41 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:34:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:34:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:34:41 --> Encryption Class Initialized
INFO - 2021-07-01 11:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:34:41 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:34:41 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:34:41 --> Model "user_model" initialized
INFO - 2021-07-01 11:34:41 --> Model "role_model" initialized
INFO - 2021-07-01 11:34:41 --> Controller Class Initialized
INFO - 2021-07-01 11:34:41 --> Helper loaded: language_helper
INFO - 2021-07-01 11:34:41 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:34:41 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:34:41 --> Model "Product_model" initialized
INFO - 2021-07-01 11:34:41 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:34:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:34:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:34:41 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:34:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:34:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:34:41 --> Final output sent to browser
DEBUG - 2021-07-01 11:34:41 --> Total execution time: 0.0770
INFO - 2021-07-01 11:35:42 --> Config Class Initialized
INFO - 2021-07-01 11:35:42 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:35:42 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:35:42 --> Utf8 Class Initialized
INFO - 2021-07-01 11:35:42 --> URI Class Initialized
INFO - 2021-07-01 11:35:42 --> Router Class Initialized
INFO - 2021-07-01 11:35:42 --> Output Class Initialized
INFO - 2021-07-01 11:35:42 --> Security Class Initialized
DEBUG - 2021-07-01 11:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:35:42 --> Input Class Initialized
INFO - 2021-07-01 11:35:42 --> Language Class Initialized
INFO - 2021-07-01 11:35:42 --> Loader Class Initialized
INFO - 2021-07-01 11:35:42 --> Helper loaded: html_helper
INFO - 2021-07-01 11:35:42 --> Helper loaded: url_helper
INFO - 2021-07-01 11:35:42 --> Helper loaded: form_helper
INFO - 2021-07-01 11:35:42 --> Database Driver Class Initialized
INFO - 2021-07-01 11:35:42 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:35:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:35:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:35:42 --> Encryption Class Initialized
INFO - 2021-07-01 11:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:35:42 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:35:42 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:35:42 --> Model "user_model" initialized
INFO - 2021-07-01 11:35:42 --> Model "role_model" initialized
INFO - 2021-07-01 11:35:42 --> Controller Class Initialized
INFO - 2021-07-01 11:35:42 --> Helper loaded: language_helper
INFO - 2021-07-01 11:35:42 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:35:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:35:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-01 11:35:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\payment_custom.php
INFO - 2021-07-01 11:35:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:35:42 --> Final output sent to browser
DEBUG - 2021-07-01 11:35:42 --> Total execution time: 0.1238
INFO - 2021-07-01 11:35:49 --> Config Class Initialized
INFO - 2021-07-01 11:35:49 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:35:49 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:35:49 --> Utf8 Class Initialized
INFO - 2021-07-01 11:35:49 --> URI Class Initialized
INFO - 2021-07-01 11:35:49 --> Router Class Initialized
INFO - 2021-07-01 11:35:49 --> Output Class Initialized
INFO - 2021-07-01 11:35:49 --> Security Class Initialized
DEBUG - 2021-07-01 11:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:35:49 --> Input Class Initialized
INFO - 2021-07-01 11:35:49 --> Language Class Initialized
INFO - 2021-07-01 11:35:49 --> Loader Class Initialized
INFO - 2021-07-01 11:35:49 --> Helper loaded: html_helper
INFO - 2021-07-01 11:35:49 --> Helper loaded: url_helper
INFO - 2021-07-01 11:35:49 --> Helper loaded: form_helper
INFO - 2021-07-01 11:35:49 --> Database Driver Class Initialized
INFO - 2021-07-01 11:35:49 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:35:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:35:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:35:49 --> Encryption Class Initialized
INFO - 2021-07-01 11:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:35:49 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:35:49 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:35:49 --> Model "user_model" initialized
INFO - 2021-07-01 11:35:49 --> Model "role_model" initialized
INFO - 2021-07-01 11:35:49 --> Controller Class Initialized
INFO - 2021-07-01 11:35:49 --> Helper loaded: language_helper
INFO - 2021-07-01 11:35:49 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:35:49 --> Model "Download_model" initialized
INFO - 2021-07-01 11:35:49 --> Final output sent to browser
DEBUG - 2021-07-01 11:35:49 --> Total execution time: 0.1177
INFO - 2021-07-01 11:36:23 --> Config Class Initialized
INFO - 2021-07-01 11:36:23 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:36:23 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:36:23 --> Utf8 Class Initialized
INFO - 2021-07-01 11:36:23 --> URI Class Initialized
INFO - 2021-07-01 11:36:23 --> Router Class Initialized
INFO - 2021-07-01 11:36:23 --> Output Class Initialized
INFO - 2021-07-01 11:36:23 --> Security Class Initialized
DEBUG - 2021-07-01 11:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:36:23 --> Input Class Initialized
INFO - 2021-07-01 11:36:23 --> Language Class Initialized
INFO - 2021-07-01 11:36:23 --> Loader Class Initialized
INFO - 2021-07-01 11:36:23 --> Helper loaded: html_helper
INFO - 2021-07-01 11:36:23 --> Helper loaded: url_helper
INFO - 2021-07-01 11:36:23 --> Helper loaded: form_helper
INFO - 2021-07-01 11:36:23 --> Database Driver Class Initialized
INFO - 2021-07-01 11:36:23 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:36:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:36:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:36:23 --> Encryption Class Initialized
INFO - 2021-07-01 11:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:36:23 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:36:23 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:36:23 --> Model "user_model" initialized
INFO - 2021-07-01 11:36:23 --> Model "role_model" initialized
INFO - 2021-07-01 11:36:23 --> Controller Class Initialized
INFO - 2021-07-01 11:36:23 --> Helper loaded: language_helper
INFO - 2021-07-01 11:36:23 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:36:23 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:36:23 --> Model "Product_model" initialized
INFO - 2021-07-01 11:36:23 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:36:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:36:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:36:23 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:36:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:36:23 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:36:23 --> Final output sent to browser
DEBUG - 2021-07-01 11:36:23 --> Total execution time: 0.0840
INFO - 2021-07-01 11:36:32 --> Config Class Initialized
INFO - 2021-07-01 11:36:32 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:36:32 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:36:32 --> Utf8 Class Initialized
INFO - 2021-07-01 11:36:32 --> URI Class Initialized
INFO - 2021-07-01 11:36:32 --> Router Class Initialized
INFO - 2021-07-01 11:36:32 --> Output Class Initialized
INFO - 2021-07-01 11:36:32 --> Security Class Initialized
DEBUG - 2021-07-01 11:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:36:32 --> Input Class Initialized
INFO - 2021-07-01 11:36:32 --> Language Class Initialized
INFO - 2021-07-01 11:36:32 --> Loader Class Initialized
INFO - 2021-07-01 11:36:32 --> Helper loaded: html_helper
INFO - 2021-07-01 11:36:32 --> Helper loaded: url_helper
INFO - 2021-07-01 11:36:32 --> Helper loaded: form_helper
INFO - 2021-07-01 11:36:32 --> Database Driver Class Initialized
INFO - 2021-07-01 11:36:32 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:36:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:36:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:36:32 --> Encryption Class Initialized
INFO - 2021-07-01 11:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:36:32 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:36:32 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:36:32 --> Model "user_model" initialized
INFO - 2021-07-01 11:36:32 --> Model "role_model" initialized
INFO - 2021-07-01 11:36:32 --> Controller Class Initialized
INFO - 2021-07-01 11:36:32 --> Helper loaded: language_helper
INFO - 2021-07-01 11:36:32 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:36:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:36:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-01 11:36:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\complaints.php
INFO - 2021-07-01 11:36:32 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:36:32 --> Final output sent to browser
DEBUG - 2021-07-01 11:36:32 --> Total execution time: 0.0679
INFO - 2021-07-01 11:36:41 --> Config Class Initialized
INFO - 2021-07-01 11:36:41 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:36:41 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:36:41 --> Utf8 Class Initialized
INFO - 2021-07-01 11:36:41 --> URI Class Initialized
INFO - 2021-07-01 11:36:41 --> Router Class Initialized
INFO - 2021-07-01 11:36:41 --> Output Class Initialized
INFO - 2021-07-01 11:36:41 --> Security Class Initialized
DEBUG - 2021-07-01 11:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:36:41 --> Input Class Initialized
INFO - 2021-07-01 11:36:41 --> Language Class Initialized
INFO - 2021-07-01 11:36:41 --> Loader Class Initialized
INFO - 2021-07-01 11:36:41 --> Helper loaded: html_helper
INFO - 2021-07-01 11:36:41 --> Helper loaded: url_helper
INFO - 2021-07-01 11:36:41 --> Helper loaded: form_helper
INFO - 2021-07-01 11:36:41 --> Database Driver Class Initialized
INFO - 2021-07-01 11:36:41 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:36:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:36:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:36:41 --> Encryption Class Initialized
INFO - 2021-07-01 11:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:36:41 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:36:41 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:36:41 --> Model "user_model" initialized
INFO - 2021-07-01 11:36:41 --> Model "role_model" initialized
INFO - 2021-07-01 11:36:41 --> Controller Class Initialized
INFO - 2021-07-01 11:36:41 --> Helper loaded: language_helper
INFO - 2021-07-01 11:36:41 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:36:41 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:36:41 --> Model "Product_model" initialized
INFO - 2021-07-01 11:36:41 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:36:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:36:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:36:41 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:36:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:36:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:36:41 --> Final output sent to browser
DEBUG - 2021-07-01 11:36:41 --> Total execution time: 0.0768
INFO - 2021-07-01 11:38:10 --> Config Class Initialized
INFO - 2021-07-01 11:38:10 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:38:10 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:38:10 --> Utf8 Class Initialized
INFO - 2021-07-01 11:38:10 --> URI Class Initialized
INFO - 2021-07-01 11:38:10 --> Router Class Initialized
INFO - 2021-07-01 11:38:10 --> Output Class Initialized
INFO - 2021-07-01 11:38:10 --> Security Class Initialized
DEBUG - 2021-07-01 11:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:38:10 --> Input Class Initialized
INFO - 2021-07-01 11:38:10 --> Language Class Initialized
INFO - 2021-07-01 11:38:10 --> Loader Class Initialized
INFO - 2021-07-01 11:38:10 --> Helper loaded: html_helper
INFO - 2021-07-01 11:38:10 --> Helper loaded: url_helper
INFO - 2021-07-01 11:38:10 --> Helper loaded: form_helper
INFO - 2021-07-01 11:38:10 --> Database Driver Class Initialized
INFO - 2021-07-01 11:38:10 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:38:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:38:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:38:10 --> Encryption Class Initialized
INFO - 2021-07-01 11:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:38:10 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:38:10 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:38:10 --> Model "user_model" initialized
INFO - 2021-07-01 11:38:10 --> Model "role_model" initialized
INFO - 2021-07-01 11:38:10 --> Controller Class Initialized
INFO - 2021-07-01 11:38:10 --> Helper loaded: language_helper
INFO - 2021-07-01 11:38:10 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:38:10 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:38:10 --> Model "Product_model" initialized
INFO - 2021-07-01 11:38:10 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:38:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:38:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:38:10 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:38:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:38:10 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:38:10 --> Final output sent to browser
DEBUG - 2021-07-01 11:38:10 --> Total execution time: 0.0853
INFO - 2021-07-01 11:38:17 --> Config Class Initialized
INFO - 2021-07-01 11:38:17 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:38:17 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:38:17 --> Utf8 Class Initialized
INFO - 2021-07-01 11:38:17 --> URI Class Initialized
INFO - 2021-07-01 11:38:17 --> Router Class Initialized
INFO - 2021-07-01 11:38:17 --> Output Class Initialized
INFO - 2021-07-01 11:38:17 --> Security Class Initialized
DEBUG - 2021-07-01 11:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:38:17 --> Input Class Initialized
INFO - 2021-07-01 11:38:17 --> Language Class Initialized
INFO - 2021-07-01 11:38:17 --> Loader Class Initialized
INFO - 2021-07-01 11:38:17 --> Helper loaded: html_helper
INFO - 2021-07-01 11:38:17 --> Helper loaded: url_helper
INFO - 2021-07-01 11:38:17 --> Helper loaded: form_helper
INFO - 2021-07-01 11:38:17 --> Database Driver Class Initialized
INFO - 2021-07-01 11:38:17 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:38:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:38:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:38:17 --> Encryption Class Initialized
INFO - 2021-07-01 11:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:38:17 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:38:17 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:38:17 --> Model "user_model" initialized
INFO - 2021-07-01 11:38:17 --> Model "role_model" initialized
INFO - 2021-07-01 11:38:17 --> Controller Class Initialized
INFO - 2021-07-01 11:38:17 --> Helper loaded: language_helper
INFO - 2021-07-01 11:38:17 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:38:17 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:38:17 --> Model "Product_model" initialized
INFO - 2021-07-01 11:38:17 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:38:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:38:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:38:17 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:38:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:38:17 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:38:17 --> Final output sent to browser
DEBUG - 2021-07-01 11:38:17 --> Total execution time: 0.0791
INFO - 2021-07-01 11:38:40 --> Config Class Initialized
INFO - 2021-07-01 11:38:40 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:38:40 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:38:40 --> Utf8 Class Initialized
INFO - 2021-07-01 11:38:40 --> URI Class Initialized
INFO - 2021-07-01 11:38:40 --> Router Class Initialized
INFO - 2021-07-01 11:38:40 --> Output Class Initialized
INFO - 2021-07-01 11:38:40 --> Security Class Initialized
DEBUG - 2021-07-01 11:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:38:40 --> Input Class Initialized
INFO - 2021-07-01 11:38:40 --> Language Class Initialized
INFO - 2021-07-01 11:38:40 --> Loader Class Initialized
INFO - 2021-07-01 11:38:40 --> Helper loaded: html_helper
INFO - 2021-07-01 11:38:40 --> Helper loaded: url_helper
INFO - 2021-07-01 11:38:40 --> Helper loaded: form_helper
INFO - 2021-07-01 11:38:40 --> Database Driver Class Initialized
INFO - 2021-07-01 11:38:41 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:38:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:38:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:38:41 --> Encryption Class Initialized
INFO - 2021-07-01 11:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:38:41 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:38:41 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:38:41 --> Model "user_model" initialized
INFO - 2021-07-01 11:38:41 --> Model "role_model" initialized
INFO - 2021-07-01 11:38:41 --> Controller Class Initialized
INFO - 2021-07-01 11:38:41 --> Helper loaded: language_helper
INFO - 2021-07-01 11:38:41 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:38:41 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:38:41 --> Model "Product_model" initialized
INFO - 2021-07-01 11:38:41 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:38:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:38:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:38:41 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:38:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:38:41 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:38:41 --> Final output sent to browser
DEBUG - 2021-07-01 11:38:41 --> Total execution time: 0.0866
INFO - 2021-07-01 11:40:45 --> Config Class Initialized
INFO - 2021-07-01 11:40:45 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:40:45 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:40:45 --> Utf8 Class Initialized
INFO - 2021-07-01 11:40:45 --> URI Class Initialized
INFO - 2021-07-01 11:40:45 --> Router Class Initialized
INFO - 2021-07-01 11:40:45 --> Output Class Initialized
INFO - 2021-07-01 11:40:45 --> Security Class Initialized
DEBUG - 2021-07-01 11:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:40:45 --> Input Class Initialized
INFO - 2021-07-01 11:40:45 --> Language Class Initialized
INFO - 2021-07-01 11:40:45 --> Loader Class Initialized
INFO - 2021-07-01 11:40:45 --> Helper loaded: html_helper
INFO - 2021-07-01 11:40:45 --> Helper loaded: url_helper
INFO - 2021-07-01 11:40:45 --> Helper loaded: form_helper
INFO - 2021-07-01 11:40:45 --> Database Driver Class Initialized
INFO - 2021-07-01 11:40:45 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:40:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:40:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:40:45 --> Encryption Class Initialized
INFO - 2021-07-01 11:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:40:45 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:40:45 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:40:45 --> Model "user_model" initialized
INFO - 2021-07-01 11:40:45 --> Model "role_model" initialized
INFO - 2021-07-01 11:40:45 --> Controller Class Initialized
INFO - 2021-07-01 11:40:45 --> Helper loaded: language_helper
INFO - 2021-07-01 11:40:45 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:40:45 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:40:45 --> Model "Product_model" initialized
INFO - 2021-07-01 11:40:45 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:40:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:40:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:40:45 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:40:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:40:45 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:40:45 --> Final output sent to browser
DEBUG - 2021-07-01 11:40:45 --> Total execution time: 0.0854
INFO - 2021-07-01 11:41:10 --> Config Class Initialized
INFO - 2021-07-01 11:41:10 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:41:10 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:41:10 --> Utf8 Class Initialized
INFO - 2021-07-01 11:41:10 --> URI Class Initialized
INFO - 2021-07-01 11:41:10 --> Router Class Initialized
INFO - 2021-07-01 11:41:10 --> Output Class Initialized
INFO - 2021-07-01 11:41:10 --> Security Class Initialized
DEBUG - 2021-07-01 11:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:41:10 --> Input Class Initialized
INFO - 2021-07-01 11:41:10 --> Language Class Initialized
INFO - 2021-07-01 11:41:10 --> Loader Class Initialized
INFO - 2021-07-01 11:41:10 --> Helper loaded: html_helper
INFO - 2021-07-01 11:41:10 --> Helper loaded: url_helper
INFO - 2021-07-01 11:41:10 --> Helper loaded: form_helper
INFO - 2021-07-01 11:41:10 --> Database Driver Class Initialized
INFO - 2021-07-01 11:41:10 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:41:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:41:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:41:10 --> Encryption Class Initialized
INFO - 2021-07-01 11:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:41:11 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:41:11 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:41:11 --> Model "user_model" initialized
INFO - 2021-07-01 11:41:11 --> Model "role_model" initialized
INFO - 2021-07-01 11:41:11 --> Controller Class Initialized
INFO - 2021-07-01 11:41:11 --> Helper loaded: language_helper
INFO - 2021-07-01 11:41:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:41:11 --> Final output sent to browser
DEBUG - 2021-07-01 11:41:11 --> Total execution time: 0.1353
INFO - 2021-07-01 11:41:11 --> Config Class Initialized
INFO - 2021-07-01 11:41:11 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:41:11 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:41:11 --> Utf8 Class Initialized
INFO - 2021-07-01 11:41:11 --> URI Class Initialized
DEBUG - 2021-07-01 11:41:11 --> No URI present. Default controller set.
INFO - 2021-07-01 11:41:11 --> Router Class Initialized
INFO - 2021-07-01 11:41:11 --> Output Class Initialized
INFO - 2021-07-01 11:41:11 --> Security Class Initialized
DEBUG - 2021-07-01 11:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:41:11 --> Input Class Initialized
INFO - 2021-07-01 11:41:11 --> Language Class Initialized
INFO - 2021-07-01 11:41:11 --> Loader Class Initialized
INFO - 2021-07-01 11:41:11 --> Helper loaded: html_helper
INFO - 2021-07-01 11:41:11 --> Helper loaded: url_helper
INFO - 2021-07-01 11:41:11 --> Helper loaded: form_helper
INFO - 2021-07-01 11:41:11 --> Database Driver Class Initialized
INFO - 2021-07-01 11:41:11 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:41:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:41:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:41:11 --> Encryption Class Initialized
INFO - 2021-07-01 11:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:41:11 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:41:11 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:41:11 --> Model "user_model" initialized
INFO - 2021-07-01 11:41:11 --> Model "role_model" initialized
INFO - 2021-07-01 11:41:11 --> Controller Class Initialized
INFO - 2021-07-01 11:41:11 --> Helper loaded: language_helper
INFO - 2021-07-01 11:41:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:41:11 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\login.php
INFO - 2021-07-01 11:41:11 --> Final output sent to browser
DEBUG - 2021-07-01 11:41:11 --> Total execution time: 0.0948
INFO - 2021-07-01 11:41:27 --> Config Class Initialized
INFO - 2021-07-01 11:41:27 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:41:27 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:41:27 --> Utf8 Class Initialized
INFO - 2021-07-01 11:41:27 --> URI Class Initialized
INFO - 2021-07-01 11:41:27 --> Router Class Initialized
INFO - 2021-07-01 11:41:27 --> Output Class Initialized
INFO - 2021-07-01 11:41:27 --> Security Class Initialized
DEBUG - 2021-07-01 11:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:41:27 --> Input Class Initialized
INFO - 2021-07-01 11:41:27 --> Language Class Initialized
INFO - 2021-07-01 11:41:27 --> Loader Class Initialized
INFO - 2021-07-01 11:41:27 --> Helper loaded: html_helper
INFO - 2021-07-01 11:41:27 --> Helper loaded: url_helper
INFO - 2021-07-01 11:41:27 --> Helper loaded: form_helper
INFO - 2021-07-01 11:41:27 --> Database Driver Class Initialized
INFO - 2021-07-01 11:41:27 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:41:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:41:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:41:27 --> Encryption Class Initialized
INFO - 2021-07-01 11:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:41:27 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:41:27 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:41:27 --> Model "user_model" initialized
INFO - 2021-07-01 11:41:27 --> Model "role_model" initialized
INFO - 2021-07-01 11:41:27 --> Controller Class Initialized
INFO - 2021-07-01 11:41:27 --> Helper loaded: language_helper
INFO - 2021-07-01 11:41:27 --> Language file loaded: language/english/content_lang.php
DEBUG - 2021-07-01 11:41:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-01 11:41:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-07-01 11:41:27 --> Model "User" initialized
INFO - 2021-07-01 11:41:27 --> Config Class Initialized
INFO - 2021-07-01 11:41:27 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:41:27 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:41:27 --> Utf8 Class Initialized
INFO - 2021-07-01 11:41:27 --> URI Class Initialized
INFO - 2021-07-01 11:41:27 --> Router Class Initialized
INFO - 2021-07-01 11:41:27 --> Output Class Initialized
INFO - 2021-07-01 11:41:27 --> Security Class Initialized
DEBUG - 2021-07-01 11:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:41:27 --> Input Class Initialized
INFO - 2021-07-01 11:41:27 --> Language Class Initialized
INFO - 2021-07-01 11:41:27 --> Loader Class Initialized
INFO - 2021-07-01 11:41:27 --> Helper loaded: html_helper
INFO - 2021-07-01 11:41:27 --> Helper loaded: url_helper
INFO - 2021-07-01 11:41:27 --> Helper loaded: form_helper
INFO - 2021-07-01 11:41:27 --> Database Driver Class Initialized
INFO - 2021-07-01 11:41:27 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:41:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:41:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:41:27 --> Encryption Class Initialized
INFO - 2021-07-01 11:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:41:27 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:41:27 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:41:27 --> Model "user_model" initialized
INFO - 2021-07-01 11:41:27 --> Model "role_model" initialized
INFO - 2021-07-01 11:41:27 --> Controller Class Initialized
INFO - 2021-07-01 11:41:27 --> Helper loaded: language_helper
INFO - 2021-07-01 11:41:27 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:41:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_header.php
INFO - 2021-07-01 11:41:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
INFO - 2021-07-01 11:41:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\dashboard_body.php
INFO - 2021-07-01 11:41:27 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:41:27 --> Final output sent to browser
DEBUG - 2021-07-01 11:41:27 --> Total execution time: 0.0796
INFO - 2021-07-01 11:41:42 --> Config Class Initialized
INFO - 2021-07-01 11:41:42 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:41:42 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:41:42 --> Utf8 Class Initialized
INFO - 2021-07-01 11:41:42 --> URI Class Initialized
INFO - 2021-07-01 11:41:42 --> Router Class Initialized
INFO - 2021-07-01 11:41:42 --> Output Class Initialized
INFO - 2021-07-01 11:41:42 --> Security Class Initialized
DEBUG - 2021-07-01 11:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:41:42 --> Input Class Initialized
INFO - 2021-07-01 11:41:42 --> Language Class Initialized
INFO - 2021-07-01 11:41:42 --> Loader Class Initialized
INFO - 2021-07-01 11:41:42 --> Helper loaded: html_helper
INFO - 2021-07-01 11:41:42 --> Helper loaded: url_helper
INFO - 2021-07-01 11:41:42 --> Helper loaded: form_helper
INFO - 2021-07-01 11:41:42 --> Database Driver Class Initialized
INFO - 2021-07-01 11:41:42 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:41:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:41:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:41:42 --> Encryption Class Initialized
INFO - 2021-07-01 11:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:41:42 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:41:42 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:41:42 --> Model "user_model" initialized
INFO - 2021-07-01 11:41:42 --> Model "role_model" initialized
INFO - 2021-07-01 11:41:42 --> Controller Class Initialized
INFO - 2021-07-01 11:41:42 --> Helper loaded: language_helper
INFO - 2021-07-01 11:41:42 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:41:42 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:41:42 --> Model "Product_model" initialized
INFO - 2021-07-01 11:41:42 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:41:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:41:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:41:42 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:41:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:41:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:41:42 --> Final output sent to browser
DEBUG - 2021-07-01 11:41:42 --> Total execution time: 0.0726
INFO - 2021-07-01 11:42:25 --> Config Class Initialized
INFO - 2021-07-01 11:42:25 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:42:25 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:42:25 --> Utf8 Class Initialized
INFO - 2021-07-01 11:42:25 --> URI Class Initialized
INFO - 2021-07-01 11:42:25 --> Router Class Initialized
INFO - 2021-07-01 11:42:25 --> Output Class Initialized
INFO - 2021-07-01 11:42:25 --> Security Class Initialized
DEBUG - 2021-07-01 11:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:42:25 --> Input Class Initialized
INFO - 2021-07-01 11:42:25 --> Language Class Initialized
INFO - 2021-07-01 11:42:25 --> Loader Class Initialized
INFO - 2021-07-01 11:42:25 --> Helper loaded: html_helper
INFO - 2021-07-01 11:42:25 --> Helper loaded: url_helper
INFO - 2021-07-01 11:42:25 --> Helper loaded: form_helper
INFO - 2021-07-01 11:42:25 --> Database Driver Class Initialized
INFO - 2021-07-01 11:42:25 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:42:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:42:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:42:25 --> Encryption Class Initialized
INFO - 2021-07-01 11:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:42:25 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:42:25 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:42:25 --> Model "user_model" initialized
INFO - 2021-07-01 11:42:25 --> Model "role_model" initialized
INFO - 2021-07-01 11:42:25 --> Controller Class Initialized
INFO - 2021-07-01 11:42:25 --> Helper loaded: language_helper
INFO - 2021-07-01 11:42:25 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:42:25 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:42:25 --> Model "Product_model" initialized
INFO - 2021-07-01 11:42:25 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:42:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:42:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:42:25 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:42:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:42:25 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:42:25 --> Final output sent to browser
DEBUG - 2021-07-01 11:42:25 --> Total execution time: 0.0791
INFO - 2021-07-01 11:46:00 --> Config Class Initialized
INFO - 2021-07-01 11:46:00 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:46:00 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:46:00 --> Utf8 Class Initialized
INFO - 2021-07-01 11:46:00 --> URI Class Initialized
INFO - 2021-07-01 11:46:00 --> Router Class Initialized
INFO - 2021-07-01 11:46:00 --> Output Class Initialized
INFO - 2021-07-01 11:46:00 --> Security Class Initialized
DEBUG - 2021-07-01 11:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:46:00 --> Input Class Initialized
INFO - 2021-07-01 11:46:00 --> Language Class Initialized
INFO - 2021-07-01 11:46:00 --> Loader Class Initialized
INFO - 2021-07-01 11:46:00 --> Helper loaded: html_helper
INFO - 2021-07-01 11:46:00 --> Helper loaded: url_helper
INFO - 2021-07-01 11:46:00 --> Helper loaded: form_helper
INFO - 2021-07-01 11:46:00 --> Database Driver Class Initialized
INFO - 2021-07-01 11:46:00 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:46:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:46:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:46:00 --> Encryption Class Initialized
INFO - 2021-07-01 11:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:46:00 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:46:00 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:46:00 --> Model "user_model" initialized
INFO - 2021-07-01 11:46:00 --> Model "role_model" initialized
INFO - 2021-07-01 11:46:00 --> Controller Class Initialized
INFO - 2021-07-01 11:46:00 --> Helper loaded: language_helper
INFO - 2021-07-01 11:46:00 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:46:00 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:46:00 --> Model "Product_model" initialized
INFO - 2021-07-01 11:46:00 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:46:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:46:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:46:00 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:46:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:46:00 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:46:00 --> Final output sent to browser
DEBUG - 2021-07-01 11:46:00 --> Total execution time: 0.0818
INFO - 2021-07-01 11:46:51 --> Config Class Initialized
INFO - 2021-07-01 11:46:51 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:46:51 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:46:51 --> Utf8 Class Initialized
INFO - 2021-07-01 11:46:51 --> URI Class Initialized
INFO - 2021-07-01 11:46:51 --> Router Class Initialized
INFO - 2021-07-01 11:46:51 --> Output Class Initialized
INFO - 2021-07-01 11:46:51 --> Security Class Initialized
DEBUG - 2021-07-01 11:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:46:51 --> Input Class Initialized
INFO - 2021-07-01 11:46:51 --> Language Class Initialized
INFO - 2021-07-01 11:46:51 --> Loader Class Initialized
INFO - 2021-07-01 11:46:51 --> Helper loaded: html_helper
INFO - 2021-07-01 11:46:51 --> Helper loaded: url_helper
INFO - 2021-07-01 11:46:51 --> Helper loaded: form_helper
INFO - 2021-07-01 11:46:51 --> Database Driver Class Initialized
INFO - 2021-07-01 11:46:51 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:46:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:46:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:46:51 --> Encryption Class Initialized
INFO - 2021-07-01 11:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:46:51 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:46:51 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:46:51 --> Model "user_model" initialized
INFO - 2021-07-01 11:46:51 --> Model "role_model" initialized
INFO - 2021-07-01 11:46:51 --> Controller Class Initialized
INFO - 2021-07-01 11:46:51 --> Helper loaded: language_helper
INFO - 2021-07-01 11:46:51 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:46:51 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:46:51 --> Model "Product_model" initialized
INFO - 2021-07-01 11:46:51 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:46:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:46:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:46:51 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:46:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:46:51 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:46:51 --> Final output sent to browser
DEBUG - 2021-07-01 11:46:51 --> Total execution time: 0.0834
INFO - 2021-07-01 11:46:52 --> Config Class Initialized
INFO - 2021-07-01 11:46:52 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:46:52 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:46:52 --> Utf8 Class Initialized
INFO - 2021-07-01 11:46:52 --> URI Class Initialized
INFO - 2021-07-01 11:46:52 --> Router Class Initialized
INFO - 2021-07-01 11:46:52 --> Output Class Initialized
INFO - 2021-07-01 11:46:52 --> Security Class Initialized
DEBUG - 2021-07-01 11:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:46:52 --> Input Class Initialized
INFO - 2021-07-01 11:46:52 --> Language Class Initialized
INFO - 2021-07-01 11:46:52 --> Loader Class Initialized
INFO - 2021-07-01 11:46:52 --> Helper loaded: html_helper
INFO - 2021-07-01 11:46:52 --> Helper loaded: url_helper
INFO - 2021-07-01 11:46:52 --> Helper loaded: form_helper
INFO - 2021-07-01 11:46:52 --> Database Driver Class Initialized
INFO - 2021-07-01 11:46:52 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:46:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:46:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:46:52 --> Encryption Class Initialized
INFO - 2021-07-01 11:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:46:52 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:46:52 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:46:52 --> Model "user_model" initialized
INFO - 2021-07-01 11:46:52 --> Model "role_model" initialized
INFO - 2021-07-01 11:46:52 --> Controller Class Initialized
INFO - 2021-07-01 11:46:52 --> Helper loaded: language_helper
INFO - 2021-07-01 11:46:52 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:46:52 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:46:52 --> Model "Product_model" initialized
INFO - 2021-07-01 11:46:52 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:46:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:46:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:46:52 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:46:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:46:52 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:46:52 --> Final output sent to browser
DEBUG - 2021-07-01 11:46:52 --> Total execution time: 0.0765
INFO - 2021-07-01 11:46:53 --> Config Class Initialized
INFO - 2021-07-01 11:46:53 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:46:53 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:46:53 --> Utf8 Class Initialized
INFO - 2021-07-01 11:46:53 --> URI Class Initialized
INFO - 2021-07-01 11:46:53 --> Router Class Initialized
INFO - 2021-07-01 11:46:53 --> Output Class Initialized
INFO - 2021-07-01 11:46:53 --> Security Class Initialized
DEBUG - 2021-07-01 11:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:46:53 --> Input Class Initialized
INFO - 2021-07-01 11:46:53 --> Language Class Initialized
INFO - 2021-07-01 11:46:53 --> Loader Class Initialized
INFO - 2021-07-01 11:46:53 --> Helper loaded: html_helper
INFO - 2021-07-01 11:46:53 --> Helper loaded: url_helper
INFO - 2021-07-01 11:46:53 --> Helper loaded: form_helper
INFO - 2021-07-01 11:46:53 --> Database Driver Class Initialized
INFO - 2021-07-01 11:46:53 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:46:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:46:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:46:53 --> Encryption Class Initialized
INFO - 2021-07-01 11:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:46:53 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:46:53 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:46:53 --> Model "user_model" initialized
INFO - 2021-07-01 11:46:53 --> Model "role_model" initialized
INFO - 2021-07-01 11:46:53 --> Controller Class Initialized
INFO - 2021-07-01 11:46:53 --> Helper loaded: language_helper
INFO - 2021-07-01 11:46:53 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:46:53 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:46:53 --> Model "Product_model" initialized
INFO - 2021-07-01 11:46:53 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:46:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:46:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:46:53 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:46:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:46:53 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:46:53 --> Final output sent to browser
DEBUG - 2021-07-01 11:46:53 --> Total execution time: 0.0837
INFO - 2021-07-01 11:47:38 --> Config Class Initialized
INFO - 2021-07-01 11:47:38 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:47:38 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:47:38 --> Utf8 Class Initialized
INFO - 2021-07-01 11:47:38 --> URI Class Initialized
INFO - 2021-07-01 11:47:38 --> Router Class Initialized
INFO - 2021-07-01 11:47:38 --> Output Class Initialized
INFO - 2021-07-01 11:47:38 --> Security Class Initialized
DEBUG - 2021-07-01 11:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:47:38 --> Input Class Initialized
INFO - 2021-07-01 11:47:38 --> Language Class Initialized
INFO - 2021-07-01 11:47:38 --> Loader Class Initialized
INFO - 2021-07-01 11:47:38 --> Helper loaded: html_helper
INFO - 2021-07-01 11:47:38 --> Helper loaded: url_helper
INFO - 2021-07-01 11:47:38 --> Helper loaded: form_helper
INFO - 2021-07-01 11:47:38 --> Database Driver Class Initialized
INFO - 2021-07-01 11:47:38 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:47:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:47:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:47:38 --> Encryption Class Initialized
INFO - 2021-07-01 11:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:47:38 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:47:38 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:47:38 --> Model "user_model" initialized
INFO - 2021-07-01 11:47:38 --> Model "role_model" initialized
INFO - 2021-07-01 11:47:38 --> Controller Class Initialized
INFO - 2021-07-01 11:47:38 --> Helper loaded: language_helper
INFO - 2021-07-01 11:47:38 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:47:38 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:47:38 --> Model "Product_model" initialized
INFO - 2021-07-01 11:47:38 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:47:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:47:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:47:38 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:47:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:47:38 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:47:38 --> Final output sent to browser
DEBUG - 2021-07-01 11:47:38 --> Total execution time: 0.0827
INFO - 2021-07-01 11:47:39 --> Config Class Initialized
INFO - 2021-07-01 11:47:39 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:47:39 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:47:39 --> Utf8 Class Initialized
INFO - 2021-07-01 11:47:39 --> URI Class Initialized
INFO - 2021-07-01 11:47:39 --> Router Class Initialized
INFO - 2021-07-01 11:47:39 --> Output Class Initialized
INFO - 2021-07-01 11:47:39 --> Security Class Initialized
DEBUG - 2021-07-01 11:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:47:39 --> Input Class Initialized
INFO - 2021-07-01 11:47:39 --> Language Class Initialized
INFO - 2021-07-01 11:47:39 --> Loader Class Initialized
INFO - 2021-07-01 11:47:39 --> Helper loaded: html_helper
INFO - 2021-07-01 11:47:39 --> Helper loaded: url_helper
INFO - 2021-07-01 11:47:39 --> Helper loaded: form_helper
INFO - 2021-07-01 11:47:39 --> Database Driver Class Initialized
INFO - 2021-07-01 11:47:39 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:47:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:47:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:47:39 --> Encryption Class Initialized
INFO - 2021-07-01 11:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:47:39 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:47:39 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:47:39 --> Model "user_model" initialized
INFO - 2021-07-01 11:47:39 --> Model "role_model" initialized
INFO - 2021-07-01 11:47:39 --> Controller Class Initialized
INFO - 2021-07-01 11:47:39 --> Helper loaded: language_helper
INFO - 2021-07-01 11:47:39 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:47:39 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:47:39 --> Model "Product_model" initialized
INFO - 2021-07-01 11:47:39 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:47:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:47:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:47:39 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:47:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:47:39 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:47:39 --> Final output sent to browser
DEBUG - 2021-07-01 11:47:39 --> Total execution time: 0.0766
INFO - 2021-07-01 11:48:19 --> Config Class Initialized
INFO - 2021-07-01 11:48:19 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:48:19 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:48:19 --> Utf8 Class Initialized
INFO - 2021-07-01 11:48:19 --> URI Class Initialized
INFO - 2021-07-01 11:48:19 --> Router Class Initialized
INFO - 2021-07-01 11:48:19 --> Output Class Initialized
INFO - 2021-07-01 11:48:19 --> Security Class Initialized
DEBUG - 2021-07-01 11:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:48:19 --> Input Class Initialized
INFO - 2021-07-01 11:48:19 --> Language Class Initialized
INFO - 2021-07-01 11:48:19 --> Loader Class Initialized
INFO - 2021-07-01 11:48:19 --> Helper loaded: html_helper
INFO - 2021-07-01 11:48:19 --> Helper loaded: url_helper
INFO - 2021-07-01 11:48:19 --> Helper loaded: form_helper
INFO - 2021-07-01 11:48:19 --> Database Driver Class Initialized
INFO - 2021-07-01 11:48:19 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:48:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:48:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:48:19 --> Encryption Class Initialized
INFO - 2021-07-01 11:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:48:19 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:48:19 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:48:19 --> Model "user_model" initialized
INFO - 2021-07-01 11:48:19 --> Model "role_model" initialized
INFO - 2021-07-01 11:48:19 --> Controller Class Initialized
INFO - 2021-07-01 11:48:19 --> Helper loaded: language_helper
INFO - 2021-07-01 11:48:19 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:48:19 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:48:19 --> Model "Product_model" initialized
INFO - 2021-07-01 11:48:19 --> Model "StateGSTCode_modal" initialized
INFO - 2021-07-01 11:48:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:48:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:48:19 --> Severity: Notice --> Undefined variable: quotations D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\create_quotation.php 32
INFO - 2021-07-01 11:48:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/create_quotation.php
INFO - 2021-07-01 11:48:19 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:48:19 --> Final output sent to browser
DEBUG - 2021-07-01 11:48:19 --> Total execution time: 0.0715
INFO - 2021-07-01 11:49:07 --> Config Class Initialized
INFO - 2021-07-01 11:49:07 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:49:07 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:49:07 --> Utf8 Class Initialized
INFO - 2021-07-01 11:49:07 --> URI Class Initialized
INFO - 2021-07-01 11:49:07 --> Router Class Initialized
INFO - 2021-07-01 11:49:07 --> Output Class Initialized
INFO - 2021-07-01 11:49:07 --> Security Class Initialized
DEBUG - 2021-07-01 11:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:49:07 --> Input Class Initialized
INFO - 2021-07-01 11:49:07 --> Language Class Initialized
INFO - 2021-07-01 11:49:07 --> Loader Class Initialized
INFO - 2021-07-01 11:49:07 --> Helper loaded: html_helper
INFO - 2021-07-01 11:49:07 --> Helper loaded: url_helper
INFO - 2021-07-01 11:49:07 --> Helper loaded: form_helper
INFO - 2021-07-01 11:49:07 --> Database Driver Class Initialized
INFO - 2021-07-01 11:49:07 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:49:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:49:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:49:07 --> Encryption Class Initialized
INFO - 2021-07-01 11:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:49:07 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:49:07 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:49:07 --> Model "user_model" initialized
INFO - 2021-07-01 11:49:07 --> Model "role_model" initialized
INFO - 2021-07-01 11:49:07 --> Controller Class Initialized
INFO - 2021-07-01 11:49:07 --> Helper loaded: language_helper
INFO - 2021-07-01 11:49:07 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:49:07 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:49:07 --> Final output sent to browser
DEBUG - 2021-07-01 11:49:07 --> Total execution time: 0.0938
INFO - 2021-07-01 11:49:11 --> Config Class Initialized
INFO - 2021-07-01 11:49:11 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:49:11 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:49:11 --> Utf8 Class Initialized
INFO - 2021-07-01 11:49:11 --> URI Class Initialized
INFO - 2021-07-01 11:49:11 --> Router Class Initialized
INFO - 2021-07-01 11:49:11 --> Output Class Initialized
INFO - 2021-07-01 11:49:11 --> Security Class Initialized
DEBUG - 2021-07-01 11:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:49:11 --> Input Class Initialized
INFO - 2021-07-01 11:49:11 --> Language Class Initialized
INFO - 2021-07-01 11:49:11 --> Loader Class Initialized
INFO - 2021-07-01 11:49:11 --> Helper loaded: html_helper
INFO - 2021-07-01 11:49:11 --> Helper loaded: url_helper
INFO - 2021-07-01 11:49:11 --> Helper loaded: form_helper
INFO - 2021-07-01 11:49:11 --> Database Driver Class Initialized
INFO - 2021-07-01 11:49:11 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:49:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:49:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:49:11 --> Encryption Class Initialized
INFO - 2021-07-01 11:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:49:11 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:49:11 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:49:11 --> Model "user_model" initialized
INFO - 2021-07-01 11:49:11 --> Model "role_model" initialized
INFO - 2021-07-01 11:49:11 --> Controller Class Initialized
INFO - 2021-07-01 11:49:11 --> Helper loaded: language_helper
INFO - 2021-07-01 11:49:11 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:49:11 --> Model "Customer_model" initialized
INFO - 2021-07-01 11:49:11 --> Final output sent to browser
DEBUG - 2021-07-01 11:49:11 --> Total execution time: 0.0650
INFO - 2021-07-01 11:49:47 --> Config Class Initialized
INFO - 2021-07-01 11:49:47 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:49:47 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:49:47 --> Utf8 Class Initialized
INFO - 2021-07-01 11:49:47 --> URI Class Initialized
INFO - 2021-07-01 11:49:47 --> Router Class Initialized
INFO - 2021-07-01 11:49:47 --> Output Class Initialized
INFO - 2021-07-01 11:49:47 --> Security Class Initialized
DEBUG - 2021-07-01 11:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:49:47 --> Input Class Initialized
INFO - 2021-07-01 11:49:47 --> Language Class Initialized
INFO - 2021-07-01 11:49:47 --> Loader Class Initialized
INFO - 2021-07-01 11:49:47 --> Helper loaded: html_helper
INFO - 2021-07-01 11:49:47 --> Helper loaded: url_helper
INFO - 2021-07-01 11:49:47 --> Helper loaded: form_helper
INFO - 2021-07-01 11:49:47 --> Database Driver Class Initialized
INFO - 2021-07-01 11:49:47 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:49:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:49:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:49:47 --> Encryption Class Initialized
INFO - 2021-07-01 11:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:49:47 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:49:47 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:49:47 --> Model "user_model" initialized
INFO - 2021-07-01 11:49:47 --> Model "role_model" initialized
INFO - 2021-07-01 11:49:47 --> Controller Class Initialized
INFO - 2021-07-01 11:49:47 --> Helper loaded: language_helper
INFO - 2021-07-01 11:49:47 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:49:47 --> Model "Product_model" initialized
INFO - 2021-07-01 11:49:47 --> Final output sent to browser
DEBUG - 2021-07-01 11:49:47 --> Total execution time: 0.0991
INFO - 2021-07-01 11:50:03 --> Config Class Initialized
INFO - 2021-07-01 11:50:03 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:50:03 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:50:03 --> Utf8 Class Initialized
INFO - 2021-07-01 11:50:03 --> URI Class Initialized
INFO - 2021-07-01 11:50:03 --> Router Class Initialized
INFO - 2021-07-01 11:50:03 --> Output Class Initialized
INFO - 2021-07-01 11:50:03 --> Security Class Initialized
DEBUG - 2021-07-01 11:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:50:03 --> Input Class Initialized
INFO - 2021-07-01 11:50:03 --> Language Class Initialized
INFO - 2021-07-01 11:50:03 --> Loader Class Initialized
INFO - 2021-07-01 11:50:03 --> Helper loaded: html_helper
INFO - 2021-07-01 11:50:03 --> Helper loaded: url_helper
INFO - 2021-07-01 11:50:03 --> Helper loaded: form_helper
INFO - 2021-07-01 11:50:03 --> Database Driver Class Initialized
INFO - 2021-07-01 11:50:03 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:50:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:50:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:50:03 --> Encryption Class Initialized
INFO - 2021-07-01 11:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:50:03 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:50:03 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:50:03 --> Model "user_model" initialized
INFO - 2021-07-01 11:50:03 --> Model "role_model" initialized
INFO - 2021-07-01 11:50:03 --> Controller Class Initialized
INFO - 2021-07-01 11:50:03 --> Helper loaded: language_helper
INFO - 2021-07-01 11:50:03 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:50:03 --> Model "Quotation_model" initialized
INFO - 2021-07-01 11:50:03 --> Final output sent to browser
DEBUG - 2021-07-01 11:50:03 --> Total execution time: 0.0721
INFO - 2021-07-01 11:50:04 --> Config Class Initialized
INFO - 2021-07-01 11:50:04 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:50:04 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:50:04 --> Utf8 Class Initialized
INFO - 2021-07-01 11:50:04 --> URI Class Initialized
INFO - 2021-07-01 11:50:04 --> Router Class Initialized
INFO - 2021-07-01 11:50:04 --> Output Class Initialized
INFO - 2021-07-01 11:50:04 --> Security Class Initialized
DEBUG - 2021-07-01 11:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:50:04 --> Input Class Initialized
INFO - 2021-07-01 11:50:04 --> Language Class Initialized
INFO - 2021-07-01 11:50:04 --> Loader Class Initialized
INFO - 2021-07-01 11:50:04 --> Helper loaded: html_helper
INFO - 2021-07-01 11:50:04 --> Helper loaded: url_helper
INFO - 2021-07-01 11:50:04 --> Helper loaded: form_helper
INFO - 2021-07-01 11:50:04 --> Database Driver Class Initialized
INFO - 2021-07-01 11:50:04 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:50:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:50:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:50:04 --> Encryption Class Initialized
INFO - 2021-07-01 11:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:50:04 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:50:04 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:50:04 --> Model "user_model" initialized
INFO - 2021-07-01 11:50:04 --> Model "role_model" initialized
INFO - 2021-07-01 11:50:04 --> Controller Class Initialized
INFO - 2021-07-01 11:50:04 --> Helper loaded: language_helper
INFO - 2021-07-01 11:50:04 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:50:04 --> Model "Quotation_model" initialized
INFO - 2021-07-01 11:50:04 --> Final output sent to browser
DEBUG - 2021-07-01 11:50:04 --> Total execution time: 0.0726
INFO - 2021-07-01 11:50:06 --> Config Class Initialized
INFO - 2021-07-01 11:50:06 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:50:06 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:50:06 --> Utf8 Class Initialized
INFO - 2021-07-01 11:50:06 --> URI Class Initialized
INFO - 2021-07-01 11:50:06 --> Router Class Initialized
INFO - 2021-07-01 11:50:06 --> Output Class Initialized
INFO - 2021-07-01 11:50:06 --> Security Class Initialized
DEBUG - 2021-07-01 11:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:50:06 --> Input Class Initialized
INFO - 2021-07-01 11:50:06 --> Language Class Initialized
INFO - 2021-07-01 11:50:06 --> Loader Class Initialized
INFO - 2021-07-01 11:50:06 --> Helper loaded: html_helper
INFO - 2021-07-01 11:50:06 --> Helper loaded: url_helper
INFO - 2021-07-01 11:50:06 --> Helper loaded: form_helper
INFO - 2021-07-01 11:50:06 --> Database Driver Class Initialized
INFO - 2021-07-01 11:50:06 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:50:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:50:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:50:06 --> Encryption Class Initialized
INFO - 2021-07-01 11:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:50:06 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:50:06 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:50:06 --> Model "user_model" initialized
INFO - 2021-07-01 11:50:06 --> Model "role_model" initialized
INFO - 2021-07-01 11:50:06 --> Controller Class Initialized
INFO - 2021-07-01 11:50:06 --> Helper loaded: language_helper
INFO - 2021-07-01 11:50:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:50:06 --> Model "Quotation_model" initialized
INFO - 2021-07-01 11:50:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:50:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:50:06 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 11:50:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 11:50:06 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:50:06 --> Final output sent to browser
DEBUG - 2021-07-01 11:50:06 --> Total execution time: 0.0869
INFO - 2021-07-01 11:50:06 --> Config Class Initialized
INFO - 2021-07-01 11:50:06 --> Hooks Class Initialized
INFO - 2021-07-01 11:50:06 --> Config Class Initialized
DEBUG - 2021-07-01 11:50:06 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:50:06 --> Hooks Class Initialized
INFO - 2021-07-01 11:50:06 --> Utf8 Class Initialized
INFO - 2021-07-01 11:50:06 --> URI Class Initialized
INFO - 2021-07-01 11:50:06 --> Router Class Initialized
DEBUG - 2021-07-01 11:50:06 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:50:06 --> Utf8 Class Initialized
INFO - 2021-07-01 11:50:06 --> URI Class Initialized
INFO - 2021-07-01 11:50:06 --> Output Class Initialized
INFO - 2021-07-01 11:50:06 --> Router Class Initialized
INFO - 2021-07-01 11:50:06 --> Security Class Initialized
INFO - 2021-07-01 11:50:06 --> Output Class Initialized
DEBUG - 2021-07-01 11:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:50:06 --> Input Class Initialized
INFO - 2021-07-01 11:50:06 --> Language Class Initialized
INFO - 2021-07-01 11:50:06 --> Security Class Initialized
DEBUG - 2021-07-01 11:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:50:06 --> Input Class Initialized
INFO - 2021-07-01 11:50:06 --> Language Class Initialized
INFO - 2021-07-01 11:50:06 --> Loader Class Initialized
INFO - 2021-07-01 11:50:06 --> Helper loaded: html_helper
INFO - 2021-07-01 11:50:06 --> Helper loaded: url_helper
INFO - 2021-07-01 11:50:06 --> Loader Class Initialized
INFO - 2021-07-01 11:50:06 --> Helper loaded: html_helper
INFO - 2021-07-01 11:50:06 --> Helper loaded: form_helper
INFO - 2021-07-01 11:50:06 --> Helper loaded: url_helper
INFO - 2021-07-01 11:50:06 --> Helper loaded: form_helper
INFO - 2021-07-01 11:50:06 --> Database Driver Class Initialized
INFO - 2021-07-01 11:50:06 --> Database Driver Class Initialized
INFO - 2021-07-01 11:50:06 --> Form Validation Class Initialized
INFO - 2021-07-01 11:50:06 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:50:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:50:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:50:06 --> Encryption Class Initialized
DEBUG - 2021-07-01 11:50:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:50:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:50:06 --> Encryption Class Initialized
INFO - 2021-07-01 11:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:50:06 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:50:06 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:50:06 --> Model "user_model" initialized
INFO - 2021-07-01 11:50:06 --> Model "role_model" initialized
INFO - 2021-07-01 11:50:06 --> Controller Class Initialized
INFO - 2021-07-01 11:50:06 --> Helper loaded: language_helper
INFO - 2021-07-01 11:50:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:50:06 --> Model "Quotation_model" initialized
INFO - 2021-07-01 11:50:06 --> Final output sent to browser
DEBUG - 2021-07-01 11:50:06 --> Total execution time: 0.1038
INFO - 2021-07-01 11:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:50:06 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:50:06 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:50:06 --> Model "user_model" initialized
INFO - 2021-07-01 11:50:06 --> Model "role_model" initialized
INFO - 2021-07-01 11:50:06 --> Controller Class Initialized
INFO - 2021-07-01 11:50:06 --> Helper loaded: language_helper
INFO - 2021-07-01 11:50:06 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:50:06 --> Model "Quotation_model" initialized
INFO - 2021-07-01 11:50:06 --> Final output sent to browser
DEBUG - 2021-07-01 11:50:06 --> Total execution time: 0.1139
INFO - 2021-07-01 11:50:43 --> Config Class Initialized
INFO - 2021-07-01 11:50:43 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:50:43 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:50:43 --> Utf8 Class Initialized
INFO - 2021-07-01 11:50:43 --> URI Class Initialized
INFO - 2021-07-01 11:50:43 --> Router Class Initialized
INFO - 2021-07-01 11:50:43 --> Output Class Initialized
INFO - 2021-07-01 11:50:43 --> Security Class Initialized
DEBUG - 2021-07-01 11:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:50:43 --> Input Class Initialized
INFO - 2021-07-01 11:50:43 --> Language Class Initialized
INFO - 2021-07-01 11:50:43 --> Loader Class Initialized
INFO - 2021-07-01 11:50:43 --> Helper loaded: html_helper
INFO - 2021-07-01 11:50:43 --> Helper loaded: url_helper
INFO - 2021-07-01 11:50:43 --> Helper loaded: form_helper
INFO - 2021-07-01 11:50:43 --> Database Driver Class Initialized
INFO - 2021-07-01 11:50:43 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:50:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:50:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:50:43 --> Encryption Class Initialized
INFO - 2021-07-01 11:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:50:43 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:50:43 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:50:43 --> Model "user_model" initialized
INFO - 2021-07-01 11:50:43 --> Model "role_model" initialized
INFO - 2021-07-01 11:50:43 --> Controller Class Initialized
INFO - 2021-07-01 11:50:43 --> Helper loaded: language_helper
INFO - 2021-07-01 11:50:43 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:50:43 --> Model "Quotation_model" initialized
INFO - 2021-07-01 11:50:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:50:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:50:43 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 11:50:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 11:50:43 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:50:43 --> Final output sent to browser
DEBUG - 2021-07-01 11:50:43 --> Total execution time: 0.0798
INFO - 2021-07-01 11:50:44 --> Config Class Initialized
INFO - 2021-07-01 11:50:44 --> Hooks Class Initialized
INFO - 2021-07-01 11:50:44 --> Config Class Initialized
INFO - 2021-07-01 11:50:44 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:50:44 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:50:44 --> Utf8 Class Initialized
INFO - 2021-07-01 11:50:44 --> URI Class Initialized
DEBUG - 2021-07-01 11:50:44 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:50:44 --> Utf8 Class Initialized
INFO - 2021-07-01 11:50:44 --> Router Class Initialized
INFO - 2021-07-01 11:50:44 --> URI Class Initialized
INFO - 2021-07-01 11:50:44 --> Output Class Initialized
INFO - 2021-07-01 11:50:44 --> Router Class Initialized
INFO - 2021-07-01 11:50:44 --> Security Class Initialized
INFO - 2021-07-01 11:50:44 --> Output Class Initialized
DEBUG - 2021-07-01 11:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:50:44 --> Input Class Initialized
INFO - 2021-07-01 11:50:44 --> Security Class Initialized
INFO - 2021-07-01 11:50:44 --> Language Class Initialized
DEBUG - 2021-07-01 11:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:50:44 --> Input Class Initialized
INFO - 2021-07-01 11:50:44 --> Language Class Initialized
INFO - 2021-07-01 11:50:44 --> Loader Class Initialized
INFO - 2021-07-01 11:50:44 --> Helper loaded: html_helper
INFO - 2021-07-01 11:50:44 --> Loader Class Initialized
INFO - 2021-07-01 11:50:44 --> Helper loaded: url_helper
INFO - 2021-07-01 11:50:44 --> Helper loaded: html_helper
INFO - 2021-07-01 11:50:44 --> Helper loaded: form_helper
INFO - 2021-07-01 11:50:44 --> Helper loaded: url_helper
INFO - 2021-07-01 11:50:44 --> Helper loaded: form_helper
INFO - 2021-07-01 11:50:44 --> Database Driver Class Initialized
INFO - 2021-07-01 11:50:44 --> Database Driver Class Initialized
INFO - 2021-07-01 11:50:44 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:50:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:50:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:50:44 --> Encryption Class Initialized
INFO - 2021-07-01 11:50:44 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:50:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:50:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:50:44 --> Encryption Class Initialized
INFO - 2021-07-01 11:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:50:44 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:50:44 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:50:44 --> Model "user_model" initialized
INFO - 2021-07-01 11:50:44 --> Model "role_model" initialized
INFO - 2021-07-01 11:50:44 --> Controller Class Initialized
INFO - 2021-07-01 11:50:44 --> Helper loaded: language_helper
INFO - 2021-07-01 11:50:44 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:50:44 --> Model "Quotation_model" initialized
INFO - 2021-07-01 11:50:44 --> Final output sent to browser
DEBUG - 2021-07-01 11:50:44 --> Total execution time: 0.0849
INFO - 2021-07-01 11:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:50:44 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:50:44 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:50:44 --> Model "user_model" initialized
INFO - 2021-07-01 11:50:44 --> Model "role_model" initialized
INFO - 2021-07-01 11:50:44 --> Controller Class Initialized
INFO - 2021-07-01 11:50:44 --> Helper loaded: language_helper
INFO - 2021-07-01 11:50:44 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:50:44 --> Model "Quotation_model" initialized
INFO - 2021-07-01 11:50:44 --> Final output sent to browser
DEBUG - 2021-07-01 11:50:44 --> Total execution time: 0.0981
INFO - 2021-07-01 11:50:57 --> Config Class Initialized
INFO - 2021-07-01 11:50:57 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:50:57 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:50:57 --> Utf8 Class Initialized
INFO - 2021-07-01 11:50:57 --> URI Class Initialized
INFO - 2021-07-01 11:50:57 --> Router Class Initialized
INFO - 2021-07-01 11:50:57 --> Output Class Initialized
INFO - 2021-07-01 11:50:57 --> Security Class Initialized
DEBUG - 2021-07-01 11:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:50:57 --> Input Class Initialized
INFO - 2021-07-01 11:50:57 --> Language Class Initialized
INFO - 2021-07-01 11:50:57 --> Loader Class Initialized
INFO - 2021-07-01 11:50:57 --> Helper loaded: html_helper
INFO - 2021-07-01 11:50:57 --> Helper loaded: url_helper
INFO - 2021-07-01 11:50:57 --> Helper loaded: form_helper
INFO - 2021-07-01 11:50:57 --> Database Driver Class Initialized
INFO - 2021-07-01 11:50:57 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:50:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:50:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:50:57 --> Encryption Class Initialized
INFO - 2021-07-01 11:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:50:57 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:50:57 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:50:57 --> Model "user_model" initialized
INFO - 2021-07-01 11:50:57 --> Model "role_model" initialized
INFO - 2021-07-01 11:50:57 --> Controller Class Initialized
INFO - 2021-07-01 11:50:57 --> Helper loaded: language_helper
INFO - 2021-07-01 11:50:57 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:50:57 --> Model "Quotation_model" initialized
INFO - 2021-07-01 11:50:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:50:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:50:57 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 11:50:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 11:50:57 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:50:57 --> Final output sent to browser
DEBUG - 2021-07-01 11:50:57 --> Total execution time: 0.0740
INFO - 2021-07-01 11:50:58 --> Config Class Initialized
INFO - 2021-07-01 11:50:58 --> Hooks Class Initialized
INFO - 2021-07-01 11:50:58 --> Config Class Initialized
INFO - 2021-07-01 11:50:58 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:50:58 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:50:58 --> Utf8 Class Initialized
DEBUG - 2021-07-01 11:50:58 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:50:58 --> Utf8 Class Initialized
INFO - 2021-07-01 11:50:58 --> URI Class Initialized
INFO - 2021-07-01 11:50:58 --> URI Class Initialized
INFO - 2021-07-01 11:50:58 --> Router Class Initialized
INFO - 2021-07-01 11:50:58 --> Router Class Initialized
INFO - 2021-07-01 11:50:58 --> Output Class Initialized
INFO - 2021-07-01 11:50:58 --> Output Class Initialized
INFO - 2021-07-01 11:50:58 --> Security Class Initialized
INFO - 2021-07-01 11:50:58 --> Security Class Initialized
DEBUG - 2021-07-01 11:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:50:58 --> Input Class Initialized
INFO - 2021-07-01 11:50:58 --> Language Class Initialized
DEBUG - 2021-07-01 11:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:50:58 --> Input Class Initialized
INFO - 2021-07-01 11:50:58 --> Language Class Initialized
INFO - 2021-07-01 11:50:58 --> Loader Class Initialized
INFO - 2021-07-01 11:50:58 --> Loader Class Initialized
INFO - 2021-07-01 11:50:58 --> Helper loaded: html_helper
INFO - 2021-07-01 11:50:58 --> Helper loaded: html_helper
INFO - 2021-07-01 11:50:58 --> Helper loaded: url_helper
INFO - 2021-07-01 11:50:58 --> Helper loaded: url_helper
INFO - 2021-07-01 11:50:58 --> Helper loaded: form_helper
INFO - 2021-07-01 11:50:58 --> Helper loaded: form_helper
INFO - 2021-07-01 11:50:58 --> Database Driver Class Initialized
INFO - 2021-07-01 11:50:58 --> Database Driver Class Initialized
INFO - 2021-07-01 11:50:58 --> Form Validation Class Initialized
INFO - 2021-07-01 11:50:58 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:50:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:50:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:50:58 --> Encryption Class Initialized
DEBUG - 2021-07-01 11:50:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:50:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:50:58 --> Encryption Class Initialized
INFO - 2021-07-01 11:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:50:58 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:50:58 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:50:58 --> Model "user_model" initialized
INFO - 2021-07-01 11:50:58 --> Model "role_model" initialized
INFO - 2021-07-01 11:50:58 --> Controller Class Initialized
INFO - 2021-07-01 11:50:58 --> Helper loaded: language_helper
INFO - 2021-07-01 11:50:58 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:50:58 --> Model "Quotation_model" initialized
INFO - 2021-07-01 11:50:58 --> Final output sent to browser
DEBUG - 2021-07-01 11:50:58 --> Total execution time: 0.0710
INFO - 2021-07-01 11:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:50:58 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:50:58 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:50:58 --> Model "user_model" initialized
INFO - 2021-07-01 11:50:58 --> Model "role_model" initialized
INFO - 2021-07-01 11:50:58 --> Controller Class Initialized
INFO - 2021-07-01 11:50:58 --> Helper loaded: language_helper
INFO - 2021-07-01 11:50:58 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:50:58 --> Model "Quotation_model" initialized
INFO - 2021-07-01 11:50:58 --> Final output sent to browser
DEBUG - 2021-07-01 11:50:58 --> Total execution time: 0.0858
INFO - 2021-07-01 11:51:42 --> Config Class Initialized
INFO - 2021-07-01 11:51:42 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:51:42 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:51:42 --> Utf8 Class Initialized
INFO - 2021-07-01 11:51:42 --> URI Class Initialized
INFO - 2021-07-01 11:51:42 --> Router Class Initialized
INFO - 2021-07-01 11:51:42 --> Output Class Initialized
INFO - 2021-07-01 11:51:42 --> Security Class Initialized
DEBUG - 2021-07-01 11:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:51:42 --> Input Class Initialized
INFO - 2021-07-01 11:51:42 --> Language Class Initialized
INFO - 2021-07-01 11:51:42 --> Loader Class Initialized
INFO - 2021-07-01 11:51:42 --> Helper loaded: html_helper
INFO - 2021-07-01 11:51:42 --> Helper loaded: url_helper
INFO - 2021-07-01 11:51:42 --> Helper loaded: form_helper
INFO - 2021-07-01 11:51:42 --> Database Driver Class Initialized
INFO - 2021-07-01 11:51:42 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:51:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:51:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:51:42 --> Encryption Class Initialized
INFO - 2021-07-01 11:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:51:42 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:51:42 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:51:42 --> Model "user_model" initialized
INFO - 2021-07-01 11:51:42 --> Model "role_model" initialized
INFO - 2021-07-01 11:51:42 --> Controller Class Initialized
INFO - 2021-07-01 11:51:42 --> Helper loaded: language_helper
INFO - 2021-07-01 11:51:42 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:51:42 --> Model "Quotation_model" initialized
INFO - 2021-07-01 11:51:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\header.php
INFO - 2021-07-01 11:51:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\sidebar.php
ERROR - 2021-07-01 11:51:42 --> Severity: Notice --> Object of class CI_DB_sqlsrv_result could not be converted to int D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations\view_quotation.php 40
INFO - 2021-07-01 11:51:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\Quotations/view_quotation.php
INFO - 2021-07-01 11:51:42 --> File loaded: D:\development\web\xampp\htdocs\proadmin\proadmin\application\views\footer.php
INFO - 2021-07-01 11:51:42 --> Final output sent to browser
DEBUG - 2021-07-01 11:51:42 --> Total execution time: 0.0761
INFO - 2021-07-01 11:51:43 --> Config Class Initialized
INFO - 2021-07-01 11:51:43 --> Hooks Class Initialized
INFO - 2021-07-01 11:51:43 --> Config Class Initialized
INFO - 2021-07-01 11:51:43 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:51:43 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:51:43 --> Utf8 Class Initialized
DEBUG - 2021-07-01 11:51:43 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:51:43 --> Utf8 Class Initialized
INFO - 2021-07-01 11:51:43 --> URI Class Initialized
INFO - 2021-07-01 11:51:43 --> URI Class Initialized
INFO - 2021-07-01 11:51:43 --> Router Class Initialized
INFO - 2021-07-01 11:51:43 --> Router Class Initialized
INFO - 2021-07-01 11:51:43 --> Output Class Initialized
INFO - 2021-07-01 11:51:43 --> Output Class Initialized
INFO - 2021-07-01 11:51:43 --> Security Class Initialized
INFO - 2021-07-01 11:51:43 --> Security Class Initialized
DEBUG - 2021-07-01 11:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-01 11:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:51:43 --> Input Class Initialized
INFO - 2021-07-01 11:51:43 --> Language Class Initialized
INFO - 2021-07-01 11:51:43 --> Loader Class Initialized
INFO - 2021-07-01 11:51:43 --> Helper loaded: html_helper
INFO - 2021-07-01 11:51:43 --> Helper loaded: url_helper
INFO - 2021-07-01 11:51:43 --> Helper loaded: form_helper
INFO - 2021-07-01 11:51:43 --> Input Class Initialized
INFO - 2021-07-01 11:51:43 --> Language Class Initialized
INFO - 2021-07-01 11:51:43 --> Loader Class Initialized
INFO - 2021-07-01 11:51:43 --> Database Driver Class Initialized
INFO - 2021-07-01 11:51:43 --> Helper loaded: html_helper
INFO - 2021-07-01 11:51:43 --> Helper loaded: url_helper
INFO - 2021-07-01 11:51:43 --> Helper loaded: form_helper
INFO - 2021-07-01 11:51:43 --> Database Driver Class Initialized
INFO - 2021-07-01 11:51:43 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:51:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:51:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:51:43 --> Encryption Class Initialized
INFO - 2021-07-01 11:51:43 --> Form Validation Class Initialized
DEBUG - 2021-07-01 11:51:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-07-01 11:51:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-07-01 11:51:43 --> Encryption Class Initialized
INFO - 2021-07-01 11:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:51:43 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:51:43 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:51:43 --> Model "user_model" initialized
INFO - 2021-07-01 11:51:43 --> Model "role_model" initialized
INFO - 2021-07-01 11:51:43 --> Controller Class Initialized
INFO - 2021-07-01 11:51:43 --> Helper loaded: language_helper
INFO - 2021-07-01 11:51:43 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:51:43 --> Model "Quotation_model" initialized
INFO - 2021-07-01 11:51:43 --> Final output sent to browser
DEBUG - 2021-07-01 11:51:43 --> Total execution time: 0.0804
INFO - 2021-07-01 11:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:51:43 --> Model "vendor_model" initialized
INFO - 2021-07-01 11:51:43 --> Model "coupon_model" initialized
INFO - 2021-07-01 11:51:43 --> Model "user_model" initialized
INFO - 2021-07-01 11:51:43 --> Model "role_model" initialized
INFO - 2021-07-01 11:51:43 --> Controller Class Initialized
INFO - 2021-07-01 11:51:43 --> Helper loaded: language_helper
INFO - 2021-07-01 11:51:43 --> Language file loaded: language/english/content_lang.php
INFO - 2021-07-01 11:51:43 --> Model "Quotation_model" initialized
INFO - 2021-07-01 11:51:43 --> Final output sent to browser
DEBUG - 2021-07-01 11:51:43 --> Total execution time: 0.0905
