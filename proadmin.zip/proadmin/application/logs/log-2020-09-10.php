<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-10 04:57:29 --> Config Class Initialized
INFO - 2020-09-10 04:57:29 --> Hooks Class Initialized
DEBUG - 2020-09-10 04:57:30 --> UTF-8 Support Enabled
INFO - 2020-09-10 04:57:30 --> Utf8 Class Initialized
INFO - 2020-09-10 04:57:30 --> URI Class Initialized
INFO - 2020-09-10 04:57:30 --> Router Class Initialized
INFO - 2020-09-10 04:57:30 --> Output Class Initialized
INFO - 2020-09-10 04:57:30 --> Security Class Initialized
DEBUG - 2020-09-10 04:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 04:57:30 --> Input Class Initialized
INFO - 2020-09-10 04:57:31 --> Language Class Initialized
INFO - 2020-09-10 04:57:31 --> Loader Class Initialized
INFO - 2020-09-10 04:57:31 --> Helper loaded: html_helper
INFO - 2020-09-10 04:57:31 --> Helper loaded: url_helper
INFO - 2020-09-10 04:57:31 --> Helper loaded: form_helper
INFO - 2020-09-10 04:57:32 --> Database Driver Class Initialized
INFO - 2020-09-10 04:57:32 --> Form Validation Class Initialized
DEBUG - 2020-09-10 04:57:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 04:57:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 04:57:32 --> Encryption Class Initialized
INFO - 2020-09-10 04:57:32 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 04:57:32 --> Controller Class Initialized
INFO - 2020-09-10 04:57:33 --> Helper loaded: language_helper
INFO - 2020-09-10 04:57:33 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-10 04:57:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-10 04:57:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-10 04:57:33 --> Model "User" initialized
INFO - 2020-09-10 04:57:34 --> Config Class Initialized
INFO - 2020-09-10 04:57:34 --> Hooks Class Initialized
DEBUG - 2020-09-10 04:57:34 --> UTF-8 Support Enabled
INFO - 2020-09-10 04:57:34 --> Utf8 Class Initialized
INFO - 2020-09-10 04:57:34 --> URI Class Initialized
INFO - 2020-09-10 04:57:34 --> Router Class Initialized
INFO - 2020-09-10 04:57:34 --> Output Class Initialized
INFO - 2020-09-10 04:57:34 --> Security Class Initialized
DEBUG - 2020-09-10 04:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 04:57:34 --> Input Class Initialized
INFO - 2020-09-10 04:57:34 --> Language Class Initialized
INFO - 2020-09-10 04:57:34 --> Loader Class Initialized
INFO - 2020-09-10 04:57:34 --> Helper loaded: html_helper
INFO - 2020-09-10 04:57:34 --> Helper loaded: url_helper
INFO - 2020-09-10 04:57:34 --> Helper loaded: form_helper
INFO - 2020-09-10 04:57:34 --> Database Driver Class Initialized
INFO - 2020-09-10 04:57:34 --> Form Validation Class Initialized
DEBUG - 2020-09-10 04:57:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 04:57:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 04:57:34 --> Encryption Class Initialized
INFO - 2020-09-10 04:57:34 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 04:57:34 --> Controller Class Initialized
INFO - 2020-09-10 04:57:34 --> Helper loaded: language_helper
INFO - 2020-09-10 04:57:34 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 04:57:34 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-10 04:57:34 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-10 04:57:35 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-10 04:57:35 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-10 04:57:35 --> Final output sent to browser
DEBUG - 2020-09-10 04:57:35 --> Total execution time: 0.8319
INFO - 2020-09-10 04:57:38 --> Config Class Initialized
INFO - 2020-09-10 04:57:38 --> Hooks Class Initialized
DEBUG - 2020-09-10 04:57:38 --> UTF-8 Support Enabled
INFO - 2020-09-10 04:57:38 --> Utf8 Class Initialized
INFO - 2020-09-10 04:57:38 --> URI Class Initialized
INFO - 2020-09-10 04:57:38 --> Router Class Initialized
INFO - 2020-09-10 04:57:38 --> Output Class Initialized
INFO - 2020-09-10 04:57:38 --> Security Class Initialized
DEBUG - 2020-09-10 04:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 04:57:38 --> Input Class Initialized
INFO - 2020-09-10 04:57:38 --> Language Class Initialized
INFO - 2020-09-10 04:57:38 --> Loader Class Initialized
INFO - 2020-09-10 04:57:38 --> Helper loaded: html_helper
INFO - 2020-09-10 04:57:38 --> Helper loaded: url_helper
INFO - 2020-09-10 04:57:38 --> Helper loaded: form_helper
INFO - 2020-09-10 04:57:38 --> Database Driver Class Initialized
INFO - 2020-09-10 04:57:38 --> Form Validation Class Initialized
DEBUG - 2020-09-10 04:57:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 04:57:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 04:57:39 --> Encryption Class Initialized
INFO - 2020-09-10 04:57:39 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 04:57:39 --> Controller Class Initialized
INFO - 2020-09-10 04:57:39 --> Helper loaded: language_helper
INFO - 2020-09-10 04:57:39 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 04:57:39 --> Final output sent to browser
DEBUG - 2020-09-10 04:57:39 --> Total execution time: 0.6418
INFO - 2020-09-10 04:57:39 --> Config Class Initialized
INFO - 2020-09-10 04:57:39 --> Hooks Class Initialized
DEBUG - 2020-09-10 04:57:39 --> UTF-8 Support Enabled
INFO - 2020-09-10 04:57:39 --> Utf8 Class Initialized
INFO - 2020-09-10 04:57:39 --> URI Class Initialized
DEBUG - 2020-09-10 04:57:39 --> No URI present. Default controller set.
INFO - 2020-09-10 04:57:39 --> Router Class Initialized
INFO - 2020-09-10 04:57:39 --> Output Class Initialized
INFO - 2020-09-10 04:57:39 --> Security Class Initialized
DEBUG - 2020-09-10 04:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 04:57:39 --> Input Class Initialized
INFO - 2020-09-10 04:57:39 --> Language Class Initialized
INFO - 2020-09-10 04:57:39 --> Loader Class Initialized
INFO - 2020-09-10 04:57:39 --> Helper loaded: html_helper
INFO - 2020-09-10 04:57:39 --> Helper loaded: url_helper
INFO - 2020-09-10 04:57:39 --> Helper loaded: form_helper
INFO - 2020-09-10 04:57:39 --> Database Driver Class Initialized
INFO - 2020-09-10 04:57:39 --> Form Validation Class Initialized
DEBUG - 2020-09-10 04:57:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 04:57:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 04:57:40 --> Encryption Class Initialized
INFO - 2020-09-10 04:57:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 04:57:40 --> Controller Class Initialized
INFO - 2020-09-10 04:57:40 --> Helper loaded: language_helper
INFO - 2020-09-10 04:57:40 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 04:57:40 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-10 04:57:40 --> Final output sent to browser
DEBUG - 2020-09-10 04:57:40 --> Total execution time: 0.5465
INFO - 2020-09-10 13:28:08 --> Config Class Initialized
INFO - 2020-09-10 13:28:08 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:28:08 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:28:08 --> Utf8 Class Initialized
INFO - 2020-09-10 13:28:08 --> URI Class Initialized
DEBUG - 2020-09-10 13:28:08 --> No URI present. Default controller set.
INFO - 2020-09-10 13:28:08 --> Router Class Initialized
INFO - 2020-09-10 13:28:08 --> Output Class Initialized
INFO - 2020-09-10 13:28:08 --> Security Class Initialized
DEBUG - 2020-09-10 13:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:28:09 --> Input Class Initialized
INFO - 2020-09-10 13:28:09 --> Language Class Initialized
INFO - 2020-09-10 13:28:09 --> Loader Class Initialized
INFO - 2020-09-10 13:28:09 --> Helper loaded: html_helper
INFO - 2020-09-10 13:28:09 --> Helper loaded: url_helper
INFO - 2020-09-10 13:28:09 --> Helper loaded: form_helper
INFO - 2020-09-10 13:28:09 --> Database Driver Class Initialized
INFO - 2020-09-10 13:28:10 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:28:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:28:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:28:10 --> Encryption Class Initialized
INFO - 2020-09-10 13:28:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:28:10 --> Controller Class Initialized
INFO - 2020-09-10 13:28:10 --> Helper loaded: language_helper
INFO - 2020-09-10 13:28:10 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:28:10 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-10 13:28:10 --> Final output sent to browser
DEBUG - 2020-09-10 13:28:10 --> Total execution time: 3.0805
INFO - 2020-09-10 13:28:15 --> Config Class Initialized
INFO - 2020-09-10 13:28:15 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:28:15 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:28:15 --> Utf8 Class Initialized
INFO - 2020-09-10 13:28:15 --> URI Class Initialized
INFO - 2020-09-10 13:28:15 --> Router Class Initialized
INFO - 2020-09-10 13:28:15 --> Output Class Initialized
INFO - 2020-09-10 13:28:15 --> Security Class Initialized
DEBUG - 2020-09-10 13:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:28:15 --> Input Class Initialized
INFO - 2020-09-10 13:28:15 --> Language Class Initialized
INFO - 2020-09-10 13:28:15 --> Loader Class Initialized
INFO - 2020-09-10 13:28:15 --> Helper loaded: html_helper
INFO - 2020-09-10 13:28:15 --> Helper loaded: url_helper
INFO - 2020-09-10 13:28:15 --> Helper loaded: form_helper
INFO - 2020-09-10 13:28:15 --> Database Driver Class Initialized
INFO - 2020-09-10 13:28:15 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:28:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:28:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:28:15 --> Encryption Class Initialized
INFO - 2020-09-10 13:28:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:28:15 --> Controller Class Initialized
INFO - 2020-09-10 13:28:15 --> Helper loaded: language_helper
INFO - 2020-09-10 13:28:15 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-10 13:28:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-10 13:28:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-10 13:28:15 --> Model "User" initialized
INFO - 2020-09-10 13:28:16 --> Config Class Initialized
INFO - 2020-09-10 13:28:16 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:28:16 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:28:16 --> Utf8 Class Initialized
INFO - 2020-09-10 13:28:16 --> URI Class Initialized
INFO - 2020-09-10 13:28:16 --> Router Class Initialized
INFO - 2020-09-10 13:28:16 --> Output Class Initialized
INFO - 2020-09-10 13:28:16 --> Security Class Initialized
DEBUG - 2020-09-10 13:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:28:16 --> Input Class Initialized
INFO - 2020-09-10 13:28:16 --> Language Class Initialized
INFO - 2020-09-10 13:28:16 --> Loader Class Initialized
INFO - 2020-09-10 13:28:16 --> Helper loaded: html_helper
INFO - 2020-09-10 13:28:16 --> Helper loaded: url_helper
INFO - 2020-09-10 13:28:16 --> Helper loaded: form_helper
INFO - 2020-09-10 13:28:16 --> Database Driver Class Initialized
INFO - 2020-09-10 13:28:16 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:28:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:28:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:28:16 --> Encryption Class Initialized
INFO - 2020-09-10 13:28:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:28:16 --> Controller Class Initialized
INFO - 2020-09-10 13:28:16 --> Helper loaded: language_helper
INFO - 2020-09-10 13:28:16 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:28:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-10 13:28:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-10 13:28:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-10 13:28:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-10 13:28:16 --> Final output sent to browser
DEBUG - 2020-09-10 13:28:17 --> Total execution time: 0.6514
INFO - 2020-09-10 13:28:20 --> Config Class Initialized
INFO - 2020-09-10 13:28:20 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:28:20 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:28:20 --> Utf8 Class Initialized
INFO - 2020-09-10 13:28:21 --> URI Class Initialized
INFO - 2020-09-10 13:28:21 --> Router Class Initialized
INFO - 2020-09-10 13:28:21 --> Output Class Initialized
INFO - 2020-09-10 13:28:21 --> Security Class Initialized
DEBUG - 2020-09-10 13:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:28:21 --> Input Class Initialized
INFO - 2020-09-10 13:28:21 --> Language Class Initialized
INFO - 2020-09-10 13:28:21 --> Loader Class Initialized
INFO - 2020-09-10 13:28:21 --> Helper loaded: html_helper
INFO - 2020-09-10 13:28:21 --> Helper loaded: url_helper
INFO - 2020-09-10 13:28:21 --> Helper loaded: form_helper
INFO - 2020-09-10 13:28:21 --> Database Driver Class Initialized
INFO - 2020-09-10 13:28:21 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:28:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:28:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:28:21 --> Encryption Class Initialized
INFO - 2020-09-10 13:28:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:28:21 --> Controller Class Initialized
INFO - 2020-09-10 13:28:21 --> Helper loaded: language_helper
INFO - 2020-09-10 13:28:21 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:28:21 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-10 13:28:21 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-10 13:28:21 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-10 13:28:21 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-10 13:28:21 --> Final output sent to browser
DEBUG - 2020-09-10 13:28:21 --> Total execution time: 0.7042
INFO - 2020-09-10 13:28:23 --> Config Class Initialized
INFO - 2020-09-10 13:28:23 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:28:23 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:28:23 --> Utf8 Class Initialized
INFO - 2020-09-10 13:28:23 --> URI Class Initialized
INFO - 2020-09-10 13:28:23 --> Router Class Initialized
INFO - 2020-09-10 13:28:23 --> Output Class Initialized
INFO - 2020-09-10 13:28:23 --> Security Class Initialized
DEBUG - 2020-09-10 13:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:28:23 --> Input Class Initialized
INFO - 2020-09-10 13:28:23 --> Language Class Initialized
INFO - 2020-09-10 13:28:23 --> Loader Class Initialized
INFO - 2020-09-10 13:28:23 --> Helper loaded: html_helper
INFO - 2020-09-10 13:28:23 --> Helper loaded: url_helper
INFO - 2020-09-10 13:28:23 --> Helper loaded: form_helper
INFO - 2020-09-10 13:28:23 --> Database Driver Class Initialized
INFO - 2020-09-10 13:28:23 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:28:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:28:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:28:23 --> Encryption Class Initialized
INFO - 2020-09-10 13:28:23 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:28:23 --> Controller Class Initialized
INFO - 2020-09-10 13:28:23 --> Helper loaded: language_helper
INFO - 2020-09-10 13:28:23 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:28:23 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-10 13:28:23 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-10 13:28:23 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-10 13:28:23 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-10 13:28:23 --> Final output sent to browser
DEBUG - 2020-09-10 13:28:23 --> Total execution time: 0.6983
INFO - 2020-09-10 13:28:30 --> Config Class Initialized
INFO - 2020-09-10 13:28:30 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:28:30 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:28:30 --> Utf8 Class Initialized
INFO - 2020-09-10 13:28:30 --> URI Class Initialized
INFO - 2020-09-10 13:28:30 --> Router Class Initialized
INFO - 2020-09-10 13:28:30 --> Output Class Initialized
INFO - 2020-09-10 13:28:30 --> Security Class Initialized
DEBUG - 2020-09-10 13:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:28:30 --> Input Class Initialized
INFO - 2020-09-10 13:28:30 --> Language Class Initialized
INFO - 2020-09-10 13:28:30 --> Loader Class Initialized
INFO - 2020-09-10 13:28:30 --> Helper loaded: html_helper
INFO - 2020-09-10 13:28:30 --> Helper loaded: url_helper
INFO - 2020-09-10 13:28:30 --> Helper loaded: form_helper
INFO - 2020-09-10 13:28:30 --> Database Driver Class Initialized
INFO - 2020-09-10 13:28:30 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:28:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:28:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:28:30 --> Encryption Class Initialized
INFO - 2020-09-10 13:28:30 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:28:30 --> Controller Class Initialized
INFO - 2020-09-10 13:28:30 --> Helper loaded: language_helper
INFO - 2020-09-10 13:28:30 --> Language file loaded: language/english/content_lang.php
ERROR - 2020-09-10 13:28:30 --> Severity: error --> Exception: Unable to locate the model you have specified: Sale_model C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\system\core\Loader.php 348
INFO - 2020-09-10 13:28:42 --> Config Class Initialized
INFO - 2020-09-10 13:28:42 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:28:42 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:28:42 --> Utf8 Class Initialized
INFO - 2020-09-10 13:28:42 --> URI Class Initialized
INFO - 2020-09-10 13:28:42 --> Router Class Initialized
INFO - 2020-09-10 13:28:42 --> Output Class Initialized
INFO - 2020-09-10 13:28:42 --> Security Class Initialized
DEBUG - 2020-09-10 13:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:28:42 --> Input Class Initialized
INFO - 2020-09-10 13:28:42 --> Language Class Initialized
INFO - 2020-09-10 13:28:42 --> Loader Class Initialized
INFO - 2020-09-10 13:28:42 --> Helper loaded: html_helper
INFO - 2020-09-10 13:28:42 --> Helper loaded: url_helper
INFO - 2020-09-10 13:28:42 --> Helper loaded: form_helper
INFO - 2020-09-10 13:28:42 --> Database Driver Class Initialized
INFO - 2020-09-10 13:28:42 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:28:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:28:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:28:42 --> Encryption Class Initialized
INFO - 2020-09-10 13:28:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:28:42 --> Controller Class Initialized
INFO - 2020-09-10 13:28:42 --> Helper loaded: language_helper
INFO - 2020-09-10 13:28:42 --> Language file loaded: language/english/content_lang.php
ERROR - 2020-09-10 13:28:42 --> Severity: error --> Exception: Unable to locate the model you have specified: Sale_model C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\system\core\Loader.php 348
INFO - 2020-09-10 13:29:30 --> Config Class Initialized
INFO - 2020-09-10 13:29:30 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:29:30 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:29:30 --> Utf8 Class Initialized
INFO - 2020-09-10 13:29:30 --> URI Class Initialized
INFO - 2020-09-10 13:29:30 --> Router Class Initialized
INFO - 2020-09-10 13:29:30 --> Output Class Initialized
INFO - 2020-09-10 13:29:30 --> Security Class Initialized
DEBUG - 2020-09-10 13:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:29:30 --> Input Class Initialized
INFO - 2020-09-10 13:29:30 --> Language Class Initialized
INFO - 2020-09-10 13:29:30 --> Loader Class Initialized
INFO - 2020-09-10 13:29:30 --> Helper loaded: html_helper
INFO - 2020-09-10 13:29:30 --> Helper loaded: url_helper
INFO - 2020-09-10 13:29:30 --> Helper loaded: form_helper
INFO - 2020-09-10 13:29:30 --> Database Driver Class Initialized
INFO - 2020-09-10 13:29:30 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:29:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:29:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:29:31 --> Encryption Class Initialized
INFO - 2020-09-10 13:29:31 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:29:31 --> Controller Class Initialized
INFO - 2020-09-10 13:29:31 --> Helper loaded: language_helper
INFO - 2020-09-10 13:29:31 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:29:31 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-10 13:29:31 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-10 13:29:31 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-10 13:29:31 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-10 13:29:31 --> Final output sent to browser
DEBUG - 2020-09-10 13:29:31 --> Total execution time: 0.6445
INFO - 2020-09-10 13:29:36 --> Config Class Initialized
INFO - 2020-09-10 13:29:36 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:29:36 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:29:36 --> Utf8 Class Initialized
INFO - 2020-09-10 13:29:36 --> URI Class Initialized
INFO - 2020-09-10 13:29:36 --> Router Class Initialized
INFO - 2020-09-10 13:29:36 --> Output Class Initialized
INFO - 2020-09-10 13:29:36 --> Security Class Initialized
DEBUG - 2020-09-10 13:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:29:36 --> Input Class Initialized
INFO - 2020-09-10 13:29:36 --> Language Class Initialized
INFO - 2020-09-10 13:29:36 --> Loader Class Initialized
INFO - 2020-09-10 13:29:36 --> Helper loaded: html_helper
INFO - 2020-09-10 13:29:36 --> Helper loaded: url_helper
INFO - 2020-09-10 13:29:36 --> Helper loaded: form_helper
INFO - 2020-09-10 13:29:36 --> Database Driver Class Initialized
INFO - 2020-09-10 13:29:36 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:29:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:29:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:29:36 --> Encryption Class Initialized
INFO - 2020-09-10 13:29:36 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:29:36 --> Controller Class Initialized
INFO - 2020-09-10 13:29:36 --> Helper loaded: language_helper
INFO - 2020-09-10 13:29:36 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:29:36 --> Model "Sale_model" initialized
INFO - 2020-09-10 13:29:36 --> Final output sent to browser
DEBUG - 2020-09-10 13:29:36 --> Total execution time: 0.5512
INFO - 2020-09-10 13:29:52 --> Config Class Initialized
INFO - 2020-09-10 13:29:52 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:29:52 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:29:52 --> Utf8 Class Initialized
INFO - 2020-09-10 13:29:52 --> URI Class Initialized
INFO - 2020-09-10 13:29:52 --> Router Class Initialized
INFO - 2020-09-10 13:29:52 --> Output Class Initialized
INFO - 2020-09-10 13:29:52 --> Security Class Initialized
DEBUG - 2020-09-10 13:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:29:52 --> Input Class Initialized
INFO - 2020-09-10 13:29:52 --> Language Class Initialized
INFO - 2020-09-10 13:29:52 --> Loader Class Initialized
INFO - 2020-09-10 13:29:52 --> Helper loaded: html_helper
INFO - 2020-09-10 13:29:52 --> Helper loaded: url_helper
INFO - 2020-09-10 13:29:52 --> Helper loaded: form_helper
INFO - 2020-09-10 13:29:52 --> Database Driver Class Initialized
INFO - 2020-09-10 13:29:52 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:29:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:29:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:29:53 --> Encryption Class Initialized
INFO - 2020-09-10 13:29:53 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:29:53 --> Controller Class Initialized
INFO - 2020-09-10 13:29:53 --> Helper loaded: language_helper
INFO - 2020-09-10 13:29:53 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:29:53 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-10 13:29:53 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-10 13:29:53 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment.php
INFO - 2020-09-10 13:29:53 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-10 13:29:53 --> Final output sent to browser
DEBUG - 2020-09-10 13:29:53 --> Total execution time: 0.8039
INFO - 2020-09-10 13:29:53 --> Config Class Initialized
INFO - 2020-09-10 13:29:53 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:29:53 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:29:53 --> Utf8 Class Initialized
INFO - 2020-09-10 13:29:53 --> URI Class Initialized
INFO - 2020-09-10 13:29:53 --> Router Class Initialized
INFO - 2020-09-10 13:29:53 --> Output Class Initialized
INFO - 2020-09-10 13:29:53 --> Security Class Initialized
DEBUG - 2020-09-10 13:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:29:54 --> Input Class Initialized
INFO - 2020-09-10 13:29:54 --> Language Class Initialized
INFO - 2020-09-10 13:29:54 --> Loader Class Initialized
INFO - 2020-09-10 13:29:54 --> Helper loaded: html_helper
INFO - 2020-09-10 13:29:54 --> Helper loaded: url_helper
INFO - 2020-09-10 13:29:54 --> Helper loaded: form_helper
INFO - 2020-09-10 13:29:54 --> Database Driver Class Initialized
INFO - 2020-09-10 13:29:54 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:29:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:29:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:29:54 --> Encryption Class Initialized
INFO - 2020-09-10 13:29:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:29:54 --> Controller Class Initialized
INFO - 2020-09-10 13:29:54 --> Helper loaded: language_helper
INFO - 2020-09-10 13:29:54 --> Language file loaded: language/english/content_lang.php
ERROR - 2020-09-10 13:29:57 --> Severity: Notice --> Undefined index: id C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\third_party\razorpay-php\src\Resource.php 30
ERROR - 2020-09-10 13:29:57 --> Severity: Notice --> Undefined index: amount C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\third_party\razorpay-php\src\Resource.php 30
ERROR - 2020-09-10 13:29:57 --> Severity: Notice --> Undefined index: amount_paid C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\third_party\razorpay-php\src\Resource.php 30
ERROR - 2020-09-10 13:29:57 --> Severity: Notice --> Undefined index: amount_due C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\third_party\razorpay-php\src\Resource.php 30
ERROR - 2020-09-10 13:29:57 --> Severity: Notice --> Undefined index: currency C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\third_party\razorpay-php\src\Resource.php 30
ERROR - 2020-09-10 13:29:57 --> Severity: Notice --> Undefined index: receipt C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\third_party\razorpay-php\src\Resource.php 30
ERROR - 2020-09-10 13:29:57 --> Severity: Notice --> Undefined index: status C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\third_party\razorpay-php\src\Resource.php 30
ERROR - 2020-09-10 13:29:57 --> Severity: Notice --> Undefined index: attempts C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\third_party\razorpay-php\src\Resource.php 30
ERROR - 2020-09-10 13:29:57 --> Severity: Notice --> Undefined index: created_at C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\third_party\razorpay-php\src\Resource.php 30
INFO - 2020-09-10 13:29:57 --> Final output sent to browser
DEBUG - 2020-09-10 13:29:57 --> Total execution time: 4.1226
INFO - 2020-09-10 13:30:46 --> Config Class Initialized
INFO - 2020-09-10 13:30:47 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:30:47 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:30:47 --> Utf8 Class Initialized
INFO - 2020-09-10 13:30:47 --> URI Class Initialized
INFO - 2020-09-10 13:30:47 --> Router Class Initialized
INFO - 2020-09-10 13:30:47 --> Output Class Initialized
INFO - 2020-09-10 13:30:47 --> Security Class Initialized
DEBUG - 2020-09-10 13:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:30:47 --> Input Class Initialized
INFO - 2020-09-10 13:30:47 --> Language Class Initialized
INFO - 2020-09-10 13:30:47 --> Loader Class Initialized
INFO - 2020-09-10 13:30:47 --> Helper loaded: html_helper
INFO - 2020-09-10 13:30:47 --> Helper loaded: url_helper
INFO - 2020-09-10 13:30:47 --> Helper loaded: form_helper
INFO - 2020-09-10 13:30:47 --> Database Driver Class Initialized
INFO - 2020-09-10 13:30:47 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:30:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:30:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:30:47 --> Encryption Class Initialized
INFO - 2020-09-10 13:30:47 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:30:47 --> Controller Class Initialized
INFO - 2020-09-10 13:30:47 --> Helper loaded: language_helper
INFO - 2020-09-10 13:30:47 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:30:47 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-10 13:30:47 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-10 13:30:47 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-10 13:30:47 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-10 13:30:47 --> Final output sent to browser
DEBUG - 2020-09-10 13:30:47 --> Total execution time: 0.6710
INFO - 2020-09-10 13:30:50 --> Config Class Initialized
INFO - 2020-09-10 13:30:50 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:30:50 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:30:50 --> Utf8 Class Initialized
INFO - 2020-09-10 13:30:50 --> URI Class Initialized
INFO - 2020-09-10 13:30:50 --> Router Class Initialized
INFO - 2020-09-10 13:30:50 --> Output Class Initialized
INFO - 2020-09-10 13:30:50 --> Security Class Initialized
DEBUG - 2020-09-10 13:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:30:50 --> Input Class Initialized
INFO - 2020-09-10 13:30:50 --> Language Class Initialized
INFO - 2020-09-10 13:30:50 --> Loader Class Initialized
INFO - 2020-09-10 13:30:50 --> Helper loaded: html_helper
INFO - 2020-09-10 13:30:50 --> Helper loaded: url_helper
INFO - 2020-09-10 13:30:50 --> Helper loaded: form_helper
INFO - 2020-09-10 13:30:50 --> Database Driver Class Initialized
INFO - 2020-09-10 13:30:50 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:30:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:30:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:30:50 --> Encryption Class Initialized
INFO - 2020-09-10 13:30:50 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:30:50 --> Controller Class Initialized
INFO - 2020-09-10 13:30:50 --> Helper loaded: language_helper
INFO - 2020-09-10 13:30:50 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:30:50 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-10 13:30:50 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-10 13:30:51 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-10 13:30:51 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-10 13:30:51 --> Final output sent to browser
DEBUG - 2020-09-10 13:30:51 --> Total execution time: 0.8813
INFO - 2020-09-10 13:30:56 --> Config Class Initialized
INFO - 2020-09-10 13:30:56 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:30:56 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:30:56 --> Utf8 Class Initialized
INFO - 2020-09-10 13:30:56 --> URI Class Initialized
INFO - 2020-09-10 13:30:56 --> Router Class Initialized
INFO - 2020-09-10 13:30:56 --> Output Class Initialized
INFO - 2020-09-10 13:30:56 --> Security Class Initialized
DEBUG - 2020-09-10 13:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:30:56 --> Input Class Initialized
INFO - 2020-09-10 13:30:56 --> Language Class Initialized
INFO - 2020-09-10 13:30:56 --> Loader Class Initialized
INFO - 2020-09-10 13:30:56 --> Helper loaded: html_helper
INFO - 2020-09-10 13:30:56 --> Helper loaded: url_helper
INFO - 2020-09-10 13:30:56 --> Helper loaded: form_helper
INFO - 2020-09-10 13:30:56 --> Database Driver Class Initialized
INFO - 2020-09-10 13:30:56 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:30:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:30:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:30:57 --> Encryption Class Initialized
INFO - 2020-09-10 13:30:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:30:57 --> Controller Class Initialized
INFO - 2020-09-10 13:30:57 --> Helper loaded: language_helper
INFO - 2020-09-10 13:30:57 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:30:57 --> Model "Sale_model" initialized
INFO - 2020-09-10 13:30:57 --> Final output sent to browser
DEBUG - 2020-09-10 13:30:57 --> Total execution time: 0.7182
INFO - 2020-09-10 13:30:59 --> Config Class Initialized
INFO - 2020-09-10 13:30:59 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:30:59 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:30:59 --> Utf8 Class Initialized
INFO - 2020-09-10 13:30:59 --> URI Class Initialized
INFO - 2020-09-10 13:30:59 --> Router Class Initialized
INFO - 2020-09-10 13:30:59 --> Output Class Initialized
INFO - 2020-09-10 13:30:59 --> Security Class Initialized
DEBUG - 2020-09-10 13:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:30:59 --> Input Class Initialized
INFO - 2020-09-10 13:30:59 --> Language Class Initialized
INFO - 2020-09-10 13:30:59 --> Loader Class Initialized
INFO - 2020-09-10 13:30:59 --> Helper loaded: html_helper
INFO - 2020-09-10 13:30:59 --> Helper loaded: url_helper
INFO - 2020-09-10 13:30:59 --> Helper loaded: form_helper
INFO - 2020-09-10 13:30:59 --> Database Driver Class Initialized
INFO - 2020-09-10 13:30:59 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:30:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:30:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:30:59 --> Encryption Class Initialized
INFO - 2020-09-10 13:31:00 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:31:00 --> Controller Class Initialized
INFO - 2020-09-10 13:31:00 --> Helper loaded: language_helper
INFO - 2020-09-10 13:31:00 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:31:00 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-10 13:31:00 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-10 13:31:00 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment.php
INFO - 2020-09-10 13:31:00 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-10 13:31:00 --> Final output sent to browser
DEBUG - 2020-09-10 13:31:00 --> Total execution time: 0.9386
INFO - 2020-09-10 13:33:05 --> Config Class Initialized
INFO - 2020-09-10 13:33:05 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:33:05 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:33:05 --> Utf8 Class Initialized
INFO - 2020-09-10 13:33:05 --> URI Class Initialized
INFO - 2020-09-10 13:33:05 --> Router Class Initialized
INFO - 2020-09-10 13:33:05 --> Output Class Initialized
INFO - 2020-09-10 13:33:05 --> Security Class Initialized
DEBUG - 2020-09-10 13:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:33:05 --> Input Class Initialized
INFO - 2020-09-10 13:33:05 --> Language Class Initialized
INFO - 2020-09-10 13:33:06 --> Loader Class Initialized
INFO - 2020-09-10 13:33:06 --> Helper loaded: html_helper
INFO - 2020-09-10 13:33:06 --> Helper loaded: url_helper
INFO - 2020-09-10 13:33:06 --> Helper loaded: form_helper
INFO - 2020-09-10 13:33:06 --> Database Driver Class Initialized
INFO - 2020-09-10 13:33:06 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:33:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:33:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:33:06 --> Encryption Class Initialized
INFO - 2020-09-10 13:33:06 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:33:06 --> Controller Class Initialized
INFO - 2020-09-10 13:33:06 --> Helper loaded: language_helper
INFO - 2020-09-10 13:33:06 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:33:06 --> Final output sent to browser
DEBUG - 2020-09-10 13:33:06 --> Total execution time: 0.6282
INFO - 2020-09-10 13:33:15 --> Config Class Initialized
INFO - 2020-09-10 13:33:15 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:33:15 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:33:15 --> Utf8 Class Initialized
INFO - 2020-09-10 13:33:15 --> URI Class Initialized
INFO - 2020-09-10 13:33:15 --> Router Class Initialized
INFO - 2020-09-10 13:33:15 --> Output Class Initialized
INFO - 2020-09-10 13:33:15 --> Security Class Initialized
DEBUG - 2020-09-10 13:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:33:15 --> Input Class Initialized
INFO - 2020-09-10 13:33:15 --> Language Class Initialized
INFO - 2020-09-10 13:33:15 --> Loader Class Initialized
INFO - 2020-09-10 13:33:15 --> Helper loaded: html_helper
INFO - 2020-09-10 13:33:15 --> Helper loaded: url_helper
INFO - 2020-09-10 13:33:15 --> Helper loaded: form_helper
INFO - 2020-09-10 13:33:15 --> Database Driver Class Initialized
INFO - 2020-09-10 13:33:15 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:33:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:33:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:33:15 --> Encryption Class Initialized
INFO - 2020-09-10 13:33:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:33:16 --> Controller Class Initialized
INFO - 2020-09-10 13:33:16 --> Helper loaded: language_helper
INFO - 2020-09-10 13:33:16 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:33:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-10 13:33:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-10 13:33:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-10 13:33:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-10 13:33:16 --> Final output sent to browser
DEBUG - 2020-09-10 13:33:16 --> Total execution time: 0.7908
INFO - 2020-09-10 13:33:21 --> Config Class Initialized
INFO - 2020-09-10 13:33:21 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:33:21 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:33:21 --> Utf8 Class Initialized
INFO - 2020-09-10 13:33:21 --> URI Class Initialized
INFO - 2020-09-10 13:33:21 --> Router Class Initialized
INFO - 2020-09-10 13:33:21 --> Output Class Initialized
INFO - 2020-09-10 13:33:21 --> Security Class Initialized
DEBUG - 2020-09-10 13:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:33:21 --> Input Class Initialized
INFO - 2020-09-10 13:33:21 --> Language Class Initialized
INFO - 2020-09-10 13:33:21 --> Loader Class Initialized
INFO - 2020-09-10 13:33:22 --> Helper loaded: html_helper
INFO - 2020-09-10 13:33:22 --> Helper loaded: url_helper
INFO - 2020-09-10 13:33:22 --> Helper loaded: form_helper
INFO - 2020-09-10 13:33:22 --> Database Driver Class Initialized
INFO - 2020-09-10 13:33:22 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:33:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:33:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:33:22 --> Encryption Class Initialized
INFO - 2020-09-10 13:33:22 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:33:22 --> Controller Class Initialized
INFO - 2020-09-10 13:33:22 --> Helper loaded: language_helper
INFO - 2020-09-10 13:33:22 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:33:22 --> Model "Sale_model" initialized
INFO - 2020-09-10 13:33:22 --> Final output sent to browser
DEBUG - 2020-09-10 13:33:22 --> Total execution time: 0.8106
INFO - 2020-09-10 13:33:25 --> Config Class Initialized
INFO - 2020-09-10 13:33:25 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:33:25 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:33:25 --> Utf8 Class Initialized
INFO - 2020-09-10 13:33:25 --> URI Class Initialized
INFO - 2020-09-10 13:33:25 --> Router Class Initialized
INFO - 2020-09-10 13:33:25 --> Output Class Initialized
INFO - 2020-09-10 13:33:25 --> Security Class Initialized
DEBUG - 2020-09-10 13:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:33:25 --> Input Class Initialized
INFO - 2020-09-10 13:33:25 --> Language Class Initialized
INFO - 2020-09-10 13:33:25 --> Loader Class Initialized
INFO - 2020-09-10 13:33:25 --> Helper loaded: html_helper
INFO - 2020-09-10 13:33:25 --> Helper loaded: url_helper
INFO - 2020-09-10 13:33:25 --> Helper loaded: form_helper
INFO - 2020-09-10 13:33:25 --> Database Driver Class Initialized
INFO - 2020-09-10 13:33:25 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:33:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:33:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:33:25 --> Encryption Class Initialized
INFO - 2020-09-10 13:33:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:33:25 --> Controller Class Initialized
INFO - 2020-09-10 13:33:25 --> Helper loaded: language_helper
INFO - 2020-09-10 13:33:25 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:33:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-10 13:33:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-10 13:33:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment.php
INFO - 2020-09-10 13:33:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-10 13:33:25 --> Final output sent to browser
DEBUG - 2020-09-10 13:33:25 --> Total execution time: 0.8303
INFO - 2020-09-10 13:33:27 --> Config Class Initialized
INFO - 2020-09-10 13:33:27 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:33:27 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:33:27 --> Utf8 Class Initialized
INFO - 2020-09-10 13:33:27 --> URI Class Initialized
INFO - 2020-09-10 13:33:27 --> Router Class Initialized
INFO - 2020-09-10 13:33:28 --> Output Class Initialized
INFO - 2020-09-10 13:33:28 --> Security Class Initialized
DEBUG - 2020-09-10 13:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:33:28 --> Input Class Initialized
INFO - 2020-09-10 13:33:28 --> Language Class Initialized
INFO - 2020-09-10 13:33:28 --> Loader Class Initialized
INFO - 2020-09-10 13:33:28 --> Helper loaded: html_helper
INFO - 2020-09-10 13:33:28 --> Helper loaded: url_helper
INFO - 2020-09-10 13:33:28 --> Helper loaded: form_helper
INFO - 2020-09-10 13:33:28 --> Database Driver Class Initialized
INFO - 2020-09-10 13:33:28 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:33:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:33:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:33:28 --> Encryption Class Initialized
INFO - 2020-09-10 13:33:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:33:28 --> Controller Class Initialized
INFO - 2020-09-10 13:33:28 --> Helper loaded: language_helper
INFO - 2020-09-10 13:33:28 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:33:28 --> Final output sent to browser
DEBUG - 2020-09-10 13:33:28 --> Total execution time: 0.6600
INFO - 2020-09-10 13:36:33 --> Config Class Initialized
INFO - 2020-09-10 13:36:33 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:36:33 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:36:34 --> Utf8 Class Initialized
INFO - 2020-09-10 13:36:34 --> URI Class Initialized
INFO - 2020-09-10 13:36:34 --> Router Class Initialized
INFO - 2020-09-10 13:36:34 --> Output Class Initialized
INFO - 2020-09-10 13:36:34 --> Security Class Initialized
DEBUG - 2020-09-10 13:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:36:34 --> Input Class Initialized
INFO - 2020-09-10 13:36:34 --> Language Class Initialized
INFO - 2020-09-10 13:36:34 --> Loader Class Initialized
INFO - 2020-09-10 13:36:34 --> Helper loaded: html_helper
INFO - 2020-09-10 13:36:34 --> Helper loaded: url_helper
INFO - 2020-09-10 13:36:34 --> Helper loaded: form_helper
INFO - 2020-09-10 13:36:34 --> Database Driver Class Initialized
INFO - 2020-09-10 13:36:34 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:36:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:36:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:36:34 --> Encryption Class Initialized
INFO - 2020-09-10 13:36:34 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:36:34 --> Controller Class Initialized
INFO - 2020-09-10 13:36:34 --> Helper loaded: language_helper
INFO - 2020-09-10 13:36:34 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:36:34 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-10 13:36:34 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-10 13:36:34 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-10 13:36:34 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-10 13:36:34 --> Final output sent to browser
DEBUG - 2020-09-10 13:36:34 --> Total execution time: 1.0619
INFO - 2020-09-10 13:36:39 --> Config Class Initialized
INFO - 2020-09-10 13:36:39 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:36:39 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:36:39 --> Utf8 Class Initialized
INFO - 2020-09-10 13:36:39 --> URI Class Initialized
INFO - 2020-09-10 13:36:39 --> Router Class Initialized
INFO - 2020-09-10 13:36:39 --> Output Class Initialized
INFO - 2020-09-10 13:36:39 --> Security Class Initialized
DEBUG - 2020-09-10 13:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:36:39 --> Input Class Initialized
INFO - 2020-09-10 13:36:39 --> Language Class Initialized
INFO - 2020-09-10 13:36:39 --> Loader Class Initialized
INFO - 2020-09-10 13:36:39 --> Helper loaded: html_helper
INFO - 2020-09-10 13:36:39 --> Helper loaded: url_helper
INFO - 2020-09-10 13:36:39 --> Helper loaded: form_helper
INFO - 2020-09-10 13:36:39 --> Database Driver Class Initialized
INFO - 2020-09-10 13:36:39 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:36:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:36:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:36:40 --> Encryption Class Initialized
INFO - 2020-09-10 13:36:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:36:40 --> Controller Class Initialized
INFO - 2020-09-10 13:36:40 --> Helper loaded: language_helper
INFO - 2020-09-10 13:36:40 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:36:40 --> Model "Sale_model" initialized
INFO - 2020-09-10 13:36:40 --> Final output sent to browser
DEBUG - 2020-09-10 13:36:40 --> Total execution time: 0.6435
INFO - 2020-09-10 13:36:47 --> Config Class Initialized
INFO - 2020-09-10 13:36:47 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:36:47 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:36:47 --> Utf8 Class Initialized
INFO - 2020-09-10 13:36:47 --> URI Class Initialized
INFO - 2020-09-10 13:36:47 --> Router Class Initialized
INFO - 2020-09-10 13:36:47 --> Output Class Initialized
INFO - 2020-09-10 13:36:47 --> Security Class Initialized
DEBUG - 2020-09-10 13:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:36:47 --> Input Class Initialized
INFO - 2020-09-10 13:36:47 --> Language Class Initialized
INFO - 2020-09-10 13:36:47 --> Loader Class Initialized
INFO - 2020-09-10 13:36:47 --> Helper loaded: html_helper
INFO - 2020-09-10 13:36:47 --> Helper loaded: url_helper
INFO - 2020-09-10 13:36:47 --> Helper loaded: form_helper
INFO - 2020-09-10 13:36:47 --> Database Driver Class Initialized
INFO - 2020-09-10 13:36:47 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:36:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:36:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:36:47 --> Encryption Class Initialized
INFO - 2020-09-10 13:36:47 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:36:47 --> Controller Class Initialized
INFO - 2020-09-10 13:36:47 --> Helper loaded: language_helper
INFO - 2020-09-10 13:36:47 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:36:47 --> Final output sent to browser
DEBUG - 2020-09-10 13:36:47 --> Total execution time: 0.7212
INFO - 2020-09-10 13:37:52 --> Config Class Initialized
INFO - 2020-09-10 13:37:52 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:37:52 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:37:52 --> Utf8 Class Initialized
INFO - 2020-09-10 13:37:52 --> URI Class Initialized
INFO - 2020-09-10 13:37:52 --> Router Class Initialized
INFO - 2020-09-10 13:37:53 --> Output Class Initialized
INFO - 2020-09-10 13:37:53 --> Security Class Initialized
DEBUG - 2020-09-10 13:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:37:53 --> Input Class Initialized
INFO - 2020-09-10 13:37:53 --> Language Class Initialized
INFO - 2020-09-10 13:37:53 --> Loader Class Initialized
INFO - 2020-09-10 13:37:53 --> Helper loaded: html_helper
INFO - 2020-09-10 13:37:53 --> Helper loaded: url_helper
INFO - 2020-09-10 13:37:53 --> Helper loaded: form_helper
INFO - 2020-09-10 13:37:53 --> Database Driver Class Initialized
INFO - 2020-09-10 13:37:53 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:37:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:37:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:37:53 --> Encryption Class Initialized
INFO - 2020-09-10 13:37:53 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:37:53 --> Controller Class Initialized
INFO - 2020-09-10 13:37:53 --> Helper loaded: language_helper
INFO - 2020-09-10 13:37:53 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:37:53 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-10 13:37:53 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-10 13:37:53 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-10 13:37:53 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-10 13:37:53 --> Final output sent to browser
DEBUG - 2020-09-10 13:37:53 --> Total execution time: 0.7484
INFO - 2020-09-10 13:37:56 --> Config Class Initialized
INFO - 2020-09-10 13:37:56 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:37:56 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:37:56 --> Utf8 Class Initialized
INFO - 2020-09-10 13:37:56 --> URI Class Initialized
INFO - 2020-09-10 13:37:57 --> Router Class Initialized
INFO - 2020-09-10 13:37:57 --> Output Class Initialized
INFO - 2020-09-10 13:37:57 --> Security Class Initialized
DEBUG - 2020-09-10 13:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:37:57 --> Input Class Initialized
INFO - 2020-09-10 13:37:57 --> Language Class Initialized
INFO - 2020-09-10 13:37:57 --> Loader Class Initialized
INFO - 2020-09-10 13:37:57 --> Helper loaded: html_helper
INFO - 2020-09-10 13:37:57 --> Helper loaded: url_helper
INFO - 2020-09-10 13:37:57 --> Helper loaded: form_helper
INFO - 2020-09-10 13:37:57 --> Database Driver Class Initialized
INFO - 2020-09-10 13:37:57 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:37:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:37:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:37:57 --> Encryption Class Initialized
INFO - 2020-09-10 13:37:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:37:57 --> Controller Class Initialized
INFO - 2020-09-10 13:37:57 --> Helper loaded: language_helper
INFO - 2020-09-10 13:37:57 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:37:57 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-10 13:37:57 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-10 13:37:57 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-10 13:37:57 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-10 13:37:57 --> Final output sent to browser
DEBUG - 2020-09-10 13:37:57 --> Total execution time: 0.7204
INFO - 2020-09-10 13:37:59 --> Config Class Initialized
INFO - 2020-09-10 13:37:59 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:37:59 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:37:59 --> Utf8 Class Initialized
INFO - 2020-09-10 13:37:59 --> URI Class Initialized
INFO - 2020-09-10 13:37:59 --> Router Class Initialized
INFO - 2020-09-10 13:37:59 --> Output Class Initialized
INFO - 2020-09-10 13:37:59 --> Security Class Initialized
DEBUG - 2020-09-10 13:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:37:59 --> Input Class Initialized
INFO - 2020-09-10 13:37:59 --> Language Class Initialized
INFO - 2020-09-10 13:37:59 --> Loader Class Initialized
INFO - 2020-09-10 13:37:59 --> Helper loaded: html_helper
INFO - 2020-09-10 13:37:59 --> Helper loaded: url_helper
INFO - 2020-09-10 13:37:59 --> Helper loaded: form_helper
INFO - 2020-09-10 13:37:59 --> Database Driver Class Initialized
INFO - 2020-09-10 13:37:59 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:37:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:37:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:37:59 --> Encryption Class Initialized
INFO - 2020-09-10 13:37:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:37:59 --> Controller Class Initialized
INFO - 2020-09-10 13:37:59 --> Helper loaded: language_helper
INFO - 2020-09-10 13:37:59 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:38:00 --> Final output sent to browser
DEBUG - 2020-09-10 13:38:00 --> Total execution time: 0.7276
INFO - 2020-09-10 13:38:00 --> Config Class Initialized
INFO - 2020-09-10 13:38:00 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:38:00 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:38:00 --> Utf8 Class Initialized
INFO - 2020-09-10 13:38:00 --> URI Class Initialized
DEBUG - 2020-09-10 13:38:00 --> No URI present. Default controller set.
INFO - 2020-09-10 13:38:00 --> Router Class Initialized
INFO - 2020-09-10 13:38:00 --> Output Class Initialized
INFO - 2020-09-10 13:38:00 --> Security Class Initialized
DEBUG - 2020-09-10 13:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:38:00 --> Input Class Initialized
INFO - 2020-09-10 13:38:00 --> Language Class Initialized
INFO - 2020-09-10 13:38:00 --> Loader Class Initialized
INFO - 2020-09-10 13:38:00 --> Helper loaded: html_helper
INFO - 2020-09-10 13:38:00 --> Helper loaded: url_helper
INFO - 2020-09-10 13:38:00 --> Helper loaded: form_helper
INFO - 2020-09-10 13:38:00 --> Database Driver Class Initialized
INFO - 2020-09-10 13:38:00 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:38:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:38:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:38:00 --> Encryption Class Initialized
INFO - 2020-09-10 13:38:00 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:38:00 --> Controller Class Initialized
INFO - 2020-09-10 13:38:00 --> Helper loaded: language_helper
INFO - 2020-09-10 13:38:00 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:38:00 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-10 13:38:01 --> Final output sent to browser
DEBUG - 2020-09-10 13:38:01 --> Total execution time: 0.6375
INFO - 2020-09-10 13:46:00 --> Config Class Initialized
INFO - 2020-09-10 13:46:00 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:46:00 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:46:00 --> Utf8 Class Initialized
INFO - 2020-09-10 13:46:00 --> URI Class Initialized
DEBUG - 2020-09-10 13:46:00 --> No URI present. Default controller set.
INFO - 2020-09-10 13:46:00 --> Router Class Initialized
INFO - 2020-09-10 13:46:00 --> Output Class Initialized
INFO - 2020-09-10 13:46:00 --> Security Class Initialized
DEBUG - 2020-09-10 13:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:46:00 --> Input Class Initialized
INFO - 2020-09-10 13:46:00 --> Language Class Initialized
INFO - 2020-09-10 13:46:00 --> Loader Class Initialized
INFO - 2020-09-10 13:46:00 --> Helper loaded: html_helper
INFO - 2020-09-10 13:46:00 --> Helper loaded: url_helper
INFO - 2020-09-10 13:46:00 --> Helper loaded: form_helper
INFO - 2020-09-10 13:46:00 --> Database Driver Class Initialized
INFO - 2020-09-10 13:46:00 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:46:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:46:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:46:00 --> Encryption Class Initialized
INFO - 2020-09-10 13:46:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:46:01 --> Controller Class Initialized
INFO - 2020-09-10 13:46:01 --> Helper loaded: language_helper
INFO - 2020-09-10 13:46:01 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:46:01 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-10 13:46:01 --> Final output sent to browser
DEBUG - 2020-09-10 13:46:01 --> Total execution time: 1.1631
INFO - 2020-09-10 13:46:22 --> Config Class Initialized
INFO - 2020-09-10 13:46:22 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:46:22 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:46:22 --> Utf8 Class Initialized
INFO - 2020-09-10 13:46:22 --> URI Class Initialized
INFO - 2020-09-10 13:46:22 --> Router Class Initialized
INFO - 2020-09-10 13:46:22 --> Output Class Initialized
INFO - 2020-09-10 13:46:22 --> Security Class Initialized
DEBUG - 2020-09-10 13:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:46:22 --> Input Class Initialized
INFO - 2020-09-10 13:46:22 --> Language Class Initialized
INFO - 2020-09-10 13:46:22 --> Loader Class Initialized
INFO - 2020-09-10 13:46:22 --> Helper loaded: html_helper
INFO - 2020-09-10 13:46:22 --> Helper loaded: url_helper
INFO - 2020-09-10 13:46:22 --> Helper loaded: form_helper
INFO - 2020-09-10 13:46:22 --> Database Driver Class Initialized
INFO - 2020-09-10 13:46:22 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:46:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:46:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:46:22 --> Encryption Class Initialized
INFO - 2020-09-10 13:46:23 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:46:23 --> Controller Class Initialized
INFO - 2020-09-10 13:46:23 --> Helper loaded: language_helper
INFO - 2020-09-10 13:46:23 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-10 13:46:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-10 13:46:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-10 13:46:23 --> Model "User" initialized
INFO - 2020-09-10 13:46:24 --> Config Class Initialized
INFO - 2020-09-10 13:46:24 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:46:24 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:46:24 --> Utf8 Class Initialized
INFO - 2020-09-10 13:46:24 --> URI Class Initialized
INFO - 2020-09-10 13:46:24 --> Router Class Initialized
INFO - 2020-09-10 13:46:24 --> Output Class Initialized
INFO - 2020-09-10 13:46:24 --> Security Class Initialized
DEBUG - 2020-09-10 13:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:46:24 --> Input Class Initialized
INFO - 2020-09-10 13:46:24 --> Language Class Initialized
INFO - 2020-09-10 13:46:24 --> Loader Class Initialized
INFO - 2020-09-10 13:46:24 --> Helper loaded: html_helper
INFO - 2020-09-10 13:46:24 --> Helper loaded: url_helper
INFO - 2020-09-10 13:46:24 --> Helper loaded: form_helper
INFO - 2020-09-10 13:46:24 --> Database Driver Class Initialized
INFO - 2020-09-10 13:46:24 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:46:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:46:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:46:24 --> Encryption Class Initialized
INFO - 2020-09-10 13:46:24 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:46:24 --> Controller Class Initialized
INFO - 2020-09-10 13:46:24 --> Helper loaded: language_helper
INFO - 2020-09-10 13:46:24 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:46:24 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-10 13:46:24 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-10 13:46:24 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-10 13:46:24 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-10 13:46:24 --> Final output sent to browser
DEBUG - 2020-09-10 13:46:24 --> Total execution time: 0.7147
INFO - 2020-09-10 13:46:36 --> Config Class Initialized
INFO - 2020-09-10 13:46:36 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:46:36 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:46:36 --> Utf8 Class Initialized
INFO - 2020-09-10 13:46:36 --> URI Class Initialized
INFO - 2020-09-10 13:46:36 --> Router Class Initialized
INFO - 2020-09-10 13:46:36 --> Output Class Initialized
INFO - 2020-09-10 13:46:36 --> Security Class Initialized
DEBUG - 2020-09-10 13:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:46:36 --> Input Class Initialized
INFO - 2020-09-10 13:46:36 --> Language Class Initialized
INFO - 2020-09-10 13:46:36 --> Loader Class Initialized
INFO - 2020-09-10 13:46:36 --> Helper loaded: html_helper
INFO - 2020-09-10 13:46:36 --> Helper loaded: url_helper
INFO - 2020-09-10 13:46:36 --> Helper loaded: form_helper
INFO - 2020-09-10 13:46:36 --> Database Driver Class Initialized
INFO - 2020-09-10 13:46:36 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:46:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:46:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:46:36 --> Encryption Class Initialized
INFO - 2020-09-10 13:46:36 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:46:36 --> Controller Class Initialized
INFO - 2020-09-10 13:46:36 --> Helper loaded: language_helper
INFO - 2020-09-10 13:46:36 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:46:36 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-10 13:46:36 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-10 13:46:36 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-10 13:46:36 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-10 13:46:36 --> Final output sent to browser
DEBUG - 2020-09-10 13:46:36 --> Total execution time: 0.7112
INFO - 2020-09-10 13:46:52 --> Config Class Initialized
INFO - 2020-09-10 13:46:52 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:46:52 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:46:52 --> Utf8 Class Initialized
INFO - 2020-09-10 13:46:52 --> URI Class Initialized
DEBUG - 2020-09-10 13:46:52 --> No URI present. Default controller set.
INFO - 2020-09-10 13:46:52 --> Router Class Initialized
INFO - 2020-09-10 13:46:52 --> Output Class Initialized
INFO - 2020-09-10 13:46:52 --> Security Class Initialized
DEBUG - 2020-09-10 13:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:46:52 --> Input Class Initialized
INFO - 2020-09-10 13:46:52 --> Language Class Initialized
INFO - 2020-09-10 13:46:52 --> Loader Class Initialized
INFO - 2020-09-10 13:46:52 --> Helper loaded: html_helper
INFO - 2020-09-10 13:46:52 --> Helper loaded: url_helper
INFO - 2020-09-10 13:46:52 --> Helper loaded: form_helper
INFO - 2020-09-10 13:46:52 --> Database Driver Class Initialized
INFO - 2020-09-10 13:46:53 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:46:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:46:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:46:53 --> Encryption Class Initialized
INFO - 2020-09-10 13:46:53 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:46:53 --> Controller Class Initialized
INFO - 2020-09-10 13:46:53 --> Helper loaded: language_helper
INFO - 2020-09-10 13:46:53 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:46:53 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-10 13:46:53 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-10 13:46:53 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-10 13:46:53 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-10 13:46:53 --> Final output sent to browser
DEBUG - 2020-09-10 13:46:53 --> Total execution time: 1.2649
INFO - 2020-09-10 13:46:54 --> Config Class Initialized
INFO - 2020-09-10 13:46:54 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:46:54 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:46:54 --> Utf8 Class Initialized
INFO - 2020-09-10 13:46:54 --> URI Class Initialized
INFO - 2020-09-10 13:46:54 --> Router Class Initialized
INFO - 2020-09-10 13:46:54 --> Output Class Initialized
INFO - 2020-09-10 13:46:54 --> Security Class Initialized
DEBUG - 2020-09-10 13:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:46:54 --> Input Class Initialized
INFO - 2020-09-10 13:46:54 --> Language Class Initialized
INFO - 2020-09-10 13:46:54 --> Loader Class Initialized
INFO - 2020-09-10 13:46:54 --> Helper loaded: html_helper
INFO - 2020-09-10 13:46:54 --> Helper loaded: url_helper
INFO - 2020-09-10 13:46:54 --> Helper loaded: form_helper
INFO - 2020-09-10 13:46:54 --> Database Driver Class Initialized
INFO - 2020-09-10 13:46:54 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:46:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:46:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:46:54 --> Encryption Class Initialized
INFO - 2020-09-10 13:46:54 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:46:54 --> Controller Class Initialized
INFO - 2020-09-10 13:46:54 --> Helper loaded: language_helper
INFO - 2020-09-10 13:46:54 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:46:54 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-10 13:46:54 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-10 13:46:54 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-10 13:46:55 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-10 13:46:55 --> Final output sent to browser
DEBUG - 2020-09-10 13:46:55 --> Total execution time: 0.6241
INFO - 2020-09-10 13:47:23 --> Config Class Initialized
INFO - 2020-09-10 13:47:23 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:47:23 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:47:23 --> Utf8 Class Initialized
INFO - 2020-09-10 13:47:23 --> URI Class Initialized
INFO - 2020-09-10 13:47:23 --> Router Class Initialized
INFO - 2020-09-10 13:47:23 --> Output Class Initialized
INFO - 2020-09-10 13:47:23 --> Security Class Initialized
DEBUG - 2020-09-10 13:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:47:23 --> Input Class Initialized
INFO - 2020-09-10 13:47:23 --> Language Class Initialized
INFO - 2020-09-10 13:47:23 --> Loader Class Initialized
INFO - 2020-09-10 13:47:23 --> Helper loaded: html_helper
INFO - 2020-09-10 13:47:23 --> Helper loaded: url_helper
INFO - 2020-09-10 13:47:23 --> Helper loaded: form_helper
INFO - 2020-09-10 13:47:23 --> Database Driver Class Initialized
INFO - 2020-09-10 13:47:23 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:47:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:47:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:47:23 --> Encryption Class Initialized
INFO - 2020-09-10 13:47:23 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:47:23 --> Controller Class Initialized
INFO - 2020-09-10 13:47:23 --> Helper loaded: language_helper
INFO - 2020-09-10 13:47:23 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:47:23 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-10 13:47:23 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-10 13:47:23 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-10 13:47:23 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-10 13:47:23 --> Final output sent to browser
DEBUG - 2020-09-10 13:47:23 --> Total execution time: 0.6192
INFO - 2020-09-10 13:47:33 --> Config Class Initialized
INFO - 2020-09-10 13:47:33 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:47:33 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:47:33 --> Utf8 Class Initialized
INFO - 2020-09-10 13:47:33 --> URI Class Initialized
INFO - 2020-09-10 13:47:33 --> Router Class Initialized
INFO - 2020-09-10 13:47:33 --> Output Class Initialized
INFO - 2020-09-10 13:47:33 --> Security Class Initialized
DEBUG - 2020-09-10 13:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:47:33 --> Input Class Initialized
INFO - 2020-09-10 13:47:33 --> Language Class Initialized
INFO - 2020-09-10 13:47:33 --> Loader Class Initialized
INFO - 2020-09-10 13:47:33 --> Helper loaded: html_helper
INFO - 2020-09-10 13:47:33 --> Helper loaded: url_helper
INFO - 2020-09-10 13:47:34 --> Helper loaded: form_helper
INFO - 2020-09-10 13:47:34 --> Database Driver Class Initialized
INFO - 2020-09-10 13:47:34 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:47:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:47:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:47:34 --> Encryption Class Initialized
INFO - 2020-09-10 13:47:34 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:47:34 --> Controller Class Initialized
INFO - 2020-09-10 13:47:34 --> Helper loaded: language_helper
INFO - 2020-09-10 13:47:34 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:47:34 --> Model "Sale_model" initialized
INFO - 2020-09-10 13:47:34 --> Final output sent to browser
DEBUG - 2020-09-10 13:47:34 --> Total execution time: 1.1530
INFO - 2020-09-10 13:47:42 --> Config Class Initialized
INFO - 2020-09-10 13:47:42 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:47:42 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:47:42 --> Utf8 Class Initialized
INFO - 2020-09-10 13:47:42 --> URI Class Initialized
INFO - 2020-09-10 13:47:42 --> Router Class Initialized
INFO - 2020-09-10 13:47:42 --> Output Class Initialized
INFO - 2020-09-10 13:47:42 --> Security Class Initialized
DEBUG - 2020-09-10 13:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:47:42 --> Input Class Initialized
INFO - 2020-09-10 13:47:42 --> Language Class Initialized
INFO - 2020-09-10 13:47:42 --> Loader Class Initialized
INFO - 2020-09-10 13:47:42 --> Helper loaded: html_helper
INFO - 2020-09-10 13:47:43 --> Helper loaded: url_helper
INFO - 2020-09-10 13:47:43 --> Helper loaded: form_helper
INFO - 2020-09-10 13:47:43 --> Database Driver Class Initialized
INFO - 2020-09-10 13:47:43 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:47:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:47:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:47:43 --> Encryption Class Initialized
INFO - 2020-09-10 13:47:43 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:47:43 --> Controller Class Initialized
INFO - 2020-09-10 13:47:43 --> Helper loaded: language_helper
INFO - 2020-09-10 13:47:43 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:47:43 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-10 13:47:43 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-10 13:47:43 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment_custom.php
INFO - 2020-09-10 13:47:43 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-10 13:47:43 --> Final output sent to browser
DEBUG - 2020-09-10 13:47:43 --> Total execution time: 0.9848
INFO - 2020-09-10 13:48:00 --> Config Class Initialized
INFO - 2020-09-10 13:48:00 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:48:00 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:48:00 --> Utf8 Class Initialized
INFO - 2020-09-10 13:48:00 --> URI Class Initialized
INFO - 2020-09-10 13:48:00 --> Router Class Initialized
INFO - 2020-09-10 13:48:00 --> Output Class Initialized
INFO - 2020-09-10 13:48:00 --> Security Class Initialized
DEBUG - 2020-09-10 13:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:48:00 --> Input Class Initialized
INFO - 2020-09-10 13:48:00 --> Language Class Initialized
INFO - 2020-09-10 13:48:00 --> Loader Class Initialized
INFO - 2020-09-10 13:48:00 --> Helper loaded: html_helper
INFO - 2020-09-10 13:48:00 --> Helper loaded: url_helper
INFO - 2020-09-10 13:48:00 --> Helper loaded: form_helper
INFO - 2020-09-10 13:48:00 --> Database Driver Class Initialized
INFO - 2020-09-10 13:48:00 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:48:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:48:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:48:00 --> Encryption Class Initialized
INFO - 2020-09-10 13:48:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:48:01 --> Controller Class Initialized
INFO - 2020-09-10 13:48:01 --> Helper loaded: language_helper
INFO - 2020-09-10 13:48:01 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:48:02 --> Final output sent to browser
DEBUG - 2020-09-10 13:48:02 --> Total execution time: 2.3576
INFO - 2020-09-10 13:48:02 --> Config Class Initialized
INFO - 2020-09-10 13:48:02 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:48:02 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:48:02 --> Utf8 Class Initialized
INFO - 2020-09-10 13:48:02 --> URI Class Initialized
INFO - 2020-09-10 13:48:02 --> Router Class Initialized
INFO - 2020-09-10 13:48:02 --> Output Class Initialized
INFO - 2020-09-10 13:48:02 --> Security Class Initialized
DEBUG - 2020-09-10 13:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:48:02 --> Input Class Initialized
INFO - 2020-09-10 13:48:02 --> Language Class Initialized
INFO - 2020-09-10 13:48:02 --> Loader Class Initialized
INFO - 2020-09-10 13:48:02 --> Helper loaded: html_helper
INFO - 2020-09-10 13:48:02 --> Helper loaded: url_helper
INFO - 2020-09-10 13:48:03 --> Helper loaded: form_helper
INFO - 2020-09-10 13:48:03 --> Database Driver Class Initialized
INFO - 2020-09-10 13:48:03 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:48:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:48:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:48:03 --> Encryption Class Initialized
INFO - 2020-09-10 13:48:03 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:48:03 --> Controller Class Initialized
INFO - 2020-09-10 13:48:03 --> Helper loaded: language_helper
INFO - 2020-09-10 13:48:03 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:48:04 --> Final output sent to browser
DEBUG - 2020-09-10 13:48:04 --> Total execution time: 1.7139
INFO - 2020-09-10 13:48:16 --> Config Class Initialized
INFO - 2020-09-10 13:48:16 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:48:16 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:48:16 --> Utf8 Class Initialized
INFO - 2020-09-10 13:48:16 --> URI Class Initialized
INFO - 2020-09-10 13:48:16 --> Router Class Initialized
INFO - 2020-09-10 13:48:16 --> Output Class Initialized
INFO - 2020-09-10 13:48:16 --> Security Class Initialized
DEBUG - 2020-09-10 13:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:48:16 --> Input Class Initialized
INFO - 2020-09-10 13:48:16 --> Language Class Initialized
INFO - 2020-09-10 13:48:16 --> Loader Class Initialized
INFO - 2020-09-10 13:48:16 --> Helper loaded: html_helper
INFO - 2020-09-10 13:48:16 --> Helper loaded: url_helper
INFO - 2020-09-10 13:48:16 --> Helper loaded: form_helper
INFO - 2020-09-10 13:48:16 --> Database Driver Class Initialized
INFO - 2020-09-10 13:48:17 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:48:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:48:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:48:17 --> Encryption Class Initialized
INFO - 2020-09-10 13:48:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:48:17 --> Controller Class Initialized
INFO - 2020-09-10 13:48:17 --> Helper loaded: language_helper
INFO - 2020-09-10 13:48:17 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:48:17 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-10 13:48:17 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-10 13:48:17 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment_custom.php
INFO - 2020-09-10 13:48:17 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-10 13:48:17 --> Final output sent to browser
DEBUG - 2020-09-10 13:48:17 --> Total execution time: 0.6723
INFO - 2020-09-10 13:49:00 --> Config Class Initialized
INFO - 2020-09-10 13:49:00 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:49:00 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:49:00 --> Utf8 Class Initialized
INFO - 2020-09-10 13:49:00 --> URI Class Initialized
INFO - 2020-09-10 13:49:00 --> Router Class Initialized
INFO - 2020-09-10 13:49:00 --> Output Class Initialized
INFO - 2020-09-10 13:49:00 --> Security Class Initialized
DEBUG - 2020-09-10 13:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:49:00 --> Input Class Initialized
INFO - 2020-09-10 13:49:00 --> Language Class Initialized
INFO - 2020-09-10 13:49:00 --> Loader Class Initialized
INFO - 2020-09-10 13:49:00 --> Helper loaded: html_helper
INFO - 2020-09-10 13:49:00 --> Helper loaded: url_helper
INFO - 2020-09-10 13:49:00 --> Helper loaded: form_helper
INFO - 2020-09-10 13:49:00 --> Database Driver Class Initialized
INFO - 2020-09-10 13:49:00 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:49:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:49:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:49:00 --> Encryption Class Initialized
INFO - 2020-09-10 13:49:00 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:49:00 --> Controller Class Initialized
INFO - 2020-09-10 13:49:00 --> Helper loaded: language_helper
INFO - 2020-09-10 13:49:01 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:49:01 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-10 13:49:01 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-10 13:49:01 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-10 13:49:01 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-10 13:49:01 --> Final output sent to browser
DEBUG - 2020-09-10 13:49:01 --> Total execution time: 1.0324
INFO - 2020-09-10 13:49:05 --> Config Class Initialized
INFO - 2020-09-10 13:49:05 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:49:05 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:49:05 --> Utf8 Class Initialized
INFO - 2020-09-10 13:49:05 --> URI Class Initialized
INFO - 2020-09-10 13:49:05 --> Router Class Initialized
INFO - 2020-09-10 13:49:05 --> Output Class Initialized
INFO - 2020-09-10 13:49:05 --> Security Class Initialized
DEBUG - 2020-09-10 13:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:49:05 --> Input Class Initialized
INFO - 2020-09-10 13:49:05 --> Language Class Initialized
INFO - 2020-09-10 13:49:05 --> Loader Class Initialized
INFO - 2020-09-10 13:49:05 --> Helper loaded: html_helper
INFO - 2020-09-10 13:49:05 --> Helper loaded: url_helper
INFO - 2020-09-10 13:49:05 --> Helper loaded: form_helper
INFO - 2020-09-10 13:49:05 --> Database Driver Class Initialized
INFO - 2020-09-10 13:49:05 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:49:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:49:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:49:05 --> Encryption Class Initialized
INFO - 2020-09-10 13:49:06 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:49:06 --> Controller Class Initialized
INFO - 2020-09-10 13:49:06 --> Helper loaded: language_helper
INFO - 2020-09-10 13:49:06 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:49:06 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-10 13:49:06 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-10 13:49:06 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-10 13:49:06 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-10 13:49:06 --> Final output sent to browser
DEBUG - 2020-09-10 13:49:06 --> Total execution time: 0.8615
INFO - 2020-09-10 13:49:27 --> Config Class Initialized
INFO - 2020-09-10 13:49:27 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:49:27 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:49:27 --> Utf8 Class Initialized
INFO - 2020-09-10 13:49:27 --> URI Class Initialized
INFO - 2020-09-10 13:49:27 --> Router Class Initialized
INFO - 2020-09-10 13:49:27 --> Output Class Initialized
INFO - 2020-09-10 13:49:27 --> Security Class Initialized
DEBUG - 2020-09-10 13:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:49:28 --> Input Class Initialized
INFO - 2020-09-10 13:49:28 --> Language Class Initialized
INFO - 2020-09-10 13:49:28 --> Loader Class Initialized
INFO - 2020-09-10 13:49:28 --> Helper loaded: html_helper
INFO - 2020-09-10 13:49:28 --> Helper loaded: url_helper
INFO - 2020-09-10 13:49:28 --> Helper loaded: form_helper
INFO - 2020-09-10 13:49:28 --> Database Driver Class Initialized
INFO - 2020-09-10 13:49:28 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:49:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:49:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:49:28 --> Encryption Class Initialized
INFO - 2020-09-10 13:49:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:49:28 --> Controller Class Initialized
INFO - 2020-09-10 13:49:28 --> Helper loaded: language_helper
INFO - 2020-09-10 13:49:28 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:49:28 --> Model "Sale_model" initialized
INFO - 2020-09-10 13:49:28 --> Final output sent to browser
DEBUG - 2020-09-10 13:49:28 --> Total execution time: 0.8457
INFO - 2020-09-10 13:49:56 --> Config Class Initialized
INFO - 2020-09-10 13:49:56 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:49:56 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:49:56 --> Utf8 Class Initialized
INFO - 2020-09-10 13:49:56 --> URI Class Initialized
INFO - 2020-09-10 13:49:56 --> Router Class Initialized
INFO - 2020-09-10 13:49:56 --> Output Class Initialized
INFO - 2020-09-10 13:49:56 --> Security Class Initialized
DEBUG - 2020-09-10 13:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:49:56 --> Input Class Initialized
INFO - 2020-09-10 13:49:57 --> Language Class Initialized
INFO - 2020-09-10 13:49:57 --> Loader Class Initialized
INFO - 2020-09-10 13:49:57 --> Helper loaded: html_helper
INFO - 2020-09-10 13:49:57 --> Helper loaded: url_helper
INFO - 2020-09-10 13:49:57 --> Helper loaded: form_helper
INFO - 2020-09-10 13:49:57 --> Database Driver Class Initialized
INFO - 2020-09-10 13:49:57 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:49:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:49:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:49:57 --> Encryption Class Initialized
INFO - 2020-09-10 13:49:57 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:49:57 --> Controller Class Initialized
INFO - 2020-09-10 13:49:57 --> Helper loaded: language_helper
INFO - 2020-09-10 13:49:57 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:49:57 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-10 13:49:57 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-10 13:49:57 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment_custom.php
INFO - 2020-09-10 13:49:57 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-10 13:49:57 --> Final output sent to browser
DEBUG - 2020-09-10 13:49:57 --> Total execution time: 0.6467
INFO - 2020-09-10 13:50:08 --> Config Class Initialized
INFO - 2020-09-10 13:50:08 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:50:08 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:50:08 --> Utf8 Class Initialized
INFO - 2020-09-10 13:50:08 --> URI Class Initialized
INFO - 2020-09-10 13:50:08 --> Router Class Initialized
INFO - 2020-09-10 13:50:08 --> Output Class Initialized
INFO - 2020-09-10 13:50:08 --> Security Class Initialized
DEBUG - 2020-09-10 13:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:50:08 --> Input Class Initialized
INFO - 2020-09-10 13:50:08 --> Language Class Initialized
INFO - 2020-09-10 13:50:08 --> Loader Class Initialized
INFO - 2020-09-10 13:50:08 --> Helper loaded: html_helper
INFO - 2020-09-10 13:50:08 --> Helper loaded: url_helper
INFO - 2020-09-10 13:50:08 --> Helper loaded: form_helper
INFO - 2020-09-10 13:50:08 --> Database Driver Class Initialized
INFO - 2020-09-10 13:50:08 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:50:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:50:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:50:08 --> Encryption Class Initialized
INFO - 2020-09-10 13:50:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:50:08 --> Controller Class Initialized
INFO - 2020-09-10 13:50:08 --> Helper loaded: language_helper
INFO - 2020-09-10 13:50:08 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:50:08 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-10 13:50:08 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-10 13:50:08 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment_custom.php
INFO - 2020-09-10 13:50:08 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-10 13:50:09 --> Final output sent to browser
DEBUG - 2020-09-10 13:50:09 --> Total execution time: 0.6451
INFO - 2020-09-10 13:50:19 --> Config Class Initialized
INFO - 2020-09-10 13:50:19 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:50:19 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:50:19 --> Utf8 Class Initialized
INFO - 2020-09-10 13:50:19 --> URI Class Initialized
INFO - 2020-09-10 13:50:19 --> Router Class Initialized
INFO - 2020-09-10 13:50:19 --> Output Class Initialized
INFO - 2020-09-10 13:50:20 --> Security Class Initialized
DEBUG - 2020-09-10 13:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:50:20 --> Input Class Initialized
INFO - 2020-09-10 13:50:20 --> Language Class Initialized
INFO - 2020-09-10 13:50:20 --> Loader Class Initialized
INFO - 2020-09-10 13:50:20 --> Helper loaded: html_helper
INFO - 2020-09-10 13:50:20 --> Helper loaded: url_helper
INFO - 2020-09-10 13:50:20 --> Helper loaded: form_helper
INFO - 2020-09-10 13:50:20 --> Database Driver Class Initialized
INFO - 2020-09-10 13:50:20 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:50:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:50:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:50:20 --> Encryption Class Initialized
INFO - 2020-09-10 13:50:20 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:50:20 --> Controller Class Initialized
INFO - 2020-09-10 13:50:20 --> Helper loaded: language_helper
INFO - 2020-09-10 13:50:20 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:50:21 --> Final output sent to browser
DEBUG - 2020-09-10 13:50:21 --> Total execution time: 1.8126
INFO - 2020-09-10 13:50:21 --> Config Class Initialized
INFO - 2020-09-10 13:50:21 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:50:21 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:50:21 --> Utf8 Class Initialized
INFO - 2020-09-10 13:50:21 --> URI Class Initialized
INFO - 2020-09-10 13:50:21 --> Router Class Initialized
INFO - 2020-09-10 13:50:21 --> Output Class Initialized
INFO - 2020-09-10 13:50:21 --> Security Class Initialized
DEBUG - 2020-09-10 13:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:50:21 --> Input Class Initialized
INFO - 2020-09-10 13:50:21 --> Language Class Initialized
INFO - 2020-09-10 13:50:21 --> Loader Class Initialized
INFO - 2020-09-10 13:50:21 --> Helper loaded: html_helper
INFO - 2020-09-10 13:50:21 --> Helper loaded: url_helper
INFO - 2020-09-10 13:50:22 --> Helper loaded: form_helper
INFO - 2020-09-10 13:50:22 --> Database Driver Class Initialized
INFO - 2020-09-10 13:50:22 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:50:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:50:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:50:22 --> Encryption Class Initialized
INFO - 2020-09-10 13:50:22 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:50:22 --> Controller Class Initialized
INFO - 2020-09-10 13:50:22 --> Helper loaded: language_helper
INFO - 2020-09-10 13:50:22 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:50:24 --> Final output sent to browser
DEBUG - 2020-09-10 13:50:24 --> Total execution time: 3.0601
INFO - 2020-09-10 13:50:34 --> Config Class Initialized
INFO - 2020-09-10 13:50:34 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:50:34 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:50:34 --> Utf8 Class Initialized
INFO - 2020-09-10 13:50:34 --> URI Class Initialized
INFO - 2020-09-10 13:50:34 --> Router Class Initialized
INFO - 2020-09-10 13:50:34 --> Output Class Initialized
INFO - 2020-09-10 13:50:34 --> Security Class Initialized
DEBUG - 2020-09-10 13:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:50:34 --> Input Class Initialized
INFO - 2020-09-10 13:50:34 --> Language Class Initialized
INFO - 2020-09-10 13:50:34 --> Loader Class Initialized
INFO - 2020-09-10 13:50:34 --> Helper loaded: html_helper
INFO - 2020-09-10 13:50:34 --> Helper loaded: url_helper
INFO - 2020-09-10 13:50:34 --> Helper loaded: form_helper
INFO - 2020-09-10 13:50:34 --> Database Driver Class Initialized
INFO - 2020-09-10 13:50:34 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:50:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:50:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:50:34 --> Encryption Class Initialized
INFO - 2020-09-10 13:50:34 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:50:34 --> Controller Class Initialized
INFO - 2020-09-10 13:50:34 --> Helper loaded: language_helper
INFO - 2020-09-10 13:50:35 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:50:36 --> Final output sent to browser
DEBUG - 2020-09-10 13:50:36 --> Total execution time: 1.8689
INFO - 2020-09-10 13:50:36 --> Config Class Initialized
INFO - 2020-09-10 13:50:36 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:50:36 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:50:36 --> Utf8 Class Initialized
INFO - 2020-09-10 13:50:36 --> URI Class Initialized
INFO - 2020-09-10 13:50:36 --> Router Class Initialized
INFO - 2020-09-10 13:50:36 --> Output Class Initialized
INFO - 2020-09-10 13:50:36 --> Security Class Initialized
DEBUG - 2020-09-10 13:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:50:36 --> Input Class Initialized
INFO - 2020-09-10 13:50:36 --> Language Class Initialized
INFO - 2020-09-10 13:50:36 --> Loader Class Initialized
INFO - 2020-09-10 13:50:36 --> Helper loaded: html_helper
INFO - 2020-09-10 13:50:36 --> Helper loaded: url_helper
INFO - 2020-09-10 13:50:36 --> Helper loaded: form_helper
INFO - 2020-09-10 13:50:36 --> Database Driver Class Initialized
INFO - 2020-09-10 13:50:36 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:50:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:50:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:50:36 --> Encryption Class Initialized
INFO - 2020-09-10 13:50:36 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:50:36 --> Controller Class Initialized
INFO - 2020-09-10 13:50:36 --> Helper loaded: language_helper
INFO - 2020-09-10 13:50:36 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:50:38 --> Final output sent to browser
DEBUG - 2020-09-10 13:50:38 --> Total execution time: 2.1846
INFO - 2020-09-10 13:51:45 --> Config Class Initialized
INFO - 2020-09-10 13:51:45 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:51:45 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:51:45 --> Utf8 Class Initialized
INFO - 2020-09-10 13:51:45 --> URI Class Initialized
INFO - 2020-09-10 13:51:45 --> Router Class Initialized
INFO - 2020-09-10 13:51:45 --> Output Class Initialized
INFO - 2020-09-10 13:51:45 --> Security Class Initialized
DEBUG - 2020-09-10 13:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:51:45 --> Input Class Initialized
INFO - 2020-09-10 13:51:45 --> Language Class Initialized
INFO - 2020-09-10 13:51:45 --> Loader Class Initialized
INFO - 2020-09-10 13:51:45 --> Helper loaded: html_helper
INFO - 2020-09-10 13:51:45 --> Helper loaded: url_helper
INFO - 2020-09-10 13:51:45 --> Helper loaded: form_helper
INFO - 2020-09-10 13:51:45 --> Database Driver Class Initialized
INFO - 2020-09-10 13:51:45 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:51:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:51:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:51:45 --> Encryption Class Initialized
INFO - 2020-09-10 13:51:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:51:46 --> Controller Class Initialized
INFO - 2020-09-10 13:51:46 --> Helper loaded: language_helper
INFO - 2020-09-10 13:51:46 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:51:46 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-10 13:51:46 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-10 13:51:46 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sale.php
INFO - 2020-09-10 13:51:46 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-10 13:51:46 --> Final output sent to browser
DEBUG - 2020-09-10 13:51:46 --> Total execution time: 1.0493
INFO - 2020-09-10 13:52:28 --> Config Class Initialized
INFO - 2020-09-10 13:52:28 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:52:28 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:52:28 --> Utf8 Class Initialized
INFO - 2020-09-10 13:52:28 --> URI Class Initialized
INFO - 2020-09-10 13:52:28 --> Router Class Initialized
INFO - 2020-09-10 13:52:28 --> Output Class Initialized
INFO - 2020-09-10 13:52:28 --> Security Class Initialized
DEBUG - 2020-09-10 13:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:52:28 --> Input Class Initialized
INFO - 2020-09-10 13:52:28 --> Language Class Initialized
INFO - 2020-09-10 13:52:28 --> Loader Class Initialized
INFO - 2020-09-10 13:52:28 --> Helper loaded: html_helper
INFO - 2020-09-10 13:52:29 --> Helper loaded: url_helper
INFO - 2020-09-10 13:52:29 --> Helper loaded: form_helper
INFO - 2020-09-10 13:52:29 --> Database Driver Class Initialized
INFO - 2020-09-10 13:52:29 --> Form Validation Class Initialized
DEBUG - 2020-09-10 13:52:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-10 13:52:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-10 13:52:29 --> Encryption Class Initialized
INFO - 2020-09-10 13:52:29 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-10 13:52:29 --> Controller Class Initialized
INFO - 2020-09-10 13:52:29 --> Helper loaded: language_helper
INFO - 2020-09-10 13:52:29 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-10 13:52:29 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-10 13:52:29 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-10 13:52:29 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment_custom.php
INFO - 2020-09-10 13:52:29 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-10 13:52:29 --> Final output sent to browser
DEBUG - 2020-09-10 13:52:29 --> Total execution time: 0.7828
