<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-19 04:57:10 --> Config Class Initialized
INFO - 2020-09-19 04:57:10 --> Hooks Class Initialized
DEBUG - 2020-09-19 04:57:10 --> UTF-8 Support Enabled
INFO - 2020-09-19 04:57:10 --> Utf8 Class Initialized
INFO - 2020-09-19 04:57:10 --> URI Class Initialized
INFO - 2020-09-19 04:57:10 --> Router Class Initialized
INFO - 2020-09-19 04:57:10 --> Output Class Initialized
INFO - 2020-09-19 04:57:10 --> Security Class Initialized
DEBUG - 2020-09-19 04:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-19 04:57:11 --> Input Class Initialized
INFO - 2020-09-19 04:57:11 --> Language Class Initialized
INFO - 2020-09-19 04:57:11 --> Loader Class Initialized
INFO - 2020-09-19 04:57:11 --> Helper loaded: html_helper
INFO - 2020-09-19 04:57:11 --> Helper loaded: url_helper
INFO - 2020-09-19 04:57:11 --> Helper loaded: form_helper
INFO - 2020-09-19 04:57:11 --> Database Driver Class Initialized
INFO - 2020-09-19 04:57:11 --> Form Validation Class Initialized
DEBUG - 2020-09-19 04:57:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-19 04:57:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-19 04:57:12 --> Encryption Class Initialized
INFO - 2020-09-19 04:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-19 04:57:12 --> Controller Class Initialized
INFO - 2020-09-19 04:57:12 --> Helper loaded: language_helper
INFO - 2020-09-19 04:57:12 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-19 04:57:12 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-19 04:57:12 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-19 04:57:12 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment_custom.php
INFO - 2020-09-19 04:57:12 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-19 04:57:12 --> Final output sent to browser
DEBUG - 2020-09-19 04:57:12 --> Total execution time: 2.3049
INFO - 2020-09-19 17:47:58 --> Config Class Initialized
INFO - 2020-09-19 17:47:58 --> Hooks Class Initialized
DEBUG - 2020-09-19 17:47:58 --> UTF-8 Support Enabled
INFO - 2020-09-19 17:47:58 --> Utf8 Class Initialized
INFO - 2020-09-19 17:47:59 --> URI Class Initialized
INFO - 2020-09-19 17:47:59 --> Router Class Initialized
INFO - 2020-09-19 17:47:59 --> Output Class Initialized
INFO - 2020-09-19 17:47:59 --> Security Class Initialized
DEBUG - 2020-09-19 17:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-19 17:47:59 --> Input Class Initialized
INFO - 2020-09-19 17:47:59 --> Language Class Initialized
INFO - 2020-09-19 17:47:59 --> Loader Class Initialized
INFO - 2020-09-19 17:47:59 --> Helper loaded: html_helper
INFO - 2020-09-19 17:47:59 --> Helper loaded: url_helper
INFO - 2020-09-19 17:47:59 --> Helper loaded: form_helper
INFO - 2020-09-19 17:48:00 --> Database Driver Class Initialized
INFO - 2020-09-19 17:48:00 --> Form Validation Class Initialized
DEBUG - 2020-09-19 17:48:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-19 17:48:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-19 17:48:00 --> Encryption Class Initialized
INFO - 2020-09-19 17:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-19 17:48:00 --> Controller Class Initialized
INFO - 2020-09-19 17:48:00 --> Helper loaded: language_helper
INFO - 2020-09-19 17:48:01 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-19 17:48:01 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-19 17:48:01 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-19 17:48:01 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\customer_care.php
INFO - 2020-09-19 17:48:01 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-19 17:48:01 --> Final output sent to browser
DEBUG - 2020-09-19 17:48:01 --> Total execution time: 2.8091
INFO - 2020-09-19 17:48:02 --> Config Class Initialized
INFO - 2020-09-19 17:48:02 --> Hooks Class Initialized
DEBUG - 2020-09-19 17:48:02 --> UTF-8 Support Enabled
INFO - 2020-09-19 17:48:02 --> Utf8 Class Initialized
INFO - 2020-09-19 17:48:02 --> URI Class Initialized
INFO - 2020-09-19 17:48:02 --> Router Class Initialized
INFO - 2020-09-19 17:48:02 --> Output Class Initialized
INFO - 2020-09-19 17:48:02 --> Security Class Initialized
DEBUG - 2020-09-19 17:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-19 17:48:02 --> Input Class Initialized
INFO - 2020-09-19 17:48:02 --> Language Class Initialized
INFO - 2020-09-19 17:48:02 --> Loader Class Initialized
INFO - 2020-09-19 17:48:02 --> Helper loaded: html_helper
INFO - 2020-09-19 17:48:02 --> Helper loaded: url_helper
INFO - 2020-09-19 17:48:02 --> Helper loaded: form_helper
INFO - 2020-09-19 17:48:02 --> Database Driver Class Initialized
INFO - 2020-09-19 17:48:03 --> Form Validation Class Initialized
DEBUG - 2020-09-19 17:48:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-19 17:48:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-19 17:48:03 --> Encryption Class Initialized
INFO - 2020-09-19 17:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-19 17:48:03 --> Controller Class Initialized
INFO - 2020-09-19 17:48:03 --> Helper loaded: language_helper
INFO - 2020-09-19 17:48:03 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-19 17:48:03 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-19 17:48:03 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-19 17:48:03 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment_custom.php
INFO - 2020-09-19 17:48:03 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-19 17:48:03 --> Final output sent to browser
DEBUG - 2020-09-19 17:48:03 --> Total execution time: 1.1381
