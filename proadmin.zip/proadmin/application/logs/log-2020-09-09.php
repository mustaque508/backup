<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-09 08:10:05 --> Config Class Initialized
INFO - 2020-09-09 08:10:05 --> Hooks Class Initialized
DEBUG - 2020-09-09 08:10:05 --> UTF-8 Support Enabled
INFO - 2020-09-09 08:10:05 --> Utf8 Class Initialized
INFO - 2020-09-09 08:10:05 --> URI Class Initialized
INFO - 2020-09-09 08:10:05 --> Router Class Initialized
INFO - 2020-09-09 08:10:05 --> Output Class Initialized
INFO - 2020-09-09 08:10:05 --> Security Class Initialized
DEBUG - 2020-09-09 08:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 08:10:05 --> Input Class Initialized
INFO - 2020-09-09 08:10:05 --> Language Class Initialized
INFO - 2020-09-09 08:10:05 --> Loader Class Initialized
INFO - 2020-09-09 08:10:05 --> Helper loaded: html_helper
INFO - 2020-09-09 08:10:05 --> Helper loaded: url_helper
INFO - 2020-09-09 08:10:05 --> Helper loaded: form_helper
INFO - 2020-09-09 08:10:05 --> Database Driver Class Initialized
INFO - 2020-09-09 08:10:05 --> Form Validation Class Initialized
DEBUG - 2020-09-09 08:10:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 08:10:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 08:10:05 --> Encryption Class Initialized
INFO - 2020-09-09 08:10:06 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 08:10:06 --> Controller Class Initialized
INFO - 2020-09-09 08:10:06 --> Helper loaded: language_helper
INFO - 2020-09-09 08:10:06 --> Language file loaded: language/english/content_lang.php
ERROR - 2020-09-09 08:10:06 --> THIS IS TEST
INFO - 2020-09-09 08:10:06 --> Final output sent to browser
DEBUG - 2020-09-09 08:10:06 --> Total execution time: 1.1612
INFO - 2020-09-09 08:10:51 --> Config Class Initialized
INFO - 2020-09-09 08:10:51 --> Hooks Class Initialized
DEBUG - 2020-09-09 08:10:51 --> UTF-8 Support Enabled
INFO - 2020-09-09 08:10:51 --> Utf8 Class Initialized
INFO - 2020-09-09 08:10:51 --> URI Class Initialized
INFO - 2020-09-09 08:10:51 --> Router Class Initialized
INFO - 2020-09-09 08:10:51 --> Output Class Initialized
INFO - 2020-09-09 08:10:51 --> Security Class Initialized
DEBUG - 2020-09-09 08:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 08:10:51 --> Input Class Initialized
INFO - 2020-09-09 08:10:51 --> Language Class Initialized
INFO - 2020-09-09 08:10:51 --> Loader Class Initialized
INFO - 2020-09-09 08:10:51 --> Helper loaded: html_helper
INFO - 2020-09-09 08:10:51 --> Helper loaded: url_helper
INFO - 2020-09-09 08:10:51 --> Helper loaded: form_helper
INFO - 2020-09-09 08:10:51 --> Database Driver Class Initialized
INFO - 2020-09-09 08:10:51 --> Form Validation Class Initialized
DEBUG - 2020-09-09 08:10:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 08:10:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 08:10:51 --> Encryption Class Initialized
INFO - 2020-09-09 08:10:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 08:10:52 --> Controller Class Initialized
INFO - 2020-09-09 08:10:52 --> Helper loaded: language_helper
INFO - 2020-09-09 08:10:52 --> Language file loaded: language/english/content_lang.php
ERROR - 2020-09-09 08:10:52 --> THIS IS TEST
INFO - 2020-09-09 08:10:52 --> Final output sent to browser
DEBUG - 2020-09-09 08:10:52 --> Total execution time: 0.7019
INFO - 2020-09-09 08:15:17 --> Config Class Initialized
INFO - 2020-09-09 08:15:17 --> Hooks Class Initialized
DEBUG - 2020-09-09 08:15:17 --> UTF-8 Support Enabled
INFO - 2020-09-09 08:15:17 --> Utf8 Class Initialized
INFO - 2020-09-09 08:15:17 --> URI Class Initialized
INFO - 2020-09-09 08:15:17 --> Router Class Initialized
INFO - 2020-09-09 08:15:17 --> Output Class Initialized
INFO - 2020-09-09 08:15:17 --> Security Class Initialized
DEBUG - 2020-09-09 08:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 08:15:17 --> Input Class Initialized
INFO - 2020-09-09 08:15:17 --> Language Class Initialized
INFO - 2020-09-09 08:15:17 --> Loader Class Initialized
INFO - 2020-09-09 08:15:17 --> Helper loaded: html_helper
INFO - 2020-09-09 08:15:17 --> Helper loaded: url_helper
INFO - 2020-09-09 08:15:17 --> Helper loaded: form_helper
INFO - 2020-09-09 08:15:17 --> Database Driver Class Initialized
INFO - 2020-09-09 08:15:17 --> Form Validation Class Initialized
DEBUG - 2020-09-09 08:15:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 08:15:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 08:15:18 --> Encryption Class Initialized
INFO - 2020-09-09 08:15:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 08:15:18 --> Controller Class Initialized
INFO - 2020-09-09 08:15:18 --> Helper loaded: language_helper
INFO - 2020-09-09 08:15:18 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 08:15:18 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 08:15:18 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 08:15:18 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\purchase.php
INFO - 2020-09-09 08:15:18 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 08:15:18 --> Final output sent to browser
DEBUG - 2020-09-09 08:15:18 --> Total execution time: 0.9440
INFO - 2020-09-09 08:15:26 --> Config Class Initialized
INFO - 2020-09-09 08:15:26 --> Hooks Class Initialized
DEBUG - 2020-09-09 08:15:26 --> UTF-8 Support Enabled
INFO - 2020-09-09 08:15:26 --> Utf8 Class Initialized
INFO - 2020-09-09 08:15:26 --> URI Class Initialized
INFO - 2020-09-09 08:15:26 --> Router Class Initialized
INFO - 2020-09-09 08:15:26 --> Output Class Initialized
INFO - 2020-09-09 08:15:26 --> Security Class Initialized
DEBUG - 2020-09-09 08:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 08:15:26 --> Input Class Initialized
INFO - 2020-09-09 08:15:26 --> Language Class Initialized
INFO - 2020-09-09 08:15:26 --> Loader Class Initialized
INFO - 2020-09-09 08:15:26 --> Helper loaded: html_helper
INFO - 2020-09-09 08:15:26 --> Helper loaded: url_helper
INFO - 2020-09-09 08:15:26 --> Helper loaded: form_helper
INFO - 2020-09-09 08:15:26 --> Database Driver Class Initialized
INFO - 2020-09-09 08:15:26 --> Form Validation Class Initialized
DEBUG - 2020-09-09 08:15:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 08:15:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 08:15:26 --> Encryption Class Initialized
INFO - 2020-09-09 08:15:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 08:15:26 --> Controller Class Initialized
INFO - 2020-09-09 08:15:26 --> Helper loaded: language_helper
INFO - 2020-09-09 08:15:26 --> Language file loaded: language/english/content_lang.php
ERROR - 2020-09-09 08:15:27 --> Severity: Notice --> Undefined index: from_timestamp C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\controllers\Purchase.php 33
INFO - 2020-09-09 08:15:27 --> Final output sent to browser
DEBUG - 2020-09-09 08:15:27 --> Total execution time: 1.0590
INFO - 2020-09-09 08:17:14 --> Config Class Initialized
INFO - 2020-09-09 08:17:14 --> Hooks Class Initialized
DEBUG - 2020-09-09 08:17:14 --> UTF-8 Support Enabled
INFO - 2020-09-09 08:17:14 --> Utf8 Class Initialized
INFO - 2020-09-09 08:17:14 --> URI Class Initialized
INFO - 2020-09-09 08:17:14 --> Router Class Initialized
INFO - 2020-09-09 08:17:14 --> Output Class Initialized
INFO - 2020-09-09 08:17:14 --> Security Class Initialized
DEBUG - 2020-09-09 08:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 08:17:14 --> Input Class Initialized
INFO - 2020-09-09 08:17:14 --> Language Class Initialized
INFO - 2020-09-09 08:17:14 --> Loader Class Initialized
INFO - 2020-09-09 08:17:14 --> Helper loaded: html_helper
INFO - 2020-09-09 08:17:14 --> Helper loaded: url_helper
INFO - 2020-09-09 08:17:14 --> Helper loaded: form_helper
INFO - 2020-09-09 08:17:14 --> Database Driver Class Initialized
INFO - 2020-09-09 08:17:14 --> Form Validation Class Initialized
DEBUG - 2020-09-09 08:17:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 08:17:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 08:17:15 --> Encryption Class Initialized
INFO - 2020-09-09 08:17:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 08:17:15 --> Controller Class Initialized
INFO - 2020-09-09 08:17:15 --> Helper loaded: language_helper
INFO - 2020-09-09 08:17:15 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 08:17:15 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 08:17:15 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 08:17:15 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\purchase.php
INFO - 2020-09-09 08:17:15 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 08:17:15 --> Final output sent to browser
DEBUG - 2020-09-09 08:17:15 --> Total execution time: 1.1679
INFO - 2020-09-09 08:17:18 --> Config Class Initialized
INFO - 2020-09-09 08:17:18 --> Hooks Class Initialized
DEBUG - 2020-09-09 08:17:18 --> UTF-8 Support Enabled
INFO - 2020-09-09 08:17:18 --> Utf8 Class Initialized
INFO - 2020-09-09 08:17:18 --> URI Class Initialized
INFO - 2020-09-09 08:17:19 --> Router Class Initialized
INFO - 2020-09-09 08:17:19 --> Output Class Initialized
INFO - 2020-09-09 08:17:19 --> Security Class Initialized
DEBUG - 2020-09-09 08:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 08:17:19 --> Input Class Initialized
INFO - 2020-09-09 08:17:19 --> Language Class Initialized
INFO - 2020-09-09 08:17:19 --> Loader Class Initialized
INFO - 2020-09-09 08:17:19 --> Helper loaded: html_helper
INFO - 2020-09-09 08:17:19 --> Helper loaded: url_helper
INFO - 2020-09-09 08:17:19 --> Helper loaded: form_helper
INFO - 2020-09-09 08:17:19 --> Database Driver Class Initialized
INFO - 2020-09-09 08:17:19 --> Form Validation Class Initialized
DEBUG - 2020-09-09 08:17:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 08:17:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 08:17:19 --> Encryption Class Initialized
INFO - 2020-09-09 08:17:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 08:17:19 --> Controller Class Initialized
INFO - 2020-09-09 08:17:19 --> Helper loaded: language_helper
INFO - 2020-09-09 08:17:19 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 08:17:19 --> Final output sent to browser
DEBUG - 2020-09-09 08:17:19 --> Total execution time: 0.7694
INFO - 2020-09-09 08:20:08 --> Config Class Initialized
INFO - 2020-09-09 08:20:08 --> Hooks Class Initialized
DEBUG - 2020-09-09 08:20:08 --> UTF-8 Support Enabled
INFO - 2020-09-09 08:20:08 --> Utf8 Class Initialized
INFO - 2020-09-09 08:20:08 --> URI Class Initialized
INFO - 2020-09-09 08:20:08 --> Router Class Initialized
INFO - 2020-09-09 08:20:08 --> Output Class Initialized
INFO - 2020-09-09 08:20:08 --> Security Class Initialized
DEBUG - 2020-09-09 08:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 08:20:08 --> Input Class Initialized
INFO - 2020-09-09 08:20:08 --> Language Class Initialized
INFO - 2020-09-09 08:20:08 --> Loader Class Initialized
INFO - 2020-09-09 08:20:08 --> Helper loaded: html_helper
INFO - 2020-09-09 08:20:08 --> Helper loaded: url_helper
INFO - 2020-09-09 08:20:08 --> Helper loaded: form_helper
INFO - 2020-09-09 08:20:08 --> Database Driver Class Initialized
INFO - 2020-09-09 08:20:08 --> Form Validation Class Initialized
DEBUG - 2020-09-09 08:20:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 08:20:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 08:20:08 --> Encryption Class Initialized
INFO - 2020-09-09 08:20:09 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 08:20:09 --> Controller Class Initialized
INFO - 2020-09-09 08:20:09 --> Helper loaded: language_helper
INFO - 2020-09-09 08:20:09 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 08:20:09 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-09 08:20:09 --> Final output sent to browser
DEBUG - 2020-09-09 08:20:09 --> Total execution time: 1.1682
INFO - 2020-09-09 08:20:14 --> Config Class Initialized
INFO - 2020-09-09 08:20:14 --> Hooks Class Initialized
DEBUG - 2020-09-09 08:20:14 --> UTF-8 Support Enabled
INFO - 2020-09-09 08:20:14 --> Utf8 Class Initialized
INFO - 2020-09-09 08:20:14 --> URI Class Initialized
INFO - 2020-09-09 08:20:14 --> Router Class Initialized
INFO - 2020-09-09 08:20:14 --> Output Class Initialized
INFO - 2020-09-09 08:20:14 --> Security Class Initialized
DEBUG - 2020-09-09 08:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 08:20:14 --> Input Class Initialized
INFO - 2020-09-09 08:20:14 --> Language Class Initialized
INFO - 2020-09-09 08:20:14 --> Loader Class Initialized
INFO - 2020-09-09 08:20:14 --> Helper loaded: html_helper
INFO - 2020-09-09 08:20:14 --> Helper loaded: url_helper
INFO - 2020-09-09 08:20:14 --> Helper loaded: form_helper
INFO - 2020-09-09 08:20:14 --> Database Driver Class Initialized
INFO - 2020-09-09 08:20:14 --> Form Validation Class Initialized
DEBUG - 2020-09-09 08:20:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 08:20:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 08:20:14 --> Encryption Class Initialized
INFO - 2020-09-09 08:20:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 08:20:15 --> Controller Class Initialized
INFO - 2020-09-09 08:20:15 --> Helper loaded: language_helper
INFO - 2020-09-09 08:20:15 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-09 08:20:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-09 08:20:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-09 08:20:15 --> Model "User" initialized
INFO - 2020-09-09 08:20:16 --> Config Class Initialized
INFO - 2020-09-09 08:20:16 --> Hooks Class Initialized
DEBUG - 2020-09-09 08:20:16 --> UTF-8 Support Enabled
INFO - 2020-09-09 08:20:16 --> Utf8 Class Initialized
INFO - 2020-09-09 08:20:16 --> URI Class Initialized
INFO - 2020-09-09 08:20:16 --> Router Class Initialized
INFO - 2020-09-09 08:20:16 --> Output Class Initialized
INFO - 2020-09-09 08:20:16 --> Security Class Initialized
DEBUG - 2020-09-09 08:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 08:20:16 --> Input Class Initialized
INFO - 2020-09-09 08:20:16 --> Language Class Initialized
INFO - 2020-09-09 08:20:16 --> Loader Class Initialized
INFO - 2020-09-09 08:20:16 --> Helper loaded: html_helper
INFO - 2020-09-09 08:20:16 --> Helper loaded: url_helper
INFO - 2020-09-09 08:20:16 --> Helper loaded: form_helper
INFO - 2020-09-09 08:20:16 --> Database Driver Class Initialized
INFO - 2020-09-09 08:20:16 --> Form Validation Class Initialized
DEBUG - 2020-09-09 08:20:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 08:20:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 08:20:16 --> Encryption Class Initialized
INFO - 2020-09-09 08:20:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 08:20:17 --> Controller Class Initialized
INFO - 2020-09-09 08:20:17 --> Helper loaded: language_helper
INFO - 2020-09-09 08:20:17 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 08:20:17 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-09 08:20:17 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 08:20:17 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-09 08:20:17 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 08:20:17 --> Final output sent to browser
DEBUG - 2020-09-09 08:20:17 --> Total execution time: 1.2144
INFO - 2020-09-09 08:20:19 --> Config Class Initialized
INFO - 2020-09-09 08:20:19 --> Hooks Class Initialized
DEBUG - 2020-09-09 08:20:19 --> UTF-8 Support Enabled
INFO - 2020-09-09 08:20:19 --> Utf8 Class Initialized
INFO - 2020-09-09 08:20:20 --> URI Class Initialized
INFO - 2020-09-09 08:20:20 --> Router Class Initialized
INFO - 2020-09-09 08:20:20 --> Output Class Initialized
INFO - 2020-09-09 08:20:20 --> Security Class Initialized
DEBUG - 2020-09-09 08:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 08:20:20 --> Input Class Initialized
INFO - 2020-09-09 08:20:20 --> Language Class Initialized
INFO - 2020-09-09 08:20:20 --> Loader Class Initialized
INFO - 2020-09-09 08:20:20 --> Helper loaded: html_helper
INFO - 2020-09-09 08:20:20 --> Helper loaded: url_helper
INFO - 2020-09-09 08:20:20 --> Helper loaded: form_helper
INFO - 2020-09-09 08:20:20 --> Database Driver Class Initialized
INFO - 2020-09-09 08:20:20 --> Form Validation Class Initialized
DEBUG - 2020-09-09 08:20:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 08:20:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 08:20:20 --> Encryption Class Initialized
INFO - 2020-09-09 08:20:20 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 08:20:20 --> Controller Class Initialized
INFO - 2020-09-09 08:20:20 --> Helper loaded: language_helper
INFO - 2020-09-09 08:20:20 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 08:20:20 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-09 08:20:20 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 08:20:20 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-09 08:20:20 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 08:20:21 --> Final output sent to browser
DEBUG - 2020-09-09 08:20:21 --> Total execution time: 1.1267
INFO - 2020-09-09 08:20:39 --> Config Class Initialized
INFO - 2020-09-09 08:20:39 --> Hooks Class Initialized
DEBUG - 2020-09-09 08:20:39 --> UTF-8 Support Enabled
INFO - 2020-09-09 08:20:39 --> Utf8 Class Initialized
INFO - 2020-09-09 08:20:39 --> URI Class Initialized
INFO - 2020-09-09 08:20:39 --> Router Class Initialized
INFO - 2020-09-09 08:20:39 --> Output Class Initialized
INFO - 2020-09-09 08:20:39 --> Security Class Initialized
DEBUG - 2020-09-09 08:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 08:20:39 --> Input Class Initialized
INFO - 2020-09-09 08:20:39 --> Language Class Initialized
INFO - 2020-09-09 08:20:39 --> Loader Class Initialized
INFO - 2020-09-09 08:20:39 --> Helper loaded: html_helper
INFO - 2020-09-09 08:20:39 --> Helper loaded: url_helper
INFO - 2020-09-09 08:20:39 --> Helper loaded: form_helper
INFO - 2020-09-09 08:20:39 --> Database Driver Class Initialized
INFO - 2020-09-09 08:20:39 --> Form Validation Class Initialized
DEBUG - 2020-09-09 08:20:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 08:20:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 08:20:40 --> Encryption Class Initialized
INFO - 2020-09-09 08:20:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 08:20:40 --> Controller Class Initialized
INFO - 2020-09-09 08:20:40 --> Helper loaded: language_helper
INFO - 2020-09-09 08:20:40 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 08:20:40 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 08:20:40 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 08:20:40 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\purchase.php
INFO - 2020-09-09 08:20:40 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 08:20:40 --> Final output sent to browser
DEBUG - 2020-09-09 08:20:40 --> Total execution time: 1.2800
INFO - 2020-09-09 08:20:51 --> Config Class Initialized
INFO - 2020-09-09 08:20:51 --> Hooks Class Initialized
DEBUG - 2020-09-09 08:20:51 --> UTF-8 Support Enabled
INFO - 2020-09-09 08:20:51 --> Utf8 Class Initialized
INFO - 2020-09-09 08:20:51 --> URI Class Initialized
INFO - 2020-09-09 08:20:51 --> Router Class Initialized
INFO - 2020-09-09 08:20:51 --> Output Class Initialized
INFO - 2020-09-09 08:20:51 --> Security Class Initialized
DEBUG - 2020-09-09 08:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 08:20:51 --> Input Class Initialized
INFO - 2020-09-09 08:20:51 --> Language Class Initialized
INFO - 2020-09-09 08:20:51 --> Loader Class Initialized
INFO - 2020-09-09 08:20:51 --> Helper loaded: html_helper
INFO - 2020-09-09 08:20:51 --> Helper loaded: url_helper
INFO - 2020-09-09 08:20:51 --> Helper loaded: form_helper
INFO - 2020-09-09 08:20:51 --> Database Driver Class Initialized
INFO - 2020-09-09 08:20:51 --> Form Validation Class Initialized
DEBUG - 2020-09-09 08:20:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 08:20:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 08:20:51 --> Encryption Class Initialized
INFO - 2020-09-09 08:20:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 08:20:52 --> Controller Class Initialized
INFO - 2020-09-09 08:20:52 --> Helper loaded: language_helper
INFO - 2020-09-09 08:20:52 --> Language file loaded: language/english/content_lang.php
ERROR - 2020-09-09 08:20:52 --> Severity: error --> Exception: Function name must be a string C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\controllers\Purchase.php 31
INFO - 2020-09-09 08:20:59 --> Config Class Initialized
INFO - 2020-09-09 08:20:59 --> Hooks Class Initialized
DEBUG - 2020-09-09 08:20:59 --> UTF-8 Support Enabled
INFO - 2020-09-09 08:20:59 --> Utf8 Class Initialized
INFO - 2020-09-09 08:20:59 --> URI Class Initialized
INFO - 2020-09-09 08:20:59 --> Router Class Initialized
INFO - 2020-09-09 08:20:59 --> Output Class Initialized
INFO - 2020-09-09 08:20:59 --> Security Class Initialized
DEBUG - 2020-09-09 08:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 08:20:59 --> Input Class Initialized
INFO - 2020-09-09 08:20:59 --> Language Class Initialized
INFO - 2020-09-09 08:20:59 --> Loader Class Initialized
INFO - 2020-09-09 08:20:59 --> Helper loaded: html_helper
INFO - 2020-09-09 08:20:59 --> Helper loaded: url_helper
INFO - 2020-09-09 08:20:59 --> Helper loaded: form_helper
INFO - 2020-09-09 08:20:59 --> Database Driver Class Initialized
INFO - 2020-09-09 08:20:59 --> Form Validation Class Initialized
DEBUG - 2020-09-09 08:20:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 08:20:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 08:20:59 --> Encryption Class Initialized
INFO - 2020-09-09 08:20:59 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 08:21:00 --> Controller Class Initialized
INFO - 2020-09-09 08:21:00 --> Helper loaded: language_helper
INFO - 2020-09-09 08:21:00 --> Language file loaded: language/english/content_lang.php
ERROR - 2020-09-09 08:21:00 --> Severity: error --> Exception: Function name must be a string C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\controllers\Purchase.php 31
INFO - 2020-09-09 10:10:24 --> Config Class Initialized
INFO - 2020-09-09 10:10:24 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:10:24 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:10:24 --> Utf8 Class Initialized
INFO - 2020-09-09 10:10:24 --> URI Class Initialized
INFO - 2020-09-09 10:10:24 --> Router Class Initialized
INFO - 2020-09-09 10:10:24 --> Output Class Initialized
INFO - 2020-09-09 10:10:24 --> Security Class Initialized
DEBUG - 2020-09-09 10:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:10:24 --> Input Class Initialized
INFO - 2020-09-09 10:10:24 --> Language Class Initialized
INFO - 2020-09-09 10:10:24 --> Loader Class Initialized
INFO - 2020-09-09 10:10:25 --> Helper loaded: html_helper
INFO - 2020-09-09 10:10:25 --> Helper loaded: url_helper
INFO - 2020-09-09 10:10:25 --> Helper loaded: form_helper
INFO - 2020-09-09 10:10:25 --> Database Driver Class Initialized
INFO - 2020-09-09 10:10:25 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:10:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:10:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:10:25 --> Encryption Class Initialized
INFO - 2020-09-09 10:10:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:10:25 --> Controller Class Initialized
INFO - 2020-09-09 10:10:25 --> Helper loaded: language_helper
INFO - 2020-09-09 10:10:25 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:10:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 10:10:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 10:10:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\purchase.php
INFO - 2020-09-09 10:10:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 10:10:25 --> Final output sent to browser
DEBUG - 2020-09-09 10:10:25 --> Total execution time: 1.1690
INFO - 2020-09-09 10:10:29 --> Config Class Initialized
INFO - 2020-09-09 10:10:29 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:10:29 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:10:29 --> Utf8 Class Initialized
INFO - 2020-09-09 10:10:29 --> URI Class Initialized
INFO - 2020-09-09 10:10:29 --> Router Class Initialized
INFO - 2020-09-09 10:10:29 --> Output Class Initialized
INFO - 2020-09-09 10:10:29 --> Security Class Initialized
DEBUG - 2020-09-09 10:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:10:29 --> Input Class Initialized
INFO - 2020-09-09 10:10:29 --> Language Class Initialized
INFO - 2020-09-09 10:10:29 --> Loader Class Initialized
INFO - 2020-09-09 10:10:29 --> Helper loaded: html_helper
INFO - 2020-09-09 10:10:29 --> Helper loaded: url_helper
INFO - 2020-09-09 10:10:29 --> Helper loaded: form_helper
INFO - 2020-09-09 10:10:29 --> Database Driver Class Initialized
INFO - 2020-09-09 10:10:29 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:10:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:10:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:10:30 --> Encryption Class Initialized
INFO - 2020-09-09 10:10:30 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:10:30 --> Controller Class Initialized
INFO - 2020-09-09 10:10:30 --> Helper loaded: language_helper
INFO - 2020-09-09 10:10:30 --> Language file loaded: language/english/content_lang.php
ERROR - 2020-09-09 10:10:30 --> Severity: error --> Exception: Function name must be a string C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\controllers\Purchase.php 31
INFO - 2020-09-09 10:10:35 --> Config Class Initialized
INFO - 2020-09-09 10:10:35 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:10:35 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:10:35 --> Utf8 Class Initialized
INFO - 2020-09-09 10:10:35 --> URI Class Initialized
INFO - 2020-09-09 10:10:35 --> Router Class Initialized
INFO - 2020-09-09 10:10:35 --> Output Class Initialized
INFO - 2020-09-09 10:10:35 --> Security Class Initialized
DEBUG - 2020-09-09 10:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:10:35 --> Input Class Initialized
INFO - 2020-09-09 10:10:35 --> Language Class Initialized
INFO - 2020-09-09 10:10:35 --> Loader Class Initialized
INFO - 2020-09-09 10:10:35 --> Helper loaded: html_helper
INFO - 2020-09-09 10:10:35 --> Helper loaded: url_helper
INFO - 2020-09-09 10:10:35 --> Helper loaded: form_helper
INFO - 2020-09-09 10:10:35 --> Database Driver Class Initialized
INFO - 2020-09-09 10:10:35 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:10:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:10:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:10:35 --> Encryption Class Initialized
INFO - 2020-09-09 10:10:35 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:10:35 --> Controller Class Initialized
INFO - 2020-09-09 10:10:35 --> Helper loaded: language_helper
INFO - 2020-09-09 10:10:35 --> Language file loaded: language/english/content_lang.php
ERROR - 2020-09-09 10:10:35 --> Severity: error --> Exception: Function name must be a string C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\controllers\Purchase.php 31
INFO - 2020-09-09 10:15:12 --> Config Class Initialized
INFO - 2020-09-09 10:15:12 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:15:12 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:15:12 --> Utf8 Class Initialized
INFO - 2020-09-09 10:15:12 --> URI Class Initialized
INFO - 2020-09-09 10:15:12 --> Router Class Initialized
INFO - 2020-09-09 10:15:12 --> Output Class Initialized
INFO - 2020-09-09 10:15:12 --> Security Class Initialized
DEBUG - 2020-09-09 10:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:15:12 --> Input Class Initialized
INFO - 2020-09-09 10:15:12 --> Language Class Initialized
INFO - 2020-09-09 10:15:12 --> Loader Class Initialized
INFO - 2020-09-09 10:15:12 --> Helper loaded: html_helper
INFO - 2020-09-09 10:15:12 --> Helper loaded: url_helper
INFO - 2020-09-09 10:15:12 --> Helper loaded: form_helper
INFO - 2020-09-09 10:15:12 --> Database Driver Class Initialized
INFO - 2020-09-09 10:15:12 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:15:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:15:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:15:12 --> Encryption Class Initialized
INFO - 2020-09-09 10:15:12 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:15:12 --> Controller Class Initialized
INFO - 2020-09-09 10:15:12 --> Helper loaded: language_helper
INFO - 2020-09-09 10:15:12 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:15:12 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 10:15:12 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 10:15:12 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\purchase.php
INFO - 2020-09-09 10:15:12 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 10:15:12 --> Final output sent to browser
DEBUG - 2020-09-09 10:15:12 --> Total execution time: 0.7453
INFO - 2020-09-09 10:15:20 --> Config Class Initialized
INFO - 2020-09-09 10:15:20 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:15:20 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:15:20 --> Utf8 Class Initialized
INFO - 2020-09-09 10:15:20 --> URI Class Initialized
INFO - 2020-09-09 10:15:20 --> Router Class Initialized
INFO - 2020-09-09 10:15:20 --> Output Class Initialized
INFO - 2020-09-09 10:15:20 --> Security Class Initialized
DEBUG - 2020-09-09 10:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:15:20 --> Input Class Initialized
INFO - 2020-09-09 10:15:20 --> Language Class Initialized
INFO - 2020-09-09 10:15:20 --> Loader Class Initialized
INFO - 2020-09-09 10:15:20 --> Helper loaded: html_helper
INFO - 2020-09-09 10:15:20 --> Helper loaded: url_helper
INFO - 2020-09-09 10:15:20 --> Helper loaded: form_helper
INFO - 2020-09-09 10:15:20 --> Database Driver Class Initialized
INFO - 2020-09-09 10:15:20 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:15:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:15:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:15:20 --> Encryption Class Initialized
INFO - 2020-09-09 10:15:20 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:15:20 --> Controller Class Initialized
INFO - 2020-09-09 10:15:20 --> Helper loaded: language_helper
INFO - 2020-09-09 10:15:20 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:15:20 --> Model "Purchase_Model" initialized
ERROR - 2020-09-09 10:15:20 --> Severity: error --> Exception: Call to a member function result() on string C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\controllers\Purchase.php 40
INFO - 2020-09-09 10:15:25 --> Config Class Initialized
INFO - 2020-09-09 10:15:25 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:15:25 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:15:25 --> Utf8 Class Initialized
INFO - 2020-09-09 10:15:25 --> URI Class Initialized
INFO - 2020-09-09 10:15:25 --> Router Class Initialized
INFO - 2020-09-09 10:15:25 --> Output Class Initialized
INFO - 2020-09-09 10:15:25 --> Security Class Initialized
DEBUG - 2020-09-09 10:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:15:25 --> Input Class Initialized
INFO - 2020-09-09 10:15:25 --> Language Class Initialized
INFO - 2020-09-09 10:15:25 --> Loader Class Initialized
INFO - 2020-09-09 10:15:25 --> Helper loaded: html_helper
INFO - 2020-09-09 10:15:25 --> Helper loaded: url_helper
INFO - 2020-09-09 10:15:25 --> Helper loaded: form_helper
INFO - 2020-09-09 10:15:25 --> Database Driver Class Initialized
INFO - 2020-09-09 10:15:25 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:15:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:15:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:15:25 --> Encryption Class Initialized
INFO - 2020-09-09 10:15:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:15:25 --> Controller Class Initialized
INFO - 2020-09-09 10:15:25 --> Helper loaded: language_helper
INFO - 2020-09-09 10:15:25 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:15:25 --> Model "Purchase_Model" initialized
ERROR - 2020-09-09 10:15:25 --> Severity: error --> Exception: Call to a member function result() on string C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\controllers\Purchase.php 40
INFO - 2020-09-09 10:18:08 --> Config Class Initialized
INFO - 2020-09-09 10:18:08 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:18:08 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:18:08 --> Utf8 Class Initialized
INFO - 2020-09-09 10:18:08 --> URI Class Initialized
INFO - 2020-09-09 10:18:08 --> Router Class Initialized
INFO - 2020-09-09 10:18:08 --> Output Class Initialized
INFO - 2020-09-09 10:18:08 --> Security Class Initialized
DEBUG - 2020-09-09 10:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:18:08 --> Input Class Initialized
INFO - 2020-09-09 10:18:08 --> Language Class Initialized
INFO - 2020-09-09 10:18:08 --> Loader Class Initialized
INFO - 2020-09-09 10:18:08 --> Helper loaded: html_helper
INFO - 2020-09-09 10:18:08 --> Helper loaded: url_helper
INFO - 2020-09-09 10:18:08 --> Helper loaded: form_helper
INFO - 2020-09-09 10:18:08 --> Database Driver Class Initialized
INFO - 2020-09-09 10:18:08 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:18:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:18:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:18:08 --> Encryption Class Initialized
INFO - 2020-09-09 10:18:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:18:08 --> Controller Class Initialized
INFO - 2020-09-09 10:18:09 --> Helper loaded: language_helper
INFO - 2020-09-09 10:18:09 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:18:09 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-09 10:18:09 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 10:18:09 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-09 10:18:09 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 10:18:09 --> Final output sent to browser
DEBUG - 2020-09-09 10:18:09 --> Total execution time: 0.6318
INFO - 2020-09-09 10:18:11 --> Config Class Initialized
INFO - 2020-09-09 10:18:11 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:18:11 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:18:11 --> Utf8 Class Initialized
INFO - 2020-09-09 10:18:11 --> URI Class Initialized
INFO - 2020-09-09 10:18:11 --> Router Class Initialized
INFO - 2020-09-09 10:18:11 --> Output Class Initialized
INFO - 2020-09-09 10:18:11 --> Security Class Initialized
DEBUG - 2020-09-09 10:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:18:11 --> Input Class Initialized
INFO - 2020-09-09 10:18:11 --> Language Class Initialized
INFO - 2020-09-09 10:18:11 --> Loader Class Initialized
INFO - 2020-09-09 10:18:11 --> Helper loaded: html_helper
INFO - 2020-09-09 10:18:11 --> Helper loaded: url_helper
INFO - 2020-09-09 10:18:11 --> Helper loaded: form_helper
INFO - 2020-09-09 10:18:11 --> Database Driver Class Initialized
INFO - 2020-09-09 10:18:11 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:18:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:18:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:18:11 --> Encryption Class Initialized
INFO - 2020-09-09 10:18:11 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:18:11 --> Controller Class Initialized
INFO - 2020-09-09 10:18:11 --> Helper loaded: language_helper
INFO - 2020-09-09 10:18:11 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:18:11 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-09 10:18:11 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 10:18:11 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-09 10:18:11 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 10:18:11 --> Final output sent to browser
DEBUG - 2020-09-09 10:18:11 --> Total execution time: 0.6149
INFO - 2020-09-09 10:18:14 --> Config Class Initialized
INFO - 2020-09-09 10:18:14 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:18:14 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:18:14 --> Utf8 Class Initialized
INFO - 2020-09-09 10:18:14 --> URI Class Initialized
INFO - 2020-09-09 10:18:14 --> Router Class Initialized
INFO - 2020-09-09 10:18:14 --> Output Class Initialized
INFO - 2020-09-09 10:18:14 --> Security Class Initialized
DEBUG - 2020-09-09 10:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:18:14 --> Input Class Initialized
INFO - 2020-09-09 10:18:14 --> Language Class Initialized
INFO - 2020-09-09 10:18:14 --> Loader Class Initialized
INFO - 2020-09-09 10:18:14 --> Helper loaded: html_helper
INFO - 2020-09-09 10:18:14 --> Helper loaded: url_helper
INFO - 2020-09-09 10:18:15 --> Helper loaded: form_helper
INFO - 2020-09-09 10:18:15 --> Database Driver Class Initialized
INFO - 2020-09-09 10:18:15 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:18:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:18:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:18:15 --> Encryption Class Initialized
INFO - 2020-09-09 10:18:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:18:15 --> Controller Class Initialized
INFO - 2020-09-09 10:18:15 --> Helper loaded: language_helper
INFO - 2020-09-09 10:18:15 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:18:15 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 10:18:15 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 10:18:15 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\purchase.php
INFO - 2020-09-09 10:18:15 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 10:18:15 --> Final output sent to browser
DEBUG - 2020-09-09 10:18:15 --> Total execution time: 0.5698
INFO - 2020-09-09 10:18:23 --> Config Class Initialized
INFO - 2020-09-09 10:18:23 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:18:23 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:18:23 --> Utf8 Class Initialized
INFO - 2020-09-09 10:18:23 --> URI Class Initialized
INFO - 2020-09-09 10:18:23 --> Router Class Initialized
INFO - 2020-09-09 10:18:23 --> Output Class Initialized
INFO - 2020-09-09 10:18:23 --> Security Class Initialized
DEBUG - 2020-09-09 10:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:18:23 --> Input Class Initialized
INFO - 2020-09-09 10:18:23 --> Language Class Initialized
INFO - 2020-09-09 10:18:23 --> Loader Class Initialized
INFO - 2020-09-09 10:18:23 --> Helper loaded: html_helper
INFO - 2020-09-09 10:18:23 --> Helper loaded: url_helper
INFO - 2020-09-09 10:18:23 --> Helper loaded: form_helper
INFO - 2020-09-09 10:18:23 --> Database Driver Class Initialized
INFO - 2020-09-09 10:18:23 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:18:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:18:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:18:24 --> Encryption Class Initialized
INFO - 2020-09-09 10:18:24 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:18:24 --> Controller Class Initialized
INFO - 2020-09-09 10:18:24 --> Helper loaded: language_helper
INFO - 2020-09-09 10:18:24 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:18:24 --> Model "Purchase_Model" initialized
ERROR - 2020-09-09 10:18:24 --> Severity: error --> Exception: Call to a member function result() on string C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\controllers\Purchase.php 54
INFO - 2020-09-09 10:18:27 --> Config Class Initialized
INFO - 2020-09-09 10:18:27 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:18:27 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:18:27 --> Utf8 Class Initialized
INFO - 2020-09-09 10:18:27 --> URI Class Initialized
INFO - 2020-09-09 10:18:27 --> Router Class Initialized
INFO - 2020-09-09 10:18:27 --> Output Class Initialized
INFO - 2020-09-09 10:18:27 --> Security Class Initialized
DEBUG - 2020-09-09 10:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:18:27 --> Input Class Initialized
INFO - 2020-09-09 10:18:27 --> Language Class Initialized
INFO - 2020-09-09 10:18:27 --> Loader Class Initialized
INFO - 2020-09-09 10:18:27 --> Helper loaded: html_helper
INFO - 2020-09-09 10:18:27 --> Helper loaded: url_helper
INFO - 2020-09-09 10:18:27 --> Helper loaded: form_helper
INFO - 2020-09-09 10:18:27 --> Database Driver Class Initialized
INFO - 2020-09-09 10:18:27 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:18:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:18:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:18:27 --> Encryption Class Initialized
INFO - 2020-09-09 10:18:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:18:28 --> Controller Class Initialized
INFO - 2020-09-09 10:18:28 --> Helper loaded: language_helper
INFO - 2020-09-09 10:18:28 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:18:28 --> Model "Purchase_Model" initialized
ERROR - 2020-09-09 10:18:28 --> Severity: error --> Exception: Call to a member function result() on string C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\controllers\Purchase.php 54
INFO - 2020-09-09 10:23:44 --> Config Class Initialized
INFO - 2020-09-09 10:23:45 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:23:45 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:23:45 --> Utf8 Class Initialized
INFO - 2020-09-09 10:23:45 --> URI Class Initialized
INFO - 2020-09-09 10:23:45 --> Router Class Initialized
INFO - 2020-09-09 10:23:45 --> Output Class Initialized
INFO - 2020-09-09 10:23:45 --> Security Class Initialized
DEBUG - 2020-09-09 10:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:23:45 --> Input Class Initialized
INFO - 2020-09-09 10:23:45 --> Language Class Initialized
INFO - 2020-09-09 10:23:45 --> Loader Class Initialized
INFO - 2020-09-09 10:23:45 --> Helper loaded: html_helper
INFO - 2020-09-09 10:23:45 --> Helper loaded: url_helper
INFO - 2020-09-09 10:23:45 --> Helper loaded: form_helper
INFO - 2020-09-09 10:23:45 --> Database Driver Class Initialized
INFO - 2020-09-09 10:23:45 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:23:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:23:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:23:45 --> Encryption Class Initialized
INFO - 2020-09-09 10:23:45 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:23:45 --> Controller Class Initialized
INFO - 2020-09-09 10:23:45 --> Helper loaded: language_helper
INFO - 2020-09-09 10:23:45 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:23:45 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 10:23:45 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 10:23:45 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\purchase.php
INFO - 2020-09-09 10:23:45 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 10:23:45 --> Final output sent to browser
DEBUG - 2020-09-09 10:23:45 --> Total execution time: 0.7090
INFO - 2020-09-09 10:23:51 --> Config Class Initialized
INFO - 2020-09-09 10:23:51 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:23:51 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:23:51 --> Utf8 Class Initialized
INFO - 2020-09-09 10:23:51 --> URI Class Initialized
INFO - 2020-09-09 10:23:51 --> Router Class Initialized
INFO - 2020-09-09 10:23:51 --> Output Class Initialized
INFO - 2020-09-09 10:23:51 --> Security Class Initialized
DEBUG - 2020-09-09 10:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:23:51 --> Input Class Initialized
INFO - 2020-09-09 10:23:51 --> Language Class Initialized
INFO - 2020-09-09 10:23:51 --> Loader Class Initialized
INFO - 2020-09-09 10:23:51 --> Helper loaded: html_helper
INFO - 2020-09-09 10:23:51 --> Helper loaded: url_helper
INFO - 2020-09-09 10:23:51 --> Helper loaded: form_helper
INFO - 2020-09-09 10:23:52 --> Database Driver Class Initialized
INFO - 2020-09-09 10:23:52 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:23:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:23:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:23:52 --> Encryption Class Initialized
INFO - 2020-09-09 10:23:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:23:52 --> Controller Class Initialized
INFO - 2020-09-09 10:23:52 --> Helper loaded: language_helper
INFO - 2020-09-09 10:23:52 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:23:52 --> Model "Purchase_Model" initialized
INFO - 2020-09-09 10:23:52 --> Final output sent to browser
DEBUG - 2020-09-09 10:23:52 --> Total execution time: 0.6352
INFO - 2020-09-09 10:29:11 --> Config Class Initialized
INFO - 2020-09-09 10:29:11 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:29:11 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:29:11 --> Utf8 Class Initialized
INFO - 2020-09-09 10:29:11 --> URI Class Initialized
INFO - 2020-09-09 10:29:11 --> Router Class Initialized
INFO - 2020-09-09 10:29:11 --> Output Class Initialized
INFO - 2020-09-09 10:29:11 --> Security Class Initialized
DEBUG - 2020-09-09 10:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:29:11 --> Input Class Initialized
INFO - 2020-09-09 10:29:11 --> Language Class Initialized
INFO - 2020-09-09 10:29:11 --> Loader Class Initialized
INFO - 2020-09-09 10:29:11 --> Helper loaded: html_helper
INFO - 2020-09-09 10:29:11 --> Helper loaded: url_helper
INFO - 2020-09-09 10:29:11 --> Helper loaded: form_helper
INFO - 2020-09-09 10:29:11 --> Database Driver Class Initialized
INFO - 2020-09-09 10:29:11 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:29:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:29:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:29:11 --> Encryption Class Initialized
INFO - 2020-09-09 10:29:12 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:29:12 --> Controller Class Initialized
INFO - 2020-09-09 10:29:12 --> Helper loaded: language_helper
INFO - 2020-09-09 10:29:12 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:29:12 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 10:29:12 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 10:29:12 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\purchase.php
INFO - 2020-09-09 10:29:12 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 10:29:12 --> Final output sent to browser
DEBUG - 2020-09-09 10:29:12 --> Total execution time: 0.6686
INFO - 2020-09-09 10:29:15 --> Config Class Initialized
INFO - 2020-09-09 10:29:15 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:29:15 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:29:15 --> Utf8 Class Initialized
INFO - 2020-09-09 10:29:15 --> URI Class Initialized
INFO - 2020-09-09 10:29:15 --> Router Class Initialized
INFO - 2020-09-09 10:29:15 --> Output Class Initialized
INFO - 2020-09-09 10:29:15 --> Security Class Initialized
DEBUG - 2020-09-09 10:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:29:15 --> Input Class Initialized
INFO - 2020-09-09 10:29:15 --> Language Class Initialized
INFO - 2020-09-09 10:29:15 --> Loader Class Initialized
INFO - 2020-09-09 10:29:15 --> Helper loaded: html_helper
INFO - 2020-09-09 10:29:15 --> Helper loaded: url_helper
INFO - 2020-09-09 10:29:15 --> Helper loaded: form_helper
INFO - 2020-09-09 10:29:15 --> Database Driver Class Initialized
INFO - 2020-09-09 10:29:15 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:29:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:29:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:29:15 --> Encryption Class Initialized
INFO - 2020-09-09 10:29:15 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:29:15 --> Controller Class Initialized
INFO - 2020-09-09 10:29:15 --> Helper loaded: language_helper
INFO - 2020-09-09 10:29:15 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:29:15 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 10:29:15 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 10:29:15 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\purchase.php
INFO - 2020-09-09 10:29:15 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 10:29:15 --> Final output sent to browser
DEBUG - 2020-09-09 10:29:15 --> Total execution time: 0.7110
INFO - 2020-09-09 10:29:24 --> Config Class Initialized
INFO - 2020-09-09 10:29:24 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:29:24 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:29:24 --> Utf8 Class Initialized
INFO - 2020-09-09 10:29:24 --> URI Class Initialized
INFO - 2020-09-09 10:29:24 --> Router Class Initialized
INFO - 2020-09-09 10:29:24 --> Output Class Initialized
INFO - 2020-09-09 10:29:24 --> Security Class Initialized
DEBUG - 2020-09-09 10:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:29:24 --> Input Class Initialized
INFO - 2020-09-09 10:29:24 --> Language Class Initialized
INFO - 2020-09-09 10:29:24 --> Loader Class Initialized
INFO - 2020-09-09 10:29:24 --> Helper loaded: html_helper
INFO - 2020-09-09 10:29:24 --> Helper loaded: url_helper
INFO - 2020-09-09 10:29:24 --> Helper loaded: form_helper
INFO - 2020-09-09 10:29:24 --> Database Driver Class Initialized
INFO - 2020-09-09 10:29:24 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:29:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:29:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:29:24 --> Encryption Class Initialized
INFO - 2020-09-09 10:29:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:29:25 --> Controller Class Initialized
INFO - 2020-09-09 10:29:25 --> Helper loaded: language_helper
INFO - 2020-09-09 10:29:25 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:29:25 --> Model "Purchase_Model" initialized
INFO - 2020-09-09 10:29:25 --> Final output sent to browser
DEBUG - 2020-09-09 10:29:25 --> Total execution time: 0.8672
INFO - 2020-09-09 10:31:41 --> Config Class Initialized
INFO - 2020-09-09 10:31:41 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:31:41 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:31:41 --> Utf8 Class Initialized
INFO - 2020-09-09 10:31:41 --> URI Class Initialized
INFO - 2020-09-09 10:31:41 --> Router Class Initialized
INFO - 2020-09-09 10:31:41 --> Output Class Initialized
INFO - 2020-09-09 10:31:41 --> Security Class Initialized
DEBUG - 2020-09-09 10:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:31:41 --> Input Class Initialized
INFO - 2020-09-09 10:31:41 --> Language Class Initialized
INFO - 2020-09-09 10:31:41 --> Loader Class Initialized
INFO - 2020-09-09 10:31:41 --> Helper loaded: html_helper
INFO - 2020-09-09 10:31:41 --> Helper loaded: url_helper
INFO - 2020-09-09 10:31:41 --> Helper loaded: form_helper
INFO - 2020-09-09 10:31:41 --> Database Driver Class Initialized
INFO - 2020-09-09 10:31:41 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:31:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:31:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:31:41 --> Encryption Class Initialized
INFO - 2020-09-09 10:31:41 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:31:41 --> Controller Class Initialized
INFO - 2020-09-09 10:31:41 --> Helper loaded: language_helper
INFO - 2020-09-09 10:31:41 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:31:41 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 10:31:42 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 10:31:42 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\purchase.php
INFO - 2020-09-09 10:31:42 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 10:31:42 --> Final output sent to browser
DEBUG - 2020-09-09 10:31:42 --> Total execution time: 0.6859
INFO - 2020-09-09 10:31:45 --> Config Class Initialized
INFO - 2020-09-09 10:31:45 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:31:45 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:31:45 --> Utf8 Class Initialized
INFO - 2020-09-09 10:31:45 --> URI Class Initialized
INFO - 2020-09-09 10:31:45 --> Router Class Initialized
INFO - 2020-09-09 10:31:45 --> Output Class Initialized
INFO - 2020-09-09 10:31:45 --> Security Class Initialized
DEBUG - 2020-09-09 10:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:31:45 --> Input Class Initialized
INFO - 2020-09-09 10:31:45 --> Language Class Initialized
INFO - 2020-09-09 10:31:45 --> Loader Class Initialized
INFO - 2020-09-09 10:31:45 --> Helper loaded: html_helper
INFO - 2020-09-09 10:31:45 --> Helper loaded: url_helper
INFO - 2020-09-09 10:31:46 --> Helper loaded: form_helper
INFO - 2020-09-09 10:31:46 --> Database Driver Class Initialized
INFO - 2020-09-09 10:31:46 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:31:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:31:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:31:46 --> Encryption Class Initialized
INFO - 2020-09-09 10:31:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:31:46 --> Controller Class Initialized
INFO - 2020-09-09 10:31:46 --> Helper loaded: language_helper
INFO - 2020-09-09 10:31:46 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:31:46 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 10:31:46 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 10:31:46 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\purchase.php
INFO - 2020-09-09 10:31:46 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 10:31:46 --> Final output sent to browser
DEBUG - 2020-09-09 10:31:46 --> Total execution time: 0.6244
INFO - 2020-09-09 10:31:54 --> Config Class Initialized
INFO - 2020-09-09 10:31:54 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:31:54 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:31:54 --> Utf8 Class Initialized
INFO - 2020-09-09 10:31:54 --> URI Class Initialized
INFO - 2020-09-09 10:31:54 --> Router Class Initialized
INFO - 2020-09-09 10:31:54 --> Output Class Initialized
INFO - 2020-09-09 10:31:54 --> Security Class Initialized
DEBUG - 2020-09-09 10:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:31:54 --> Input Class Initialized
INFO - 2020-09-09 10:31:54 --> Language Class Initialized
INFO - 2020-09-09 10:31:54 --> Loader Class Initialized
INFO - 2020-09-09 10:31:54 --> Helper loaded: html_helper
INFO - 2020-09-09 10:31:54 --> Helper loaded: url_helper
INFO - 2020-09-09 10:31:54 --> Helper loaded: form_helper
INFO - 2020-09-09 10:31:55 --> Database Driver Class Initialized
INFO - 2020-09-09 10:31:55 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:31:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:31:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:31:55 --> Encryption Class Initialized
INFO - 2020-09-09 10:31:55 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:31:55 --> Controller Class Initialized
INFO - 2020-09-09 10:31:55 --> Helper loaded: language_helper
INFO - 2020-09-09 10:31:55 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:31:55 --> Model "Purchase_Model" initialized
INFO - 2020-09-09 10:31:55 --> Final output sent to browser
DEBUG - 2020-09-09 10:31:55 --> Total execution time: 1.0114
INFO - 2020-09-09 10:32:42 --> Config Class Initialized
INFO - 2020-09-09 10:32:42 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:32:42 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:32:42 --> Utf8 Class Initialized
INFO - 2020-09-09 10:32:42 --> URI Class Initialized
INFO - 2020-09-09 10:32:42 --> Router Class Initialized
INFO - 2020-09-09 10:32:42 --> Output Class Initialized
INFO - 2020-09-09 10:32:42 --> Security Class Initialized
DEBUG - 2020-09-09 10:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:32:42 --> Input Class Initialized
INFO - 2020-09-09 10:32:42 --> Language Class Initialized
INFO - 2020-09-09 10:32:42 --> Loader Class Initialized
INFO - 2020-09-09 10:32:42 --> Helper loaded: html_helper
INFO - 2020-09-09 10:32:42 --> Helper loaded: url_helper
INFO - 2020-09-09 10:32:42 --> Helper loaded: form_helper
INFO - 2020-09-09 10:32:42 --> Database Driver Class Initialized
INFO - 2020-09-09 10:32:42 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:32:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:32:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:32:42 --> Encryption Class Initialized
INFO - 2020-09-09 10:32:42 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:32:42 --> Controller Class Initialized
INFO - 2020-09-09 10:32:42 --> Helper loaded: language_helper
INFO - 2020-09-09 10:32:42 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:32:42 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 10:32:42 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 10:32:42 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\purchase.php
INFO - 2020-09-09 10:32:42 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 10:32:42 --> Final output sent to browser
DEBUG - 2020-09-09 10:32:42 --> Total execution time: 0.6720
INFO - 2020-09-09 10:32:50 --> Config Class Initialized
INFO - 2020-09-09 10:32:50 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:32:50 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:32:50 --> Utf8 Class Initialized
INFO - 2020-09-09 10:32:50 --> URI Class Initialized
INFO - 2020-09-09 10:32:50 --> Router Class Initialized
INFO - 2020-09-09 10:32:50 --> Output Class Initialized
INFO - 2020-09-09 10:32:50 --> Security Class Initialized
DEBUG - 2020-09-09 10:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:32:50 --> Input Class Initialized
INFO - 2020-09-09 10:32:50 --> Language Class Initialized
INFO - 2020-09-09 10:32:50 --> Loader Class Initialized
INFO - 2020-09-09 10:32:50 --> Helper loaded: html_helper
INFO - 2020-09-09 10:32:50 --> Helper loaded: url_helper
INFO - 2020-09-09 10:32:50 --> Helper loaded: form_helper
INFO - 2020-09-09 10:32:50 --> Database Driver Class Initialized
INFO - 2020-09-09 10:32:50 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:32:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:32:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:32:50 --> Encryption Class Initialized
INFO - 2020-09-09 10:32:50 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:32:50 --> Controller Class Initialized
INFO - 2020-09-09 10:32:50 --> Helper loaded: language_helper
INFO - 2020-09-09 10:32:50 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:32:50 --> Model "Purchase_Model" initialized
INFO - 2020-09-09 10:32:51 --> Final output sent to browser
DEBUG - 2020-09-09 10:32:51 --> Total execution time: 0.5747
INFO - 2020-09-09 10:33:28 --> Config Class Initialized
INFO - 2020-09-09 10:33:28 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:33:28 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:33:28 --> Utf8 Class Initialized
INFO - 2020-09-09 10:33:28 --> URI Class Initialized
INFO - 2020-09-09 10:33:28 --> Router Class Initialized
INFO - 2020-09-09 10:33:28 --> Output Class Initialized
INFO - 2020-09-09 10:33:28 --> Security Class Initialized
DEBUG - 2020-09-09 10:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:33:28 --> Input Class Initialized
INFO - 2020-09-09 10:33:28 --> Language Class Initialized
INFO - 2020-09-09 10:33:28 --> Loader Class Initialized
INFO - 2020-09-09 10:33:28 --> Helper loaded: html_helper
INFO - 2020-09-09 10:33:28 --> Helper loaded: url_helper
INFO - 2020-09-09 10:33:28 --> Helper loaded: form_helper
INFO - 2020-09-09 10:33:28 --> Database Driver Class Initialized
INFO - 2020-09-09 10:33:29 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:33:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:33:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:33:29 --> Encryption Class Initialized
INFO - 2020-09-09 10:33:29 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:33:29 --> Controller Class Initialized
INFO - 2020-09-09 10:33:29 --> Helper loaded: language_helper
INFO - 2020-09-09 10:33:29 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:33:29 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 10:33:29 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 10:33:29 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\purchase.php
INFO - 2020-09-09 10:33:29 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 10:33:29 --> Final output sent to browser
DEBUG - 2020-09-09 10:33:29 --> Total execution time: 0.5876
INFO - 2020-09-09 10:33:40 --> Config Class Initialized
INFO - 2020-09-09 10:33:40 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:33:40 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:33:40 --> Utf8 Class Initialized
INFO - 2020-09-09 10:33:40 --> URI Class Initialized
INFO - 2020-09-09 10:33:40 --> Router Class Initialized
INFO - 2020-09-09 10:33:40 --> Output Class Initialized
INFO - 2020-09-09 10:33:40 --> Security Class Initialized
DEBUG - 2020-09-09 10:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:33:40 --> Input Class Initialized
INFO - 2020-09-09 10:33:40 --> Language Class Initialized
INFO - 2020-09-09 10:33:40 --> Loader Class Initialized
INFO - 2020-09-09 10:33:40 --> Helper loaded: html_helper
INFO - 2020-09-09 10:33:40 --> Helper loaded: url_helper
INFO - 2020-09-09 10:33:40 --> Helper loaded: form_helper
INFO - 2020-09-09 10:33:40 --> Database Driver Class Initialized
INFO - 2020-09-09 10:33:40 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:33:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:33:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:33:40 --> Encryption Class Initialized
INFO - 2020-09-09 10:33:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:33:40 --> Controller Class Initialized
INFO - 2020-09-09 10:33:40 --> Helper loaded: language_helper
INFO - 2020-09-09 10:33:40 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:33:40 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 10:33:40 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 10:33:40 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\purchase.php
INFO - 2020-09-09 10:33:40 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 10:33:40 --> Final output sent to browser
DEBUG - 2020-09-09 10:33:40 --> Total execution time: 0.6219
INFO - 2020-09-09 10:33:49 --> Config Class Initialized
INFO - 2020-09-09 10:33:49 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:33:49 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:33:49 --> Utf8 Class Initialized
INFO - 2020-09-09 10:33:49 --> URI Class Initialized
INFO - 2020-09-09 10:33:49 --> Router Class Initialized
INFO - 2020-09-09 10:33:49 --> Output Class Initialized
INFO - 2020-09-09 10:33:49 --> Security Class Initialized
DEBUG - 2020-09-09 10:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:33:49 --> Input Class Initialized
INFO - 2020-09-09 10:33:49 --> Language Class Initialized
INFO - 2020-09-09 10:33:49 --> Loader Class Initialized
INFO - 2020-09-09 10:33:49 --> Helper loaded: html_helper
INFO - 2020-09-09 10:33:49 --> Helper loaded: url_helper
INFO - 2020-09-09 10:33:49 --> Helper loaded: form_helper
INFO - 2020-09-09 10:33:49 --> Database Driver Class Initialized
INFO - 2020-09-09 10:33:49 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:33:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:33:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:33:49 --> Encryption Class Initialized
INFO - 2020-09-09 10:33:49 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:33:49 --> Controller Class Initialized
INFO - 2020-09-09 10:33:49 --> Helper loaded: language_helper
INFO - 2020-09-09 10:33:49 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:33:49 --> Model "Purchase_Model" initialized
INFO - 2020-09-09 10:33:49 --> Final output sent to browser
DEBUG - 2020-09-09 10:33:49 --> Total execution time: 0.6556
INFO - 2020-09-09 10:34:08 --> Config Class Initialized
INFO - 2020-09-09 10:34:08 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:34:08 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:34:08 --> Utf8 Class Initialized
INFO - 2020-09-09 10:34:08 --> URI Class Initialized
INFO - 2020-09-09 10:34:08 --> Router Class Initialized
INFO - 2020-09-09 10:34:08 --> Output Class Initialized
INFO - 2020-09-09 10:34:08 --> Security Class Initialized
DEBUG - 2020-09-09 10:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:34:08 --> Input Class Initialized
INFO - 2020-09-09 10:34:08 --> Language Class Initialized
INFO - 2020-09-09 10:34:08 --> Loader Class Initialized
INFO - 2020-09-09 10:34:08 --> Helper loaded: html_helper
INFO - 2020-09-09 10:34:08 --> Helper loaded: url_helper
INFO - 2020-09-09 10:34:08 --> Helper loaded: form_helper
INFO - 2020-09-09 10:34:08 --> Database Driver Class Initialized
INFO - 2020-09-09 10:34:08 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:34:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:34:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:34:08 --> Encryption Class Initialized
INFO - 2020-09-09 10:34:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:34:08 --> Controller Class Initialized
INFO - 2020-09-09 10:34:08 --> Helper loaded: language_helper
INFO - 2020-09-09 10:34:08 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:34:08 --> Model "Purchase_Model" initialized
INFO - 2020-09-09 10:34:08 --> Final output sent to browser
DEBUG - 2020-09-09 10:34:08 --> Total execution time: 0.5434
INFO - 2020-09-09 10:34:27 --> Config Class Initialized
INFO - 2020-09-09 10:34:27 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:34:27 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:34:27 --> Utf8 Class Initialized
INFO - 2020-09-09 10:34:27 --> URI Class Initialized
INFO - 2020-09-09 10:34:27 --> Router Class Initialized
INFO - 2020-09-09 10:34:27 --> Output Class Initialized
INFO - 2020-09-09 10:34:27 --> Security Class Initialized
DEBUG - 2020-09-09 10:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:34:27 --> Input Class Initialized
INFO - 2020-09-09 10:34:27 --> Language Class Initialized
INFO - 2020-09-09 10:34:27 --> Loader Class Initialized
INFO - 2020-09-09 10:34:27 --> Helper loaded: html_helper
INFO - 2020-09-09 10:34:27 --> Helper loaded: url_helper
INFO - 2020-09-09 10:34:27 --> Helper loaded: form_helper
INFO - 2020-09-09 10:34:27 --> Database Driver Class Initialized
INFO - 2020-09-09 10:34:28 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:34:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:34:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:34:28 --> Encryption Class Initialized
INFO - 2020-09-09 10:34:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:34:28 --> Controller Class Initialized
INFO - 2020-09-09 10:34:28 --> Helper loaded: language_helper
INFO - 2020-09-09 10:34:28 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:34:28 --> Model "Purchase_Model" initialized
ERROR - 2020-09-09 10:34:28 --> Severity: error --> Exception: Call to a member function result() on int C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\controllers\Purchase.php 38
INFO - 2020-09-09 10:34:32 --> Config Class Initialized
INFO - 2020-09-09 10:34:32 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:34:32 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:34:32 --> Utf8 Class Initialized
INFO - 2020-09-09 10:34:32 --> URI Class Initialized
INFO - 2020-09-09 10:34:32 --> Router Class Initialized
INFO - 2020-09-09 10:34:32 --> Output Class Initialized
INFO - 2020-09-09 10:34:32 --> Security Class Initialized
DEBUG - 2020-09-09 10:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:34:33 --> Input Class Initialized
INFO - 2020-09-09 10:34:33 --> Language Class Initialized
INFO - 2020-09-09 10:34:33 --> Loader Class Initialized
INFO - 2020-09-09 10:34:33 --> Helper loaded: html_helper
INFO - 2020-09-09 10:34:33 --> Helper loaded: url_helper
INFO - 2020-09-09 10:34:33 --> Helper loaded: form_helper
INFO - 2020-09-09 10:34:33 --> Database Driver Class Initialized
INFO - 2020-09-09 10:34:33 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:34:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:34:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:34:33 --> Encryption Class Initialized
INFO - 2020-09-09 10:34:33 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:34:33 --> Controller Class Initialized
INFO - 2020-09-09 10:34:33 --> Helper loaded: language_helper
INFO - 2020-09-09 10:34:33 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:34:33 --> Model "Purchase_Model" initialized
ERROR - 2020-09-09 10:34:33 --> Severity: error --> Exception: Call to a member function result() on int C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\controllers\Purchase.php 38
INFO - 2020-09-09 10:37:16 --> Config Class Initialized
INFO - 2020-09-09 10:37:16 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:37:16 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:37:16 --> Utf8 Class Initialized
INFO - 2020-09-09 10:37:16 --> URI Class Initialized
INFO - 2020-09-09 10:37:16 --> Router Class Initialized
INFO - 2020-09-09 10:37:16 --> Output Class Initialized
INFO - 2020-09-09 10:37:16 --> Security Class Initialized
DEBUG - 2020-09-09 10:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:37:16 --> Input Class Initialized
INFO - 2020-09-09 10:37:16 --> Language Class Initialized
INFO - 2020-09-09 10:37:16 --> Loader Class Initialized
INFO - 2020-09-09 10:37:16 --> Helper loaded: html_helper
INFO - 2020-09-09 10:37:16 --> Helper loaded: url_helper
INFO - 2020-09-09 10:37:16 --> Helper loaded: form_helper
INFO - 2020-09-09 10:37:16 --> Database Driver Class Initialized
INFO - 2020-09-09 10:37:16 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:37:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:37:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:37:16 --> Encryption Class Initialized
INFO - 2020-09-09 10:37:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:37:16 --> Controller Class Initialized
INFO - 2020-09-09 10:37:16 --> Helper loaded: language_helper
INFO - 2020-09-09 10:37:16 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:37:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 10:37:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 10:37:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\purchase.php
INFO - 2020-09-09 10:37:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 10:37:16 --> Final output sent to browser
DEBUG - 2020-09-09 10:37:16 --> Total execution time: 0.8558
INFO - 2020-09-09 10:37:43 --> Config Class Initialized
INFO - 2020-09-09 10:37:43 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:37:43 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:37:43 --> Utf8 Class Initialized
INFO - 2020-09-09 10:37:43 --> URI Class Initialized
INFO - 2020-09-09 10:37:43 --> Router Class Initialized
INFO - 2020-09-09 10:37:43 --> Output Class Initialized
INFO - 2020-09-09 10:37:43 --> Security Class Initialized
DEBUG - 2020-09-09 10:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:37:43 --> Input Class Initialized
INFO - 2020-09-09 10:37:43 --> Language Class Initialized
INFO - 2020-09-09 10:37:43 --> Loader Class Initialized
INFO - 2020-09-09 10:37:43 --> Helper loaded: html_helper
INFO - 2020-09-09 10:37:43 --> Helper loaded: url_helper
INFO - 2020-09-09 10:37:43 --> Helper loaded: form_helper
INFO - 2020-09-09 10:37:43 --> Database Driver Class Initialized
INFO - 2020-09-09 10:37:43 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:37:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:37:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:37:43 --> Encryption Class Initialized
INFO - 2020-09-09 10:37:43 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:37:43 --> Controller Class Initialized
INFO - 2020-09-09 10:37:43 --> Helper loaded: language_helper
INFO - 2020-09-09 10:37:43 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:37:44 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 10:37:44 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 10:37:44 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\purchase.php
INFO - 2020-09-09 10:37:44 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 10:37:44 --> Final output sent to browser
DEBUG - 2020-09-09 10:37:44 --> Total execution time: 0.7422
INFO - 2020-09-09 10:37:50 --> Config Class Initialized
INFO - 2020-09-09 10:37:50 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:37:50 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:37:50 --> Utf8 Class Initialized
INFO - 2020-09-09 10:37:50 --> URI Class Initialized
INFO - 2020-09-09 10:37:50 --> Router Class Initialized
INFO - 2020-09-09 10:37:50 --> Output Class Initialized
INFO - 2020-09-09 10:37:50 --> Security Class Initialized
DEBUG - 2020-09-09 10:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:37:50 --> Input Class Initialized
INFO - 2020-09-09 10:37:50 --> Language Class Initialized
INFO - 2020-09-09 10:37:50 --> Loader Class Initialized
INFO - 2020-09-09 10:37:50 --> Helper loaded: html_helper
INFO - 2020-09-09 10:37:51 --> Helper loaded: url_helper
INFO - 2020-09-09 10:37:51 --> Helper loaded: form_helper
INFO - 2020-09-09 10:37:51 --> Database Driver Class Initialized
INFO - 2020-09-09 10:37:51 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:37:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:37:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:37:51 --> Encryption Class Initialized
INFO - 2020-09-09 10:37:51 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:37:51 --> Controller Class Initialized
INFO - 2020-09-09 10:37:51 --> Helper loaded: language_helper
INFO - 2020-09-09 10:37:51 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:37:51 --> Model "Purchase_Model" initialized
INFO - 2020-09-09 10:37:51 --> Final output sent to browser
DEBUG - 2020-09-09 10:37:51 --> Total execution time: 0.5453
INFO - 2020-09-09 10:38:04 --> Config Class Initialized
INFO - 2020-09-09 10:38:05 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:38:05 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:38:05 --> Utf8 Class Initialized
INFO - 2020-09-09 10:38:05 --> URI Class Initialized
INFO - 2020-09-09 10:38:05 --> Router Class Initialized
INFO - 2020-09-09 10:38:05 --> Output Class Initialized
INFO - 2020-09-09 10:38:05 --> Security Class Initialized
DEBUG - 2020-09-09 10:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:38:05 --> Input Class Initialized
INFO - 2020-09-09 10:38:05 --> Language Class Initialized
INFO - 2020-09-09 10:38:05 --> Loader Class Initialized
INFO - 2020-09-09 10:38:05 --> Helper loaded: html_helper
INFO - 2020-09-09 10:38:05 --> Helper loaded: url_helper
INFO - 2020-09-09 10:38:05 --> Helper loaded: form_helper
INFO - 2020-09-09 10:38:05 --> Database Driver Class Initialized
INFO - 2020-09-09 10:38:05 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:38:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:38:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:38:05 --> Encryption Class Initialized
INFO - 2020-09-09 10:38:05 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:38:05 --> Controller Class Initialized
INFO - 2020-09-09 10:38:05 --> Helper loaded: language_helper
INFO - 2020-09-09 10:38:05 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:38:05 --> Model "Purchase_Model" initialized
INFO - 2020-09-09 10:38:05 --> Final output sent to browser
DEBUG - 2020-09-09 10:38:05 --> Total execution time: 0.6719
INFO - 2020-09-09 10:38:22 --> Config Class Initialized
INFO - 2020-09-09 10:38:22 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:38:22 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:38:22 --> Utf8 Class Initialized
INFO - 2020-09-09 10:38:22 --> URI Class Initialized
INFO - 2020-09-09 10:38:22 --> Router Class Initialized
INFO - 2020-09-09 10:38:22 --> Output Class Initialized
INFO - 2020-09-09 10:38:22 --> Security Class Initialized
DEBUG - 2020-09-09 10:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:38:22 --> Input Class Initialized
INFO - 2020-09-09 10:38:22 --> Language Class Initialized
INFO - 2020-09-09 10:38:22 --> Loader Class Initialized
INFO - 2020-09-09 10:38:22 --> Helper loaded: html_helper
INFO - 2020-09-09 10:38:22 --> Helper loaded: url_helper
INFO - 2020-09-09 10:38:22 --> Helper loaded: form_helper
INFO - 2020-09-09 10:38:22 --> Database Driver Class Initialized
INFO - 2020-09-09 10:38:22 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:38:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:38:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:38:22 --> Encryption Class Initialized
INFO - 2020-09-09 10:38:22 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:38:22 --> Controller Class Initialized
INFO - 2020-09-09 10:38:22 --> Helper loaded: language_helper
INFO - 2020-09-09 10:38:22 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:38:22 --> Model "Purchase_Model" initialized
INFO - 2020-09-09 10:38:22 --> Final output sent to browser
DEBUG - 2020-09-09 10:38:22 --> Total execution time: 0.8177
INFO - 2020-09-09 10:47:17 --> Config Class Initialized
INFO - 2020-09-09 10:47:17 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:47:17 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:47:17 --> Utf8 Class Initialized
INFO - 2020-09-09 10:47:17 --> URI Class Initialized
INFO - 2020-09-09 10:47:17 --> Router Class Initialized
INFO - 2020-09-09 10:47:17 --> Output Class Initialized
INFO - 2020-09-09 10:47:17 --> Security Class Initialized
DEBUG - 2020-09-09 10:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:47:17 --> Input Class Initialized
INFO - 2020-09-09 10:47:17 --> Language Class Initialized
INFO - 2020-09-09 10:47:17 --> Loader Class Initialized
INFO - 2020-09-09 10:47:17 --> Helper loaded: html_helper
INFO - 2020-09-09 10:47:17 --> Helper loaded: url_helper
INFO - 2020-09-09 10:47:17 --> Helper loaded: form_helper
INFO - 2020-09-09 10:47:17 --> Database Driver Class Initialized
INFO - 2020-09-09 10:47:17 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:47:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:47:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:47:17 --> Encryption Class Initialized
INFO - 2020-09-09 10:47:17 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:47:17 --> Controller Class Initialized
INFO - 2020-09-09 10:47:17 --> Helper loaded: language_helper
INFO - 2020-09-09 10:47:17 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:47:18 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 10:47:18 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 10:47:18 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment.php
INFO - 2020-09-09 10:47:18 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 10:47:18 --> Final output sent to browser
DEBUG - 2020-09-09 10:47:18 --> Total execution time: 1.0620
INFO - 2020-09-09 10:47:36 --> Config Class Initialized
INFO - 2020-09-09 10:47:36 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:47:36 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:47:36 --> Utf8 Class Initialized
INFO - 2020-09-09 10:47:36 --> URI Class Initialized
INFO - 2020-09-09 10:47:36 --> Router Class Initialized
INFO - 2020-09-09 10:47:36 --> Output Class Initialized
INFO - 2020-09-09 10:47:36 --> Security Class Initialized
DEBUG - 2020-09-09 10:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:47:36 --> Input Class Initialized
INFO - 2020-09-09 10:47:36 --> Language Class Initialized
INFO - 2020-09-09 10:47:36 --> Loader Class Initialized
INFO - 2020-09-09 10:47:36 --> Helper loaded: html_helper
INFO - 2020-09-09 10:47:36 --> Helper loaded: url_helper
INFO - 2020-09-09 10:47:36 --> Helper loaded: form_helper
INFO - 2020-09-09 10:47:36 --> Database Driver Class Initialized
INFO - 2020-09-09 10:47:36 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:47:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:47:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:47:37 --> Encryption Class Initialized
INFO - 2020-09-09 10:47:37 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:47:37 --> Controller Class Initialized
INFO - 2020-09-09 10:47:37 --> Helper loaded: language_helper
INFO - 2020-09-09 10:47:37 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:47:39 --> Final output sent to browser
DEBUG - 2020-09-09 10:47:39 --> Total execution time: 3.1786
INFO - 2020-09-09 10:47:59 --> Config Class Initialized
INFO - 2020-09-09 10:47:59 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:47:59 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:47:59 --> Utf8 Class Initialized
INFO - 2020-09-09 10:47:59 --> URI Class Initialized
INFO - 2020-09-09 10:47:59 --> Router Class Initialized
INFO - 2020-09-09 10:47:59 --> Output Class Initialized
INFO - 2020-09-09 10:47:59 --> Security Class Initialized
DEBUG - 2020-09-09 10:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:47:59 --> Input Class Initialized
INFO - 2020-09-09 10:47:59 --> Language Class Initialized
INFO - 2020-09-09 10:47:59 --> Loader Class Initialized
INFO - 2020-09-09 10:47:59 --> Helper loaded: html_helper
INFO - 2020-09-09 10:47:59 --> Helper loaded: url_helper
INFO - 2020-09-09 10:47:59 --> Helper loaded: form_helper
INFO - 2020-09-09 10:48:00 --> Database Driver Class Initialized
INFO - 2020-09-09 10:48:00 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:48:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:48:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:48:00 --> Encryption Class Initialized
INFO - 2020-09-09 10:48:00 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:48:00 --> Controller Class Initialized
INFO - 2020-09-09 10:48:00 --> Helper loaded: language_helper
INFO - 2020-09-09 10:48:00 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:48:01 --> Final output sent to browser
DEBUG - 2020-09-09 10:48:01 --> Total execution time: 1.7658
INFO - 2020-09-09 10:48:10 --> Config Class Initialized
INFO - 2020-09-09 10:48:10 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:48:10 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:48:10 --> Utf8 Class Initialized
INFO - 2020-09-09 10:48:10 --> URI Class Initialized
INFO - 2020-09-09 10:48:10 --> Router Class Initialized
INFO - 2020-09-09 10:48:10 --> Output Class Initialized
INFO - 2020-09-09 10:48:10 --> Security Class Initialized
DEBUG - 2020-09-09 10:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:48:10 --> Input Class Initialized
INFO - 2020-09-09 10:48:10 --> Language Class Initialized
INFO - 2020-09-09 10:48:10 --> Loader Class Initialized
INFO - 2020-09-09 10:48:10 --> Helper loaded: html_helper
INFO - 2020-09-09 10:48:10 --> Helper loaded: url_helper
INFO - 2020-09-09 10:48:10 --> Helper loaded: form_helper
INFO - 2020-09-09 10:48:10 --> Database Driver Class Initialized
INFO - 2020-09-09 10:48:10 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:48:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:48:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:48:11 --> Encryption Class Initialized
INFO - 2020-09-09 10:48:11 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:48:11 --> Controller Class Initialized
INFO - 2020-09-09 10:48:11 --> Helper loaded: language_helper
INFO - 2020-09-09 10:48:11 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:48:11 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 10:48:11 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 10:48:11 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment.php
INFO - 2020-09-09 10:48:11 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 10:48:11 --> Final output sent to browser
DEBUG - 2020-09-09 10:48:11 --> Total execution time: 0.5916
INFO - 2020-09-09 10:48:34 --> Config Class Initialized
INFO - 2020-09-09 10:48:34 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:48:35 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:48:35 --> Utf8 Class Initialized
INFO - 2020-09-09 10:48:35 --> URI Class Initialized
INFO - 2020-09-09 10:48:35 --> Router Class Initialized
INFO - 2020-09-09 10:48:35 --> Output Class Initialized
INFO - 2020-09-09 10:48:35 --> Security Class Initialized
DEBUG - 2020-09-09 10:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:48:35 --> Input Class Initialized
INFO - 2020-09-09 10:48:35 --> Language Class Initialized
INFO - 2020-09-09 10:48:35 --> Loader Class Initialized
INFO - 2020-09-09 10:48:35 --> Helper loaded: html_helper
INFO - 2020-09-09 10:48:35 --> Helper loaded: url_helper
INFO - 2020-09-09 10:48:35 --> Helper loaded: form_helper
INFO - 2020-09-09 10:48:35 --> Database Driver Class Initialized
INFO - 2020-09-09 10:48:35 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:48:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:48:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:48:35 --> Encryption Class Initialized
INFO - 2020-09-09 10:48:36 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:48:36 --> Controller Class Initialized
INFO - 2020-09-09 10:48:36 --> Helper loaded: language_helper
INFO - 2020-09-09 10:48:36 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:48:36 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 10:48:36 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 10:48:36 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment.php
INFO - 2020-09-09 10:48:36 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 10:48:36 --> Final output sent to browser
DEBUG - 2020-09-09 10:48:36 --> Total execution time: 1.7168
INFO - 2020-09-09 10:48:45 --> Config Class Initialized
INFO - 2020-09-09 10:48:45 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:48:45 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:48:45 --> Utf8 Class Initialized
INFO - 2020-09-09 10:48:45 --> URI Class Initialized
INFO - 2020-09-09 10:48:45 --> Router Class Initialized
INFO - 2020-09-09 10:48:45 --> Output Class Initialized
INFO - 2020-09-09 10:48:45 --> Security Class Initialized
DEBUG - 2020-09-09 10:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:48:45 --> Input Class Initialized
INFO - 2020-09-09 10:48:45 --> Language Class Initialized
INFO - 2020-09-09 10:48:45 --> Loader Class Initialized
INFO - 2020-09-09 10:48:45 --> Helper loaded: html_helper
INFO - 2020-09-09 10:48:45 --> Helper loaded: url_helper
INFO - 2020-09-09 10:48:45 --> Helper loaded: form_helper
INFO - 2020-09-09 10:48:45 --> Database Driver Class Initialized
INFO - 2020-09-09 10:48:45 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:48:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:48:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:48:46 --> Encryption Class Initialized
INFO - 2020-09-09 10:48:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:48:46 --> Controller Class Initialized
INFO - 2020-09-09 10:48:46 --> Helper loaded: language_helper
INFO - 2020-09-09 10:48:46 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:48:48 --> Final output sent to browser
DEBUG - 2020-09-09 10:48:48 --> Total execution time: 3.1779
INFO - 2020-09-09 10:50:49 --> Config Class Initialized
INFO - 2020-09-09 10:50:50 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:50:50 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:50:50 --> Utf8 Class Initialized
INFO - 2020-09-09 10:50:50 --> URI Class Initialized
INFO - 2020-09-09 10:50:50 --> Router Class Initialized
INFO - 2020-09-09 10:50:50 --> Output Class Initialized
INFO - 2020-09-09 10:50:50 --> Security Class Initialized
DEBUG - 2020-09-09 10:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:50:50 --> Input Class Initialized
INFO - 2020-09-09 10:50:50 --> Language Class Initialized
INFO - 2020-09-09 10:50:50 --> Loader Class Initialized
INFO - 2020-09-09 10:50:50 --> Helper loaded: html_helper
INFO - 2020-09-09 10:50:50 --> Helper loaded: url_helper
INFO - 2020-09-09 10:50:50 --> Helper loaded: form_helper
INFO - 2020-09-09 10:50:50 --> Database Driver Class Initialized
INFO - 2020-09-09 10:50:50 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:50:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:50:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:50:50 --> Encryption Class Initialized
INFO - 2020-09-09 10:50:50 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:50:50 --> Controller Class Initialized
INFO - 2020-09-09 10:50:50 --> Helper loaded: language_helper
INFO - 2020-09-09 10:50:50 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:50:50 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 10:50:50 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 10:50:50 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment.php
INFO - 2020-09-09 10:50:50 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 10:50:50 --> Final output sent to browser
DEBUG - 2020-09-09 10:50:50 --> Total execution time: 0.6528
INFO - 2020-09-09 10:50:58 --> Config Class Initialized
INFO - 2020-09-09 10:50:58 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:50:58 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:50:58 --> Utf8 Class Initialized
INFO - 2020-09-09 10:50:58 --> URI Class Initialized
INFO - 2020-09-09 10:50:58 --> Router Class Initialized
INFO - 2020-09-09 10:50:58 --> Output Class Initialized
INFO - 2020-09-09 10:50:58 --> Security Class Initialized
DEBUG - 2020-09-09 10:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:50:58 --> Input Class Initialized
INFO - 2020-09-09 10:50:58 --> Language Class Initialized
INFO - 2020-09-09 10:50:58 --> Loader Class Initialized
INFO - 2020-09-09 10:50:58 --> Helper loaded: html_helper
INFO - 2020-09-09 10:50:58 --> Helper loaded: url_helper
INFO - 2020-09-09 10:50:58 --> Helper loaded: form_helper
INFO - 2020-09-09 10:50:58 --> Database Driver Class Initialized
INFO - 2020-09-09 10:50:58 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:50:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:50:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:50:58 --> Encryption Class Initialized
INFO - 2020-09-09 10:50:58 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:50:58 --> Controller Class Initialized
INFO - 2020-09-09 10:50:58 --> Helper loaded: language_helper
INFO - 2020-09-09 10:50:58 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:50:58 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 10:50:58 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 10:50:58 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\purchase.php
INFO - 2020-09-09 10:50:58 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 10:50:58 --> Final output sent to browser
DEBUG - 2020-09-09 10:50:58 --> Total execution time: 0.6539
INFO - 2020-09-09 10:51:00 --> Config Class Initialized
INFO - 2020-09-09 10:51:00 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:51:00 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:51:00 --> Utf8 Class Initialized
INFO - 2020-09-09 10:51:00 --> URI Class Initialized
INFO - 2020-09-09 10:51:00 --> Router Class Initialized
INFO - 2020-09-09 10:51:00 --> Output Class Initialized
INFO - 2020-09-09 10:51:00 --> Security Class Initialized
DEBUG - 2020-09-09 10:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:51:00 --> Input Class Initialized
INFO - 2020-09-09 10:51:00 --> Language Class Initialized
INFO - 2020-09-09 10:51:00 --> Loader Class Initialized
INFO - 2020-09-09 10:51:00 --> Helper loaded: html_helper
INFO - 2020-09-09 10:51:00 --> Helper loaded: url_helper
INFO - 2020-09-09 10:51:00 --> Helper loaded: form_helper
INFO - 2020-09-09 10:51:00 --> Database Driver Class Initialized
INFO - 2020-09-09 10:51:00 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:51:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:51:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:51:00 --> Encryption Class Initialized
INFO - 2020-09-09 10:51:01 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:51:01 --> Controller Class Initialized
INFO - 2020-09-09 10:51:01 --> Helper loaded: language_helper
INFO - 2020-09-09 10:51:01 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:51:01 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 10:51:01 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 10:51:01 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\purchase.php
INFO - 2020-09-09 10:51:01 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 10:51:01 --> Final output sent to browser
DEBUG - 2020-09-09 10:51:01 --> Total execution time: 0.5728
INFO - 2020-09-09 10:51:08 --> Config Class Initialized
INFO - 2020-09-09 10:51:08 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:51:08 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:51:08 --> Utf8 Class Initialized
INFO - 2020-09-09 10:51:08 --> URI Class Initialized
INFO - 2020-09-09 10:51:08 --> Router Class Initialized
INFO - 2020-09-09 10:51:08 --> Output Class Initialized
INFO - 2020-09-09 10:51:08 --> Security Class Initialized
DEBUG - 2020-09-09 10:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:51:08 --> Input Class Initialized
INFO - 2020-09-09 10:51:08 --> Language Class Initialized
INFO - 2020-09-09 10:51:08 --> Loader Class Initialized
INFO - 2020-09-09 10:51:08 --> Helper loaded: html_helper
INFO - 2020-09-09 10:51:08 --> Helper loaded: url_helper
INFO - 2020-09-09 10:51:09 --> Helper loaded: form_helper
INFO - 2020-09-09 10:51:09 --> Database Driver Class Initialized
INFO - 2020-09-09 10:51:09 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:51:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:51:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:51:09 --> Encryption Class Initialized
INFO - 2020-09-09 10:51:09 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:51:09 --> Controller Class Initialized
INFO - 2020-09-09 10:51:09 --> Helper loaded: language_helper
INFO - 2020-09-09 10:51:09 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:51:09 --> Model "Purchase_Model" initialized
INFO - 2020-09-09 10:51:09 --> Final output sent to browser
DEBUG - 2020-09-09 10:51:09 --> Total execution time: 0.5335
INFO - 2020-09-09 10:51:16 --> Config Class Initialized
INFO - 2020-09-09 10:51:16 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:51:16 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:51:16 --> Utf8 Class Initialized
INFO - 2020-09-09 10:51:16 --> URI Class Initialized
INFO - 2020-09-09 10:51:16 --> Router Class Initialized
INFO - 2020-09-09 10:51:16 --> Output Class Initialized
INFO - 2020-09-09 10:51:16 --> Security Class Initialized
DEBUG - 2020-09-09 10:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:51:16 --> Input Class Initialized
INFO - 2020-09-09 10:51:16 --> Language Class Initialized
INFO - 2020-09-09 10:51:16 --> Loader Class Initialized
INFO - 2020-09-09 10:51:16 --> Helper loaded: html_helper
INFO - 2020-09-09 10:51:16 --> Helper loaded: url_helper
INFO - 2020-09-09 10:51:16 --> Helper loaded: form_helper
INFO - 2020-09-09 10:51:16 --> Database Driver Class Initialized
INFO - 2020-09-09 10:51:16 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:51:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:51:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:51:16 --> Encryption Class Initialized
INFO - 2020-09-09 10:51:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:51:16 --> Controller Class Initialized
INFO - 2020-09-09 10:51:16 --> Helper loaded: language_helper
INFO - 2020-09-09 10:51:16 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:51:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 10:51:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 10:51:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment.php
INFO - 2020-09-09 10:51:16 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 10:51:16 --> Final output sent to browser
DEBUG - 2020-09-09 10:51:16 --> Total execution time: 0.7444
INFO - 2020-09-09 10:51:28 --> Config Class Initialized
INFO - 2020-09-09 10:51:28 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:51:28 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:51:28 --> Utf8 Class Initialized
INFO - 2020-09-09 10:51:28 --> URI Class Initialized
INFO - 2020-09-09 10:51:28 --> Router Class Initialized
INFO - 2020-09-09 10:51:28 --> Output Class Initialized
INFO - 2020-09-09 10:51:28 --> Security Class Initialized
DEBUG - 2020-09-09 10:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:51:28 --> Input Class Initialized
INFO - 2020-09-09 10:51:28 --> Language Class Initialized
INFO - 2020-09-09 10:51:28 --> Loader Class Initialized
INFO - 2020-09-09 10:51:28 --> Helper loaded: html_helper
INFO - 2020-09-09 10:51:28 --> Helper loaded: url_helper
INFO - 2020-09-09 10:51:28 --> Helper loaded: form_helper
INFO - 2020-09-09 10:51:28 --> Database Driver Class Initialized
INFO - 2020-09-09 10:51:28 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:51:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:51:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:51:28 --> Encryption Class Initialized
INFO - 2020-09-09 10:51:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:51:28 --> Controller Class Initialized
INFO - 2020-09-09 10:51:28 --> Helper loaded: language_helper
INFO - 2020-09-09 10:51:28 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:51:30 --> Final output sent to browser
DEBUG - 2020-09-09 10:51:30 --> Total execution time: 1.7918
INFO - 2020-09-09 10:55:07 --> Config Class Initialized
INFO - 2020-09-09 10:55:07 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:55:07 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:55:07 --> Utf8 Class Initialized
INFO - 2020-09-09 10:55:07 --> URI Class Initialized
INFO - 2020-09-09 10:55:07 --> Router Class Initialized
INFO - 2020-09-09 10:55:07 --> Output Class Initialized
INFO - 2020-09-09 10:55:07 --> Security Class Initialized
DEBUG - 2020-09-09 10:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:55:07 --> Input Class Initialized
INFO - 2020-09-09 10:55:07 --> Language Class Initialized
INFO - 2020-09-09 10:55:07 --> Loader Class Initialized
INFO - 2020-09-09 10:55:07 --> Helper loaded: html_helper
INFO - 2020-09-09 10:55:07 --> Helper loaded: url_helper
INFO - 2020-09-09 10:55:07 --> Helper loaded: form_helper
INFO - 2020-09-09 10:55:07 --> Database Driver Class Initialized
INFO - 2020-09-09 10:55:07 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:55:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:55:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:55:07 --> Encryption Class Initialized
INFO - 2020-09-09 10:55:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:55:08 --> Controller Class Initialized
INFO - 2020-09-09 10:55:08 --> Helper loaded: language_helper
INFO - 2020-09-09 10:55:08 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:55:08 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 10:55:08 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 10:55:08 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\purchase.php
INFO - 2020-09-09 10:55:08 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 10:55:08 --> Final output sent to browser
DEBUG - 2020-09-09 10:55:08 --> Total execution time: 0.9481
INFO - 2020-09-09 10:55:11 --> Config Class Initialized
INFO - 2020-09-09 10:55:11 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:55:11 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:55:11 --> Utf8 Class Initialized
INFO - 2020-09-09 10:55:11 --> URI Class Initialized
INFO - 2020-09-09 10:55:11 --> Router Class Initialized
INFO - 2020-09-09 10:55:11 --> Output Class Initialized
INFO - 2020-09-09 10:55:11 --> Security Class Initialized
DEBUG - 2020-09-09 10:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:55:11 --> Input Class Initialized
INFO - 2020-09-09 10:55:11 --> Language Class Initialized
INFO - 2020-09-09 10:55:11 --> Loader Class Initialized
INFO - 2020-09-09 10:55:11 --> Helper loaded: html_helper
INFO - 2020-09-09 10:55:11 --> Helper loaded: url_helper
INFO - 2020-09-09 10:55:11 --> Helper loaded: form_helper
INFO - 2020-09-09 10:55:11 --> Database Driver Class Initialized
INFO - 2020-09-09 10:55:11 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:55:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:55:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:55:11 --> Encryption Class Initialized
INFO - 2020-09-09 10:55:11 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:55:11 --> Controller Class Initialized
INFO - 2020-09-09 10:55:11 --> Helper loaded: language_helper
INFO - 2020-09-09 10:55:11 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:55:11 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 10:55:11 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 10:55:11 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\purchase.php
INFO - 2020-09-09 10:55:11 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 10:55:11 --> Final output sent to browser
DEBUG - 2020-09-09 10:55:11 --> Total execution time: 0.7147
INFO - 2020-09-09 10:55:19 --> Config Class Initialized
INFO - 2020-09-09 10:55:19 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:55:19 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:55:19 --> Utf8 Class Initialized
INFO - 2020-09-09 10:55:19 --> URI Class Initialized
INFO - 2020-09-09 10:55:19 --> Router Class Initialized
INFO - 2020-09-09 10:55:19 --> Output Class Initialized
INFO - 2020-09-09 10:55:19 --> Security Class Initialized
DEBUG - 2020-09-09 10:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:55:19 --> Input Class Initialized
INFO - 2020-09-09 10:55:19 --> Language Class Initialized
INFO - 2020-09-09 10:55:19 --> Loader Class Initialized
INFO - 2020-09-09 10:55:19 --> Helper loaded: html_helper
INFO - 2020-09-09 10:55:19 --> Helper loaded: url_helper
INFO - 2020-09-09 10:55:19 --> Helper loaded: form_helper
INFO - 2020-09-09 10:55:19 --> Database Driver Class Initialized
INFO - 2020-09-09 10:55:19 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:55:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:55:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:55:19 --> Encryption Class Initialized
INFO - 2020-09-09 10:55:19 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:55:19 --> Controller Class Initialized
INFO - 2020-09-09 10:55:19 --> Helper loaded: language_helper
INFO - 2020-09-09 10:55:19 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:55:19 --> Model "Purchase_Model" initialized
INFO - 2020-09-09 10:55:20 --> Final output sent to browser
DEBUG - 2020-09-09 10:55:20 --> Total execution time: 0.5988
INFO - 2020-09-09 10:55:25 --> Config Class Initialized
INFO - 2020-09-09 10:55:25 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:55:25 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:55:25 --> Utf8 Class Initialized
INFO - 2020-09-09 10:55:25 --> URI Class Initialized
INFO - 2020-09-09 10:55:25 --> Router Class Initialized
INFO - 2020-09-09 10:55:25 --> Output Class Initialized
INFO - 2020-09-09 10:55:25 --> Security Class Initialized
DEBUG - 2020-09-09 10:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:55:25 --> Input Class Initialized
INFO - 2020-09-09 10:55:25 --> Language Class Initialized
INFO - 2020-09-09 10:55:25 --> Loader Class Initialized
INFO - 2020-09-09 10:55:25 --> Helper loaded: html_helper
INFO - 2020-09-09 10:55:25 --> Helper loaded: url_helper
INFO - 2020-09-09 10:55:25 --> Helper loaded: form_helper
INFO - 2020-09-09 10:55:25 --> Database Driver Class Initialized
INFO - 2020-09-09 10:55:25 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:55:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:55:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:55:25 --> Encryption Class Initialized
INFO - 2020-09-09 10:55:25 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:55:25 --> Controller Class Initialized
INFO - 2020-09-09 10:55:25 --> Helper loaded: language_helper
INFO - 2020-09-09 10:55:25 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:55:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 10:55:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 10:55:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment.php
INFO - 2020-09-09 10:55:25 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 10:55:25 --> Final output sent to browser
DEBUG - 2020-09-09 10:55:25 --> Total execution time: 0.6804
INFO - 2020-09-09 10:55:48 --> Config Class Initialized
INFO - 2020-09-09 10:55:48 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:55:48 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:55:48 --> Utf8 Class Initialized
INFO - 2020-09-09 10:55:48 --> URI Class Initialized
INFO - 2020-09-09 10:55:48 --> Router Class Initialized
INFO - 2020-09-09 10:55:48 --> Output Class Initialized
INFO - 2020-09-09 10:55:48 --> Security Class Initialized
DEBUG - 2020-09-09 10:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:55:48 --> Input Class Initialized
INFO - 2020-09-09 10:55:48 --> Language Class Initialized
INFO - 2020-09-09 10:55:49 --> Loader Class Initialized
INFO - 2020-09-09 10:55:49 --> Helper loaded: html_helper
INFO - 2020-09-09 10:55:49 --> Helper loaded: url_helper
INFO - 2020-09-09 10:55:49 --> Helper loaded: form_helper
INFO - 2020-09-09 10:55:49 --> Database Driver Class Initialized
INFO - 2020-09-09 10:55:49 --> Form Validation Class Initialized
DEBUG - 2020-09-09 10:55:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 10:55:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 10:55:49 --> Encryption Class Initialized
INFO - 2020-09-09 10:55:49 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 10:55:49 --> Controller Class Initialized
INFO - 2020-09-09 10:55:49 --> Helper loaded: language_helper
INFO - 2020-09-09 10:55:49 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 10:55:51 --> Final output sent to browser
DEBUG - 2020-09-09 10:55:51 --> Total execution time: 2.3385
INFO - 2020-09-09 11:08:51 --> Config Class Initialized
INFO - 2020-09-09 11:08:51 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:08:51 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:08:52 --> Utf8 Class Initialized
INFO - 2020-09-09 11:08:52 --> URI Class Initialized
INFO - 2020-09-09 11:08:52 --> Router Class Initialized
INFO - 2020-09-09 11:08:52 --> Output Class Initialized
INFO - 2020-09-09 11:08:52 --> Security Class Initialized
DEBUG - 2020-09-09 11:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:08:52 --> Input Class Initialized
INFO - 2020-09-09 11:08:52 --> Language Class Initialized
INFO - 2020-09-09 11:08:52 --> Loader Class Initialized
INFO - 2020-09-09 11:08:52 --> Helper loaded: html_helper
INFO - 2020-09-09 11:08:52 --> Helper loaded: url_helper
INFO - 2020-09-09 11:08:52 --> Helper loaded: form_helper
INFO - 2020-09-09 11:08:52 --> Database Driver Class Initialized
INFO - 2020-09-09 11:08:52 --> Form Validation Class Initialized
DEBUG - 2020-09-09 11:08:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 11:08:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 11:08:52 --> Encryption Class Initialized
INFO - 2020-09-09 11:08:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 11:08:52 --> Controller Class Initialized
INFO - 2020-09-09 11:08:52 --> Helper loaded: language_helper
INFO - 2020-09-09 11:08:52 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 11:08:52 --> Final output sent to browser
DEBUG - 2020-09-09 11:08:52 --> Total execution time: 0.8577
INFO - 2020-09-09 11:08:53 --> Config Class Initialized
INFO - 2020-09-09 11:08:53 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:08:53 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:08:53 --> Utf8 Class Initialized
INFO - 2020-09-09 11:08:53 --> URI Class Initialized
DEBUG - 2020-09-09 11:08:53 --> No URI present. Default controller set.
INFO - 2020-09-09 11:08:53 --> Router Class Initialized
INFO - 2020-09-09 11:08:53 --> Output Class Initialized
INFO - 2020-09-09 11:08:53 --> Security Class Initialized
DEBUG - 2020-09-09 11:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:08:53 --> Input Class Initialized
INFO - 2020-09-09 11:08:53 --> Language Class Initialized
INFO - 2020-09-09 11:08:53 --> Loader Class Initialized
INFO - 2020-09-09 11:08:53 --> Helper loaded: html_helper
INFO - 2020-09-09 11:08:53 --> Helper loaded: url_helper
INFO - 2020-09-09 11:08:53 --> Helper loaded: form_helper
INFO - 2020-09-09 11:08:53 --> Database Driver Class Initialized
INFO - 2020-09-09 11:08:53 --> Form Validation Class Initialized
DEBUG - 2020-09-09 11:08:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 11:08:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 11:08:53 --> Encryption Class Initialized
INFO - 2020-09-09 11:08:53 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 11:08:53 --> Controller Class Initialized
INFO - 2020-09-09 11:08:53 --> Helper loaded: language_helper
INFO - 2020-09-09 11:08:53 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 11:08:53 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-09 11:08:53 --> Final output sent to browser
DEBUG - 2020-09-09 11:08:53 --> Total execution time: 0.6396
INFO - 2020-09-09 11:37:07 --> Config Class Initialized
INFO - 2020-09-09 11:37:07 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:37:07 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:37:07 --> Utf8 Class Initialized
INFO - 2020-09-09 11:37:07 --> URI Class Initialized
INFO - 2020-09-09 11:37:07 --> Router Class Initialized
INFO - 2020-09-09 11:37:07 --> Output Class Initialized
INFO - 2020-09-09 11:37:07 --> Security Class Initialized
DEBUG - 2020-09-09 11:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:37:07 --> Input Class Initialized
INFO - 2020-09-09 11:37:07 --> Language Class Initialized
INFO - 2020-09-09 11:37:07 --> Loader Class Initialized
INFO - 2020-09-09 11:37:07 --> Helper loaded: html_helper
INFO - 2020-09-09 11:37:07 --> Helper loaded: url_helper
INFO - 2020-09-09 11:37:07 --> Helper loaded: form_helper
INFO - 2020-09-09 11:37:07 --> Database Driver Class Initialized
INFO - 2020-09-09 11:37:07 --> Form Validation Class Initialized
DEBUG - 2020-09-09 11:37:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 11:37:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 11:37:07 --> Encryption Class Initialized
INFO - 2020-09-09 11:37:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 11:37:08 --> Controller Class Initialized
INFO - 2020-09-09 11:37:08 --> Helper loaded: language_helper
INFO - 2020-09-09 11:37:08 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-09 11:37:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-09 11:37:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-09 11:37:08 --> Model "User" initialized
INFO - 2020-09-09 11:37:08 --> Config Class Initialized
INFO - 2020-09-09 11:37:08 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:37:08 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:37:08 --> Utf8 Class Initialized
INFO - 2020-09-09 11:37:08 --> URI Class Initialized
INFO - 2020-09-09 11:37:08 --> Router Class Initialized
INFO - 2020-09-09 11:37:08 --> Output Class Initialized
INFO - 2020-09-09 11:37:08 --> Security Class Initialized
DEBUG - 2020-09-09 11:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:37:09 --> Input Class Initialized
INFO - 2020-09-09 11:37:09 --> Language Class Initialized
INFO - 2020-09-09 11:37:09 --> Loader Class Initialized
INFO - 2020-09-09 11:37:09 --> Helper loaded: html_helper
INFO - 2020-09-09 11:37:09 --> Helper loaded: url_helper
INFO - 2020-09-09 11:37:09 --> Helper loaded: form_helper
INFO - 2020-09-09 11:37:09 --> Database Driver Class Initialized
INFO - 2020-09-09 11:37:09 --> Form Validation Class Initialized
DEBUG - 2020-09-09 11:37:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 11:37:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 11:37:09 --> Encryption Class Initialized
INFO - 2020-09-09 11:37:09 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 11:37:09 --> Controller Class Initialized
INFO - 2020-09-09 11:37:09 --> Helper loaded: language_helper
INFO - 2020-09-09 11:37:09 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 11:37:09 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-09 11:37:09 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 11:37:09 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-09 11:37:09 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 11:37:09 --> Final output sent to browser
DEBUG - 2020-09-09 11:37:09 --> Total execution time: 1.0604
INFO - 2020-09-09 11:37:16 --> Config Class Initialized
INFO - 2020-09-09 11:37:16 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:37:16 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:37:16 --> Utf8 Class Initialized
INFO - 2020-09-09 11:37:16 --> URI Class Initialized
INFO - 2020-09-09 11:37:16 --> Router Class Initialized
INFO - 2020-09-09 11:37:16 --> Output Class Initialized
INFO - 2020-09-09 11:37:16 --> Security Class Initialized
DEBUG - 2020-09-09 11:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:37:16 --> Input Class Initialized
INFO - 2020-09-09 11:37:16 --> Language Class Initialized
INFO - 2020-09-09 11:37:16 --> Loader Class Initialized
INFO - 2020-09-09 11:37:16 --> Helper loaded: html_helper
INFO - 2020-09-09 11:37:16 --> Helper loaded: url_helper
INFO - 2020-09-09 11:37:16 --> Helper loaded: form_helper
INFO - 2020-09-09 11:37:16 --> Database Driver Class Initialized
INFO - 2020-09-09 11:37:16 --> Form Validation Class Initialized
DEBUG - 2020-09-09 11:37:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 11:37:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 11:37:16 --> Encryption Class Initialized
INFO - 2020-09-09 11:37:16 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 11:37:17 --> Controller Class Initialized
INFO - 2020-09-09 11:37:17 --> Helper loaded: language_helper
INFO - 2020-09-09 11:37:17 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 11:37:17 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 11:37:17 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 11:37:17 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\purchase.php
INFO - 2020-09-09 11:37:17 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 11:37:17 --> Final output sent to browser
DEBUG - 2020-09-09 11:37:17 --> Total execution time: 0.6582
INFO - 2020-09-09 11:37:23 --> Config Class Initialized
INFO - 2020-09-09 11:37:23 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:37:23 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:37:23 --> Utf8 Class Initialized
INFO - 2020-09-09 11:37:23 --> URI Class Initialized
INFO - 2020-09-09 11:37:23 --> Router Class Initialized
INFO - 2020-09-09 11:37:23 --> Output Class Initialized
INFO - 2020-09-09 11:37:23 --> Security Class Initialized
DEBUG - 2020-09-09 11:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:37:23 --> Input Class Initialized
INFO - 2020-09-09 11:37:23 --> Language Class Initialized
INFO - 2020-09-09 11:37:23 --> Loader Class Initialized
INFO - 2020-09-09 11:37:23 --> Helper loaded: html_helper
INFO - 2020-09-09 11:37:23 --> Helper loaded: url_helper
INFO - 2020-09-09 11:37:23 --> Helper loaded: form_helper
INFO - 2020-09-09 11:37:23 --> Database Driver Class Initialized
INFO - 2020-09-09 11:37:23 --> Form Validation Class Initialized
DEBUG - 2020-09-09 11:37:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 11:37:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 11:37:23 --> Encryption Class Initialized
INFO - 2020-09-09 11:37:23 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 11:37:23 --> Controller Class Initialized
INFO - 2020-09-09 11:37:23 --> Helper loaded: language_helper
INFO - 2020-09-09 11:37:23 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 11:37:23 --> Model "Purchase_Model" initialized
INFO - 2020-09-09 11:37:23 --> Final output sent to browser
DEBUG - 2020-09-09 11:37:23 --> Total execution time: 0.6050
INFO - 2020-09-09 11:37:27 --> Config Class Initialized
INFO - 2020-09-09 11:37:27 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:37:27 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:37:27 --> Utf8 Class Initialized
INFO - 2020-09-09 11:37:27 --> URI Class Initialized
INFO - 2020-09-09 11:37:27 --> Router Class Initialized
INFO - 2020-09-09 11:37:27 --> Output Class Initialized
INFO - 2020-09-09 11:37:27 --> Security Class Initialized
DEBUG - 2020-09-09 11:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:37:27 --> Input Class Initialized
INFO - 2020-09-09 11:37:27 --> Language Class Initialized
INFO - 2020-09-09 11:37:27 --> Loader Class Initialized
INFO - 2020-09-09 11:37:27 --> Helper loaded: html_helper
INFO - 2020-09-09 11:37:27 --> Helper loaded: url_helper
INFO - 2020-09-09 11:37:27 --> Helper loaded: form_helper
INFO - 2020-09-09 11:37:27 --> Database Driver Class Initialized
INFO - 2020-09-09 11:37:27 --> Form Validation Class Initialized
DEBUG - 2020-09-09 11:37:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 11:37:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 11:37:27 --> Encryption Class Initialized
INFO - 2020-09-09 11:37:27 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 11:37:27 --> Controller Class Initialized
INFO - 2020-09-09 11:37:27 --> Helper loaded: language_helper
INFO - 2020-09-09 11:37:27 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 11:37:27 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 11:37:27 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 11:37:27 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment.php
INFO - 2020-09-09 11:37:27 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 11:37:27 --> Final output sent to browser
DEBUG - 2020-09-09 11:37:27 --> Total execution time: 0.7621
INFO - 2020-09-09 11:37:28 --> Config Class Initialized
INFO - 2020-09-09 11:37:28 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:37:28 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:37:28 --> Utf8 Class Initialized
INFO - 2020-09-09 11:37:28 --> URI Class Initialized
INFO - 2020-09-09 11:37:28 --> Router Class Initialized
INFO - 2020-09-09 11:37:28 --> Output Class Initialized
INFO - 2020-09-09 11:37:28 --> Security Class Initialized
DEBUG - 2020-09-09 11:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:37:28 --> Input Class Initialized
INFO - 2020-09-09 11:37:28 --> Language Class Initialized
INFO - 2020-09-09 11:37:28 --> Loader Class Initialized
INFO - 2020-09-09 11:37:28 --> Helper loaded: html_helper
INFO - 2020-09-09 11:37:28 --> Helper loaded: url_helper
INFO - 2020-09-09 11:37:28 --> Helper loaded: form_helper
INFO - 2020-09-09 11:37:28 --> Database Driver Class Initialized
INFO - 2020-09-09 11:37:28 --> Form Validation Class Initialized
DEBUG - 2020-09-09 11:37:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 11:37:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 11:37:28 --> Encryption Class Initialized
INFO - 2020-09-09 11:37:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 11:37:28 --> Controller Class Initialized
INFO - 2020-09-09 11:37:28 --> Helper loaded: language_helper
INFO - 2020-09-09 11:37:29 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 11:37:30 --> Final output sent to browser
DEBUG - 2020-09-09 11:37:30 --> Total execution time: 2.4280
INFO - 2020-09-09 12:42:59 --> Config Class Initialized
INFO - 2020-09-09 12:42:59 --> Hooks Class Initialized
DEBUG - 2020-09-09 12:42:59 --> UTF-8 Support Enabled
INFO - 2020-09-09 12:43:00 --> Utf8 Class Initialized
INFO - 2020-09-09 12:43:00 --> URI Class Initialized
INFO - 2020-09-09 12:43:00 --> Router Class Initialized
INFO - 2020-09-09 12:43:00 --> Output Class Initialized
INFO - 2020-09-09 12:43:00 --> Security Class Initialized
DEBUG - 2020-09-09 12:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 12:43:00 --> Input Class Initialized
INFO - 2020-09-09 12:43:00 --> Language Class Initialized
INFO - 2020-09-09 12:43:00 --> Loader Class Initialized
INFO - 2020-09-09 12:43:00 --> Helper loaded: html_helper
INFO - 2020-09-09 12:43:00 --> Helper loaded: url_helper
INFO - 2020-09-09 12:43:00 --> Helper loaded: form_helper
INFO - 2020-09-09 12:43:00 --> Database Driver Class Initialized
INFO - 2020-09-09 12:43:00 --> Form Validation Class Initialized
DEBUG - 2020-09-09 12:43:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 12:43:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 12:43:00 --> Encryption Class Initialized
INFO - 2020-09-09 12:43:00 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 12:43:00 --> Controller Class Initialized
INFO - 2020-09-09 12:43:00 --> Helper loaded: language_helper
INFO - 2020-09-09 12:43:00 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 12:43:00 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 12:43:00 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 12:43:00 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\purchase.php
INFO - 2020-09-09 12:43:00 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 12:43:00 --> Final output sent to browser
DEBUG - 2020-09-09 12:43:00 --> Total execution time: 0.9957
INFO - 2020-09-09 12:43:17 --> Config Class Initialized
INFO - 2020-09-09 12:43:17 --> Hooks Class Initialized
DEBUG - 2020-09-09 12:43:17 --> UTF-8 Support Enabled
INFO - 2020-09-09 12:43:17 --> Utf8 Class Initialized
INFO - 2020-09-09 12:43:17 --> URI Class Initialized
INFO - 2020-09-09 12:43:17 --> Router Class Initialized
INFO - 2020-09-09 12:43:18 --> Output Class Initialized
INFO - 2020-09-09 12:43:18 --> Security Class Initialized
DEBUG - 2020-09-09 12:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 12:43:18 --> Input Class Initialized
INFO - 2020-09-09 12:43:18 --> Language Class Initialized
INFO - 2020-09-09 12:43:18 --> Loader Class Initialized
INFO - 2020-09-09 12:43:18 --> Helper loaded: html_helper
INFO - 2020-09-09 12:43:18 --> Helper loaded: url_helper
INFO - 2020-09-09 12:43:18 --> Helper loaded: form_helper
INFO - 2020-09-09 12:43:18 --> Database Driver Class Initialized
INFO - 2020-09-09 12:43:18 --> Form Validation Class Initialized
DEBUG - 2020-09-09 12:43:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 12:43:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 12:43:18 --> Encryption Class Initialized
INFO - 2020-09-09 12:43:18 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 12:43:18 --> Controller Class Initialized
INFO - 2020-09-09 12:43:18 --> Helper loaded: language_helper
INFO - 2020-09-09 12:43:18 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 12:43:18 --> Model "Purchase_Model" initialized
INFO - 2020-09-09 12:43:18 --> Final output sent to browser
DEBUG - 2020-09-09 12:43:18 --> Total execution time: 0.6694
INFO - 2020-09-09 12:43:36 --> Config Class Initialized
INFO - 2020-09-09 12:43:36 --> Hooks Class Initialized
DEBUG - 2020-09-09 12:43:36 --> UTF-8 Support Enabled
INFO - 2020-09-09 12:43:36 --> Utf8 Class Initialized
INFO - 2020-09-09 12:43:36 --> URI Class Initialized
INFO - 2020-09-09 12:43:36 --> Router Class Initialized
INFO - 2020-09-09 12:43:36 --> Output Class Initialized
INFO - 2020-09-09 12:43:36 --> Security Class Initialized
DEBUG - 2020-09-09 12:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 12:43:36 --> Input Class Initialized
INFO - 2020-09-09 12:43:36 --> Language Class Initialized
INFO - 2020-09-09 12:43:36 --> Loader Class Initialized
INFO - 2020-09-09 12:43:36 --> Helper loaded: html_helper
INFO - 2020-09-09 12:43:36 --> Helper loaded: url_helper
INFO - 2020-09-09 12:43:36 --> Helper loaded: form_helper
INFO - 2020-09-09 12:43:36 --> Database Driver Class Initialized
INFO - 2020-09-09 12:43:36 --> Form Validation Class Initialized
DEBUG - 2020-09-09 12:43:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 12:43:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 12:43:36 --> Encryption Class Initialized
INFO - 2020-09-09 12:43:36 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 12:43:36 --> Controller Class Initialized
INFO - 2020-09-09 12:43:36 --> Helper loaded: language_helper
INFO - 2020-09-09 12:43:36 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 12:43:36 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 12:43:36 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 12:43:36 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment.php
INFO - 2020-09-09 12:43:36 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 12:43:36 --> Final output sent to browser
DEBUG - 2020-09-09 12:43:36 --> Total execution time: 0.6750
INFO - 2020-09-09 12:43:37 --> Config Class Initialized
INFO - 2020-09-09 12:43:37 --> Hooks Class Initialized
DEBUG - 2020-09-09 12:43:37 --> UTF-8 Support Enabled
INFO - 2020-09-09 12:43:37 --> Utf8 Class Initialized
INFO - 2020-09-09 12:43:37 --> URI Class Initialized
INFO - 2020-09-09 12:43:37 --> Router Class Initialized
INFO - 2020-09-09 12:43:37 --> Output Class Initialized
INFO - 2020-09-09 12:43:37 --> Security Class Initialized
DEBUG - 2020-09-09 12:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 12:43:37 --> Input Class Initialized
INFO - 2020-09-09 12:43:37 --> Language Class Initialized
INFO - 2020-09-09 12:43:37 --> Loader Class Initialized
INFO - 2020-09-09 12:43:37 --> Helper loaded: html_helper
INFO - 2020-09-09 12:43:37 --> Helper loaded: url_helper
INFO - 2020-09-09 12:43:37 --> Helper loaded: form_helper
INFO - 2020-09-09 12:43:37 --> Database Driver Class Initialized
INFO - 2020-09-09 12:43:38 --> Form Validation Class Initialized
DEBUG - 2020-09-09 12:43:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 12:43:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 12:43:38 --> Encryption Class Initialized
INFO - 2020-09-09 12:43:38 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 12:43:38 --> Controller Class Initialized
INFO - 2020-09-09 12:43:38 --> Helper loaded: language_helper
INFO - 2020-09-09 12:43:38 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 12:43:40 --> Final output sent to browser
DEBUG - 2020-09-09 12:43:40 --> Total execution time: 2.4964
INFO - 2020-09-09 12:44:59 --> Config Class Initialized
INFO - 2020-09-09 12:44:59 --> Hooks Class Initialized
DEBUG - 2020-09-09 12:44:59 --> UTF-8 Support Enabled
INFO - 2020-09-09 12:44:59 --> Utf8 Class Initialized
INFO - 2020-09-09 12:44:59 --> URI Class Initialized
INFO - 2020-09-09 12:44:59 --> Router Class Initialized
INFO - 2020-09-09 12:44:59 --> Output Class Initialized
INFO - 2020-09-09 12:44:59 --> Security Class Initialized
DEBUG - 2020-09-09 12:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 12:45:00 --> Input Class Initialized
INFO - 2020-09-09 12:45:00 --> Language Class Initialized
INFO - 2020-09-09 12:45:00 --> Loader Class Initialized
INFO - 2020-09-09 12:45:00 --> Helper loaded: html_helper
INFO - 2020-09-09 12:45:00 --> Helper loaded: url_helper
INFO - 2020-09-09 12:45:00 --> Helper loaded: form_helper
INFO - 2020-09-09 12:45:00 --> Database Driver Class Initialized
INFO - 2020-09-09 12:45:00 --> Form Validation Class Initialized
DEBUG - 2020-09-09 12:45:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 12:45:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 12:45:00 --> Encryption Class Initialized
INFO - 2020-09-09 12:45:00 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 12:45:00 --> Controller Class Initialized
INFO - 2020-09-09 12:45:00 --> Helper loaded: language_helper
INFO - 2020-09-09 12:45:00 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 12:45:00 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 12:45:00 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 12:45:00 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\purchase.php
INFO - 2020-09-09 12:45:00 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 12:45:00 --> Final output sent to browser
DEBUG - 2020-09-09 12:45:00 --> Total execution time: 0.7145
INFO - 2020-09-09 12:45:07 --> Config Class Initialized
INFO - 2020-09-09 12:45:07 --> Hooks Class Initialized
DEBUG - 2020-09-09 12:45:07 --> UTF-8 Support Enabled
INFO - 2020-09-09 12:45:07 --> Utf8 Class Initialized
INFO - 2020-09-09 12:45:07 --> URI Class Initialized
INFO - 2020-09-09 12:45:08 --> Router Class Initialized
INFO - 2020-09-09 12:45:08 --> Output Class Initialized
INFO - 2020-09-09 12:45:08 --> Security Class Initialized
DEBUG - 2020-09-09 12:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 12:45:08 --> Input Class Initialized
INFO - 2020-09-09 12:45:08 --> Language Class Initialized
INFO - 2020-09-09 12:45:08 --> Loader Class Initialized
INFO - 2020-09-09 12:45:08 --> Helper loaded: html_helper
INFO - 2020-09-09 12:45:08 --> Helper loaded: url_helper
INFO - 2020-09-09 12:45:08 --> Helper loaded: form_helper
INFO - 2020-09-09 12:45:08 --> Database Driver Class Initialized
INFO - 2020-09-09 12:45:08 --> Form Validation Class Initialized
DEBUG - 2020-09-09 12:45:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 12:45:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 12:45:08 --> Encryption Class Initialized
INFO - 2020-09-09 12:45:08 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 12:45:08 --> Controller Class Initialized
INFO - 2020-09-09 12:45:08 --> Helper loaded: language_helper
INFO - 2020-09-09 12:45:08 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 12:45:08 --> Model "Purchase_Model" initialized
INFO - 2020-09-09 12:45:08 --> Final output sent to browser
DEBUG - 2020-09-09 12:45:08 --> Total execution time: 0.6176
INFO - 2020-09-09 12:46:50 --> Config Class Initialized
INFO - 2020-09-09 12:46:50 --> Hooks Class Initialized
DEBUG - 2020-09-09 12:46:50 --> UTF-8 Support Enabled
INFO - 2020-09-09 12:46:50 --> Utf8 Class Initialized
INFO - 2020-09-09 12:46:50 --> URI Class Initialized
INFO - 2020-09-09 12:46:50 --> Router Class Initialized
INFO - 2020-09-09 12:46:50 --> Output Class Initialized
INFO - 2020-09-09 12:46:50 --> Security Class Initialized
DEBUG - 2020-09-09 12:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 12:46:50 --> Input Class Initialized
INFO - 2020-09-09 12:46:50 --> Language Class Initialized
INFO - 2020-09-09 12:46:50 --> Loader Class Initialized
INFO - 2020-09-09 12:46:50 --> Helper loaded: html_helper
INFO - 2020-09-09 12:46:50 --> Helper loaded: url_helper
INFO - 2020-09-09 12:46:50 --> Helper loaded: form_helper
INFO - 2020-09-09 12:46:50 --> Database Driver Class Initialized
INFO - 2020-09-09 12:46:51 --> Form Validation Class Initialized
DEBUG - 2020-09-09 12:46:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 12:46:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 12:46:51 --> Encryption Class Initialized
INFO - 2020-09-09 12:46:51 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 12:46:51 --> Controller Class Initialized
INFO - 2020-09-09 12:46:51 --> Helper loaded: language_helper
INFO - 2020-09-09 12:46:51 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 12:46:51 --> Final output sent to browser
DEBUG - 2020-09-09 12:46:51 --> Total execution time: 0.6509
INFO - 2020-09-09 12:46:51 --> Config Class Initialized
INFO - 2020-09-09 12:46:51 --> Hooks Class Initialized
DEBUG - 2020-09-09 12:46:51 --> UTF-8 Support Enabled
INFO - 2020-09-09 12:46:51 --> Utf8 Class Initialized
INFO - 2020-09-09 12:46:51 --> URI Class Initialized
DEBUG - 2020-09-09 12:46:51 --> No URI present. Default controller set.
INFO - 2020-09-09 12:46:51 --> Router Class Initialized
INFO - 2020-09-09 12:46:51 --> Output Class Initialized
INFO - 2020-09-09 12:46:51 --> Security Class Initialized
DEBUG - 2020-09-09 12:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 12:46:51 --> Input Class Initialized
INFO - 2020-09-09 12:46:51 --> Language Class Initialized
INFO - 2020-09-09 12:46:51 --> Loader Class Initialized
INFO - 2020-09-09 12:46:51 --> Helper loaded: html_helper
INFO - 2020-09-09 12:46:51 --> Helper loaded: url_helper
INFO - 2020-09-09 12:46:51 --> Helper loaded: form_helper
INFO - 2020-09-09 12:46:51 --> Database Driver Class Initialized
INFO - 2020-09-09 12:46:52 --> Form Validation Class Initialized
DEBUG - 2020-09-09 12:46:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 12:46:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 12:46:52 --> Encryption Class Initialized
INFO - 2020-09-09 12:46:52 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 12:46:52 --> Controller Class Initialized
INFO - 2020-09-09 12:46:52 --> Helper loaded: language_helper
INFO - 2020-09-09 12:46:52 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 12:46:52 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-09 12:46:52 --> Final output sent to browser
DEBUG - 2020-09-09 12:46:52 --> Total execution time: 0.8296
INFO - 2020-09-09 12:47:09 --> Config Class Initialized
INFO - 2020-09-09 12:47:09 --> Hooks Class Initialized
DEBUG - 2020-09-09 12:47:09 --> UTF-8 Support Enabled
INFO - 2020-09-09 12:47:09 --> Utf8 Class Initialized
INFO - 2020-09-09 12:47:09 --> URI Class Initialized
INFO - 2020-09-09 12:47:09 --> Router Class Initialized
INFO - 2020-09-09 12:47:09 --> Output Class Initialized
INFO - 2020-09-09 12:47:09 --> Security Class Initialized
DEBUG - 2020-09-09 12:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 12:47:09 --> Input Class Initialized
INFO - 2020-09-09 12:47:09 --> Language Class Initialized
INFO - 2020-09-09 12:47:09 --> Loader Class Initialized
INFO - 2020-09-09 12:47:09 --> Helper loaded: html_helper
INFO - 2020-09-09 12:47:09 --> Helper loaded: url_helper
INFO - 2020-09-09 12:47:09 --> Helper loaded: form_helper
INFO - 2020-09-09 12:47:09 --> Database Driver Class Initialized
INFO - 2020-09-09 12:47:09 --> Form Validation Class Initialized
DEBUG - 2020-09-09 12:47:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 12:47:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 12:47:09 --> Encryption Class Initialized
INFO - 2020-09-09 12:47:09 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 12:47:09 --> Controller Class Initialized
INFO - 2020-09-09 12:47:09 --> Helper loaded: language_helper
INFO - 2020-09-09 12:47:09 --> Language file loaded: language/english/content_lang.php
DEBUG - 2020-09-09 12:47:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2020-09-09 12:47:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-09 12:47:09 --> Model "User" initialized
INFO - 2020-09-09 12:47:10 --> Config Class Initialized
INFO - 2020-09-09 12:47:10 --> Hooks Class Initialized
DEBUG - 2020-09-09 12:47:10 --> UTF-8 Support Enabled
INFO - 2020-09-09 12:47:10 --> Utf8 Class Initialized
INFO - 2020-09-09 12:47:10 --> URI Class Initialized
INFO - 2020-09-09 12:47:10 --> Router Class Initialized
INFO - 2020-09-09 12:47:10 --> Output Class Initialized
INFO - 2020-09-09 12:47:10 --> Security Class Initialized
DEBUG - 2020-09-09 12:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 12:47:10 --> Input Class Initialized
INFO - 2020-09-09 12:47:10 --> Language Class Initialized
INFO - 2020-09-09 12:47:10 --> Loader Class Initialized
INFO - 2020-09-09 12:47:10 --> Helper loaded: html_helper
INFO - 2020-09-09 12:47:10 --> Helper loaded: url_helper
INFO - 2020-09-09 12:47:10 --> Helper loaded: form_helper
INFO - 2020-09-09 12:47:10 --> Database Driver Class Initialized
INFO - 2020-09-09 12:47:10 --> Form Validation Class Initialized
DEBUG - 2020-09-09 12:47:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 12:47:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 12:47:10 --> Encryption Class Initialized
INFO - 2020-09-09 12:47:10 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 12:47:10 --> Controller Class Initialized
INFO - 2020-09-09 12:47:10 --> Helper loaded: language_helper
INFO - 2020-09-09 12:47:10 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 12:47:10 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_header.php
INFO - 2020-09-09 12:47:10 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 12:47:10 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\dashboard_body.php
INFO - 2020-09-09 12:47:10 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 12:47:11 --> Final output sent to browser
DEBUG - 2020-09-09 12:47:11 --> Total execution time: 0.6728
INFO - 2020-09-09 12:52:38 --> Config Class Initialized
INFO - 2020-09-09 12:52:38 --> Hooks Class Initialized
DEBUG - 2020-09-09 12:52:38 --> UTF-8 Support Enabled
INFO - 2020-09-09 12:52:38 --> Utf8 Class Initialized
INFO - 2020-09-09 12:52:38 --> URI Class Initialized
INFO - 2020-09-09 12:52:38 --> Router Class Initialized
INFO - 2020-09-09 12:52:38 --> Output Class Initialized
INFO - 2020-09-09 12:52:38 --> Security Class Initialized
DEBUG - 2020-09-09 12:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 12:52:38 --> Input Class Initialized
INFO - 2020-09-09 12:52:38 --> Language Class Initialized
INFO - 2020-09-09 12:52:39 --> Loader Class Initialized
INFO - 2020-09-09 12:52:39 --> Helper loaded: html_helper
INFO - 2020-09-09 12:52:39 --> Helper loaded: url_helper
INFO - 2020-09-09 12:52:39 --> Helper loaded: form_helper
INFO - 2020-09-09 12:52:39 --> Database Driver Class Initialized
INFO - 2020-09-09 12:52:39 --> Form Validation Class Initialized
DEBUG - 2020-09-09 12:52:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 12:52:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 12:52:39 --> Encryption Class Initialized
INFO - 2020-09-09 12:52:39 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 12:52:39 --> Controller Class Initialized
INFO - 2020-09-09 12:52:39 --> Helper loaded: language_helper
INFO - 2020-09-09 12:52:39 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 12:52:39 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-09 12:52:39 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-09 12:52:39 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\purchase.php
INFO - 2020-09-09 12:52:39 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-09 12:52:39 --> Final output sent to browser
DEBUG - 2020-09-09 12:52:39 --> Total execution time: 0.7942
INFO - 2020-09-09 12:52:49 --> Config Class Initialized
INFO - 2020-09-09 12:52:49 --> Hooks Class Initialized
DEBUG - 2020-09-09 12:52:49 --> UTF-8 Support Enabled
INFO - 2020-09-09 12:52:49 --> Utf8 Class Initialized
INFO - 2020-09-09 12:52:49 --> URI Class Initialized
INFO - 2020-09-09 12:52:49 --> Router Class Initialized
INFO - 2020-09-09 12:52:49 --> Output Class Initialized
INFO - 2020-09-09 12:52:49 --> Security Class Initialized
DEBUG - 2020-09-09 12:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 12:52:49 --> Input Class Initialized
INFO - 2020-09-09 12:52:49 --> Language Class Initialized
INFO - 2020-09-09 12:52:49 --> Loader Class Initialized
INFO - 2020-09-09 12:52:49 --> Helper loaded: html_helper
INFO - 2020-09-09 12:52:49 --> Helper loaded: url_helper
INFO - 2020-09-09 12:52:49 --> Helper loaded: form_helper
INFO - 2020-09-09 12:52:49 --> Database Driver Class Initialized
INFO - 2020-09-09 12:52:49 --> Form Validation Class Initialized
DEBUG - 2020-09-09 12:52:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 12:52:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 12:52:49 --> Encryption Class Initialized
INFO - 2020-09-09 12:52:49 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 12:52:49 --> Controller Class Initialized
INFO - 2020-09-09 12:52:49 --> Helper loaded: language_helper
INFO - 2020-09-09 12:52:49 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 12:52:49 --> Model "Purchase_Model" initialized
INFO - 2020-09-09 12:52:49 --> Final output sent to browser
DEBUG - 2020-09-09 12:52:49 --> Total execution time: 0.6515
INFO - 2020-09-09 13:30:45 --> Config Class Initialized
INFO - 2020-09-09 13:30:45 --> Hooks Class Initialized
DEBUG - 2020-09-09 13:30:45 --> UTF-8 Support Enabled
INFO - 2020-09-09 13:30:45 --> Utf8 Class Initialized
INFO - 2020-09-09 13:30:45 --> URI Class Initialized
INFO - 2020-09-09 13:30:45 --> Router Class Initialized
INFO - 2020-09-09 13:30:45 --> Output Class Initialized
INFO - 2020-09-09 13:30:45 --> Security Class Initialized
DEBUG - 2020-09-09 13:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 13:30:45 --> Input Class Initialized
INFO - 2020-09-09 13:30:45 --> Language Class Initialized
INFO - 2020-09-09 13:30:45 --> Loader Class Initialized
INFO - 2020-09-09 13:30:45 --> Helper loaded: html_helper
INFO - 2020-09-09 13:30:46 --> Helper loaded: url_helper
INFO - 2020-09-09 13:30:46 --> Helper loaded: form_helper
INFO - 2020-09-09 13:30:46 --> Database Driver Class Initialized
INFO - 2020-09-09 13:30:46 --> Form Validation Class Initialized
DEBUG - 2020-09-09 13:30:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 13:30:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 13:30:46 --> Encryption Class Initialized
INFO - 2020-09-09 13:30:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 13:30:46 --> Controller Class Initialized
INFO - 2020-09-09 13:30:46 --> Helper loaded: language_helper
INFO - 2020-09-09 13:30:46 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 13:30:46 --> Final output sent to browser
DEBUG - 2020-09-09 13:30:46 --> Total execution time: 1.6524
INFO - 2020-09-09 13:30:47 --> Config Class Initialized
INFO - 2020-09-09 13:30:47 --> Hooks Class Initialized
DEBUG - 2020-09-09 13:30:47 --> UTF-8 Support Enabled
INFO - 2020-09-09 13:30:47 --> Utf8 Class Initialized
INFO - 2020-09-09 13:30:47 --> URI Class Initialized
DEBUG - 2020-09-09 13:30:47 --> No URI present. Default controller set.
INFO - 2020-09-09 13:30:47 --> Router Class Initialized
INFO - 2020-09-09 13:30:47 --> Output Class Initialized
INFO - 2020-09-09 13:30:47 --> Security Class Initialized
DEBUG - 2020-09-09 13:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 13:30:47 --> Input Class Initialized
INFO - 2020-09-09 13:30:47 --> Language Class Initialized
INFO - 2020-09-09 13:30:47 --> Loader Class Initialized
INFO - 2020-09-09 13:30:47 --> Helper loaded: html_helper
INFO - 2020-09-09 13:30:47 --> Helper loaded: url_helper
INFO - 2020-09-09 13:30:47 --> Helper loaded: form_helper
INFO - 2020-09-09 13:30:47 --> Database Driver Class Initialized
INFO - 2020-09-09 13:30:47 --> Form Validation Class Initialized
DEBUG - 2020-09-09 13:30:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-09 13:30:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-09 13:30:47 --> Encryption Class Initialized
INFO - 2020-09-09 13:30:48 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-09 13:30:48 --> Controller Class Initialized
INFO - 2020-09-09 13:30:48 --> Helper loaded: language_helper
INFO - 2020-09-09 13:30:48 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-09 13:30:48 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\login.php
INFO - 2020-09-09 13:30:48 --> Final output sent to browser
DEBUG - 2020-09-09 13:30:48 --> Total execution time: 0.6045
