<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-12 08:35:25 --> Config Class Initialized
INFO - 2020-09-12 08:35:25 --> Hooks Class Initialized
DEBUG - 2020-09-12 08:35:25 --> UTF-8 Support Enabled
INFO - 2020-09-12 08:35:25 --> Utf8 Class Initialized
INFO - 2020-09-12 08:35:25 --> URI Class Initialized
INFO - 2020-09-12 08:35:26 --> Router Class Initialized
INFO - 2020-09-12 08:35:26 --> Output Class Initialized
INFO - 2020-09-12 08:35:26 --> Security Class Initialized
DEBUG - 2020-09-12 08:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 08:35:26 --> Input Class Initialized
INFO - 2020-09-12 08:35:26 --> Language Class Initialized
INFO - 2020-09-12 08:35:26 --> Loader Class Initialized
INFO - 2020-09-12 08:35:26 --> Helper loaded: html_helper
INFO - 2020-09-12 08:35:26 --> Helper loaded: url_helper
INFO - 2020-09-12 08:35:27 --> Helper loaded: form_helper
INFO - 2020-09-12 08:35:27 --> Database Driver Class Initialized
INFO - 2020-09-12 08:35:27 --> Form Validation Class Initialized
DEBUG - 2020-09-12 08:35:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-09-12 08:35:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-09-12 08:35:27 --> Encryption Class Initialized
INFO - 2020-09-12 08:35:28 --> Session: Class initialized using 'database' driver.
INFO - 2020-09-12 08:35:28 --> Controller Class Initialized
INFO - 2020-09-12 08:35:28 --> Helper loaded: language_helper
INFO - 2020-09-12 08:35:29 --> Language file loaded: language/english/content_lang.php
INFO - 2020-09-12 08:35:29 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\header.php
INFO - 2020-09-12 08:35:29 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\sidebar.php
INFO - 2020-09-12 08:35:29 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\payment_custom.php
INFO - 2020-09-12 08:35:29 --> File loaded: C:\inetpub\vhosts\prosoftesolutions.com\httpdocs\cc_razor\application\views\footer.php
INFO - 2020-09-12 08:35:29 --> Final output sent to browser
DEBUG - 2020-09-12 08:35:29 --> Total execution time: 4.4458
