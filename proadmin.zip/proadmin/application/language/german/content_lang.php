<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$lang['welcome'] = 'Willkommen auf unserer Webseite';
$lang['message'] = 'Unsere Mission ist es, einem breiten Spektrum potenzieller Kunden auf der ganzen Welt professionelle und äußerst kreative Webdesign-Services und damit verbundene Dienstleistungen anzubieten.';
