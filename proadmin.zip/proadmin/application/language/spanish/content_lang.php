<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$lang['welcome'] = 'Bienvenido a nuestro sitio web';
$lang['message'] = 'Nuestra misión es proporcionar servicios de diseño web profesionales y altamente creativos y otros servicios relacionados a una amplia gama de clientes potenciales en todo el mundo.';
