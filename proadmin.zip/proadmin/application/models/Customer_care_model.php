<?php
class Customer_care_model extends CI_Model {

    function __construct()
    {
        //parent::__construct();
    }
	
	function get_data($maintenance_code, $serial_key, $mobile_no, $email_id)
	{
		$sql = "SELECT
					bt.SerialKey, 
					bt.id as Maintenance_code,
					bt.Edition,
					bt.Product,
					Subs_AMC_Type,
					Subs_AMC_Date,
					DATEADD(Month,No_Of_AMC, Subs_AMC_Date) ExpiryDate ,
					CASE WHEN DATEADD(MONTH,No_Of_AMC,Subs_AMC_Date) >= CAST(GETDATE() AS DATE) 
					THEN 'NOT EX' 
					ELSE 'EXPIRED' END AS [Status], 
					DATEDIFF(Day,CAST(GETDATE() AS DATE),DATEADD(MONTH,No_Of_AMC,Subs_AMC_Date)) AS [RemainingDays]	,
					InstalledDate,
					ik.EmailID,
					ik.PhoneNo,
					ik.UserName				
					, ik.InstalledKeyID
					, ik.ServerSerialKey
					, ik.Status
					, ClientUserID, PCName, MACAddress, HDDAddress, IPAddress, Latitude, Longitude
					, Address, IsBlocked, ClientID, SubscriptionDate, ik.SubscriptionType
					, ik.HasUnInstalled, UnInstalledDate, UnInstalledBy

				FROM SerialKey bt
					INNER JOIN InstalledKeys ik ON bt.SerialKey = ik.serialkey
					INNER JOIN [Subscription_AMC] amc ON amc.Serial_Key = ik.serialkey
				WHERE 1=1"			
				;
		
		if ($serial_key != ""){
			$sql .= " AND bt.serialkey = '". $serial_key ."'";
		}
		
		if ($maintenance_code != ""){
			$sql .= " AND bt.id = '". $maintenance_code ."'";
		}	
		
		if ($mobile_no != ""){
			$sql .= " AND ik.phoneno = '". $mobile_no ."'";
		}
		
		if ($email_id != ""){
			$sql .= " AND ik.emailid = '". $email_id ."'";
		}
		
		$sql .= " ORDER BY InstalledDate desc";
		
		//return $sql;
			
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0) 
		{
			return $query;
		}
		else
		{
			return 0;
		}
	}
	
	
	// get database data through api

	public function get_data_api($mobile, $email)
	{
					/****************curl library *****************/

			// dummy input
			$data_array=array(
				// 'mobile'=>'919743588121',
				// 'email'=>'arbaz@prosoftesolutions.com'
				'mobile'=>$mobile,
				'email'=>$email
			);

			// API key 
			$url="http://c5celltracker.azurewebsites.net/apps/support/fetchUserDetails.php";

			// connection
			$curl=curl_init();

			// Set cURL options
			curl_setopt($curl,CURLOPT_URL,$url);//set url
			curl_setopt($curl,CURLOPT_POST,TRUE);//when you use post request with parameters
			curl_setopt($curl,CURLOPT_POSTFIELDS,http_build_query($data_array));//when you use post request with parameters
			curl_setopt($curl,CURLOPT_RETURNTRANSFER,TRUE);//return data

			// execute cURL
			$response=curl_exec($curl);

			if(curl_error($curl)){
				echo "request-error :".curl_error($curl);
			}
			else{
				
				// // print_r($response);
				return $response;
			}

			// close cURL
			curl_close($curl);

			/*************************************************** */
	}
}	
?>