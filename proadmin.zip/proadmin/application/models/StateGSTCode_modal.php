<?php
class StateGSTCode_modal extends CI_Model {

    function __construct()
    {
        //parent::__construct();
    }
	
	function get_stategstcode()
	{
		$sql = "SELECT [State]
                        ,[CodeDigit]
                        ,[Code]
                        ,[StateGSTCode]
                        ,[IGSTRateGOVT]
                        ,[IGSTRatePRIVATE]
                        ,[SGSTRate]
                        ,[CGSTRate]
				FROM [prosoft_testdb].[dbo].[StateGSTCode]";
		
		//return $sql;
			
		$query = $this->db->query($sql);	
		return $query;
	}


}	
?>