<?php
class Download_model extends CI_Model {

    function __construct()
    {
        //parent::__construct();
    }
	
	function get_all_downloads($from_timestamp, $to_timestamp)
	{
		$sql = "SELECT id, full_name, contact_no, dept_email_id, department, designation, address, created_dt, serial_key, installed_dt, status, razorpay_order_id
				FROM [prosoft_testdb].[dbo].tbl_user_info 
				WHERE created_dt BETWEEN '". $from_timestamp ."' AND '". $to_timestamp ."'"		;	
				
		//return $sql;
			
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0) 
		{
			return $query;
		}
		else
		{
			return 0;
		}
	}	

	function get_downloads_by_status($from_timestamp, $to_timestamp, $onlytrial, $onlypurchased)
	{
		$sql = "SELECT id, full_name, contact_no, dept_email_id, department, designation, address, created_dt, serial_key, installed_dt, status, razorpay_order_id
				FROM [prosoft_testdb].[dbo].tbl_user_info 
				WHERE created_dt BETWEEN '". $from_timestamp ."' AND '". $to_timestamp ."'"		;	
				

		if ($onlytrial == "true"  && $onlypurchased == "true" ){
			$sql = $sql . " AND status = 'TRIAL' OR status = 'SUCCESS' ";
		}
		elseif ($onlypurchased== "true"){
			$sql = $sql . " AND status = 'SUCCESS'";
		}		
		elseif ($onlytrial == "true"){
			$sql = $sql . " AND status = 'TRIAL'";
		}

			
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0) 
		{
			return $query;
		}
		else
		{
			return 0;
		}
	}	

	function get_downloads_by_cust_info($mobile_no, $email_id, $from_timestamp, $to_timestamp, $order_id)
	{
		$sql = "SELECT id, full_name, contact_no, dept_email_id, department, designation, address, created_dt, serial_key, installed_dt, status, razorpay_order_id
				FROM [prosoft_testdb].[dbo].tbl_user_info
				WHERE 1 = 1"			
				;

		if ($from_timestamp != 0 && $to_timestamp != 0){
			$sql = $sql . " AND created_dt BETWEEN '". $from_timestamp ."' AND '". $to_timestamp ."'";
		}

		if ($mobile_no != ""){
			$sql = $sql . " AND contact_no = '". $mobile_no ."'";
		}

		if ($email_id != ""){
			$sql = $sql . " AND dept_email_id = '". $email_id ."'";
		}

		if ($order_id != ""){
			$sql = $sql . " AND razorpay_order_id = '". $order_id ."'";
		}
				
		//return $sql;
			
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0) 
		{
			return $query;
		}
		else
		{
			return 0;
		}
	}	
}	
?>