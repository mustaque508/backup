<?php
class Quotation_model extends CI_Model {

    function __construct()
    {
        //parent::__construct();
    }
	
	function get_quotation_details($quotation_no)
	{

	}	

	function is_quotation_number_exists($quotation_no)
	{
		$sql = "SELECT [Quotation_No]
					  FROM Quotation
					  WHERE Quotation_No = '". $quotation_no ."'
				";
			
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0) 
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	function save_quotation($state, $code, $cust_gstin, $currency, $customer_id, 
                            $quotation_no, $quotation_date, $reference_no, $reference_date, $preparedby, $project_job, $hsnsac_code, 
                            $total_beforegst, $igst, $sgst, $cgst, $round_off, $total_aftergst, $note, $revised_on_quot)
    {
		try
		{

			$storedata=array(

				// Customer Info
				'State'=>$state,
				'Code'=>$code,
				'Customer_GSTIN_No'=> $cust_gstin,
				'Currency'=> $currency,
				'Customer_ID'=>$customer_id,

				// Quotation Details
				'Quotation_No'=>$quotation_no,
				'Quotation_Date'=>$quotation_date,
				'Reference_No'=>$reference_no,
				'Reference_Date'=>$reference_date,
				'PreparedBy'=>$preparedby,
				'Project_Job'=>$project_job,
				'HSN_SAC_Code'=>$hsnsac_code,

				// Amount Details
				'Total_Before_GST'=>$total_beforegst,
				'IGST'=>$igst,
				'SGST'=>$sgst,
				'CGST'=>$cgst,
				'Round_Off'=>$round_off,
				'Total_After_GST'=>$total_aftergst,
				'GSTIN_No'=>"29AAFCP3322E1ZN",
				'PAN_No'=>"AAFCP3322E",
				'Note'=>$note,
				'RevisedOnQN'=>$revised_on_quot

			);

			$data=$this->db->insert('Quotation', $storedata);

			return ($data == 1) ?  TRUE :  FALSE ;



		}
		catch(Exception $e) 
		{
			return $e->getMessage();
		}

		// try {
		// 	//// Customer Info
		// 	$this->State = $state;
		// 	$this->Code = $code;
		// 	$this->Customer_GSTIN_No = $cust_gstin;
		// 	$this->Currency = $currency;
		// 	$this->Customer_ID = $customer_id;

		// 	//// Quotation Details
		// 	$this->Quotation_No = $quotation_no;
		// 	$this->Quotation_Date = $quotation_date; // $('#collected_datetime').data('datetimepicker');
		// 	$this->Reference_No = $reference_no;
		// 	$this->Reference_Date = $reference_date;
		// 	$this->PreparedBy = $preparedby;
        //     $this->Project_Job = $project_job;
            
		// 	$this->HSN_SAC_Code = $hsnsac_code;

		// 	//// Amount Details
		// 	$this->Total_Before_GST = $total_beforegst;
		// 	//$this->igst_percentage = $igst_percentage;
		// 	$this->IGST = $igst;
		// 	//$this->sgst_percentage = $sgst_percentage;
		// 	$this->SGST = $sgst;
		// 	//$this->cgst_percentage = $cgst_percentage;
		// 	$this->CGST = $cgst;
		// 	//$this->r_add = $add;
		// 	//$this->r_less = $less;
		// 	$this->Round_Off = $round_off;
		// 	$this->Total_After_GST = $total_aftergst;

		// 	$this->GSTIN_No = "29AAFCP3322E1ZN";
		// 	$this->PAN_No = "AAFCP3322E";

		// 	$this->Note = $note;
		// 	$this->RevisedOnQN = $revised_on_quot;
		
		// 	$this->db->insert('Quotation', $this);
		// 	//$record_id =  $this->db->insert_id();
		
		// 	return 1;
		// }catch(Exception $e) {
		// 	return $e->getMessage();
		// }
    }	

	function edit_quotation($state, $code, $cust_gstin, $currency, $customer_id, 
							$quotation_no, $quotation_date, $reference_no, $reference_date,$preparedby, $project_job, $hsnsac_code, 
							$total_beforegst, $igst, $sgst, $cgst, $round_off, $total_aftergst, $note, $revised_on_quot)
    {
		try {
			//// Customer Info
			$this->State = $state;
			$this->Code = $code;
			$this->Customer_GSTIN_No = $cust_gstin;
			$this->Currency = $currency;
			$this->Customer_ID = $customer_id;

			//// Quotation Details
			$this->Quotation_No = $quotation_no;
			$this->Quotation_Date = $quotation_date; // $('#collected_datetime').data('datetimepicker');
			$this->Reference_No = $reference_no;
            $this->Reference_Date = $reference_date;
            $this->PreparedBy = $preparedby;
			$this->Project_Job = $project_job;
			$this->HSN_SAC_Code = $hsnsac_code;

			//// Amount Details
			$this->Total_Before_GST = $total_beforegst;
			//$this->igst_percentage = $igst_percentage;
			$this->IGST = $igst;
			//$this->sgst_percentage = $sgst_percentage;
			$this->SGST = $sgst;
			//$this->cgst_percentage = $cgst_percentage;
			$this->CGST = $cgst;
			//$this->r_add = $add;
			//$this->r_less = $less;
			$this->Round_Off = $round_off;
			$this->Total_After_GST = $total_aftergst;

			$this->GSTIN_No = "29AAFCP3322E1ZN";
			$this->PAN_No = "AAFCP3322E";

			$this->Note = $note;
			$this->RevisedOnQN = $revised_on_quot;

			//// Delete existing Quotation
			$this->db->delete('Quotation', array('Quotation_No' => $quotation_no));	
		
			//// Save Quotation
			$this->db->insert('Quotation', $this);
			//$record_id =  $this->db->insert_id();
		
			return 1;
		}catch(Exception $e) {
			return $e->getMessage();
		}
    }	

	function save_quotation_items($quotation_no, $product_id, $description, $rate, $warranty, $amc_percentage, $quantity)
    {
		try {
			$this->Quotation_No = $quotation_no;
			$this->Product_ID = $product_id;
			$this->Description = $description;
			$this->Rate = $rate;
			$this->Warranty = $warranty;
			$this->AMC_Percentage = $amc_percentage;
			$this->Quantity = $quantity;
				
			$this->db->insert('Quotation_Items', $this);
			//$record_id =  $this->db->insert_id();
		
			return 1;
		}catch(Exception $e) {
			return $e->getMessage();
		}
    }

	function delete_quotation_items($quotation_no)
    {
		try {
			$this->db->delete('Quotation_Items', array('Quotation_No' => $quotation_no));					
			return 1;
		}catch(Exception $e) {
			return $e->getMessage();
		}
    }

	function get_quotations()
	{
		$sql = "SELECT [ID]
					  ,[Quotation_No]
					  ,[Quotation_Date]
					  ,[Reference_No]
					  ,[Reference_Date]
					  ,[PreparedBy]
					  ,[Project_Job]
					  ,[HSN_SAC_Code]
					  ,[GSTIN_No]
					  ,[PAN_No]
					  ,[State]
					  ,[Code]
					  ,[Customer_GSTIN_No]
					  ,[Customer_ID]
					  ,[Total_Before_GST]
					  ,[IGST]
					  ,[SGST]
					  ,[CGST]
					  ,[Round_Off]
					  ,[Total_After_GST]
					  ,[Note]
					  ,[RevisedOnQN]
				  FROM [prosoft_testdb].[dbo].[Quotation]"			
				;
			
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0) 
		{
			return $query;
		}
		else
		{
			return 0;
		}
	}	

	function get_selected_quotations($quotation_no)
	{
		$sql = "SELECT i.[ID]
						  ,[Quotation_No]
						  ,[Quotation_Date]
						  ,[Reference_No]
						  ,[Reference_Date]
    					  ,[PreparedBy]
						  ,[Project_Job]
						  ,[HSN_SAC_Code]
						  ,i.[GSTIN_No]
						  ,i.[PAN_No]
						  ,[State]
						  ,[Code]
						  ,[Customer_GSTIN_No]
						  ,i.[Customer_ID]
						  ,[Total_Before_GST]
						  ,[IGST]
						  ,[SGST]
						  ,[CGST]
						  ,[Round_Off]
						  ,[Total_After_GST]
						  ,c.Customer_Name
						  ,c.Customer_Address
						  ,[Currency]
						  ,[Note]
						  ,[RevisedOnQN]
					  FROM [prosoft_testdb].[dbo].Quotation i
					  INNER JOIN Customer c ON i.Customer_ID = c.Customer_ID
					  WHERE i.Quotation_No = '". $quotation_no ."'"
				  ;
			
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0) 
		{
			return $query;
		}
		else
		{
			return 0;
		}
	}

	function get_quotation_item_details($quotation_no)
	{
		$sql = "SELECT i.[ID]
						,i.[Quotation_No]
						,i.[Rate]
						,i.[Warranty]
						,i.[AMC_Percentage]
						,i.[Quantity]
						,p.Product_ID
						,p.Product_Name
						,i.Description
						,p.Edition
					FROM [prosoft_testdb].[dbo].Quotation_Items i
					INNER JOIN Product p ON i.Product_ID = p.Product_ID
					WHERE i.Quotation_No = '". $quotation_no ."'"		
				;

		//return $sql;
			
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0) 
		{
			return $query;
		}
		else
		{
			return 0;
		}
	}


	//delete Quotation based on Quotation Id
	public function delete_quotation($quotation_no){
		try {
			
			 $this->db->where('Quotation_No',$quotation_no);
			 $result=$this->db->delete('Quotation');

			 return (($result) ?  TRUE : FALSE);

			 
		}catch(Exception $e) {
			return $e->getMessage();
		}
	}
}	
?>