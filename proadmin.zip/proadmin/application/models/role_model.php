
<?php
class role_model extends CI_Model
{
    //get model details
    function get_modules()
    {
        $get=$this->db->query("select *from tbl_module");

          //check database contain data or not ?
          if($get->num_rows()>0)
          {
              return $get->result();
          }
        // if database is empty
          else
          {
              return "";
          }
    }


    //get role names
    function get_rolenames($role_id)
    {

       $sql="SELECT c.role_id ,role_name ,read_access ,write_access ,delete_access
             FROM tbl_roles c
             WHERE 1=1 ";


         if ($role_id != ""){
             $sql .= " AND c.role_id = '". $role_id ."'";
         }

         $query = $this->db->query($sql);

         //check database contain data or not ?
         if($query->num_rows()>0)
         {
             return $query->result();
         }
         // if database is empty
         else
         {
             return "";
         }


      
    }

    // get role details based on role_id
    function getrole_details($role_id)
    {
      $sql="SELECT r.role_id,r.role_name,ra.module_id,ra.read_access,ra.write_access,ra.delete_access
           from tbl_role_access ra
            inner join tbl_roles r
            on r.role_id = ra.role_id
            where r.role_id ='".$role_id."'";

        $query = $this->db->query($sql);

         //check database contain data or not ?
         if($query->num_rows()>0)
         {
             return $query->result();
         }
         // if database is empty
         else
         {
             return "";
         }
    }

    // store role details
    function store_role_details($user_data)
    {

        // insert into table[tbl_role_access]
          for ($i=0; $i <count($user_data['access_details']) ; $i++)
          { 
            $get_access_details=array(
              'role_id'=>$user_data['role_id'],
              'module_id'=>$user_data['access_details'][$i]['module_id'],
              'read_access'=>$user_data['access_details'][$i]['read_access'],
              'write_access'=>$user_data['access_details'][$i]['write_access'],
              'delete_access'=>$user_data['access_details'][$i]['delete_access']
            );

              $store_access_details=$this->db->insert('tbl_role_access',$get_access_details);
          }


        //insert into table[tbl_roles]
          $role_data=array(
            'role_name'=>$user_data['role_name'],
            'role_id'=>$user_data['role_id']
          );

          $store_role_details=$this->db->insert('tbl_roles',$role_data);


        if($store_access_details==1 &&  $store_role_details==1)
        {
          return TRUE;
        }
        else
        {
          return FALSE;
        }

    }


    //update role details
    function update_role_details($user_data)
    {

      // intialize 
        $result=FALSE;
        
          for ($i=0; $i <count($user_data['access_details']); $i++) 
          { 
              $get_access_details=array(
                'read_access'=>$user_data['access_details'][$i]['read_access'],
                'write_access'=>$user_data['access_details'][$i]['write_access'],
                'delete_access'=>$user_data['access_details'][$i]['delete_access']
              );

              // update role_access details
                $this->db->where(array('role_id'=>$user_data['role_id'] ,'module_id'=>$user_data['access_details'][$i]['module_id']));
                $result=$this->db->update('tbl_role_access',$get_access_details);

              
              // check if new record is occured
              if(!($this->db->affected_rows()))
              {
                  // if(true) insert new record
                  $new_model=array(
                    'role_id'=>$user_data['role_id'],
                    'module_id'=>$user_data['access_details'][$i]['module_id']
                  );
                  $result=$this->db->insert('tbl_role_access',array_merge($get_access_details,$new_model));

                  if($result==1)
                  {
                    $result=TRUE;
                  }
                  else
                  {
                    $result=FALSE;
                  }
              }
              
              //update role details
              $this->db->where(array('role_id'=>$user_data['role_id']));
              $result=$this->db->update('tbl_roles',array('role_name'=>$user_data['role_name']));

              // delete module_id if [read_access==write_access==delete_access==0]
              $access_details=array(
                'role_id'=>$user_data['role_id'],
                'module_id'=>$user_data['access_details'][$i]['module_id'],
                'read_access'=>0,
                'write_access'=>0,
                'delete_access'=>0
              );
              $this->db->where($access_details);
              $result=$this->db->delete('tbl_role_access');


          }



          if($result)
          {
            return TRUE; //if success
          }
          else
          {
            return FALSE; //if fail
          }
      
    }

    // delete role based on role id
    function delete_role_details($role_id)
    {
        // delete role-id from tbl_roles
          $this->db->where('role_id',$role_id);
          $result=$this->db->delete('tbl_roles');

        //delete role-id  from tbl_role_access
          $this->db->where('role_id',$role_id);
          $result=$this->db->delete('tbl_role_access');

         return (($result) ?  TRUE : FALSE);

    }
}

?>