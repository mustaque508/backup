<?php
class Contact_us_model extends CI_Model {

    function __construct()
    {
        //parent::__construct();
    }
	
	function get_data($from_timestamp, $to_timestamp)
	{
		$sql = "SELECT [id]
					  ,[f_name]
					  ,[contact_no]
					  ,[f_email]
					  ,[subject]
					  ,[message]
					  ,[contacted_on]
				FROM [prosoft_testdb].[dbo].tbl_contact_us
				WHERE contacted_on BETWEEN '". $from_timestamp ."' AND '". $to_timestamp ."'"			
				;
		
		//return $sql;
			
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0) 
		{
			return $query;
		}
		else
		{
			return 0;
		}
	}	
}	
?>