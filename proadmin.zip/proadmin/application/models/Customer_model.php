<?php
class Customer_model extends CI_Model {

    function __construct()
    {
        //parent::__construct();
    }
	
	function get_customers()
	{
		$sql = "SELECT [Customer_ID]
					,[Customer_Name]
					,[Customer_Address]
					,[Customer_City]
					,[Customer_State]
					,[Customer_Country]
					,[GSTIN_No]
					,[PAN_No]
					,[TAN_No]
				FROM [prosoft_testdb].[dbo].[CUSTOMER]";
		
		//return $sql;
			
		$query = $this->db->query($sql);
		return $query;
	}	

	function get_customer_details($customer_id)
	{
		$sql = "SELECT [Customer_ID]
					,[Customer_Name]
					,[Customer_Address]
					,[Customer_City]
					,[Customer_State]
					,[Customer_Country]
					,[GSTIN_No]
					,[PAN_No]
					,[TAN_No]
				FROM [prosoft_testdb].[dbo].[CUSTOMER] 
				WHERE Customer_ID = '". $customer_id ."'";
		
		//return $sql;
			
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0) 
		{
			return $query;
		}
		else
		{
			return 0;
		}
	}

	// function save_customer($customer_id, $customer_name, $address, $city, $state, $country, $gstin, $pan, $tan){
	// 	try {
	// 		$this->customer_id = $customer_id;
	// 		$this->customer_name = $customer_name;
	// 		$this->Customer_Address = $address;
	// 		$this->Customer_City = $city;
	// 		$this->Customer_State = $state;
	// 		$this->Customer_Country = $country;
	// 		$this->GSTIN_No = $gstin;
	// 		$this->PAN_No = $pan;
	// 		$this->TAN_No = $tan;

	// 		echo $this;
				
	// 		$this->db->insert('[prosoft_testdb].[dbo].[CUSTOMER]', $this);
	// 		//$record_id =  $this->db->insert_id();
		
	// 		return 1;
	// 	}catch(Exception $e) {
	// 		return $e->getMessage();
	// 	}
    // }

	// save customer record
	function save_customer ($store_data){
		try
		{
			$data=$this->db->insert('CUSTOMER',$store_data);

			return ($data == 1) ?  TRUE :  FALSE ;
		}
		catch(Exception $e) {
			return $e->getMessage();
		}
	}
}	
?>