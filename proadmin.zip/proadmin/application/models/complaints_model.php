<?php

class complaints_model extends CI_Model
{
 
    function get_data($complaintno, $username, $serialkey,$from_timestamp, $to_timestamp,$contact_no)
	{
		$sql="SELECT 
                    c.Id, ComplaintNo, Comp_date_time, Complaint, c.Status,  c.Name, userid, Serial_key, Contact, Email
                FROM [prosoft_testdb].[dbo].complaint_details c
                        inner join [prosoft_testdb].[dbo].[user_register_form] u ON c.userid = u.Id
                WHERE 1=1 ";

		
		if ($complaintno != ""){
			$sql .= " AND c.[ComplaintNo] = '". $complaintno ."'";
		}
		
		if ($username != ""){
			$sql .= " AND c.[Name] = '". $username ."'";
		}	
		
		if ($serialkey != ""){
			$sql .= " AND c.[Serial_key] =  '". $serialkey ."'";
		}

		if($contact_no!="")
		{
			$sql.=" AND  RIGHT(u.[Contact],10) = '".$contact_no."'";
		}
        
        // if ($from_timestamp != "" || $to_timestamp != ""){
		// 	$sql .= "  AND Comp_date_time BETWEEN '". $from_timestamp ."' AND '". $to_timestamp ."'";
		// }

		if ($from_timestamp != "" || $to_timestamp != ""){
			$sql .= "  AND Comp_date_time BETWEEN '". $from_timestamp ."' AND '". $to_timestamp ."'";
		}
        
		
		$sql .= " order by Comp_date_time desc";
		
		//return $sql;
			
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0) 
		{
			return $query;
		}
		else
		{
			return 0;
		}
	}
	

	//get complaint history
		function get_complaint_history($complaintno)
		{
			$sql="SELECT
				Id, ComplaintNo, ActionTaken, ActionDate, ActionStatus, Remark, userid
				from complaint_history
				where complaintNo = '".$complaintno."' 
				Order by ActionDate desc ";
			
			$query = $this->db->query($sql);
			if ($query->num_rows() > 0) 
			{
				return $query;
			}
			else
			{
				return 0;
			}
		}

	//store complaint_history
		function store_complaint_history($getData)
		{
			$data=$this->db->insert('complaint_history',$getData);

			if($data==1)
			{
			  // success
			  return TRUE;
			}
			else
			{
			  // fail
			  return FALSE;
			}
		}
}

?>
