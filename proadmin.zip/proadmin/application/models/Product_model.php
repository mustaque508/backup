<?php
class Product_model extends CI_Model {

    function __construct()
    {
        //parent::__construct();
    }
	
	function get_products()
	{
		$sql = "SELECT [ID]
					  ,[Product_ID]
					  ,[Product_Name]
					  ,[Product_Desc]
					  ,[Rate]
					  ,[Edition]
				FROM [prosoft_testdb].[dbo].[PRODUCT]";
		
		//return $sql;
			
		$query = $this->db->query($sql);	
		return $query;
	}

	function get_distinct_product_names()
	{
		$sql = "SELECT DISTINCT([Product_Name]) 
				FROM [prosoft_testdb].[dbo].[PRODUCT]";
		
		//return $sql;
			
		$query = $this->db->query($sql);		
		return $query;		
	}
	
	function get_product_editions($product_name)
	{
		$sql = "SELECT [Edition]
				FROM [prosoft_testdb].[dbo].[PRODUCT]
				WHERE Product_Name = '". $product_name ."'";
		
		//return $sql;
			
		$query = $this->db->query($sql);
		return $query;
	}

	function get_product_details($product_id)
	{
		$sql = "SELECT [ID]
					  ,[Product_ID]
					  ,[Product_Name]
					  ,[Product_Desc]
					  ,[Rate]
					  ,[Edition]
				FROM [prosoft_testdb].[dbo].[PRODUCT] 
				WHERE Product_ID = '". $product_id ."'";
		
		//return $sql;
			
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0) 
		{
			return $query;
		}
		else
		{
			return 0;
		}
	}

	function get_product_id($product_name, $edition)
	{
		$product_id = "";
		$sql = "SELECT [Product_ID]					  
				FROM [prosoft_testdb].[dbo].[PRODUCT] 
				WHERE Product_Name = '". $product_name ."' AND Edition = '". $edition ."'";
		
		//return $sql;
			
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0) 
		{
			$data = $query->result();
			foreach($data as $row)
			{
				$product_id = $row->Product_ID;
			}
		}
		
		return $product_id;
	}

	function save_product($store_data){
		try
		{
			$data=$this->db->insert('Product',$store_data);

			return ($data == 1) ?  TRUE :  FALSE ;
		}
		catch(Exception $e) {
			return $e->getMessage();
		}
    }
}	
?>