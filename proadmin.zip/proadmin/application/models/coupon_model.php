<?php

class coupon_model extends CI_Model
{
 
    function get_data($get_details)
	{
		// return $get_details;
		
		$sql="SELECT 
			cc.ID
			,cc.[CouponCode]
			,cc.[VendorID_CustomerID]
			,v.[Vendor_Name]	
			,cc.[CouponValue]
			,sp.[OfferPrice]
			,sp.[SubscriptionName]
			,sp.[Product_Name]
			,sp.[Edition]
			,cc.[IsUsed]
			,cc.[CouponOfferPrice]
			,cc.[CouponUsedDate]
			,o.[OfferName]
			,cc.[SerialKey]
	
			FROM [prosoft_testdb].[dbo].[Coupon] cc
				left outer join [dbo].[SubscriptionPlan] sp ON cc.[SubscriptionPlan_No] = sp.[SubscriptionPlan_No]
				left outer join [dbo].[Vendor] v ON v.[Vendor_ID] = cc.[VendorID_CustomerID]
				left outer join [dbo].[Customer] c ON  c.[Customer_ID] = cc.[VendorID_CustomerID]
				INNER JOIN Offers o ON o.OfferName = cc.OfferName
	
			where 1=1";

		
		if ($get_details['couponcode'] != ""){
			$sql .= " AND cc.[CouponCode] = '". $get_details['couponcode'] ."'";
		}
		
	
		if ($get_details['vendor_id'] != "0"){
			$sql .= " AND [VendorID_CustomerID] = '". $get_details['vendor_id'] ."'";
		}	
	
		// ($get_details['isused']=="true") ? $sql .= " AND cc.[IsUsed] = '1'" : $sql .= " AND cc.[IsUsed] = '0'"; 

		if ($get_details['isused'] == "true"){
			$sql .= " AND cc.[IsUsed] = '1'";
		}


		
		if ($get_details['fromDateTime'] != "" || $get_details['toDateTime'] != ""){
			$sql .= "  AND cc.[CouponUsedDate] BETWEEN '". $get_details['fromDateTime'] ."' AND '". $get_details['toDateTime'] ."'";
		}

		if ($get_details['offername'] != ""){
			$sql .= " AND o.[OfferName] = '". $get_details['offername'] ."'";
		}	
		
		$sql .= " order by cc.id desc";
		
		//return $sql;
			
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0) 
		{
			return $query;
		}
		else
		{
			return 0;
		}
	}


	// get get_offer_details
	function get_offer_details()
	{
		$sql="SELECT DISTINCT
			  OfferName ,StartDate,ExpiryDate,IsActive
			  FROM Offers";

		$query = $this->db->query($sql);
		if ($query->num_rows() > 0) 
		{
			return $query->result();
		}
		else
		{
			return "";
		}

	}
	
}

?>