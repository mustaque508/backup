<?php
class Purchase_Model extends CI_Model {

    function __construct()
    {
        //parent::__construct();
    }
	
	function get_all_purchases($from_timestamp, $to_timestamp, $top_records)
	{
		$sql = "SELECT `id`, `full_name`, `contact_no`, `dept_email_id`, `department`, `designation`, `address`, `created_dt`, `serial_key`, `installed_dt`, `status`, `razorpay_order_id`
				FROM [prosoft_testdb].[dbo].tbl_user_info
				WHERE UNIX_TIMESTAMP(`created_dt`) BETWEEN ". $from_timestamp ." AND ". $to_timestamp ."
				LIMIT ". $top_records .""				
				;
				
		//return $sql;
			
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0) 
		{
			return $query;
		}
		else
		{
			return 0;
		}
	}	
}	
?>