<?php

class monthly_sales_model extends CI_Model
{
    
}


?>