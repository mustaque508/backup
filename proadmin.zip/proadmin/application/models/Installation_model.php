<?php
class Installation_model extends CI_Model {

    function __construct()
    {
        //parent::__construct();
    }
	
	// function get_data($product_name, $edition, $from_timestamp, $to_timestamp, $maintenance_code, $serial_key, $mobile_no, $email_id)
	function get_data($from_timestamp, $to_timestamp, $maintenance_code, $serial_key, $mobile_no, $email_id)

	{
		$sql = "SELECT
					bt.SerialKey, 
					bt.id as Maintenance_code,
	
					bt.Product,
					bt.Edition,ik.SubscriptionType,Subs_AMC_Type,
					InstalledDate,
					Subs_AMC_Date, 
					CASE WHEN DATEADD(MONTH,No_Of_AMC,Subs_AMC_Date) >= CAST(GETDATE() AS DATE) 
					THEN 'NOT EX' 
					ELSE 'EXPIRED' END AS [Status], 
					DATEADD(Month,No_Of_AMC, Subs_AMC_Date) ExpiryDate ,
					DATEDIFF(Day,CAST(GETDATE() AS DATE),DATEADD(MONTH,No_Of_AMC,Subs_AMC_Date)) AS [RemainingDays],
					ik.UserName,		
					ik.PhoneNo,
					ik.EmailID,	
					ik.InstalledKeyID,
					ik.ServerSerialKey,
					ik.Status,
					ClientUserID, PCName, MACAddress, HDDAddress, IPAddress, Latitude, Longitude,
					Address, IsBlocked, ClientID, SubscriptionDate,
					ik.HasUnInstalled, UnInstalledDate, UnInstalledBy

				FROM [prosoft_testdb].[dbo].[SerialKey] bt
					INNER JOIN [prosoft_testdb].[dbo].[InstalledKeys] ik ON bt.SerialKey = ik.serialkey
					INNER JOIN [prosoft_testdb].[dbo].[Subscription_AMC] amc ON amc.Serial_Key = ik.serialkey
				WHERE 1=1 "			
				;
		
		// if ($product_name != ""){
		// 	$sql .= " AND bt.Product = '". $product_name ."'";
		// }

		// if ($edition != ""){
		// 	$sql .= " AND bt.edition = '". $edition ."'";
		// }

		if ($from_timestamp != "" || $to_timestamp != ""){
			$sql .= "  AND InstalledDate BETWEEN '". $from_timestamp ."' AND '". $to_timestamp ."'";
		}



		
		if ($serial_key != ""){
			$sql .= " AND bt.serialkey = '". $serial_key ."'";
		}
		
		if ($maintenance_code != ""){
			$sql .= " AND bt.id = '". $maintenance_code ."'";
		}	
		
		if ($mobile_no != ""){
			$sql .= " AND ik.phoneno = '". $mobile_no ."'";
		}
		
		if ($email_id != ""){
			$sql .= " AND ik.emailid = '". $email_id ."'";
		}
		
		$sql .= " ORDER BY InstalledDate desc";
		
		//return $sql;
			
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0) 
		{
			return $query;
		}
		else
		{
			return 0;
		}
	}	
}	
?>