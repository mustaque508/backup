<?php

class user_model extends CI_Model
{
    // get role details
    function get_roleDetails()
    {
        $get=$this->db->query("select *from tbl_roles");

          //check database contain data or not ?
          if($get->num_rows()>0)
          {
              return $get->result();
          }
        // if database is empty
          else
          {
              return "";
          }
    }


    //store user details
    function storeData($user_data)
    {
        $data=$this->db->insert('tbl_users',$user_data);

        if($data==1)
        {
          // success
          return TRUE;
        }
        else
        {
          // fail
          return FALSE;
        }
    }

     // get user details
     public function getUserDetails($user_id)
     {
         $sql="SELECT c.user_id ,user_name,password,contact_no,email,role_id
             FROM tbl_users c
             WHERE 1=1 ";


         if ($user_id != ""){
             $sql .= " AND c.user_id = '". $user_id ."'";
         }

         $query = $this->db->query($sql);

         //check database contain data or not ?
         if($query->num_rows()>0)
         {
             return $query->result();
         }
         // if database is empty
         else
         {
             return "";
         }

     }


     //update user_details
     public function update_Details($user_data,$user_id)
     {
        $this->db->where('user_id',$user_id);
        $result=$this->db->update('tbl_users',$user_data);

         if($result)
           {
                // success
                return TRUE;
           }
           else
           {
                // fail
               return FALSE;
           }
     }


     //delete user details based on [user_id]
     public function delete_Details($user_id)
     {
         $this->db->where('user_id',$user_id);
         $result=$this->db->delete('tbl_users');

         if($result)
         {
              // success
              return TRUE;
         }
         else
         {
              // fail
             return FALSE;
         }
     }

}

?>