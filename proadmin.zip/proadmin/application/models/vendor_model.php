<?php

class vendor_model extends CI_Model
{
    function __construct()
    {
        //parent::__construct();
    }

    function get_vendors()
    {


        $this->db->select(['Vendor_ID','Vendor_Name']);
        $get=$this->db->get('Vendor');

        if($get->num_rows()>0)
        {
            return $get->result();
        }
        else
        {
            return 0;
        }
    }

}

?>