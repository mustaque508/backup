<?php
class Invoice_model extends CI_Model {

    function __construct()
    {
        //parent::__construct();
    }
	
	function get_invoice_details($invoice_no)
	{
		$sql = "SELECT
					bt.SerialKey, 
					bt.id as Maintenance_code,
					bt.Edition,
					bt.Product,
					Subs_AMC_Type,
					Subs_AMC_Date,
					DATEADD(Month,No_Of_AMC, Subs_AMC_Date) ExpiryDate ,
					CASE WHEN DATEADD(MONTH,No_Of_AMC,Subs_AMC_Date) >= CAST(GETDATE() AS DATE) 
					THEN 'NOT EX' 
					ELSE 'EXPIRED' END AS [Status], 
					DATEDIFF(Day,CAST(GETDATE() AS DATE),DATEADD(MONTH,No_Of_AMC,Subs_AMC_Date)) AS [RemainingDays]	,
					InstalledDate,
					ik.EmailID,
					ik.PhoneNo,
					ik.UserName				
					, ik.InstalledKeyID
					, ik.ServerSerialKey
					, ik.Status
					, ClientUserID, PCName, MACAddress, HDDAddress, IPAddress, Latitude, Longitude
					, Address, IsBlocked, ClientID, SubscriptionDate, ik.SubscriptionType
					, ik.HasUnInstalled, UnInstalledDate, UnInstalledBy

				FROM SerialKey bt
					INNER JOIN InstalledKeys ik ON bt.SerialKey = ik.serialkey
					INNER JOIN [Subscription_AMC] amc ON amc.Serial_Key = ik.serialkey
				WHERE InstalledDate BETWEEN '". $from_timestamp ."' AND '". $to_timestamp ."'"			
				;
		
		if ($serial_key != ""){
			$sql .= " AND bt.serialkey = '". $serial_key ."'";
		}
		
		if ($maintenance_code != ""){
			$sql .= " AND bt.id = '". $maintenance_code ."'";
		}	
		
		if ($mobile_no != ""){
			$sql .= " AND ik.phoneno = '". $mobile_no ."'";
		}
		
		if ($email_id != ""){
			$sql .= " AND ik.emailid = '". $email_id ."'";
		}
		
		$sql .= " ORDER BY InstalledDate desc";
		
		//return $sql;
			
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0) 
		{
			return $query;
		}
		else
		{
			return 0;
		}
	}	

	function is_invoice_number_exists($invoice_no)
	{
		$sql = "SELECT [Invoice_No]
					  FROM [prosoft_testdb].[dbo].INVOICE
					  WHERE Invoice_No = '". $invoice_no ."'
				";
			
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0) 
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	function save_invoice($state, $code, $cust_gstin, $currency, $customer_id, 
							$invoice_no, $invoice_date, $order_no, $order_date, $project_job, $hsnsac_code, 
							$total_beforegst, $igst, $sgst, $cgst, $round_off, $total_aftergst)
    {
		try {
			//// Customer Info
			$this->State = $state;
			$this->Code = $code;
			$this->Customer_GSTIN_No = $cust_gstin;
			$this->Currency = $currency;
			$this->Customer_ID = $customer_id;

			//// Invoice Details
			$this->Invoice_No = $invoice_no;
			$this->Invoice_Date = $invoice_date; // $('#collected_datetime').data('datetimepicker');
			$this->Order_No = $order_no;
			$this->Order_Date = $order_date;
			$this->Project_Job = $project_job;
			$this->HSN_SAC_Code = $hsnsac_code;

			//// Amount Details
			$this->Total_Before_GST = $total_beforegst;
			//$this->igst_percentage = $igst_percentage;
			$this->IGST = $igst;
			//$this->sgst_percentage = $sgst_percentage;
			$this->SGST = $sgst;
			//$this->cgst_percentage = $cgst_percentage;
			$this->CGST = $cgst;
			//$this->r_add = $add;
			//$this->r_less = $less;
			$this->Round_Off = $round_off;
			$this->Total_After_GST = $total_aftergst;

			$this->GSTIN_No = "29AAFCP3322E1ZN";
			$this->PAN_No = "AAFCP3322E";
		
			$this->db->insert('INVOICE', $this);
			//$record_id =  $this->db->insert_id();
		
			return 1;
		}catch(Exception $e) {
			return $e->getMessage();
		}
    }	

	function edit_invoice($state, $code, $cust_gstin, $currency, $customer_id, 
							$invoice_no, $invoice_date, $order_no, $order_date, $project_job, $hsnsac_code, 
							$total_beforegst, $igst, $sgst, $cgst, $round_off, $total_aftergst)
    {
		try {
			//// Customer Info
			$this->State = $state;
			$this->Code = $code;
			$this->Customer_GSTIN_No = $cust_gstin;
			$this->Currency = $currency;
			$this->Customer_ID = $customer_id;

			//// Invoice Details
			$this->Invoice_No = $invoice_no;
			$this->Invoice_Date = $invoice_date; // $('#collected_datetime').data('datetimepicker');
			$this->Order_No = $order_no;
			$this->Order_Date = $order_date;
			$this->Project_Job = $project_job;
			$this->HSN_SAC_Code = $hsnsac_code;

			//// Amount Details
			$this->Total_Before_GST = $total_beforegst;
			//$this->igst_percentage = $igst_percentage;
			$this->IGST = $igst;
			//$this->sgst_percentage = $sgst_percentage;
			$this->SGST = $sgst;
			//$this->cgst_percentage = $cgst_percentage;
			$this->CGST = $cgst;
			//$this->r_add = $add;
			//$this->r_less = $less;
			$this->Round_Off = $round_off;
			$this->Total_After_GST = $total_aftergst;

			$this->GSTIN_No = "29AAFCP3322E1ZN";
			$this->PAN_No = "AAFCP3322E";

			//// Delete existing Invoice
			$this->db->delete('INVOICE', array('Invoice_No' => $invoice_no));	
		
			//// Save Invoice
			$this->db->insert('INVOICE', $this);
			//$record_id =  $this->db->insert_id();
		
			return 1;
		}catch(Exception $e) {
			return $e->getMessage();
		}
    }	

	function save_invoice_items($invoice_no, $product_id, $description, $rate, $warranty, $amc_percentage, $quantity)
    {
		try {
			$this->Invoice_No = $invoice_no;
			$this->Product_ID = $product_id;
			$this->Description = $description;
			$this->Rate = $rate;
			$this->Warranty = $warranty;
			$this->AMC_Percentage = $amc_percentage;
			$this->Quantity = $quantity;
				
			$this->db->insert('INVOICE_ITEMS', $this);
			//$record_id =  $this->db->insert_id();
		
			return 1;
		}catch(Exception $e) {
			return $e->getMessage();
		}
    }

	function delete_invoice_items($invoice_no)
    {
		try {
			$this->db->delete('INVOICE_ITEMS', array('Invoice_No' => $invoice_no));					
			return 1;
		}catch(Exception $e) {
			return $e->getMessage();
		}
    }

	function get_invoices()
	{
		$sql = "SELECT [ID]
					  ,[Invoice_No]
					  ,[Invoice_Date]
					  ,[Order_No]
					  ,[Order_Date]
					  ,[Project_Job]
					  ,[HSN_SAC_Code]
					  ,[GSTIN_No]
					  ,[PAN_No]
					  ,[State]
					  ,[Code]
					  ,[Customer_GSTIN_No]
					  ,[Customer_ID]
					  ,[Total_Before_GST]
					  ,[IGST]
					  ,[SGST]
					  ,[CGST]
					  ,[Round_Off]
					  ,[Total_After_GST]
				  FROM [prosoft_testdb].[dbo].[INVOICE]"			
				;
			
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0) 
		{
			return $query;
		}
		else
		{
			return 0;
		}
	}	

	function get_selected_invoices($invoice_no)
	{
		$sql = "SELECT i.[ID]
						  ,[Invoice_No]
						  ,[Invoice_Date]
						  ,[Order_No]
						  ,[Order_Date]
						  ,[Project_Job]
						  ,[HSN_SAC_Code]
						  ,i.[GSTIN_No]
						  ,i.[PAN_No]
						  ,[State]
						  ,[Code]
						  ,[Customer_GSTIN_No]
						  ,i.[Customer_ID]
						  ,[Total_Before_GST]
						  ,[IGST]
						  ,[SGST]
						  ,[CGST]
						  ,[Round_Off]
						  ,[Total_After_GST]
						  ,c.Customer_Name
						  ,c.Customer_Address
						  ,[Currency]
					  FROM [prosoft_testdb].[dbo].INVOICE i
					  INNER JOIN Customer c ON i.Customer_ID = c.Customer_ID
					  WHERE i.Invoice_No = '". $invoice_no ."'"
				  ;
			
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0) 
		{
			return $query;
		}
		else
		{
			return 0;
		}
	}

	function get_invoice_item_details($invoice_no)
	{
		$sql = "SELECT i.[ID]
						,i.[Invoice_No]
						,i.[Rate]
						,i.[Warranty]
						,i.[AMC_Percentage]
						,i.[Quantity]
						,p.Product_ID
						,p.Product_Name
						,i.Description
					FROM [prosoft_testdb].[dbo].INVOICE_ITEMS i
					INNER JOIN Product p ON i.Product_ID = p.Product_ID
					WHERE i.Invoice_No = '". $invoice_no ."'"		
				;

		//return $sql;
			
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0) 
		{
			return $query;
		}
		else
		{
			return 0;
		}
	}
}	
?>